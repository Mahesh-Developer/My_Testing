# -*- coding: utf-8 -*-
"""
Created on Sun Jun 05 17:30:02 2016

@author: rajeeshv
"""


import pandas as pd
import networkx as nx
import numpy as np
from pandas import ExcelWriter
from datetime import datetime, timedelta, time
from py2neo import authenticate, Graph
authenticate("localhost:7474", "neo4j", "server")
import datetime
import time
import traceback
import ftplib

from pandas import pivot_table
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import os


oppath2 = 'D:/Python/Scripts and Files/Path and Graph Files/ETA_Data.csv'
print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppath2
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()

#FTP Upload ends
ftpend = datetime.datetime.now().time()
print 'ftpend is', ftpend
