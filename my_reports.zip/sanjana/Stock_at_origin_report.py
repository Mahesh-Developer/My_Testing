# -*- coding: utf-8 -*-
"""
Created on Wed Apr 19 11:51:34 2017

@author: rajeeshv
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
import calendar
from pandas import ExcelWriter
import glob
import smtplib
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import Utilities

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()
try:
  cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
  cursor = cnxn.cursor()

  query = ("""EXEC USP_ORIGINSC_STOCK """)
  print (query)

  originstock = pd.read_sql(query, Utilities.cnxn)
  print ('data',len(originstock))
  # In[7]:
  # originstock = pd.read_csv('http://spoton.co.in/downloads/IEProjects/STOCKOrigin/StockOrigin.csv')

  datetimenow = datetime.now()

  opfilevar=datetimenow.date()
  opfilevar1=datetimenow.time()
  ct2= str (opfilevar1)
  currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

  opfilevar2=np.round((float(currhrs)/60),0)

  def roundofffuc(actwt):
      wt_in_ton = pd.np.round((actwt*1.0)/1000.0,1)
      return wt_in_ton

  #originstock = originstock.rename(columns={'\xef\xbb\xbfDOCKNO':'DOCKNO'})

  ## Exclude DEPS/Sender/Reciever Failures
  excludelist = ['DEPS','SENDER FAILURE','RECEIVER FAILURE']
  originstock = originstock[~(originstock['LatConStatusCategory'].isin(excludelist))]
  ## Exclude DEPS/Sender/Reciever Failures

  orggrp = originstock.groupby(['ORGREGION','ORGDEPOT','ORGAREA','ORGBRCD','ORGBRNM']).agg({'DOCKNO':len,'ACTUWT':sum}).reset_index().sort_values('ACTUWT',ascending=False)

  orggrp['ACTUWT'] = orggrp.apply(lambda x:roundofffuc(x['ACTUWT']),axis=1) 

  orggrp.to_csv(r'D:\Data\Load_available_origin\Summary\Load_Available_Origin_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv')
  orggrp.to_csv(r'D:\Data\Load_available_origin\Load_Available_Origin.csv')

  oppath2 = r'D:\Data\Load_available_origin\Load_Available_Origin.csv'

  orggrp = orggrp.rename(columns={'ORGBRCD':'LOCN','DOCKNO':'CON','ACTUWT':'WT','ORGBRNM':'LOC_NAME'})
  orgmail = orggrp[['LOCN','CON','WT','LOC_NAME']]
  orgmail = orgmail[orgmail['WT']>=7.2]

  if len(orgmail) != 0:
      orgmail = orgmail
      #orgmail = orgmail.to_string(index=False)
  else:
      #grp_finaltable2_maildf = pd.DataFrame()
      orgmail = '    There is no SC with pickup load more than 7.2T available for Hub'

  print (orgmail)
  filepath = oppath2

  #TO=['mahesh.reddy@spoton.co.in']
  TO = ["aom_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in"]
  #CC=['vishwas.j@spoton.co.in']
  CC = ["abhik.mitra@spoton.co.in","Pawan.Sharma@Spoton.Co.In","Jothi.Menon@Spoton.Co.In","Rajesh.Kumar@Spoton.Co.In","Shivananda.P@Spoton.Co.In"]
  BCC = ["mahesh.reddy@spoton.co.in"] 
  FROM="reports.ie@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  msg["CC"] = ",".join(CC)
  msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "Origin SC Load Available "+ str(opfilevar)+"-"+str(opfilevar2)
  html3='''
  <h5> For the conwise details, please download the file from the below link </h5>
  <p><a href= "http://spoton.co.in/downloads/IEProjects/STOCKOrigin/StockOrigin.csv"</a>http://spoton.co.in/downloads/IEProjects/STOCKOrigin/StockOrigin.csv</p></b>

  '''
  report=""
  report+='Dear All,'
  report+='<br>'
  report+='<br>'
  report+='PFB the load available at Origin SC at '+ str(opfilevar)+"-"+str(opfilevar2)
  report+='<br>'
  report+='<br>'
  report+='Only the SCs where available load isn 7.2T is mentioned in the email body. The full summary The Cons having DEPS/Sender Failure/Reciever Failure statuses is excluded in the report'
  report+='<br>'
  report+='<br>'
  report+='<br>'+orgmail.to_html()+'<br>'
  report+='<br>'
  report+='<br>'
  report+=html3

  abc=MIMEText(report,'html')
  msg.attach(abc)

  part = MIMEBase('application', "octet-stream")
  part.set_payload( open(filepath,"rb").read() )
  encoders.encode_base64(part)
  part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
  msg.attach(part)



  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
  server.quit()



except:
  TO=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  #msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "Origin SC Load Available Error in Execution" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in Origin SC Load Available'
  report+='<br>'

  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO, msg.as_string())
  server.quit()

