
# coding: utf-8

# In[9]:

import pandas as pd
from datetime import datetime, timedelta, date
import datetime


# In[2]:

ocidclosingstock = pd.io.excel.read_excel('http://spoton.co.in/downloads/OCID/OCID.xls','CLOSING STOCK')


# In[40]:

datenow = date.today()
dateyest = datenow-timedelta(hours=24)
ocidclosingstock.loc[ocidclosingstock.index,'Timestamp'] = dateyest
##$$ocidclosingstock.to_csv(r'D:\\Data\\eta_rank\\Destination_sc_closingstock\\Closing_Stock_'+str(dateyest)+'.csv',encoding='utf-8',compression='gzip')
ocidclosingstock.to_csv(r'D:\\Data\\eta_rank\\Destination_sc_closingstock\\Closing_Stock_'+str(dateyest)+'.csv',encoding='utf-8')

"""
# In[38]:

import gzip

# Open source file.
with open("C:\\Data\\Closing_Stock_2015-11-15.csv", "rb") as file_in:
    # Open output file.
    with gzip.open("C:\\Data\\Closing_Stock_2015-11-15.csv.gz", "wb") as file_out:
        # Write output.
        file_out.writelines(file_in)


# In[ ]:
"""


