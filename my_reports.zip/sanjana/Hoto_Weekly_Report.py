
# coding: utf-8

# In[ ]:

import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta,datetime
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

# In[ ]:
try:
    startdate=datetime.strptime('2018-04-01','%Y-%m-%d')
    startdate


    # In[ ]:

    enddate=datetime.strftime(datetime.now(),'%Y-%m-%d')
    enddate


    # In[ ]:

    from datetime import datetime, timedelta

    today = datetime.now().date()-timedelta(7)
    start = today - timedelta(days=today.weekday())
    end = start + timedelta(days=5)
    print("Today: " + str(today))
    print("Start: " + str(start))
    print("End: " + str(end))


    # In[ ]:

    # cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
    # cursor=cnxn.cursor()
    #query=("""EXEC USP_DESTN_HUB_FEEDER_OTP_REPORT_VIRTUAL_DT '2018-07-09' , '2018-07-14'""")
    query=(""" EXEC USP_DESTN_HUB_FEEDER_OTP_REPORT_VIRTUAL_DT '{0}' , '{1}'""".format(start,end))


    # In[ ]:

    hoto_df=pd.read_sql(query,Utilities.cnxn)
    len(hoto_df)


    # In[ ]:

    def ignoreValue(day,hours):
        if (day=='Saturday') & (hours>=9.0):
            return "Ignore"
        else:
            return "Required"


    # In[ ]:

    hoto_df['Ignore']=hoto_df.apply(lambda x:ignoreValue(x['HUB_Dayname'],x['HUB_Arrv_Hours']),axis=1)


    # In[ ]:

    def getHours(hrs):
        if pd.isnull(hrs):
            return 23
        else:
            return hrs


    # In[ ]:

    hoto_df['SC_ARRV_HOURS']=hoto_df.apply(lambda x: getHours(x['SC_Arrv_Hours']),axis=1)


    # In[ ]:

    hoto_df1=hoto_df[hoto_df['Ignore']!='Ignore']


    # In[ ]:

    len(hoto_df1)


    # In[ ]:

    hubarrv7to10=hoto_df1[hoto_df1['HUB_Arrv_Hours']<7.0]
    len(hubarrv7to10)


    # In[ ]:

    pivot_hub7to10=pd.pivot_table(hubarrv7to10,index=['LOCATION'],columns=['SC_ARRV_HOURS'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total')


    # In[ ]:

    pivot_hub7to10=pivot_hub7to10.fillna(0)


    # In[ ]:

    for k in ['0.0','1.0','2.0','3.0','4.0','5.0','6.0','7.0','8.0','9.0']:
        print (k)
        try:
            print (pivot_hub7to10[('DOCKNO',float(k))])
        except:
            pivot_hub7to10[('DOCKNO',float(k))]=0.0


    # In[ ]:

    pivot_hub7to10[('DOCKNO','Cons')]=pivot_hub7to10[('DOCKNO',0.0)]+pivot_hub7to10[('DOCKNO',1.0)]+pivot_hub7to10[('DOCKNO',2.0)]+pivot_hub7to10[('DOCKNO',3.0)]+pivot_hub7to10[('DOCKNO',4.0)]+pivot_hub7to10[('DOCKNO',5.0)]+pivot_hub7to10[('DOCKNO',6.0)]+pivot_hub7to10[('DOCKNO',7.0)]+pivot_hub7to10[('DOCKNO',8.0)]+pivot_hub7to10[('DOCKNO',9.0)]


    # In[ ]:

    pivot_hub7to10[('DOCKNO','Performance')]=pd.np.round(pivot_hub7to10[('DOCKNO','Cons')]*100.0/pivot_hub7to10[('DOCKNO','Total')],1)


    # In[ ]:

    pivot_hub7to10.columns=[''.join(str(col)).strip() for col in pivot_hub7to10.columns.values]


    # In[ ]:

    no=datetime.date(datetime.now()).isocalendar()[1]-14
    no


    # In[ ]:

    pivot_hub7to10.rename(columns={"('DOCKNO', 'Cons')":'Wk_'+str(no)+'_Cons',"('DOCKNO', 'Performance')":'Wk_'+str(no)+'_Success'},inplace=True)


    # In[ ]:

    pivot_hub7to10_1=pivot_hub7to10.reset_index()


    # In[ ]:

    pivot_hub7to10_1.rename(columns={'LOCATION':'Locations'},inplace=True)


    # In[ ]:

    pivot_hub7to10_2=pivot_hub7to10_1[['Locations','Wk_'+str(no)+'_Cons','Wk_'+str(no)+'_Success']]


    # In[ ]:

    pivot_hub7to10_2['Wk_'+str(no)+'_Cons']=pivot_hub7to10_2['Wk_'+str(no)+'_Cons'].astype(int)
    pivot_hub7to10_2['Wk_'+str(no)+'_Success']=pivot_hub7to10_2['Wk_'+str(no)+'_Success']


    # In[ ]:

    pivot_hub7to10_2.columns


    # In[ ]:

    weekly_df=pd.read_excel(r'C:\Users\rajeeshv\Downloads\Trend_Hoto_Weekly.xlsx')


    # In[ ]:

    weekly_df.head()


    # In[ ]:

    weekly_df=pd.merge(weekly_df,pivot_hub7to10_2,on='Locations',how='left')


    # In[ ]:

    weekly_df=weekly_df.fillna(0)


    # In[ ]:

    weekly_df.columns


    # In[ ]:

    hubarrv10to12=hoto_df1[hoto_df1['HUB_Arrv_Hours']<9.0]
    len(hubarrv10to12)


    # In[ ]:

    pivot_hub10to12=pd.pivot_table(hubarrv10to12,index=['LOCATION'],columns=['SC_Arrv_Hours'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total')


    # In[ ]:

    pivot_hub10to12=pivot_hub10to12.fillna(0)


    # In[ ]:

    for k in ['0.0','1.0','2.0','3.0','4.0','5.0','6.0','7.0','8.0','9.0','10.0','11.0']:
        print (k)
        try:
            print (pivot_hub10to12[('DOCKNO',float(k))])
        except:
            pivot_hub10to12[('DOCKNO',float(k))]=0.0


    # In[ ]:

    pivot_hub10to12[('DOCKNO','Cons')]=pivot_hub10to12[('DOCKNO',0.0)]+pivot_hub10to12[('DOCKNO',1.0)]+pivot_hub10to12[('DOCKNO',2.0)]+pivot_hub10to12[('DOCKNO',3.0)]+pivot_hub10to12[('DOCKNO',4.0)]+pivot_hub10to12[('DOCKNO',5.0)]+pivot_hub10to12[('DOCKNO',6.0)]+pivot_hub10to12[('DOCKNO',7.0)]+pivot_hub10to12[('DOCKNO',8.0)]+pivot_hub10to12[('DOCKNO',9.0)]+pivot_hub10to12[('DOCKNO',10.0)]+pivot_hub10to12[('DOCKNO',11.0)]


    # In[ ]:

    pivot_hub10to12[('DOCKNO','Performance')]=pd.np.round(pivot_hub10to12[('DOCKNO','Cons')]*100.0/pivot_hub10to12[('DOCKNO','Total')],1)


    # In[ ]:

    pivot_hub10to12.columns=[''.join(str(col)).strip() for col in pivot_hub10to12.columns.values]


    # In[ ]:

    pivot_hub10to12.rename(columns={"('DOCKNO', 'Cons')":'Wk_'+str(no)+'_Cons',"('DOCKNO', 'Performance')":'Wk_'+str(no)+'_Success'},inplace=True)


    # In[ ]:

    pivot_hub10to12_1=pivot_hub10to12.reset_index()


    # In[ ]:

    pivot_hub10to12_1.columns


    # In[ ]:

    pivot_hub10to12_1.rename(columns={'LOCATION':'Locations'},inplace=True)


    # In[ ]:

    pivot_hub10to12_2=pivot_hub10to12_1[['Locations','Wk_'+str(no)+'_Cons','Wk_'+str(no)+'_Success']]


    # In[ ]:

    pivot_hub10to12_2['Wk_'+str(no)+'_Cons']=pivot_hub10to12_2['Wk_'+str(no)+'_Cons'].astype(int)
    pivot_hub10to12_2['Wk_'+str(no)+'_Success']=pivot_hub10to12_2['Wk_'+str(no)+'_Success'].astype(str)+'%'


    # In[ ]:

    pivot_hub10to12_2.head()


    # In[ ]:

    weekly_df1=pd.read_excel(r'C:\Users\rajeeshv\Downloads\Trend_Hoto_Weekly.xlsx',sheetname='Summary_9 from HUB to 12 SC')


    # In[ ]:

    weekly_df1.columns


    # In[ ]:

    #weekly_df1.rename(columns={'Locations':'Location'},inplace=True)


    # In[ ]:

    weekly_df1=pd.merge(weekly_df1,pivot_hub10to12_2,on='Locations')


    # In[ ]:

    weekly_df1.columns


    # In[ ]:

    from pandas import ExcelWriter
    with ExcelWriter(r'C:\Users\rajeeshv\Downloads\Trend_Hoto_Weekly.xlsx') as writer:
        weekly_df.to_excel(writer, sheet_name='Summary_7 from HUB to 10 SC',engine='xlsxwriter')
        weekly_df1.to_excel(writer, sheet_name='Summary_9 from HUB to 12 SC',engine='xlsxwriter') 


    # In[ ]:

    filepath=r'C:\Users\rajeeshv\Downloads\Trend_Hoto_Weekly.xlsx'


    # In[ ]:



    #CC=['mahesh.reddy@spoton.co.in']
    CC=['abhik.mitra@spoton.co.in','pawan.sharma@spoton.co.in','rajesh.kumar@spoton.co.in','sq_spot@spoton.co.in']
    FROM='mis.ho@spoton.co.in'
    #BCC=["mahesh.reddy@spoton.co.in"]
    BCC=['aom_spot@spoton.co.in','dom_spot@spoton.co.in','rom_spot@spoton.co.in','hubmgr_spot@spoton.co.in']
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    msg["Subject"] = "Hoto Weekly Report"

    report=""
    report+='Dear All,'
    report+='<br>'
    report+='<br>'
    report+='PFA Hoto Weekly Trend Summary.'
    report+='<br>'

    abc=MIMEText(report,'html')
    msg.attach(abc)
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filepath,"rb").read() )
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, CC+BCC, msg.as_string())
    server.quit()

except:

  TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in']  
  CC=['mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "ERROR Report" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in Hoto Weekly Report'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO+CC, msg.as_string())
  server.quit()


# In[ ]:

exit(0)


# In[ ]:



