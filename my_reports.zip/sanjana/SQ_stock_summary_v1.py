# -*- coding: utf-8 -*-
"""
Created on Wed Nov 02 18:03:53 2016

@author: rajeeshv
"""


# coding: utf-8

# In[1]:

import pandas as pd
from pandas import ExcelWriter
import os
import traceback
import math
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
import ftplib
import os
import traceback
#sys.setdefaultencoding("Windows-1252")


# In[2]:
try:
    #stockdata = pd.read_csv(r'C:\Data\Shiv_ops\CLSSTKSUM_25042016.csv')
    stockdata = pd.read_csv(r'http://spoton.co.in/downloads/IEPROJECTS/CLSSTKSUM/CLSSTKSUM.csv')
    stockdata.PARENTNAME1.fillna('Blank', inplace=True)

    stockdata = stockdata.drop('LATEST_CON_REC_COMM1', axis=1)
    # In[3]:

    stockdatalist = ['CDELDT1','ARRV_AT_DEST_SC2','ConStatusDate2']
    print stockdatalist


    print stockdata['ARRV_AT_DEST_SC2'].values[0]
    print pd.unique(stockdata['CDELDT1'])
    print pd.unique(stockdata['ARRV_AT_DEST_SC2'])
    print pd.unique(stockdata['ConStatusDate2'])

    timeformat1 = '%d/%m/%Y %H:%M:%S %p'
    dayzero1 = '30/12/2011 00:00:00 AM'
    dayzero = datetime.strptime(dayzero1,timeformat1)

    stockdata.ConStatusDate2.fillna(dayzero1, inplace=True)

    def datestring(x):
        x = str(x)
        try:
            fulldate = datetime.strptime(x,'%m/%d/%Y %H:%M:%S %p')
            return fulldate
        except:
            fulldate = datetime.strptime(x,'%d/%m/%Y %H:%M:%S %p')
            return fulldate

    print stockdata['ARRV_AT_DEST_SC2'].values[0]

    for cols in stockdatalist:
        stockdata[cols] = stockdata.apply(lambda x:datestring(x[cols]),axis=1)



    # In[4]:

    stockdata = stockdata.rename(columns={'\xef\xbb\xbfPARENTCODE1':'PARENTCODE1'})

    cslist= ['1_CS Bucket','A2_CCF without Tickets']
    demlist = ['2_CS Dem_Pin Drs Block','5_OPS Dem Drs Block']
    depslist = ['6_DEPS-OPS','9_DEPS-SQ']
    opslist = ['3_OPS/Free Con Bucket-Old','4_OPS/Free Con Bucket-New','7_Others/Timelag']
    otherslist = ['A1_DEAD STOCK','A3_PAYMENT_ISSUE','A4_Seized by Sales Tax']
    ucglist = ['8_UCG']

    def categoriesdunc(status):
        if status in cslist:
            return 'CCF'
        elif status in demlist:
            return 'Dem_Cons'
        elif status in depslist:
            return 'DEPS'
        elif status in opslist:
            return 'OPS'
        elif status in otherslist:
            return 'Others'
        elif status in ucglist:
            return 'UCG'
        else:
            return 'Check'

    stockdata['Main_category'] = stockdata.apply(lambda x:categoriesdunc(x['STATUS1']),axis=1)
    print len(stockdata[stockdata['Main_category']=='CCF'])
    print len(stockdata[stockdata['Main_category']=='Dem_Cons'])
    print len(stockdata[stockdata['Main_category']=='DEPS'])
    print len(stockdata[stockdata['Main_category']=='OPS'])
    print len(stockdata[stockdata['Main_category']=='Others'])
    print len(stockdata[stockdata['Main_category']=='UCG'])
    print len(stockdata[stockdata['Main_category']=='Check'])

    #stockdata_grp = stockdata.groupby(['DEST_BRNM2','Main_category']).agg({'DOCKNO2':len}).reset_index()
    #stockdata_grp = stockdata.groupby(["DEST_BRNM2"]).get_group('Main_category')[['DOCKNO2']].len()

    #stockdata_grp.to_csv(r'D:\Data\stockdata_grp.csv')

    stockdata_pivot = pd.pivot_table(stockdata,index=['DEST_BRNM2'],columns=['Main_category'],values=['DOCKNO2'],aggfunc=[len],fill_value=0).reset_index()


    ## Alternatives for Getting the column names properly for a pivot_table

    ##$$$$$$$$$$$$$$ pivot = pd.DataFrame(stockdata_pivot.to_records())
    ##$$$$$$$$$$$$$$ stockdata_pivot.columns = stockdata_pivot.columns.get_level_values(0)
    stockdata_pivot.columns = [' '.join(col).strip() for col in stockdata_pivot.columns.values]

    ## Alternatives for Getting the column names properly for a pivot_table

    stockdata_pivot.rename(columns={'DEST_BRNM2':'DestinationBranchName','len DOCKNO2 CCF':'CCF','len DOCKNO2 DEPS':'DEPS','len DOCKNO2 Dem_Cons':'Dem_Cons','len DOCKNO2 OPS':'OPS','len DOCKNO2 Others':'Others','len DOCKNO2 UCG':'UCG'}, inplace=True)

    stockdata_pivot['Grand_Total'] = stockdata_pivot.apply(lambda x:(x['CCF']+x['Dem_Cons']+x['DEPS']+x['OPS']+x['Others']+x['UCG']),axis=1)
    #

    stockdata_pivot = stockdata_pivot.sort_values('Grand_Total',ascending=False)

    stockdata_pivot_email = stockdata_pivot.head(20)

    datetoday = datetime.today()
    datefilter = datetoday-timedelta(hours=24)
    datefilter=datefilter.date()
    datefilter


    stockdata.to_csv(r'D:\Data\Shiv_closingstock_automation\Stock_Delivery_SC_data.csv')
    stockdata.to_csv(r'D:\Data\Shiv_closingstock_automation\Top20_SC_Stock\Data\Stock_Delivery_SC_data_'+str(datefilter)+'.csv')

    stockdata_pivot.to_csv(r'D:\Data\Shiv_closingstock_automation\Stock_Delivery_SC_Summary.csv')
    stockdata_pivot.to_csv(r'D:\Data\Shiv_closingstock_automation\Top20_SC_Stock\Summary\Stock_Delivery_SC_Summary_'+str(datefilter)+'.csv')


    oppath1 = r'D:\Data\Shiv_closingstock_automation\Stock_Delivery_SC_data.csv'
    # In[ ]:
    print ('Logging in...')
    ftp = ftplib.FTP()
    ftp.connect('10.109.230.50')
    print (ftp.getwelcome())
    try:
        try:
            ftp.login('IEPROJECTUSER', 'spotStar@123')
            ftp.cwd('ETA')
            # move to the desired upload directory
            print ("Currently in:", ftp.pwd())
            print ('Uploading...')
            fullname = oppath1
            name = os.path.split(fullname)[1]
            f = open(fullname, "rb")
            ftp.storbinary('STOR ' + name, f)
            f.close()
            print ("OK"  )
            print ("Files:")
            print (ftp.retrlines('LIST'))
        finally:
            print ("Quitting...")
            ftp.quit()
    except:
        traceback.print_exc()


    stockdata_pivot_email = stockdata_pivot_email.to_string(index=False)

    oppath2 = r'D:\Data\Shiv_closingstock_automation\Stock_Delivery_SC_Summary.csv'
    # In[ ]:
    filePath = oppath2
    def sendEmail(TO = ["aom_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in","spot_cstl@spoton.co.in"],
                 #TO = ["vishwas.j@spoton.co.in"],
                 #BCC =  ["vishwas.j@spoton.co.in","shivananda.p@spoton.co.in"],
                 CC =  ["anitha.thyagarajan@spoton.co.in","shivananda.p@spoton.co.in"],
                 #CC =  ["vishwas.j@spoton.co.in"],
                 BCC =  ["mahesh.reddy@spoton.co.in"],
                #FROM="mis.ho@spoton.co.in"):
                FROM="mis.ho@spoton.co.in"):
        HOST = "smtp.spoton.co.in"
        #HOST = "smpt.spoton.co.in"
    #smtplib.SMTP('smtp.spoton.co.in', 25)

        msg = MIMEMultipart()
        msg["From"] = FROM
        msg["To"] = ",".join(TO)
        msg["CC"] = ",".join(CC)
        msg["BCC"] = ",".join(BCC)
        #msg["Subject"] = "DEPOTWISE OPS Bucket Stock  - "+ str(datefilter)
        msg["Subject"] = "Stock levels at Delivery Service Centers - TOP 20 - "+ str(datefilter)
        body_text = """
        Dear All,
        
        PFB the Stock levels at Delivery Service Centers - TOP 20 Report as of """ + str(datefilter) +"""
        
    """+str(stockdata_pivot_email)+"""
        

        To download the Data, Please click the link below
        http://spoton.co.in/downloads/IEProjects/ETA/Stock_Delivery_SC_data.csv   
        """
        if body_text:
            msg.attach( MIMEText(body_text) )
        part = MIMEBase('application', "octet-stream")
        part.set_payload( open(filePath,"rb").read() )
        Encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
        msg.attach(part)
        server=smtplib.SMTP('smtp.sendgrid.net', 587)
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login("spoton.net.in", "Star@123#")

        try:
            failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
            server.close()
        except Exception, e:
            errorMsg = "Unable to send email. Error: %s" % str(e)

    if __name__ == "__main__":
        sendEmail()
    #print('Email sent')

    ## CCF TOP 20 Customers mail


    # For CCF customers separate summary

    stockdata_ccf = stockdata[stockdata['Main_category']=='CCF']
    print len(stockdata_ccf)

    stockdata_ccf_grp = stockdata_ccf.groupby(['PARENTNAME1']).agg({'DOCKNO2':len}).reset_index()

    stockdata_ccf_grp = stockdata_ccf_grp.sort_values('DOCKNO2',ascending=False)


    stockdata_ccf.to_csv(r'D:\Data\Shiv_closingstock_automation\CCF_Delivery_SC_data.csv')
    stockdata_ccf.to_csv(r'D:\Data\Shiv_closingstock_automation\High_stocks_Dest_SC_CCF\Data\CCF_Delivery_SC_data_'+str(datefilter)+'.csv')

    stockdata_ccf_grp.to_csv(r'D:\Data\Shiv_closingstock_automation\CCF_Delivery_SC_Summary.csv')
    stockdata_ccf_grp.to_csv(r'D:\Data\Shiv_closingstock_automation\High_stocks_Dest_SC_CCF\Summary\CCF_Delivery_SC_Summary_'+str(datefilter)+'.csv')

    oppathccf = r'D:\Data\Shiv_closingstock_automation\CCF_Delivery_SC_Summary.csv'

    stockdata_ccf_grp_email = stockdata_ccf_grp.head(20)
    stockdata_ccf_grp_email = stockdata_ccf_grp_email.to_string(index=False)



    oppath_ccf_data = r'D:\Data\Shiv_closingstock_automation\CCF_Delivery_SC_data.csv'
    # In[ ]:
    print ('Logging in...')
    ftp = ftplib.FTP()
    ftp.connect('10.109.230.50')
    print (ftp.getwelcome())
    try:
        try:
            ftp.login('IEPROJECTUSER', 'spotStar@123')
            ftp.cwd('ETA')
            # move to the desired upload directory
            print ("Currently in:", ftp.pwd())
            print ('Uploading...')
            fullname = oppath_ccf_data
            name = os.path.split(fullname)[1]
            f = open(fullname, "rb")
            ftp.storbinary('STOR ' + name, f)
            f.close()
            print ("OK"  )
            print ("Files:")
            print (ftp.retrlines('LIST'))
        finally:
            print ("Quitting...")
            ftp.quit()
    except:
        traceback.print_exc()



    filePath = oppathccf
    def sendEmail(#TO = ["anitha.thyagarajan@spoton.co.in"],
                 TO = ["mahesh.reddy@spoton.co.in"],
                 #BCC =  ["vishwas.j@spoton.co.in","shivananda.p@spoton.co.in"],
                 #CC =  ["shivananda.p@spoton.co.in"],
                 CC =  ["mahesh.reddy@spoton.co.in"],
                 BCC =  ["mahesh.reddy@spoton.co.in"],
                #FROM="mis.ho@spoton.co.in"):
                FROM="mis.ho@spoton.co.in"):
        HOST = "smtp.spoton.co.in"
        #HOST = "smpt.spoton.co.in"
    #smtplib.SMTP('smtp.spoton.co.in', 25)

        msg = MIMEMultipart()
        msg["From"] = FROM
        msg["To"] = ",".join(TO)
        msg["CC"] = ",".join(CC)
        msg["BCC"] = ",".join(BCC)
        #msg["Subject"] = "DEPOTWISE OPS Bucket Stock  - "+ str(datefilter)
        msg["Subject"] = "High stock levels in the Network, especially at Delivery Service Centers - CCF - "+ str(datefilter)
        body_text = """
        Dear All,
        
        PFB the SHigh stock levels in the Network, especially at Delivery Service Centers - CCF """ + str(datefilter) +"""
        
    """+str(stockdata_ccf_grp_email)+"""
        

        To download the Data, Please click the link below
        http://spoton.co.in/downloads/IEProjects/ETA/CCF_Delivery_SC_data.csv  
        """
        if body_text:
            msg.attach( MIMEText(body_text) )
        part = MIMEBase('application', "octet-stream")
        part.set_payload( open(filePath,"rb").read() )
        Encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
        msg.attach(part)
        server=smtplib.SMTP('smtp.sendgrid.net', 587)
        server.ehlo()
        server.starttls()
        server.ehlo()
        #server.login("spoton.co.in", "#Xat694#")
		server.login("spoton.net.in", "Star@123#")
		

        try:
            failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
            server.close()
        except Exception, e:
            errorMsg = "Unable to send email. Error: %s" % str(e)

    if __name__ == "__main__":
        sendEmail()
    #print('Email sent')

    ## CCF TOP 20 Customers mail

except:

  TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in'] 
  CC=['mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "High stock levels in the Network, especially at Delivery Service Centers - CCF Error in Execution" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in High stock levels in the Network, especially at Delivery Service Centers - CCF'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO+CC, msg.as_string())
  server.quit()
