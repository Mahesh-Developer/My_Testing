
# coding: utf-8

# In[81]:


import numpy as np
import pandas as pd
import pyodbc
from IPython import display
from datetime import datetime
from datetime import datetime,timedelta
from datetime import datetime, timedelta
import smtplib
import ftplib
import traceback
import calendar
import os
import openpyxl
import Utilities

now_start=datetime.strftime((datetime.today()),'%d-%m-%y-%H:%M:%S')
now_start


# In[82]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()


# In[83]:


yest=datetime.now()-timedelta(1)
enddate=yest.date()
enddate=str(enddate)+' 23:59:00'
enddate

yest=datetime.now()-timedelta(1)
startdate=yest.date()
startdate=str(startdate)
enddate
startdate,enddate


# In[84]:


query1='''
EXEC dbo.USP_DELV_EFF_SC_WISE_ALL_WONFS @FLAG = 'S', -- varchar(3)
    @frdt = '{0}', -- smalldatetime
    @todt = '{1}' -- smalldatetime   
    ''' .format(startdate,enddate)


# In[85]:


wonfs=pd.read_sql(query1,Utilities.cnxn)


# In[86]:


wonfs


# In[87]:


query2= '''  EXEC dbo.USP_DELV_EFF_SC_WISE_ALL @FLAG = 'S', -- varchar(3)
    @frdt = '{0}', -- smalldatetime
    @todt = '{1}' -- smalldatetime
  '''  .format(startdate,enddate)


# In[88]:


nfs=pd.read_sql(query2,Utilities.cnxn)


# In[89]:


nfs


# In[90]:


# DE_df=DE.groupby(['RGALPH']).sum()
# dfDE_WT=DE_rloc.groupby(['RGALPH','DEL_LOCATION_TYPE']).sum()


# In[91]:


wonfs.rename(columns={'TOTAL':'TOTAL_WN'},inplace= True)
wonfs.rename(columns={'Delivered': 'Delivered_wn'},inplace= True)
DF1=wonfs[['RGALPH', 'ControlArea', 
       'TOTAL_WN','Delivered_wn']]

df1_check=DF1.groupby(['RGALPH','ControlArea']).sum()


# In[92]:


df1_check.head(5)


# In[93]:


nfs.rename(columns={'TOTAL':'TOTAL_n'},inplace= True)
nfs.rename(columns={'Delivered': 'Delivered_n'},inplace= True)
DF2=nfs[['RGALPH', 'ControlArea', 
       'TOTAL_n','Delivered_n']]
# DF2.head(5)
df2_check=DF2.groupby(['RGALPH','ControlArea']).sum()
df2_check.head(5)


# In[94]:


# piv_MERG=pd.merge(df1_check,df2_check,on=['RGALPH','ControlArea'])
piv_MERG=pd.merge(df1_check,df2_check, left_index=True, right_index=True)
piv_MERG


# In[95]:


df1=pd.pivot_table(piv_MERG,index=['RGALPH','ControlArea'],
                      values=['TOTAL_WN','Delivered_wn','TOTAL_n','Delivered_n'],
                      aggfunc={'TOTAL_WN':sum, 'Delivered_wn':sum,'TOTAL_n':sum,'Delivered_n':sum},
                   margins= True, margins_name= 'Grand Total')
df1


# In[96]:


df1['DE_woNFS']=pd.np.round((df1['Delivered_wn']*100)/ df1['TOTAL_WN'],1).replace(np.inf, np.nan).fillna(0)
df1['DE_NFS']=pd.np.round((df1['Delivered_n']*100)/ df1['TOTAL_n'],1).replace(np.inf, np.nan).fillna(0)
df1['woNFS-NFS']= pd.np.round(df1['DE_woNFS'] - df1['DE_NFS'],1).replace(np.inf, np.nan).fillna(0)
df1.tail(5)


# In[97]:


tot_de=df1[['DE_woNFS','DE_NFS','woNFS-NFS']].tail(1)
tot_de


# In[98]:


de_full=df1[['DE_woNFS','DE_NFS','woNFS-NFS']]
# de_full['DE_woNFS']=de_full['DE_woNFS'].astype(int)
de_full['DE_woNFS']=de_full['DE_woNFS'].astype(str)+'%'
# de_full['DE_NFS']=de_full['DE_NFS'].astype(int)
de_full['DE_NFS']=de_full['DE_NFS'].astype(str)+'%'
# de_full['woNFS-NFS']=de_full['woNFS-NFS'].astype(int)
de_full['woNFS-NFS']=de_full['woNFS-NFS'].astype(str)+'%'

de_full


# In[99]:




df_nogt=df1
df_nogt.drop(df_nogt.tail(1).index,inplace= True)
df_nogt


# In[100]:


df2=df_nogt[(df_nogt['woNFS-NFS'] != 0)]
df2


# In[101]:


WN_DE=df2[['DE_woNFS','DE_NFS','woNFS-NFS']]
# WN_DE['DE_woNFS']=WN_DE['DE_woNFS'].astype(int)
WN_DE['DE_woNFS']=WN_DE['DE_woNFS'].astype(str)+'%'
# WN_DE['DE_NFS']=WN_DE['DE_NFS'].astype(int)
WN_DE['DE_NFS']=WN_DE['DE_NFS'].astype(str)+'%'
# WN_DE['woNFS-NFS']=WN_DE['woNFS-NFS'].astype(int)
WN_DE['woNFS-NFS']=WN_DE['woNFS-NFS'].astype(str)+'%'
WN_DE


# # EMAIL ########

# In[102]:


from glob import glob
from IPython import display
from datetime import datetime,timedelta
import pyodbc

# date=datetime.strftime(datetime.now()-timedelta(2),'%Y-%m-%d-%H')
date=datetime.strftime(datetime.now(),'%Y-%m-%d-%H')
date


# In[103]:


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template
                  

# TO=['sanjana.narayana@spoton.co.in']
TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in']

FROM="sanjana.narayana@spoton.co.in"
# CC = ['sanjana.narayana@spoton.co.in']


BCC = ['sanjana.narayana@spoton.co.in']


msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
# msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = " DE-Comparison With and Without NFS " + " - " + str(enddate)
html='''<html>
<style>        
p
 {
   margin:0;
   margin-top: 5px;
   padding:0;
   font-size:15px;
   line-height:20px;
 }
</style>                


 '''
# html3='''
# <h5> To download File, Please click the link below </h5>
# <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/APT_DE_"+str(today)+".xlsx"</a>
# "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/APT_DE.xlsx"</p>
# '''
report=""
report+='<br>'
report+='Hello,'
report+='<br>'
report+='<br>'
report+=' Please find below,'
report+='<br>'
report+='<br>'
report+='DE of Areas where NFS have been raised'
report+='<br>'
report+='<br>'+WN_DE.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='Full DE summary'
report+='<br>'
report+='<br>'+de_full.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='<br>'



# report+=html
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
# part.set_payload( open(oppath1,"rb").read() )
# encoders.encode_base64(part)
# part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
# msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login('spoton.net.in', 'Star@123#')
failed = server.sendmail(FROM, TO+BCC, msg.as_string())
print ('mail sent')
server.quit()


# In[104]:


now_end=datetime.strftime((datetime.today()),'%d-%m-%y-%H:%M:%S')
now_end

" your email is sent-  stared at " +now_start+ " and finished at " +now_end 

