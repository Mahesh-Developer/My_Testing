
# coding: utf-8

# In[27]:

import graphlab as gl
import graphlab.aggregate as agg
import pandas as pd
from datetime import datetime, timedelta,date
import networkx as nx
import time

import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
import os
import pandas as pd
from datetime import datetime, timedelta
import numpy as np
from sqlalchemy import *
import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import sys
import Utilities
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.87;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()

stockquery = ("""EXEC USP_THC_LINEHAUL_UTILIZATION """)
print (stockquery)

data1=pd.read_sql(stockquery,Utilities.cnxn)
data1.rename(columns={'CoolingHours':'Cooling Hours','IsSourceLocTHCOrgin':'Is Source Loc THCOrgin','IsLoaded':'Is Loaded','ConAllowedForLoading':'Con Allowed For Loading','LatestConStatusCodeAtSourceLoc':'Latest Con Status Code At Source Loc'},inplace=True)

stockquery1 = ("""EXEC USP_THC_LINEHAUL_UTILIZATION_HEADER """)
print (stockquery1)
header1=pd.read_sql(stockquery1,Utilities.cnxn)
header1.rename(columns={'SourceLocation':'Source Location','THCImageProcessResult':'THCImage Process Result','VehicleVolume':'Vehicle Volume','VehiclePayLoad':'Vehicle Pay Load','TotalLoadedConsVolume':'Total Loaded Cons Volume','TotalLoadedConsActWt':'Total Loaded Cons Act Wt','IsSourceLocTHCOrgin':'Is Source Loc THCOrgin','RoutePath':'Route Path','RemainingPayLoad':'Remaining Pay Load','RemainingVolume':'Remaining Volume','TotLeftCons':'Tot Left Cons'},inplace=True)

# In[28]:

#ippath1 = 'C:/Users/s1738raj/Desktop/LHUtilization/THC_LINEHAUL_DAILY_IEP.xls'
#
#
## In[29]:
#
#x1 = pd.ExcelFile(ippath1)
#header1 = x1.parse("THC UTILIZATION HEADER")
#xl2 = pd.ExcelFile(ippath1)
#data1 = xl2.parse('THC_UTILIZATION_DETAILS')

# data1 = pd.io.excel.read_excel('http://10.109.230.50/downloads/THC_LINEHAUL_DAILY_IEP/THC_LINEHAUL_DAILY_IEP.xls','THC_UTILIZATION_DETAILS')
# header1 = pd.io.excel.read_excel('http://10.109.230.50/downloads/THC_LINEHAUL_DAILY_IEP/THC_LINEHAUL_DAILY_IEP.xls','THC UTILIZATION HEADER')

 
# In[30]:

header = header1[header1['Is Source Loc THCOrgin']=='Y']
data2 = data1[data1['Is Source Loc THCOrgin']=='Y']


# In[31]:

#new
def coolinghrs(x):
    timelist = x.split(':')
    h=timelist[0]
    s=timelist[1]
    ## To handle negative timings in Cooling hours
    int_h = int(h)
    int_s = int(s)
    if int_h<0 or int_s<0:
        chtime = 0
    else:
        chtime1 = str(h)+str('.')+str(s)
        chtime2 = float(chtime1)
        chtime = pd.np.round(chtime2, 2)
    #print chtime
    #y = str(chtime)
    return chtime
    


# In[32]:

#new
header['Route_Path'] = header.apply( lambda x: x['Route Path'].replace(" ", ""), axis=1)
data2['CH'] = data2['Cooling Hours'].apply( lambda x: coolinghrs(x))
data = data2[data2['CH']>2.0]
len(header), len(data)

totalthcsprep = len(header)


# In[33]:

potentialthc  = header[(header['Remaining Pay Load']>0) & (header['Remaining Volume']>0) & (header['Tot Left Cons']>0)]
possiblethclist = potentialthc['THCNO'].tolist()
data_potentialthc1 = data[(data['THCNO'].isin(possiblethclist)) & (data['Is Loaded']=='N') & (data['Con Allowed For Loading']=='Y')]

len(data_potentialthc1)

depspaperworkcodelist = ['SRE','DIR','EIR','SIR','SRD','SRS','SRP','DLP','SWP','PWS','HCM','HPM','MOP','SRH','HOC','ONR','SPH','SPO','DBO','DIP','SHS','SSC','HIP']

def depspwk(statuscodeatloc):
    if statuscodeatloc in depspaperworkcodelist:
        return 'Yes'
    else:
        return 'No'
    
data_potentialthc1['IsPaperWork'] = data_potentialthc1.apply(lambda x: depspwk(x['Latest Con Status Code At Source Loc']), axis=1)
data_potentialthc = data_potentialthc1[data_potentialthc1['IsPaperWork']=='No']

# In[34]:

def consavailable(hdrid, thcno, rem_wt, rem_vol):
    df = data_potentialthc[(data_potentialthc['hdrid']==hdrid) & (data_potentialthc['THCNO']==thcno) & (data_potentialthc['ACTUWT']<=rem_wt) & (data_potentialthc['ACTUWT']<=rem_vol)]
    return len(df)
#new
def wtavailable(hdrid, thcno, rem_wt, rem_vol):
    df = data_potentialthc[(data_potentialthc['hdrid']==hdrid) & (data_potentialthc['THCNO']==thcno) & (data_potentialthc['ACTUWT']<=rem_wt) & (data_potentialthc['ACTUWT']<=rem_vol)]
    return df['ACTUWT'].sum()
#new
def volavailable(hdrid, thcno, rem_wt, rem_vol):
    df = data_potentialthc[(data_potentialthc['hdrid']==hdrid) & (data_potentialthc['THCNO']==thcno) & (data_potentialthc['ACTUWT']<=rem_wt) & (data_potentialthc['ACTUWT']<=rem_vol)]
    return df['Volume'].sum()
    


# In[35]:

potentialthc['Cons_Available'] = potentialthc.apply(lambda x: consavailable(x['hdrid'],x['THCNO'],x['Remaining Pay Load'],x['Remaining Volume']), axis=1)
#new
potentialthc['Wt_Available'] = potentialthc.apply(lambda x: wtavailable(x['hdrid'],x['THCNO'],x['Remaining Pay Load'],x['Remaining Volume']), axis=1)
#new
potentialthc['Vol_Available'] = potentialthc.apply(lambda x: volavailable(x['hdrid'],x['THCNO'],x['Remaining Pay Load'],x['Remaining Volume']), axis=1)


# In[36]:

#new
potentialthc['Wt_Util%'] = potentialthc.apply(lambda x: pd.np.round(((x['Total Loaded Cons Act Wt']*100)/x['Vehicle Pay Load']),0), axis=1)
potentialthc['Vol_Util%'] = potentialthc.apply(lambda x: pd.np.round(((x['Total Loaded Cons Volume']*100)/x['Vehicle Volume']),0), axis=1)


# In[37]:

#new

## Commented on 20-12-2016 as the same thing was added at the beginning
def issueidentify(wt_util, vol_util):
    if wt_util>= 95 or  vol_util>=90:
        return 'OK'
    else:
        return 'Not OK'
## Commented on 20-12-2016 as the same thing was added at the beginning

potentialthc['Issue'] = potentialthc.apply(lambda x: issueidentify(x['Wt_Util%'],x['Vol_Util%']), axis=1)


# In[38]:
#potentialthc.to_csv(r'thc_investigation_before.csv')
#thc_investigation = potentialthc[potentialthc['Cons_Available']>0]
thc_investigation = potentialthc[(potentialthc['Cons_Available']>0) & (potentialthc['Vehicle Pay Load']>=7500) & (potentialthc['Issue']=='Not OK') & (potentialthc['THCImage Process Result']=='low')]
#thc_investigation.to_csv(r'thc_investigation_after.csv')
thc_investigation_no_img = potentialthc[(potentialthc['Cons_Available']>0) & (potentialthc['Vehicle Pay Load']>=7500) & (potentialthc['Issue']=='Not OK') & (potentialthc['THCImage Process Result']=='NOIMG')]


## For separating THCs whose THC origin and THC destination are in the below hublist
yesterdate=date.today()-timedelta(hours=24)

header_org_dest = thc_investigation_no_img

corehublist = ['AMCH','AMDH','BLRH','BOMH','BRGH','CCUH','DELH','HYDH','MAAH','NAGH','PNQH','VPIH','VZAH','SXVF']

def extract_org(routepath):
    thcorg = routepath[:4]
    return thcorg

def extract_dest(routepath):
    thcdest = routepath[-4:]
    return thcdest
    
header_org_dest['THC_ORIGIN'] = header_org_dest.apply(lambda x:extract_org(x['Route Path']),axis=1)
header_org_dest['THC_DESTINATION'] = header_org_dest.apply(lambda x:extract_dest(x['Route Path']),axis=1)


def org_dest_hublist(thcorigin,thcdest):
    if (thcorigin in corehublist) and (thcdest in corehublist):
        return 'YES'
    else:
        return 'NO'
        
header_org_dest['THC_ORG_DEST_IN_CORE_LIST']  = header_org_dest.apply(lambda x:org_dest_hublist(x['THC_ORIGIN'],x['THC_DESTINATION']),axis=1)   
header_org_dest_in_hublist = header_org_dest[(header_org_dest['THC_ORG_DEST_IN_CORE_LIST']=='YES') & (header_org_dest['THCImage Process Result']=='NOIMG')]
#header_org_dest_in_hublist = header_org_dest[(header_org_dest['THC_ORG_DEST_IN_CORE_LIST']=='YES') & (header_org_dest['THCImage Process Result']=='NOIMG') & (header_org_dest['Issue']=='OK')]


def thcorigin_chec(thcorigin,sourcehhub):
    if thcorigin==sourcehhub:
        return 'YES'
    else:
        return 'NO'

#header_org_dest_in_hublist.to_csv(r'D:\Python\Scripts and Files\Path and Graph Files\header_org_dest_in_hublist.csv')
header_org_dest_in_hublist['THC_CHECK']  = header_org_dest_in_hublist.apply(lambda x:thcorigin_chec(x['THC_ORIGIN'],x['Source Location']),axis=1)   

header_org_dest_in_hublist = header_org_dest_in_hublist[header_org_dest_in_hublist['THC_CHECK']=='YES']

header_org_dest_in_hublist_thcs = len(header_org_dest_in_hublist)

header_org_dest_in_hublist.loc[header_org_dest_in_hublist.index,'Date'] = yesterdate

header_org_dest_in_hublist_grp = header_org_dest_in_hublist.groupby(['THC_ORIGIN']).agg({'THCNO':len}).reset_index()
header_org_dest_in_hublist_grp = header_org_dest_in_hublist_grp.sort_values('THCNO',ascending=False)


header_org_dest_in_hublist.to_csv(r'D:\Data\LH_utilization_Verification\THC_OD_HUBLIST\THC_OD_IN_HUBLIST_'+str(yesterdate)+'.csv')
oppath_hublist_thcs = r'D:\Data\LH_utilization_Verification\THC_OD_HUBLIST\THC_OD_IN_HUBLIST_'+str(yesterdate)+'.csv'
## For separating THCs whose THC origin and THC destination are in the below hublist

#thc_investigation.to_csv(r'thc_investigation_after.csv')

#for giving con data to Prasanna
columnlist_thc = data_potentialthc.columns.tolist()
condata = pd.DataFrame(columns = columnlist_thc)
for p in range (0, len(thc_investigation)):
    hdrid_thc = thc_investigation.iloc[p]['hdrid']
    thcno_thc = thc_investigation.iloc[p]['THCNO']
    payload_thc = thc_investigation.iloc[p]['Remaining Pay Load']
    vol_thc = thc_investigation.iloc[p]['Remaining Volume']
    df_con = data_potentialthc[(data_potentialthc['hdrid']==hdrid_thc) & (data_potentialthc['THCNO']==thcno_thc) & (data_potentialthc['ACTUWT']<=payload_thc) & (data_potentialthc['ACTUWT']<=vol_thc)]
    condata = condata.append(df_con)
#for giving con data to Prasanna



# In[39]:

#thc_investigation.to_csv('thc_investigation.csv')
thcVerification = len(thc_investigation)
print 'THC Length', thcVerification

yesterdate=date.today()-timedelta(hours=24)

## TO handle error of THCs count zero
if thcVerification==0:
    TO = ["prasanna.hegde@spoton.co.in"]
    CC = ["mahesh.reddy@spoton.co.in"]
    #recipients = ["vishwas.j@spoton.co.in"]
    sender ="reports.ie@spoton.co.in"
    subject = "LH Utilization Verification " + '- ' + str(yesterdate)
    body = """
    Dear All,
        THCs with low utilization and image identified as 'low' = """+str(thcVerification)+"""
    
    """
    
    # make up message
    msg = MIMEText(body)
    msg['Subject'] = subject
    msg['From'] = sender
    msg['To'] = ", ".join(TO)
    msg['CC'] = ", ".join(CC)
    
    # sending
    session = smtplib.SMTP('smtp.sendgrid.net', 587)
    session.starttls()
    session.login("spoton.net.in", "Star@123#")
    send_it = session.sendmail(sender, TO+CC, msg.as_string())
    session.quit()
## TO handle error of THCs count zero
# In[42]:

## VISHWAS EDIT 30/06/2016 for Actual Utilization and Volume Utilization. Summary is the same but giving the selected columns
thc_investigation_grpby = pd.DataFrame(thc_investigation,columns=['THCNO','Route_Path','Cons_Available','Wt_Available','Vol_Available','Wt_Util%','Vol_Util%'])
## VISHWAS EDIT 30/06/2016 for Actual Utilization and Volume Utilization. Summary is the same but giving the selected columns


##thc_investigation_grpby = thc_investigation.groupby(['Route_Path']).agg({'Cons_Available':sum, 'Wt_Available':sum, 'Vol_Available':sum}).reset_index()
thc_investigation_grpby.to_csv(r'D:\Data\LH_utilization_Verification\thc_investigation_grpb.csv')
thc_investigation_grpby['Wt_Available'] = thc_investigation_grpby.apply(lambda x:pd.np.round(x['Wt_Available']), axis=1)
thc_investigation_grpby['Vol_Available'] = thc_investigation_grpby.apply(lambda x:pd.np.round(x['Vol_Available']), axis=1)
thc_investigation_grpby = thc_investigation_grpby.sort_values('Cons_Available', ascending=False)
#thc_investigation_grpby.to_csv('summary.csv')




with ExcelWriter(r'D:\Data\LH_utilization_Verification\THC_Verification_'+str(yesterdate)+'.xlsx') as writer:
    thc_investigation_grpby.to_excel(writer, sheet_name='SUMMARY',engine='xlsxwriter')
    thc_investigation.to_excel(writer, sheet_name='THC_Verification',engine='xlsxwriter')
    condata.to_excel(writer, sheet_name='ConData',engine='xlsxwriter')

oppath = r'D:\Data\LH_utilization_Verification\THC_Verification_'+str(yesterdate)+'.xlsx'
# In[ ]:
filePath = oppath
def sendEmail(TO = ["prasanna.hegde@spoton.co.in","hubmgr_spot@spoton.co.in"],
            #TO = ["rajeesh.vr@spoton.co.in"],
            #TO = ["vishwas.j@spoton.co.in"],
            #CC = ["vishwas.j@spoton.co.in"],
            CC = ["pawan.sharma@spoton.co.in","abhik.mitra@spoton.co.in"],
            #CC = ["supratim@iepfunds.com","Ankit@iepfunds.com","vishwas.j@spoton.co.in","rajeesh.vr@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "LH Utilization Verification " + '- ' + str(yesterdate)
    body_text = """
    Dear All,
    
    PFA the LH Utilization verification for """+str(yesterdate)+ """
    
    Total THCs prepared on """+str(yesterdate)+""" = """+str(totalthcsprep)+"""
    THCs with low utilization and image identified as 'low' = """+str(thcVerification)+"""
    
    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends



#Sending output file via mail ends for THCS whose Origin and Destination are in main hublist

filePath = oppath_hublist_thcs
def sendEmail(TO = ["prasanna.hegde@spoton.co.in","hubmgr_spot@spoton.co.in"],
            #TO = ["rajeesh.vr@spoton.co.in"],
            #TO = ["vishwas.j@spoton.co.in"],
            #CC = ["vishwas.j@spoton.co.in"],
            CC = ["pawan.sharma@spoton.co.in","abhik.mitra@spoton.co.in","vishwas.j@spoton.co.in"],
            #CC = ["supratim@iepfunds.com","Ankit@iepfunds.com","vishwas.j@spoton.co.in","rajeesh.vr@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "THC Image not uploaded report" + '- ' + str(yesterdate)
    body_text = """
    Dear All,
    
    Linehaul THCs Image not uploaded in main hubs = """+str(header_org_dest_in_hublist_thcs)+"""
    
    PFA the report which shows the Linehaul THCs prepared yesterday and whose image not uploaded within 8 hours of THC departure time.
    
    
"""+str(header_org_dest_in_hublist_grp)+"""    
    
    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends for THCS whose Origin and Destination are in main hublist
