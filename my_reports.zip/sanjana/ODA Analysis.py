
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta,datetime
import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta,datetime
import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
from pandas import ExcelWriter
import os
import smtplib


import os
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from pandas import ExcelWriter
from email import encoders
# In[2]:


import geopy
import pandas as pd
from geopy.distance import vincenty, great_circle
# from __future__ import print_function, division
from datetime import datetime, timedelta
import webbrowser
import simplejson
import urllib
import numpy as np
import ast
from sqlalchemy import *
import operator
import Utilities

cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=PYTHON_DB;UID=PythonOnline;PWD=P@ssw0rd123$")

data = pd.read_sql("SELECT SC,[Name of SC],Type,Pincode FROM branchmaster",cnxn)
data=data.replace('425001\xa0','425001')

# In[3]:


scpins = data[['SC','Pincode']]


# In[4]:


scpins = scpins.rename(columns={'SC': 'BRANCH_CODE','Pincode':'BRPIN'})


# In[5]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()

query=("""SELECT CASE WHEN PUDTYPE = 'ADHOC'   

                          AND (( A.MKT_SBA_APPLICABLE = 'Y'   
                                OR A.MKT_HIRE_REASON = 'DEDICATED FOR SINGLE CUSTOMER'   
                                OR A.MKT_HIRE_REASON = 'NSL SHIPMENT'   
                                OR A.MKT_HIRE_REASON = 'LATE NIGHT/EARLY MORNING'   
                              )   
                          OR ( A.SENDERCODE = '000119837'    
                               OR A.SENDERCODE = '000118040'   
                               OR A.SENDERCODE = '000118041'   
                               OR A.SENDERCODE = '000119721'   
                               OR A.SENDERCODE = '000120083'   
                             )) THEN 'ADHOC-Special'   
                     ELSE PUDTYPE   
                END PUDTYPE_STATUS ,a.* FROM dbo.tblPUDYestMtdData  a  WITH (NOLOCK)""")


# In[6]:


pmd_df=pd.read_sql(query,Utilities.cnxn)


# In[7]:


pmd_df = pmd_df.dropna(subset = ['DATE'])


# In[8]:


# pmd_df.to_csv(r'PMD_May2018.csv')


# In[9]:


# pmd_df = pd.read_csv(r'PMD_2018-05-24.csv')


# In[10]:
# print len(pmd_df)

pmd_oda = pmd_df[pmd_df['PINTYPE']=='ODA']
# print len(pmd_oda)
pmd_oda = pmd_oda[pmd_oda.PUDTYPE.isin(['ADHOC','ODA'])]
# In[11]:
# print len(pmd_oda)

# exit(0)

pmd_oda.head()


# In[12]:


# pmd_oda.DATE2=pmd_oda.DATE2.map(lambda x:datetime.strptime(x,'%d %b %Y %H:%M'))


# In[17]:


totaldayslist = pmd_oda['DATE'].dt.date.unique()


# In[18]:

print (totaldayslist)
# exit(0)

workingdaylist = [i for i in totaldayslist if i.weekday()!=6]


# In[19]:


workingdays = len(workingdaylist)


# In[20]:


workingdays


# In[21]:


len(pmd_oda)


# In[80]:


odasummary = pd.pivot_table(pmd_oda,index=['BRANCH_CODE','PINCODE','PINTYPE'],columns=['TYP'], values=['ACT_WT','COST'], aggfunc={'ACT_WT':sum,'COST':sum}).reset_index()


# In[81]:


odasummary.columns = [' '.join(col).strip() for col in odasummary.columns.values]


# In[82]:


monthfirst = date.today().replace(day=1)
monthlast = date.today()-timedelta(days=1)


# In[83]:


monthfirst,monthlast

odasummary = odasummary.fillna(0)
# In[84]:


odasummary['BKG/Day'] = odasummary.apply(lambda x:pd.np.round(x['ACT_WT BKG']/workingdays,1), axis=1)


# In[85]:


odasummary['DLV/Day'] = odasummary.apply(lambda x:pd.np.round(x['ACT_WT DLV']/workingdays,1), axis=1)
odasummary['BKG_CPK'] = odasummary.apply(lambda x: 0 if x['ACT_WT BKG']==0 else pd.np.round(x['COST BKG']/x['ACT_WT BKG'],1), axis=1)
odasummary['DLV_CPK'] = odasummary.apply(lambda x: 0 if x['ACT_WT DLV']==0 else pd.np.round(x['COST DLV']/x['ACT_WT DLV'],1), axis=1)
odasummary['Total_ACT_WT'] = odasummary.apply(lambda x:(x['ACT_WT BKG']+x['ACT_WT DLV']), axis=1)
odasummary['Total_COST'] = odasummary.apply(lambda x:(x['COST BKG']+x['COST DLV']), axis=1)


# In[86]:


odasummary['Wt/Day'] = odasummary.apply(lambda x:pd.np.round(x['Total_ACT_WT']/workingdays,1), axis=1)


# In[87]:


odasummary['Total_CPK'] = odasummary.apply(lambda x: 0 if x['Total_ACT_WT']==0 else pd.np.round(x['Total_COST']/x['Total_ACT_WT'],1), axis=1)


# In[88]:


# odasummary.to_csv(r'ODA_Summary.csv')


# In[89]:


odasummary = pd.merge(odasummary,scpins, on=['BRANCH_CODE'], how='left')

print (odasummary[odasummary['BRANCH_CODE'] == 'SIKM'])
# In[90]:


odasummary.loc[odasummary.index[odasummary['BRANCH_CODE'] == 'BHRF'].values[0],['BRPIN']]=753012
odasummary.loc[odasummary.index[odasummary['BRANCH_CODE'] == 'NEIR'].values[0],['BRPIN']]=781031
try:
  odasummary.loc[odasummary.index[odasummary['BRANCH_CODE'] == 'SIKM'].values[0],['BRPIN']]=734015
except:
  pass
# odasummary.loc[odasummary.index[odasummary['BRANCH_CODE'] == 'LNIF'].values[0],['BRPIN']]=412308
try:
  odasummary.loc[odasummary.index[odasummary['BRANCH_CODE'] == 'SGLF'].values[0],['BRPIN']]=416122
except:
  pass
odasummary.loc[odasummary.index[odasummary['BRANCH_CODE'] == 'OJRF'].values[0],['BRPIN']]=422113 


# In[91]:


ia = odasummary[odasummary['BRANCH_CODE']=='BHRF'].index
odasummary.loc[ia,'BRPIN'] = 753012
ib = odasummary[odasummary['BRANCH_CODE']=='NEIR'].index
odasummary.loc[ib,'BRPIN'] = 781031
try:
  ic = odasummary[odasummary['BRANCH_CODE']=='SIKM'].index
  odasummary.loc[ic,'BRPIN'] = 734015
except:
  pass
try:
  ie = odasummary[odasummary['BRANCH_CODE']=='SGLF'].index
  odasummary.loc[ie,'BRPIN'] = 416122
except:
  pass
ig = odasummary[odasummary['BRANCH_CODE']=='OJRF'].index
odasummary.loc[ig,'BRPIN'] = 422113


# In[92]:


odasummary[odasummary['BRPIN']=='-']['BRANCH_CODE'].unique()


# In[93]:
odasummary=odasummary.fillna(0)

odasummary.BRPIN=odasummary.BRPIN.astype(int)


# In[94]:


keylist=['AIzaSyD74opFMfu5BXSfWrlz3JWdHKPlZq8SmVA','AIzaSyAQnhRjbUW7DTaqh2oDB_dDLE7WFOAGpIc','AIzaSyBHh5UbW1CYILQssgheYvaHcu9gOiAMOW4']


# In[95]:


def getdist(pin,scpin):

    try:
        g = geopy.geocoders.GoogleV3(api_key=keylist[2])
        pinresult=g.geocode('INDIA,'+str(pin))
        pinlat=pinresult.latitude
#         pinlat=coorddict.get(br)[0]
        pinlon=pinresult.longitude
#         pinlon=coorddict.get(br)[1]
        scpinresult=g.geocode('INDIA,'+str(scpin))
        scpinlat=scpinresult.latitude
        scpinlon=scpinresult.longitude
        distance=vincenty((scpinlat, scpinlon),(pinlat,pinlon)).kilometers
        return round(distance)
    except:
        return '-'


# In[98]:


import pandas as pd
dist=pd.read_csv('D:\shashvat\ODA-Dist-Pincode.csv')
dist=dist[dist.Distance!='Address not found']
dist.Distance=dist.Distance.astype(int)
dist=dist[dist.Distance<500]
distdict=dist.set_index(['SC Branch Pincode','PinCode'])['Distance'].to_dict()


# In[100]:


def getdistance(scpin,pin):
    try:
        s=distdict.get((scpin,pin))
        if s==None:
            s=getdist(scpin,pin)
            print('1   {0}'.format(s))
    except:
        s=getdist(scpin,pin)
        print('2   {0}'.format(s))
    return s


# In[101]:


odasummary['Distance']=odasummary.apply(lambda x:getdistance(x['BRPIN'],x['PINCODE']),axis=1)
# odasummary.Distance=odasummary.Distance.astype(int)
# odasummary.Distance=pd.np.round(odasummary.Distance.astype(pd.np.double),0)

# In[116]:
  

# odasummary1=odasummary.copy()


# In[117]:


# odasummary.head()


# In[118]:


# odasummary=odasummary[odasummary['Distance']!=]


# In[119]:


# odasummary1[odasummary1['Distance']=='-']


# In[111]:

bkgoda_exc = odasummary.sort_values('BKG/Day', ascending=False)
bkgoda_exc = bkgoda_exc[(bkgoda_exc['BKG/Day']>=700)& (bkgoda_exc['BKG_CPK']>=3.0)]
bkgoda_exc=bkgoda_exc[['BRANCH_CODE','PINCODE','BKG/Day','BKG_CPK','Distance']]
bkgoda_exc=bkgoda_exc.to_html()
dlvoda_exc = odasummary.sort_values('DLV/Day', ascending=False)
dlvoda_exc = dlvoda_exc[(dlvoda_exc['DLV/Day']>=700) & (dlvoda_exc['DLV_CPK']>=3.0)]
dlvoda_exc=dlvoda_exc[['BRANCH_CODE','PINCODE','DLV/Day','DLV_CPK','Distance']]
dlvoda_exc=dlvoda_exc.to_html()
oda_exc = odasummary.sort_values('Wt/Day', ascending=False)
oda_exc = oda_exc[(oda_exc['Wt/Day']>=700) & (oda_exc['Total_CPK']>=3.0)]
oda_exc=oda_exc[['BRANCH_CODE','PINCODE','BKG/Day','DLV/Day','BKG_CPK','DLV_CPK','Wt/Day','Total_CPK','Distance']]
oda_exc=oda_exc.to_html()
oda_exc


reportts = datetime.now()
opfilevar=reportts.date()

odasummary.to_csv(r'D:\Data\ODA Analysis\ODA_Summary_'+str(opfilevar)+'.csv')
oppath = r'D:\Data\ODA Analysis\ODA_Summary_'+str(opfilevar)+'.csv'


TO=['anto.paul@spoton.co.in']
FROM='reports.ie@spoton.co.in'
# TO=['vishwas.j@spoton.co.in']
# CC=['shashvat.suhane@spoton.co.in','vishwas.j@spoton.co.in']
# BCC = ['yogesh.singh@spoton.co.in','prabhakar.mahajan@spoton.co.in','nitin.tatyarao@spoton.co.in','vinodkumar.mishra@spoton.co.in','jai.prakash@spoton.co.in','nomesh.ganvir@spoton.co.in','sanjay.panse@spoton.co.in','sunil.khare@spoton.co.in','OPS.HUB.AMDH.1@spoton.co.in','aditya.shekhar@spoton.co.in','chidananda.biswal@spoton.co.in']
CC=['krishna.chandrasekar@spoton.co.in','abhik.mitra@spoton.co.in','satya.pal@spoton.co.in','shashvat.suhane@spoton.co.in']
BCC=['vishwas.j@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "ODA Pincodes PUD "+ str(opfilevar)
html='''<html>
<h4>Dear All,</h4>
<br>PFB the ODA analysis for PUD MTD</br>
Overall(BKG+DLV)'''+str(oda_exc)+'''<br>
BKG</br>'''+str(bkgoda_exc)+'''<br>
DLV</br>'''+str(dlvoda_exc)
# report=""
# # report+='<br>'
# report+='PFB the weight which are available in stock where distance between two location less than 500'
# # report+='<br>'
# report+=''
# report+='<br>'+senddf2.to_html()+'<br>'
klm=MIMEText(html,'html')
msg.attach(klm)
# bcd=MIMEText(senddf1.to_html(),'html')
# msg.attach(bcd)
# abc=MIMEText(report,'html')
# msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(oppath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()