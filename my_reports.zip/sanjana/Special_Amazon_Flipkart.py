
# coding: utf-8

# In[1]:

import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
import calendar
import datetime
from pandas import ExcelWriter
import os
import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from string import Template
import ftplib
from sqlalchemy import *
import pandas.io.sql
import sys
import Utilities


# In[ ]:




# In[2]:

cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
cursor = cnxn.cursor()


# In[94]:


query=("""SELECT --TOP 100              
        A.DOCKNO ,
        A.CDELDT ,

        --A.DC ,

        --A.DACCC ,

        --A.VTC ,

        --A.FTC ,
        A.BOOKING_REGION ,
        A.ACTUAL_WEIGHT ,
        A.PKGSNO ,
        A.VOLUME ,
        A.ORIGIN_BRCODE ,
        A.ORIGIN_BRNAME ,
        A.orgareaname ,
        A.ORGLOCTYPE ,
        A.DESTCD ,
        A.destareaname ,
        A.DESTHUB ,
        A.DESTLOCTYPE ,
        A.PINCODE ,
        A.DOCKDT ,
        A.DEFAULTHUB ,
        A.CURR_AREA ,
        A.CURR_BRANCHCODE ,
        A.CURR_BRANCHNAME ,
        BR.RGALPH CURR_REGION ,
        ISNULL(A.ARRV_AT_CURR_LOCATION, A.DOCKDT) ARRV_AT_CURR_LOCATION ,
        A.HOURS_LYING_AT_CURR_LOCATION ,
        BR.HUBCENTER ,
        A.ISDEPARTED_FRM_CURRLOC ,
        A.DEPARTURE_TO_LOC_FRM_CURLOC ,
        A.CurLocConStatusCategory ,
        A.CurLocConStatusCode ,
        A.CurLocConStatusDesc ,
        A.CurLocConStatusReason ,
        A.CurLocConStatusDate ,
        A.CurLocConStatusMasterCategory ,
        A.CSGNCD ,

        --REPLACE(A.CSGNNM, '"', '') CSGNNM ,
        REPLACE(DK.CSGNNM, '"', '') DK_CSGNNM ,
        A.CSGECD ,

        --REPLACE(A.CSGENM, '"', '') CSGENM ,
        REPLACE(DK.CSGENM, '"', '') DK_CSGENM ,
        A.TIME_STAMP ,
        A.DLV_PINCODE ,
        D.CustCode ,
        D.CustName ,
        D.ParentCode ,
        D.ParentName ,
        CASE WHEN ( A.CURR_BRANCHCODE = A.ORIGIN_BRCODE
                    AND A.ISDEPARTED_FRM_CURRLOC = 'NO'
                  ) THEN 'At_Origin_SC'
             WHEN ( A.CURR_BRANCHCODE = A.ORIGIN_BRCODE
                    AND A.ISDEPARTED_FRM_CURRLOC = 'YES'
                  ) THEN 'At_Origin_SC_Departed'
             WHEN ( A.CURR_BRANCHCODE = A.DEFAULTHUB
                    AND A.ISDEPARTED_FRM_CURRLOC = 'NO'
                  ) THEN 'At_Origin_HUB'
             WHEN ( A.CURR_BRANCHCODE = A.DEFAULTHUB
                    AND A.ISDEPARTED_FRM_CURRLOC = 'YES'
                  ) THEN 'At_Origin_HUB_Departed'
             WHEN ( A.CURR_BRANCHCODE = A.DESTHUB
                    AND A.ISDEPARTED_FRM_CURRLOC = 'NO'
                  ) THEN 'At_Destn_HUB'
             WHEN ( A.CURR_BRANCHCODE = A.DESTHUB
                    AND A.ISDEPARTED_FRM_CURRLOC = 'YES'
                  ) THEN 'At_Destn_HUB_Departed'
             WHEN ( A.CURR_BRANCHCODE = A.DESTCD
                    AND A.ISDEPARTED_FRM_CURRLOC = 'NO'
                  ) THEN 'At_Destn'
             WHEN ( A.ISDEPARTED_FRM_CURRLOC = 'NO' ) THEN 'At_Intransit_HUB'
             WHEN ( A.ISDEPARTED_FRM_CURRLOC = 'YES' ) THEN 'INTRANSIT_MOVING'
        END CON_LOC_TYPE ,
        A.ApptmntDelDate
FROM    dbo.tblTimeConnectionReport_Undelivered_2Hrs A
        CROSS APPLY dbo.UFN_GET_CUSTCODE_FOR_CON(A.DOCKNO) D
        INNER JOIN dbo.brms BR WITH ( NOLOCK ) ON A.CURR_BRANCHCODE = BR.BRCD
        LEFT OUTER JOIN dbo.tblETAData ET WITH ( NOLOCK ) ON A.DOCKNO = ET.ConNo
        LEFT OUTER JOIN dbo.DKT_TRACK DK WITH ( NOLOCK ) ON A.DOCKNO = DK.DOCKNO
                                                            AND DK.srno = 1
--WHERE A.CURR_AREA = 'pnqa' AND A.DESTCD IN ('KLHF','SGLF','STRF')
--WHERE   A.CURR_BRANCHCODE = A.DESTCD """)


# In[ ]:


df=pd.read_sql(query,cnxn)


# In[3]:

len(df)


# In[4]:

def fuzzyLogic(x):
    if x==None:
        return None
    elif (fuzz.partial_ratio('AMAZON'.lower(),x.lower()))>80:
#         v=fuzz.partial_ratio('Amazon'.lower(),x.lower())
        return "Amazon"
    elif (fuzz.partial_ratio('Cloudtail'.lower(),x.lower()))>80:
        return "CLOUDTAIL"
    elif (fuzz.partial_ratio('flipkart'.lower(),x.lower()))>80:
        return "Flipkart"
    elif (fuzz.partial_ratio('Appario'.lower(),x.lower()))>80:
        return "Amazon"
    elif (fuzz.partial_ratio('Myntra'.lower(),x.lower()))>80:
        return "Flipkart"
    else:
        return 0


# In[5]:

from fuzzywuzzy import fuzz,process
from fuzzywuzzy import fuzz


# In[6]:

df['Test']=df.apply(lambda x:fuzzyLogic(x['DK_CSGENM']),axis=1)


# In[7]:

ccflist= ['ADC','CPN','HCM','VSC','SSC','CDA','DNR','AFS','DDV','HWC','RRA','NPO','NPE','NPH','RRF','RRL','DIP','RRT','SHD','SPS','WIA','WIP','SRH','PSP','HIP','NTW','HIM','HMP','EWX','EWN','EWI','EEG']
ncflist = ['DNH','DEP','DDS','LDR','WIH','DDB','DDR','DGA','PDB','CSD','DLI','DSI','LMA','LCC','LDW','SHS','VCI']
stflist =['CCD','NSL','HBH','AND','PVB','WDP','MRS','SRD','SWP','SRS','SRP','CNC','LAM','SHO','SRC','DNL','SDC','SPD','DAL','SRE','DWA','DIA','DLP','DWR','FLD','ODV','SMD','LHI','MMB','MCD','MCL','MPH','MSH','LDV','LCR','LXL','LDD','LXN','LXO','LXV','LOC','LCN','LVB','MCV','HPM','LDO','MCA','MOO','MOP','SLX','DWC','AOD','SWN','DIR','EIR','SIR','PIR','VSV','VSD','VNT','DNC','VLE','SPC','NTD','CFD']
ucglist =['UCG','UG1','UG2','UG3']
aptlist=['APT','APN']
#blanklist =['CCD','NSL','SSC','CPN','HCM','HBH','AND','VSC']
def ccffunc(statuscode):
    if statuscode in ccflist:
        return 'CCF Con'
    elif statuscode in ucglist:
        return 'UCG'
    elif statuscode in ncflist:
        return "STF Con"
    elif statuscode in aptlist:
        return "Appointment Con"
    else:
        return "STF Con"


# In[8]:

df['Con_Type']=df.apply(lambda x:ccffunc(x['CurLocConStatusCode']),axis=1)


# In[9]:

off=['a','AM','A','ANIL','n','D','IBD AMAZING BUY','m',
     'SANTOSH HANAMAGOND','l','C','CLOUD PACKERS MOVERS','SHAH ZAHEER BILAL SHAH (KHAMGAON)(MAIN)',
'AM',
'M',
'SLKA AMAZON SLLER SERVICE',
'MA',
'A',
'A T S DREAMZONE ',
'N','ANIL',
'D',
'C',
'ADIL',
'LO',
'U']
off


# In[100]:


df= df[~df['DK_CSGENM'].isin(off)]


# In[10]:

df['DESTCD'] = df['DESTCD'].replace({'DBOM':'BWDB','DBLR':'BLRC','DPNQ':'PNQO','DLKO':'LKOB','DCCU':'CCUC','JAIO':'JAIC','HSRB':'BLRT'})


# In[11]:

amazon_cloud_df=df[((df.Test== 'Amazon')|(df.Test== 'CLOUDTAIL')) ]
len(amazon_cloud_df)


# In[12]:

amazon_cloud_df['ACTUAL_WEIGHT'].sum()


# In[13]:

amazon_summary=amazon_cloud_df.pivot_table(index=['DESTCD'],columns=['Con_Type'],aggfunc={'ACTUAL_WEIGHT':sum}).fillna(0)


# In[14]:

amazon_summary.columns = [' '.join(col).strip() for col in amazon_summary.columns.values]


# In[15]:

amazon_summary.rename(columns={'DESTCD':'Location','ACTUAL_WEIGHT Appointment Con':'Appointment_Wt',
                            'ACTUAL_WEIGHT CCF Con':'CCF_Wt','ACTUAL_WEIGHT STF Con':'Other_Wt','ACTUAL_WEIGHT UCG':'UCG_Wt'},inplace=True)


# In[16]:

amazon_summary=amazon_summary.reset_index()


# In[17]:

amazon_summary.rename(columns={'DESTCD':'Location'},inplace=True)


# In[18]:

amazon_summary['Total_Weight']=amazon_summary['Appointment_Wt']+amazon_summary['CCF_Wt']+amazon_summary['Other_Wt']+amazon_summary['UCG_Wt']


# In[19]:

amazon_summary['Appointment_Wt'] = pd.np.round(amazon_summary['Appointment_Wt']/1000.0,0)
# mergedf['Wt_CCF_Dest'] = pd.np.round(mergedf['Wt_CCF_Dest']/1000.0,0)
amazon_summary['CCF_Wt'] = pd.np.round(amazon_summary['CCF_Wt']/1000.0,0)
amazon_summary['Other_Wt'] = pd.np.round(amazon_summary['Other_Wt']/1000.0,0)
amazon_summary['UCG_Wt'] = pd.np.round(amazon_summary['UCG_Wt']/1000.0,0)
amazon_summary['Total_Weight'] = pd.np.round(amazon_summary['Total_Weight']/1000.0,0)


# In[20]:

capacity = pd.read_csv(r'D:\Python\Scripts and Files\Python Scripts\SC_Space.csv')

merger = pd.merge(amazon_summary, capacity, on=['Location'], how='left')


# In[21]:

merger['Current Space(Sqft)'].fillna('-',inplace=True)


# In[22]:

mergerreq = merger[merger['Current Space(Sqft)']!='-']


# In[23]:

mergerreq['%_Filled'] = pd.np.round(mergerreq['Total_Weight']*100.0/mergerreq['Capacity(T)'],0)
mergerreq['%_Filled_CCF'] = pd.np.round(mergerreq['CCF_Wt']*100.0/mergerreq['Capacity(T)'],0)
mergerreq['%_Filled_Appointment'] = pd.np.round(mergerreq['Appointment_Wt']*100.0/mergerreq['Capacity(T)'],0)


# In[24]:

#mergerreq.sort_values('%_Filled_Appointment',ascending=False).to_csv(r'Amazon_LoadSummary.csv')


# In[25]:

amazonpickuploc=amazon_cloud_df.pivot_table(index=['DESTCD',u'ORIGIN_BRCODE'],aggfunc={'ACTUAL_WEIGHT':sum}).reset_index()


# In[26]:

amazonpickuploc['ACTUAL_WEIGHT']=pd.np.round(amazonpickuploc['ACTUAL_WEIGHT']/1000.0,1)


# In[27]:

def getwt(loc):
    dfee=amazonpickuploc[amazonpickuploc['DESTCD']==loc].sort_values('ACTUAL_WEIGHT',ascending=False).head(3)
    return dfee


# In[28]:

amazon_pkplocs=pd.DataFrame()
for i in mergerreq['Location'].unique().tolist():
    dfe=getwt(i)
    amazon_pkplocs=pd.concat([amazon_pkplocs,dfe],ignore_index=True)


# In[29]:


amazon_pkplocs['Top_3_PickupLocs']=amazon_pkplocs.apply(lambda x:{x['ORIGIN_BRCODE']:x['ACTUAL_WEIGHT']},axis=1)


# In[30]:


amazon_pickuplocs1 = amazon_pkplocs.groupby('DESTCD')['Top_3_PickupLocs'].apply(lambda x: x.values).reset_index() 


# In[31]:

amazon_pickuplocs11=pd.merge(mergerreq,amazon_pickuplocs1,left_on='Location',right_on='DESTCD',how='left')


# In[32]:

amazon_pickuplocs11.sort_values('%_Filled_Appointment',ascending=False,inplace=True)


# In[ ]:

## Flip cart


# In[33]:

flipkart_df=df[df.Test== 'Flipkart']
len(flipkart_df)


# In[34]:

flipkart_df['ACTUAL_WEIGHT'].sum()


# In[35]:

flipkart_summary=flipkart_df.pivot_table(index=['DESTCD'],columns=['Con_Type'],aggfunc={'ACTUAL_WEIGHT':sum}).fillna(0)


# In[36]:

flipkart_summary.columns = [' '.join(col).strip() for col in flipkart_summary.columns.values]
flipkart_summary.rename(columns={'DESTCD':'Location','ACTUAL_WEIGHT Appointment Con':'Appointment_Wt',
                            'ACTUAL_WEIGHT CCF Con':'CCF_Wt','ACTUAL_WEIGHT STF Con':'Other_Wt','ACTUAL_WEIGHT UCG':'UCG_Wt'},inplace=True)


# In[37]:

flipkart_summary=flipkart_summary.reset_index()


# In[38]:

flipkart_summary.rename(columns={'DESTCD':'Location'},inplace=True)


# In[39]:

flipkart_summary['Total_Weight']=flipkart_summary['Appointment_Wt']+flipkart_summary['CCF_Wt']+flipkart_summary['Other_Wt']+flipkart_summary['UCG_Wt']
flipkart_summary['Appointment_Wt'] = pd.np.round(flipkart_summary['Appointment_Wt']/1000.0,0)

flipkart_summary['CCF_Wt'] = pd.np.round(flipkart_summary['CCF_Wt']/1000.0,0)
flipkart_summary['Other_Wt'] = pd.np.round(flipkart_summary['Other_Wt']/1000.0,0)
flipkart_summary['UCG_Wt'] = pd.np.round(flipkart_summary['UCG_Wt']/1000.0,0)
flipkart_summary['Total_Weight'] = pd.np.round(flipkart_summary['Total_Weight']/1000.0,0)


# In[40]:

flipkartmerger = pd.merge(flipkart_summary, capacity, on=['Location'], how='left')


# In[41]:

flipkartmerger['Current Space(Sqft)'].fillna('-',inplace=True)
flipkartmerger = flipkartmerger[flipkartmerger['Current Space(Sqft)']!='-']
flipkartmerger['%_Filled'] = pd.np.round(flipkartmerger['Total_Weight']*100.0/flipkartmerger['Capacity(T)'],0)
flipkartmerger['%_Filled_CCF'] = pd.np.round(flipkartmerger['CCF_Wt']*100.0/flipkartmerger['Capacity(T)'],0)
flipkartmerger['%_Filled_Appointment'] = pd.np.round(flipkartmerger['Appointment_Wt']*100.0/flipkartmerger['Capacity(T)'],0)


# In[42]:

#flipkartmerger.sort_values('%_Filled_Appointment',ascending=False).to_csv(r'Flipkart_LoadSummary.csv')


# In[43]:

pickuploc=flipkart_df.pivot_table(index=['DESTCD',u'ORIGIN_BRCODE'],aggfunc={'ACTUAL_WEIGHT':sum}).reset_index()


# In[44]:

pickuploc['ACTUAL_WEIGHT']=pd.np.round(pickuploc['ACTUAL_WEIGHT']/1000.0,1)


# In[45]:

def getwt(loc):
    dfe=pickuploc[pickuploc['DESTCD']==i].sort_values('ACTUAL_WEIGHT',ascending=False).head(3)
    return dfe


# In[46]:

flipkart_pickuplocs=pd.DataFrame()
for i in flipkartmerger['Location'].unique():
    dfee=getwt(i)
    flipkart_pickuplocs=pd.concat([flipkart_pickuplocs,dfee],ignore_index=True)


# In[47]:

flipkart_pickuplocs['Top_3_PickupLocs']=flipkart_pickuplocs.apply(lambda x:{x['ORIGIN_BRCODE']:x['ACTUAL_WEIGHT']},axis=1)


# In[48]:


flipkart_pickuplocs1 = flipkart_pickuplocs.groupby('DESTCD')['Top_3_PickupLocs'].apply(lambda x: x.values).reset_index() 


# In[49]:

flipkart_pickuplocs11=pd.merge(flipkartmerger,flipkart_pickuplocs1,left_on='Location',right_on='DESTCD',how='left')


# In[50]:

flipkart_pickuplocs11.sort_values('%_Filled_Appointment',ascending=False,inplace=True)


# In[51]:

todate=datetime.datetime.strftime(datetime.datetime.now(),"%Y-%m-%d")
todate


# In[55]:

amazon_pickuplocs12=amazon_pickuplocs11[['Location', u'Appointment_Wt', u'CCF_Wt', u'Other_Wt', u'UCG_Wt',
       u'Total_Weight', u'Current Space(Sqft)', u'Total Hub space(Sqft)',
       u'Capacity(T)', u'Type', u'Branch_type', u'%_Filled', u'%_Filled_CCF',
       u'%_Filled_Appointment', u'Top_3_PickupLocs']]


# In[57]:

flipkart_pickuplocs12=flipkart_pickuplocs11[[u'Location', u'Appointment_Wt', u'CCF_Wt', u'Other_Wt', u'UCG_Wt',
       u'Total_Weight', u'Current Space(Sqft)', u'Total Hub space(Sqft)',
       u'Capacity(T)', u'Type', u'Branch_type', u'%_Filled', u'%_Filled_CCF',
       u'%_Filled_Appointment',u'Top_3_PickupLocs']]


# In[58]:

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

# TO=['satya.pal@spoton.co.in','mahesh.reddy@spoton.co.in']  
TO=['mahesh.reddy@spoton.co.in']  

#TO=["krishna.chandrasekar@spoton.co.in","abhik.mitra@spoton.co.in",'satya.pal@spoton.co.in','uday.sharma@spoton.co.in']
FROM="reports.ie@spoton.co.in"
#CC=['mahesh.reddy@spoton.co.in']
CC=['mahesh.reddy@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = "Special Report for Amazon" + " - " + str(todate)


report="Dear All,"
report+='<br>'
report+='<br>'
report+='Please find the Load Summarry for Amazon'
report+='<br>'+amazon_pickuplocs12.to_html()+'<br>'

#report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)
# part = MIMEBase('application', "octet-stream")
# part.set_payload( open(filepath,"rb").read() )
# encoders.encode_base64(part)
# part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
# msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()



# In[59]:


# TO=['satya.pal@spoton.co.in','mahesh.reddy@spoton.co.in']  
TO=['mahesh.reddy@spoton.co.in']  

#TO=["krishna.chandrasekar@spoton.co.in","abhik.mitra@spoton.co.in",'satya.pal@spoton.co.in','uday.sharma@spoton.co.in']
FROM="reports.ie@spoton.co.in"
#CC=['mahesh.reddy@spoton.co.in']
CC=['mahesh.reddy@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = "Special Report for FlipKart" + " - " + str(todate)


report="Dear All,"
report+='<br>'
report+='<br>'
report+='Please find the Load Summarry for FlipKart'
report+='<br>'+flipkart_pickuplocs12.to_html()+'<br>'

#report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)
# part = MIMEBase('application', "octet-stream")
# part.set_payload( open(filepath,"rb").read() )
# encoders.encode_base64(part)
# part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
# msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()



# In[ ]:



