# -*- coding: utf-8 -*-
"""
Created on Tue Apr 25 10:15:11 2017

@author: rajeeshv
"""


# coding: utf-8

# In[36]:

import pandas as pd
from datetime import datetime, timedelta, date
from pandas import ExcelWriter

import os
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from pandas import ExcelWriter
from email import encoders
# In[2]:

pmddata = pd.read_csv(r'http://spoton.co.in/downloads/PMD/PMD.csv')


# In[3]:

len(pmddata)


# In[4]:

def adhocstdoda(pudtype,pintype):
    if pudtype == 'ADHOC':
        return 'MKT'+str('-')+str(pintype)
    else:
        return pudtype


# In[5]:

pmddata['PUDTYPES'] = pmddata.apply(lambda x: adhocstdoda (x['PUDTYPE2'],x['PINTYPE']),axis=1)


# In[6]:

#pmddata.to_csv(r'C:\Data\OCID_PMD\Monitoring_report_automation\PMD_test.csv')


# In[7]:

pmddatagrp = pmddata.groupby(['REGION2','DEPOT2','PUDTYPES']).agg({'ACT_WT2':sum,'COST2':sum}).reset_index()
pmddatagrp = pmddatagrp.fillna(0)

# In[8]:

pmddatagrp['CPKG'] = pmddatagrp.apply(lambda x: round(x['COST2']/x['ACT_WT2'],2),axis=1)



# In[9]:

pmddatagrpfull = pmddata.groupby(['PUDTYPES']).agg({'ACT_WT2':sum,'COST2':sum}).reset_index()
pmddatagrpfull['CPKG'] = pmddatagrpfull.apply(lambda x: round(x['COST2']/x['ACT_WT2'],2),axis=1)


# In[10]:

pmddatagrpfull.loc[pmddatagrpfull.index,'REGION2'] = 'ALL_INDIA'
columnsop = ['REGION2','DEPOT2','PUDTYPES','COST2','ACT_WT2','CPKG']
pmddatagrpfull = pd.DataFrame(pmddatagrpfull,columns=columnsop)


# In[11]:

totalpmd = pmddatagrpfull.append(pmddatagrp,ignore_index=True)


# In[12]:

totalpmdgrp = totalpmd.groupby(['REGION2','DEPOT2']).agg({'COST2':sum,'ACT_WT2':sum}).reset_index()
totalpmdgrp['CPKG'] = totalpmdgrp.apply(lambda x: round(x['COST2']/x['ACT_WT2'],2),axis=1)


# In[13]:

totalpmdmtd = pd.merge(totalpmdgrp,totalpmd,on=['REGION2','DEPOT2'],how='outer')


# In[14]:

totalpmdmtd['% ACT_WT'] = totalpmdmtd.apply(lambda x: round(x['ACT_WT2_y']*100.0/x['ACT_WT2_x'],2),axis=1)


# In[15]:

totalpmdmtd = totalpmdmtd.drop(['COST2_x', 'ACT_WT2_x', 'CPKG_x'], axis=1)
totalpmdmtd = totalpmdmtd.rename(columns={'COST2_y':'COST'})
totalpmdmtd = totalpmdmtd.rename(columns={'ACT_WT2_y':'ACT_WT'})
totalpmdmtd = totalpmdmtd.rename(columns={'CPKG_y':'CPKG'})


# ### FOR YESTERDAY

# In[17]:

def datestring(x):
    fulldate = datetime.strptime(x,'%d %b %Y %H:%M')
    return fulldate


# In[18]:

pmddata['DATE'] = pmddata.apply (lambda x:datestring (x['DATE2']),axis=1)


# In[19]:

pmddata['DATE'].values[0]


# In[20]:

yesterdate=date.today()-timedelta(hours=24)


# In[21]:

yesterdaydf = pmddata[(pmddata['DATE'] >= yesterdate)]
len(yesterdaydf)


# In[22]:

pmddatagrpyest = yesterdaydf.groupby(['REGION2','DEPOT2','PUDTYPES']).agg({'ACT_WT2':sum,'COST2':sum}).reset_index()
pmddatagrpyest['CPKG'] = pmddatagrpyest.apply(lambda x: round(x['COST2']/x['ACT_WT2'],2),axis=1)


# In[23]:

pmddatagrpfullyest = yesterdaydf.groupby(['PUDTYPES']).agg({'ACT_WT2':sum,'COST2':sum}).reset_index()
pmddatagrpfullyest['CPKG'] = pmddatagrpfullyest.apply(lambda x: round(x['COST2']/x['ACT_WT2'],2),axis=1)


# In[24]:

pmddatagrpfullyest.loc[pmddatagrpfullyest.index,'REGION2'] = 'ALL_INDIA'
columnsop = ['REGION2','DEPOT2','PUDTYPES','COST2','ACT_WT2','CPKG']
pmddatagrpfullyest = pd.DataFrame(pmddatagrpfullyest,columns=columnsop)


# In[25]:

totalpmdyest = pmddatagrpfullyest.append(pmddatagrpyest,ignore_index=True)


# In[26]:

totalpmdgrpyest = totalpmdyest.groupby(['REGION2','DEPOT2']).agg({'COST2':sum,'ACT_WT2':sum}).reset_index()
totalpmdgrpyest['CPKG'] = totalpmdgrpyest.apply(lambda x: round(x['COST2']/x['ACT_WT2'],2),axis=1)


# In[27]:

totalpmdyest = pd.merge(totalpmdgrpyest,totalpmdyest,on=['REGION2','DEPOT2'],how='outer')
totalpmdyest['% ACT_WT'] = totalpmdyest.apply(lambda x: round(x['ACT_WT2_y']*100.0/x['ACT_WT2_x'],2),axis=1)


# In[29]:

totalpmdyest = totalpmdyest.drop(['COST2_x', 'ACT_WT2_x', 'CPKG_x'], axis=1)
totalpmdyest = totalpmdyest.rename(columns={'COST2_y':'COST'})
totalpmdyest = totalpmdyest.rename(columns={'ACT_WT2_y':'ACT_WT'})
totalpmdyest = totalpmdyest.rename(columns={'CPKG_y':'CPKG'})


# In[31]:

totalpmdmerge = pd.merge(totalpmdyest,totalpmdmtd,on=['REGION2','DEPOT2','PUDTYPES'],suffixes=['_YDAY','_MTD'],how='outer')
columnsoptotal = ['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST_MTD','CPKG_MTD']
totalpmdmerge = pd.DataFrame(totalpmdmerge,columns=columnsoptotal)

print totalpmdmerge
totalpmdmerge.to_csv(r'totalpmdmerge.csv')
# In[37]:

slhgsngvldsnv

# In[34]:
dfformail = totalpmdmerge[totalpmdmerge['REGION2']=='ALL_INDIA']
peractwtyday = pd.np.round(dfformail['% ACT_WT_YDAY'].sum(),2)
actwtyday = dfformail['ACT_WT_YDAY'].sum()
costyday = dfformail['COST_YDAY'].sum()
cpkyday = pd.np.round((costyday/actwtyday),2)
peractwtmtd = dfformail['% ACT_WT_MTD'].sum()
actwtmtd = dfformail['ACT_WT_MTD'].sum()
costmtd = dfformail['COST_MTD'].sum()
cpkmtd = pd.np.round((costmtd/actwtmtd),2)


# In[35]:

sumlist = ['GRAND_TOTAL','-',peractwtyday,actwtyday,costyday,cpkyday,peractwtmtd,actwtmtd,costmtd,cpkmtd]
col_list = ['REGION2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST_MTD','CPKG_MTD']
totalsdf = pd.DataFrame(data=[sumlist], columns = col_list)
dfformail = dfformail.append(totalsdf,ignore_index=True)
 
columnsreq=['PUDTYPES','% ACT_WT_YDAY','CPKG_YDAY','% ACT_WT_MTD','CPKG_MTD']
dfformailreqcols = pd.DataFrame(dfformail,columns=columnsreq)
dfformailreqcols = dfformailreqcols.rename(columns={'% ACT_WT_YDAY':'%WT_YDAY'})
dfformailreqcols = dfformailreqcols.rename(columns={'% ACT_WT_MTD':'%WT_MTD'})

## For EAST TOTALS
easttotaldf = totalpmdmerge[totalpmdmerge['REGION2']=='E']
peractwtydayeast = pd.np.round(easttotaldf['% ACT_WT_YDAY'].sum(),2)
actwtydayeast = easttotaldf['ACT_WT_YDAY'].sum()
costydayeast = easttotaldf['COST_YDAY'].sum()
cpkydayeast = pd.np.round((costydayeast/actwtydayeast),2)
peractwtmtdeast = easttotaldf['% ACT_WT_MTD'].sum()
actwtmtdeast = easttotaldf['ACT_WT_MTD'].sum()
costmtdeast = easttotaldf['COST_MTD'].sum()
cpkmtdeast = pd.np.round((costmtdeast/actwtmtdeast),2)
sumlisteast = ['EAST_TOTAL','-',peractwtydayeast,actwtydayeast,costydayeast,cpkydayeast,peractwtmtdeast,actwtmtdeast,costmtdeast,cpkmtdeast]
col_list = ['REGION2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST_MTD','CPKG_MTD']
totalsdfeast = pd.DataFrame(data=[sumlisteast], columns = col_list)
dfformaileast = easttotaldf.append(totalsdfeast,ignore_index=True)
## For EAST TOTALS

## For NORTH TOTALS
northtotaldf = totalpmdmerge[totalpmdmerge['REGION2']=='N']
peractwtydaynorth = pd.np.round(northtotaldf['% ACT_WT_YDAY'].sum(),2)
actwtydaynorth = northtotaldf['ACT_WT_YDAY'].sum()
costydaynorth = northtotaldf['COST_YDAY'].sum()
cpkydaynorth = pd.np.round((costydaynorth/actwtydaynorth),2)
peractwtmtdnorth = northtotaldf['% ACT_WT_MTD'].sum()
actwtmtdnorth = northtotaldf['ACT_WT_MTD'].sum()
costmtdnorth = northtotaldf['COST_MTD'].sum()
cpkmtdnorth = pd.np.round((costmtdnorth/actwtmtdnorth),2)

sumlistnorth = ['NORTH_TOTAL','-',peractwtydaynorth,actwtydaynorth,costydaynorth,cpkydaynorth,peractwtmtdnorth,actwtmtdnorth,costmtdnorth,cpkmtdnorth]
col_list = ['REGION2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST_MTD','CPKG_MTD']
totalsdfnorth = pd.DataFrame(data=[sumlistnorth], columns = col_list)
dfformailnorth = northtotaldf.append(totalsdfnorth,ignore_index=True)
## For NORTH TOTALS

## For SOUTH TOTALS
southtotaldf = totalpmdmerge[totalpmdmerge['REGION2']=='S']
peractwtydaysouth = pd.np.round(southtotaldf['% ACT_WT_YDAY'].sum(),2)
actwtydaysouth = southtotaldf['ACT_WT_YDAY'].sum()
costydaysouth = southtotaldf['COST_YDAY'].sum()
cpkydaysouth = pd.np.round((costydaysouth/actwtydaysouth),2)
peractwtmtdsouth = southtotaldf['% ACT_WT_MTD'].sum()
actwtmtdsouth = southtotaldf['ACT_WT_MTD'].sum()
costmtdsouth = southtotaldf['COST_MTD'].sum()
cpkmtdsouth = pd.np.round((costmtdsouth/actwtmtdsouth),2)

sumlistsouth = ['SOUTH_TOTAL','-',peractwtydaysouth,actwtydaysouth,costydaysouth,cpkydaysouth,peractwtmtdsouth,actwtmtdsouth,costmtdsouth,cpkmtdsouth]
col_list = ['REGION2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST_MTD','CPKG_MTD']
totalsdfsouth = pd.DataFrame(data=[sumlistsouth], columns = col_list)
dfformailsouth = southtotaldf.append(totalsdfsouth,ignore_index=True)
## For SOUTH TOTALS

## For WEST TOTALS
westtotaldf = totalpmdmerge[totalpmdmerge['REGION2']=='W']
peractwtydaywest = pd.np.round(westtotaldf['% ACT_WT_YDAY'].sum(),2)
actwtydaywest = westtotaldf['ACT_WT_YDAY'].sum()
costydaywest = westtotaldf['COST_YDAY'].sum()
cpkydaywest = pd.np.round((costydaywest/actwtydaywest),2)
peractwtmtdwest = westtotaldf['% ACT_WT_MTD'].sum()
actwtmtdwest = westtotaldf['ACT_WT_MTD'].sum()
costmtdwest = westtotaldf['COST_MTD'].sum()
cpkmtdwest = pd.np.round((costmtdwest/actwtmtdwest),2)

sumlistwest = ['WEST_TOTAL','-',peractwtydaywest,actwtydaywest,costydaywest,cpkydaywest,peractwtmtdwest,actwtmtdwest,costmtdwest,cpkmtdwest]
col_list = ['REGION2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST_MTD','CPKG_MTD']
totalsdfwest = pd.DataFrame(data=[sumlistwest], columns = col_list)
dfformailwest = westtotaldf.append(totalsdfwest,ignore_index=True)
## For WEST TOTALS



eastpanindia = dfformail.append(dfformaileast,ignore_index=True)
eastpinorth = eastpanindia.append(dfformailnorth,ignore_index=True)
eastpinorthsouth = eastpinorth.append(dfformailsouth,ignore_index=True)
eastpinorthsouthwest = eastpinorthsouth.append(dfformailwest,ignore_index=True)


### Accessing Particular cells

mktoda = dfformailreqcols[dfformailreqcols['PUDTYPES']=='MKT-ODA']
mktmtdodacpk = mktoda['CPKG_MTD'].values[0]
mktydayodacpk = mktoda['CPKG_YDAY'].values[0]

mktstd = dfformailreqcols[dfformailreqcols['PUDTYPES']=='MKT-STD']
mktmtdstdcpk = mktstd['CPKG_MTD'].values[0]
mktydaystdcpk = mktstd['CPKG_YDAY'].values[0]
    
ctn = dfformailreqcols[dfformailreqcols['PUDTYPES']=='COUNTER']
mtdctncpk = ctn['CPKG_MTD'].values[0]
ydayctncpk = ctn['CPKG_YDAY'].values[0]

std = dfformailreqcols[dfformailreqcols['PUDTYPES']=='STD']
mtdstdcpk = std['CPKG_MTD'].values[0]
ydaystdcpk = std['CPKG_YDAY'].values[0]

oda = dfformailreqcols[dfformailreqcols['PUDTYPES']=='ODA']
mtdodacpk = oda['CPKG_MTD'].values[0]
ydayodacpk = oda['CPKG_YDAY'].values[0]
    
fixed = dfformailreqcols[dfformailreqcols['PUDTYPES']=='FIXED']
mtdfixedcpk = fixed['CPKG_MTD'].values[0]
ydayfixedcpk = fixed['CPKG_YDAY'].values[0]

if ydayfixedcpk>=0:  
     ydayfixedcpk = ydayfixedcpk
else:
    ydayfixedcpk =  0
    
smedf = dfformailreqcols[dfformailreqcols['PUDTYPES']=='SME']
try:
    mtdsmedfcpk = smedf['CPKG_MTD'].values[0]
except:
    mtdsmedfcpk=0

try:
    ydaysmedfcpk = smedf['CPKG_YDAY'].values[0]
except:
    ydaysmedfcpk = 0
### Accessing Particular cells
    
    
    
### For CPKS and Target CPK
dfforcpks = eastpinorthsouthwest[eastpinorthsouthwest['REGION2']=='ALL_INDIA']

stdsmelist = ['STD','SME']
stdsmedf = dfforcpks[dfforcpks['PUDTYPES'].isin(stdsmelist)]
stdsmecpk_yday = pd.np.round(stdsmedf['COST_YDAY'].sum()*1.0/stdsmedf['ACT_WT_YDAY'].sum(),2)
stdsmecpk_mtd = pd.np.round(stdsmedf['COST_MTD'].sum()*1.0/stdsmedf['ACT_WT_MTD'].sum(),2)

stdsmewt_yday = pd.np.round(stdsmedf['ACT_WT_YDAY'].sum()*100.0/actwtyday,2)
stdsmewt_mtd = pd.np.round(stdsmedf['ACT_WT_MTD'].sum()*100.0/actwtmtd,2)

print stdsmecpk_yday, stdsmecpk_mtd,stdsmewt_yday,stdsmewt_mtd

mktlist = ['MKT-ODA','MKT-STD']
mktdf = dfforcpks[dfforcpks['PUDTYPES'].isin(mktlist)]
mktdfcpk_yday = pd.np.round(mktdf['COST_YDAY'].sum()*1.0/mktdf['ACT_WT_YDAY'].sum(),2)
mktdfcpk_mtd = pd.np.round(mktdf['COST_MTD'].sum()*1.0/mktdf['ACT_WT_MTD'].sum(),2)

mktdfwt_yday = pd.np.round(mktdf['ACT_WT_YDAY'].sum()*100.0/actwtyday,2)
mktdfwt_mtd = pd.np.round(mktdf['ACT_WT_MTD'].sum()*100.0/actwtmtd,2)

print mktdfcpk_yday, mktdfcpk_mtd, mktdfwt_yday, mktdfwt_mtd

fixdf = dfforcpks[dfforcpks['PUDTYPES']=='FIXED']
fixdfcpk_yday = pd.np.round(fixdf['COST_YDAY'].sum()*1.0/fixdf['ACT_WT_YDAY'].sum(),2)
fixdfcpk_mtd = pd.np.round(fixdf['COST_MTD'].sum()*1.0/fixdf['ACT_WT_MTD'].sum(),2)

fixdfwt_yday = pd.np.round(fixdf['ACT_WT_YDAY'].sum()*100.0/actwtyday,2)
fixdfwt_mtd = pd.np.round(fixdf['ACT_WT_MTD'].sum()*100.0/actwtmtd,2)

print fixdfcpk_yday, fixdfcpk_mtd, fixdfwt_yday, fixdfwt_mtd

odadf = dfforcpks[dfforcpks['PUDTYPES']=='ODA']
#print odadf
odadfcpk_yday = pd.np.round(odadf['COST_YDAY'].sum()*1.0/odadf['ACT_WT_YDAY'].sum(),2)
odadfcpk_mtd = pd.np.round(odadf['COST_MTD'].sum()*1.0/odadf['ACT_WT_MTD'].sum(),2)

odadfwt_yday = pd.np.round(odadf['ACT_WT_YDAY'].sum()*100.0/actwtyday,2)
odadfwt_mtd = pd.np.round(odadf['ACT_WT_MTD'].sum()*100.0/actwtmtd,2)

print odadfcpk_yday, odadfcpk_mtd, odadfwt_yday, odadfwt_mtd


ctndf = dfforcpks[dfforcpks['PUDTYPES']=='COUNTER']
#print odadf
ctndfcpk_yday = pd.np.round(ctndf['COST_YDAY'].sum()*1.0/ctndf['ACT_WT_YDAY'].sum(),2)
ctndfcpk_mtd = pd.np.round(ctndf['COST_MTD'].sum()*1.0/ctndf['ACT_WT_MTD'].sum(),2)

ctndfwt_yday = pd.np.round(ctndf['ACT_WT_YDAY'].sum()*100.0/actwtyday,2)
ctndfwt_mtd = pd.np.round(ctndf['ACT_WT_MTD'].sum()*100.0/actwtmtd,2)


## Yesterday summary
data_yest = {'PUDTYPES': ['Overall', 'STD_SME', 'ODA' ,'MKT(STD&ODA)','FIX', 'COUNTER'],
         'CPK': [cpkyday,stdsmecpk_yday, odadfcpk_yday, mktdfcpk_yday, fixdfcpk_yday, ctndfcpk_yday],
         '%WT': [peractwtyday, stdsmewt_yday, odadfwt_yday, mktdfwt_yday, fixdfwt_yday, ctndfwt_yday]}
summary_yest = pd.DataFrame.from_dict(data_yest)
## Yesterday summary


## For MTD Summary
data_mtd = {'PUDTYPES': ['Overall', 'STD_SME', 'ODA' ,'MKT(STD&ODA)','FIX', 'COUNTER'],
         'CPK': [cpkmtd,stdsmecpk_mtd, odadfcpk_mtd, mktdfcpk_mtd, fixdfcpk_mtd, ctndfcpk_mtd],
         '%WT': [peractwtmtd, stdsmewt_mtd, odadfwt_mtd, mktdfwt_mtd, fixdfwt_mtd, ctndfwt_mtd],
         'Target_CPK': [0.99,0.79, 3.40, 2.00, 1.40, 0],
         'Target_%WT': ['100.00', '83.50', '5.90', '5.10', '2.00', '3.50']}
summary_mtd = pd.DataFrame.from_dict(data_mtd)
## For MTD Summary

summary_yest = pd.DataFrame(summary_yest,columns=['PUDTYPES','CPK','%WT'])
summary_mtd = pd.DataFrame(summary_mtd,columns=['PUDTYPES','CPK','%WT','Target_CPK','Target_%WT'])

### For CPKS and Target CPK

# In[ ]:
with ExcelWriter(r'D:\Data\Monitoring_report\Monitoring_Report_'+str(yesterdate)+'.xlsx') as writer:
    eastpinorthsouthwest.to_excel(writer, sheet_name='Monitoring_Report',engine='xlsxwriter')
    summary_yest.to_excel(writer, sheet_name='Yesterday_Summary',engine='xlsxwriter')
    summary_mtd.to_excel(writer, sheet_name='MTD_Summary',engine='xlsxwriter')

oppath = r'D:\Data\Monitoring_report\Monitoring_Report_'+str(yesterdate)+'.xlsx'
filePath = oppath
def sendEmail(#TO = ["supratim@iepfunds.com","Ankit@iepfunds.com","abhik.mitra@spoton.co.in","krishna.chandrasekar@spoton.co.in","Anto.Paul@Spoton.Co.In"],
             TO = ["mahesh.reddy@spoton.co.in"],
             CC = ["mahesh.reddy@spoton.co.in"],
             #CC = ["vishwas.j@spoton.co.in","rajeesh.vr@spoton.co.in","goutam.barik@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "Monitoring Report " + '- ' + str(yesterdate)
    msg["Subject"] = "Monitoring Report " + '- ' + str(yesterdate)
    body_text = """
    Dear All,
    
    PFB the PAN-INDIA Monitoring Report as of """+str(yesterdate)+ """
    
    PFB yesterday's summary
    
"""+str(summary_yest)+"""
    
    
    PFB MTD summary
    
"""+str(summary_mtd)+"""
    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends



