
# coding: utf-8

# In[1]:

import pandas as pd
import numpy as np
import pyodbc
from datetime import datetime,timedelta


# In[2]:

cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()
try:
    yestdate=datetime.strftime(datetime.now()-timedelta(days=1),"%Y-%m-%d")


    query=("""SELECT  DT.DOCKNO ,
            CONVERT(VARCHAR(10), DT.DOCKDT, 103) BookingDate ,
            DT.ORGNCD ,
            DT.DESTCD ,
            DT.PKGSNO ,
            PC.PcsNo ,
            PH.SheetType ,
            PH.SheetNo ,
            PH.SCCode ,
            PC.scanTime ,
            PH.RequestDate ,
            PH.FinalSubmitDate ,
            CONVERT(VARCHAR(10), DD.DELY_DT, 103) DeliveryDate ,
            ISNULL(PC.excepType, '-') excepType
    FROM    dbo.DKT_DELY DD WITH ( NOLOCK )
            INNER JOIN dbo.DOCKET DT WITH ( NOLOCK ) ON DT.DOCKNO = DD.DOCKNO
            INNER JOIN dbo.tblPLTAPICONDtls TC WITH ( NOLOCK ) ON TC.ConNo = DT.DOCKNO
            INNER JOIN dbo.tblPLTAPIPcsDtls PC WITH ( NOLOCK ) ON PC.ConNo = TC.ConNo
                                                                  AND PC.PLTHDRID = TC.PLTHDRID
            INNER JOIN dbo.tblPLTAPIHDR PH WITH ( NOLOCK ) ON PH.AutoID = TC.PLTHDRID
    WHERE    DD.DELY_DT IS NOT NULL
            AND DD.DELY_DT BETWEEN '{0}'
                           AND     '{1}'
                  """).format(yestdate+' 00:00:00',yestdate+' 23:59:00')
    #AND pc.excepType='PPS'


    # In[4]:

    df=pd.read_sql(query,cnxn)


    # In[5]:

    len(df)


    # In[6]:

    df=df[df['excepType']!='PPV']


    # In[7]:

    virtual_list=['AMCF',
    'AMDO',
    'BBIB','BDQB','IXGF','BLRF','BWDB','BRGO','CCUC','CJBC','DELO','GZBB','HYDO','IDRB','JAIC','JLRB','KNUB','LKOB','MAAC',
    'NAGB','PLGB','PNQO','PNQK','RPRB','SMBF','SNRB','VPIB','VGAF','SLMF','PATF','NDAB','COKB','BHOB']


    # In[8]:

    len(df)


    # In[9]:

    df['Ignore']=df.apply(lambda x: x['DOCKNO'] if x['SCCode'] in virtual_list else False,axis=1)


    # In[10]:

    conlist=df[df['Ignore']!=False]['DOCKNO'].unique().tolist()
    len(conlist)


    # In[11]:

    df=df[~df['DOCKNO'].isin(conlist)]
    len(df)


    # In[12]:

    df1=df[df['SheetType'].isin(['PT','LT'])]


    # In[19]:

    pt_summary=df1.pivot_table(index=['DOCKNO','SCCode'],columns=['SheetType'],aggfunc={'PcsNo':len}).fillna('-').reset_index()


    # In[20]:

    summary=pt_summary[pt_summary[('PcsNo','PT')]!='-']


    # In[21]:

    summary[('PcsNo','Remarks')]=summary.apply(lambda x: "Exception" if [('PcsNo','PT')]< x[('PcsNo','LT')] else None,axis=1)


    # In[23]:

    summary1=summary[summary[('PcsNo','Remarks')]=='Exception']
    summary1


    # In[27]:

    df.to_csv(r'D:\Data\Daily_Alok_PLT_Report\Pickup\PLT_Data_v3.csv')


    # In[28]:

    summary.to_csv(r'D:\Data\Daily_Alok_PLT_Report\Pickup\Summary.csv')


    # In[29]:

    filepath=r'D:\Data\Daily_Alok_PLT_Report\Pickup\PLT_Data_v3.csv'
    filepath1=r'D:\Data\Daily_Alok_PLT_Report\Pickup\Summary.csv'


    # In[30]:

    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    from email.mime.base import MIMEBase
    from email import encoders
    from datetime import datetime, timedelta
    import os
    import ftplib
    # import Utilities
    from calendar import monthrange
    import smtplib


    # In[31]:

    todate=datetime.strftime(datetime.now(),"%Y-%m-%d")
    todate


    # In[32]:


    TO=['mahesh.reddy@spoton.co.in',"alok.b@spoton.co.in"]
    CC=['satya.pal@spoton.co.in','abhik.mitra@spoton.co.in','shivananda.p@spoton.co.in']
    FROM="reports.ie@spoton.co.in"
    # FROM="mahesh.reddy@spoton.co.in"
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "PLT Pickup Exception Report " + " - " + str(todate)

    report=""
    report+="Dear All,"
    report+='<br>'
    report+='Please find the PLT Pickup Exception Report'
    report+='<br>'
    report+='<br>'
    report+='<br>'+summary1.to_html()+'<br>'
    report+='<br>'

    abc=MIMEText(report,'html')
    msg.attach(abc)
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filepath,"rb").read() )
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
    msg.attach(part)

    part1 = MIMEBase('application', "octet-stream")
    part1.set_payload( open(filepath1,"rb").read() )
    encoders.encode_base64(part1)
    part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
    msg.attach(part1)


    # server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    # server.login("mahesh.reddy@spoton.co.in", "Nov@2018")
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO+CC, msg.as_string())
    server.quit()

except:

  TO=['mahesh.reddy@spoton.co.in'] 
  CC=['mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "PLT Pickup Exception Error in Execution" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in PLT Pickup Exception Error in Execution'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO+CC, msg.as_string())
  server.quit()





