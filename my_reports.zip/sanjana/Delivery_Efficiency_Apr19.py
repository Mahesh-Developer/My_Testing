
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
import calendar
import datetime
from pandas import ExcelWriter
import os
import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from string import Template
import ftplib
from sqlalchemy import *
import pandas.io.sql
import sys


# In[2]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()


# In[3]:


query = ("""EXEC UBESP_PUD_ANALYSIS_OPEN_CLOSE_STOCK_ARRV_DELV_SSRS_OS""")
openingstock=pd.read_sql(query, cnxn)


# In[4]:


query1 = ("""EXEC UBESP_PUD_ANALYSIS_OPEN_CLOSE_STOCK_ARRV_DELV_SSRS_IN""")
fullincomingstock=pd.read_sql(query1, cnxn)


# In[5]:


query2 = ("""EXEC UBESP_PUD_ANALYSIS_OPEN_CLOSE_STOCK_ARRV_DELV_SSRS_DL""")
deliveredstock=pd.read_sql(query2, cnxn)


# In[6]:


query3 = ("""EXEC UBESP_PUD_ANALYSIS_OPEN_CLOSE_STOCK_ARRV_DELV_SSRS_CS """)
closingstockfull=pd.read_sql(query3, cnxn)


# In[7]:


openingstock.to_csv(r'openingstock.csv')
fullincomingstock.to_csv(r'fullincomingstock.csv')
deliveredstock.to_csv(r'deliveredstock.csv')
closingstockfull.to_csv(r'closingstockfull.csv')


# In[8]:


print (len(openingstock), len(fullincomingstock), len(deliveredstock), len(closingstockfull))
#exit(0)

# In[9]:


openingstock.rename(columns={'CDELDT':'DUE DATE','DeliveryStatus': 'Delivery Status','REPORTDATE_MIN_ARRVDT':'REPORTDATE MIN ARRVDT','ConStatusCode':'Con Status Code','DEL_LOCATION_TYPE':'DEL LOCATION TYPE','DEST_BRCD':'DEST BRCD','DEST_AREA':'DEST AREA'},inplace=True)
fullincomingstock.rename(columns={'INC_ARRV_CATEGORY':'INC ARRV CATEGORY','ConStatusCode':'Con Status Code','DEL_LOCATION_TYPE':'DEL LOCATION TYPE','DEST_BRCD':'DEST BRCD','DEST_AREA':'DEST AREA'},inplace=True)
deliveredstock.rename(columns={'CDELDT':'DUE DATE','DELY_DT':'DELY DT','ConStatusCode':'Con Status Code','DEL_LOCATION_TYPE':'DEL LOCATION TYPE','DEST_BRCD':'DEST BRCD','DEST_AREA':'DEST AREA'},inplace=True)
closingstockfull.rename(columns={ 'CDELDT':'DUE DATE','REPORTDATE_MIN_ARRVDT':'REPORTDATE MIN ARRVDT','IS_FREE_CON':'Is Free Con','ARRV_AT_DEST_SC':'ARRV AT DEST SC','ConStatusCategory':'Con Status Category','ConStatusCode':'Con Status Code','DEL_LOCATION_TYPE':'DEL LOCATION TYPE','DEST_BRCD':'DEST BRCD','DEST_AREA':'DEST AREA'},inplace=True)


# In[10]:


openingstock=openingstock.fillna({'PARENTCODE':0,'CSGNCD':0,'CSGECD':0})
fullincomingstock=fullincomingstock.fillna({'PARENTCODE':0,'CSGNCD':0,'CSGECD':0})
deliveredstock=deliveredstock.fillna({'PARENTCODE':0,'CSGNCD':0,'CSGECD':0})
closingstockfull=closingstockfull.fillna({'PARENTCODE':0,'CSGNCD':0,'CSGECD':0})


# In[11]:


liblist = ['000119721']
openingstock = openingstock[~(openingstock['CSGNCD'].isin(liblist))&~(openingstock['CSGECD'].isin(liblist))]
deliveredstock = deliveredstock[~(deliveredstock['CSGNCD'].isin(liblist))&~(deliveredstock['CSGECD'].isin(liblist))]
fullincomingstock = fullincomingstock[~(fullincomingstock['CSGNCD'].isin(liblist))&~(fullincomingstock['CSGECD'].isin(liblist))]


# In[12]:


len(openingstock), len(fullincomingstock), len(deliveredstock), len(closingstockfull)


# In[13]:


projectparentcodesexclist = ['000117991','000118040','000118041','000118042','000118043','000118075','000111007','000114381','000120083']
openingstock = openingstock[~(openingstock['PARENTCODE'].isin(projectparentcodesexclist))]
fullincomingstock = fullincomingstock[~(fullincomingstock['PARENTCODE'].isin(projectparentcodesexclist))]
deliveredstock = deliveredstock[~(deliveredstock['PARENTCODE'].isin(projectparentcodesexclist))]


# In[14]:


len(openingstock), len(fullincomingstock), len(deliveredstock), len(closingstockfull)


# In[15]:


projectconsgcd = ['000117991','000118040','000118041','000118043','000111007','000118042','000118075','000114381']
openingstock = openingstock[~(openingstock['CSGNCD'].isin(projectconsgcd))&~(openingstock['CSGECD'].isin(projectconsgcd))]
fullincomingstock = fullincomingstock[~(fullincomingstock['CSGNCD'].isin(projectconsgcd))&~(fullincomingstock['CSGECD'].isin(projectconsgcd))]
deliveredstock = deliveredstock[~(deliveredstock['CSGNCD'].isin(projectconsgcd))&~(deliveredstock['CSGECD'].isin(projectconsgcd))]


# In[16]:


len(openingstock), len(fullincomingstock), len(deliveredstock), len(closingstockfull)


# In[17]:


parentcodesexclist = ['000116867','000118067','000118068','000108751','000118554']
destareaexcludelist = ['BOMA','HYDA', 'NCRA', 'BLRA'] ## Added HYDA on 27-10-2017
openingstock = openingstock[~((openingstock['PARENTCODE'].isin(parentcodesexclist)) & (openingstock['DEST AREA'].isin(destareaexcludelist)))]
fullincomingstock = fullincomingstock[~((fullincomingstock['PARENTCODE'].isin(parentcodesexclist))& (fullincomingstock['DEST AREA'].isin(destareaexcludelist)))]
deliveredstock = deliveredstock[~((deliveredstock['PARENTCODE'].isin(parentcodesexclist)) & (deliveredstock['DEST AREA'].isin(destareaexcludelist)))]


# In[18]:


delbranchdf=deliveredstock[['DEST BRCD','DEST AREA']]
opbranchdf=openingstock[['DEST BRCD','DEST AREA']]
branchdf = pd.merge(delbranchdf,opbranchdf,on=['DEST BRCD','DEST AREA'],how='outer')
branchdf.rename(columns={'DEST BRCD':'BRANCH CODE','DEST AREA':'Area'}, inplace=True)
branchdf = branchdf.drop_duplicates(['BRANCH CODE'])


# In[19]:


holidayquery = ("""
            select * from tblYearlyHolidayMst with (nolock) where HDAY_DATE>'2016-01-01'
            """)

holidaymaster = pd.read_sql(holidayquery, cnxn)

def datestring(x):
    try:
        x = str(x)
        fulldate = datetime.datetime.strptime(x,'%Y-%m-%d %H:%M:%S')
        return fulldate
    except:
        x = str(x)
        fulldate = datetime.datetime.strptime(x,'%d-%m-%Y %H:%M')
        return fulldate


holidaymaster['HDAY_DATE'] = holidaymaster.apply(lambda x : datestring(x['HDAY_DATE']),axis=1)


now = datetime.datetime.now()
selectdate = now-timedelta(days=1)
selectdate = selectdate.replace(hour=0, minute=0, second=0).strftime('%Y-%m-%d %H:%M:%S')
selectdate = datetime.datetime.strptime(selectdate,'%Y-%m-%d %H:%M:%S')

holidaylist = list(set(holidaymaster['HDAY_DATE'].tolist()))

## check yesterday in holiday list
if selectdate in holidaylist:
    print ('Yesterday in holiday list')
    selectdf = holidaymaster[holidaymaster['HDAY_DATE']==selectdate]
    selectdfbrcdlist = selectdf['BRCD'].tolist()
    selectdfbrcdlist = list(set(selectdfbrcdlist))
    selectdfarealist = selectdf['ControlArea'].tolist()
    selectdfarealist = list(set(selectdfarealist))
    print (selectdfbrcdlist)
    print (selectdfarealist)

    openingstock = openingstock[~(openingstock['DEST BRCD'].isin(selectdfbrcdlist))]
    openingstock = openingstock[~(openingstock['DEST AREA'].isin(selectdfarealist))]

    fullincomingstock = fullincomingstock[~(fullincomingstock['DEST BRCD'].isin(selectdfbrcdlist))]
    fullincomingstock = fullincomingstock[~(fullincomingstock['DEST AREA'].isin(selectdfarealist))]

    deliveredstock = deliveredstock[~(deliveredstock['DEST BRCD'].isin(selectdfbrcdlist))]
    deliveredstock = deliveredstock[~(deliveredstock['DEST AREA'].isin(selectdfarealist))]
else:
    selectdfbrcdlist = []
    selectdfarealist = []
    print ('Yesterday not in holiday list')


# In[20]:


len(openingstock), len(fullincomingstock), len(deliveredstock), len(closingstockfull)


# In[21]:


openingstock = openingstock[openingstock['CON_BLOCKED_FOR_PAY_ISSUES']=='NO']
fullincomingstock = fullincomingstock[fullincomingstock['CON_BLOCKED_FOR_PAY_ISSUES']=='NO']
# deliveredstock = deliveredstock[deliveredstock['CON_BLOCKED_FOR_PAY_ISSUES']=='NO']
closingstockfull = closingstockfull[closingstockfull['CON_BLOCKED_FOR_PAY_ISSUES']=='NO']


# In[22]:


len(openingstock), len(fullincomingstock), len(deliveredstock), len(closingstockfull)


# In[23]:


openingstock_std = openingstock[openingstock['DEL LOCATION TYPE']=='STD']
fullincomingstock_std = fullincomingstock[fullincomingstock['DEL LOCATION TYPE']=='STD']
deliveredstock_std = deliveredstock[deliveredstock['DEL LOCATION TYPE']=='STD']
closingstockfull_std = closingstockfull[closingstockfull['DEL LOCATION TYPE']=='STD']


# In[24]:


ignorestatuscodelist = ['UCG','SSC','UG1','UG2','UG3','SHS']
#ignorestatuscodelist = ['UCG','SSC','UG1','UG2','UG3']
#ignorestatusdesclist = ['Awaiting for NSL Delivery Confirmation', 'Awaiting for ODA Delivery Confirmation', 'Change of Pincode from STD to ODA - Pending Approval', 'Non Serviceable Location', 'ODA DRS PREPARED', 'Shipment Held for ODA Delivery', 'Shipment held for Sales Tax inspection', 'Shipment Seized By Check Post / Sales Tax','STD to ODA Pincode Change Request - Awaiting CS Confirmation','Tagged For UCG']
openingstock_std=openingstock_std[~openingstock_std['Con Status Code'].isin(ignorestatuscodelist)]
closingstockfull_std=closingstockfull_std[~closingstockfull_std['Con Status Code'].isin(ignorestatuscodelist)]


# In[25]:


incoming12stock_std = fullincomingstock_std[(fullincomingstock_std['INC ARRV CATEGORY']=='<12PM')]
openinggroupby_std=openingstock_std.groupby(['DEST BRCD']).agg({'DOCKNO': 'count'}).reset_index()
incoming12groupby_std=incoming12stock_std.groupby(['DEST BRCD']).agg({'DOCKNO': 'count'}).reset_index()
deliveredgroupby_std=deliveredstock_std.groupby(['DEST BRCD']).agg({'DOCKNO': 'count'}).reset_index()


# In[26]:


merge_effeciency_std = pd.merge(openinggroupby_std,incoming12groupby_std,on=['DEST BRCD'], suffixes=['_op','_in'],how='outer')
merge_effeciency_std = pd.merge(merge_effeciency_std,deliveredgroupby_std, on=['DEST BRCD'], how='outer')
merge_effeciency_std = merge_effeciency_std.fillna(0)


# In[27]:


merge_effeciency_std['Delivery_Efficiency']=pd.np.round((merge_effeciency_std['DOCKNO']*100.0/(merge_effeciency_std['DOCKNO_op']+merge_effeciency_std['DOCKNO_in'])).replace([np.inf,-np.inf],np.nan).fillna(0),0)


# In[28]:


merge_effeciency_std.rename(columns={'DOCKNO':'DOCKNO_Delivered'}, inplace=True)
merge_effeciency_std=pd.merge(merge_effeciency_std,branchdf,left_on=['DEST BRCD'],right_on=['BRANCH CODE'], how = 'inner')
merge_effeciency_std = merge_effeciency_std.drop(['BRANCH CODE'], axis=1)


# In[29]:


openingcons_std = merge_effeciency_std['DOCKNO_op'].sum() 
incomingcons_std = merge_effeciency_std['DOCKNO_in'].sum()
deliveredcons_std = merge_effeciency_std['DOCKNO_Delivered'].sum()
deliveryefficiency_std = pd.np.round(deliveredcons_std*100.0/(incomingcons_std+openingcons_std),2)
merge_effeciency_area_std=merge_effeciency_std.groupby(['Area']).agg({'DOCKNO_op': 'sum','DOCKNO_in': 'sum','DOCKNO_Delivered': 'sum'}).reset_index()
stockcons = openingcons_std+incomingcons_std


# In[30]:


merge_effeciency_area_std['Delivery_Efficiency']=pd.np.round((merge_effeciency_area_std['DOCKNO_Delivered']*100.0/(merge_effeciency_area_std['DOCKNO_op']+merge_effeciency_area_std['DOCKNO_in'])).replace([np.inf,-np.inf],np.nan).fillna(0),0)


# In[31]:


def datetimesplit(x):
    fulldate = datetime.strptime(x.split(' '),'%d-%m-%Y %H:%M:S')
    return fulldate

opfilevar = date.today() - timedelta(hours=24)


# In[32]:


merge_effeciency_std


# In[33]:


merge_effeciency_area_std['Total_Stock'] = merge_effeciency_area_std['DOCKNO_op']+merge_effeciency_area_std['DOCKNO_in']


# In[34]:


merge_effeciency_area_std.columns


# In[35]:


efficiencyreqcols_std = merge_effeciency_area_std[['Area','DOCKNO_op','DOCKNO_in','Total_Stock','DOCKNO_Delivered','Delivery_Efficiency']]


# In[36]:


efficiencyreqcols_std.head()


# In[37]:


sumlist = ['TOTAL',openingcons_std, incomingcons_std, stockcons, deliveredcons_std, deliveryefficiency_std]
col_list = ['Area','DOCKNO_op','DOCKNO_in','Total_Stock','DOCKNO_Delivered','Delivery_Efficiency']
totalsdf_std = pd.DataFrame(data=[sumlist], columns = col_list)
efficiencyreqcols_std = efficiencyreqcols_std.append(totalsdf_std,ignore_index=True)


# In[38]:


merge_effeciency_std =merge_effeciency_std[~(merge_effeciency_std['DEST BRCD'].isin(selectdfbrcdlist))]
efficiencyreqcols_std=efficiencyreqcols_std[~(efficiencyreqcols_std['Area'].isin(selectdfarealist))]

oppath1=r'D:\Data\eta_rank\Delivery_Efficiency\Delivery_Efficiency_'+str(opfilevar)+'.xlsx'

with ExcelWriter(r'D:\Data\eta_rank\Delivery_Efficiency\Delivery_Efficiency_'+str(opfilevar)+'.xlsx') as writer:
    ###orginal_cancel_basedata.to_excel(writer, sheet_name='Sheet1',engine='xlsxwriter')
    efficiencyreqcols_std.to_excel(writer, sheet_name='AREA_WISE',engine='xlsxwriter')
    merge_effeciency_std.to_excel(writer, sheet_name='SC_WISE',engine='xlsxwriter')


# In[39]:


def datestring2(tsp):
    tsp = str(tsp)
    try:
        return datetime.datetime.strptime(tsp.split(' ')[0], '%d-%m-%Y')
    except:
        return datetime.datetime.strptime(tsp.split(' ')[0], '%Y-%m-%d')


def datestring(x):
    try:
        fulldate = datetime.datetime.strptime(x,'%Y-%m-%d')
        return fulldate
    except:
        fulldate = datetime.datetime.strptime(x,'%d-%m-%Y')
        return fulldate


# In[40]:


efficiencyreqcols_std.rename(columns={'DOCKNO_op':'Opening','DOCKNO_in':'Incoming','DOCKNO_Delivered':'Delivered','Delivery_Efficiency':'STD_DE'},inplace=True)
efficiencyreqcols_std.Opening = efficiencyreqcols_std.Opening.astype(int)
efficiencyreqcols_std.Incoming = efficiencyreqcols_std.Incoming.astype(int)
efficiencyreqcols_std.Total_Stock = efficiencyreqcols_std.Total_Stock.astype(int)
efficiencyreqcols_std.Delivered = efficiencyreqcols_std.Delivered.astype(int)
efficiencyreqcols_std.STD_DE = efficiencyreqcols_std.STD_DE.astype(int)


# In[41]:


filePath1 = oppath1
#efficiencyreqcols_std=efficiencyreqcols_std.dropna()
efficiencyreqcols_std=efficiencyreqcols_std.fillna(0)

#vishwas.j@spoton.co.in
# TO=["vishwas.j@spoton.co.in"]
TO = ["reports.ie@spoton.co.in"]
FROM="reports.ie@spoton.co.in"
# CC=["vishwas.j@spoton.co.in"]
CC = ["sqtf@spoton.co.in","SQ_spot@spoton.co.in","abhik.mitra@spoton.co.in"]
# BCC=["vishwas.j@spoton.co.in"]
BCC = ["shashvat.suhane@spoton.co.in","mahesh.reddy@spoton.co.in","sachidanand.pandey@spoton.co.in","renugopal.l@spoton.co.in","sathya.chander@spoton.co.in","alagu.mahendran@spoton.co.in","awadhesh.kumar.mishra@spoton.co.in","sanjay.parab@spoton.co.in","ramesh.s@spoton.co.in","md.zaya@spoton.co.in","Pradyumna.Kumar@Spoton.Co.In","rajesh.mishra@spoton.co.in","raghavendra.rao@spoton.co.in","ashwani.gangwar@spoton.co.in","pramod.pandey@spoton.co.in","trilochan.panda@spoton.co.in","sunil.nakte@spoton.co.in","chandrima.banerjee@spoton.co.in", "suresh.d@spoton.co.in", "pankaj.jha@spoton.co.in","aom_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in","narendra.londhe@spoton.co.in"]
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)


html3='''
<h5>The AREA-WISE and SC-WISE summary has been attached in the mail.</h5>
<h5> For the base data, please refer the link </h5>
<p><a href= "http://spoton.co.in/downloads/OCID/OCID.xls"</a>http://spoton.co.in/downloads/OCID/OCID.xls</p></b>
''' 
    
report=""
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='PFB the STD Delivery Efficiency of '+str(opfilevar)
report+='<br>'
report+='Delivered = '+str(deliveredcons_std)
report+='<br>'
report+='Opening Stock = '+str(openingcons_std)
report+='<br>'
report+='Incoming Cons = '+str(incomingcons_std)
report+='<br>'
report+='STD DE = '+str(deliveryefficiency_std)+ '%'
report+='<br>'
report+='<br>'+efficiencyreqcols_std.to_html()+'<br>'
report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)

part = MIMEBase('application', "octet-stream")
part.set_payload( open(filePath1,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath1))
msg.attach(part)


server=smtplib.SMTP('smtp.sendgrid.net', 587)
# server=smtplib.SMTP('smtp.gmail.com', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
# server.login('vishwas.j@spoton.co.in', 'Nov@2018')
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()


# In[42]:


# with ExcelWriter(r'D:\Data\DE_Conwise_Stock\DE_STD\Delivery_Efficiency_STD_'+str(opfilevar)+'.xlsx') as writer:
#     openingstock.to_excel(writer, sheet_name='OPENING_STOCK',engine='xlsxwriter')
#     incoming12stock_std.to_excel(writer, sheet_name='INCOMING_STOCK',engine='xlsxwriter')
#     deliveredstock.to_excel(writer, sheet_name='DELIVERED',engine='xlsxwriter')
    # closingstockfull.to_excel(writer, sheet_name='CLOSING_STOCK',engine='xlsxwriter')


# ## ODA DE Calculation

# In[43]:


openingstock_oda = openingstock[openingstock['DEL LOCATION TYPE']=='ODA']
deliveredstock_oda = deliveredstock[deliveredstock['DEL LOCATION TYPE']=='ODA']

openingstock_oda=openingstock_oda[~openingstock_oda['Con Status Code'].isin(ignorestatuscodelist)]


openingstock_oda = openingstock_oda[(openingstock_oda['REPORTDATE MIN ARRVDT']>48)]
openinggroupby_oda=openingstock_oda.groupby(['DEST BRCD']).agg({'DOCKNO': 'count'}).reset_index()

deliveredgroupby_oda=deliveredstock_oda.groupby(['DEST BRCD']).agg({'DOCKNO': 'count'}).reset_index()
merge_effeciency_oda = pd.merge(openinggroupby_oda,deliveredgroupby_oda, on=['DEST BRCD'], suffixes=['_open','_d'], how='outer')
merge_effeciency_oda = merge_effeciency_oda.fillna(0)

merge_effeciency_oda['Delivery_Efficiency']=pd.np.round((merge_effeciency_oda['DOCKNO_d']*100.0/merge_effeciency_oda['DOCKNO_open']).replace([np.inf,-np.inf],np.nan).fillna(0),2)

merge_effeciency_oda.rename(columns={'DOCKNO_d':'DOCKNO_Delivered'}, inplace=True)
merge_effeciency_oda=pd.merge(merge_effeciency_oda,branchdf,left_on=['DEST BRCD'],right_on=['BRANCH CODE'], how = 'inner')


# In[44]:


merge_effeciency_oda['DOCKNO_open'].sum()
merge_effeciency_oda['DOCKNO_Delivered'].sum()


# In[45]:


merge_effeciency_oda = merge_effeciency_oda.drop(['BRANCH CODE'], axis=1)
openingcons_oda = merge_effeciency_oda['DOCKNO_open'].sum() 
deliveredcons_oda = merge_effeciency_oda['DOCKNO_Delivered'].sum()
deliveryefficiency_oda = pd.np.round(deliveredcons_oda*100.0/(openingcons_oda),2)


# In[46]:


openingcons_oda,deliveredcons_oda,deliveryefficiency_oda


# In[47]:


merge_effeciency_area_oda=merge_effeciency_oda.groupby(['Area']).agg({'DOCKNO_open': 'sum','DOCKNO_Delivered': 'sum'}).reset_index()

merge_effeciency_area_oda['Delivery_Efficiency']=pd.np.round((merge_effeciency_area_oda['DOCKNO_Delivered']*100.0/merge_effeciency_area_oda['DOCKNO_open']).replace([np.inf,-np.inf],np.nan).fillna(0),2)
#merge_effeciency_area['Delivery_Efficiency']= merge_effeciency_area.apply(lambda x:getsum(x['DOCKNO_Delivered'],x['DOCKNO_open']),axis=1)

sumlist_oda = ['TOTAL',deliveredcons_oda,openingcons_oda,deliveryefficiency_oda]
col_list_oda = ['Area','DOCKNO_Delivered','DOCKNO_open','Delivery_Efficiency']
totalsdf_oda = pd.DataFrame(data=[sumlist_oda], columns = col_list_oda)
merge_effeciency_area_oda = merge_effeciency_area_oda.append(totalsdf_oda,ignore_index=True)


# In[48]:


merge_effeciency_area_oda


# In[49]:


merge_effeciency_area_oda
merge_effeciency_area_oda.rename(columns={'DOCKNO_open':'Opening','DOCKNO_Delivered':'Delivered','Delivery_Efficiency':'ODA_DE'},inplace=True)
merge_effeciency_area_oda.Opening = merge_effeciency_area_oda.Opening.astype(int)
merge_effeciency_area_oda.Delivered = merge_effeciency_area_oda.Delivered.astype(int)
merge_effeciency_area_oda.ODA_DE = merge_effeciency_area_oda.ODA_DE.astype(int)


# In[50]:


merge_effeciency_oda =merge_effeciency_oda[~(merge_effeciency_oda['DEST BRCD'].isin(selectdfbrcdlist))]
merge_effeciency_area_oda =merge_effeciency_area_oda[~(merge_effeciency_area_oda['Area'].isin(selectdfarealist))]


# In[51]:


oppath2=r'D:\Data\eta_rank\Delivery_Efficiency_ODA\Delivery_Efficiency_ODA_'+str(opfilevar)+'.xlsx'

with ExcelWriter(r'D:\Data\eta_rank\Delivery_Efficiency_ODA\Delivery_Efficiency_ODA_'+str(opfilevar)+'.xlsx') as writer:
    merge_effeciency_area_oda.to_excel(writer, sheet_name='AREA_WISE',engine='xlsxwriter')
    merge_effeciency_oda.to_excel(writer, sheet_name='SC_WISE',engine='xlsxwriter')


# In[ ]:


# with ExcelWriter(r'D:\Data\DE_Conwise_Stock\DE_ODA\Delivery_Efficiency_ODA_'+str(opfilevar)+'.xlsx') as writer:
#         openingstock_oda.to_excel(writer, sheet_name='OPENING_STOCK',engine='xlsxwriter')
#         deliveredstock_oda.to_excel(writer, sheet_name='DELIVERED',engine='xlsxwriter')


# In[52]:


filePath2 = oppath2

## Mail part for ODA Delivery Efficiency
# TO=["vishwas.j@spoton.co.in"]
TO = ["reports.ie@spoton.co.in"]
FROM="reports.ie@spoton.co.in"
# CC=["vishwas.j@spoton.co.in"]
CC = ["sqtf@spoton.co.in","SQ_spot@spoton.co.in","vishwas.j@spoton.co.in","abhik.mitra@spoton.co.in"]
# BCC=["vishwas.j@spoton.co.in"]
BCC = ['mahesh.reddy@spoton.co.in',"sachidanand.pandey@spoton.co.in","renugopal.l@spoton.co.in","sathya.chander@spoton.co.in","alagu.mahendran@spoton.co.in","awadhesh.kumar.mishra@spoton.co.in","sanjay.parab@spoton.co.in","ramesh.s@spoton.co.in","md.zaya@spoton.co.in","Pradyumna.Kumar@Spoton.Co.In","rajesh.mishra@spoton.co.in","raghavendra.rao@spoton.co.in","ashwani.gangwar@spoton.co.in","pramod.pandey@spoton.co.in","trilochan.panda@spoton.co.in","sunil.nakte@spoton.co.in","chandrima.banerjee@spoton.co.in", "suresh.d@spoton.co.in", "pankaj.jha@spoton.co.in","aom_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in","narendra.londhe@spoton.co.in"]
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "ODA DELIVERY EFFICIENCY" + " - " + str(opfilevar)

html3='''
<h5> For the base data, please refer the link </h5>
<p><a href= "http://spoton.co.in/downloads/OCID/OCID.xls"</a>http://spoton.co.in/downloads/OCID/OCID.xls</p></b>
'''

report=""
report+='Dear All,'
report+='<br>'
report+='PFB the ODA Delivery Efficiency of '+str(opfilevar)
report+='<br>'
report+='<br>'
report+='Delivered = '+str(deliveredcons_oda)
report+='<br>'
report+='Opening Stock = '+str(openingcons_oda)
report+='<br>'
report+='ODA DE = '+str(deliveryefficiency_oda)+ '%'
report+='<br>'
report+='<br>'+merge_effeciency_area_oda.to_html()+'<br>'
report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)


part = MIMEBase('application', "octet-stream")
part.set_payload( open(filePath2,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath2))
msg.attach(part)
    
server=smtplib.SMTP('smtp.sendgrid.net', 587)
# server=smtplib.SMTP('smtp.gmail.com', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
# server.login('vishwas.j@spoton.co.in', 'Nov@2018')
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()


# ## For TOTAL DE

# In[53]:


mergedf_area = pd.merge(efficiencyreqcols_std,merge_effeciency_area_oda, on='Area',suffixes=['_STD','_ODA'], how='outer')


# In[54]:


mergedf_area.fillna(0,inplace=True)
mergedf_area['Stock'] = mergedf_area['Total_Stock']+mergedf_area['Opening_ODA']
mergedf_area['Delivered'] = mergedf_area['Delivered_STD']+mergedf_area['Delivered_ODA']
mergedf_area['TOTAL_DE'] = pd.np.round(mergedf_area['Delivered']*100.0/mergedf_area['Stock'],0)


# In[55]:


mergedf_area = mergedf_area[['Area','Stock','Delivered','STD_DE','ODA_DE','TOTAL_DE']]


# In[56]:


mergedf_area


# In[57]:


mergedf_sc = pd.merge(merge_effeciency_std,merge_effeciency_oda, on='DEST BRCD',suffixes=['_STD','_ODA'], how='outer')


# In[58]:


mergedf_sc.fillna(0, inplace=True)


# In[59]:


mergedf_sc


# In[60]:


mergedf_sc['Total_Stock'] = mergedf_sc['DOCKNO_op']+mergedf_sc['DOCKNO_in']+mergedf_sc['DOCKNO_open']
mergedf_sc['Total_Delivered'] = mergedf_sc['DOCKNO_Delivered_STD']+mergedf_sc['DOCKNO_Delivered_ODA']
mergedf_sc['TOTAL_DE'] = pd.np.round(mergedf_sc['Total_Delivered']*100.0/mergedf_sc['Total_Stock'],0)
mergedf_sc = mergedf_sc[['DEST BRCD','Total_Stock','Total_Delivered','Delivery_Efficiency_STD','Delivery_Efficiency_ODA','TOTAL_DE']]


# In[61]:


with ExcelWriter(r'D:\Data\eta_rank\Delivery_Efficiency_Total\Total_DE.xlsx') as writer:
    efficiencyreqcols_std.to_excel(writer, sheet_name='STD',engine='xlsxwriter')
    merge_effeciency_area_oda.to_excel(writer, sheet_name='ODA',engine='xlsxwriter')
    mergedf_area.to_excel(writer, sheet_name='Total',engine='xlsxwriter')
    mergedf_sc.to_excel(writer, sheet_name='SC_WISE',engine='xlsxwriter')

oppath3=r'D:\Data\eta_rank\Delivery_Efficiency_Total\Total_DE.xlsx'

with ExcelWriter(r'D:\Data\eta_rank\Delivery_Efficiency_Total\Total_DE_'+str(opfilevar)+'.xlsx') as writer:
    efficiencyreqcols_std.to_excel(writer, sheet_name='STD',engine='xlsxwriter')
    merge_effeciency_area_oda.to_excel(writer, sheet_name='ODA',engine='xlsxwriter')
    mergedf_area.to_excel(writer, sheet_name='Total',engine='xlsxwriter')
    mergedf_sc.to_excel(writer, sheet_name='SC_WISE',engine='xlsxwriter')

oppath4 = r'D:\Data\eta_rank\Delivery_Efficiency_Total\Total_DE_'+str(opfilevar)+'.xlsx'
filePath4 = oppath4


# In[62]:


stockcons_total = mergedf_area[mergedf_area['Area']=='TOTAL']['Stock'].values[0]
totaldeliveredcons_total = mergedf_area[mergedf_area['Area']=='TOTAL']['Delivered'].values[0]
totalefficiency_total = pd.np.round((totaldeliveredcons_total*100.0)/stockcons_total,2)


# In[63]:


stockcons_total,totaldeliveredcons_total


# In[64]:


TO = ["reports.ie@spoton.co.in"]
# TO=['vishwas.j@spoton.co.in']
FROM="reports.ie@spoton.co.in"
# CC=["vishwas.j@spoton.co.in"]
CC = ["sqtf@spoton.co.in","SQ_spot@spoton.co.in","vishwas.j@spoton.co.in","abhik.mitra@spoton.co.in"]
BCC = ["shashvat.suhane@spoton.co.in","mahesh.reddy@spoton.co.in","sachidanand.pandey@spoton.co.in","renugopal.l@spoton.co.in","sathya.chander@spoton.co.in","alagu.mahendran@spoton.co.in","awadhesh.kumar.mishra@spoton.co.in","sanjay.parab@spoton.co.in","ramesh.s@spoton.co.in","md.zaya@spoton.co.in","Pradyumna.Kumar@Spoton.Co.In","rajesh.mishra@spoton.co.in","raghavendra.rao@spoton.co.in","ashwani.gangwar@spoton.co.in","pramod.pandey@spoton.co.in","trilochan.panda@spoton.co.in","sunil.nakte@spoton.co.in","chandrima.banerjee@spoton.co.in", "suresh.d@spoton.co.in", "pankaj.jha@spoton.co.in","aom_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in","narendra.londhe@spoton.co.in"]
# BCC=["vishwas.j@spoton.co.in"]
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "TOTAL DELIVERY EFFICIENCY" + " - " + str(opfilevar)

html3='''
<h5> To download the Duedate cons Undel, Please click the link below </h5>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Duedate_cons_undel.xlsx"</a>http://spoton.co.in/downloads/IEProjects/ETA/Duedate_cons_undel.xlsx</p></b>
'''

report=""
report+='Dear All,'
report+='<br>'
report+='PFB the TOTAL Delivery Efficiency of '+str(opfilevar)
report+='<br>'
report+='<br>'
report+='Total Delivered = '+str(totaldeliveredcons_total)
report+='<br>'
report+='Total Stock = '+str(stockcons_total)
report+='<br>'
report+='Total Delivery Efficiency = '+str(totalefficiency_total)+ '%'
report+='<br>'
report+='<br>'+mergedf_area.to_html()+'<br>'
report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)


part = MIMEBase('application', "octet-stream")
part.set_payload( open(filePath4,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath4))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
# server=smtplib.SMTP('smtp.gmail.com', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
# server.login('vishwas.j@spoton.co.in', 'Nov@2018')
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()

