
# coding: utf-8

# In[1]:


import pandas as pd
from datetime import datetime, timedelta
import numpy as np
from sqlalchemy import *
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template
import pyodbc


# In[6]:


# engine = create_engine("mysql+pymysql://spotonhr:spoton54321@104.199.198.197/hourlyinventory")
startdate="'"+datetime.strftime((datetime.now()-timedelta(days=1)),"%Y-%m-%d")+"'"
startdate1="'"+datetime.strftime((datetime.now()-timedelta(days=1)),"%d/%m/%Y")+"'"
enddate = "'"+datetime.strftime(datetime.now(),"%Y-%m-%d")+"'"
enddate2 = "'"+datetime.strftime(datetime.now()+timedelta(hours=24),"%Y-%m-%d")+"'"


# In[7]:


print (startdate,startdate1,enddate,enddate2)


# In[8]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=PYTHON_DB;UID=PythonOnline;PWD=P@ssw0rd123$")
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


# In[ ]:


# query = ("""
#             EXEC UBESP_PUD_ANALYSIS_OPEN_CLOSE_STOCK_ARRV_DELV_SSRS_OS
#             """)

# yestdf2=pd.read_sql(query, cnxn)


# In[9]:


# startdate="'2018-10-07'"
# enddate="'2018-10-08'"
# enddate2="'07/10/2018'"
yestdf2=pd.read_sql("SELECT * FROM destsc WHERE TimestateDate >= {0} AND TimestateDate < {1} AND [Con Stats Code]='APT' AND [Appointment Date] LIKE {2}".format(startdate,enddate,startdate1),cnxn)
print (yestdf2['Appointment Date'].unique())
# exit(0)
# In[10]:


len(yestdf2)


# In[ ]:


#yestdf2.to_csv(r'yestdf2.csv')


# In[11]:


yestdf2=yestdf2.sort_values('TimestateDate',ascending=False)


# In[12]:


yestdf2=yestdf2.drop_duplicates('DOCKNO',keep='first')


# In[13]:


len(yestdf2)


# In[14]:


doclist=yestdf2["DOCKNO"].tolist()
doclist2=tuple(str(tup) for tup in doclist)
len(doclist)


# In[32]:


enddate = datetime.strftime(datetime.now(),"%Y-%m-%d")
enddates="'"+str(enddate)+' 08:00:00'+"'"
enddate1="'"+enddate+' 09:00:00'+"'"


# In[33]:


str(enddates),str(enddate1)


# In[34]:


todaydf=pd.read_sql("SELECT * FROM destsc WHERE TimestateDate >= {0} AND TimestateDate < {1} ".format(enddates,enddate1),cnxn)


# In[35]:


len(todaydf)


# In[36]:


todaydf=todaydf[todaydf['DOCKNO'].isin(doclist)]


# In[37]:


len(todaydf)


# In[ ]:


#todaydf.to_csv(r'todaydf.csv')


# today=datetime.today().replace(hour=0,minute=0,second=0,microsecond=0)
# today

# In[38]:


#today='08/10/2018'
today = datetime.strftime(datetime.now(),"%d/%m/%Y")
today


# In[39]:


todaydf["Remarks"]=todaydf.apply(lambda x: "Rescheduled" if pd.isnull(x["Appointment Date"])==True or x["Appointment Date"]>=today else "Missed",axis=1)


# In[40]:


len(todaydf)


# In[41]:


todaydf1=todaydf[['DOCKNO',"Remarks"]]


# In[42]:


len(todaydf1)


# In[43]:


yestdf2=pd.merge(yestdf2,todaydf1,on=["DOCKNO"],how='left')


# In[44]:


len(yestdf2)


# In[45]:


yestdf2["Remarks"]=yestdf2["Remarks"].fillna("Delivered")


# In[46]:


yestdf2=yestdf2.fillna(0)


# In[47]:


perfpivot=yestdf2.loc[:,["DEST_DEPOT","Remarks","DOCKNO"]].pivot_table(index=["DEST_DEPOT"],columns=["Remarks"],aggfunc={"DOCKNO": len},margins=True)


# In[48]:


perfpivot=perfpivot.fillna(0)


# In[49]:


perfpivot


# In[50]:


try:
    perfpivot["Delivery%"]=perfpivot.apply(lambda x: np.round(x[("DOCKNO","Delivered")]*100.0/(x[("DOCKNO","All")]),1),axis=1)
except:
    pass


# In[17]:

try:
    perfpivot[("DOCKNO","Delivered")]=perfpivot[("DOCKNO","Delivered")].astype(int)
    perfpivot[("DOCKNO","All")]=perfpivot[("DOCKNO","All")].astype(int)
except:
    pass
try:
    perfpivot[("DOCKNO","Rescheduled")]=perfpivot[("DOCKNO","Rescheduled")].astype(int)
except:
    pass
try:
    perfpivot[("DOCKNO","Missed")]=perfpivot[("DOCKNO","Missed")].astype(int)
except:
    pass


# In[51]:


perfpivot


# In[ ]:


filepath1=r'APT_Cons.csv'


# In[ ]:


yestdf2.to_csv(filepath1)


# In[ ]:



from datetime import date,timedelta
todate=date.today()-timedelta(1)
today_date=datetime.strftime(todate,'%d-%m-%Y')
today_date
#vishwas.j@spoton.co.in


TO=['mahesh.reddy@spoton.co.in',"shivananda.p@spoton.co.in"]
#TO=['pawan.sharma@spoton.co.in','krishna.chandrasekar@spoton.co.in','abhik.mitra@spoton.co.in','vishwas.j@spoton.co.in','jothi.menon@spoton.co.in','sharmistha.majumdar@spoton.co.in','sq_spot@spoton.co.in','aom_spot@spoton.co.in','dom_spot@spoton.co.in','rom_spot@spoton.co.in','ganesh.m@spoton.co.in','vinit.tiwari@spoton.co.in','mani.kumar@spoton.co.in']
FROM="reports.ie@spoton.co.in"
# CC=[]
BCC=['mahesh.reddy@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
# msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = "APT Deliveries - Performance Report for yesterday" + " - " + str(today_date)


#s = Template(html).safe_substitute(mktcostperc=mktcostperc,mktcpk=mktcpk,mktspend=mktspend,mktcpky=mktcpky,mktspendy=mktspendy,date=today_date)
report=""
#report+=s
report+='<br>'
report+='<br>'+perfpivot.to_html()+'<br>'
#report+=html3
#depotpivot_std
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath1,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+BCC, msg.as_string())
server.quit()

