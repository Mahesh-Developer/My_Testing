
# coding: utf-8

# In[1]:


import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
from string import Template
import sys
reload(sys).setdefaultencoding("ISO-8859-1")
import Utilities
# In[2]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()
# In[3]:


ewbnpquery = ("""
        EXEC dbo.USP_EWAYBILL_STOCK_CONS_SQ 'NP'
        """)


ewbfull = pd.read_sql(ewbnpquery, Utilities.cnxn)

ewb_na = ewbfull[ewbfull['CURR_LOC_TYPE']=='HUB']
print (len(ewb_na))

ewb_na_sc = ewbfull[ewbfull['CURR_LOC_TYPE']=='SC']
try:
    try:
        pivot=pd.pivot_table(ewb_na,index=['CURR_BRANCHCODE'],values=['DOCKNO'],aggfunc={'DOCKNO':len})
        pivot=pivot.sort_values([('DOCKNO')],ascending=False)
        pivot=pivot.fillna(0)
        np_max_hub=pivot['DOCKNO'][0]
        np_hub_loc=pivot.index[0]
    except:
        pivot=pd.DataFrame()
        np_max_hub=0
        np_hub_loc=''

    try:
        scpivot=pd.pivot_table(ewb_na_sc,index=['CURR_AREA'],values=['DOCKNO'],aggfunc={'DOCKNO':len})
        scpivot=scpivot.sort_values([('DOCKNO')],ascending=False)
        scpivot=scpivot.fillna(0)
        np_sc_max=scpivot['DOCKNO'][0]
        np_sc_loc=scpivot.index[0]
    except:
        scpivot=pd.DataFrame()
        np_sc_max=0
        np_sc_loc=''

    #EXEC dbo.USP_EWAYBILL_STOCK_CONS_SQ 'NU'
    query2=("""EXEC dbo.USP_EWAYBILL_STOCK_CONS_SQ 'NU' """)

    notupdf=pd.read_sql(query2,Utilities.cnxn)

    hub_notdf=notupdf[notupdf['CURR_LOC_TYPE']=='HUB']

    hub_notup_pivot=pd.pivot_table(hub_notdf,index=['CURR_BRANCHCODE'],values=['DOCKNO'],aggfunc={'DOCKNO':len})

    hub_notup_pivot=hub_notup_pivot.sort_values([('DOCKNO')],ascending=False)

    hub_notup_pivot=hub_notup_pivot.fillna(0)

    nu_hub_max=hub_notup_pivot['DOCKNO'][0]

    nu_hub_loc=hub_notup_pivot.index[0]

    sc_notdf=notupdf[notupdf['CURR_LOC_TYPE']=='SC']

    sc_notup_pivot=pd.pivot_table(sc_notdf,index=['CURR_AREA'],values=['DOCKNO'],aggfunc={'DOCKNO':len})

    sc_notup_pivot=sc_notup_pivot.sort_values([('DOCKNO')],ascending=False)


    sc_notup_pivot=sc_notup_pivot.fillna(0)


    nu_sc_max=sc_notup_pivot['DOCKNO'][0]

    nu_sc_loc=sc_notup_pivot.index[0]

    query3=("""EXEC dbo.USP_EWAYBILL_STOCK_CONS_SQ 'EU'""")

    updf=pd.read_sql(query3,Utilities.cnxn)

    def getBucket(val):
        if (val<0):
            return "Expired"
        elif ((val>=0) & (val<=8)):
            return "< 8 hrs"
        elif ((val>8)&(val<=16)):
            return "8-16 hrs"
        else:
            return ">16 hrs"


    updf['Bucket']=updf['VALID_HRS'].apply(lambda x: getBucket(x))

    hubupdf=updf[updf['CURR_LOC_TYPE']=='HUB']


    hubupdf_pivot=pd.pivot_table(hubupdf,index=['CURR_BRANCHCODE'],columns=['Bucket'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True)

    hubupdf_pivot=hubupdf_pivot.sort_values([('DOCKNO','All')],ascending=False)

    hubupdf_pivot=hubupdf_pivot.fillna(0)


    hubupdf_pivot['DOCKNO']=hubupdf_pivot['DOCKNO'].astype(int)

    eu_hub_max=hubupdf_pivot[('DOCKNO','All')][1]

    eu_hub_loc=hubupdf_pivot.index[1]

    try:
        eu_expired=hubupdf_pivot[('DOCKNO','Expired')][0]
    except:
        eu_expired=0

    try:
        eu_8hrs=hubupdf_pivot[('DOCKNO','< 8 hrs')][0]
    except:
        eu_8hrs=0

    hub_clmns=[]
    for i in [('DOCKNO', 'Expired'),('DOCKNO', '< 8 hrs'),('DOCKNO', '8-16 hrs'),('DOCKNO', '>16 hrs'),('DOCKNO', 'All')]:
        if i in hubupdf_pivot.columns.tolist():
            print (i)
            hub_clmns.append(i)
        else:
            pass

    hubupdf_pivot=hubupdf_pivot[hub_clmns]

    scupdf=updf[updf['CURR_LOC_TYPE']=='SC']

    scupdf_pivot=pd.pivot_table(scupdf,index=['CURR_AREA'],columns=['Bucket'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True)

    scupdf_pivot=scupdf_pivot.sort_values([('DOCKNO','All')],ascending=False)

    scupdf_pivot=scupdf_pivot.fillna(0)

    scupdf_pivot['DOCKNO']=scupdf_pivot['DOCKNO'].astype(int)

    eu_sc_max=scupdf_pivot[('DOCKNO','All')][1]

    eu_sc_loc=scupdf_pivot.index[1]

    try:
        eu_sc_expired=scupdf_pivot[('DOCKNO','Expired')][0]
    except:
        eu_sc_expired=0
    eu_sc_expired

    try:
        eu_sc_8hrs=scupdf_pivot[('DOCKNO','< 8 hrs')][0]
    except:
        eu_sc_8hrs=0

    sc_clmns=[]
    for j in [('DOCKNO', 'Expired'),('DOCKNO', '< 8 hrs'),('DOCKNO', '8-16 hrs'),('DOCKNO', '>16 hrs'),('DOCKNO', 'All')]:
        if j in scupdf_pivot.columns.tolist():
            print (j)
            sc_clmns.append(j)
        else:
            pass

    scupdf_pivot=scupdf_pivot[sc_clmns]

    # In[63]:


    reportts = datetime.now()
    opfilevar=reportts.date()
    opfilevar1=reportts.time()
    ct2= str (opfilevar1)
    currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

    opfilevar2=pd.np.round((float(currhrs)/60),0)

    ewb_na.to_csv(r'D:\Data\Ewaybill\Stock\EWB Nt Available\Hub\EwayBill_NotAvl_Hub.csv')
    ewb_na.to_csv(r'D:\Data\Ewaybill\Stock\EWB Nt Available\Hub\EwayBill_NotAvl_Hub_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv')
    filepath1=r'D:\Data\Ewaybill\Stock\EWB Nt Available\Hub\EwayBill_NotAvl_Hub.csv'


    # ewb_na_sc.to_csv(r'D:\Data\Ewaybill\Stock\EWB Nt Available\Sc\EwayBill_NotAvl_SC.csv')
    # ewb_na_sc.to_csv(r'D:\Data\Ewaybill\Stock\EWB Nt Available\Sc\EwayBill_NotAvl_SC_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv')
    # filepath2=r'D:\Data\Ewaybill\Stock\EWB Nt Available\Sc\EwayBill_NotAvl_SC.csv'

    hub_notdf.to_csv(r'D:\Data\Ewaybill\Stock\PartB Nt Updated\Hub\EwayBill_PartB NotUpdated HUB.csv')
    hub_notdf.to_csv(r'D:\Data\Ewaybill\Stock\PartB Nt Updated\Hub\EwayBill_PartB NotUpdated HUB_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv')
    filepath3=r'D:\Data\Ewaybill\Stock\PartB Nt Updated\Hub\EwayBill_PartB NotUpdated HUB.csv'


    # sc_notdf.to_csv(r'D:\Data\Ewaybill\Stock\PartB Nt Updated\Sc\EwayBill_PartB NotUpdated SC.csv')
    # sc_notdf.to_csv(r'D:\Data\Ewaybill\Stock\PartB Nt Updated\Sc\EwayBill_PartB NotUpdated SC_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv')
    # filepath4=r'D:\Data\Ewaybill\Stock\PartB Nt Updated\Sc\EwayBill_PartB NotUpdated SC.csv'


    hubupdf.to_csv(r'D:\Data\Ewaybill\Stock\EWB Validity\Hub\Hub_EwayBill_Validity.csv')
    hubupdf.to_csv(r'D:\Data\Ewaybill\Stock\EWB Validity\Hub\Hub_EwayBill_Validity_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv')
    filepath5=r'D:\Data\Ewaybill\Stock\EWB Validity\Hub\Hub_EwayBill_Validity.csv'

    scupdf.to_csv(r'D:\Data\Ewaybill\Stock\EWB Validity\Sc\Sc_EwayBill_Validity.csv')
    scupdf.to_csv(r'D:\Data\Ewaybill\Stock\EWB Validity\Sc\Sc_EwayBill_Validity_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv')
    filepath6=r'D:\Data\Ewaybill\Stock\EWB Validity\Sc\Sc_EwayBill_Validity.csv'

    for i in [filepath1,filepath3,filepath5,filepath6]:
        import numpy as np
        import pandas as pd
        import itertools
        import json
        from pandas import ExcelWriter
        from pandas import pivot_table
        from datetime import datetime
        import os
        import ftplib
        import traceback

        oppath1=i
        #FTP Upload starts
        print ('Logging in...')
        ftp = ftplib.FTP()  
        ftp.connect('10.109.230.50')  
        print (ftp.getwelcome())
        try:  
            try:  
                ftp.login('HOSQTeam', 'Te@mH0$q')
                print ('login done')
                ftp.cwd('Auto_reports')  
                #ftp.cwd('FIFO')
                # move to the desired upload directory  
                print ("Currently in:", ftp.pwd()) 
                print ('Uploading...')  
                fullname = oppath1
                name = os.path.split(fullname)[1]  
                f = open(fullname, "rb")  
                ftp.storbinary('STOR ' + name, f)  
                f.close()  
                print ("OK"  )
                print ("Files:")  
                print (ftp.retrlines('LIST'))
            finally:  
                print ("Quitting...")
                ftp.quit()  
        except:  
            traceback.print_exc()
    # In[71]:

    #TO=['mahesh.reddy@spoton.co.in']
    #CC=['mahesh.reddy@spoton.co.in']
    #BCC=['mahesh.reddy@spoton.co.in']

    TO=["sq_spot@spoton.co.in",'hubmgr_spot@spoton.co.in','HUBEWBcontroller@spoton.co.in']
    CC=['sqtf@spoton.co.in','rajesh.kapase@spoton.co.in']
    BCC=['mahesh.reddy@spoton.co.in','shashvat.suhane@spoton.co.in','ramesh.chaturvedi@spoton.co.in','raju.meshram@spoton.co.in','Rajaram.vishwakarma@spoton.co.in']
    FROM='mis.ho@spoton.co.in'
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "Ewaybill Exception Report for Cons in Stock @ HUB -" + str(opfilevar)+"-"+str(opfilevar2)
    html3='''
    <h5> To download the cons data , Please click the link below </h5>
    <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EwayBill_NotAvl_Hub.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EwayBill_NotAvl_Hub.csv</p></b>
    '''
    report=""
    report+='Dear All,'

    report+='<br>'
    report+='Below is the exception report for all cons in stock and where Ewaybill is not available and invoice value > 50 K'
    report+='<br>'
    report+='<br>'
    report+='Pls ensure to update the correct Ewaybill No before departing from the location'
    report+='<br>'
    report+='<br>'
    report+='NOTE: Download the Attachment from the Below link'
    report+='<br>'
    report+='<br>'
    report+='Eg:- '+str(np_hub_loc)+' is having '+str(np_max_hub)+' cons in stock where Ewaybill is not available'
    report+='<br>'+pivot.to_html()+'<br>'
    report+=html3
    abc=MIMEText(report,'html')
    msg.attach(abc)

    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filepath1,"rb").read() )
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
    #msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
    server.quit()



    # In[74]:


    # TO=["dom_spot@spoton.co.in","rom_spot@spoton.co.in","sq_spot@spoton.co.in","aom_spot@spoton.co.in",'scincharge_spot@spoton.co.in']
    # CC=['sqtf@spoton.co.in','rajesh.kapase@spoton.co.in']
    # BCC=['mahesh.reddy@spoton.co.in','shashvat.suhane@spoton.co.in','vishwas.j@spoton.co.in','gireesh.kumar@spoton.co.in','ajesh.c@spoton.co.in','devakumar.d@spoton.co.in','shejeer.b@spoton.co.in']
    # FROM='reports.ie@spoton.co.in'
    # msg = MIMEMultipart()
    # msg["From"] = FROM
    # msg["To"] = ",".join(TO)
    # msg["CC"] = ",".join(CC)
    # msg["BCC"] = ",".join(BCC)
    # #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    # msg["Subject"] = "Ewaybill Exception Report for Cons in Stock @ SC -" + str(opfilevar)+"-"+str(opfilevar2)
    # html3='''
    # <h5> To download the cons data , Please click the link below </h5>
    # <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EwayBill_NotAvl_SC.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EwayBill_NotAvl_SC.csv</p></b>
    # '''
    # report=""
    # report+='Dear All,'

    # report+='<br>'
    # report+='Below is the exception report for all cons in stock and where Ewaybill is not available and invoice value > 50 K'
    # report+='<br>'
    # report+='<br>'
    # report+='Pls ensure to update the correct Ewaybill No before departing from the location'
    # report+='<br>'
    # report+='<br>'
    # report+='NOTE: Download the Attachment from the Below link'
    # report+='<br>'
    # report+='<br>'
    # report+='Eg:- '+str(np_sc_loc)+' is having '+str(np_sc_max)+' cons in stock where Ewaybill is not available'
    # report+='<br>'+scpivot.to_html()+'<br>'
    # report+=html3
    # abc=MIMEText(report,'html')
    # msg.attach(abc)

    # part = MIMEBase('application', "octet-stream")
    # part.set_payload( open(filepath2,"rb").read() )
    # encoders.encode_base64(part)
    # part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath2))
    # #msg.attach(part)
    # server=smtplib.SMTP('smtp.sendgrid.net', 587)
    # server.ehlo()
    # server.starttls()
    # server.ehlo()
    # server.login("spoton.net.in", "Star@123#")
    # #failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
    # server.quit()



    # In[78]:


    TO=["sq_spot@spoton.co.in",'hubmgr_spot@spoton.co.in','HUBEWBcontroller@spoton.co.in']
    CC=['sqtf@spoton.co.in','rajesh.kapase@spoton.co.in']
    BCC=['mahesh.reddy@spoton.co.in','shashvat.suhane@spoton.co.in','ramesh.chaturvedi@spoton.co.in','raju.meshram@spoton.co.in','Rajaram.vishwakarma@spoton.co.in']
    FROM='mis.ho@spoton.co.in'
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "Ewaybill Exception Report for Stock cons @ HUB - PartB updation is failed " + str(opfilevar)+"-"+str(opfilevar2)

    html3='''
    <h5> To download the cons data , Please click the link below </h5>
    <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EwayBill_PartB NotUpdated HUB.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EwayBill_PartB NotUpdated HUB.csv</p></b>
    '''
    report=""
    report+='Dear All,'

    report+='<br>'
    report+='Below is the exception report on stock cons, where Ewaybill is available but when it arrive to your location Part B is not updated, Pls go through the error message in the attachment why the Part B updation is not happened & correct it accordingly before departing the con from your location.'
    report+='<br>'
    report+='<br>'
    report+='NOTE: Download the Attachment from the Below link'
    report+='<br>'
    report+='<br>'
    report+='Eg:- '+str(nu_hub_loc)+' is have '+str(nu_hub_max)+' cons where Ewaybill is available but Part B is not updated from previous location.'
    report+='<br>'+hub_notup_pivot.to_html()+'<br>'
    report+=html3
    abc=MIMEText(report,'html')
    msg.attach(abc)

    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filepath3,"rb").read() )
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath3))
    #msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
    server.quit()



    # In[83]:


    # TO=["dom_spot@spoton.co.in","rom_spot@spoton.co.in","sq_spot@spoton.co.in","aom_spot@spoton.co.in",'scincharge_spot@spoton.co.in']
    # CC=['sqtf@spoton.co.in','rajesh.kapase@spoton.co.in']
    # BCC=['mahesh.reddy@spoton.co.in','shashvat.suhane@spoton.co.in','vishwas.j@spoton.co.in','gireesh.kumar@spoton.co.in','ajesh.c@spoton.co.in','devakumar.d@spoton.co.in','shejeer.b@spoton.co.in']
    # FROM='reports.ie@spoton.co.in'
    # msg = MIMEMultipart()
    # msg["From"] = FROM
    # msg["To"] = ",".join(TO)
    # msg["CC"] = ",".join(CC)
    # msg["BCC"] = ",".join(BCC)
    # #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    # msg["Subject"] = "Ewaybill Exception Report for Stock cons @ SC - PartB updation is failed " + str(opfilevar)+"-"+str(opfilevar2)

    # html3='''
    # <h5> To download the cons data , Please click the link below </h5>
    # <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EwayBill_PartB NotUpdated SC.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EwayBill_PartB NotUpdated SC.csv</p></b>
    # '''
    # report=""
    # report+='Dear All,'

    # report+='<br>'
    # report+='Below is the exception report on stock cons, where Ewaybill is available but when the con is booked/arrived from previous location Part B is not updated, Pls go through the error message in the attachment why the Part B updation is not happened & correct it accordingly before departing the con from your location.'
    # report+='<br>'
    # report+='<br>'
    # report+='NOTE: Download the Attachment from the Below link'
    # report+='<br>'
    # report+='<br>'
    # report+='Eg:- '+str(nu_sc_loc)+' is have '+str(nu_sc_max)+' cons where Ewaybill is available but Part B is not updated.'
    # report+='<br>'+sc_notup_pivot.to_html()+'<br>'
    # report+=html3
    # abc=MIMEText(report,'html')
    # msg.attach(abc)

    # part = MIMEBase('application', "octet-stream")
    # part.set_payload( open(filepath4,"rb").read() )
    # encoders.encode_base64(part)
    # part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath4))
    # #msg.attach(part)
    # server=smtplib.SMTP('smtp.sendgrid.net', 587)
    # server.ehlo()
    # server.starttls()
    # server.ehlo()
    # server.login("spoton.net.in", "Star@123#")
    # #failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
    # server.quit()



    # In[90]:


    TO=["sq_spot@spoton.co.in",'hubmgr_spot@spoton.co.in','HUBEWBcontroller@spoton.co.in']
    CC=['sqtf@spoton.co.in','rajesh.kapase@spoton.co.in','cnm@spoton.co.in']
    BCC=['mahesh.reddy@spoton.co.in','shashvat.suhane@spoton.co.in','ramesh.chaturvedi@spoton.co.in','raju.meshram@spoton.co.in','Rajaram.vishwakarma@spoton.co.in']
    FROM='mis.ho@spoton.co.in'
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "Ewaybill Validity report for Stock cons @ HUB " + str(opfilevar)+"-"+str(opfilevar2)
    html3='''
    <h5> To download the cons data , Please click the link below </h5>
    <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Hub_EwayBill_Validity.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Hub_EwayBill_Validity.csv</p></b>
    '''
    report=""
    report+='Dear All,'

    report+='<br>'
    report+='Below is the Ewaybill Validity report for the con in stock. Pls note without valid Ewaybill Con should not move out from your location'
    report+='<br>'
    report+='<br>'
    report+='Expired - Need to update the status code ( EWX) and ticket will be triggered to CS to check with customer for fresh Ewaybill.'
    report+='<br>'
    report+='<br>'
    #report+='<8 Hrs -  Need to update the status code ( EWX) and ticket will be triggered to CS to check with customer for fresh Ewaybill.'
    #report+='<br>'
    #report+='<br>'
    #report+='8 to 16 Hrs - you need to login to the GSTIN portal ( Z4) and extended the validity'
    #report+='<br>'
    report+='NOTE: Download the Attachment from the Below link'
    report+='<br>'
    report+='<br>'
    report+='Eg:- '+str(eu_expired)+' cons where Ewaybill is expired and '+str(eu_8hrs)+' cons where Ewaybill will get expired within 8 Hrs'
    report+='<br>'+hubupdf_pivot.to_html()+'<br>'
    report+=html3
    abc=MIMEText(report.encode('utf-8'),'html')
    msg.attach(abc)

    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filepath5,"rb").read() )
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath5))
    #msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
    server.quit()


    # In[93]:


    TO=["dom_spot@spoton.co.in","rom_spot@spoton.co.in","sq_spot@spoton.co.in","aom_spot@spoton.co.in",'scincharge_spot@spoton.co.in']
    CC=['sqtf@spoton.co.in','rajesh.kapase@spoton.co.in','cnm@spoton.co.in']

    BCC=['mahesh.reddy@spoton.co.in','shashvat.suhane@spoton.co.in','gireesh.kumar@spoton.co.in','ajesh.c@spoton.co.in','devakumar.d@spoton.co.in','shejeer.b@spoton.co.in']
    FROM='mis.ho@spoton.co.in'
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "Ewaybill Validity report for Stock cons @ SC " + str(opfilevar)+"-"+str(opfilevar2)

    html3='''
    <h5> To download the cons data , Please click the link below </h5>
    <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Sc_EwayBill_Validity.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Sc_EwayBill_Validity.csv</p></b>
    '''

    report=""
    report+='Dear All,'

    report+='<br>'
    report+='Below is the Ewaybill Validity report for the con in stock. Pls note without valid Ewaybill Con should not move out from your location'
    report+='<br>'
    report+='<br>'
    report+='Expired - Need to update the status code ( EWX) and ticket will be triggered to CS to check with customer for fresh Ewaybill.'
    report+='<br>'
    report+='<br>'
    #report+='<8 Hrs -  Need to update the status code ( EWX) and ticket will be triggered to CS to check with customer for fresh Ewaybill.'
    #report+='<br>'
    #report+='<br>'
    #report+='8 to 16 Hrs - you need to login to the GSTIN portal ( Z4) and extended the validity'
    #report+='<br>'
    #report+='<br>'
    #report+='>16 Hrs - Check for next destination & if the Ewaybill is getting expired before reaching the destination extend the validity for that also'
    #report+='<br>'
    #report+='<br>'
    report+='NOTE: Download the Attachment from the Below link'
    report+='<br>'
    report+='<br>'
    report+='Eg:- '+str(eu_sc_expired)+' cons where Ewaybill is expired and '+str(eu_sc_8hrs)+' cons where Ewaybill will get expired within 8 Hrs'
    report+='<br>'+scupdf_pivot.to_html()+'<br>'
    report+=html3
    abc=MIMEText(report.encode('utf-8'),'html')
    msg.attach(abc)

    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filepath6,"rb").read() )
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath6))
    #msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
    server.quit()

except:
    TO=['mahesh.reddy@spoton.co.in','shivananda.p@spoton.co.in']
    FROM='mis.ho@spoton.co.in'
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    #msg["CC"] = ",".join(CC)
    #msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "ERROR Report" 
    report=""
    report+='Hi,'

    report+='<br>'
    report+='There was some error in Eway Bill Stock and Validity Report'
    report+='<br>'
    
    abc=MIMEText(report.encode('utf-8'),'html')
    msg.attach(abc)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO, msg.as_string())
    server.quit()
