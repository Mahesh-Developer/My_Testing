
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta,datetime
import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta,datetime
import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
from pandas import ExcelWriter
import os
import smtplib
import Utilities
import ftplib
import traceback
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
# In[2]:


#C:\Users\S2769MAH\Downloads\PMD\spoton.co.in\downloads\PMD\PMD.csv
#pmd_df=pd.read_csv(r'http://spoton.co.in/downloads/PMD/PMD.csv')
#pmd_df=pd.read_csv(r'http://spoton.co.in/downloads/PUD_MTD_REPORT.zip')
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()


# query=("""SELECT CASE WHEN PUDTYPE = 'ADHOC'   

#                           AND (( A.MKT_SBA_APPLICABLE = 'Y'   

#                                 OR A.MKT_HIRE_REASON = 'DEDICATED FOR SINGLE CUSTOMER'   

#                                 OR A.MKT_HIRE_REASON = 'NSL SHIPMENT'   

#                                 OR A.MKT_HIRE_REASON = 'LATE NIGHT/EARLY MORNING'   

#                               )   

#                           OR ( A.SENDERCODE = '000119837'    

#                                OR A.SENDERCODE = '000118040'   

#                                OR A.SENDERCODE = '000118041'   

#                                OR A.SENDERCODE = '000119721'   

#                                OR A.SENDERCODE = '000120083'   

#                              )) THEN 'ADHOC-Special'   

#                      ELSE PUDTYPE   

#                 END PUDTYPE_STATUS ,a.* FROM dbo.tblPUDYestMtdData  a  WITH (NOLOCK)""")

#try:
query=("""EXEC USP_PUD_YEST_MTD_DATA 'M' """)

print ('yes')
#df=pd.read_sql(query,Utilities.cnxn)
pmd_df=pd.read_sql(query,Utilities.cnxn)
pmd_df=pmd_df[pmd_df['PTYPE']!='AR']
print (len(pmd_df))
# exit(0)
m = {'Jan': '01','Feb': '02','Mar': '03','Apr':'04','May':'05','Jun':'06','Jul':'07','Aug':'08','Sep':'09','Oct':'10','Nov':'11','Dec':'12'}


# In[7]:

def dateconv(date):
    dt = date.split(' ')[2]+'-'+str(m.get(date.split(' ')[1]))+'-'+date.split(' ')[0]
    #print (dt)
    return dt


# In[8]:

pmd_df["DateOnly"]=pmd_df.apply(lambda x: dateconv(x["DATE"]),axis=1)

pmd_df.to_csv(r'D:\Data\PMD_Save\PMD.csv')
# exit(0)
fullname=r'D:\Data\PMD_Save\PMD.csv'
print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = fullname
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()


to_date=date.today()-timedelta(1)
yest_date=datetime.strftime(to_date,'%Y-%m-%d')
yest_date
print (pmd_df.columns)
print (len(pmd_df))
# In[3]:


#print len('pmd_df',pmd_df)


# In[4]:


def dateconv(date):
    # val=date.split(' ')
    # date1=val[0]+'-'+val[1]+'-'+val[2]
    try:
        dt = datetime.strftime(date, '%Y-%m-%d')
        return dt
    except:
        pass


# In[5]:


#pmd_df["DATE2"]=pmd_df.apply(lambda x: dateconv(x["DATE"]),axis=1)


# In[6]:


pud_list=['SME','STD']


# In[7]:


def getPudType(pudtype):
    if pudtype in pud_list:
        return "STD_SME"
    else:
        return pudtype


# In[8]:


pmd_df['PUDTYPES']=pmd_df.apply(lambda x:getPudType(x['PUDTYPE']),axis=1)


# In[9]:


pmd_df["ACT_WT"]=pmd_df["ACT_WT"].astype(float)
pmd_df["COST"]=pmd_df["COST"].astype(float)

## getting previous month pmd
today=date.today()
firstday=today.replace(day=1)

lastmnth_lastdate1=firstday-timedelta(1)
lastmnth_lastdate2=firstday-timedelta(2)
lastmnth_lastdate1

lastdate1=datetime.strftime(lastmnth_lastdate1,"%Y-%m-%d")
lastdate2=datetime.strftime(lastmnth_lastdate2,"%Y-%m-%d")

print (lastdate1,lastdate2)



try:
    previous_df=pd.read_csv(r'D:\Data\PMD_Save\PMD_'+str('2019-07-31')+'.csv')
    print ('D:\Data\PMD_Save\PMD_'+str(lastdate1)+'.csv')
except:
    import smtplib
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    # from email.MIMEBase import MIMEBase
    # from email import Encoders
    from email.mime.base import MIMEBase
    from email import encoders
    import os
    from string import Template
    #vishwas.j@spoton.co.in
    FROM='mahesh.reddy@spoton.co.in'
    TO=['mahesh.reddy@spoton.co.in']
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["Subject"] = "Error Report" + " - " + str(yest_date)
    html='''<html>
    <h4>Hi,</h4>
    <p></p>
    </html>'''
    report=""
    report+='<br>'
    report+='There was error in Monitoring Report Last month file not avaliable'
    report+='<br>'
    abc=MIMEText(report,'html')
    msg.attach(abc)
    
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO, msg.as_string())
    server.quit()



#previous month operations starts from here
#previous_df=pd.read_csv(r'D:\Data\PMD_Save\PMD_2018-01-31.csv')
#previous_df=pd.read_csv(r'D:\Data\PMD_Save\PMD_2018-05-31.csv')
#try:
 #   previous_df=pd.read_csv(r'D:\Data\PMD_Save\PMD_'+str(lastdate1)+'.csv')
 #   print ('D:\Data\PMD_Save\PMD_'+str(lastdate1)+'.csv')
#except:
    #previous_df=pd.read_csv(r'D:\Data\PMD_Save\PMD_'+str(lastdate2)+'.csv')
    #print ('D:\Data\PMD_Save\PMD_'+str(lastdate2)+'.csv')
# In[10]:
print (len(previous_df))
previous_df.rename(columns={'PUDTYPE2':'PUDTYPE','COST2':'COST','DATE2':'DATE','TYP2':'TYP','ACT_WT2':'ACT_WT'},inplace=True)

previous_df['PUDTYPES']=previous_df.apply(lambda x:getPudType(x['PUDTYPE']),axis=1)
pivot_previous_df=pd.pivot_table(previous_df,index=['PUDTYPES'],values=['ACT_WT','COST'],aggfunc={'ACT_WT':sum,'COST':sum},margins=True)
g=[]
for i in range(0,len(pivot_previous_df)):
    g.append(pivot_previous_df['ACT_WT'][i]*100.0/pivot_previous_df['ACT_WT'].values[-1])


# In[12]:


se1 = pd.Series(g)
pivot_previous_df['ACT_WT%'] = se1.values
pivot_previous_df1=pivot_previous_df.reset_index()




pivot_pmd_df=pd.pivot_table(pmd_df,index=['PUDTYPES'],values=['ACT_WT','COST'],aggfunc={'ACT_WT':sum,'COST':sum},margins=True)


# In[11]:


l=[]
for i in range(0,len(pivot_pmd_df)):
    l.append(pivot_pmd_df['ACT_WT'][i]*100.0/pivot_pmd_df['ACT_WT'].values[-1])


# In[12]:


se = pd.Series(l)
pivot_pmd_df['ACT_WT%'] = se.values


# In[13]:


pivot_pmd_df['CPKG']=pd.np.round(pivot_pmd_df['COST']/pivot_pmd_df['ACT_WT'],3)
pivot_pmd_df['COST'] = pivot_pmd_df['COST'].apply(lambda x: '{:.2f}'.format(x))
pivot_pmd_df['ACT_WT'] = pivot_pmd_df['ACT_WT'].apply(lambda x: '{:.2f}'.format(x))
print (pivot_pmd_df)

# In[14]:


pivot_pmd_df=pivot_pmd_df.replace([np.inf,-np.inf],np.nan)


# In[15]:


pivot_pmd_df=pivot_pmd_df.fillna(0)

# In[16]:


pivot_pmd_df


# In[17]:



#pivot_pmd_df1=pd.np.round(pivot_pmd_df,2)


# In[18]:





# In[19]:


pivot_pmd_df1=pivot_pmd_df.reset_index()


# In[20]:


pivot_pmd_df1


# In[21]:




to_date=date.today()-timedelta(1)
to_date1=date.today()-timedelta(2)
yest_date3=datetime.strftime(to_date,'%Y-%m-%d ')+'00:00:00'
yest_date4=datetime.strftime(to_date,'%Y-%m-%d ')+'23:59:00'
yest_date1=datetime.strftime(to_date1,'%Y-%m-%d')
print (yest_date,yest_date1)
# In[22]:


# yest_pmd_df=pmd_df[pmd_df['DATE']==yest_date]
# query1=("""SELECT * FROM dbo.tblPUDYestMtdData WHERE DATE BETWEEN '{0}' AND '{1}'""".format(yest_date3,yest_date4))
# print (query1)
# yest_pmd_df=pd.read_sql(query1,cnxn)
yest_pmd_df=pmd_df[pmd_df['DateOnly']==yest_date]
print ('length of Yesterday data ',len(yest_pmd_df))
#yest_pmd_df=pmd_df[pmd_df['DATE2']=='2018-01-25']
#yest_pmd_df['PUDTYPES']=yest_pmd_df.apply(lambda x:getPudType(x['PUDTYPE']),axis=1)

# In[23]:


print len(yest_pmd_df)


# In[24]:


pivot_yest_pmd_df=pd.pivot_table(yest_pmd_df,index=['PUDTYPES'],values=['ACT_WT','COST'],aggfunc={'ACT_WT':sum,'COST':sum},margins=True)
print ('pivot_yest_pmd_df',pivot_yest_pmd_df)


# In[25]:


y=[]
for i in range(0,len(pivot_yest_pmd_df)):
    y.append(pivot_yest_pmd_df['ACT_WT'][i]*100.0/pivot_yest_pmd_df['ACT_WT'].values[-1])
#     pivot_pmd_df['opp']=pivot_pmd_df['ACT_WT2'][i]*100.0/pivot_pmd_df['ACT_WT2'][6]


# In[26]:


se = pd.Series(y)
pivot_yest_pmd_df['ACT_WT%'] = se.values
pivot_yest_pmd_df['CPKG']=pivot_yest_pmd_df['COST']/pivot_yest_pmd_df['ACT_WT']
print (pivot_yest_pmd_df)
pivot_yest_pmd_df.to_csv(r'C:\Users\rajeeshv\Downloads\pivot_yest_pmd_df.csv')

# In[27]:


pivot_yest_pmd_df=pivot_yest_pmd_df.replace([np.inf,-np.inf],np.nan)


# In[28]:


pivot_yest_pmd_df=pivot_yest_pmd_df.fillna(0)


# In[29]:


#pivot_yest_pmd_df1=pd.np.round(pivot_yest_pmd_df,2)


# In[30]:





# In[31]:


pivot_yest_pmd_df1=pivot_yest_pmd_df.reset_index()


# In[32]:


pivot_yest_pmd_df1


# In[33]:


pivot_mtd_yest_df=pd.merge(pivot_pmd_df1,pivot_yest_pmd_df1,on=['PUDTYPES'],suffixes=('-MTD','-YST'))


# In[34]:


# pivot_mtd_yest_df1=pivot_mtd_yest_df[['PUDTYPE2','ACT_WT2-MTD','ACT_WT2%-MTD','ACT_WT2-YST','ACT_WT2%-YST']]


# In[35]:


pivot_mtd_yest_df.rename(columns={'ACT_WT-MTD':'Wt(MTD)','COST-MTD':'COST(MTD)','ACT_WT%-MTD':'Wt%(MTD)','CPKG-MTD':'CPK(MTD)','ACT_WT-YST':'Wt(YST)','COST-YST':'COST(YST)','ACT_WT%-YST':'Wt%(YST)','CPKG-YST':'CPK(YST)'},inplace=True)


# In[36]:


pivot_mtd_yest_df


# In[37]:


# data_mtd = {'PUDTYPES': ['All', 'STD_SME', 'ODA' ,'ADHOC','AD','FIXED', 'COUNTER'],
#          'CPK': [cpkmtd,stdsmecpk_mtd, odadfcpk_mtd, mktdfcpk_mtd, fixdfcpk_mtd, ctndfcpk_mtd],
#          '%WT': [peractwtmtd, stdsmewt_mtd, odadfwt_mtd, mktdfwt_mtd, fixdfwt_mtd, ctndfwt_mtd],
#          'Target_CPK': [0.99,0.79, 3.40, 2.00, 1.40, 0],
#          'Target_%WT': ['100.00', '83.50', '5.90', '5.10', '2.00', '3.50']}


# In[38]:


cst_pmd_df=pd.read_excel(r'C:\Users\rajeeshv\Downloads\Rajesh\mahesh\pmd_wt_cst_file.xlsx')


# In[39]:


cst_pmd_df


# In[40]:


final_data_df=pd.merge(pivot_mtd_yest_df,cst_pmd_df,on=['PUDTYPES'])


# In[41]:


final_data_df


# In[42]:
mnth=date.today()-timedelta(30)
current_mnth=datetime.strftime(lastmnth_lastdate1,'%b')
print (current_mnth)



yest_summary_df=final_data_df[['PUDTYPES','Wt%(YST)','CPK(YST)']]
mtd_summary_df=final_data_df[['PUDTYPES','CPK(MTD)','Wt%(MTD)','Target_Wt','Target_Cpk']]
print (mtd_summary_df)
print (pivot_previous_df1)
print ('*************')
mtd_summary_df=pd.merge(mtd_summary_df,pivot_previous_df1,on='PUDTYPES',suffixes=('_YST','_'+current_mnth),how='outer')
# In[43]:
print (mtd_summary_df)

yest_summary_df.rename(columns={'Wt%(YST)':'WT%','CPK(YST)':'CPK'},inplace=True)
# yest_summary_df['WT%-'+current_mnth]=pd.np.round(yest_summary_df['WT%-'+current_mnth],2)
mtd_summary_df.rename(columns={'CPK(MTD)':'CPK','Wt%(MTD)':'WT%','ACT_WT%':'WT%-'+current_mnth},inplace=True)
print (mtd_summary_df.columns)
mtd_summary_df=mtd_summary_df[['PUDTYPES','CPK','WT%','Target_Wt','Target_Cpk','WT%-'+current_mnth]]
mtd_summary_df['WT%']=pd.np.round(mtd_summary_df['WT%'],2)
mtd_summary_df['WT%-'+current_mnth]=pd.np.round(mtd_summary_df['WT%-'+current_mnth],2)
yest_summary_df['WT%']=pd.np.round(yest_summary_df['WT%'],2)
yest_summary_df['CPK']=pd.np.round(yest_summary_df['CPK'],3)
mtd_summary_df=mtd_summary_df.fillna('-')
print (yest_summary_df)
print (mtd_summary_df)

# In[47]:


d=date.today()
to_date=datetime.strftime(d,'%d-%m-%Y')
to_date

# In[44]:


from pandas import ExcelWriter
with ExcelWriter(r'D:\Data\Updated Monitoring report\Monitoring_Report_'+str(to_date)+'.xlsx') as writer:
    yest_summary_df.to_excel(writer,engine='xlsxwriter',sheet_name='Yesterday_Summary')
    mtd_summary_df.to_excel(writer,engine='xlsxwriter',sheet_name='MTD_Summary')
    final_data_df.to_excel(writer,engine='xlsxwriter',sheet_name='Summary')


# In[45]:


filePath=r'D:\Data\Updated Monitoring report\Monitoring_Report_'+str(to_date)+'.xlsx'


# In[46]:
# print (yest_summary_df)
# print (mtd_summary_df)


from string import Template

# TO=["vishwas.j@spoton.co.in","mahesh.reddy@spoton.co.in"]
TO=["abhik.mitra@spoton.co.in","krishna.chandrasekar@spoton.co.in","Anto.Paul@Spoton.Co.In","t.devakumar@spoton.co.in"]
CC= ["mahesh.reddy@spoton.co.in","goutam.barik@spoton.co.in","Anto.Paul@Spoton.Co.In"]
# CC=["mahesh.reddy@spoton.co.in"]
FROM="mahesh.reddy@spoton.co.in"

msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "Surface - Monitoring Report" + " - " + str(yest_date)
html='''<html>
<h4>Dear All,</h4>
<p>PFA the Monitoring Report for $date</p>
</html>'''
s = Template(html).safe_substitute(date=yest_date)
report=""
report+=s
report+='<br>'
report+='PFB yesterday Summary'
report+='<br>'+yest_summary_df.to_html()+'<br>'
report+='<br>'
report+='PFB MTD summary'
report+='<br>'+mtd_summary_df.to_html()+'<br>'
report+='<br>'
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filePath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
msg.attach(part)
# server=smtplib.SMTP('smtp.sendgrid.net', 587)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("spoton.net.in", "Star@123#")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()


# except:
#   TO=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
#   FROM="mahesh.reddy@spoton.co.in"
#   msg = MIMEMultipart()
#   msg["From"] = FROM
#   msg["To"] = ",".join(TO)
#   #msg["CC"] = ",".join(CC)
#   #msg["BCC"] = ",".join(BCC)
#   #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
#   msg["Subject"] = "ERROR Report" 
#   report=""
#   report+='Hi,'

#   report+='<br>'
#   report+='There was some error in Monitoring Report.'
#   report+='<br>'
  
#   abc=MIMEText(report.encode('utf-8'),'html')
#   msg.attach(abc)
#   server=smtplib.SMTP('smtp.sendgrid.net', 587)
#   server.ehlo()
#   server.starttls()
#   server.ehlo()
#   server.login("spoton.net.in", "Star@123#")
#   failed = server.sendmail(FROM, TO, msg.as_string())
#   server.quit()


