
# coding: utf-8

# In[1]:

import pandas as pd
from datetime import datetime, timedelta


# In[22]:

dieselvar = -2.01  #Update from variance from Prasanna -indicates net impact diesel price dropped


# In[2]:

pmdlh30 = pd.read_excel('http://spoton.co.in/downloads/PMDLH/PMDLH_30DAYS.xls')


# In[3]:

pmdlh = pd.read_excel('http://spoton.co.in/downloads/PMDLH/PMDLH.xls')


# In[4]:

kms = pd.read_excel('km_mileage.xlsx', 'Kms')
mileage = pd.read_excel('km_mileage.xlsx', 'Mileage')


# In[5]:

pmdlh30mkt = pmdlh30[pmdlh30['ROUTE CODE']=='9888']


# In[6]:

len(pmdlh30mkt), len(pmdlh30)


# In[7]:

pmdlh30grp = pmdlh30mkt.groupby(['ROUTE NAME','VEHICLE PAYLOAD']).agg({'THC NUMBER':len,'COST':sum}).reset_index()


# In[8]:

pmdlh30grp['AvgCost'] = pmdlh30grp.apply(lambda x: x['COST']/x['THC NUMBER'], axis=1)


# In[9]:

pmdlh30grp.head(2)


# In[10]:

len(pmdlh30grp)


# In[11]:

pmdlh30grp = pd.merge(pmdlh30grp, kms, on=['ROUTE NAME'], how='left')
pmdlh30grp = pd.merge(pmdlh30grp, mileage, on=['VEHICLE PAYLOAD'], how='left')


# In[12]:

pmdlh30grp.head(5)


# In[14]:

pmdlh30grp['Kms'].fillna(0, inplace=True)
pmdlh30grp.head(5)


# In[15]:

pmdlh30grp =pmdlh30grp.rename(columns={'THC NUMBER':'THCCount', 'COST':'COST30days'}) 


# In[23]:

pmdlh30grp['AdjCost'] = pmdlh30grp.apply(lambda x: pd.np.round(x['AvgCost']+(x['Kms']/x['Mileage'])*dieselvar, 0), axis=1)


# In[24]:

pmdlh30grp.head(2)


# In[25]:

import datetime
datefilter=(datetime.datetime.today()-timedelta(hours=24)).date()
date_ll = datetime.datetime.combine(datefilter, datetime.time(9,1))


# In[26]:

pmdlhmkt = pmdlh[(pmdlh['THC DATE']>=date_ll) & (pmdlh['ROUTE CODE']=='9888')]


# In[27]:

df = pd.merge(pmdlh30grp, pmdlhmkt, on=['ROUTE NAME','VEHICLE PAYLOAD'], how='inner')


# In[29]:

df['%diff'] = df.apply(lambda x: pd.np.round((x['COST']*1.0/x['AdjCost']-1)*100,0) , axis=1)


# In[30]:

df['ActDiff'] = df.apply(lambda x: x['COST']-x['AdjCost'] , axis=1)


# In[31]:

df['Remarks'] = df.apply(lambda x: 'Exception' if (x['%diff']>=5 and x['ActDiff']>=10000) else 'Normal', axis=1)


# In[32]:

df.to_csv('df.csv') #alldf save a link


# In[33]:

exc_df = df[df['Remarks']=='Exception']
exc_df.to_csv('Market_Exception.csv') #attachment


# In[34]:

if len(exc_df)>0:
    maildf = exc_df[['ROUTE NAME', 'VEHICLE PAYLOAD', 'AdjCost', 'THC NUMBER', 'COST']]
else:
    maildf = 'There is no market vehicle used with 5% increase in cost and more than Rs 10000'


# In[35]:

maildf #mailbody


# In[ ]:



