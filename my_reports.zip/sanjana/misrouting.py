import ast
import pandas as pd
from datetime import datetime, timedelta
from itertools import permutations
import numpy as np
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import Utilities
pd.set_option('display.max_columns',100)
# df=pd.read_csv(r'http://spoton.co.in/downloads/IEP_CON_THC_DATA_DAILY/IEP_CON_THC_DATA_DAILY.csv')
#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.87;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
#cursor = cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()

query = ("""EXEC USP_CON_THC_DAILY_DATA """)
print (query)
df = pd.read_sql(query, Utilities.cnxn)
print (df.head())

df.to_csv(r'Misrouting.csv')
df.rename(columns={'Con No':'Con_No','TC Dest':'TC_Dest','TC Source':'TC_Source','THC Transaction Date':'THC_Transaction_Date','THC Date':'THC_Date','TC Date':'TC_Date'},inplace=True)
for i in ["Pickupdate","DueDate","THC_Transaction_Date","THC_Date","TC_Date"]:
    df[i]=pd.to_datetime(df[i],format="%d/%m/%Y %H:%M")
dfyest=df[(df["TC_Date"]>=((datetime.today()).replace(hour=9,minute=0,second=0,microsecond=0)-timedelta(days=1)))&(df["TC_Date"]<=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)))]
import pickle
try:
    pkl_file = open(r'D:\Path Dict\path_dict.pkl', 'rb')
except:
    pkl_file = open(r'D:\Path Dict\path_dict.pkl', 'rb')
path_dict = pickle.load(pkl_file)
pkl_file.close()
dfyest=dfyest.loc[:,["TC_Source","TC_Dest","Destn","Act_Wt","Con_No"]]
dfyest["Resid_Path"]=dfyest.apply(lambda x: path_dict.get((x['TC_Source'],x['Destn'])),axis=1)
dfyest=dfyest[dfyest["Resid_Path"].notnull()]
dfyest["NextLoc"]=dfyest["Resid_Path"].map(lambda x: x[0][1])
dfyest["error"]=dfyest["TC_Dest"]!=dfyest["NextLoc"]
errordf=dfyest[dfyest["error"]==True]
errordf["Resid_Path2"]=errordf["Resid_Path"].astype(str)
errordfpivot=errordf.pivot_table(index=["TC_Source","TC_Dest","Destn","NextLoc","Resid_Path2"],aggfunc={"Act_Wt":np.sum,"Con_No":len}).reset_index().sort_values("Act_Wt",ascending=False)
finaldf=errordfpivot[errordfpivot["Act_Wt"]>=750]
finaldf=finaldf[finaldf["Resid_Path2"].str.len()>18] #More than 2 in resid path
finaldf["Resid_Path2"]=finaldf["Resid_Path2"].map(lambda x: ast.literal_eval(x)[0])
finaldf["inpath"]=finaldf.apply(lambda x: x["TC_Dest"] in (x["Resid_Path2"]),axis=1)
finaldf=finaldf[finaldf['inpath']==False]
finaldf["chartest"]=finaldf.apply(lambda x: x["TC_Dest"][0:3]==x["NextLoc"][0:3],axis=1)
finaldf=finaldf[finaldf['chartest']==False]
opttuples=[("BLRH","VZAH","HYDH"),("BLRH","HYDH","VZAH"),("DELH","AMDH","BOMH"),("AMDH","DELH","BOMH"),("DELH","AMCH","LUHB"),("DELH","LUHB","AMCH"),("DELH","JAIH","AMDH"),("DELH","AMDH","JAIH"),("AMDH","PNQH","BOMH"),("DELH","IXCB","AMCH"),("DELH","JAIH","UDRF"),("KNPH","GOPF","LKOH"),("DELH","BRGH","CCUH"),("BOMH","BRGH","CCUH"),("BLRH","BRGH","CCUH"),("MAAH","BRGH","CCUH"),("IDRH","AMDH","BOMH"),("DELH","IDRH","HYDH"),("MRDF","GZBH","DELH"),("RPRH","NAGH","IDRH"),("KNPH","GZBH","AGRB"),("MRDF","GZBH","KNPH"),("DELH","GZBH","AGRB"),("IXUB","PNQH","SNRH"),("CCUH","PNQH","BOMH"),("BDQH","PNQH","BOMH"),("IDRH","KNPH","DELH"),("BRGH","PNQH","NAGH"),("PYDF","HYDH","VZAH"),("HTRF","GZBH","AGRB"),("DELH","IXRB","IXWB"),("DELH","IXWB","IXRB"),("BOMH","SXVF","CJBH"),("BOMH","CJBH","SXVF"),("PNQH","SXVF","CJBH"),("BOMH","CJBH","SXVF"),("DELH","KNPH","LKOH"),("CCUH","DELH","KNPH"),("PATH","BRGH","GAUH")]
for i in opttuples:
   finaldf=finaldf[~((finaldf["TC_Source"]==i[0])&(finaldf["TC_Dest"]==i[1])&(finaldf["NextLoc"]==i[2]))]

optrouting=["SPTFBLRH","BLRHSPTF","JAIHALWF","ALWFJAIH"]
finaldf["Optkey"]=finaldf["TC_Source"]+finaldf["Destn"]
finaldf=finaldf[~finaldf["Optkey"].isin(optrouting)]
pd.set_option('display.max_columns',40)
from sqlalchemy import *
engine = create_engine("mysql+pymysql://spotonhr:spoton54321@104.199.198.197/LH30days")
startdate=datetime.strftime(datetime.now()-timedelta(days=2),"%Y-%m-%d")
lhdf = pd.read_sql("SELECT * FROM LH30days WHERE `THC DATE` >='{}'".format(startdate),engine)
lhdf=lhdf[~(lhdf["Vech Type"].isin(['DATAVECHILE','VIRTUALHUB']))]
lhdf["Util%"] = lhdf.apply(lambda x: round(x["TOTAL ACTUAL LOAD"]*100.0/x["VEHICLE PAYLOAD"],1),axis=1)
lhdf["Vol Util%"] = lhdf.apply(lambda x: round(x["TOTAL VOL WEIGHT"]*100.0/x["VEHICLE PAYLOAD"],1),axis=1)
dfyest=lhdf[(lhdf["THC DATE"]>=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)-timedelta(days=1)))&(lhdf["THC DATE"]<=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)))]
dfyest["ROUTE NAME"]=dfyest["ROUTE NAME"].str.replace(" ","")
dfyest["Route Details"]=dfyest["ROUTE NAME"].str.split("-")
utildf=dfyest.loc[:,["Route Details","Util%","Vol Util%"]]
finaldf["Util%"]=finaldf.apply(lambda x: round(utildf[utildf["Route Details"].astype(str).str.contains(".*"+x["TC_Source"]+".*"+x["NextLoc"]+".*",regex=True)]["Util%"].mean(),1),axis=1)
df = pd.read_csv(r'http://www.spoton.co.in/downloads/PMD_TC_LINEHAUL_DATA/PMDTCLH.csv')
df["THC_DATE"]=pd.to_datetime(df["THC_DATE"])
df["TC_DATE"]=pd.to_datetime(df["TC_DATE"])
df=df[df["ROUTE_CODE"]!="9888"]
df=df[(df["THC_DATE"]>=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)-timedelta(days=1)))&(df["THC_DATE"]<=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)))]
from sqlalchemy import *
dfschedule = pd.read_sql("SELECT * FROM schedule",con=create_engine("mysql+pymysql://root:iep321@104.199.198.197/schedule"))
getkmdict = {} #2. Stored in Dict
for ele in zip(dfschedule['Origin'],dfschedule['Destination'],dfschedule['Transit Distance']):
   getkmdict.update({(ele[0],ele[1]):ele[2]})
dfschedule=dfschedule[dfschedule["Origin"]==dfschedule["Route Details"].str[0:4]]
dfschedule["Routelist"]=dfschedule.apply(lambda x: x["Route Details"].split("-"),axis=1)
dfschedule["OD Routelist"] = dfschedule.apply(lambda x: [[i[0],i[1]] for i in permutations(x['Routelist'],2) if x['Routelist'].index(i[0])<x['Routelist'].index(i[1])],axis=1)
def getkms(odroutelist,routelist): #3. Adding transit time column - function adds tt for touching OD combos as well (unlike ttdict)
   odpathlist=[]
   kms=0.0
   for i in range(routelist.index(odroutelist[0]),(routelist.index(odroutelist[1]))):
       odpathlist = odpathlist+[(routelist[i],routelist[i+1])]
   for i in odpathlist:
       if getkmdict.get((i[0],i[1]))!=None:
           kms = kms+float(str(getkmdict.get((i[0],i[1]))))
       else:
           kms=kms
   return kms

def getkmslist(odroutelist,routelist):
   kmlist=[]
   for i in odroutelist:
       kmlist=kmlist+[getkms(i,routelist)]
   return kmlist

dfschedule["od kms"]=dfschedule.apply(lambda x: getkmslist(x["OD Routelist"],x["Routelist"]),axis=1)
dfschedule=dfschedule.loc[:,["OD Routelist","od kms"]]
dfschedule['stackcol']=dfschedule.apply(lambda x: tuple([x["OD Routelist"][i],x["od kms"][i]] for i in range(len(x["od kms"]))),axis=1)

tcdfschedule=dfschedule['stackcol'].apply(pd.Series).stack().reset_index(level=1, drop=True).to_frame('stackcol')#.join(dfschedule[['user']], how='left')
tcdfschedule["TC_BR"]=tcdfschedule.apply(lambda x: x["stackcol"][0][0],axis=1)
tcdfschedule["TC_TOBRCODE"]=tcdfschedule.apply(lambda x: x["stackcol"][0][1],axis=1)
tcdfschedule["kms"]=tcdfschedule.apply(lambda x: x["stackcol"][1],axis=1)
tcdfschedule=tcdfschedule.groupby(['TC_BR','TC_TOBRCODE']).mean()['kms'].reset_index()
df2=df.merge(tcdfschedule,on=["TC_BR","TC_TOBRCODE"],how="left")
df2["kmsweight"]=df2["kms"]*df2["TOTAL_ACTUAL_LOAD"]
df3=df2.pivot_table(index=["THC_NUMBER","ROUTE_CODE","ROUTE_NAME","NEW_PATH"],aggfunc={"kmsweight":np.sum,"VEHICLE_PAYLOAD":np.mean}).reset_index()
df4=df3[df3["VEHICLE_PAYLOAD"]>500]
dfkms = pd.read_sql("SELECT * FROM schedule",con=create_engine("mysql+pymysql://root:iep321@104.199.198.197/schedule"))
dfkms=dfkms.pivot_table(index="Route Code",aggfunc={"Transit Distance":np.sum}).reset_index()
dfkms=dfkms.rename_axis({'Route Code':'ROUTE_CODE',"Transit Distance":"Total Kms"},axis=1)
df5=df4.merge(dfkms,on="ROUTE_CODE",how='left')
df5["WtdWt"]=np.round(df5["kmsweight"]/df5["Total Kms"])
df5["WtdUtil"]=np.round(df5["WtdWt"]*100.0/df5["VEHICLE_PAYLOAD"],1)
df6=df5.pivot_table(index=["ROUTE_CODE","ROUTE_NAME"],aggfunc={'VEHICLE_PAYLOAD':np.mean,'WtdUtil':np.mean}).reset_index().sort_values("WtdUtil",ascending=True)
finaldf["WtdUtil%"]=finaldf.apply(lambda x: round(df6[df6["ROUTE_NAME"].astype(str).str.contains(".*"+x["TC_Source"]+".*"+x["NextLoc"]+".*",regex=True)]["WtdUtil"].mean(),1),axis=1)
finaldf=finaldf[finaldf["WtdUtil%"]<=90.0]
finaldf=finaldf[finaldf["Util%"]<=95.0]
finaldf["Optkey2"]=finaldf["TC_Source"]+finaldf["TC_Dest"]+finaldf["Destn"]
df7=finaldf.drop(["inpath","chartest","Optkey","Optkey2"],axis=1)[0:25].rename_axis({'Destn':'Con_Dest','Resid_Path2':'Ideal_Path'},axis=1)
dfdetail=errordf.drop(['Resid_Path','error','Resid_Path2'],axis=1)
dfdetail["Key"]=dfdetail["TC_Source"]+dfdetail["TC_Dest"]+dfdetail["Destn"]
dfdetail=dfdetail[dfdetail["Key"].isin(finaldf["Optkey2"].values.tolist())]
dfdetail=dfdetail.drop("Key",axis=1)
from datetime import date,timedelta
todate=date.today()
today_date=datetime.strftime(todate,'%d-%m-%Y')
today_date

filepath=r'D:\Data\Appointment Reports\Misrouting\DetailedReport'+str(todate)+'.csv'
filepath2=r'D:\Data\Appointment Reports\DetailedReport'+str(todate)+'.csv'
try:
    dfdetail.to_csv(filepath,encoding='utf-8')
except:
    dfdetail.to_csv(filepath2,encoding='utf-8')

df8=df7.sort_values(by='Act_Wt',ascending=False).head(25)



#pnqh_df=df8



#vishwas.j@spoton.co.in
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

TO=['vishwas.j@spoton.co.in','saptarshi.pathak@spoton.co.in']
FROM="reports.ie@spoton.co.in"

CC=['mahesh.reddy@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = "LH - Misrouted Cons Report" + " : " + str(today_date)
html='''<html>
<style>
p
{
  margin:0;
  margin-top: 5px;
  padding:0;
  font-size:17px;
    line-height:20px;
}
</style>

</html>'''

# html3='''
# <h5> For the base data, please refer the link </h5>
# <p><a href= "http://spoton.co.in/downloads/OCID/OCID.xls"</a>http://spoton.co.in/downloads/OCID/OCID.xls</p></b>
# '''
s = Template(html).safe_substitute(date=today_date)
report=""
report+=s
report+='<br>'
report+='<br>'+df8.to_html()+'<br>'
abc=MIMEText(report,'html')
msg.attach(abc)
# part = MIMEBase('application', "octet-stream")
# part.set_payload( open(filePath,"rb").read() )
# encoders.encode_base64(part)
# part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
# msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()
