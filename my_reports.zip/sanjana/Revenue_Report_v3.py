
# coding: utf-8

# In[1]:

import pandas as pd
from datetime import datetime, timedelta, date
import numpy as np
import zipfile as zf
#from urllib import urlopen
import io
from calendar import monthrange
from sqlalchemy import *
import pyodbc

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template
import Utilities

# In[ ]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=PYTHON_DB;UID=PythonOnline;PWD=P@ssw0rd123$")


# In[ ]:



startdate="'"+datetime.strftime((datetime.now()-timedelta(days=1)).replace(day=1),"%Y-%m-%d")+"'"
enddate="'"+datetime.strftime(datetime.now(),"%Y-%m-%d")+"'"
df = pd.read_sql("SELECT * FROM revenuebkg WHERE PICKUP_DATE >= {0} AND PICKUP_DATE < {1}".format(startdate,enddate),cnxn) 
# df.to_csv(r'Revenuedata_check.csv')
print (df.columns)
print (len(df), df['NetRev'].sum())
df=df[df['Product Type']!='AR']
yeststart = datetime.combine((datetime.now()-timedelta(days=1)).date(), datetime.min.time())
mtdrevenue = round(df["NetRev"].sum()*0.9675/100000.0,1)
yestrevenue=round(df[df["PICKUP_DATE"]>=yeststart]["NetRev"].sum()*0.9675/100000.0,1)
print ('mtdrevenue',mtdrevenue,'yestrevenue',yestrevenue)
if yestrevenue!=0:
    pass
else:
    startdate=datetime.strftime((datetime.now()-timedelta(days=1)),"%Y-%b-%d")
    enddate=datetime.strftime(datetime.now(),"%Y-%b-%d")
    df=pd.read_csv(r'http://spoton.co.in/downloads/PMD_PL_DL_RV/PMDPLDLRL.csv')
    df=df[df['Product_Type']!='AR']
    def getDate(dt):
        dt1=(dt.split(' ')[2]+'-'+dt.split(' ')[1]+'-'+dt.split(' ')[0])
        return dt1
    df['PICKUP DATE']=df.apply(lambda x:getDate(x['PICKUP_DATE']),axis=1)
    yestrevenue=round(df[df["PICKUP DATE"]>=startdate]["NetRev"].sum()*0.9675/100000.0,1)
    mtdrevenue = round(df["NetRev"].sum()*0.9675/100000.0,1)
    print ('mtdrevenue1',mtdrevenue,'yestrevenue1',yestrevenue)
# blhdlist=[29910, 30784, 44929, 50163, 50592, 51306, 51558, 56105, 63465, 64858, 65139, 66235, 66788, 67313, 67514, 67862, 68027, 68029, 68031, 68032, 68033, 68034, 68035, 68036, 68037, 68038, 68039, 68040, 68041, 68042, 68043, 68044, 68045, 68046, 68047, 68048, 68049, 68051, 68052, 68055, 68058, 68060, 68061, 68062, 68063, 68064, 68065, 68066, 68067, 68069, 68077, 68078, 68080, 68081, 68082, 68084, 68085, 68087, 68089, 68093, 68094, 68095, 68096, 68098, 68099, 68101, 68102, 68103, 68104, 68105, 68106, 68107, 68108, 68111, 68113, 68114, 68115, 68116, 68117, 68118, 68119, 68120, 68121, 68122, 68123, 69950, 72155, 73084, 73085, 73086, 73087, 75818, 75954, 76360, 77029, 79107, 80663, 81244, 83074, 83579, 85314, 85315, 86387, 86782, 87167, 87201, 87205, 87206, 87207, 87208, 87209, 87210, 87211, 87212, 87213, 87296, 87297, 87298, 87338, 87340, 87342, 87356, 87437, 87854, 88131, 88165, 88489, 89425, 89824, 90150, 90187, 90203, 90642, 91124, 91125, 92325, 92569, 92570, 93450, 94560, 95302, 95657, 95658, 95659, 95660, 95662, 95663, 95664, 95665, 95666, 95667, 95668, 96045, 96119, 96297, 96307, 96333, 96334, 96725, 96828, 96970, 96971, 97174, 97175, 98464, 99041, 99393, 99394, 99551, 99707, 99708, 99709, 99710, 99804, 99813, 99814, 99815, 100226, 100227, 100228, 100229, 100230, 100231, 100232, 100233, 100234, 100235, 100374, 101109, 102557, 102956, 103064, 103348, 103914, 104374, 104375, 104376, 104377, 105974, 106156, 106415, 106657, 106658, 107495, 107923, 108058, 108083, 108274, 109003, 112951, 112952, 112953, 112954, 112955, 113823, 113824, 115924, 116216, 116615, 114288, 111617, 106472, 106625,108619]
# df.loc[df["CUSTOMERCODE"].isin(blhdlist),['CUSTOMER_SIGNED_AT_DEPOT']]="BLHD"
regcleandict = {'AHMEDABAD':'W', 'BENGALURU':'S', 'CHANDIGARH':'N', 'NOIDA':'N', 'GURGAON':'N', 'CHENNAI':'S', 'HEAD OFFICE':'H', 'HO TNT':'H','HYDERABAD':'S','INDORE':'W','KOLKATA':'E','MUMBAI':'W','NEW DELHI':'N','PUNE':'W','ROTN/KL':'S','UP':'N','UTTARAKHAND':'N'}
df["Region"] = df["SaleDepott"].map(regcleandict)
depocleandict = {'AHMEDABAD':'AMDD', 'BENGALURU':'BLRD', 'GURGAON':'NCRD', 'NOIDA':'NCRD', 'CHANDIGARH':'IXCD','CHENNAI':'MAAD', 'HEAD OFFICE':'BLHD', 'HO TNT':'BLHD','HYDERABAD':'HYDD','INDORE':'IDRD','KOLKATA':'CCUD','MUMBAI':'BOMD','NEW DELHI':'NCRD','PUNE':'PNQD','ROTN/KL':'RTKD','UP':'LKOD','UTTARAKHAND':'UKND'}
df.replace({"SaleDepott":depocleandict},inplace=True)


# In[ ]:





# In[ ]:

df1=df[df['DEST_REGION']!='H']
print (len(df1),'df1')
regpivot=np.round(df1.pivot_table(index="ORG_REGION",columns="DEST_REGION",values=["NetRev"],aggfunc={"NetRev":lambda x: (x*0.9675/1e5).sum()*100.0/mtdrevenue},margins=True),1)
print (regpivot)
regpivot.columns=pd.MultiIndex(levels=[[""],['All','E','N','S','W']],labels=[[0, 0, 0, 0, 0],[1, 2, 3, 4, 0]],names=[None,None])


# In[2]:

regpivot


# In[3]:
try:
  target_procedure=("exec [SP_DAILY_REVENUE_REPORT_WITH_Q113TARGET_SALES_COLLTARGET] 'CMT'")


  # In[4]:

  cnxn123 = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")


  # In[5]:

  targetdf=pd.read_sql(target_procedure,cnxn123)


  # In[6]:

  summary=targetdf[targetdf['REGION'].isin(['East','HO','North','South','West'])]


  # In[7]:

  summary['REVENUE'].sum()/100000


  # In[8]:

  summary['TOTTARGET'].sum()/100000


  # In[9]:

  blho_rev=targetdf[targetdf['REGION']=='HO']['REVENUE'].values[0]
  blho_rev


  # In[ ]:

  ## To get Number of Working days


  # In[10]:

  cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
  cursor = cnxn.cursor()
  startdate1=datetime.strftime((datetime.today()-timedelta(1)).replace(day=1,hour=0,minute=0,second=0),"%Y-%m-%d %H:%M:%S")
  enddate1=datetime.strftime((datetime.today()-timedelta(1)).replace(hour=23,minute=0,second=0),"%Y-%m-%d %H:%M:%S")
  targetdate=datetime.strftime((datetime.today()-timedelta(1)),"%Y-%m-%d")
  q_query=("SELECT * FROM tblSaleDepotTargetDtls WHERE TARGET_DATE BETWEEN '{0}' AND '{1}'").format(startdate1,enddate1)
  r_df=pd.read_sql(q_query,Utilities.cnxn)
  yesttarget=pd.np.round((r_df[r_df['TARGET_DATE']==targetdate]['per_day_target'].sum()*0.9675)/100000.0,2)+(100000.0/100000.0)
  yesttarget=pd.np.round(yesttarget,2)
  r_df['day']=r_df['TARGET_DATE'].dt.weekday
  r_df1=r_df[r_df['day']!=6]
  n=len(r_df1['TARGET_DATE'].unique())
  n


  # In[11]:

  blho_target=n*100000.0
  blho_target


  # In[12]:

  summary=summary[summary['REGION']!='HO']


  # In[13]:

  blhd_df=pd.DataFrame([{'DEPOT_CODE':'BLHD','REVENUE':blho_rev,'REGION':'HO','TOTTARGET':blho_target}])


  # In[14]:

  blhd_df


  # In[15]:

  summary1=pd.concat([summary,blhd_df],ignore_index=True)


  # In[16]:

  summary1[summary1['REGION']=='HO']


  # In[17]:

  summary1['TOTTARGET'].sum()/100000


  # In[18]:

  summary1['REVENUE'].sum()/100000


  # In[ ]:

  ## BranchWise Actual values


  # In[69]:

  startdate1=datetime.strftime((datetime.today()-timedelta(1)).replace(day=1,hour=0,minute=0,second=0),"%Y-%m-%d %H:%M:%S")
  enddate1=datetime.strftime((datetime.today()-timedelta(1)).replace(hour=23,minute=0,second=0),"%Y-%m-%d %H:%M:%S")
  startdate1,enddate1


  # In[19]:

  branch_cash_query=("""SELECT  SaleDepott ,

         

          COUNT(A.[Con Number]) CON_CNT ,

          SUM(A.[Charged Weight]) CHRGWT ,

          SUM(A.REVISED_CHRG_AMOUNT) REVENUE

  FROM    ( SELECT    CASE WHEN ( ( TS.Conno IS NULL

                                    AND DT.PAYBAS IN ( 1, 4 )

                                    AND DT.CSGNCD = '8888'

                                    AND DT.CSGECD = '8888'

                                  )

                                  OR ( TS.Conno IS  NOT NULL

                                       AND DT.PAYBAS IN ( 1, 4 )

                                       AND DT.CSGNCD = '8888'

                                       AND DT.CSGECD = '8888'

                                     )

                                  OR ( DT.PAYBAS IN ( 1, 4 )

                                       AND ( DT.CSGNCD LIKE '0008%' )

                                       AND DT.CSGECD = '8888'

                                     )

                                ) THEN 'BRANCHCASH OPS'

                      END AS DEPOT_CODE ,

                      A.[Con Number] ,

                      A.[Charged Weight] ,

                      A.REVISED_CHRG_AMOUNT ,

                      A.SaleDepott

            FROM      Con_BalanceSheet_Sales A WITH ( NOLOCK )

                      INNER JOIN dbo.DOCKET DT WITH ( NOLOCK ) ON DT.DOCKNO = A.[Con Number]

                      LEFT OUTER JOIN TBLOPSSALEDEPOTMAPPING OSM WITH ( NOLOCK ) ON OSM.SALEDEPOTID = A.SaleDepotId

                                                                AND OSM.IsActive = 1

                      LEFT OUTER JOIN dbo.tblsaleDepotMst TDM WITH ( NOLOCK ) ON TDM.saleDepotId = A.SaleDepotId

                      INNER JOIN dbo.ptms PT WITH ( NOLOCK ) ON PT.PTMSPTCD = A.[Customer Code]

                      LEFT OUTER JOIN dbo.TNT_STL_CUSTOMERS TSC WITH ( NOLOCK ) ON TSC.GLACCOUNTCODE = A.[Customer Code]

                                                                AND TSC.ACTFLAG = 'Y'

                      LEFT OUTER JOIN dbo.TBL_PUD_ANDROID_CASH_BOOKING TS WITH ( NOLOCK ) ON TS.Conno = A.[Con Number]

                                                                AND TS.RateModifyEnabled = 'Y'

            WHERE     A.[Con Date] BETWEEN '{0}'

                                   AND     '{1}'

                      AND A.ProductName = 'RE'

                                   

          ) A

  WHERE   A.DEPOT_CODE IS NOT NULL

  GROUP BY DEPOT_CODE ,

          SaleDepott   """).format(startdate1,enddate1)


  # In[20]:

  branch_cash_act=pd.read_sql(branch_cash_query,cnxn123)


  # In[21]:

  depocleandict = {'AHMEDABAD':'AMDD', 'BENGALURU':'BLRD', 'GURGAON':'NCRD', 'NOIDA':'NCRD', 'CHANDIGARH':'IXCD','CHENNAI':'MAAD', 'HEAD OFFICE':'BLHD', 'HO TNT':'BLHD','HYDERABAD':'HYDD','INDORE':'IDRD','KOLKATA':'CCUD','MUMBAI':'BOMD','NEW DELHI':'NCRD','PUNE':'PNQD','ROTN/KL':'RTKD','UP':'LKOD','UTTARAKHAND':'UKND'}
  branch_cash_act.replace({"SaleDepott":depocleandict},inplace=True)


  # In[22]:

  branch_cash_act['REVENUE'].sum()/100000


  # In[23]:

  4321.08+72.49


  # In[24]:

  branch_cash_act_summary=branch_cash_act.pivot_table(index=['SaleDepott'],aggfunc={'REVENUE':sum}).reset_index()


  # In[25]:

  branch_cash_act_summary.rename(columns={'SaleDepott':'DEPOT_CODE','REVENUE':'Cash_Revenue'},inplace=True)


  # In[26]:

  summary1=pd.merge(summary1,branch_cash_act_summary,on='DEPOT_CODE',how='outer')


  # In[27]:

  summary1['REVENUE'].sum()


  # In[39]:

  summary1['TOTTARGET'].sum()/100000


  # In[29]:

  summary1=summary1.fillna(0)


  # In[30]:

  depot_list=summary1['DEPOT_CODE'].unique()


  # In[ ]:

  ##Cash Target


  # In[31]:

  from datetime import datetime
  cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
  cursor = cnxn.cursor()

  query1=("SELECT * FROM TBL_BRANCH_PUD_TARGET_MASTER where [IS ACTIVE]='Y'")
  dfff=pd.read_sql(query1,cnxn)
  startdate2=datetime.strftime((datetime.today()-timedelta(1)).replace(day=1,hour=0,minute=0,second=0),"%Y-%m-%d %H:%M:%S")
  enddate2=datetime.strftime((datetime.today()-timedelta(1)).replace(day=30,hour=23,minute=0,second=0),"%Y-%m-%d %H:%M:%S")
  dfff=dfff[(dfff['CREATED ON']>=startdate2) & (dfff['CREATED ON']<=enddate2)]


  # In[32]:

  dfff['TARGET REVENUE']=dfff.apply(lambda x:x['TARGET REVENUE']*100000.0,axis=1)
  #print (dfff[dfff['DEPOCODE']=='CCUD']['TARGET REVENUE'].sum())
  #revenue_depot=dfff.pivot_table(index=['DEPOCODE'],aggfunc={'TARGET REVENUE':sum}).reset_index()


  # In[33]:

  dfff['TARGET REVENUE'].sum()


  # In[34]:

  lyear,lmonth,ldate=datetime.now().replace(day=30).year,datetime.now().replace(day=30).month,datetime.now().replace(day=30).day
  fyear,fmonth,fdate=(datetime.now()-timedelta(days=2)).replace(day=1).year,(datetime.now()-timedelta(days=2)).replace(day=1).month,(datetime.now()-timedelta(days=2)).replace(day=1).day
  import datetime

  def workdays(d, end):
      days = []
      while d.date() <= end.date():
          if d.isoweekday()!=7:
              days.append(d)
          d += datetime.timedelta(days=1)
      return days

  import datetime
  no_of_days=workdays(datetime.datetime(fyear,fmonth,fdate),datetime.datetime(lyear, lmonth, ldate))
  len(no_of_days)


  # In[ ]:

  fyear,fmonth,fdate,lyear,lmonth,ldate


  # In[ ]:

  from datetime import datetime
  startdate=datetime.strftime((datetime.now()-timedelta(days=2)).replace(day=1),"%Y-%m-%d")
  enddate=datetime.strftime(datetime.now()-timedelta(days=1),"%Y-%m-%d")
  depotmatch={'BLRD':1,'BOMD':2,'CCUD':3,'IXCD':4,'LKOD':5,'MAAD':6,'NCRD':7,'PNQD':8,'BLHD':9,'AMDD':10,'HYDD':11,'RTKD':12,'UCGD':13,'IDRD':14,'UKND':15,'NOID':16,'GRGD':17}
  holidayquery = ("""
      SELECT  *FROM dbo.tblSalesHolidayMaster where HdayDate between  '{0}' and '{1}'
      """).format(startdate,enddate)


  holidaymaster = pd.read_sql(holidayquery, Utilities.cnxn)
  def getKey(x):
      for k,v in depotmatch.items():
          if v==x:
              return k
          else:
              pass
  #holidaymaster['Depot']=holidaymaster.apply(lambda x:getKey(x['SaleDepotId']),axis=1)
  # holidaysummary=holidaymaster.pivot_table(index=['Depot'],aggfunc={'HdayDate':len}).reset_index()
  # holidaysummary.rename(columns={'HdayDate':'Non_Wrkng_Days'},inplace=True)
  # # branch_df=pd.read_excel(r'C:\Users\rajeeshv\Downloads\Branch Details Master  V 1.23.xlsx',sheet_name='Area')
  # # holidaysummary=pd.merge(holidaysummary,branch_df,on='ControlArea',how='outer')
  # holidaysummary=holidaysummary.fillna(0)


  # # In[ ]:

  # holidaysummary


  # In[ ]:

  # depot_holiday_summary=holidaysummary
  # def excludingLeave(x):
  #     days=len(no_of_days)-x
  #     return days

  # depot_holiday_summary['Working_days']=depot_holiday_summary.apply(lambda x:excludingLeave(x['Non_Wrkng_Days']),axis=1)
  # revenue_depot.rename(columns={'DEPOCODE':'Depot'},inplace=True)
  # depot_holiday_summary=pd.merge(depot_holiday_summary,revenue_depot,on='Depot',how='outer')
  # depot_holiday_summary=depot_holiday_summary.fillna(0)


  # # In[ ]:

  # depot_holiday_summary=depot_holiday_summary.fillna(0)


  # # In[ ]:

  # depot_holiday_summary


  # In[35]:

  dfff['Per_Day_Target']=pd.np.round(dfff['TARGET REVENUE']/26,1)


  # In[36]:

  dfff=dfff.replace([np.inf,-np.inf],np.nan).fillna(0)


  # In[37]:

  dfff['Per_Day_Target']=dfff['Per_Day_Target'].apply(lambda x: x*n)


  # In[38]:

  dfff['Per_Day_Target'].sum()/100000


  # In[40]:

  (4398.61+108.51)


  # In[42]:

  (4321.08+72.49)


  # In[43]:

  dfff.rename(columns={'Per_Day_Target':'Cash_Target','DEPOCODE':'DEPOT_CODE'},inplace=True)


  # In[44]:

  summary2=pd.merge(summary1,dfff,how='left',on='DEPOT_CODE')


  # In[45]:

  summary2=summary2.fillna(0)


  # In[46]:

  summary2['REVENUE']=pd.np.round(summary2['REVENUE']+summary2['Cash_Revenue'],1)
  summary2['TOTTARGET']=pd.np.round(summary2['TOTTARGET']+summary2['Cash_Target'],1)


  # In[47]:

  summary2=summary2.fillna(0)


  # In[48]:

  summary2['REVENUE'].sum()/100000


  # In[49]:

  summary2['TOTTARGET'].sum()/100000


  # In[50]:

  summary2['REVENUE']=pd.np.round(summary2['REVENUE']*0.9675)
  summary2['TOTTARGET']=pd.np.round(summary2['TOTTARGET']*0.9675)


  # In[51]:

  f2=summary2.pivot_table(index=['REGION','DEPOT_CODE'],aggfunc={'REVENUE':sum,'TOTTARGET':sum})


  # In[52]:

  f2['REVENUE'].sum()/100000


  # In[53]:

  f2['TOTTARGET'].sum()/100000


  # In[54]:

  f2['REVENUE']=pd.np.round(f2['REVENUE']/100000.0,1)
  f2['TOTTARGET']=pd.np.round(f2['TOTTARGET']/100000.0,1)


  # In[56]:

  f2['REVENUE'].sum()


  # In[57]:

  f2['TOTTARGET'].sum()


  # In[58]:

  depotdftots1 = f2.groupby(level='REGION').sum()


  # In[59]:

  depotdftots1.index = [depotdftots1.index, ['Total'] * len(depotdftots1)]


  # In[60]:

  depotpivot1 = np.round(pd.concat([f2,depotdftots1]).sort_index().append(f2.sum().rename(('Grand', 'Total'))),2)

except:
  target_procedure=("exec [SP_DAILY_REVENUE_REPORT_WITH_Q113TARGET_SALES_COLLTARGET] 'CMT'")
  cnxn123 = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
  targetdf=pd.read_sql(target_procedure,cnxn123)
  summary=targetdf[targetdf['REGION'].isin(['East','HO','North','South','West'])]
  startdate1=datetime.strftime((datetime.today()-timedelta(1)).replace(day=1,hour=0,minute=0,second=0),"%Y-%m-%d %H:%M:%S")
  enddate1=datetime.strftime((datetime.today()-timedelta(1)).replace(hour=23,minute=0,second=0),"%Y-%m-%d %H:%M:%S")
  branch_cash_query=("""SELECT  SaleDepott ,

           

            COUNT(A.[Con Number]) CON_CNT ,

            SUM(A.[Charged Weight]) CHRGWT ,

            SUM(A.REVISED_CHRG_AMOUNT) REVENUE

    FROM    ( SELECT    CASE WHEN ( ( TS.Conno IS NULL

                                      AND DT.PAYBAS IN ( 1, 4 )

                                      AND DT.CSGNCD = '8888'

                                      AND DT.CSGECD = '8888'

                                    )

                                    OR ( TS.Conno IS  NOT NULL

                                         AND DT.PAYBAS IN ( 1, 4 )

                                         AND DT.CSGNCD = '8888'

                                         AND DT.CSGECD = '8888'

                                       )

                                    OR ( DT.PAYBAS IN ( 1, 4 )

                                         AND ( DT.CSGNCD LIKE '0008%' )

                                         AND DT.CSGECD = '8888'

                                       )

                                  ) THEN 'BRANCHCASH OPS'

                        END AS DEPOT_CODE ,

                        A.[Con Number] ,

                        A.[Charged Weight] ,

                        A.REVISED_CHRG_AMOUNT ,

                        A.SaleDepott

              FROM      Con_BalanceSheet_Sales A WITH ( NOLOCK )

                        INNER JOIN dbo.DOCKET DT WITH ( NOLOCK ) ON DT.DOCKNO = A.[Con Number]

                        LEFT OUTER JOIN TBLOPSSALEDEPOTMAPPING OSM WITH ( NOLOCK ) ON OSM.SALEDEPOTID = A.SaleDepotId

                                                                  AND OSM.IsActive = 1

                        LEFT OUTER JOIN dbo.tblsaleDepotMst TDM WITH ( NOLOCK ) ON TDM.saleDepotId = A.SaleDepotId

                        INNER JOIN dbo.ptms PT WITH ( NOLOCK ) ON PT.PTMSPTCD = A.[Customer Code]

                        LEFT OUTER JOIN dbo.TNT_STL_CUSTOMERS TSC WITH ( NOLOCK ) ON TSC.GLACCOUNTCODE = A.[Customer Code]

                                                                  AND TSC.ACTFLAG = 'Y'

                        LEFT OUTER JOIN dbo.TBL_PUD_ANDROID_CASH_BOOKING TS WITH ( NOLOCK ) ON TS.Conno = A.[Con Number]

                                                                  AND TS.RateModifyEnabled = 'Y'

              WHERE     A.[Con Date] BETWEEN '{0}'

                                     AND     '{1}'

                        AND A.ProductName = 'RE'

                                     

            ) A

    WHERE   A.DEPOT_CODE IS NOT NULL

    GROUP BY DEPOT_CODE ,

            SaleDepott   """).format(startdate1,enddate1)

  # In[6]:

  branch_cash_act=pd.read_sql(branch_cash_query,cnxn123)
  depocleandict = {'AHMEDABAD':'AMDD', 'BENGALURU':'BLRD', 'GURGAON':'NCRD', 'NOIDA':'NCRD', 'CHANDIGARH':'IXCD','CHENNAI':'MAAD', 'HEAD OFFICE':'BLHD', 'HO TNT':'BLHD','HYDERABAD':'HYDD','INDORE':'IDRD','KOLKATA':'CCUD','MUMBAI':'BOMD','NEW DELHI':'NCRD','PUNE':'PNQD','ROTN/KL':'RTKD','UP':'LKOD','UTTARAKHAND':'UKND'}
  branch_cash_act.replace({"SaleDepott":depocleandict},inplace=True)
  branch_cash_act1=branch_cash_act[['SaleDepott','REVENUE']]
  branch_cash_act1.rename(columns={'REVENUE':'Cash_Revenue'},inplace=True)
  branch_cash_act1=branch_cash_act1.pivot_table(index=['SaleDepott'],aggfunc={'Cash_Revenue':sum}).reset_index()
  summary2=summary[['REGION','DEPOT_CODE','REVENUE']]
  summary3=pd.merge(summary2,branch_cash_act1,left_on='DEPOT_CODE',right_on='SaleDepott',how='outer')
  summary3=summary3.fillna(0)
  summary3['REVENUE']=summary3['REVENUE']+summary3['Cash_Revenue']
  summary3['REVENUE']=pd.np.round(summary3['REVENUE']*0.9675)
  f2=summary3.pivot_table(index=['REGION','DEPOT_CODE'],aggfunc={'REVENUE':sum})
  f2['REVENUE']=pd.np.round(f2['REVENUE']/100000.0,1)
  depotdftots1 = f2.groupby(level='REGION').sum()
  depotdftots1.index = [depotdftots1.index, ['Total'] * len(depotdftots1)]
  depotpivot1 = np.round(pd.concat([f2,depotdftots1]).sort_index().append(f2.sum().rename(('Grand', 'Total'))),2)
  depotpivot1


# In[63]:
depotpivot1=depotpivot1.reset_index()
mtd_revenue=depotpivot1[depotpivot1['REGION']=='Grand']['REVENUE'].values[0]
try:
  mtd_target=depotpivot1[depotpivot1['REGION']=='Grand']['TOTTARGET'].values[0]
except:
  mtd_target=0.0
try:
  depotpivot1.rename(columns={'REVENUE':'GrossRev','TOTTARGET':'Target'},inplace=True)
  depotpivot1['%Ach']=pd.np.round(depotpivot1['GrossRev']*100.0/depotpivot1['Target'],1)

except:
  depotpivot1.rename(columns={'REVENUE':'GrossRev'},inplace=True)

#depotpivot1['%Ach']=pd.np.round(depotpivot1['GrossRev']*100.0/depotpivot1['Target'],1)

# In[61]:



# In[62]:


# In[64]:

mtd_revenue,mtd_target


# In[65]:
try:
  yesttarget=pd.np.round((r_df[r_df['TARGET_DATE']==targetdate]['per_day_target'].sum()*0.9675)/100000.0,2)+(100000.0/100000.0)
  yesttarget
except:
  yesttarget=0.0

# In[66]:
try:
  yestrevenue=round(df[df["PICKUP_DATE"]>=yeststart]["NetRev"].sum()*0.9675/100000.0,1)
except:
  yestrevenue=0.0


# In[67]:

from datetime import date,timedelta
todate=date.today()
todate


# In[68]:


df.to_csv(r'D:\Data\Revenue Reports\Data\Revenue_Data_'+str(todate)+'.csv')
depotpivot1.to_csv(r'D:\Data\Revenue Reports\Summaries\Depot_Summary_'+str(todate)+'.csv')
regpivot.to_csv(r'D:\Data\Revenue Reports\Summaries\Region_Summary_'+str(todate)+'.csv')

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

# TO=['mahesh.reddy@spoton.co.in']  
TO=["krishna.chandrasekar@spoton.co.in","abhik.mitra@spoton.co.in",'satya.pal@spoton.co.in','uday.sharma@spoton.co.in']
FROM="reports.ie@spoton.co.in"
# CC=['mahesh.reddy@spoton.co.in']
CC=['mahesh.reddy@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = "Revenue Variance Report RDB" + " - " + str(todate)
html='''<html>
<style>
p
{
margin:0;
margin-top: 5px;
padding:0;
font-size:17px;
line-height:20px;
}
</style>
</html>'''

report="Dear All,"
report+='<br>'
report+='<br>'
report+="Revenue for yesterday is Rs. "+str(round(yestrevenue,2))+' lakhs (Target Rs. '+str(yesttarget)+' lakhs @3.25% CN)'
report+='<br>'
report+='<br>'
report+="MTD Revenue is Rs. "+str(mtd_revenue)+' lakhs (Target Rs. '+str(mtd_target)+' lakhs @3.25% CN)'
report+='<br>'
report+='<br>'
report+='A. MTD REGION TO REGION TRADING PATTERN (%)'
report+='<br>'
report+='<br>'+regpivot.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='DEPOTWISE TRADING:'
report+='<br>'
report+='<br>'+depotpivot1.to_html()+'<br>'

#report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)
# part = MIMEBase('application', "octet-stream")
# part.set_payload( open(filepath,"rb").read() )
# encoders.encode_base64(part)
# part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
# msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()


# In[ ]:



