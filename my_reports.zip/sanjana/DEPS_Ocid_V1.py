
# coding: utf-8

# In[1]:

import numpy as np
import pandas as pd
import datetime
from datetime import date,timedelta
import os
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from pandas import ExcelWriter
import sys
from email import encoders
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import Utilities
reload(sys)
sys.setdefaultencoding("UTF8")

cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
cursor = cnxn.cursor()

query = ("""EXEC UBESP_PUD_ANALYSIS_OPEN_CLOSE_STOCK_ARRV_DELV_SSRS_CS """)
print (query)

# closingdf = pd.read_sql(query, cnxn)
# closingdf.rename(columns={'CDELDT':'DUE DATE','DEFAULTHUB':'DEST DEFAULT HUB','DEST_BRCD':'DEST BRCD','DEST_BRNM':'DEST BRNM','DEST_BA_LOC':'DEST BA LOC','DEST_AREA':'DEST AREA','DEST_DEPOT':'DEST DEPOT','DEST_REGION':'DEST REGION','DEL_LOCATION_TYPE':'DEL LOCATION TYPE','ARRV_AT_DEST_SC':'ARRV AT DEST SC','REPORTDATE_MIN_ARRVDT':'REPORTDATE MIN ARRVDT','CUSTOMER_REGION':'CUSTOMER REGION','ORG_BRCD':'ORG BRCD','ORG_BRNM':'ORG BRNM','ORG_AREA':'ORG AREA','ORG_DEPOT':'ORG DEPOT','ORG_REGION':'ORG REGION','ConStatusCategory':'Con Status Category','ConStatusCode':'Con Status Code','ConStatusDesc':'Con Status Desc','ConStatusReason':'Con Status Reason','ConStatusDate':'Con Status Date','ConStatusMasterCategory':'Con Status Master Category','ReportGenConStatusDate':'Report Gen Con Status Date','DRS_PREPARED':'DRS PREPARED','LASTDRS_PREPAREDDATE':'LA STDRS PREPARED DATE','DRS_PREP_TIME':'DRS PREP TIME','DRS_UPTO_12PM':'DRS UPTO 12PM','DRS_BW_12PM_2PM':'DRS BW 12PM 2PM','ANDR_DRS_UPTO_12PM':'ANDR DRS UPTO 12PM','ANDR_DRS_BW_12PM_2PM':'ANDR DRS BW 12PM 2PM','IS_AVAIL_IN_OPENING_STOCK':'IS AVAIL IN OPENING STOCK','LATEST_CON_REC_COMM_AVAIL':'LATEST CON REC COMM AVAIL','LATEST_CON_REC_COMM':'LATEST CON REC COMM','LATEST_CON_REC_COMM_ON':'LATEST CON REC COMM ON','RPT_TIME_MINS_LATEST_CON_REC_COMM_ON':'RPT TIME MINS LATEST CON REC COMM ON','ORG_PINCODE':'ORG PINCODE','DEST_PINCODE':'DEST PINCODE','FreeStorageDays':'Free Storage Days','CON_BLOCKED_FOR_PAY_ISSUES':'DRS Blocked Due to Payment Issues','CON_BLOCKED_FOR_ODA_PIN_ISSUES':'DRS Blocked due to ODA Pincode Change','CON_BLOCKED_FOR_DEMURRAGE':'DRS Blocked due to Demurrage','DEMURRAGE_RESPONSIBILITY':'Demurrage Responsibility','IS_FREE_CON':'Is Free Con','TTSTicketRaised':'TTS Ticket Raised','LatestTicketStatus':'Latest Ticket Status','LatestTicketStatusCode':'Latest Ticket Status Code','TTS_AuditStatus':'TTS Audit Status','TTS_AuditRemarks':'TTS Audit Remarks','IsApptmntDel':'Appointment Delivery?','ApptmntDelDate':'Appointment Delivery Date'},inplace=True)
"""
def save_xls(list_dfs, name_dfs, xls_path):
   i = 0
   writer = ExcelWriter(xls_path)   
   for dataframe in list_dfs:
       sheetname = name_dfs[i]
       dataframe.to_excel(writer, sheetname, merge_cells = False)
       i = i+1
   writer.save()
"""

# print (closingdf.columns)
# In[2]:
closingdf = pd.io.excel.read_excel('http://10.109.230.50/downloads/OCID/OCID.xls','CLOSING STOCK')
ignorestatuscodelist = ['UCG','SSC','UG1','UG2','UG3','SHS']
closingdf=closingdf[~closingdf['Con Status Code'].isin(ignorestatuscodelist)]
print (len(closingdf))
#ippath0 = r'C:\Data\DEPS_Pred_061015\OCID_Closing_091015.xls'
#xl2 = pd.ExcelFile(ippath0)
#closingdf = xl2.parse('CLOSING STOCK')

#depsdf = pd.io.excel.read_excel('http://10.109.230.50/downloads/DOCKSCORE/DOCK_SCORE_REPORT.xls ','SalesScoreRpt')
depsdf = pd.read_csv(r'http://10.109.230.50/downloads/DOCKSCORE/DOCK_SCORE_REPORT.csv')

depsdf = depsdf[depsdf['ScoreValue']>=0.80]
print ('depsdf',len(depsdf))
print (depsdf.columns)

# In[3]:

mergedeps = pd.merge(closingdf,depsdf,left_on=['DOCKNO'],right_on=['DOCKNO'], how = 'inner')
print (len(mergedeps))
#exit(0)
# In[4]:

mergedeps=mergedeps.rename(columns={'REPORTDATE MIN ARRVDT':'Avg Cooling Hrs'})
countofdepscons = len(mergedeps)
avrcoolingtimelist = mergedeps['Avg Cooling Hrs'].tolist()
avrcoolingtime = np.round(np.mean(avrcoolingtimelist),2)
print avrcoolingtime


##Sepeartion of CCF/NCF and Spoton Controllable START

ix = mergedeps[mergedeps['Con Status Category']=='RECEIVER FAILURE'].index
iy = mergedeps[mergedeps['Con Status Category']=='SENDER FAILURE'].index
iz = mergedeps[mergedeps['Con Status Category']=='NON CONTROLLABLE FAILURE'].index


mergedeps.loc[mergedeps.index,'Base_category'] = 'Spoton_Failure'
mergedeps.loc[ix,'Base_category'] = 'CCF/NCF'
mergedeps.loc[iy,'Base_category'] = 'CCF/NCF'
mergedeps.loc[iz,'Base_category'] = 'CCF/NCF'



##Sepeartion of CCF/NCF and Spoton Controllable END
# In[5]:

#depsdf.describe()
ccflist=['SENDER FAILURE','RECEIVER FAILURE','NON CONTROLLABLE FAILURE']
custdeps=mergedeps[(mergedeps['Con Status Category'].isin(ccflist))]
customerpivot1=pd.pivot_table(custdeps,index=['SENDER NAME','RECEIVER NAME'],values=['DOCKNO'],aggfunc=len).reset_index()
customerpivot =customerpivot1.sort_values('DOCKNO',ascending=False)

final_merge_cust = np.round(custdeps.groupby(['DEST BRCD']).agg({'DOCKNO':'count','Avg Cooling Hrs':np.mean}),2).reset_index()
##final_merge_cust = final_merge_cust.replace(r'\s+',0)

restdf = mergedeps[(mergedeps['Base_category']=='Spoton_Failure')]
final_merge_rest = np.round(restdf.groupby(['DEST BRCD']).agg({'DOCKNO':'count','Avg Cooling Hrs':np.mean}),2).reset_index()
##final_merge_rest = final_merge_rest.replace(r'\s+', 0)

mergepivot = pd.merge(final_merge_rest,final_merge_cust,on=['DEST BRCD'],suffixes = ['_Spoton','_CCF/NCF'],left_index=True,how='left')
mergepivot = mergepivot.fillna(0)
mergepivot['Total_Cons'] = mergepivot.apply(lambda x: (((x['DOCKNO_Spoton'])+(x['DOCKNO_CCF/NCF']))),axis = 1)

# In[6]:

##$$mergepivot = np.round(pd.pivot_table(mergedeps,index=['DEST BRCD'],values=['DOCKNO','Avg Cooling Hrs'],aggfunc={'DOCKNO':len,'Avg Cooling Hrs':np.mean}),2).reset_index()
#####@@@@@@@@@@@@@@mergepivot = np.round(pd.pivot_table(mergedeps,index=['DEST BRCD'], columns=['Base_category'],values=['DOCKNO','Avg Cooling Hrs'],aggfunc={'DOCKNO':len,'Avg Cooling Hrs':np.mean}),2).reset_index()
#####mergepivot = mergedeps.groupby(['DEST BRCD','Base_category']).agg({'DOCKNO':'count','Avg Cooling Hrs':np.mean}).reset_index()

# In[7]:

mergepivot=mergepivot.sort_values('Total_Cons',ascending=False)
mergepivotmail=mergepivot.head(20)
#mergepivotmail = mergepivotmail[['DEST BRCD','DOCKNO','Avg Cooling Hrs']]
mergepivotmail=mergepivotmail.to_string(index=False)


# In[8]:
opfilevar=date.today()

opfilevar2=7.0

print 'opfilevar,opfilevar2',opfilevar,opfilevar2
print 'Done!!!!!'

oppath1=r'D:\Data\eta_rank\HighRisk_DestSC\High_risk_DEPS_DESTSC'+'-'+str(opfilevar)+'-'+str(opfilevar2)+'.xlsx'
#mergepivot.to_csv(r'C:\Data\DEPS_Pred_061015\High_risk_DEPS_DESTSC_Pivot.csv',encoding='utf-8')

"""
printlist =  [mergedeps,mergepivot,customerpivot]
namelist = ['Data','Summary','CS_Customers_list']
save_xls (printlist, namelist, oppath1)
"""

with ExcelWriter(r'D:\Data\eta_rank\HighRisk_DestSC\High_risk_DEPS_DESTSC'+'-'+str(opfilevar)+'-'+str(opfilevar2)+'.xlsx') as writer:
    ###orginal_cancel_basedata.to_excel(writer, sheet_name='Sheet1',engine='xlsxwriter')
    mergedeps.to_excel(writer, sheet_name='Data',engine='xlsxwriter')
    mergepivot.to_excel(writer, sheet_name='Summary',engine='xlsxwriter')
    customerpivot.to_excel(writer, sheet_name='CS_Customers_list',engine='xlsxwriter')

        
filePath = oppath1
def sendEmail(TO = ["spot_cstl@spoton.co.in",'sq_spot@spoton.co.in',"shivananda.p@spoton.co.in","trilochan.panda@spoton.co.in","sunil.nakte@spoton.co.in","chandrima.banerjee@spoton.co.in","spot_security@spoton.co.in"],
            #TO = ["rajeesh.vr@spoton.co.in"],
            #TO = ["vishwas.j@spoton.co.in"],
            #CC = ["vishwas.j@spoton.co.in"],
            CC = ["sqtf@spoton.co.in","mahesh.reddy@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "High Risk DEPS Cons - In Destination SC" + " - " + str(opfilevar)+ " - " +str(opfilevar2)+" | Avg Cooling Hrs of "+str(avrcoolingtime)
    msg["Subject"] = "High Risk DEPS Cons - In Destination SC" + " - " + str(opfilevar)+ " - " +str(opfilevar2)+" | Avg Cooling Hrs of "+str(avrcoolingtime)
    body_text = """
    
    Dear All,
    PFA a report on High risk DEPS cons lying in the Destination SC. 
    This file contains cons having high probability of being DEPS and lying in the Destination SC. 
    As we can see in the attachment, Average cooling hours at Destination SC for these cons are high and most of these cons have CCF/NCF statuses. 
    
    PFB a summary of TOP 20 count of High risk DEPS cons at Destination SC. The complete summary is attached in the 'Summary' sheet of the attachment.
    
    The average cooling hours for """+str(countofdepscons)+""" high risk DEPS Cons at Destination SC is """+str(avrcoolingtime)+""" hrs
    
    Note : Initally, cons picked during the last 10 days were considered. For uniformity, from now, all the cons lying in Dest SC are considered irrespective of their pickup date.
    
    """+ str(mergepivotmail) +"""
    
    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')

#Sending output file via mail ends





