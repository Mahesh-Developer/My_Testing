
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
import calendar
from pandas import ExcelWriter
import glob
import smtplib
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import Utilities


# In[2]:

reportts = datetime.now()
opfilevar=reportts.date()
opfilevar1=reportts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=np.round((float(currhrs)/60),0)


#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
#cursor = cnxn.cursor()


capacityfile = pd.read_csv(r'D:\Python\Scripts and Files\Python Scripts\Capacity_BLR_BOM.csv')

# In[3]:


destquery = ("""EXEC USP_CLOSINGSTOCK_REPORT_1HR_IE""")
destsc = pd.read_sql(destquery,Utilities.cnxn) 


# In[4]:


htrquery = ("""EXEC USP_HUB_THROUGHPUT_DETAILS_SALES_ONEHOUR""")
invdf = pd.read_sql(htrquery,Utilities.cnxn)


# In[5]:


orgquery = ("""EXEC USP_ORIGINSC_STOCK """)
originstock = pd.read_sql(orgquery, Utilities.cnxn)


# In[6]:
destsc['DEST_BRCD'] = destsc['DEST_BRCD'].replace({'DBOM':'BWDB','DBLR':'BLRC','DPNQ':'PNQO','DLKO':'LKOB','DCCU':'CCUC','JAIO':'JAIC','HSRB':'BLRT'})
destsc = destsc[destsc['DRS_PREPARED']=='NO']

originstock['Dest_Check'] = originstock.apply(lambda x: True if x['ORGBRCD']== x['DLVBRCD'] else False, axis=1)
originstock = originstock[originstock['Dest_Check']==False]

len(originstock), len(destsc), len(invdf)


# In[7]:


invdf1 = invdf[invdf['Hub/SC Location'].isin(['BOMH','BLRH','PNQH'])]
destsc1 = destsc[destsc['DEST_BRCD'].isin(['BWDB','BLRF','PNQO'])]
originstock1 = originstock[originstock['ORGBRCD'].isin(['BWDB','BLRF','PNQO'])]

destsc1 = destsc1[destsc1['DRS_PREPARED']=='NO']


# In[8]:


invdf1['Date'] = invdf1['TIMESTAMP'].dt.date
invdf1['Hour'] = invdf1['TIMESTAMP'].dt.hour

originstock1['Date'] = originstock1['TimeStamp'].dt.date
originstock1['Hour'] = originstock1['TimeStamp'].dt.hour

destsc1['Date'] = destsc1['TimestateDate'].dt.date
destsc1['Hour'] = destsc1['TimestateDate'].dt.hour


# In[9]:


ccflist= ['APT','APN','CPN','HCM','VSC','SSC','CDA','DNR','AFS','DDV','HWC','RRA','NPO','NPE','NPH','RRF','RRL','DIP','RRT','SHD','SPS','WIA','WIP','SRH','PSP','HIP','NTW','HIM','HMP','EWX','EWN','EWI','EEG']
ncflist = ['DNH','DEP','DDS','LDR','WIH','DDB','DDR','DGA','PDB','CSD','DLI','DSI','LMA','LCC','LDW','SHS','VCI']
stflist =['CCD','NSL','HBH','AND','PVB','WDP','MRS','SRD','SWP','SRS','SRP','CNC','LAM','SHO','SRC','DNL','SDC','SPD','DAL','SRE','DWA','DIA','DLP','DWR','FLD','ODV','SMD','LHI','MMB','MCD','MCL','MPH','MSH','LDV','LCR','LXL','LDD','LXN','LXO','LXV','LOC','LCN','LVB','MCV','HPM','LDO','MCA','MOO','MOP','SLX','DWC','AOD','SWN','DIR','EIR','SIR','PIR','VSV','VSD','VNT','DNC','VLE','SPC','NTD','CFD']
ucglist =['UCG','UG1','UG2','UG3']
#blanklist =['CCD','NSL','SSC','CPN','HCM','HBH','AND','VSC']
def ccffunc(statuscode):
    if statuscode in ccflist:
        return 'CCF Con'
    elif statuscode in ucglist:
        return 'CCF Con'
    elif statuscode in ncflist:
        return "STF Con"
    else:
        return "STF Con"


# In[10]:


destsc1['CCF_Con'] =destsc1.apply(lambda x:ccffunc(x['ConStatusCode']),axis=1)
destsummary = pd.pivot_table(destsc1,index=['DEST_BRCD','Date','Hour'], columns=['CCF_Con'], values='ACTUWT', aggfunc={sum}).reset_index()
destsummary.columns = [' '.join(col).strip() for col in destsummary.columns.values]
destsummary.rename(columns={'DEST_BRCD':'Location','sum CCF Con':'Wt_CCF_Dest','sum STF Con':'Wt_Other_Dest'},inplace=True)


# In[11]:


hubsummary = invdf1.groupby(['Hub/SC Location','Date','Hour']).agg({'Act.WtInTonnes':sum}).reset_index()
orgsummary = originstock1.groupby(['ORGBRCD','Date','Hour']).agg({'ACTUWT':sum}).reset_index()
# destsummary = destsc1.groupby(['DEST_BRCD','Date','Hour']).agg({'ACTUWT':sum}).reset_index()



hubsummary['Hub/SC Location'] = hubsummary['Hub/SC Location'].replace(['BOMH'], 'BOMH+BWDB')
orgsummary['ORGBRCD'] = orgsummary['ORGBRCD'].replace(['BWDB'], 'BOMH+BWDB')
destsummary['Location'] = destsummary['Location'].replace(['BWDB'], 'BOMH+BWDB')


hubsummary['Hub/SC Location'] = hubsummary['Hub/SC Location'].replace(['BLRH'], 'BLRH+BLRF')
orgsummary['ORGBRCD'] = orgsummary['ORGBRCD'].replace(['BLRF'], 'BLRH+BLRF')
destsummary['Location'] = destsummary['Location'].replace(['BLRF'], 'BLRH+BLRF')

hubsummary['Hub/SC Location'] = hubsummary['Hub/SC Location'].replace(['PNQH'], 'PNQH+PNQO')
orgsummary['ORGBRCD'] = orgsummary['ORGBRCD'].replace(['PNQO'], 'PNQH+PNQO')
destsummary['Location'] = destsummary['Location'].replace(['PNQO'], 'PNQH+PNQO')

# In[12]:


orgsummary.rename(columns={'ORGBRCD':'Location','ACTUWT':'Wt_Org'},inplace=True)
hubsummary.rename(columns={'Hub/SC Location':'Location','Act.WtInTonnes':'Hub_load'},inplace=True)
# destsummary.rename(columns={'DEST_BRCD':'Location','ACTUWT':'Wt_Dest'},inplace=True)


# In[13]:


orgdest = pd.merge(orgsummary,destsummary, on=['Location','Date','Hour'],how='outer')
summary = pd.merge(orgdest,hubsummary, on=['Location','Date','Hour'], how='outer')


# In[14]:


summary


# In[15]:


summary['Wt_Org'] = pd.np.round(summary['Wt_Org']/1000.0,1)
summary['Wt_CCF_Dest'] = pd.np.round(summary['Wt_CCF_Dest']/1000.0,1)
summary['Wt_Other_Dest'] = pd.np.round(summary['Wt_Other_Dest']/1000.0,1)


# In[16]:


summary['Hub_load'] = pd.np.round(summary['Hub_load'],1)


# In[17]:
summary.fillna(0,inplace=True)

summary['Total_Load'] = summary['Wt_Org']+summary['Wt_CCF_Dest']+summary['Hub_load']+summary['Wt_Other_Dest']


# In[18]:
storagefor13t = 512
fiftypercextraforaisle = 512*1.5
spacepertonfactor = pd.np.round((fiftypercextraforaisle/13.5)*1.2,0)  ## 20% extra for loading unloading area(Staging area)

print (fiftypercextraforaisle, spacepertonfactor)



# summary['Capacity'] = pd.np.round(4900/spacepertonfactor,1)
# blrcap = pd.np.round(70000/spacepertonfactor,1)
# bomcap = pd.np.round(89500/spacepertonfactor,1)


summary = pd.merge(summary, capacityfile, on='Location',how='left')

# In[19]:


summary['Used%'] = pd.np.round((summary['Total_Load']/summary['Capacity'])*100.0,1)

#### Pallet postions
kgperpallet = 0.35

summary['Pallet_positions'] = pd.np.round((summary['Total_Load']/kgperpallet),0)

# In[20]:


print (summary)


# In[21]:


destsc1_ccf = destsc1[destsc1['CCF_Con']=='CCF Con']


# In[22]:


# destsc1_ccf.to_csv('IXRB_CCF.csv')


# In[23]:

print (destsc1_ccf.columns)

dest_ccf_grp = destsc1_ccf.groupby(['DEST_BRCD','CustomerName']).agg({'ACTUWT':sum}).reset_index().sort_values('ACTUWT',ascending=False)


# In[24]:


dest_ccf_grp['ACTUWT(T)'] = pd.np.round(dest_ccf_grp['ACTUWT']/1000.0,1)


# In[25]:


dest_ccf_grp = dest_ccf_grp[['DEST_BRCD','CustomerName','ACTUWT(T)']]




# In[13]:

summary.to_csv(r'D:\Data\BOMH_BLRH_Space_Monitoring\BOMH_BLRH_Summary_'+ str(opfilevar)+"-"+str(opfilevar2)+'.csv')
# destsc1_ccf.to_csv(r'D:\Data\IXRB Monitoring\CCF\IXRB_CCF_'+ str(opfilevar)+"-"+str(opfilevar2)+'.csv')
# In[27]:


dest_ccf_grp_sum = dest_ccf_grp[dest_ccf_grp['ACTUWT(T)']>=0.1]

# TO=['']
# TO=["pawan.sharma@spoton.co.in","avinash.singh@spoton.co.in","ashwani.gangwar@spoton.co.in","prasanna.hegde@spoton.co.in","rajesh.kumar@spoton.co.in","pramod.kumar@spoton.co.in"]
FROM="reports.ie@spoton.co.in"
# CC=['vishwas.j@spoton.co.in','syed.hussain@spoton.co.in','satya.pal@spoton.co.in','mahesh.reddy@spoton.co.in','shashvat.suhane@spoton.co.in',"abhik.mitra@spoton.co.in"]
TO=['syed.hussain@spoton.co.in','satya.pal@spoton.co.in','abhishek.cv@spoton.co.in']
# CC=['vishwas.j@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
# msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = "BOMH,BLRH,PNQH Space Monitoring Report" + "-" + str(opfilevar)+"-"+str(opfilevar2)
html='''<html>
<style>
p
{
margin:0;
margin-top: 5px;
padding:0;
font-size:17px;
line-height:20px;
}
</style>
</html>'''

report="Dear All,"
report+='<br>'
report+='Please find below space utilization of BOMH and BLRH with their respective virtual branches'
report+='<br>'
report+='<br>'+summary.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='Please find below the major CCF Customers'
report+='<br>'
report+='<br>'+dest_ccf_grp_sum.to_html()+'<br>'

#report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)
# part = MIMEBase('application', "octet-stream")
# part.set_payload( open(filepath,"rb").read() )
# encoders.encode_base64(part)
# part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
# msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
# failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
failed = server.sendmail(FROM, TO+BCC, msg.as_string())
server.quit()

