# -*- coding: utf-8 -*-
"""
Created on Wed Dec 02 13:49:05 2015

@author: rajeeshv
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
import calendar
import datetime
from pandas import ExcelWriter

ttscomplaintsdf = pd.read_csv('http://10.109.230.50/downloads/TTSComplaint/TTS_Complaints.csv')

datenow = date.today()
dateyest = datenow-timedelta(hours=24)

ttscomplaintsdf.to_csv(r'D:\\Data\\eta_rank\TTS_Complaints\\TTS_Complaints_'+str(dateyest)+'.csv',encoding='utf-8')
print 'TTS_Complaints saving done'