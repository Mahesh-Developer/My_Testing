
# coding: utf-8

# In[ ]:

import pandas as pd
from datetime import datetime
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
import pyodbc
from string import Template
from email import *
import numpy as np

today=datetime.strftime(datetime.now(),'%Y-%m-%d')
yestdate=datetime.strftime(datetime.now()-timedelta(1),'%Y-%m-%d')
print (today,yestdate)
# In[ ]:

clng_ful_df1=pd.read_csv(r'D:\Data\eta_rank\Destination_sc_closingstock\Jan2018_jun05_2018\Closing_Stock_Area_Summary_'+yestdate+'.csv')

dlry_ful_df1=pd.read_csv(r'D:\Data\eta_rank\Destination_sc_delivered\Jan2018_Jun05_2018\Delivered_Area_Summary_'+yestdate+'.csv')

fromdate=datetime.strftime(datetime.now()-timedelta(32),'%Y-%m-%d')
yestdate=datetime.strftime(datetime.now()-timedelta(1),'%Y-%m-%d')


# In[ ]:

clng_ful_df=clng_ful_df1[clng_ful_df1['Timestamp']>=fromdate]

dlry_ful_df=dlry_ful_df1[dlry_ful_df1['Timestamp']>=fromdate]


clng_ful_df.rename(columns={'ACTUWT':'Clsng_Wt'},inplace=True)
dlry_ful_df.rename(columns={'ACTUWT':'Dlry_Wt'},inplace=True)

clng_ful_df=pd.merge(clng_ful_df,dlry_ful_df,on=['DEST AREA','Timestamp'])

clng_ful_df=clng_ful_df[clng_ful_df['Timestamp']!='2018-05-01']

clng_ful_df=clng_ful_df[clng_ful_df['Timestamp']!='2018-06-15']

clng_ful_df['Timestamp']=pd.to_datetime(clng_ful_df['Timestamp'])
clng_ful_df['Day']=clng_ful_df['Timestamp'].dt.weekday


# In[ ]:

clng_ful_df=clng_ful_df[clng_ful_df['Day']!=6]
clng_ful_df['Timestamp']=clng_ful_df['Timestamp'].astype(str)
holiday_df=pd.read_csv(r'C:\Users\rajeeshv\Downloads\holidaylist.csv')
holiday_df['HDAY_DATE']=holiday_df['HDAY_DATE'].apply(lambda x: x.split(' ')[0])

cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
cursor = cnxn.cursor()


query2 = ("""
        EXEC UBESP_PUD_ANALYSIS_OPEN_CLOSE_STOCK_ARRV_DELV_SSRS_DL
        """)

dlvrydf=pd.read_sql(query2, cnxn)
dlvrydf.rename(columns={'CDELDT':'DUE DATE','DELY_DT':'DELY DT','ConStatusCode':'Con Status Code','DEL_LOCATION_TYPE':'DEL LOCATION TYPE','DEST_BRCD':'DEST BRCD','DEST_AREA':'DEST AREA'},inplace=True)

# In[ ]:
lastwk_area_dlvrydf=dlry_ful_df[dlry_ful_df['Timestamp']>=(datetime.strftime(datetime.now()-timedelta(8),"%Y-%m-%d"))]
lastwk_area_dlvrydf['Timestamp']=pd.to_datetime(lastwk_area_dlvrydf['Timestamp'])
lastwk_area_dlvrydf['Day']=lastwk_area_dlvrydf['Timestamp'].dt.weekday
lastwk_area_dlvrydf1=lastwk_area_dlvrydf[lastwk_area_dlvrydf['Day']!=6]
lastwk_area_dlvrydf1['Timestamp']=lastwk_area_dlvrydf1['Timestamp'].astype(str)

lastwk_area_dlvrydf1['Uniq_Days']=1
lastwk_area_dlvrydf1.rename(columns={'Dlry_Wt':'ACTUWT'},inplace=True)
lastwk_area_dlry_pivot=lastwk_area_dlvrydf1.pivot_table(index=['DEST AREA'],values=['ACTUWT','Uniq_Days'],aggfunc={'Uniq_Days':sum,'ACTUWT':sum}).reset_index()

lastwk_area_dlry_pivot.rename(columns={'ACTUWT':'Delivered'},inplace=True)
lastwk_area_dlry_pivot['Delivered']=pd.np.round(lastwk_area_dlry_pivot['Delivered']/1000.0,0)
lastwk_area_dlry_pivot['7Days_Dlvry(T)']=pd.np.round(lastwk_area_dlry_pivot['Delivered']/lastwk_area_dlry_pivot['Uniq_Days'],1)


clsng_df=pd.read_excel(r'http://spoton.co.in/downloads/OCID/OCID.xls',sheetname='CLOSING STOCK')
clng_pivot=clsng_df.pivot_table(index=['DEST AREA'],values=['ACTUWT'],aggfunc={'ACTUWT':sum}).reset_index()
#dlvrydf=pd.read_excel(r'http://spoton.co.in/downloads/OCID/OCID.xls',sheetname='DELIVERED')
dlry_pivot=dlvrydf.pivot_table(index=['DEST AREA'],values=['ACTUWT'],aggfunc={'ACTUWT':sum}).reset_index()
clng_pivot.rename(columns={'ACTUWT':'Closing_Stock'},inplace=True)
dlry_pivot.rename(columns={'ACTUWT':'Delivered'},inplace=True)
clng_pivot['Closing_Stock']=pd.np.round(clng_pivot['Closing_Stock']/1000.0,0)
dlry_pivot['Delivered']=pd.np.round(dlry_pivot['Delivered']/1000.0,0)
clng_pivot=pd.merge(clng_pivot,lastwk_area_dlry_pivot,on=['DEST AREA'])


clng_pivot['DaysOfStock']=pd.np.round(clng_pivot['Closing_Stock']/clng_pivot['7Days_Dlvry(T)'],1)
clng_pivot=clng_pivot.replace([np.inf,-np.inf],np.nan).fillna(0)
clng_pivot1=clng_pivot.sort_values('DaysOfStock',ascending=False)
#clng_pivot1=clng_pivot[clng_pivot['DaysOfStock']>=1.8].sort_values('Closing_Stock',ascending=False)
clng_pivot1=clng_pivot1.reset_index()
clng_pivot2=clng_pivot1.head()
del clng_pivot2['index']
clng_pivot2['Closing_Stock']=clng_pivot2['Closing_Stock'].astype(int)
del clng_pivot2['Delivered']
del clng_pivot2['Uniq_Days']

# In[ ]:

clsng_stck_sum=clsng_df['ACTUWT'].sum()/1000.0
clsng_stck_sum

deliveres_sum=dlvrydf['ACTUWT'].sum()/1000.0
deliveres_sum

national_avg_number=pd.np.round(clsng_stck_sum/deliveres_sum,1)


# In[ ]:

reportts = datetime.now()
opfilevar=reportts.date()
opfilevar1=reportts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=pd.np.round((float(currhrs)/60),0)


# In[ ]:

sc_summary=pd.read_csv(r'D:\Data\eta_rank\Destination_sc_delivered\Jan2018_Jun05_2018\Delivered_SC_Summary_'+yestdate+'.csv')
len(sc_summary)


# In[ ]:

sc_summary1=sc_summary[sc_summary['Timestamp']>=(datetime.strftime(datetime.now()-timedelta(8),"%Y-%m-%d"))]
sc_summary1['Timestamp']=pd.to_datetime(sc_summary1['Timestamp'])
sc_summary1['Day']=sc_summary1['Timestamp'].dt.weekday
sc_summary2=sc_summary1[sc_summary1['Day']!=6]
sc_summary2['Timestamp']=sc_summary2['Timestamp'].astype(str)


# In[ ]:

sc_summary2['Uniq_Days']=1


# In[ ]:

sc_clsng_stock_summary=pd.read_csv(r'D:\Data\eta_rank\Destination_sc_closingstock\Jan2018_jun05_2018\Closing_Stock_SC_Summary_'+yestdate+'.csv')


# In[ ]:

sc_summary2[sc_summary2['DEST BRCD']=='DCCU']


# In[ ]:

lastwk_sc_summary=pd.pivot_table(sc_summary2,index=['DEST BRCD'],values=['ACTUWT','Uniq_Days'],aggfunc={'ACTUWT':sum,'Uniq_Days':sum}).reset_index()
#print (lastwk_sc_summary)

lastwk_sc_summary['ACTUWT']=pd.np.round(lastwk_sc_summary['ACTUWT']/1000.0,1)

#yester closing stock sc wise

yest_Clsng_summary=clsng_df.pivot_table(index=['DEST BRCD'],values=['ACTUWT'],aggfunc={'ACTUWT':sum}).reset_index()
yest_Clsng_summary['ACTUWT']=pd.np.round(yest_Clsng_summary['ACTUWT']/1000.0,1)

yest_Clsng_summary.rename(columns={'ACTUWT':'Yest_Clsng_Wt(T)'},inplace=True)
lastwk_sc_summary.rename(columns={'ACTUWT':'7Days_Dlvry_Wt(T)'},inplace=True)


# In[ ]:

lastwk_sc_summary[lastwk_sc_summary['DEST BRCD']=='DCCU']


# In[ ]:

yest_Clsng_summary[yest_Clsng_summary['DEST BRCD']=='DCCU']


# In[ ]:

yest_Clsng_summary=pd.merge(yest_Clsng_summary,lastwk_sc_summary,on='DEST BRCD')


# In[ ]:

yest_Clsng_summary[yest_Clsng_summary['DEST BRCD']=='DCCU']


# In[ ]:

yest_Clsng_summary['7Days_Dlvry_Wt(T)']=pd.np.round(yest_Clsng_summary['7Days_Dlvry_Wt(T)']/yest_Clsng_summary['Uniq_Days'],1)

yest_Clsng_summary


# In[ ]:

yest_Clsng_summary[yest_Clsng_summary['DEST BRCD']=='DCCU']


# In[ ]:

sc_final_summary=pd.DataFrame()

for i in yest_Clsng_summary['DEST BRCD'].unique().tolist():
    result_df=yest_Clsng_summary[yest_Clsng_summary['DEST BRCD']==i]
    result_df['DaysOfStock']=pd.np.round(result_df['Yest_Clsng_Wt(T)']/result_df['7Days_Dlvry_Wt(T)'],1)
    sc_final_summary=pd.concat([sc_final_summary,result_df],ignore_index=True)




# In[ ]:

del sc_final_summary['Uniq_Days']
spacedf=pd.read_excel(r'C:\Users\rajeeshv\Downloads\Sq_ft_details.xlsx')
spacedf.rename(columns={'DEST':'DEST BRCD'},inplace=True)

# In[ ]:

import numpy as np
sc_final_summary=sc_final_summary.replace([np.inf,-np.inf],np.nan).fillna(0) 
sc_final_summary=pd.merge(sc_final_summary,spacedf,on='DEST BRCD')
sc_final_summary['Space_Util%']=pd.np.round(sc_final_summary['Yest_Clsng_Wt(T)']*100.0/sc_final_summary['Storage_capacity in Tonnes'],1)   
sc_final_summary=sc_final_summary.sort_values('DaysOfStock',ascending=False)
sc_final_summary1=sc_final_summary[['DEST BRCD','Yest_Clsng_Wt(T)','7Days_Dlvry_Wt(T)','DaysOfStock','Space_Util%']]
sc_final_summary2=sc_final_summary1.head(20)

# In[ ]:

sc_final_summary[sc_final_summary['DEST BRCD']=='DCCU']


# In[ ]:

sc_final_summary2['DaysOfStock']=pd.np.round(sc_final_summary2['DaysOfStock'],0)

# In[ ]:

sc_final_summary1


# In[ ]:
sc_final_summary1.to_csv(r'D:\Data\Day of Stock\DaysOfStock_SC'+str(opfilevar)+'.csv')
sc_final_summary1.to_csv(r'D:\Data\Day of Stock\DaysOfStock_SC.csv')

clng_pivot.to_csv(r'D:\Data\Day of Stock\DaysOfStock_Area'+str(opfilevar)+'.csv')
clng_pivot.to_csv(r'D:\Data\Day of Stock\DaysOfStock_Area.csv')

oppath1=r'D:\Data\Day of Stock\DaysOfStock_SC.csv'
oppath2=r'D:\Data\Day of Stock\DaysOfStock_Area.csv'


# In[ ]:

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.base import MIMEBase


# In[ ]:

TO=['aom_spot@spoton.co.in','dom_spot@spoton.co.in','rom_spot@spoton.co.in','sqtf@spoton.co.in']
#TO=['mahesh.reddy@spoton.co.in']
CC=['abhik.mitra@spoton.co.in','satya.pal@spoton.co.in','pawan.sharma@spoton.co.in','vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
#CC=['mahesh.reddy@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in']
FROM='reports.ie@spoton.co.in'
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "Days Of Stock Report -" + str(opfilevar)
html='''<html>
<h4>Dear All,</h4>
</html>'''
report=""
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='PFA Days Of Stock Summary'
report+='<br>'
report+='<br>'
#report+='National Average is '+str(pd.np.round(national_avg_number,1))
#report+='<br>'
#report+='<br>'
report+='Days Of Stock Area Wise'
report+='<br>'
report+='<br>'+clng_pivot2.to_html()+'<br>'
report+='Days Of Stock SC Wise.PFB Top 20 locations sorted based on Days Of Stock'
report+='<br>'
report+='<br>'+sc_final_summary2.to_html()+'<br>'
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(oppath1,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
msg.attach(part)

part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(oppath2,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath2))
msg.attach(part1)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()


# In[ ]:

#adding yester day closing stock and delivered summary to Master data

checkday=datetime.strftime(datetime.now()-timedelta(1),'%Y-%m-%d')
clsng_df['Timestamp']=datetime.strftime(datetime.now()-timedelta(1),'%Y-%m-%d')

daily_clsng_pivot=pd.pivot_table(clsng_df,index=['Timestamp','DEST AREA'],values=['ACTUWT'],aggfunc={'ACTUWT':sum}).reset_index()
dlvrydf['Timestamp']=datetime.strftime(datetime.now()-timedelta(1),'%Y-%m-%d')
daily_dlvry_pivot=pd.pivot_table(dlvrydf,index=['Timestamp','DEST AREA'],values=['ACTUWT'],aggfunc={'ACTUWT':sum}).reset_index()
clng_ful_df1=pd.concat([clng_ful_df1,daily_clsng_pivot],ignore_index=True)
dlry_ful_df1=pd.concat([dlry_ful_df1,daily_dlvry_pivot],ignore_index=True)


# In[ ]:

dlry_ful_df1.to_csv(r'D:\Data\eta_rank\Destination_sc_delivered\Jan2018_Jun05_2018\Delivered_Area_Summary_'+today+'.csv')


# In[ ]:

clng_ful_df1.to_csv(r'D:\Data\eta_rank\Destination_sc_closingstock\Jan2018_jun05_2018\Closing_Stock_Area_Summary_'+today+'.csv')


# In[ ]:

daily_dlvry_sc_pivot=pd.pivot_table(dlvrydf,index=['Timestamp','DEST BRCD'],values=['ACTUWT'],aggfunc={'ACTUWT':sum}).reset_index()


# In[ ]:

sc_summary=pd.concat([sc_summary,daily_dlvry_sc_pivot],ignore_index=True)
sc_summary


# In[ ]:

sc_summary.to_csv(r'D:\Data\eta_rank\Destination_sc_delivered\Jan2018_Jun05_2018\Delivered_SC_Summary_'+today+'.csv')


# In[ ]:

daily_clsng_sc_pivot=pd.pivot_table(clsng_df,index=['Timestamp','DEST BRCD'],values=['ACTUWT'],aggfunc={'ACTUWT':sum}).reset_index()


# In[ ]:

sc_clsng_stock_summary=pd.concat([sc_clsng_stock_summary,daily_clsng_sc_pivot],ignore_index=True)
sc_clsng_stock_summary


# In[ ]:

sc_clsng_stock_summary.to_csv(r'D:\Data\eta_rank\Destination_sc_delivered\Jan2018_Jun05_2018\Delivered_SC_Summary_'+today+'.csv')


# In[ ]:



