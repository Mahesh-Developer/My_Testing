
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta,datetime
import sys
import Utilities

reload(sys).setdefaultencoding("ISO-8859-1")
# reload(sys)
# sys.setdefaultencoding('utf8')

# In[2]:


# cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")


# # In[3]:


# cursor=cnxn.cursor()
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()

# In[4]:


query=("""EXEC dbo.USP_EWAYBILL_MIS_SQ 'B'""")


# In[5]:


#Booking Data
booking_df=pd.read_sql(query,Utilities.cnxn)


# In[6]:


len(booking_df)


# In[7]:


booking_cons=booking_df['CONS'].values[0]


# In[8]:


booking_cons


# In[9]:


query2=("""EXEC dbo.USP_EWAYBILL_MIS_SQ 'E'""")


# In[10]:


#EWAY bill cons
eway_df=pd.read_sql(query2,Utilities.cnxn)


# In[11]:


eway_df


# In[12]:


eway_cons=eway_df['CONS'].values[0]


# In[13]:


eway_cons


# In[14]:


query3=("""EXEC dbo.USP_EWAYBILL_MIS_SQ 'D'""")


# In[15]:


#con Wise details
cons_df=pd.read_sql(query3,Utilities.cnxn)


# In[16]:


len(cons_df)


# In[17]:


cons_df.head(6)


# In[18]:


cons_df.columns


# In[19]:


# cons_df.to_csv(r'C:\Users\S2769MAH\Downloads\Rajesh\cons.csv')


# In[20]:


pivot_cons_df=pd.pivot_table(cons_df,index=['ORG_AREA'],columns=['REMARKS'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Grand Total')


# In[21]:


pivot_cons_df


# In[22]:


pivot_cons_df.columns = [' '.join(col).strip() for col in pivot_cons_df.columns.values]


# In[23]:


pivot_cons_df1=pivot_cons_df.reset_index()


# In[24]:


pivot_cons_df1


# In[25]:


columns=['ORG_AREA','DOCKNO No Details Available','DOCKNO Only Part A Available','DOCKNO Part A Available, Part B Not updated','DOCKNO Part A & Part B Updated','DOCKNO Invalid Part A','DOCKNO Grand Total']


# In[26]:





# In[27]:



df_columns=pivot_cons_df1.columns
for i in columns:
    if i not in df_columns:
        pivot_cons_df1[i]=0
    else:
        pivot_cons_df1[i]=pivot_cons_df1[i]


# In[28]:


pivot_cons_df1


# In[29]:


pivot_cons_df1.rename(columns={'ORG_AREA':'Row Labels','DOCKNO No Details Available':'No Details Available','DOCKNO Only Part A Available':'Only Part A Available','DOCKNO Part A Available, Part B Not updated':'Part A Available, Part B Not updated','DOCKNO Grand Total':'Grand Total','DOCKNO Part A & Part B Updated':'Part A & Part B Updated','DOCKNO Invalid Part A':'Invalid Part A'},inplace=True)


# In[30]:


pivot_cons_df2=pivot_cons_df1.fillna(0)


# In[31]:


pivot_cons_df3=pivot_cons_df2[['Row Labels','Part A & Part B Updated','Part A Available, Part B Not updated','Only Part A Available','Invalid Part A','No Details Available','Grand Total']]


# In[32]:


pivot_cons_df3['Part A & Part B Updated']=pivot_cons_df3['Part A & Part B Updated'].astype(int)
pivot_cons_df3['Part A Available, Part B Not updated']=pivot_cons_df3['Part A Available, Part B Not updated'].astype(int)
pivot_cons_df3['Only Part A Available']=pivot_cons_df3['Only Part A Available'].astype(int)
pivot_cons_df3['Invalid Part A']=pivot_cons_df3['Invalid Part A'].astype(int)
pivot_cons_df3['No Details Available']=pivot_cons_df3['No Details Available'].astype(int)
pivot_cons_df3['Grand Total']=pivot_cons_df3['Grand Total'].astype(int)


# In[33]:


print (pivot_cons_df3)


# In[34]:


yestdate=date.today()-timedelta(1)
yest_date=datetime.strftime(yestdate,'%d-%b-%Y')
yest_date


# In[35]:


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

#TO=['mahesh.reddy@spoton.co.in','maheshmahesh11464@gmail.com']
TO=['abhik.mitra@spoton.co.in','jothi.menon@spoton.co.in','rajesh.kumar@spoton.co.in','rajesh.kapase@spoton.co.in','pawan.sharma@spoton.co.in','shivananda.p@spoton.co.in']
FROM='mis.ho@spoton.co.in'
BCC=['mahesh.reddy@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
#msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "Eway Bill MIS " + str(yest_date)
html='''<html>
<h4>Dear All,</h4>
<p>PFA below Eway bill MIS for booking cons of $date</p>
<p>Total Cons Booked =  $totalcons</p>
<p>Con Require Eway Bill =  $ewycons</p>
</html>'''
s = Template(html).safe_substitute(date=yest_date,totalcons=booking_cons,ewycons=eway_cons)
report=""
report+=s
report+='<br>'
report+='<br>'+pivot_cons_df3.to_html()+'<br>'
report+='<br>'
abc=MIMEText(report.encode('utf-8'),'html')
msg.attach(abc)
# part = MIMEBase('application', "octet-stream")
# part.set_payload( open(filePath,"rb").read() )
# encoders.encode_base64(part)
# part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
# msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+BCC, msg.as_string())
server.quit()

