
# coding: utf-8

# In[ ]:


import numpy as np
import pandas as pd
# import matplotlib.pyplot as plt
# import seaborn
from glob import glob
from IPython import display
from datetime import datetime,timedelta
import pyodbc
# import geopy
import pandas as pd
import Utilities

# In[ ]:

#try:
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

yest=datetime.now()
enddate=yest.date()
enddate=str(enddate)+' 23:59:00'

yest=datetime.now()-timedelta(16)
startdate=yest.date()
startdate=str(startdate)


pod_query=("""SELECT  CONVERT(DATE, ViewDate) VW_DATE ,
        ViewBy ,
        EMPNM ,
        COUNT(DOCKNO) CONS
FROM    espeedage.dbo.tblPODValidatorLog A WITH ( NOLOCK )
        INNER JOIN dbo.EMPMST B ON ViewBy = EMPCD
WHERE   ViewDate BETWEEN '{0}'
                 AND     '{1}'
        --AND ViewBy = '02040'
GROUP BY CONVERT(DATE, ViewDate) ,
        ViewBy ,
        EMPNM
ORDER BY 1 DESC
""").format(startdate,enddate)


# In[ ]:


query=pd.read_sql(pod_query,Utilities.cnxn)
print (len(query))
PODSummary=pd.pivot_table(query,index=["VW_DATE"],columns=["EMPNM"],aggfunc={'CONS':sum}).fillna(0)
PODSummary=PODSummary.fillna(0)
PODSummary['CONS']=PODSummary['CONS'].astype(int)

PenByPOD=pd.read_sql("""select DELIVERY_REGION, DELIVERY_DEPOT, SCAN_DATE,count(* ) cons from(
SELECT
DBR.RGALPH DELIVERY_REGION ,
        DBR.DEPOT_CODE DELIVERY_DEPOT ,
        DBR.controlarea CONTROL_AREA ,
        DBR.brcd DELIVERY_BRANCH_CODE ,
        DBR.BRNM DELIVERY_BRANCH_NAME ,
        B.DOCKNO CON_NUMBER ,
        CONVERT(VARCHAR, DKT.DOCKDT, 106) AS BOOK_DATE ,
        CONVERT(VARCHAR, B.scandate, 106) AS SCAN_DATE ,
        CASE WHEN ( PVL.DOCKNO IS NOT NULL ) THEN 'YES'
             ELSE 'NO'
        END IS_VIEWED_BY_ADMIN ,
        CONVERT(VARCHAR, PVL.VIEWDATE, 106) AS VIEWED_DATE
FROM    espeedage.DBO.SCAN_DOCKET B WITH ( NOLOCK )
        LEFT OUTER JOIN espeedage.dbo.tblPODValidatorLog PVL WITH ( NOLOCK ) ON PVL.DOCKNO = B.DOCKNO
        INNER JOIN ESTL_CRP2.DBO.DOCKET DKT WITH ( NOLOCK ) ON DKT.DOCKNO = B.DOCKNO
        INNER JOIN dbo.brms DBR WITH ( NOLOCK ) ON DKT.REASSIGN_DESTCD = DBR.BRCD
        INNER JOIN dbo.brms ORG WITH ( NOLOCK ) ON DKT.ORGNCD = ORG.BRCD
        INNER JOIN espeedage.dbo.gl_delivery GL WITH    (NOLOCK) ON    b.dockno = gl.con_id
WHERE   B.scandate BETWEEN '2018-10-28' AND  CAST(CONVERT(VARCHAR, GETDATE() -0, 112) + ' 23:59:00' AS SMALLDATETIME)
        AND pvl.DOCKNO IS null
        )X
        group by SCAN_DATE,
        DELIVERY_DEPOT,
        DELIVERY_REGION
        """,Utilities.cnxn)

print (len(PenByPOD))
# PenByPOD['Date']=pd.to_datetime(PenByPOD['SCAN_DATE'])
# PenByPOD['Check']=PenByPOD['Date'].apply(lambda x: True if x<datetime.now()-timedelta(2) else False)
# PenByPOD=PenByPOD[PenByPOD['Check']==True]

# PenByPOD['DATE']=PenByPOD['Date'].dt.date
# PenByPOD['DATE']=PenByPOD['DATE'].astype(str)
PenByPOD['Name']=PenByPOD['DELIVERY_DEPOT'].apply(lambda x: 'vinodha' if x in ['AMDD','BLRD','BOMD','CCUD','HYDD','IDRD'] else 'Malleshwari')
print (enddate)
# PenByPOD=PenByPOD[PenByPOD['DATE']<=enddate]
print ()
PendingPOD=pd.pivot_table(PenByPOD,index=["SCAN_DATE"],columns=["DELIVERY_DEPOT"],values=['cons'],aggfunc={'cons':sum},margins=True).fillna(0)
PendingPOD=PendingPOD.fillna(0)
#print (PendingPOD)
PendingPOD1=pd.pivot_table(PenByPOD,index=["SCAN_DATE"],columns=["Name","DELIVERY_DEPOT"],values=['cons'],aggfunc={'cons':sum},margins=True).fillna(0)
PendingPOD1=PendingPOD1.fillna(0)

# exit(0)
PendingPOD['cons']=PendingPOD['cons'].astype(int)
today=datetime.now()
d=today.date()


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

#TO=['vishwas.j@spoton.co.in','satya.pal@spoton.co.in','saptarshi.pathak@spoton.co.in']
#
TO=['vinodha@spoton.co.in','malleshwari.D@spoton.co.in']
FROM="mis.ho@spoton.co.in"
CC=['mahesh.reddy@spoton.co.in','anitha.thyagarajan@spoton.co.in','shivananda.p@spoton.co.in','shravani.g@spoton.co.in','sharanagouda.biradar@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = "Validated and Pending POD's Report" + " : " + str(d)
html='''<html>
<style>
p
{
  margin:0;
  margin-top: 5px;
  padding:0;
  font-size:17px;
    line-height:20px;
}
</style>
<h3>Dear All,</h3>
<p>Please Find POD's Summary.</p>
</html>'''


s = Template(html).safe_substitute()
report=""
#report+=s
#report+='<br>'+final_dff5.to_html()+'<br>'
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='Please Find POD Summary.'
report+='<br>'
report+='<br>'
report+='Validated By'
report+='<br>'
report+='<br>'+PODSummary.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='Pending POD'
report+='<br>'
report+='<br>'+PendingPOD.to_html()+'<br>'
# report+='Pending POD'
report+='<br>'
report+='<br>'
report+='<br>'+PendingPOD1.to_html()+'<br>'


abc=MIMEText(report,'html')
msg.attach(abc)
# part = MIMEBase('application', "octet-stream")
# part.set_payload( open(filePath,"rb").read() )
# encoders.encode_base64(part)
# part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
# msg.attach(part)
# part1 = MIMEBase('application', "octet-stream")
# part1.set_payload( open(filePath1,"rb").read() )
# encoders.encode_base64(part1)
# part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath1))
# msg.attach(part1)

server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
# server.login("mahesh.reddy@spoton.co.in", "Nov@2018")

failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()

# except:
#   TO=['mahesh.reddy@spoton.co.in']
#   FROM="mahesh.reddy@spoton.co.in"
#   msg = MIMEMultipart()
#   msg["From"] = FROM
#   msg["To"] = ",".join(TO)
#   #msg["CC"] = ",".join(CC)
#   #msg["BCC"] = ",".join(BCC)
#   #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
#   msg["Subject"] = "ERROR Report" 
#   report=""
#   report+='Hi,'

#   report+='<br>'
#   report+='There was some error in Validated and Pending PODs Report'
#   report+='<br>'

#   abc=MIMEText(report.encode('utf-8'),'html')
#   msg.attach(abc)
#   server=smtplib.SMTP('smtp.sendgrid.net', 587)
#   server.ehlo()
#   server.starttls()
#   server.ehlo()
#   server.login("spoton.net.in", "Star@123#")
#   failed = server.sendmail(FROM, TO, msg.as_string())
#   server.quit()

