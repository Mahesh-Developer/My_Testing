
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta,datetime
import sys
import Utilities
reload(sys).setdefaultencoding("ISO-8859-1")

# In[2]:


# cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")


# # In[3]:


# cursor=cnxn.cursor()

#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
#cursor = cnxn.cursor()


# In[4]:


query=("""EXEC USP_ORG_FEEDER_HUB_UDAN_PROJ""")


# In[5]:


udan_df=pd.read_sql(query,Utilities.cnxn)
# udan_df=pd.read_excel(r'C:\Users\S2769MAH\Downloads\udan_data.xlsx')


# In[6]:


len(udan_df)


# In[7]:


fil_udan_df=udan_df[udan_df['ControlArea'].isin(['BOMA','NCRA','BLRA','MAAA'])]


# In[8]:


len(fil_udan_df)


# In[9]:


before_df=fil_udan_df[fil_udan_df['IsAfterCutoff']=='N']
after_df=fil_udan_df[fil_udan_df['IsAfterCutoff']=='Y']
len(after_df)


# In[10]:


before_df['FINAL_FLAG'].unique()


# In[11]:


pivot_before_df=pd.pivot_table(before_df,index=['ControlArea','ORGNCD'],columns=['FINAL_FLAG'],values=['DOCKNO'],aggfunc={'DOCKNO':len},fill_value=0)


# In[12]:


pivot_before_df


# In[13]:


pivot_bf_df=pd.pivot_table(before_df,index=['ControlArea','ORGNCD'],columns=['FINAL_FLAG'],values=['DOCKNO'],aggfunc={'DOCKNO':'count'},fill_value=0,margins=True)


# In[14]:


#pivot_before_df[('DOCKNO','Feeder_Failure')]=0.0
a=(pivot_before_df.columns)
e=[]
for i in a:
    e.append(i)
print (e)
list=[('DOCKNO', 'HUB_Failure'), ('DOCKNO', 'SC_Failure'), ('DOCKNO', 'SUCCESS'),('DOCKNO', 'Feeder_Failure'),('DOCKNO', 'All')]
for i in list:
    if i in e:
        print ('y')
    else:
        pivot_before_df[i]=0.0


# In[15]:


pivot_before_df.columns = [' '.join(col).strip() for col in pivot_before_df.columns.values]


# In[16]:


pivot_before_df1=pivot_before_df.reset_index()


# In[17]:


pivot_before_df1


# In[18]:


del pivot_before_df1['DOCKNO All']


# In[19]:


boma=pivot_before_df1[pivot_before_df1['ControlArea']=='BOMA']


# In[20]:


sc_sum=boma['DOCKNO SC_Failure'].sum()
fd_sum=boma['DOCKNO Feeder_Failure'].sum()
hub_sum=boma['DOCKNO HUB_Failure'].sum()
succ_sum=boma['DOCKNO SUCCESS'].sum()
f1=['BOMA','BOMA_Total',sc_sum,fd_sum,hub_sum,succ_sum]
f2=['ControlArea','ORGNCD','DOCKNO SC_Failure','DOCKNO Feeder_Failure','DOCKNO HUB_Failure','DOCKNO SUCCESS']


# In[21]:


bomadf = pd.DataFrame(data=[f1], columns = f2)


# In[22]:


bomadf


# In[23]:


boma = pd.concat([boma,bomadf],ignore_index=True)


# In[24]:


boma


# In[25]:


blra=pivot_before_df1[pivot_before_df1['ControlArea']=='BLRA']


# In[26]:


blra_sc_sum=blra['DOCKNO SC_Failure'].sum()
blra_fd_sum=blra['DOCKNO Feeder_Failure'].sum()
blra_hub_sum=blra['DOCKNO HUB_Failure'].sum()
blra_succ_sum=blra['DOCKNO SUCCESS'].sum()
f25=['BLRA','BLRA_Total',blra_sc_sum,blra_fd_sum,blra_hub_sum,blra_succ_sum]
f26=['ControlArea','ORGNCD','DOCKNO SC_Failure','DOCKNO Feeder_Failure','DOCKNO HUB_Failure','DOCKNO SUCCESS']


# In[27]:


blradf = pd.DataFrame(data=[f25], columns = f26)


# In[28]:


blra = pd.concat([blra,blradf],ignore_index=True)


# In[29]:


blra


# In[30]:


maaa=pivot_before_df1[pivot_before_df1['ControlArea']=='MAAA']


# In[31]:


maaa_sc_sum=maaa['DOCKNO SC_Failure'].sum()
maaa_fd_sum=maaa['DOCKNO Feeder_Failure'].sum()
maaa_hub_sum=maaa['DOCKNO HUB_Failure'].sum()
maaa_succ_sum=maaa['DOCKNO SUCCESS'].sum()
f27=['MAAA','MAAA_Total',maaa_sc_sum,maaa_fd_sum,maaa_hub_sum,maaa_succ_sum]
f28=['ControlArea','ORGNCD','DOCKNO SC_Failure','DOCKNO Feeder_Failure','DOCKNO HUB_Failure','DOCKNO SUCCESS']


# In[32]:


maaadf = pd.DataFrame(data=[f27], columns = f28)


# In[33]:


maaa = pd.concat([maaa,maaadf],ignore_index=True)


# In[34]:


maaa


# In[35]:


ncra=pivot_before_df1[pivot_before_df1['ControlArea']=='NCRA']


# In[36]:


ncra_sc_sum=ncra['DOCKNO SC_Failure'].sum()
ncra_fd_sum=ncra['DOCKNO Feeder_Failure'].sum()
ncra_hub_sum=ncra['DOCKNO HUB_Failure'].sum()
ncra_succ_sum=ncra['DOCKNO SUCCESS'].sum()
f3=['NCRA','NCRA_Total',ncra_sc_sum,ncra_fd_sum,ncra_hub_sum,ncra_succ_sum]
f4=['ControlArea','ORGNCD','DOCKNO SC_Failure','DOCKNO Feeder_Failure','DOCKNO HUB_Failure','DOCKNO SUCCESS']


# In[37]:


ncradf = pd.DataFrame(data=[f3], columns = f4)


# In[38]:


ncradf


# In[39]:


ncra = pd.concat([ncra,ncradf],ignore_index=True)


# In[40]:


boma = pd.concat([blra,boma,maaa,ncra],ignore_index=True)


# In[41]:


boma


# In[42]:


g_sc_sum=sc_sum+ncra_sc_sum+blra_sc_sum+maaa_sc_sum
g_fd_sum=fd_sum+ncra_fd_sum+blra_fd_sum+maaa_fd_sum
g_hub_sum=ncra_hub_sum+hub_sum+blra_hub_sum+maaa_hub_sum
g_succ_sum=ncra_succ_sum+succ_sum+blra_succ_sum+maaa_succ_sum
f5=['Grand','Total',g_sc_sum,g_fd_sum,g_hub_sum,g_succ_sum]
f6=['ControlArea','ORGNCD','DOCKNO SC_Failure','DOCKNO Feeder_Failure','DOCKNO HUB_Failure','DOCKNO SUCCESS']


# In[43]:


granddf = pd.DataFrame(data=[f5], columns = f6)


# In[44]:


granddf


# In[45]:


boma = pd.concat([boma,granddf],ignore_index=True)


# In[46]:


boma=boma[['ControlArea','ORGNCD','DOCKNO SC_Failure','DOCKNO Feeder_Failure','DOCKNO HUB_Failure','DOCKNO SUCCESS']]


# In[47]:


boma.rename(columns={'DOCKNO SC_Failure':'SC_Failure','DOCKNO Feeder_Failure':'Feeder_Failure','DOCKNO HUB_Failure':'HUB_Failure','DOCKNO SUCCESS':'SUCCESS'},inplace=True)


# In[48]:


boma


# In[49]:


pivot_after_df=pd.pivot_table(after_df,index=['ControlArea','ORGNCD'],columns=['FINAL_FLAG'],values=['DOCKNO'],aggfunc={'DOCKNO':'count'},fill_value=0)


# In[50]:


#pivot_before_df[('DOCKNO','Feeder_Failure')]=0.0
x=(pivot_after_df.columns)
y=[]
for i in x:
    y.append(i)
print (y)
list=[('DOCKNO', 'HUB_Failure'), ('DOCKNO', 'SC_Failure'), ('DOCKNO', 'SUCCESS'),('DOCKNO', 'Feeder_Failure'),('DOCKNO', 'All')]
for i in list:
    if i in y:
        print ('y')
    else:
        pivot_after_df[i]=0.0


# In[51]:


pivot_after_df.columns = [' '.join(col).strip() for col in pivot_after_df.columns.values]


# In[52]:


pivot_after_df1=pivot_after_df.reset_index()


# In[53]:


del pivot_after_df1['DOCKNO All']


# In[54]:


after_boma=pivot_after_df1[pivot_after_df1['ControlArea']=='BOMA']


# In[55]:


after_boma


# In[56]:


after_boma_sc_sum=after_boma['DOCKNO SC_Failure'].sum()
after_boma_fd_sum=after_boma['DOCKNO Feeder_Failure'].sum()
after_boma_hub_sum=after_boma['DOCKNO HUB_Failure'].sum()
after_boma_succ_sum=after_boma['DOCKNO SUCCESS'].sum()
f7=['BOMA','BOMA_Total',after_boma_sc_sum,after_boma_fd_sum,after_boma_hub_sum,after_boma_succ_sum]
f8=['ControlArea','ORGNCD','DOCKNO SC_Failure','DOCKNO Feeder_Failure','DOCKNO HUB_Failure','DOCKNO SUCCESS']


# In[57]:


after_boma_df=pd.DataFrame(data=[f7],columns=f8)


# In[58]:


after_boma=pd.concat([after_boma,after_boma_df],ignore_index=True)


# In[59]:


after_blra=pivot_after_df1[pivot_after_df1['ControlArea']=='BLRA']


# In[60]:


after_blra_sc_sum=after_blra['DOCKNO SC_Failure'].sum()
after_blra_fd_sum=after_blra['DOCKNO Feeder_Failure'].sum()
after_blra_hub_sum=after_blra['DOCKNO HUB_Failure'].sum()
after_blra_succ_sum=after_blra['DOCKNO SUCCESS'].sum()
f29=['BLRA','BLRA_Total',after_blra_sc_sum,after_blra_fd_sum,after_blra_hub_sum,after_blra_succ_sum]
f30=['ControlArea','ORGNCD','DOCKNO SC_Failure','DOCKNO Feeder_Failure','DOCKNO HUB_Failure','DOCKNO SUCCESS']


# In[61]:


after_blra_df=pd.DataFrame(data=[f29],columns=f30)


# In[62]:


after_blra=pd.concat([after_blra,after_blra_df],ignore_index=True)


# In[63]:


after_maaa=pivot_after_df1[pivot_after_df1['ControlArea']=='MAAA']


# In[64]:


after_maaa_sc_sum=after_maaa['DOCKNO SC_Failure'].sum()
after_maaa_fd_sum=after_maaa['DOCKNO Feeder_Failure'].sum()
after_maaa_hub_sum=after_maaa['DOCKNO HUB_Failure'].sum()
after_maaa_succ_sum=after_maaa['DOCKNO SUCCESS'].sum()
f31=['MAAA','MAAA_Total',after_maaa_sc_sum,after_maaa_fd_sum,after_maaa_hub_sum,after_maaa_succ_sum]
f32=['ControlArea','ORGNCD','DOCKNO SC_Failure','DOCKNO Feeder_Failure','DOCKNO HUB_Failure','DOCKNO SUCCESS']


# In[65]:


after_maaa_df=pd.DataFrame(data=[f31],columns=f32)


# In[66]:


after_maaa=pd.concat([after_maaa,after_maaa_df],ignore_index=True)


# In[67]:


after_ncra=pivot_after_df1[pivot_after_df1['ControlArea']=='NCRA']


# In[68]:


after_ncra_sc_sum=after_ncra['DOCKNO SC_Failure'].sum()
after_ncra_fd_sum=after_ncra['DOCKNO Feeder_Failure'].sum()
after_ncra_hub_sum=after_ncra['DOCKNO HUB_Failure'].sum()
after_ncra_succ_sum=after_ncra['DOCKNO SUCCESS'].sum()
f9=['NCRA','NCRA_Total',after_ncra_sc_sum,after_ncra_fd_sum,after_ncra_hub_sum,after_ncra_succ_sum]
f10=['ControlArea','ORGNCD','DOCKNO SC_Failure','DOCKNO Feeder_Failure','DOCKNO HUB_Failure','DOCKNO SUCCESS']


# In[69]:


after_ncra_df=pd.DataFrame(data=[f9],columns=f10)


# In[70]:


after_ncra_df


# In[71]:


after_ncra


# In[72]:


after_ncra=pd.concat([after_ncra,after_ncra_df],ignore_index=True)


# In[73]:


after_ncra


# In[74]:


after_boma=pd.concat([after_blra,after_boma,after_maaa,after_ncra],ignore_index=True)


# In[75]:


after_boma


# In[76]:


after_grand_sc_sum=after_boma_sc_sum+after_ncra_sc_sum+after_blra_sc_sum+after_maaa_sc_sum
after_grand_fd_sum=after_boma_fd_sum+after_ncra_fd_sum+after_blra_fd_sum+after_maaa_fd_sum
after_grand_hub_sum=after_boma_hub_sum+after_ncra_hub_sum+after_blra_hub_sum+after_maaa_hub_sum
after_grand_succ_sum=after_boma_succ_sum+after_ncra_succ_sum+after_blra_succ_sum+after_maaa_succ_sum
f11=['Grand','Total',after_grand_sc_sum,after_grand_fd_sum,after_grand_hub_sum,after_grand_succ_sum]
f12=['ControlArea','ORGNCD','DOCKNO SC_Failure','DOCKNO Feeder_Failure','DOCKNO HUB_Failure','DOCKNO SUCCESS']


# In[77]:


after_grand_df=pd.DataFrame(data=[f11],columns=f12)


# In[78]:


after_boma=pd.concat([after_boma,after_grand_df],ignore_index=True)


# In[79]:


after_boma=after_boma[['ControlArea','ORGNCD','DOCKNO SC_Failure','DOCKNO Feeder_Failure','DOCKNO HUB_Failure','DOCKNO SUCCESS']]


# In[80]:


after_boma.rename(columns={'DOCKNO SC_Failure':'SC_Failure','DOCKNO Feeder_Failure':'Feeder_Failure','DOCKNO HUB_Failure':'HUB_Failure','DOCKNO SUCCESS':'SUCCESS'},inplace=True)


# In[81]:


after_boma


# In[82]:


#pivot_before_df[('DOCKNO','Feeder_Failure')]=0.0
b=(pivot_bf_df.columns)
f=[]
for i in b:
    f.append(i)
print (b)
list1=[('DOCKNO', 'HUB_Failure'), ('DOCKNO', 'SC_Failure'), ('DOCKNO', 'SUCCESS'),('DOCKNO', 'Feeder_Failure'),('DOCKNO', 'All')]
for i in list1:
    if i in f:
        print ('y')
    else:
        pivot_bf_df[i]=0.0


# In[83]:


pivot_bf_df1=pivot_bf_df.reindex_axis(['SC_Failure', 'Feeder_Failure', 'HUB_Failure','SUCCESS','All'], axis=1, level='FINAL_FLAG')
pivot_bf_df1


# In[84]:


# pivot_before_df1=pd.concat(
#     [pivot_before_df1, tab_tots]
# ).sort_index().append(
#     pivot_before_df1.sum().rename(('Grand', 'Total'))
# )


# In[85]:


pivot_bf_df.columns = [' '.join(col).strip() for col in pivot_bf_df.columns.values]


# In[86]:


pivot_bf_df1=pivot_bf_df.reset_index()


# In[87]:


pivot_bf_df1=pivot_bf_df1[pivot_bf_df1['ControlArea']!='All']


# In[88]:


per_boma=pivot_bf_df1[pivot_bf_df1['ControlArea']=='BOMA']


# In[89]:


per_boma_sc_sum=per_boma['DOCKNO SC_Failure'].sum()
per_boma_fd_sum=per_boma['DOCKNO Feeder_Failure'].sum()
per_boma_hub_sum=per_boma['DOCKNO HUB_Failure'].sum()
per_boma_succ_sum=per_boma['DOCKNO SUCCESS'].sum()
per_boma_all_sum=per_boma['DOCKNO All'].sum()
d1=['BOMA','BOMA_Total',per_boma_sc_sum,per_boma_fd_sum,per_boma_hub_sum,per_boma_succ_sum,per_boma_all_sum]
d2=['ControlArea','ORGNCD','DOCKNO SC_Failure','DOCKNO Feeder_Failure','DOCKNO HUB_Failure','DOCKNO SUCCESS','DOCKNO All']


# In[90]:


per_total_df=pd.DataFrame(data=[d1],columns=d2)


# In[91]:


per_total_df


# In[92]:


per_boma=pd.concat([per_boma,per_total_df],ignore_index=True)


# In[93]:


# per_boma['SC_Failure%']=pd.np.round(per_boma['DOCKNO SC_Failure']*100.0/per_boma['DOCKNO All'],1).astype(str)+'%'
# per_boma['Feeder_Failure%']=pd.np.round(per_boma['DOCKNO Feeder_Failure']*100.0/per_boma['DOCKNO All'],1).astype(str)+'%'
# per_boma['HUB_Failure%']=pd.np.round(per_boma['DOCKNO HUB_Failure']*100.0/per_boma['DOCKNO All'],1).astype(str)+'%'
# per_boma['SUCCESS%']=pd.np.round(per_boma['DOCKNO SUCCESS']*100.0/per_boma['DOCKNO All'],1).astype(str)+'%'
#per_boma['SC_Failure%']=pd.np.round(per_boma['DOCKNO SC_Failure']*100.0/per_boma['DOCKNO All'],1).astype(str)+'%'


# In[94]:


per_boma


# In[95]:


per_ncra=pivot_bf_df1[pivot_bf_df1['ControlArea']=='NCRA']


# In[96]:


per_ncra_sc_sum=per_ncra['DOCKNO SC_Failure'].sum()
per_ncra_fd_sum=per_ncra['DOCKNO Feeder_Failure'].sum()
per_ncra_hub_sum=per_ncra['DOCKNO HUB_Failure'].sum()
per_ncra_succ_sum=per_ncra['DOCKNO SUCCESS'].sum()
per_ncra_all_sum=per_ncra['DOCKNO All'].sum()
d3=['NCRA','NCRA_Total',per_ncra_sc_sum,per_ncra_fd_sum,per_ncra_hub_sum,per_ncra_succ_sum,per_ncra_all_sum]
d4=['ControlArea','ORGNCD','DOCKNO SC_Failure','DOCKNO Feeder_Failure','DOCKNO HUB_Failure','DOCKNO SUCCESS','DOCKNO All']


# In[97]:


per_ncra_df=pd.DataFrame(data=[d3],columns=d4)


# In[98]:


per_ncra=pd.concat([per_ncra,per_ncra_df],ignore_index=True)


# In[99]:


per_blra=pivot_bf_df1[pivot_bf_df1['ControlArea']=='BLRA']


# In[100]:


per_blra_sc_sum=per_blra['DOCKNO SC_Failure'].sum()
per_blra_fd_sum=per_blra['DOCKNO Feeder_Failure'].sum()
per_blra_hub_sum=per_blra['DOCKNO HUB_Failure'].sum()
per_blra_succ_sum=per_blra['DOCKNO SUCCESS'].sum()
per_blra_all_sum=per_blra['DOCKNO All'].sum()
d23=['BLRA','BLRA_Total',per_blra_sc_sum,per_blra_fd_sum,per_blra_hub_sum,per_blra_succ_sum,per_blra_all_sum]
d24=['ControlArea','ORGNCD','DOCKNO SC_Failure','DOCKNO Feeder_Failure','DOCKNO HUB_Failure','DOCKNO SUCCESS','DOCKNO All']


# In[101]:


per_blra_df=pd.DataFrame(data=[d23],columns=d24)


# In[102]:


per_blra=pd.concat([per_blra,per_blra_df],ignore_index=True)


# In[103]:


per_maaa=pivot_bf_df1[pivot_bf_df1['ControlArea']=='MAAA']


# In[104]:


per_maaa_sc_sum=per_maaa['DOCKNO SC_Failure'].sum()
per_maaa_fd_sum=per_maaa['DOCKNO Feeder_Failure'].sum()
per_maaa_hub_sum=per_maaa['DOCKNO HUB_Failure'].sum()
per_maaa_succ_sum=per_maaa['DOCKNO SUCCESS'].sum()
per_maaa_all_sum=per_maaa['DOCKNO All'].sum()
d25=['MAAA','MAAA_Total',per_maaa_sc_sum,per_maaa_fd_sum,per_maaa_hub_sum,per_maaa_succ_sum,per_maaa_all_sum]
d26=['ControlArea','ORGNCD','DOCKNO SC_Failure','DOCKNO Feeder_Failure','DOCKNO HUB_Failure','DOCKNO SUCCESS','DOCKNO All']


# In[105]:


per_maaa_df=pd.DataFrame(data=[d25],columns=d26)


# In[106]:


per_maaa=pd.concat([per_maaa,per_maaa_df],ignore_index=True)


# In[107]:


per_boma=pd.concat([per_blra,per_boma,per_maaa,per_ncra],ignore_index=True)


# In[108]:


per_boma


# In[109]:


per_grand_sc_sum=per_boma_sc_sum+per_ncra_sc_sum+per_blra_sc_sum+per_maaa_sc_sum
per_grand_fd_sum=per_boma_fd_sum+per_ncra_fd_sum+per_blra_fd_sum+per_maaa_fd_sum
per_grand_hub_sum=per_boma_hub_sum+per_ncra_hub_sum+per_blra_hub_sum+per_maaa_hub_sum
per_grand_succ_sum=per_boma_succ_sum+per_ncra_succ_sum+per_blra_succ_sum+per_maaa_succ_sum
per_grand_all_sum=per_boma_all_sum+per_ncra_all_sum+per_blra_all_sum+per_maaa_all_sum
d5=['Grand','Total',per_grand_sc_sum,per_grand_fd_sum,per_grand_hub_sum,per_grand_succ_sum,per_grand_all_sum]
d6=['ControlArea','ORGNCD','DOCKNO SC_Failure','DOCKNO Feeder_Failure','DOCKNO HUB_Failure','DOCKNO SUCCESS','DOCKNO All']


# In[110]:


per_grand_df=pd.DataFrame(data=[d5],columns=d6)


# In[111]:


per_boma=pd.concat([per_boma,per_grand_df],ignore_index=True)


# In[112]:


per_boma


# In[113]:


per_boma['SC_Failure%']=pd.np.round(per_boma['DOCKNO SC_Failure']*100.0/per_boma['DOCKNO All'],1).astype(str)+'%'
per_boma['Feeder_Failure%']=pd.np.round(per_boma['DOCKNO Feeder_Failure']*100.0/per_boma['DOCKNO All'],1).astype(str)+'%'
per_boma['HUB_Failure%']=pd.np.round(per_boma['DOCKNO HUB_Failure']*100.0/per_boma['DOCKNO All'],1).astype(str)+'%'
per_boma['SUCCESS%']=pd.np.round(per_boma['DOCKNO SUCCESS']*100.0/per_boma['DOCKNO All'],1).astype(str)+'%'
# per_boma['SC_Failure%']=pd.np.round(per_boma['DOCKNO SC_Failure']*100.0/per_boma['DOCKNO All'],1).astype(str)+'%'


# In[114]:


per_boma


# In[115]:


per_before_df=per_boma[['ControlArea','ORGNCD','SC_Failure%','Feeder_Failure%','HUB_Failure%','SUCCESS%']]


# In[116]:


per_before_df


# In[117]:


pivot_aftr_df=pd.pivot_table(after_df,index=['ControlArea','ORGNCD'],columns=['FINAL_FLAG'],values=['DOCKNO'],aggfunc={'DOCKNO':'count'},fill_value=0,margins=True)


# In[118]:


#pivot_before_df[('DOCKNO','Feeder_Failure')]=0.0
c=(pivot_aftr_df.columns)
s=[]
for i in c:
    s.append(i)
print (c)
list1=[('DOCKNO', 'HUB_Failure'), ('DOCKNO', 'SC_Failure'), ('DOCKNO', 'SUCCESS'),('DOCKNO', 'Feeder_Failure'),('DOCKNO', 'All')]
for i in list1:
    if i in s:
        print ('y')
    else:
        pivot_aftr_df[i]=0.0


# In[119]:


pivot_aftr_df.columns = [' '.join(col).strip() for col in pivot_aftr_df.columns.values]


# In[120]:


pivot_aftr_df1=pivot_aftr_df.reset_index()


# In[121]:


per_aftr_df1=pivot_aftr_df1[pivot_aftr_df1['ControlArea']!='All']


# In[122]:


per_after_boma=per_aftr_df1[per_aftr_df1['ControlArea']=='BOMA']


# In[123]:


per_after_boma_sc_sum=per_after_boma['DOCKNO SC_Failure'].sum()
per_after_boma_fd_sum=per_after_boma['DOCKNO Feeder_Failure'].sum()
per_after_boma_hub_sum=per_after_boma['DOCKNO HUB_Failure'].sum()
per_after_boma_succ_sum=per_after_boma['DOCKNO SUCCESS'].sum()
per_after_boma_all_sum=per_after_boma['DOCKNO All'].sum()
d7=['BOMA','BOMA_Total',per_after_boma_sc_sum,per_after_boma_fd_sum,per_after_boma_hub_sum,per_after_boma_succ_sum,per_after_boma_all_sum]
d8=['ControlArea','ORGNCD','DOCKNO SC_Failure','DOCKNO Feeder_Failure','DOCKNO HUB_Failure','DOCKNO SUCCESS','DOCKNO All']


# In[124]:


per_after_boma_df=pd.DataFrame(data=[d7],columns=d8)


# In[125]:


per_after_boma=pd.concat([per_after_boma,per_after_boma_df],ignore_index=True)


# In[126]:


per_after_blra=per_aftr_df1[per_aftr_df1['ControlArea']=='BLRA']


# In[127]:


per_after_blra_sc_sum=per_after_blra['DOCKNO SC_Failure'].sum()
per_after_blra_fd_sum=per_after_blra['DOCKNO Feeder_Failure'].sum()
per_after_blra_hub_sum=per_after_blra['DOCKNO HUB_Failure'].sum()
per_after_blra_succ_sum=per_after_blra['DOCKNO SUCCESS'].sum()
per_after_blra_all_sum=per_after_blra['DOCKNO All'].sum()
d27=['BLRA','BLRA_Total',per_after_blra_sc_sum,per_after_blra_fd_sum,per_after_blra_hub_sum,per_after_blra_succ_sum,per_after_blra_all_sum]
d28=['ControlArea','ORGNCD','DOCKNO SC_Failure','DOCKNO Feeder_Failure','DOCKNO HUB_Failure','DOCKNO SUCCESS','DOCKNO All']


# In[128]:


per_after_blra_df=pd.DataFrame(data=[d27],columns=d28)


# In[129]:


per_after_blra=pd.concat([per_after_blra,per_after_blra_df],ignore_index=True)


# In[130]:


per_after_maaa=per_aftr_df1[per_aftr_df1['ControlArea']=='MAAA']


# In[131]:


per_after_maaa_sc_sum=per_after_maaa['DOCKNO SC_Failure'].sum()
per_after_maaa_fd_sum=per_after_maaa['DOCKNO Feeder_Failure'].sum()
per_after_maaa_hub_sum=per_after_maaa['DOCKNO HUB_Failure'].sum()
per_after_maaa_succ_sum=per_after_maaa['DOCKNO SUCCESS'].sum()
per_after_maaa_all_sum=per_after_maaa['DOCKNO All'].sum()
d29=['MAAA','MAAA_Total',per_after_maaa_sc_sum,per_after_maaa_fd_sum,per_after_maaa_hub_sum,per_after_maaa_succ_sum,per_after_maaa_all_sum]
d30=['ControlArea','ORGNCD','DOCKNO SC_Failure','DOCKNO Feeder_Failure','DOCKNO HUB_Failure','DOCKNO SUCCESS','DOCKNO All']


# In[132]:


per_after_maaa_df=pd.DataFrame(data=[d29],columns=d30)


# In[133]:


per_after_maaa=pd.concat([per_after_maaa,per_after_maaa_df],ignore_index=True)


# In[134]:


per_after_ncra=per_aftr_df1[per_aftr_df1['ControlArea']=='NCRA']


# In[135]:


per_after_ncra_sc_sum=per_after_ncra['DOCKNO SC_Failure'].sum()
per_after_ncra_fd_sum=per_after_ncra['DOCKNO Feeder_Failure'].sum()
per_after_ncra_hub_sum=per_after_ncra['DOCKNO HUB_Failure'].sum()
per_after_ncra_succ_sum=per_after_ncra['DOCKNO SUCCESS'].sum()
per_after_ncra_all_sum=per_after_ncra['DOCKNO All'].sum()
d9=['NCRA','NCRA_Total',per_after_ncra_sc_sum,per_after_ncra_fd_sum,per_after_ncra_hub_sum,per_after_ncra_succ_sum,per_after_ncra_all_sum]
d10=['ControlArea','ORGNCD','DOCKNO SC_Failure','DOCKNO Feeder_Failure','DOCKNO HUB_Failure','DOCKNO SUCCESS','DOCKNO All']


# In[136]:


per_after_ncra_df=pd.DataFrame(data=[d9],columns=d10)


# In[137]:


per_after_ncra=pd.concat([per_after_ncra,per_after_ncra_df],ignore_index=True)


# In[138]:


per_after_boma=pd.concat([per_after_blra,per_after_boma,per_after_maaa,per_after_ncra],ignore_index=True)


# In[139]:


per_after_boma


# In[140]:


per_after_grand_sc_sum=per_after_boma_sc_sum+per_after_ncra_sc_sum+per_after_blra_sc_sum+per_after_maaa_sc_sum
per_after_grand_fd_sum=per_after_boma_fd_sum+per_after_ncra_fd_sum+per_after_blra_fd_sum+per_after_maaa_fd_sum
per_after_grand_hub_sum=per_after_boma_hub_sum+per_after_ncra_hub_sum+per_after_blra_hub_sum+per_after_maaa_hub_sum
per_after_grand_succ_sum=per_after_boma_succ_sum+per_after_ncra_succ_sum+per_after_blra_succ_sum+per_after_maaa_succ_sum
per_after_grand_all_sum=per_after_boma_all_sum+per_after_ncra_all_sum+per_after_blra_all_sum+per_after_maaa_all_sum
d11=['Grand','Total',per_after_grand_sc_sum,per_after_grand_fd_sum,per_after_grand_hub_sum,per_after_grand_succ_sum,per_after_grand_all_sum]
d12=['ControlArea','ORGNCD','DOCKNO SC_Failure','DOCKNO Feeder_Failure','DOCKNO HUB_Failure','DOCKNO SUCCESS','DOCKNO All']


# In[141]:


per_after_grand_df=pd.DataFrame(data=[d11],columns=d12)


# In[142]:


per_after_grand_df


# In[143]:


per_after_boma=pd.concat([per_after_boma,per_after_grand_df],ignore_index=True)


# In[144]:


per_after_boma


# In[145]:


per_after_boma['SC_Failure%']=pd.np.round(per_after_boma['DOCKNO SC_Failure']*100.0/per_after_boma['DOCKNO All'],1).astype(str)+'%'
per_after_boma['Feeder_Failure%']=pd.np.round(per_after_boma['DOCKNO Feeder_Failure']*100.0/per_after_boma['DOCKNO All'],1).astype(str)+'%'
per_after_boma['HUB_Failure%']=pd.np.round(per_after_boma['DOCKNO HUB_Failure']*100.0/per_after_boma['DOCKNO All'],1).astype(str)+'%'
per_after_boma['SUCCESS%']=pd.np.round(per_after_boma['DOCKNO SUCCESS']*100.0/per_after_boma['DOCKNO All'],1).astype(str)+'%'
#per_boma['SC_Failure%']=pd.np.round(per_boma['DOCKNO SC_Failure']*100.0/per_boma['DOCKNO All'],1).astype(str)+'%'


# In[146]:


per_after_boma1=per_after_boma[['ControlArea','ORGNCD','SC_Failure%','Feeder_Failure%','HUB_Failure%','SUCCESS%']]


# In[147]:


#C:\Users\S2769MAH\Downloads\SQ\sreedhar\Origin_Feeder_Connection_report_'+str(date2)+'.xlsx') as writer:
from pandas import ExcelWriter
with ExcelWriter(r'D:\Data\ODA_Loads_Ton_wise\BOMA&NCRA_Udaan_performance_report.xlsx') as writer:
    boma.to_excel(writer,engine='xlsxwriter',sheet_name='Before Cutoff')
    per_before_df.to_excel(writer,engine='xlsxwriter',sheet_name='%Wise Before Cutoff')
    after_boma.to_excel(writer,engine='xlsxwriter',sheet_name='After Cutoff')
    per_after_boma1.to_excel(writer,engine='xlsxwriter',sheet_name='%Wise After Cutoff')
    fil_udan_df.to_excel(writer,engine='xlsxwriter',sheet_name='Data')
    
    
    


# In[121]:


filepath=r'D:\Data\ODA_Loads_Ton_wise\BOMA&NCRA_Udaan_performance_report.xlsx'


# In[149]:


import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback

oppath1=filepath
#FTP Upload starts
print ('Logging in...')
ftp = ftplib.FTP()  
ftp.connect('10.109.230.50')  
print (ftp.getwelcome())
try:  
    try:  
        ftp.login('HOSQTeam', 'Te@mH0$q')
        print ('login done')
        ftp.cwd('Auto_reports')  
        #ftp.cwd('FIFO')
        # move to the desired upload directory  
        print ("Currently in:", ftp.pwd()) 
        print ('Uploading...')  
        fullname = oppath1
        name = os.path.split(fullname)[1]  
        f = open(fullname, "rb")  
        ftp.storbinary('STOR ' + name, f)  
        f.close()  
        print ("OK"  )
        print ("Files:")  
        print (ftp.retrlines('LIST'))
    finally:  
        print ("Quitting...")
        ftp.quit()  
except:  
    traceback.print_exc()


# In[150]:


from datetime import date,timedelta
d=date.today()
print (type(d))
date1=d-timedelta(1)
date2=datetime.strftime(date1,'%d-%b-%y')


# In[151]:


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

from_addr = 'mis.ho@spoton.co.in'
#to_addr = ['rajesh.debnath@spoton.co.in','dinesh.kumar.sharma@Spoton.co.in']
#to_addr = ['maheshmahesh11464@gmail.com','mahesh.reddy@spoton.co.in']
cc_addr=['abhik.mitra@spoton.co.in','jothi.menon@spoton.co.in','Rajesh.kumar@spoton.co.in','shivananda.p@spoton.co.in','prafulla.masurkar@spoton.co.in','vijay.verma@spoton.co.in','sharanagouda.biradar@spoton.co.in','sreedhar.m@spoton.co.in','SQ_spot@spoton.co.in','anitha.thyagarajan@spoton.co.in']
bcc_addr=['rajesh.debnath@spoton.co.in','harish.bobade@spoton.co.in','sandeep.deshpande@spoton.co.in','naresh.patil@spoton.co.in','sanjay.parab@spoton.co.in','dinesh.kumar.sharma@spoton.co.in','Mahesh.Srivastava@spoton.co.in','umesh.shah@spoton.co.in','Chandra.prakash@spoton.co.in','dominic.sathish@spoton.co.in','sanjeeva.p@spoton.co.in','anand.kr@spoton.co.in','sanjay.padhy@spoton.co.in','sasikumar.kannan@spoton.co.in','joseph.arul.seelan@spoton.co.in','renugopal.l@spoton.co.in','uma.chandran@spoton.co.in','v.vinayakam@spoton.co.in']
#cc_addr = ['rajesh.mp@spoton.co.in']




msg = MIMEMultipart()

msg['From'] = from_addr
#msg['To'] = ', '.join(to_addr)
msg['cc'] = ', '.join(cc_addr)
msg['bcc'] = ', '.join(bcc_addr)
msg['Subject'] = 'BLRA,BOMA,MAAA and NCRA Udaan performance report of'+str(date2)
html='''<html>
<h4>Dear All,</h4>
<p>Please find below BLRA,BOMA,MAAA and NCRA Udaan performance report of before and after cutoff time pick up cons for your reference and necessary action.</p>
<h5>Before Cutoff cons Summary</h5>
<p style="color:red;">Count Wise Performance .</p>
</html>'''
html2='''
<p style="color:red;">  % Wise Summary .</p>'''
html3='''
<h5>After Cutoff cons Summary</h5>
<p style="color:red;">Count Wise Performance .</p>
'''

html5='''
<h5> Note : For data please click on the below link: </h5>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/BOMA&NCRA_Udaan_performance_report.xlsx"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/BOMA&NCRA_Udaan_performance_report.xlsx</p></b>
'''
html4='''
<p style="color:red;"> % Wise Performance</p>'''
html1='''<h5>Thanks & Regards</h5></b>
<h5>HO-SQ</h5>'''
    
#  msg.attach(part10)
s = Template(html).safe_substitute(date=date2)
report=""
report+=s
report+='<br>'
# report+='<br>'
report+='<br>'+boma.to_html()+'<br>'
report+='<br>'
report+=html2
report+='<br>'+per_before_df.to_html()+'<br>'
report+='<br>'
report+=html3
report+='<br>'
report+='<br>'+after_boma.to_html()+'<br>'
report+=html4
report+='<br>'
report+='<br>'+per_after_boma1.to_html()+'<br>'
report+='<br>'
report+=html5
report+='<br>'
report+=html1
abc=MIMEText(report,'html')
msg.attach(abc)
server = smtplib.SMTP('smtp.sendgrid.net',587)
part=MIMEBase('application','octet-stream')
# part1=MIMEBase('application','octet-stream')
part.set_payload(open(filepath,'rb').read())
# part1.set_payload(open(filepath1,'rb').read())
encoders.encode_base64(part)
# Encoders.encode_base64(part1)
part.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath))
# part1.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath1))
#msg.attach(part)
# msg.attach(part1)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
server.sendmail(from_addr,cc_addr+bcc_addr,msg.as_string())
print ('mail sent succesfully')
server.quit()

