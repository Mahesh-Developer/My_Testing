
# coding: utf-8

# In[7]:


import pandas as pd
import numpy as np
from datetime import datetime,timedelta


# In[2]:


closing_df=pd.read_excel(r'http://spoton.co.in/downloads/OCID_CLOSINGSTOCK_1HR/OCID_CLOSINGSTOCK_1HR.xls')
len(closing_df)


# In[3]:


intransit_df=pd.read_excel(r'http://spoton.co.in/downloads/TCR_UND_2HRS/TCR_UND_ISDEPART_YES_2HRS.xls')
len(intransit_df)


# In[4]:


inventory_df=pd.read_excel(r'http://spoton.co.in/downloads/HTR_1HR/HTR_1HR.xls')
len(inventory_df)


# In[5]:


timestamp=datetime.strftime(datetime.now(),'%Y-%m-%d.%H')
timestamp


# In[8]:


start="'"+datetime.strftime(datetime.now()-timedelta(days=57),"%Y-%m-%d")+"'"
end="'"+datetime.strftime(datetime.now(),"%Y-%m-%d")+"'"
print (start,end)


# In[9]:


from sqlalchemy import *
engine = create_engine("mysql+pymysql://spotonhr:spoton54321@104.199.198.197/condata")
condf = pd.read_sql("SELECT * FROM condata WHERE Pickupdate >= {0} AND Pickupdate <= {1} ".format(start,end),engine)


# In[10]:


closing_df.loc[closing_df.index,'TYPE']='Closing Stock'
inventory_df.loc[inventory_df.index,'TYPE']='Hub Inventory'
intransit_df.loc[intransit_df.index,'TYPE']='Intransit'


# In[11]:


inventory_df.rename(columns={'Con Number':'DOCKNO'},inplace=True)


# In[12]:


dff=pd.concat([closing_df,inventory_df,intransit_df])
len(dff)


# In[13]:


new_df=pd.merge(dff,condf,on='DOCKNO',how='left')


# In[14]:


new_df=new_df.fillna(0)


# In[15]:


len(new_df)


# In[16]:


new_df['Revenue1']=new_df['Revenue'].apply(lambda x: True if (x) else False)


# In[17]:


revenue_df=new_df[new_df['Revenue1']==True]
len(revenue_df)


# In[18]:


closing_revenue=pd.np.round(revenue_df[revenue_df['TYPE']=='Closing Stock']['Revenue'].sum()/100000,1)
print (closing_revenue)
inventory_revenue=pd.np.round(revenue_df[revenue_df['TYPE']=='Hub Inventory']['Revenue'].sum()/100000,1)
print (inventory_revenue)
intransit_revenue=pd.np.round(revenue_df[revenue_df['TYPE']=='Intransit']['Revenue'].sum()/100000,1)
print (intransit_revenue)


# In[19]:


closing_actwt=pd.np.round((closing_df['ACTUWT'].sum()/1000),1)
closing_cons=len(closing_df)
print (closing_actwt,closing_cons)
inventory_actwt=pd.np.round(inventory_df['Act Wt In Tonnes'].sum(),1)
inventory_cons=len(inventory_df)
print (inventory_actwt,inventory_cons)
#intransit_actwt=intransit_df['ACTUWT'].sum()
intransit_cons=len(intransit_df)
print (intransit_cons)


# In[20]:


d={'TimeStamp':timestamp,'Dest_Cons':closing_cons,'Dest_Wt(T)':closing_actwt,'Dest_Revenue(L)':closing_revenue,'Inventory_Cons':inventory_cons,'Inventory_Wt(T)':inventory_actwt,'Inventory_Revenue(L)':inventory_revenue,'Intransit_Wt(T)':'','Intransit_Cons':intransit_cons,'Intransit_Revenue(L)':intransit_revenue,'Total_Wt(T)':(closing_actwt+inventory_actwt),'Total_Cons':(intransit_cons+inventory_cons+closing_cons),'Total_Revenue(L)':(closing_revenue+intransit_revenue+inventory_revenue)}
result_df=pd.DataFrame([d])

result_df=result_df[['TimeStamp','Dest_Cons','Dest_Revenue(L)','Dest_Wt(T)','Intransit_Cons','Intransit_Revenue(L)','Intransit_Wt(T)','Inventory_Cons','Inventory_Revenue(L)','Inventory_Wt(T)','Total_Cons','Total_Revenue(L)','Total_Wt(T)']]
result_df.rename(columns={'Dest_Revenue(L)':'Dest_Rev(L)','Intransit_Revenue(L)':'Transit_Rev(L)','Intransit_Cons':'Transit_Cons','Intransit_Wt(T)':'Transit_Wt(T)','Inventory_Revenue(L)':'Inv_Rev(L)','Inventory_Cons':'Inv_Cons','Inventory_Wt(T)':'Inv_Wt(T)','Total_Revenue(L)':'Total_Rev(L)'},inplace=True)


dec_summary_df=pd.read_csv(r'D:\Data\Cons_Intransit_Inventory_Stock_Summary\Dec_Cons_Summary.csv')
dec_summary_df.rename(columns={'Dest_Revenue(L)':'Dest_Rev(L)','Intransit_Revenue(L)':'Transit_Rev(L)','Intransit_Cons':'Transit_Cons','Intransit_Wt(T)':'Transit_Wt(T)','Inventory_Revenue(L)':'Inv_Rev(L)','Inventory_Cons':'Inv_Cons','Inventory_Wt(T)':'Inv_Wt(T)','Total_Revenue(L)':'Total_Rev(L)'},inplace=True)
dec_summary_df





from datetime import date,timedelta
todate=date.today()-timedelta(1)
today_date=datetime.strftime(todate,'%d-%m-%Y')
today_date
#vishwas.j@spoton.co.in
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

#TO=['mahesh.reddy@spoton.co.in']
TO=['supratim@iepfunds.com','ankit@iepfunds.com','krishna.chandrasekar@spoton.co.in']
FROM="reports.ie@spoton.co.in"
#CC=['mahesh.reddy@spoton.co.in']
CC=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']

msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
msg["Subject"] = "Cons- Intransit & Inventory" + " : " + str(timestamp)
html='''<html>
<style>
p
{
  margin:0;
  margin-top: 5px;
  padding:0;
  font-size:17px;
    line-height:20px;
}
</style>
<h4>Dear All,</h4>
<p>PFA,Cons at Stock,Hub Inventory and Intransit as of $date</p>
</html>'''

html3='''
<h3>APT Performance Month to Date</h3>

'''
s = Template(html).safe_substitute(date=timestamp)
report=""
report+=s
report+='<br>'+result_df.fillna(0).to_html()+'<br>'
report+='December Summary as of 2017-12-31.23:00:00'
report+='<br>'+dec_summary_df.fillna(0).to_html()+'<br>'
report+='Dest_Cons : Cons at Destination SC'+'<br>'
report+='Dest_Wt(T) : Weight  at Destination SC'+'<br>'
report+='Dest_Rev(T) : Revenue at Destination SC'+'<br>'
report+='Transit_Cons : Cons in Intransit'+'<br>'
report+='Transit_Wt(T) : Weight in Intransit'+'<br>'
report+='Transit_Rev(L) : Revenue in Intransit'+'<br>'
report+='Inv_Cons : Cons in Inventory'+'<br>'
report+='Inv_Wt(T) : Weight in Inventory'+'<br>'
report+='Inv_Rev(L) : Revenue in Inventory'+'<br>'



abc=MIMEText(report,'html')
msg.attach(abc)

server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()
#exit(0)


