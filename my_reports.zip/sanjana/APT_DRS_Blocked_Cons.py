# -*- coding: utf-8 -*-
"""
Created on Tue Jan 29 11:14:11 2019

@author: S3430SAN
"""
import numpy as np
import pandas as pd
# import matplotlib.pyplot as plt
# import seaborn
from glob import glob
from IPython import display
from datetime import datetime,timedelta
import pyodbc
import csv
import Utilities
# import geopy

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

yest=datetime.now()-timedelta(1)
enddate=yest.date()
enddate=str(enddate)+' 23:59:00'

yest=datetime.now()-timedelta(16)
startdate=yest.date()
startdate=str(startdate)


##  -------------   E - C O M M E R C E   -----------
dem_query=("""EXEC USP_APT_Exception_Cons""")
query=pd.read_sql(dem_query,Utilities.cnxn)
#print (query)
Q=query[query.Con_Category == 'e-Commerce']
#print (len(query))
piv1=pd.pivot_table(Q, index=["STATUS1"], columns=["APT_DATE"], values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True, margins_name='Total').fillna(0)
piv1.rename(columns={'DOCKNO':'E-Commerce_DOCKNO'},inplace=True)
piv1.sort_values(('E-Commerce_DOCKNO','Total'), ascending=False, inplace=True)
piv1['E-Commerce_DOCKNO'] = piv1['E-Commerce_DOCKNO'].astype(int)
#print(piv1)


# ----------  N O N  E - C O M M E R C E------------
dem_query1=("""EXEC USP_APT_Exception_Cons""")
query1=pd.read_sql(dem_query1,Utilities.cnxn)
#print (query)
query1=query1[query1.Con_Category == 'Non e-Commerce']
piv2=pd.pivot_table(query1, index=["STATUS1"], columns=["APT_DATE"], values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True, margins_name='Total').fillna(0)
piv2.rename(columns={'DOCKNO':'Non E-Commerce_DOCKNO'},inplace=True)
piv2.sort_values(('Non E-Commerce_DOCKNO','Total'), ascending=False, inplace=True)
piv2['Non E-Commerce_DOCKNO'] = piv2['Non E-Commerce_DOCKNO'].astype(int)
#print(piv2)

# ---------- N U L L - U N C A T E G O R I S E D  -----------

dem_query2=("""EXEC USP_APT_Exception_Cons""")
query2=pd.read_sql(dem_query2,Utilities.cnxn)
#query2=query2[query2.Con_Category == 'None']
query2=query2[query2['Con_Category'].isnull()]

piv3=pd.pivot_table(query2, index=["STATUS1"], columns=["APT_DATE"], values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True, margins_name='Total').fillna(0)
piv3.rename(columns={'DOCKNO':'Uncategorised_DOCKNO'},inplace=True)
piv3.sort_values(('Uncategorised_DOCKNO','Total'), ascending=False, inplace=True)
piv3['Uncategorised_DOCKNO'] = piv3['Uncategorised_DOCKNO'].astype(int)
#print(piv3)

#  ------- E N D ------



query.to_csv(r'D:\Data\APT_DRS_Blocked_cons.csv')
import os
import ftplib
import traceback

oppath1=r'D:\Data\APT_DRS_Blocked_cons.csv'
 #FTP Upload starts
print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
 try:
     ftp.login('HOSQTeam', 'Te@mH0$q')
     print ('login done')
     ftp.cwd('Auto_reports')
     #ftp.cwd('FIFO')
     # move to the desired upload directory
     print ("Currently in:", ftp.pwd())
     print ('Uploading...')
     fullname = oppath1
     name = os.path.split(fullname)[1]
     f = open(fullname, "rb")
     ftp.storbinary('STOR ' + name, f)
     f.close()
     print ("OK"  )
     print ("Files:")
     print (ftp.retrlines('LIST'))
 finally:
     print ("Quitting...")
     ftp.quit()
except:
    traceback.print_exc()
    
date=datetime.strftime(datetime.now(),'%Y-%m-%d %H:%M:%S')


# ----------- E M A I L --------------------------    
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template                    


TO=['raghavendra.rao@spoton.co.in','vinit.tiwari@spoton.co.in','ganesh.m@spoton.co.in']
FROM="mis.ho@spoton.co.in"
CC = ['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in']
BCC = ['sanjana.narayana@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = "APT DRS Blocked Cons" + " - " + str(date)
html='''<html>
<style>        
p
 {
   margin:0;
   margin-top: 5px;
   padding:0;
   font-size:15px;
   line-height:20px;
 }
</style>                

'''
html3='''
<h5> To download, Please click the link below </h5>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/APT_DRS_Blocked_cons.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/APT_DRS_Blocked_cons.csv</p>
'''
report=""
report+='<br>'
report+='E-Commerce Appointment Exception Cons'
report+='<br>'
report+='<br>'+piv1.to_html()+'<br>'
report+='Non-E Commerce Appointment Exception Cons'
report+='<br>'
report+='<br>'+piv2.to_html()+'<br>'
report+='Uncategorised Appointment Exception Cons'
report+='<br>'
report+='<br>'+piv3.to_html()+'<br>'
report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(oppath1,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
#msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("spoton.net.in", "Star@123#")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
print ('mail sent')
server.quit()










