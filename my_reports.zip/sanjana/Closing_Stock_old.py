
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta,datetime
import sys

reload(sys).setdefaultencoding("ISO-8859-1")

# In[2]:


from datetime import date,timedelta 
d=date.today()
today_date=datetime.strftime(d,'%d-%b-%y')
date1=date.today()-timedelta(1)
yest_date=datetime.strftime(date1,'%d-%b-%y')
pickup_date1=datetime.strftime(date1,'%Y-%m-%d')
pickup_date2=pickup_date1+' 23:59'
print (today_date,yest_date,pickup_date1,pickup_date2)


# In[3]:


cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")


# In[4]:


cursor=cnxn.cursor()


# In[5]:


#Pickup count numbers
query=("""SELECT COUNT(*) Pick_Cons FROM dbo.DOCKET WHERE DOCKDT BETWEEN '{0}' AND '{1}' AND PAYBAS <> 6""").format(pickup_date1,pickup_date2)
query


# In[6]:


d={}


# In[7]:


Pkup_count =pd.read_sql(query,cnxn)
Pkup_count['Pick_Cons'][0]


# In[8]:


Picked_up=Pkup_count['Pick_Cons']
d['Picked up']=Pkup_count['Pick_Cons'][0]
d['Picked up']


# In[9]:


#Delivery count numbers
#query1=("""EXEC dbo.USP_BADPOD_DTL_SQI '2018-01-02', '2018-01-02'""")
# query=(""" EXEC USP_CON_SHORTAGE_EXCESS_REPORT 'ALL','ALL','ALL', '{0}' , '{1}'""".format(querydate,querydate))
querydate=date.today()-timedelta(1)
query1=(""" EXEC dbo.USP_BADPOD_DTL_SQI '{0}' , '{1}'""".format(querydate,querydate))
query1


# In[10]:


# Dlry_count=pd.read_sql(query1,cnxn)
# Dlry_count
# Delivered=Dlry_count['CONS'].sum()
# Delivered

try:
    Dlry_count=pd.read_sql(query1,cnxn)
    Delivered=Dlry_count['CONS'].sum()
except:
    Delivered=0
# Delivered=Dlry_count['CONS'].sum()
# Delivered

Delivered

# In[11]:


d['Delivered']=Delivered
d


# In[12]:


#Closing stock report
query2=("""SELECT  A.*, CASE WHEN ( CON_BLOCKED_FOR_PAY_ISSUES = 'YES' ) THEN 'A3_PAYMENT_ISSUE'  
             WHEN ( ConStatusCode IN( 'SSC','SHS' )) THEN 'A4_Seized by Sales Tax'  
             WHEN ( ConStatusCode IN ('UCG','UG1','UG2','UG3' )) THEN '8_UCG'  
             WHEN (CON_BLOCKED_FOR_DEMURRAGE = 'YES' AND DEMURRAGE_RESPONSIBILITY = 'CS') THEN '2_CS Dem_Pin Drs Block'--'CS Dem Drs Block'  
             WHEN (CON_BLOCKED_FOR_DEMURRAGE = 'YES' AND DEMURRAGE_RESPONSIBILITY = 'OPS' AND LatestTicketStatus != 'Open') THEN '5_OPS Dem Drs Block'  
             WHEN (CON_BLOCKED_FOR_ODA_PIN_ISSUES =  'YES') THEN '2_CS Dem_Pin Drs Block' --'CS PIN DRS BLOCK'  
             WHEN (REPORTDATE_MIN_ARRVDT > 1440 ) THEN 'A1_DEAD STOCK'  
             WHEN (IsTTSTicketRaised = 'YES' AND LatestTicketStatus = 'CLOSED' AND LatestTicketStatusCode = ConStatusCode AND REPORTDATE_MIN_ARRVDT >= 40) THEN '3_OPS/Free Con Bucket-Old'  
             WHEN (IsTTSTicketRaised = 'YES' AND LatestTicketStatus = 'CLOSED' AND LatestTicketStatusCode = ConStatusCode AND REPORTDATE_MIN_ARRVDT < 40) THEN '4_OPS/Free Con Bucket-NEW'  
             WHEN (IS_FREE_CON_NEW = 'YES' AND REPORTDATE_MIN_ARRVDT >= 40) THEN '3_OPS/Free Con Bucket-Old'  
             WHEN (IS_FREE_CON_NEW = 'YES' AND REPORTDATE_MIN_ARRVDT < 40) THEN '4_OPS/Free Con Bucket-New'  
             WHEN (IsTTSTicketRaised = 'YES' AND LatestTicketStatus = 'OPEN') THEN '1_CS Bucket'  
             WHEN (ConStatusCategory = 'DEPS' AND REPORTDATE_MIN_ARRVDT > 168 ) THEN '9_DEPS-SQ'  
             WHEN (ConStatusCategory = 'DEPS' AND REPORTDATE_MIN_ARRVDT <= 168 ) THEN '6_DEPS-OPS'  
             WHEN (ConStatusCategory IN ( 'RECEIVER FAILURE','SENDER FAILURE') )THEN 'A2_CCF without Tickets'   
             ELSE '7_Others/Timelag'             
        END STATUS1   
FROM    dbo.tblOCIDClosingStock A  
WHERE   LogDate >= CONVERT(DATE,GETDATE()-0)""")


# In[13]:


Closing_df=pd.read_sql(query2,cnxn)


# In[14]:


Closing_df.head(4)


# In[15]:


pivot_df=pd.pivot_table(Closing_df,index=['STATUS1'],values=['DOCKNO','REPORTDATE_MIN_ARRVDT'],aggfunc={'DOCKNO':len,'REPORTDATE_MIN_ARRVDT':np.mean}).reset_index()


# In[16]:


pivot_df['REPORTDATE_MIN_ARRVDT']=np.round(pivot_df['REPORTDATE_MIN_ARRVDT'],1)
Cons=pivot_df['DOCKNO'].sum()

# Cons
Ageing=int(pivot_df['REPORTDATE_MIN_ARRVDT'].mean())
pivot_df[6:]


# In[17]:


tts_tickets=pivot_df[pivot_df['STATUS1']=='1_CS Bucket']
cs_dem=pivot_df[pivot_df['STATUS1']=='2_CS Dem_Pin Drs Block']
ops_bucket_old=pivot_df[pivot_df['STATUS1']=='3_OPS/Free Con Bucket-Old']
ops_bucket_NEW=pivot_df[pivot_df['STATUS1']=='4_OPS/Free Con Bucket-NEW']
ops_bucket_new=pivot_df[pivot_df['STATUS1']=='4_OPS/Free Con Bucket-New']
ops_bucket_drs_block=pivot_df[pivot_df['STATUS1']=='5_OPS Dem Drs Block']
ops_bucket_deps_ops=pivot_df[pivot_df['STATUS1']=='6_DEPS-OPS']
ops_bucket_others=pivot_df[pivot_df['STATUS1']=='7_Others/Timelag']
sq_ucg=pivot_df[pivot_df['STATUS1']=='8_UCG']
sq_deps=pivot_df[pivot_df['STATUS1']=='9_DEPS-SQ']
sq_dead_stock=pivot_df[pivot_df['STATUS1']=='A1_DEAD STOCK']
unassigned_ccf_tts=pivot_df[pivot_df['STATUS1']=='A2_CCF without Tickets']
unassigned_payment_iss=pivot_df[pivot_df['STATUS1']=='A3_PAYMENT_ISSUE']
unassigned_seized=pivot_df[pivot_df['STATUS1']=='A4_Seized by Sales Tax']

ops_new_cons=ops_bucket_NEW.values[0][1]+ops_bucket_new.values[0][1]
ops_new_ageing=ops_bucket_NEW.values[0][2]+ops_bucket_new.values[0][2]
# In[18]:


xls = pd.ExcelFile(r'C:\Users\rajeeshv\Downloads\Rajesh\mahesh\Closing Stock Summary_'+str(yest_date)+'.xlsx')
kpi_df = pd.read_excel(xls,sheetname='Summary')
kpi_df1=kpi_df
kpi_df1


# In[19]:


# kpi_df1['Unnamed: 1']=d['Picked up']

# kpi_df1['Unnamed: 1']=d['Picked up']

kpi_df1=kpi_df1.append({'PS: Dead Stock is all stock with ageing more than 60 days':yest_date,'Unnamed: 1':d['Picked up'],'Unnamed: 2':d['Delivered'],'Unnamed: 3':Cons,'Unnamed: 4':Ageing,'Unnamed: 5':tts_tickets.values[0][1],'Unnamed: 6':tts_tickets.values[0][2],'Unnamed: 7':cs_dem.values[0][1],'Unnamed: 8':cs_dem.values[0][2],'Unnamed: 9':(cs_dem.values[0][1]+tts_tickets.values[0][1]),'Unnamed: 10':ops_bucket_old.values[0][1],'Unnamed: 11':ops_bucket_old.values[0][2],'Unnamed: 12'ops_new_cons:,'Unnamed: 13':ops_new_ageing,'Unnamed: 14':ops_bucket_drs_block.values[0][1],'Unnamed: 15':ops_bucket_drs_block.values[0][2],'Unnamed: 16':ops_bucket_deps_ops.values[0][1],'Unnamed: 17':ops_bucket_deps_ops.values[0][2],'Unnamed: 18':ops_bucket_others.values[0][1],'Unnamed: 19':ops_bucket_others.values[0][2],'Unnamed: 20':(ops_bucket_old.values[0][1]+ops_new_cons+ops_bucket_drs_block.values[0][1]+ops_bucket_deps_ops.values[0][1]+ops_bucket_others.values[0][1]),'Unnamed: 21':sq_ucg.values[0][1],'Unnamed: 22':sq_ucg.values[0][2],'Unnamed: 23':sq_deps.values[0][1],'Unnamed: 24':sq_deps.values[0][2],'Unnamed: 25':sq_dead_stock.values[0][1],'Unnamed: 26':sq_dead_stock.values[0][2],'Unnamed: 27':(sq_ucg.values[0][1]+sq_deps.values[0][1]+sq_dead_stock.values[0][1]),'Unnamed: 28':unassigned_ccf_tts.values[0][1],'Unnamed: 29':unassigned_ccf_tts.values[0][2],'Unnamed: 30':unassigned_payment_iss.values[0][1],'Unnamed: 31':unassigned_payment_iss.values[0][2],'Unnamed: 32':unassigned_seized.values[0][1],'Unnamed: 33':unassigned_seized.values[0][2],'Unnamed: 34':(unassigned_ccf_tts.values[0][1]+unassigned_payment_iss.values[0][1]+unassigned_seized.values[0][1])},ignore_index=True)

#kpi_df1=kpi_df1.append({'PS: Dead Stock is all stock with ageing more than 60 days':yest_date,'Unnamed: 1':d['Picked up'],'Unnamed: 2':d['Delivered'],'Unnamed: 3':Cons,'Unnamed: 4':Ageing,'Unnamed: 5':tts_tickets.values[0][1],'Unnamed: 6':tts_tickets.values[0][2],'Unnamed: 7':cs_dem.values[0][1],'Unnamed: 8':cs_dem.values[0][2],'Unnamed: 9':(cs_dem.values[0][1]+tts_tickets.values[0][1]),'Unnamed: 10':ops_bucket_old.values[0][1],'Unnamed: 11':ops_bucket_old.values[0][2],'Unnamed: 12':ops_bucket_new.values[0][1],'Unnamed: 13':ops_bucket_new.values[0][2]                        ,'Unnamed: 14':ops_bucket_drs_block.values[0][1],'Unnamed: 15':ops_bucket_drs_block.values[0][2],'Unnamed: 16':ops_bucket_deps_ops.values[0][1],'Unnamed: 17':ops_bucket_deps_ops.values[0][2],'Unnamed: 18':ops_bucket_others.values[0][1],'Unnamed: 19':ops_bucket_others.values[0][2],'Unnamed: 20':(ops_bucket_old.values[0][1]+ops_bucket_new.values[0][1]+ops_bucket_drs_block.values[0][1]+ops_bucket_deps_ops.values[0][1]+ops_bucket_others.values[0][1]),'Unnamed: 21':sq_ucg.values[0][1],'Unnamed: 22':sq_ucg.values[0][2]                        ,'Unnamed: 23':sq_deps.values[0][1],'Unnamed: 24':sq_deps.values[0][2],'Unnamed: 25':sq_dead_stock.values[0][1],'Unnamed: 26':sq_dead_stock.values[0][2],'Unnamed: 27':(sq_ucg.values[0][1]+sq_deps.values[0][1]+sq_dead_stock.values[0][1]),'Unnamed: 28':unassigned_ccf_tts.values[0][1],'Unnamed: 29':unassigned_ccf_tts.values[0][2],'Unnamed: 30':unassigned_payment_iss.values[0][1],'Unnamed: 31':unassigned_payment_iss.values[0][2],'Unnamed: 32':unassigned_seized.values[0][1],'Unnamed: 33':unassigned_seized.values[0][2]                       ,'Unnamed: 34':(unassigned_ccf_tts.values[0][1]+unassigned_payment_iss.values[0][1]+unassigned_seized.values[0][1])},ignore_index=True)


# In[20]:


kpi_df1.tail(5)


# In[21]:


from pandas import ExcelWriter
with ExcelWriter(r'C:\Users\rajeeshv\Downloads\Rajesh\mahesh\Closing Stock Summary_'+str(today_date)+'.xlsx') as writer:
    kpi_df1.to_excel(writer,engine='xlsxwriter',sheet_name='Summary')
  


# In[22]:


filepath=r'C:\Users\rajeeshv\Downloads\Rajesh\mahesh\Closing Stock Summary_'+str(today_date)+'.xlsx'


# In[23]:


import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback

oppath1=filepath
#FTP Upload starts
print ('Logging in...')
ftp = ftplib.FTP()  
ftp.connect('10.109.230.50')  
print (ftp.getwelcome())
try:  
    try:  
        ftp.login('HOSQTeam', 'Te@mH0$q')
        print ('login done')
        ftp.cwd('Auto_reports')  
        #ftp.cwd('FIFO')
        # move to the desired upload directory  
        print ("Currently in:", ftp.pwd()) 
        print ('Uploading...')  
        fullname = oppath1
        name = os.path.split(fullname)[1]  
        f = open(fullname, "rb")  
        ftp.storbinary('STOR ' + name, f)  
        f.close()  
        print ("OK"  )
        print ("Files:")  
        print (ftp.retrlines('LIST'))
    finally:  
        print ("Quitting...")
        ftp.quit()  
except:  
    traceback.print_exc()


# In[24]:


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

from_addr = 'mis.ho@spoton.co.in'
# to_addr = ['rajesh.mp@spoton.co.in','banusanketh.dc@spoton.co.in','mahesh.reddy@spoton.co.in','shivananda.p@spoton.co.in']
# to_addr = ['sreedhar.m@spoton.co.in','mahesh.reddy@spoton.co.in']
#cc_addr = ['maheshmahesh11464@gmail.com','mahesh.reddy@spoton.co.in']
#cc_addr=['sqtf@spoton.co.in','ashwani.gangwar@spoton.co.in','SQ_SPOT@spoton.co.in','pramod.pandey@spoton.co.in','md.zaya@spoton.co.in']
bcc_addr = ['maheshmahesh11464@gmail.com','mahesh.reddy@spoton.co.in','sharanagouda.biradar@spoton.co.in']
#bcc_addr=['smt_spot@spoton.co.in','pawan.sharma@spoton.co.in','rajesh.kumar@spoton.co.in','supratim@iepfunds.com','shivananda.p@spoton.co.in','Ankit@iepfunds.com','prafulla.masurkar@spoton.co.in','sharanagouda.biradar@spoton.co.in']

username = 'mis.ho@spoton.co.in'
password = 'Raj@spot12.mp'

msg = MIMEMultipart()

msg['From'] = from_addr
# msg['To'] = ', '.join(to_addr)
#msg['bcc'] = ', '.join(cc_addr)
msg['bcc'] = ', '.join(bcc_addr)
msg['Subject'] = 'Closing Stock Summary -'+str(yest_date)
html='''<html>
<h4>Dear All,</h4>
<p>Pls find attached Closing Stock Summary.</p>
</html>'''
# html4='''
# <h5> Note : For data please click on the below link: </h5>
# <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Origin SC Connection - On-Time Performance.xlsx"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Origin SC Connection - On-Time Performance.xlsx</p></b>
# '''
html1='''<h5>Thanks & Regards</h5></b>
<h5>HO-SQ</h5>'''
    
#  msg.attach(part10)
s = Template(html).safe_substitute()
report=""
report+=s
report+='<br>'
# report+='<br>'
# report+=html3
# report+='<br>'
# report+=html4
# report+='<br>'
report+=html1
abc=MIMEText(report,'html')
msg.attach(abc)
server = smtplib.SMTP('smtp.spoton.co.in',587)
part=MIMEBase('application','octet-stream')
# part1=MIMEBase('application','octet-stream')
part.set_payload(open(filepath,'rb').read())
# part1.set_payload(open(filepath1,'rb').read())
encoders.encode_base64(part)
# Encoders.encode_base64(part1)
part.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath))
# part1.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath1))
msg.attach(part)
# msg.attach(part1)
server.ehlo()
server.starttls()
server.ehlo()
server.login('mis.ho@spoton.co.in','Mis@2019')
server.sendmail(from_addr,bcc_addr,msg.as_string())
print ('mail sent succesfully')
server.quit()

