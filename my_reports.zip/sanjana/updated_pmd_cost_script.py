
# coding: utf-8

# In[1]:

import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta,datetime
import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
from pandas import ExcelWriter
import os
import smtplib
import ftplib
import traceback
import calendar
import Utilities
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

# In[2]:

cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()

# query=("""SELECT  CASE WHEN A.PUDTYPE = 'ADHOC'

#                           AND ( (            

         

#                                   A.MKT_SBA_APPLICABLE = 'Y'

#                                   AND A.MKT_SBA_AMT > 0

#                                 )

#                                 OR ( A.SENDERCODE = '000119837'

#                                      OR A.SENDERCODE = '000118040'

#                                      OR A.SENDERCODE = '000118041'

#                                      OR A.SENDERCODE = '000119721'

#                                      OR A.SENDERCODE = '000120083'

#                                      OR A.SENDERCODE = '000115133'

#                                      OR A.SENDERCODE = '000121273'

#                                    )

#                                 OR ( A.PINTYPE = 'NSL' )

#                               ) THEN 'ADHOC-Special'

#                      ELSE A.PUDTYPE


#         END PUDTYPE_STATUS ,
#         a.*
# FROM    dbo.tblPUDYestMtdData a WITH ( NOLOCK )
# """)

try:

    query=("""EXEC USP_PUD_YEST_MTD_DATA 'M' """)

    print ('yes')
    df=pd.read_sql(query,cnxn)
    df=df[df['PTYPE']!='AR']


    m = {'Jan': '01','Feb': '02','Mar': '03','Apr':'04','May':'05','Jun':'06','Jul':'07','Aug':'08','Sep':'09','Oct':'10','Nov':'11','Dec':'12'}


    # In[7]:

    def dateconv(date):
        dt = date.split(' ')[2]+'-'+str(m.get(date.split(' ')[1]))+'-'+date.split(' ')[0]
        #print (dt)
        return dt


    # In[8]:

    df["DateOnly"]=df.apply(lambda x: dateconv(x["DATE"]),axis=1)

    # In[3]:
    df.to_csv(r'D:\Data\PMD_Save\PMD.csv')
    fullname=r'D:\Data\PMD_Save\PMD.csv'
    print ('Logging in...')
    ftp = ftplib.FTP()
    ftp.connect('10.109.230.50')
    print (ftp.getwelcome())
    try:
        try:
            ftp.login('IEPROJECTUSER', 'spotStar@123')
            ftp.cwd('ETA')
            # move to the desired upload directory
            print ("Currently in:", ftp.pwd())
            print ('Uploading...')
            fullname = fullname
            name = os.path.split(fullname)[1]
            f = open(fullname, "rb")
            ftp.storbinary('STOR ' + name, f)
            f.close()
            print ("OK"  )
            print ("Files:")
            print (ftp.retrlines('LIST'))
        finally:
            print ("Quitting...")
            ftp.quit()
    except:
        traceback.print_exc()


    print len(df)


    # In[4]:

    def dateconv(date):
          try:
            dt = datetime.strftime(date, '%Y-%m-%d')
            return dt
          except:
            pass


    # In[5]:

    #df["DATE2"]=df.apply(lambda x: dateconv(x["DATE"]),axis=1)
    #print (df['DATE2'].unique())

    # In[6]:

    def getPUDTYPE(pintype,pudtype2):
        if ((pintype=='STD')& (pudtype2=='STD')):
            return "STD"
        elif ((pintype=='STD')& (pudtype2!='STD')):
            return "Non-STD"
        elif ((pintype=='ODA')):
            return "All"
        else:
            return "Check"
        


    # In[7]:

    df['PUDTYPES']=df.apply(lambda x: getPUDTYPE(x['PINTYPE'],x['PUDTYPE']),axis=1)


    # In[8]:

    total_pivot=pd.pivot_table(df,index=['PINTYPE','PUDTYPES'],values=['ACT_WT','COST'],aggfunc={'ACT_WT':sum,'COST':sum},margins=True,margins_name='Total')


    # In[9]:

    total_pivot['CPKG']=total_pivot['COST']/total_pivot['ACT_WT']


    # In[12]:


    total_pivot['COST'] = total_pivot['COST'].apply(lambda x: '{:.2f}'.format(x))
    total_pivot['ACT_WT'] = total_pivot['ACT_WT'].apply(lambda x: '{:.2f}'.format(x))
    total_pivot['CPKG'] = total_pivot['CPKG'].apply(lambda x: '{:.3f}'.format(x))


    # In[13]:


    #month to date pivot 
    total_pivot['ACT_WT(T)']=((total_pivot['ACT_WT'].astype(float))/1000).astype(int)
    total_pivot['COST(Lakhs)']=pd.np.round((total_pivot['COST'].astype(float))/100000,1)

    total_pivot


    # In[10]:

    booking_df=df[df['TYP']=='BKG']


    # In[15]:


    len(booking_df)


    # In[16]:


    booking_pivot=pd.pivot_table(booking_df,index=['PINTYPE','PUDTYPES'],values=['ACT_WT','COST'],aggfunc={'ACT_WT':sum,'COST':sum},margins=True,margins_name='Total')



    # In[11]:

    booking_pivot['CPKG']=booking_pivot['COST']/booking_pivot['ACT_WT']


    # In[18]:


    booking_pivot['COST'] = booking_pivot['COST'].apply(lambda x: '{:.2f}'.format(x))
    booking_pivot['ACT_WT'] = booking_pivot['ACT_WT'].apply(lambda x: '{:.2f}'.format(x))
    booking_pivot['CPKG'] = booking_pivot['CPKG'].apply(lambda x: '{:.3f}'.format(x))


    # In[19]:


    #month to date booking pivot
    booking_pivot['ACT_WT(T)']=((booking_pivot['ACT_WT'].astype(float))/1000).astype(int)
    booking_pivot['COST(Lakhs)']=pd.np.round((booking_pivot['COST'].astype(float))/100000,1)

    booking_pivot


    # In[12]:

    delivery_df=df[df['TYP']=='DLV']


    # In[21]:


    len(delivery_df)


    # In[22]:


    delivery_pivot=pd.pivot_table(delivery_df,index=['PINTYPE','PUDTYPES'],values=['ACT_WT','COST'],aggfunc={'ACT_WT':sum,'COST':sum},margins=True,margins_name='Total')


    # In[13]:

    delivery_pivot['CPKG']=delivery_pivot['COST']/delivery_pivot['ACT_WT']


    # In[24]:


    delivery_pivot['COST'] = delivery_pivot['COST'].apply(lambda x: '{:.2f}'.format(x))
    delivery_pivot['ACT_WT'] = delivery_pivot['ACT_WT'].apply(lambda x: '{:.2f}'.format(x))
    delivery_pivot['CPKG'] = delivery_pivot['CPKG'].apply(lambda x: '{:.3f}'.format(x))

    # In[25]:


    #month to date delivery pivot
    delivery_pivot['ACT_WT(T)']=((delivery_pivot['ACT_WT'].astype(float))/1000).astype(int)
    delivery_pivot['COST(Lakhs)']=pd.np.round((delivery_pivot['COST'].astype(float))/100000,1)

    delivery_pivot


    # In[14]:

    to_date=date.today()-timedelta(1)
    to_date1=date.today()-timedelta(2)
    yest_date=datetime.strftime(to_date,'%Y-%m-%d')
    yest_date3=datetime.strftime(to_date,'%Y-%m-%d ')+'00:00:00'
    yest_date4=datetime.strftime(to_date,'%Y-%m-%d ')+'23:59:00'
    yest_date1=datetime.strftime(to_date1,'%Y-%m-%d')
    print (yest_date,yest_date1)


    # In[15]:

    # query1=("""SELECT * FROM dbo.tblPUDYestMtdData WHERE DATE BETWEEN '{0}' AND '{1}'""".format(yest_date3,yest_date4))
    # print (query1)
    # yest_df=pd.read_sql(query1,cnxn)
    yest_df=df[df['DateOnly']==yest_date]
    #yest_df=df[df['DATE2']=='2018-02-06']
    print ('length of Yesterday data ',len(yest_df))


    # In[17]:

    #yest_df['PUDTYPES']=yest_df.apply(lambda x: getPUDTYPE(x['PINTYPE'],x['PUDTYPE']),axis=1)
    yest_total_pivot=pd.pivot_table(yest_df,index=['PINTYPE','PUDTYPES'],values=['ACT_WT','COST'],aggfunc={'ACT_WT':sum,'COST':sum},margins=True,margins_name='Total')


    # In[18]:

    yest_total_pivot['CPKG']=yest_total_pivot['COST']/yest_total_pivot['ACT_WT']


    # In[33]:


    yest_total_pivot['COST'] = yest_total_pivot['COST'].apply(lambda x: '{:.2f}'.format(x))
    yest_total_pivot['ACT_WT'] = yest_total_pivot['ACT_WT'].apply(lambda x: '{:.2f}'.format(x))
    yest_total_pivot['CPKG'] = yest_total_pivot['CPKG'].apply(lambda x: '{:.3f}'.format(x))


    # In[34]:


    #yester day total pivot
    yest_total_pivot['ACT_WT(T)']=((yest_total_pivot['ACT_WT'].astype(float))/1000).astype(int)
    yest_total_pivot['COST(Lakhs)']=pd.np.round((yest_total_pivot['COST'].astype(float))/100000,1)

    yest_total_pivot


    # In[19]:

    yest_bkng_df=yest_df[yest_df['TYP']=='BKG']


    # In[36]:


    len(yest_bkng_df)


    # In[37]:


    pivot_yest_bkng_df=pd.pivot_table(yest_bkng_df,index=['PINTYPE','PUDTYPES'],values=['ACT_WT','COST'],aggfunc={'ACT_WT':sum,'COST':sum},margins=True,margins_name='Total')


    # In[20]:

    pivot_yest_bkng_df['CPKG']=pivot_yest_bkng_df['COST']/pivot_yest_bkng_df['ACT_WT']


    # In[39]:


    pivot_yest_bkng_df['COST'] = pivot_yest_bkng_df['COST'].apply(lambda x: '{:.2f}'.format(x))
    pivot_yest_bkng_df['ACT_WT'] = pivot_yest_bkng_df['ACT_WT'].apply(lambda x: '{:.2f}'.format(x))
    pivot_yest_bkng_df['CPKG'] = pivot_yest_bkng_df['CPKG'].apply(lambda x: '{:.3f}'.format(x))


    # In[40]:


    #yester day booking pivot
    pivot_yest_bkng_df['ACT_WT(T)']=((pivot_yest_bkng_df['ACT_WT'].astype(float))/1000).astype(int)
    pivot_yest_bkng_df['COST(Lakhs)']=pd.np.round((pivot_yest_bkng_df['COST'].astype(float))/100000,1)

    pivot_yest_bkng_df


    # In[21]:

    yest_dlry_df=yest_df[yest_df['TYP']=='DLV']


    # In[42]:


    print ('yest dlv data',len(yest_dlry_df))



    # In[22]:

    pivot_yest_dlry_df=pd.pivot_table(yest_dlry_df,index=['PINTYPE','PUDTYPES'],values=['ACT_WT','COST'],aggfunc={'ACT_WT':sum,'COST':sum},margins=True,margins_name='Total')


    # In[23]:

    pivot_yest_dlry_df['CPKG']=pivot_yest_dlry_df['COST']/pivot_yest_dlry_df['ACT_WT']


    # In[45]:


    pivot_yest_dlry_df['COST'] = pivot_yest_dlry_df['COST'].apply(lambda x: '{:.2f}'.format(x))
    pivot_yest_dlry_df['ACT_WT'] =pivot_yest_dlry_df['ACT_WT'].apply(lambda x: '{:.2f}'.format(x))
    pivot_yest_dlry_df['CPKG'] = pivot_yest_dlry_df['CPKG'].apply(lambda x: '{:.3f}'.format(x))


    # In[46]:


    pivot_yest_dlry_df['ACT_WT(T)']=((pivot_yest_dlry_df['ACT_WT'].astype(float))/1000).astype(int)
    pivot_yest_dlry_df['COST(Lakhs)']=pd.np.round((pivot_yest_dlry_df['COST'].astype(float))/100000,1)


    # In[47]:


    #yester day delivery pivot
    pivot_yest_dlry_df


    # In[24]:

    today=date.today()
    firstday=today.replace(day=1)

    lastmnth_lastdate1=firstday-timedelta(1)
    lastmnth_lastdate2=firstday-timedelta(2)
    lastmnth_lastdate1

    lastdate1=datetime.strftime(lastmnth_lastdate1,"%Y-%m-%d")
    lastdate2=datetime.strftime(lastmnth_lastdate2,"%Y-%m-%d")

    print (lastdate1,lastdate2)

    year, month = datetime.now().year, datetime.now().month - 0
    print (year,month)
    # exit(0)
    aa=calendar.monthrange(year, month)[1]
    day1=str(datetime.now().year)+'-'+str(datetime.now().month - 2)+'-'+str(aa)
    day2=datetime.strftime(datetime.strptime((str(datetime.now().year)+'-'+str(datetime.now().month - 0)+'-'+str(aa)),'%Y-%m-%d')-timedelta(1),'%Y-%m-%d')
    print (aa,day1,day2)
    # In[25]:
    list_of_dates=[]
    for i in pd.date_range('2018-03-01', '2019-06-27', freq='D'):
        if (datetime.strftime(i,'%d-%m-%Y').split('-')[0])=='01':
            list_of_dates.append(datetime.strftime(i,'%d-%m-%Y'))

    #+str(lastdate1)+'

    try:
        previous_df=pd.read_csv(r'D:\Data\PMD_Save\PMD_'+str('2018-08-30')+'.csv')
        print ('D:\Data\PMD_Save\PMD_'+str(lastdate1)+'.csv')
    except:
        import smtplib
        from email.mime.multipart import MIMEMultipart
        from email.mime.text import MIMEText
        # from email.MIMEBase import MIMEBase
        # from email import Encoders
        from email.mime.base import MIMEBase
        from email import encoders
        import os
        from string import Template
        #vishwas.j@spoton.co.in
        FROM='vishwas.j@spoton.co.in'
        TO=['mahesh.reddy@spoton.co.in']
        msg = MIMEMultipart()
        msg["From"] = FROM
        msg["To"] = ",".join(TO)
        msg["Subject"] = "Error Report" + " - " + str(yest_date)
        html='''<html>
        <h4>Hi,</h4>
        <p></p>
        </html>'''
        report=""
        report+='<br>'
        report+='There was error in Monitoring Report Last month file not avaliable'
        report+='<br>'
        abc=MIMEText(report,'html')
        msg.attach(abc)
        
        server=smtplib.SMTP('smtp.sendgrid.net', 587)
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login("spoton.net.in", "Star@123#")
        failed = server.sendmail(FROM, TO, msg.as_string())
        server.quit()




    # In[26]:

    len(previous_df)


    # In[29]:

    previous_df.columns


    # In[31]:

    previous_df.rename(columns={'PUDTYPE2':'PUDTYPE','COST2':'COST','DATE2':'DATE','TYP2':'TYP','ACT_WT2':'ACT_WT','COST2':'COST'},inplace=True)
    previous_df['PUDTYPES']=previous_df.apply(lambda x: getPUDTYPE(x['PINTYPE'],x['PUDTYPE']),axis=1)
    previous_pivot=pd.pivot_table(previous_df,index=['PINTYPE','PUDTYPES'],values=['ACT_WT','COST'],aggfunc={'ACT_WT':sum,'COST':sum},margins=True,margins_name='Total')


    # In[52]:


    previous_pivot['CPKG']=previous_pivot['COST']/previous_pivot['ACT_WT']


    # In[53]:


    previous_pivot['COST'] = previous_pivot['COST'].apply(lambda x: '{:.2f}'.format(x))
    previous_pivot['ACT_WT'] = previous_pivot['ACT_WT'].apply(lambda x: '{:.2f}'.format(x))
    previous_pivot['CPKG'] = previous_pivot['CPKG'].apply(lambda x: '{:.3f}'.format(x))


    # In[54]:


    #previous month total pivot
    previous_pivot['ACT_WT(T)']=((previous_pivot['ACT_WT'].astype(float))/1000).astype(int)
    previous_pivot['COST(Lakhs)']=pd.np.round((previous_pivot['COST'].astype(float))/100000,1)
    previous_pivot


    # In[32]:

    prevs_mnth_bkng_df=previous_df[previous_df['TYP']=='BKG']


    # In[56]:


    len(prevs_mnth_bkng_df)


    # In[57]:


    pivot_prevs_mnth_bkng_df=pd.pivot_table(prevs_mnth_bkng_df,index=['PINTYPE','PUDTYPES'],values=['ACT_WT','COST'],aggfunc={'ACT_WT':sum,'COST':sum},margins=True,margins_name='Total')


    # In[33]:

    pivot_prevs_mnth_bkng_df['CPKG']=pivot_prevs_mnth_bkng_df['COST']/pivot_prevs_mnth_bkng_df['ACT_WT']


    # In[59]:


    pivot_prevs_mnth_bkng_df['COST'] = pivot_prevs_mnth_bkng_df['COST'].apply(lambda x: '{:.2f}'.format(x))
    pivot_prevs_mnth_bkng_df['ACT_WT'] = pivot_prevs_mnth_bkng_df['ACT_WT'].apply(lambda x: '{:.2f}'.format(x))
    pivot_prevs_mnth_bkng_df['CPKG'] = pivot_prevs_mnth_bkng_df['CPKG'].apply(lambda x: '{:.3f}'.format(x))


    # In[60]:


    #previous month booking pivot data
    pivot_prevs_mnth_bkng_df['ACT_WT(T)']=((pivot_prevs_mnth_bkng_df['ACT_WT'].astype(float))/1000).astype(int)
    pivot_prevs_mnth_bkng_df['COST(Lakhs)']=pd.np.round((pivot_prevs_mnth_bkng_df['COST'].astype(float))/100000,1)
    pivot_prevs_mnth_bkng_df


    # In[34]:

    prevs_mnth_dlry_df=previous_df[previous_df['TYP']=='DLV']


    # In[62]:


    len(prevs_mnth_dlry_df)
    print ('done')

    # In[63]:


    pivot_prevs_mnth_dlry_df=pd.pivot_table(prevs_mnth_dlry_df,index=['PINTYPE','PUDTYPES'],values=['ACT_WT','COST'],aggfunc={'ACT_WT':sum,'COST':sum},margins=True,margins_name='Total')


    # In[37]:

    pivot_prevs_mnth_dlry_df['COST']=pivot_prevs_mnth_dlry_df['COST'].astype(float)
    pivot_prevs_mnth_dlry_df['ACT_WT']=pivot_prevs_mnth_dlry_df['ACT_WT'].astype(float)
    pivot_prevs_mnth_dlry_df['CPKG']=pivot_prevs_mnth_dlry_df['COST']/pivot_prevs_mnth_dlry_df['ACT_WT']
    pivot_prevs_mnth_dlry_df['COST'] = pivot_prevs_mnth_dlry_df['COST'].apply(lambda x: '{:.2f}'.format(x))
    pivot_prevs_mnth_dlry_df['ACT_WT'] = pivot_prevs_mnth_dlry_df['ACT_WT'].apply(lambda x: '{:.2f}'.format(x))
    pivot_prevs_mnth_dlry_df['CPKG'] = pivot_prevs_mnth_dlry_df['CPKG'].apply(lambda x: '{:.3f}'.format(x))


    # In[66]:


    #previous month delivery pivot data
    pivot_prevs_mnth_dlry_df['ACT_WT(T)']=((pivot_prevs_mnth_dlry_df['ACT_WT'].astype(float))/1000).astype(int)
    pivot_prevs_mnth_dlry_df['COST(Lakhs)']=pd.np.round((pivot_prevs_mnth_dlry_df['COST'].astype(float))/100000,1)

    pivot_prevs_mnth_dlry_df


    # In[38]:

    pivot_prevs_mnth_dlry_df.columns = [''.join(col).strip() for col in pivot_prevs_mnth_dlry_df.columns.values]


    # In[68]:


    pivot_prevs_mnth_dlry_df1=pivot_prevs_mnth_dlry_df.reset_index()


    # In[69]:


    total_pivot.columns = [''.join(col).strip() for col in total_pivot.columns.values]


    # In[70]:


    total_pivot1=total_pivot.reset_index()


    # In[71]:


    yest_total_pivot.columns = [''.join(col).strip() for col in yest_total_pivot.columns.values]


    # In[72]:


    yest_total_pivot1=yest_total_pivot.reset_index()


    # In[73]:


    previous_pivot.columns = [''.join(col).strip() for col in previous_pivot.columns.values]




    # In[39]:

    previous_pivot1=previous_pivot.reset_index()


    # In[75]:


    #merging month to date with yester day
    pivot_mnth_yest_df=pd.merge(total_pivot1,yest_total_pivot1,on=['PINTYPE','PUDTYPES'],suffixes=('-MTD','-YST'))


    # In[76]:


    pivot_mnth_yest_df


    # In[77]:


    pivot_prvs_mnth_yest_df=pd.merge(pivot_mnth_yest_df,previous_pivot1,on=['PINTYPE','PUDTYPES'])


    # In[78]:


    # mnth=date.today()-timedelta(30)
    current_mnth=datetime.strftime(lastmnth_lastdate1,'%b')
    print (current_mnth)


    # In[79]:

    #print (pivot_prvs_mnth_yest_df.columns)
    #this is final pivot for total (with BKG & DLV)
    pivot_prvs_mnth_yest_df.rename(columns={'ACT_WT':'ACT_WT_'+current_mnth,'COST':'COST_'+current_mnth,'ACT_WT(T)':'ACT_WT(T)_'+current_mnth,'COST(Lakhs)':'COST(Lakhs)-'+current_mnth,'CPKG':'CPKG-'+current_mnth},inplace=True)
    #print ('%%%%%%%%%%%%%%%%%%%%')

    # In[80]:



    # In[40]:

    pivot_prvs_mnth_yest_df1=pivot_prvs_mnth_yest_df[['PINTYPE','PUDTYPES','COST(Lakhs)-YST','CPKG-YST','COST(Lakhs)-MTD','CPKG-MTD','COST(Lakhs)-'+current_mnth,'CPKG-'+current_mnth]]


    # In[82]:


    #total wise pivot data
    pivot_prvs_mnth_yest_df1


    # In[83]:


    booking_pivot.columns = [''.join(col).strip() for col in booking_pivot.columns.values]


    # In[84]:


    booking_pivot1=booking_pivot.reset_index()


    # In[85]:


    pivot_yest_bkng_df.columns = [''.join(col).strip() for col in pivot_yest_bkng_df.columns.values]


    # In[86]:


    pivot_yest_bkng_df1=pivot_yest_bkng_df.reset_index()


    # In[87]:


    pivot_prevs_mnth_bkng_df.columns = [''.join(col).strip() for col in pivot_prevs_mnth_bkng_df.columns.values]



    # In[41]:

    pivot_prevs_mnth_bkng_df1=pivot_prevs_mnth_bkng_df.reset_index()


    # In[89]:


    pivot_bkng_mtd_yest_df=pd.merge(booking_pivot1,pivot_yest_bkng_df1,on=['PINTYPE','PUDTYPES'],suffixes=('-MTD','-YST'))


    # In[90]:


    pivot_bkng_prvs_mtd_yest_df=pd.merge(pivot_bkng_mtd_yest_df,pivot_prevs_mnth_bkng_df1,on=['PINTYPE','PUDTYPES'])


    # In[91]:


    #this is final pivot for BKG
    pivot_bkng_prvs_mtd_yest_df.rename(columns={'ACT_WT':'ACT_WT_'+current_mnth,'COST':'COST_'+current_mnth,'ACT_WT(T)':'ACT_WT(T)_'+current_mnth,'COST(Lakhs)':'COST(Lakhs)-'+current_mnth,'CPKG':'CPKG-'+current_mnth},inplace=True)


    # In[92]:


    pivot_bkng_prvs_mtd_yest_df1=pivot_bkng_prvs_mtd_yest_df[['PINTYPE','PUDTYPES','COST(Lakhs)-YST','CPKG-YST','COST(Lakhs)-MTD','CPKG-MTD','COST(Lakhs)-'+current_mnth,'CPKG-'+current_mnth]]


    # In[93]:


    pivot_bkng_prvs_mtd_yest_df1


    # In[94]:


    # In[42]:

    delivery_pivot.columns = [''.join(col).strip() for col in delivery_pivot.columns.values]


    # In[95]:


    delivery_pivot1=delivery_pivot.reset_index()


    # In[96]:


    pivot_yest_dlry_df.columns = [''.join(col).strip() for col in pivot_yest_dlry_df.columns.values]


    # In[97]:


    pivot_yest_dlry_df1=pivot_yest_dlry_df.reset_index()


    # In[98]:


    pivot_prevs_mnth_dlry_df.columns = [''.join(col).strip() for col in pivot_prevs_mnth_dlry_df.columns.values]


    # In[99]:


    pivot_prevs_mnth_dlry_df1=pivot_prevs_mnth_dlry_df.reset_index()


    # In[100]:


    pivot_dlry_mtd_yest_df=pd.merge(delivery_pivot1,pivot_yest_dlry_df1,on=['PINTYPE','PUDTYPES'],suffixes=('-MTD','-YST'))


    # In[101]:


    pivot_prvs_mtd_yest_df=pd.merge(pivot_dlry_mtd_yest_df,pivot_prevs_mnth_dlry_df1,on=['PINTYPE','PUDTYPES'])


    # In[102]:


    #this is final pivot for DLV
    pivot_prvs_mtd_yest_df.rename(columns={'ACT_WT':'ACT_WT_'+current_mnth,'COST':'COST_'+current_mnth,'ACT_WT(T)':'ACT_WT(T)_'+current_mnth,'COST(Lakhs)':'COST(Lakhs)-'+current_mnth,'CPKG':'CPKG-'+current_mnth},inplace=True)


    # In[103]:


    pivot_prvs_mtd_yest_df1=pivot_prvs_mtd_yest_df[['PINTYPE','PUDTYPES','COST(Lakhs)-YST','CPKG-YST','COST(Lakhs)-MTD','CPKG-MTD','COST(Lakhs)-'+current_mnth,'CPKG-'+current_mnth]]


    # In[43]:

    from pandas import ExcelWriter
    with ExcelWriter(r'C:\Users\rajeeshv\Downloads\Rajesh\mahesh\Cost Monitoring Reports\Cost_Monitoring_Report.xlsx') as writer:
        pivot_prvs_mnth_yest_df1.to_excel(writer,engine='xlsxwriter',sheet_name='Cost with BKG&DLV')
        pivot_bkng_prvs_mtd_yest_df1.to_excel(writer,engine='xlsxwriter',sheet_name='Cost with BKG')
        pivot_prvs_mtd_yest_df1.to_excel(writer,engine='xlsxwriter',sheet_name='Cost with DLV')


    # In[109]:


    # In[44]:

    filepath=r'C:\Users\rajeeshv\Downloads\Rajesh\mahesh\Cost Monitoring Reports\Cost_Monitoring_Report.xlsx'


    # In[47]:

    #vishwas.j@spoton.co.in
    TO=['vishwas.j@spoton.co.in']
    #TO=['mahesh.reddy@spoton.co.in']
    FROM='vishwas.j@spoton.co.in'
    CC=['mahesh.reddy@spoton.co.in','vishwas.j@spoton.co.in']
    #CC=["mahesh.reddy@spoton.co.in"]
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "Monitoring Report" + " - " + str(yest_date)
    html='''<html>
    <h4>Dear All,</h4>
    <p>PFA the Monitoring Report for $date</p>
    </html>'''
    s = Template(html).safe_substitute(date=yest_date)
    report=""
    report+=s
    report+='<br>'
    report+='Cost summary including Booking and Delivery - Yesterday, MTD and Previous month'
    report+='<br>'
    report+='<br>'+pivot_prvs_mnth_yest_df1.to_html()+'<br>'
    report+='<br>'
    report+='Cost summary Booking - Yesterday, MTD and Previous month'
    report+='<br>'
    report+='<br>'+pivot_bkng_prvs_mtd_yest_df1.to_html()+'<br>'
    report+='<br>'
    report+='Cost summary Delivery - Yesterday, MTD and Previous month'
    report+='<br>'
    report+='<br>'+pivot_prvs_mtd_yest_df1.to_html()+'<br>'
    abc=MIMEText(report,'html')
    msg.attach(abc)
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filepath,"rb").read() )
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO+CC, msg.as_string())
    server.quit()

except:
  TO=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  #msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "ERROR Report" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in Monitoring Report'
  report+='<br>'

  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO, msg.as_string())
  server.quit()



# In[ ]:



