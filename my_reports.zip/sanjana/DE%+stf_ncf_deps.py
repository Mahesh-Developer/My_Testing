
# coding: utf-8

# In[ ]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta
import sys
import Utilities
reload(sys).setdefaultencoding("ISO-8859-1")


# In[ ]:


# if date.today()-timedelta(1)==7:
#     querydate=date.today()-timedelta(2)
# else:
querydate=date.today()-timedelta(1)

# querydate='2017-12-16'
# In[ ]:


# cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")


# # In[ ]:


# cursor=cnxn.cursor()
#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
#cursor = cnxn.cursor()


# In[ ]:
#try:
print (querydate)

query1=("""EXEC dbo.USP_DELV_EFF_SC_WISE_ALL 'S', '{0}' , '{1}'""".format(querydate,querydate))
query2=("""EXEC dbo.USP_DELV_EFF_SC_WISE_ALL 'D', '{0}' , '{1}'""".format(querydate,querydate))
print (query1)


# In[ ]:


# query1


# In[ ]:


data=pd.read_sql(query1,Utilities.cnxn)
#print (data)
data1=pd.read_sql(query2,Utilities.cnxn)
#print (data1)
print (len(data))
print (len(data1))

# In[ ]:


#data.columns


# In[ ]:


# data1=pd.read_excel(r'E:\RAJESH M P\RAJESH M P\a Rajesh M P\Reports\Closing stock\Delivery efficiency stf ccf ncf\Delivery efficiency with STF_NCF_CCF.xlsx','CCF & NCF data')


# In[ ]:


# data=pd.read_excel(r'E:\RAJESH M P\RAJESH M P\a Rajesh M P\Reports\Closing stock\Delivery efficiency stf ccf ncf\Delivery efficiency with STF_NCF_CCF.xlsx','Con Call Data')


# In[ ]:


data.rename(columns={'CCF': 'CCF_without_DRS_block'}, inplace=True)
# data.rename(columns={'NON-CCF': 'STF'}, inplace=True)
data.rename(columns={'NON_CCF': 'STF'}, inplace=True)
#print (data.head())
data[['DRS_BLOCK','CCF_without_DRS_block']]


# In[ ]:


# data['CCF']=data.apply(lambda x:x['DRS_BLOCK'] + x['CCF_without_DRS_block'],axis=1)
data = data.reset_index()
data['CCF']=data['DRS_BLOCK'] + data['CCF_without_DRS_block']


# In[ ]:


#data

print (data.columns)

# In[ ]:
# data['STF']=0

pivot=pd.pivot_table(data,index=["ControlArea",],values=["TOTAL","Delivered","NCF","STF","CCF","DEPS","DRS_BLOCK"],aggfunc={"DRS_BLOCK":sum,"TOTAL":sum,"Delivered":sum,"NCF":sum,"STF":sum,"CCF":sum,"DEPS":sum},fill_value=0,margins=True)


# In[ ]:


#pivot.head(9)


# In[ ]:


pivot['DE%'] = pd.np.round((pivot['Delivered'] / pivot['TOTAL'])*100)
pivot['STF%'] = pd.np.round((pivot['STF']/ pivot['TOTAL'])*100)
pivot['NCF%']= pd.np.round((pivot['NCF'] / pivot['TOTAL'])*100)
pivot['CCF%']= pd.np.round((pivot['CCF'] / pivot['TOTAL'])*100)
pivot['DEPS%']= pd.np.round((pivot['DEPS'] / pivot['TOTAL'])*100)
pivot['DRS_BLOCK%']= pd.np.round((pivot['DRS_BLOCK'] / pivot['TOTAL'])*100)


# In[ ]:


# pivot.TOTAL = pivot.TOTAL.astype(int)
#del pivot['STF']
import numpy as np
pivot=pivot.replace([np.inf,-np.inf],np.nan).fillna(0)
#pivot=pivot.fillna(0)
pivot = pivot[['TOTAL','Delivered','DE%','STF%','CCF%','DEPS%','NCF%',"DRS_BLOCK%"]].astype(int)


# In[ ]:


#pivot.head(10)


# In[ ]:


Std = data[data['DEL_LOCATION_TYPE']=='STD']


# In[ ]:


pivotS=pd.pivot_table(Std,index=["ControlArea",],values=["TOTAL","Delivered","NCF","STF","CCF","DEPS","DRS_BLOCK"],aggfunc={"DRS_BLOCK":sum,"TOTAL":sum,"Delivered":sum,"NCF":sum,"STF":sum,"CCF":sum,"DEPS":sum},fill_value=0,margins=True)


# In[ ]:


pivotS['DE%'] = pd.np.round((pivotS['Delivered'] / pivotS['TOTAL'])*100,0)
pivotS['STF%'] = pd.np.round((pivotS['STF']/ pivotS['TOTAL'])*100,0)
pivotS['NCF%']= pd.np.round((pivotS['NCF'] / pivotS['TOTAL'])*100,0)
pivotS['CCF%']= pd.np.round((pivotS['CCF'] / pivotS['TOTAL'])*100,0)
pivotS['DEPS%']= pd.np.round((pivotS['DEPS'] / pivotS['TOTAL'])*100,0)
pivotS['DRS_BLOCK%']= pd.np.round((pivotS['DRS_BLOCK'] / pivotS['TOTAL'])*100,0)


# In[ ]:

pivotS=pivotS.replace([np.inf,-np.inf],np.nan).fillna(0)
pivotS = pivotS[['TOTAL','Delivered','DE%','STF%','CCF%','DEPS%','NCF%',"DRS_BLOCK%"]].astype(int)


# In[ ]:


Oda = data[data['DEL_LOCATION_TYPE']=='ODA']


# In[ ]:


pivotO=pd.pivot_table(Oda,index=["ControlArea",],values=["TOTAL","Delivered","NCF","STF","CCF","DEPS","DRS_BLOCK"],aggfunc={"DRS_BLOCK":sum,"TOTAL":sum,"Delivered":sum,"NCF":sum,"STF":sum,"CCF":sum,"DEPS":sum},fill_value=0,margins=True)


# In[ ]:


#pivotO['DE%'] = pd.np.round((pivotO['Delivered'] / pivotO['TOTAL'])*100,0)
pivotO['DE%'] = pivotO['Delivered'].divide(pivotO['TOTAL'])*100
#pivotO['STF%'] = pd.np.round((pivotO['STF']/ pivotO['TOTAL'])*100,0)
pivotO['STF%'] = pivotO['STF'].divide(pivotO['TOTAL'])*100
# pivotO['NCF%']= pd.np.round((pivotO['NCF'] / pivotO['TOTAL'])*100,0)
pivotO['NCF%']= pivotO['NCF'].divide(pivotO['TOTAL'])*100
# pivotO['CCF%']= pd.np.round((pivotO['CCF'] / pivotO['TOTAL'])*100,0)
pivotO['CCF%']= pivotO['CCF'].divide(pivotO['TOTAL'])*100

#pivotO['DEPS%']= pd.np.round((pivotO['DEPS'] / pivotO['TOTAL'])*100,0)
pivotO['DEPS%']= pivotO['DEPS'].divide(pivotO['TOTAL'])*100
pivotO['DRS_BLOCK%']= pivotO['DRS_BLOCK'].divide(pivotO['TOTAL'])*100


# In[ ]:

pivotO=pivotO.replace([np.inf, -np.inf], np.nan)
pivotO=pivotO.fillna(0)
pivotS
pivotO=pivotO.replace([np.inf,-np.inf],np.nan).fillna(0)
pivotO = pivotO[['TOTAL','Delivered','DE%','STF%','CCF%','DEPS%','NCF%',"DRS_BLOCK%"]].astype(int)
#print (pivotO)
# In[ ]:


from pandas import ExcelWriter


# In[ ]:


with ExcelWriter(r'D:\Data\ODA_Loads_Ton_wise\DE.xlsx') as writer:
       pivot.to_excel(writer, sheet_name='pivot',engine='xlsxwriter')
       data.to_excel(writer, sheet_name='Con Call Data',engine='xlsxwriter')
       data1.to_excel(writer, sheet_name='CCF & NCF data',engine='xlsxwriter')


# In[ ]:


filepath=r'D:\Data\ODA_Loads_Ton_wise\DE.xlsx'


# In[ ]:


import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback

oppath1=filepath
#FTP Upload starts
print ('Logging in...')
ftp = ftplib.FTP()  
ftp.connect('10.109.230.50')  
print (ftp.getwelcome())
try:  
    try:  
        ftp.login('HOSQTeam', 'Te@mH0$q')
        print ('login done')
        ftp.cwd('Auto_reports')  
        #ftp.cwd('FIFO')
        # move to the desired upload directory  
        print ("Currently in:", ftp.pwd()) 
        print ('Uploading...')  
        fullname = oppath1
        name = os.path.split(fullname)[1]  
        f = open(fullname, "rb")  
        ftp.storbinary('STOR ' + name, f)  
        f.close()  
        print ("OK"  )
        print ("Files:")  
        print (ftp.retrlines('LIST'))
    finally:  
        print ("Quitting...")
        ftp.quit()  
except:  
    traceback.print_exc()


# In[ ]:


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.MIMEBase import MIMEBase
from email import Encoders
import os

from_addr = 'mis.ho@spoton.co.in'
# to_addr = ['pawan.sharma@spoton.co.in','shivananda.p@spoton.co.in']
to_addr = ['aom_spot@spoton.co.in','dom_spot@spoton.co.in','rom_spot@spoton.co.in','asmita.panigrahi@spoton.co.in','SQ_spot@spoton.co.in','banusanketh.dc@spoton.co.in','narendra.londhe@spoton.co.in']
cc_addr = ["abhik.mitra@spoton.co.in", "jothi.menon@spoton.co.in",'satya.pal@spoton.co.in','rajesh.kumar@spoton.co.in','shivananda.p@spoton.co.in','pawan.sharma@spoton.co.in']
bcc_addr = ['anitha.thyagarajan@spoton.co.in','mahesh.reddy@spoton.co.in']

# cc_addr = ['mahesh.reddy@spoton.co.in']
# bcc_addr=['mahesh.reddy@spoton.co.in']
username = 'mis.ho@spoton.co.in'
password = 'Mis@2019'

msg = MIMEMultipart()

msg['From'] = from_addr
msg['To'] = ', '.join(to_addr)
msg['cc'] = ', '.join(cc_addr)
msg['bcc'] = ', '.join(bcc_addr)
msg['Subject'] = 'Delivery Efficiency with STF/NCF/CCF'
html='''<html>
<h4>Dear All,</h4>
<p>PFA, Delivery efficiency with STF/NCF/CCF</p>
</html>'''
# part11=MIMEText(html,'html')
# #msg.attach(part11)

# # html3='''<h3>1. Location type : ALL</h3>'''
# # part15 = MIMEText(html3,'html')
# # msg.attach(part15)
# part12=MIMEText('''<h4>1. Location type : ALL</h4>'''+pivot.to_html(),'html')
# #msg.attach(part12)
# part13=MIMEText('''<h4>2. Location type : STD</h4>'''+pivotS.to_html(),'html')
# #msg.attach(part13)
# part14=MIMEText('''<h4>3. Location type : ODA</h4>'''+pivotO.to_html(),'html')
#msg.attach(part14)
html3='''
<h5> To download the Delivery Efficiency with STF/NCF/CCF data, Please click the link below </h5>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/DE.xlsx"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/DE.xlsx</p></b>
'''
html1='''<h5>Thanks & Regards</h5></b>
<h5>HO-SQ</h5>'''
    
#  msg.attach(part10)
report=""
report+=html
report+='<br>'
report+='<h4>1. Location type : ALL</h4>'
# report+='<br>'
report+='<br>'+pivot.to_html()+'<br>'
# report+='<br>'
report+='<h4>2. Location type : STD</h4>'
# report+='<br>'
report+='<br>'+pivotS.to_html()+'<br>'
# report+='<br>'
report+='<h4>3. Location type : ODA</h4>'
# report+='<br>'
report+='<br>'+pivotO.to_html()+'<br>'
report+=html3
report+='<br>'
report+=html1
abc=MIMEText(report,'html')
msg.attach(abc)
server = smtplib.SMTP('smtp.sendgrid.net',587)
part=MIMEBase('application','octet-stream')
# part1=MIMEBase('application','octet-stream')
part.set_payload(open(filepath,'rb').read())
# part1.set_payload(open(filepath1,'rb').read())
Encoders.encode_base64(part)
server.ehlo()
server.starttls()
server.ehlo()
# server.login('spoton.co.in','#Xat694#')
# server.login('vishwas.j@spoton.co.in','Nov@2018')
server.login("spoton.net.in", "Star@123#")
server.sendmail(from_addr,to_addr+cc_addr+bcc_addr,msg.as_string())
print ('mail sent succesfully')
server.quit()

# except:

#   TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in']  
#   CC=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
#   FROM="mahesh.reddy@spoton.co.in"
#   msg = MIMEMultipart()
#   msg["From"] = FROM
#   msg["To"] = ",".join(TO)
#   msg["CC"] = ",".join(CC)
#   #msg["BCC"] = ",".join(BCC)
#   #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
#   msg["Subject"] = "ERROR Report" 
#   report=""
#   report+='Hi,'

#   report+='<br>'
#   report+='There was some error in Delivery Efficiency with STF/NCF/CCF'
#   report+='<br>'
  
#   abc=MIMEText(report.encode('utf-8'),'html')
#   msg.attach(abc)
#   server=smtplib.SMTP('smtp.sendgrid.net', 587)
#   server.ehlo()
#   server.starttls()
#   server.ehlo()
#   server.login("spoton.net.in", "Star@123#")
#   failed = server.sendmail(FROM, TO+CC, msg.as_string())
#   server.quit()


