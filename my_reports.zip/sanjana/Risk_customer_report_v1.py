# -*- coding: utf-8 -*-
"""
Created on Wed Feb 15 15:45:22 2017

@author: rajeeshv
"""

import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
import os
import Utilities

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


crmpkpquery = ("""
        EXEC USP_RISK_CUST_CRM_PICKUP_DETAIL 'Y'
        """)
crmpkpdata = pd.read_sql(crmpkpquery, Utilities.cnxn)


unconctquery = ("""
        EXEC USP_RISK_CUST_UNCONNECT_DETAIL
        """)
unconctdata = pd.read_sql(unconctquery, Utilities.cnxn)

undelquery = ("""
        EXEC USP_RISK_CUST_UNDELCON_DETAIL
        """)
undeldata = pd.read_sql(undelquery, Utilities.cnxn)


print len(undeldata)