# -*- coding: utf-8 -*-
"""
Created on Tue Nov 08 14:23:57 2016

@author: rajeeshv
"""


# coding: utf-8

# In[1]:



# In[1]:

import pandas as pd
from datetime import datetime, timedelta
import glob
import numpy as np

import os
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from pandas import ExcelWriter
from email import encoders
import ftplib
import traceback

import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import Utilities
# In[2]:



#closing1yes = pd.read_csv(r'D:\Data\Combined_closing_1HR.csv')
#closing1yes = pd.io.excel.read_excel('OCID_CLOSINGSTOCK_1HR.xls','IEP_Closing_Stock_1HR')

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

etanexta4daysquery = ("""
        EXEC USP_ETA_PREDICTION_SHIVA
        """)

closing1yes = pd.read_sql(etanexta4daysquery, Utilities.cnxn)


##closing1yes = pd.io.excel.read_excel('http://10.109.230.50/downloads/OCID_CLOSINGSTOCK_1HR/OCID_CLOSINGSTOCK_1HR.xls', 'IEP_Closing_Stock_1HR')
len(closing1yes)

print closing1yes.columns.tolist()


# In[2]:

##closingMAAC = closing1yes[closing1yes['DEST BRCD']=='MAAC']
sclist = ['BLRF','CCUC','HYDO','BWDB','MAAC']
closingMAAC = closing1yes[closing1yes['REASSIGN_DESTCD'].isin(sclist)]
len(closingMAAC)


# In[3]:

pmd_sep = pd.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\MAAC_Routewise_input\PMD_Sep.csv')
pmdsep1 = pmd_sep[['BRANCH_CODE2','PINCODE2','CUSTOMERCODE','CUSTOMERNAME','PUD_CODE2','PUD_NAME2','PUDTYPE2']]
pmd_aug = pd.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\MAAC_Routewise_input\PMD_Aug.csv')
pmdaug1 = pmd_aug[['BRANCH_CODE2','PINCODE2','CUSTOMERCODE','CUSTOMERNAME','PUD_CODE2','PUD_NAME2','PUDTYPE2']]
pmd_july = pd.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\MAAC_Routewise_input\PMD_July.csv')
pmdjuly1 = pmd_july[['BRANCH_CODE2','PINCODE2','CUSTOMERCODE','CUSTOMERNAME','PUD_CODE2','PUD_NAME2','PUDTYPE2']]
len(pmdsep1), len(pmdaug1), len(pmdjuly1)


# In[4]:

pmdappend = pmdsep1.append(pmdaug1)
pmd = pmdappend.append(pmdjuly1)
len(pmd)


# In[5]:

pmd0 = pmd[pmd['BRANCH_CODE2'].isin(sclist)]
pmd1 = pmd0.drop(['BRANCH_CODE2'], axis=1)
len(pmd1)


# In[6]:

pmd1['primary_key'] = pmd1.apply(lambda x:str(x['PINCODE2'])+str('-')+str(x['CUSTOMERCODE']),axis=1)


# In[7]:

#pmd1.head()
pmd_ids = pmd1.drop_duplicates(cols='primary_key')
len(pmd_ids)
pmd_pincode_ids = pmd1.drop_duplicates(cols='PINCODE2') #to be used later for the merge


# In[8]:

closingMAACpc = pd.merge(closingMAAC, pmd_ids, left_on=['PinCode','Customer Code'], right_on=['PINCODE2','CUSTOMERCODE'],how='left')
#ymerge_cust=pd.merge(yorginal_success_cust,yorginal_cancel_cust,on=['BRCD','CustCode','PartyType'],suffixes = ['Success','Cancel'],how='outer')


# In[9]:

len(closingMAACpc)


# In[10]:

#ccfcategorylist = ['SENDER FAILURE','RECEIVER FAILURE','DEPS']
#closingMAACpc = closingMAACpc[~closingMAACpc['Con Status Category'].isin(ccfcategorylist)]


# In[11]:

len(closingMAACpc)

print closingMAACpc.columns.tolist()
# In[12]:

####closingMAACpc_cols = closingMAACpc[['DOCKNO','REASSIGN_DESTCD', 'PinCode','ACTUWT','PIECES','PUD_CODE2','PUD_NAME2','PUDTYPE2']]

closingMAACpc_cols = closingMAACpc
# In[13]:

import math
def allocate(pudcode):
    if math.isnan(pudcode):
        return 'Pincode'
    else:
        return 'Cust+Pincode'
    


# In[14]:

closingMAACpc_cols['Allocation'] = closingMAACpc.apply(lambda x: allocate(x['PUD_CODE2']), axis=1)


# In[15]:

closeMAAC_CcPc = closingMAACpc_cols[closingMAACpc_cols['Allocation']=='Cust+Pincode']
closeMAAC_Pc = closingMAACpc_cols[closingMAACpc_cols['Allocation']=='Pincode']


# In[16]:

closeMAAC_Pc1 = closeMAAC_Pc.drop(['PUD_CODE2','PUD_NAME2','PUDTYPE2'], axis=1)


# In[17]:

closeMAAC_Pc_Merge = pd.merge(closeMAAC_Pc1, pmd_pincode_ids, left_on=['PinCode'], right_on=['PINCODE2'],how='left')


# In[18]:

outputdf = closeMAAC_Pc_Merge.append(closeMAAC_CcPc)
len(outputdf)


# In[19]:

outputdf = outputdf[['DOCKNO','REASSIGN_DESTCD', 'PinCode','ACTUWT','PIECES','VOLUME','Customer Code','Customer Name','CSGENM','CSGNNM','PUD_CODE2','PUD_NAME2','PUDTYPE2','Allocation']]
#outputdf.to_csv('out_btw.csv')

#for creating a decent looking df for mailbody
outputdf = outputdf.replace(['PERFECT ROAD TRANSPORT (STD ) NISSAN DLY','T.G. RAJASUBBIRAMANIAN (STD)','PERFECT ROAD TRANSPORT (STD)','T.G. RAJASUBBIRAMANIAN (FIX)','KUMAR E (STD - CAVIN KARE)','B BALAMURUGAN (STD - FIX)','NAVEEN TRANSPORT (STD )','HARISH TRANSPORT (STD)','C R RAJANNA (ODA - PANTALOON/RELIANCE)','C R RAJANNA (ODA - TUMKUR / CHITRADURGA)','SUNDER WELLINGTON (STD - PHILIPS & BEL DELIVERY)','YADNESH BHAIDAS MUKADAM (STD - 3M / PHILIPS)','SIDDALINGAIAH (ODA - PANTALOON/RELIANCE)','TRIDENT SOLUTION (STD-FDC / STAR LOGISTICS)','SANTOSH PANDURANG BHOIR (FIX - ODA)','REKHA SHUKLA (STD - PANTALOON)'],['PERFECT RT NISSAN','T.G. RAJA (STD)','PERFECT RT (STD)','T.G. RAJA (FIX)','KUMAR(STD-CAVINKARE)','B BALAMURGN(STD-FIX)','NAVEEN TRANS(STD)','HARISH TRANS(STD)','C R RAJANNA(PNTL_REL)','C R RAJANNA(TMKR_CDURGA)','SUNDER WLGTN (PHILIPS&BEL)','YADNESH MUKADAM(3M/PHILIPS)','SIDDALINGAIAH(PNTL_REL)','TRIDENT SOLN(FDC&STAR_LGST)','SANTOSH BHOIR(FIX_ODA)','REKHA SHUKLA(PNTL)'])


# In[20]:

grpby=outputdf.groupby(['DEST BRCD','PUD_NAME2']).agg({'DOCKNO': 'count','ACTUWT': 'sum'}).reset_index()


# In[21]:

grpby['wt(T)']= grpby.apply(lambda x: pd.np.round((x['ACTUWT']/1000),1),axis=1)
grpby = grpby.drop(['ACTUWT'], axis=1)


# In[22]:

grpby = grpby.sort_values(['wt(T)'], ascending=False)
grpby = grpby[grpby['PUD_NAME2']!='MARKET']
grpby = grpby[grpby['PUD_NAME2']!='COUNTER']


# In[23]:

grpby


outputdf #FTP this data, provide the link in the mail body and save it in the folder. It has a ts field with name 'Timestate Date'
timestampnow = datetime.now()
opfilevar=timestampnow.date()
opfilevar1=timestampnow.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=np.round((float(currhrs)/60),0)


filePath = oppath_summary
def sendEmail(#TO = ["rajeesh.vr@spoton.co.in"],
            #TO = ["joseph.arul.seelan@spoton.co.in","renugopal.l@spoton.co.in","Sathya.Chander@Spoton.Co.In"],
            TO = ["vishwas.j@spoton.co.in"],
            #CC = ["rajeesh.vr@spoton.co.in"],
            #CC = ["sqtf@spoton.co.in"],
            CC = ["vishwas.j@spoton.co.in"],
            #BCC = ["vinayak.kumbhar@spoton.co.in","vinodkumar.mishra@spoton.co.in","nitin.tatyarao@spoton.co.in","kiran.pawar@spoton.co.in","jai.prakash@spoton.co.in"] ,
            BCC = ["vishwas.j@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "Load Available for movement @ "+ str(opfilevar)+"-"+str(opfilevar2)
    msg["Subject"] = "SC Routewise Summary @ "+ str(opfilevar)+"-"+str(opfilevar2)
    body_text = """
    Dear All,
    
    PFB the SC Routewise Summary @ """ +str(opfilevar)+"-"+str(opfilevar2)+"""

    
    """+str(finalgrpby_mail)+"""
    
    Note:
    The data is exclusive of all CCF and DEPS cons.
    Con_All: Gives the total no of cons for each vendor
    wt(T)_All: Gives the total weight of cons for each vendor
    Con_DRS: Gives the total no of cons for each vendor, for which the DRS has been prepared in the duration of that day
    wt(T)_DRS: Gives the total weight of cons for each vendor, for which the DRS has been prepared in the duration of that day
    diff_Wt: Gives the difference between wt(T)_All and wt(T)_DRS in tonnes
    
    To download the con level data, Please click the link below
    
    http://spoton.co.in/downloads/IEProjects/ETA/SC_Routewise_data.csv
    
    """
    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends