
# coding: utf-8

# In[90]:

import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
import calendar
#import datetime
from pandas import ExcelWriter

import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import os


import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import Utilities
from pandas import ExcelWriter

now = datetime.now()
today = now.strftime("%a")
print today
# In[91]:

#ocidclosingstockbase = pd.io.excel.read_excel(r'http://10.109.230.50/downloads/OCID/OCID.xls','CLOSING STOCK')
#datenow = date.today()
#dateyest = datenow-timedelta(hours=24)
#ocidclosingstockbase.loc[ocidclosingstockbase.index,'Timestamp'] = dateyest
#ocidclosingstockbase.to_csv(r'D:\\Data\\eta_rank\Destination_sc_closingstock\\Closing_Stock_'+str(dateyest)+'.csv',encoding='utf-8')

opfilevar =date.today() - timedelta(hours=24)
opfilevarhours =datetime.now() - timedelta(hours=24)
#yesterday = datetime.datetime.today() - datetime.timedelta (days=1) 
new_period=opfilevarhours.replace(hour=12, minute=0).strftime ('%Y-%m-%d %H:%M:%S')
print new_period


openingstock = pd.io.excel.read_excel(r'http://10.109.230.50/downloads/OCID/OCID.xls','OPENING STOCK')
fullincomingstock = pd.io.excel.read_excel(r'http://10.109.230.50/downloads/OCID/OCID.xls','INCOMING')
deliveredstock = pd.io.excel.read_excel(r'http://10.109.230.50/downloads/OCID/OCID.xls','DELIVERED')
closingstockfull = pd.io.excel.read_excel(r'http://10.109.230.50/downloads/OCID/OCID.xls','CLOSING STOCK')

print 'Stocks are', len(openingstock),len(fullincomingstock),len(deliveredstock)

### To exclude Liberty FOC cons
liblist = [000119721.0]
openingstock = openingstock[~(openingstock['CSGNCD'].isin(liblist))]
openingstock = openingstock[~(openingstock['CSGECD'].isin(liblist))]

deliveredstock = deliveredstock[~(deliveredstock['CSGNCD'].isin(liblist))]
deliveredstock = deliveredstock[~(deliveredstock['CSGECD'].isin(liblist))]

fullincomingstock = fullincomingstock[~(fullincomingstock['CSGNCD'].isin(liblist))]
fullincomingstock = fullincomingstock[~(fullincomingstock['CSGECD'].isin(liblist))]
### To exclude Liberty FOC cons

## To Exclude Reliance project cons
projectparentcodesexclist = [000117991.0,000118040.0,000118041.0,000118042.0,000118043.0,000118075.0,000111007.0,000114381.0]
openingstock = openingstock[~(openingstock['PARENTCODE'].isin(projectparentcodesexclist))]
fullincomingstock = fullincomingstock[~(fullincomingstock['PARENTCODE'].isin(projectparentcodesexclist))]
deliveredstock = deliveredstock[~(deliveredstock['PARENTCODE'].isin(projectparentcodesexclist))]

projectconsgcd = [000117991.0,000118040.0,000118041.0,000118043.0,000111007.0,000118042.0,000118075.0,000114381.0]
openingstock = openingstock[~(openingstock['CSGNCD'].isin(projectconsgcd))]
fullincomingstock = fullincomingstock[~(fullincomingstock['CSGNCD'].isin(projectconsgcd))]
deliveredstock = deliveredstock[~(deliveredstock['CSGNCD'].isin(projectconsgcd))]

openingstock = openingstock[~(openingstock['CSGECD'].isin(projectconsgcd))]
fullincomingstock = fullincomingstock[~(fullincomingstock['CSGECD'].isin(projectconsgcd))]
deliveredstock = deliveredstock[~(deliveredstock['CSGECD'].isin(projectconsgcd))]
## Exclude Srinagar due to Embargo. Included on 19-12-2016
#excludebranchlist = ['SXRF']
#openingstock = openingstock[~(openingstock['DEST BRCD'].isin(excludebranchlist))]
#fullincomingstock = fullincomingstock[~(fullincomingstock['DEST BRCD'].isin(excludebranchlist))]
#deliveredstock = deliveredstock[~(deliveredstock['DEST BRCD'].isin(excludebranchlist))]
## Exclude Srinagar due to Embargo. Included on 19-12-2016

## To Exclude Pantaloons
##parentcodesexclist = [000116867.0,000113916.0,000096307.0]
parentcodesexclist = [000116867.0,000118067.0,000118068.0,000108751.0,000118554.0]
#destareaexcludelist = ['BOMA','CCUA'] ## Added BLRA on 07-11-2016 and deleted BLRA on 11-11-2016, Deleted CCUA on 23022017
destareaexcludelist = ['BOMA','HYDA'] ## Added HYDA on 27-10-2017
openingstock = openingstock[~((openingstock['PARENTCODE'].isin(parentcodesexclist)) & (openingstock['DEST AREA'].isin(destareaexcludelist)))]
fullincomingstock = fullincomingstock[~((fullincomingstock['PARENTCODE'].isin(parentcodesexclist))& (fullincomingstock['DEST AREA'].isin(destareaexcludelist)))]
deliveredstock = deliveredstock[~((deliveredstock['PARENTCODE'].isin(parentcodesexclist)) & (deliveredstock['DEST AREA'].isin(destareaexcludelist)))]
#deliveredstock = deliveredstock[(deliveredstock['PARENTCODE']!=000116867.0)]
print 'Stocks are', len(openingstock),len(fullincomingstock),len(deliveredstock)

## To Exclude Pantaloons
# In[92]:

#branchdf = pd.read_csv('D:\Python\Scripts and Files\Path and Graph Files\Branchlist.csv')
#branchdf = pd.DataFrame(branchdf,columns=['BRANCH CODE','Area'])

delbranchdf = pd.DataFrame(deliveredstock,columns=['DEST BRCD','DEST AREA'])
opbranchdf = pd.DataFrame(openingstock,columns=['DEST BRCD','DEST AREA'])

branchdf = pd.merge(delbranchdf,opbranchdf,on=['DEST BRCD','DEST AREA'],how='outer')
branchdf.rename(columns={'DEST BRCD':'BRANCH CODE','DEST AREA':'Area'}, inplace=True)
branchdf = branchdf.drop_duplicates(['BRANCH CODE'])

print len(openingstock), len(fullincomingstock), len(deliveredstock)

## For Holiday exclusion
####holidaymaster = pd.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\Holiday_list_2016_test.csv')

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

holidayquery = ("""
        select * from tblYearlyHolidayMst with (nolock) where HDAY_DATE>'2016-01-01'
        """)

holidaymaster = pd.read_sql(holidayquery, Utilities.cnxn)
print len(holidaymaster)

def datestring(x):
    try:
        x = str(x)
        fulldate = datetime.strptime(x,'%Y-%m-%d %H:%M:%S')
        return fulldate
    except:
        x = str(x)
        fulldate = datetime.strptime(x,'%d-%m-%Y %H:%M')
        return fulldate


holidaymaster['HDAY_DATE'] = holidaymaster.apply(lambda x : datestring(x['HDAY_DATE']),axis=1)
selectdate = now-timedelta(days=1)
selectdate = selectdate.replace(hour=0, minute=0, second=0).strftime('%Y-%m-%d %H:%M:%S')
selectdate = datetime.strptime(selectdate,'%Y-%m-%d %H:%M:%S')
print selectdate,type(selectdate)

holidaylist = holidaymaster['HDAY_DATE']
holidaylist = list(set(holidaylist))

if selectdate in holidaylist:
    print 'Yesterday in holiday list'
    selectdf = holidaymaster[holidaymaster['HDAY_DATE']==selectdate]
    selectdfbrcdlist = selectdf['BRCD'].tolist()
    selectdfbrcdlist = list(set(selectdfbrcdlist))
    selectdfarealist = selectdf['ControlArea'].tolist()
    selectdfarealist = list(set(selectdfarealist))
    print selectdfbrcdlist
    print selectdfarealist
    
    openingstock = openingstock[~(openingstock['DEST BRCD'].isin(selectdfbrcdlist))]
    openingstock = openingstock[~(openingstock['DEST AREA'].isin(selectdfarealist))]
    
    fullincomingstock = fullincomingstock[~(fullincomingstock['DEST BRCD'].isin(selectdfbrcdlist))]
    fullincomingstock = fullincomingstock[~(fullincomingstock['DEST AREA'].isin(selectdfarealist))]
    
    deliveredstock = deliveredstock[~(deliveredstock['DEST BRCD'].isin(selectdfbrcdlist))]
    deliveredstock = deliveredstock[~(deliveredstock['DEST AREA'].isin(selectdfarealist))]
else:
    selectdfbrcdlist = []
    selectdfarealist = []
    print 'Yesterday not in holiday list'

## For Holiday exclusion
# In[93]:

openingstock = openingstock[openingstock['DEL LOCATION TYPE']=='STD']
fullincomingstock = fullincomingstock[fullincomingstock['DEL LOCATION TYPE']=='STD']
deliveredstock = deliveredstock[deliveredstock['DEL LOCATION TYPE']=='STD']
closingstockfull = closingstockfull[closingstockfull['DEL LOCATION TYPE']=='STD']

# In[94]:

#ignorestatuscodelist = ['D14', 'UCG']
ignorestatuscodelist = ['UCG','SSC','UG1','UG2','UG3','SHS']
#ignorestatuscodelist = ['UCG','SSC','UG1','UG2','UG3']
#ignorestatusdesclist = ['Awaiting for NSL Delivery Confirmation', 'Awaiting for ODA Delivery Confirmation', 'Change of Pincode from STD to ODA - Pending Approval', 'Non Serviceable Location', 'ODA DRS PREPARED', 'Shipment Held for ODA Delivery', 'Shipment held for Sales Tax inspection', 'Shipment Seized By Check Post / Sales Tax','STD to ODA Pincode Change Request - Awaiting CS Confirmation','Tagged For UCG']
openingstock=openingstock[~openingstock['Con Status Code'].isin(ignorestatuscodelist)]
closingstockfull=closingstockfull[~closingstockfull['Con Status Code'].isin(ignorestatuscodelist)]
#openingstock=openingstock[~openingstock['Con Status Desc'].isin(ignorestatusdesclist)]
#openingstock = openingstock[openingstock['DRS Blocked Due to Payment Issues']=='NO']
#openingstock = openingstock[openingstock['DRS Blocked due to ODA Pincode Change']=='NO']
#openingstock = openingstock[openingstock['DRS Blocked due to Demurrage']=='NO']


# In[112]:

incoming12stock = fullincomingstock[(fullincomingstock['INC ARRV CATEGORY']=='<12PM')]
openinggroupby=openingstock.groupby(['DEST BRCD']).agg({'DOCKNO': 'count'}).reset_index()
incoming12groupby=incoming12stock.groupby(['DEST BRCD']).agg({'DOCKNO': 'count'}).reset_index()
deliveredgroupby=deliveredstock.groupby(['DEST BRCD']).agg({'DOCKNO': 'count'}).reset_index()

# In[113]:

merge_effeciency = pd.merge(openinggroupby,incoming12groupby,on=['DEST BRCD'], suffixes=['_op','_in'],how='outer')
merge_effeciency = pd.merge(merge_effeciency,deliveredgroupby, on=['DEST BRCD'], how='outer')


# In[114]:

def getsum(x,y,z):
    try:
        return np.ceil((x*100.0)/(y+z))
    except:
        return 100.0


# In[115]:

merge_effeciency = merge_effeciency.fillna(0)
merge_effeciency['Delivery_Efficiency']= merge_effeciency.apply(lambda x:getsum(x['DOCKNO'],x['DOCKNO_op'],x['DOCKNO_in']),axis=1)
merge_effeciency.rename(columns={'DOCKNO':'DOCKNO_Delivered'}, inplace=True)
merge_effeciency=pd.merge(merge_effeciency,branchdf,left_on=['DEST BRCD'],right_on=['BRANCH CODE'], how = 'inner')
merge_effeciency.head()
merge_effeciency = merge_effeciency.drop(['BRANCH CODE'], axis=1)


# In[119]:

openingcons = merge_effeciency['DOCKNO_op'].sum() 
incomingcons = merge_effeciency['DOCKNO_in'].sum()
deliveredcons = merge_effeciency['DOCKNO_Delivered'].sum()
deliveryefficiency = pd.np.round(deliveredcons*100.0/(incomingcons+openingcons),2)
print openingcons, incomingcons, deliveredcons
#merge_effeciency.to_csv(r'C:\Data\Effeciency_Delivery\deliveryeff_19Nov_notVD1.csv', encoding='utf-8')


# In[118]:

merge_effeciency_area=merge_effeciency.groupby(['Area']).agg({'DOCKNO_op': 'sum','DOCKNO_in': 'sum','DOCKNO_Delivered': 'sum'}).reset_index()
merge_effeciency_area['Delivery_Efficiency']= merge_effeciency_area.apply(lambda x:getsum(x['DOCKNO_Delivered'],x['DOCKNO_op'],x['DOCKNO_in']),axis=1)
merge_effeciency_area.head()
#merge_effeciency_area.to_csv(r'merge_effeciency_area.csv')




## For CCF % AREA wise in Closing Stock
ccfsrlist = ['SENDER FAILURE', 'RECEIVER FAILURE']
ccfsrdf=closingstockfull[closingstockfull['Con Status Category'].isin(ccfsrlist)]
ccfsrdfgroupby = ccfsrdf.groupby(['DEST AREA']).agg({'DOCKNO': 'count'}).reset_index()

## For NON CCF Cons
nonccfsrdf=closingstockfull[~closingstockfull['Con Status Category'].isin(ccfsrlist)]
nonccfsrdfgroupby = nonccfsrdf.groupby(['DEST AREA']).agg({'DOCKNO': 'count'}).reset_index()
nonccfcons = nonccfsrdfgroupby['DOCKNO'].sum()
## For NON CCF Cons

## For CCF % AREA wise in Closing Stock

###For DueDate Cons


def datetimesplit(x):
    fulldate = datetime.strptime(x.split(' '),'%d-%m-%Y %H:%M:S')
    return fulldate
    

closingstockduecons = closingstockfull[closingstockfull['DUE DATE']==opfilevar]
closingstockduecons['ARRV_AT_DEST_SC'] = closingstockduecons.apply(lambda x:x['ARRV AT DEST SC'],axis=1)
closingarriv12 = closingstockduecons[closingstockduecons['ARRV_AT_DEST_SC']<=new_period]
print len(closingarriv12)
print type(closingstockduecons['ARRV AT DEST SC'].values[0])
closingarriv12free = closingarriv12[closingarriv12['Is Free Con']=='YES']

closingarriv12grp = closingarriv12.groupby(['DEST AREA']).agg({'DOCKNO':len}).reset_index()
totalduecons = closingarriv12grp['DOCKNO'].sum()
closingarriv12freegrp = closingarriv12free.groupby(['DEST AREA']).agg({'DOCKNO':len}).reset_index()
totaldueconsfree = closingarriv12freegrp['DOCKNO'].sum()
print 'totaldueconsfree',totaldueconsfree

cutoffformorefreecons = 0.1*totaldueconsfree
#cutoffformorefreecons = 0.01*totaldueconsfree


## For handling no free cons in the last days report. Edit on 29-01-2017
#try:
morefreeconsdestarealist = closingarriv12freegrp[closingarriv12freegrp['DOCKNO']>=cutoffformorefreecons]['DEST AREA'].tolist()
morefreeconsdestarealist = [str(x) for x in morefreeconsdestarealist]
morefreeconslist = closingarriv12freegrp[closingarriv12freegrp['DOCKNO']>=cutoffformorefreecons]['DOCKNO'].tolist()
morefreeconslist = [str(x) for x in morefreeconslist]
combinedfreeconlist = zip(morefreeconsdestarealist,morefreeconslist)
#except:
#combinedfreeconlist = ['No',0.0]

## For handling no free cons in the last days report. Edit on 29-01-2017

closingnotdel = pd.merge(closingarriv12grp,closingarriv12freegrp,left_on=['DEST AREA'],right_on=['DEST AREA'],suffixes=['_MissedDD','_Missed_FreeDD'],how='outer')
 
###For DueDate Cons

### For Closing stock Aging

closingstockfullpivot = closingstockfull.groupby(['DEST AREA']).agg({'DOCKNO': 'count'}).reset_index()
closingstockcons = closingstockfullpivot['DOCKNO'].sum()
efficiencyclstock = pd.merge(merge_effeciency_area,closingstockfullpivot,left_on=['Area'],right_on=['DEST AREA'], how = 'inner')

closingstoctl24 = closingstockfull[closingstockfull['REPORTDATE MIN ARRVDT']>=39]
closingstoctl24cons = len(closingstoctl24)
closingstoctl24aging = np.ceil(closingstoctl24['REPORTDATE MIN ARRVDT'].sum()/closingstoctl24cons)

def getavg(x,y):
    return y/x


closingstoctl24groupby=closingstoctl24.groupby(['DEST AREA']).agg({'DOCKNO': 'count', 'REPORTDATE MIN ARRVDT':'sum'}).reset_index()
closingstoctl24groupby['Avg_Cooling_Hrs']=closingstoctl24groupby.apply (lambda x : getavg(x['DOCKNO'],x['REPORTDATE MIN ARRVDT']),axis=1)
closingstoctl24gb = closingstoctl24groupby.groupby(['DEST AREA']).agg({'DOCKNO':'sum','Avg_Cooling_Hrs':np.mean}).reset_index()

efficiencyclstockfull = pd.merge(efficiencyclstock,closingstoctl24gb,left_on=['Area'],right_on=['DEST AREA'], how = 'inner')
efficiencyclstockfull = efficiencyclstockfull.drop(['DEST AREA_x'], axis=1)
efficiencyclstockfull = efficiencyclstockfull.drop(['DEST AREA_y'], axis=1)
efficiencyclstockfull = efficiencyclstockfull.rename(columns={'DOCKNO_x':'Closing_Stock'})
efficiencyclstockfull = efficiencyclstockfull.rename(columns={'DOCKNO_y':'Closing_Stock>24hrs'})
efficiencyclstockfull = efficiencyclstockfull.rename(columns={'Avg_Cooling_Hrs':'Avg_Cooling_Hrs>24hrs'})

### For Closing stock Aging
def ccfperc(x,y):
    return np.ceil((x*100.0)/(y))


efficiencyclstockfullccf = pd.merge(efficiencyclstockfull,ccfsrdfgroupby,left_on=['Area'],right_on=['DEST AREA'], how = 'outer')
efficiencyclstockfullccf['%CCF_Cons'] = efficiencyclstockfullccf.apply (lambda x : ccfperc(x['DOCKNO'],x['Closing_Stock']),axis=1)
efficiencyclstockfullccf = efficiencyclstockfullccf.rename(columns={'DOCKNO':'CCF_Cons'})

ccfconsno = efficiencyclstockfullccf['CCF_Cons'].sum()
ccfpercentagecons = pd.np.round((ccfconsno*100.0)/closingstockcons,2)

def effcheck(x,y):
    if x<65 and y<65:
        return 'Check'
    else:
        return '-'

def setceil(x):
    return pd.np.round(x,0)

## For NON CCF Cons AREA-WISE
efficiencyclstockfullccf = pd.merge(efficiencyclstockfullccf,nonccfsrdfgroupby,left_on=['Area'],right_on=['DEST AREA'], how = 'outer') 
efficiencyclstockfullccf = pd.merge(efficiencyclstockfullccf,closingnotdel,left_on=['Area'],right_on=['DEST AREA'], how = 'outer') 
efficiencyclstockfullccf['REMARKS'] = efficiencyclstockfullccf.apply(lambda x :effcheck(x['Delivery_Efficiency'],x['%CCF_Cons']),axis =1)
efficiencyclstockfullccf = efficiencyclstockfullccf.rename(columns={'DOCKNO':'NON_CCF_Cons'})
efficiencyclstockfullccf = efficiencyclstockfullccf.rename(columns={'DOCKNO_MissedDD':'Due_Undel'})
efficiencyclstockfullccf = efficiencyclstockfullccf.rename(columns={'DOCKNO_Missed_FreeDD':'Due_Undel_Free'})

columnsopreqcols=['Area','DOCKNO_Delivered','Delivery_Efficiency','%CCF_Cons','NON_CCF_Cons','REMARKS','Due_Undel','Due_Undel_Free']
efficiencyreqcols = pd.DataFrame(efficiencyclstockfullccf,columns=columnsopreqcols)

efficiencyreqcols = efficiencyreqcols.rename(columns={'DOCKNO_Delivered':'DELIVERED'})
efficiencyreqcols = efficiencyreqcols.rename(columns={'Delivery_Efficiency':'DELIVERY_EFFY'})
efficiencyreqcols['DELIVERY_EFFY'] = efficiencyreqcols.apply(lambda x :setceil(x['DELIVERY_EFFY']),axis =1)



sumlist = ['TOTAL',deliveredcons,deliveryefficiency,ccfpercentagecons,nonccfcons,'-',totalduecons,totaldueconsfree]
col_list = ['Area','DELIVERED','DELIVERY_EFFY','%CCF_Cons','NON_CCF_Cons','REMARKS','Due_Undel','Due_Undel_Free']
totalsdf = pd.DataFrame(data=[sumlist], columns = col_list)
efficiencyreqcols = efficiencyreqcols.append(totalsdf,ignore_index=True)

## For NON CCF Cons AREA-WISE
efficiencyclstockfullccf = efficiencyclstockfullccf.drop(['DEST AREA_x','DEST AREA_y','REMARKS'], axis=1)

## For CCF % AREA wise in Closing Stock

### For excluding holiday areas and branches

merge_effeciency =merge_effeciency[~(merge_effeciency['DEST BRCD'].isin(selectdfbrcdlist))]
efficiencyclstockfullccf =efficiencyclstockfullccf[~(efficiencyclstockfullccf['Area'].isin(selectdfarealist))]
efficiencyreqcols=efficiencyreqcols[~(efficiencyreqcols['Area'].isin(selectdfarealist))]
### For excluding holiday areas and branches

oppath2=r'D:\Data\eta_rank\Delivery_Efficiency\Delivery_Efficiency_'+str(opfilevar)+'.xlsx'

# In[ ]:

with ExcelWriter(r'D:\Data\eta_rank\Delivery_Efficiency\Delivery_Efficiency_'+str(opfilevar)+'.xlsx') as writer:
    ###orginal_cancel_basedata.to_excel(writer, sheet_name='Sheet1',engine='xlsxwriter')
    merge_effeciency.to_excel(writer, sheet_name='SC_WISE',engine='xlsxwriter')
    efficiencyclstockfullccf.to_excel(writer, sheet_name='AREA_WISE',engine='xlsxwriter')
    #efficiencyreqcols.to_excel(writer, sheet_name='MailRequiredcolumns',engine='xlsxwriter')
    
merge_effeciency.to_csv(r'D:\Data\eta_rank\STD_DE_SC.csv', encoding='utf-8')
efficiencyclstockfull.to_csv(r'D:\Data\eta_rank\STD_DE.csv', encoding='utf-8')

#### For Average Delay hours of DELIVERED CONS
def datestring2(tsp):
    tsp = str(tsp)
    try:
        return datetime.strptime(tsp.split(' ')[0], '%d-%m-%Y')
    except:
        return datetime.strptime(tsp.split(' ')[0], '%Y-%m-%d')
def datestring(x):
    try:
        fulldate = datetime.strptime(x,'%Y-%m-%d')
        return fulldate
    except:
        fulldate = datetime.strptime(x,'%d-%m-%Y')
        return fulldate


deliveredstock['Delivery_Date']= deliveredstock.apply(lambda x: datestring2(x['DELY DT']), axis=1)
deliveredstock['Due_date'] = deliveredstock.apply(lambda x: datestring2(x['DUE DATE']), axis=1)
deliveredstock['DD_DelyDt'] = deliveredstock.apply(lambda x: (x['Delivery_Date']-x['Due_date']).days,axis=1)

sumofdiffdays = deliveredstock['DD_DelyDt'].sum()
avrghoursofdelcons = pd.np.round((sumofdiffdays*24.0)/deliveredcons,2)

#### For Average Delay hours of DELIVERED CONS
efficiencyreqcols=efficiencyreqcols.fillna(0)
print (efficiencyreqcols)
filePath = oppath2
# def sendEmail(TO = ["aom_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in","rajesh.mishra@spoton.co.in","raghavendra.rao@spoton.co.in","ashwani.gangwar@spoton.co.in","pramod.pandey@spoton.co.in","trilochan.panda@spoton.co.in","sunil.nakte@spoton.co.in","chandrima.banerjee@spoton.co.in", "suresh.d@spoton.co.in", "pankaj.jha@spoton.co.in"],
#             #TO = ["rajeesh.vr@spoton.co.in"],
#             #CC = ["rajeesh.vr@spoton.co.in"],
#             #TO = ["vishwas.j@spoton.co.in"],
#             #CC = ["vishwas.j@spoton.co.in"],
#             #BCC = ["rajeesh.vr@spoton.co.in"],
#             #BCC = ["vishwas.j@spoton.co.in"],
#             CC = ["sqtf@spoton.co.in","SQ_spot@spoton.co.in","supratim@iepfunds.com","Ankit@iepfunds.com","vishwas.j@spoton.co.in"],
#             BCC = ["sachidanand.pandey@spoton.co.in","renugopal.l@spoton.co.in","sathya.chander@spoton.co.in","alagu.mahendran@spoton.co.in","awadhesh.kumar.mishra@spoton.co.in","sanjay.parab@spoton.co.in","ramesh.s@spoton.co.in","md.zaya@spoton.co.in"],
#     FROM="mahesh.reddy@spoton.co.in"):
#     HOST = "smtp.spoton.co.in"
# #smtplib.SMTP('smtp.spoton.co.in', 25)

#     msg = MIMEMultipart()
#     msg["From"] = FROM
#     msg["To"] = ",".join(TO)
#     msg["CC"] = ",".join(CC)
#     msg["BCC"] = ",".join(BCC)
#     #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
#     msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
#     body_text = """
#     Dear All,
    
#     Delivered = """+str(deliveredcons)+"""
#     Opening Stock = """+str(openingcons)+"""
#     Incoming Stock = """+str(incomingcons)+"""
#     Closing Stock = """+str(closingstockcons)+"""
#     Closing Stock > 24hrs = """+str(closingstoctl24cons)+"""
#     Average Ageing of Closing Stock >24hrs = """+str(closingstoctl24aging)+""" hrs
#     Cons of Duedate """+str(opfilevar)+""" not delivered = """+str(totalduecons)+"""
#     Due Date cons of """+str(opfilevar)+""" not delivered and free for today  = """+str(totaldueconsfree)+"""
#     Areas with high duedate free cons not delivered = """+str(combinedfreeconlist)+"""
#     CCF Cons % of Closing Stock = """+str(ccfpercentagecons)+""" %
#     Average Delay Hours of Delivered Cons = """+str(avrghoursofdelcons)+""" Hrs
    
#     The Overall Delivery efficiency of STD cons is """+str(deliveryefficiency)+"""%
    
#     PFB the Delivery Efficiency Area wise as of """ + str(opfilevar) +"""
    
#     """+str(efficiencyreqcols)+"""
    
#     The AREA-WISE and SC-WISE summary has been attached in the mail.
    
#     For the base data, please refer the link http://10.109.230.50/downloads/OCID/OCID.xls
    

#     """

#     if body_text:
#         msg.attach( MIMEText(body_text) )
#     part = MIMEBase('application', "octet-stream")
#     part.set_payload( open(filePath,"rb").read() )
#     Encoders.encode_base64(part)
#     part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
#     msg.attach(part)
#     server=smtplib.SMTP('smtp.sendgrid.net', 587)
#     server.ehlo()
#     server.starttls()
#     server.ehlo()
#     server.login("spoton.net.in", "Star@123#")

#     try:
#         failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
#         server.close()
#     except Exception, e:
#         errorMsg = "Unable to send email. Error: %s" % str(e)

# if __name__ == "__main__":
#     sendEmail()
# print('Email sent')
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template
#vishwas.j@spoton.co.in
TO=['mahesh.reddy@spoton.co.in','mahesh.reddy@spoton.co.in']
#TO = ["aom_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in","rajesh.mishra@spoton.co.in","raghavendra.rao@spoton.co.in","ashwani.gangwar@spoton.co.in","pramod.pandey@spoton.co.in","trilochan.panda@spoton.co.in","sunil.nakte@spoton.co.in","chandrima.banerjee@spoton.co.in", "suresh.d@spoton.co.in", "pankaj.jha@spoton.co.in"]
FROM='vishwas.j@spoton.co.in'
CC=['mahesh.reddy@spoton.co.in','mahesh.reddy@spoton.co.in']
#CC = ["sqtf@spoton.co.in","SQ_spot@spoton.co.in","supratim@iepfunds.com","Ankit@iepfunds.com","vishwas.j@spoton.co.in"]
BCC=['maheshmahesh11464@gmail.com']
#BCC = ["sachidanand.pandey@spoton.co.in","renugopal.l@spoton.co.in","sathya.chander@spoton.co.in","alagu.mahendran@spoton.co.in","awadhesh.kumar.mishra@spoton.co.in","sanjay.parab@spoton.co.in","ramesh.s@spoton.co.in","md.zaya@spoton.co.in"]
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
html='''<html>
<style>
p
{
  margin:0;
  margin-top: 5px;
  padding:0;
  font-size:15px;
    line-height:20px;
}
</style>
<h4>Dear All,</h4>
<p>Delivered = $deliveredcons</p>
<p>Opening Stock = $openingcons</p>
<p>Incoming Stock = $incomingcons</p>
<p>Closing Stock = $closingstockcons</p>
<p>Closing Stock > 24hrs =$closingstoctl24cons</p>
<p>Average Ageing of Closing Stock >24hrs = $closingstoctl24aging hrs</p>
<p>Cons of Duedate $opfilevar not delivered = $totalduecons</p>
<p>Due Date cons of $opfilevar not delivered and free for today = $totaldueconsfree</p> 
<p>Areas with high duedate free cons not delivered = $combinedfreeconlist</p>
<p>CCF Cons % of Closing Stock = $ccfpercentagecons %</p>
<p>Average Delay Hours of Delivered Cons = $avrghoursofdelcons Hrs</p>
<p>The Overall Delivery efficiency of STD cons is $deliveryefficiency %</p>
<p>PFB the Delivery Efficiency Area wise as of $opfilevar</p>
</html>'''

html3='''
<h5>The AREA-WISE and SC-WISE summary has been attached in the mail.</h5>
<h5> For the base data, please refer the link </h5>
<p><a href= "http://10.109.230.50/downloads/OCID/OCID.xls"</a>http://10.109.230.50/downloads/OCID/OCID.xls</p></b>
'''
s = Template(html).safe_substitute(deliveryefficiency=deliveryefficiency,avrghoursofdelcons=avrghoursofdelcons,ccfpercentagecons=ccfpercentagecons,combinedfreeconlist=combinedfreeconlist,totaldueconsfree=totaldueconsfree,totalduecons=totalduecons,opfilevar=opfilevar,closingstoctl24aging=closingstoctl24aging,closingstoctl24cons=closingstoctl24cons,closingstockcons=closingstockcons,incomingcons=incomingcons,openingcons=openingcons,deliveredcons=deliveredcons)
report=""
report+=s
report+='<br>'
report+='<br>'+efficiencyreqcols.to_html()+'<br>'
report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filePath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()
#Sending output file via mail ends



with ExcelWriter(r'D:\Data\DE_Conwise_Stock\DE_STD\Delivery_Efficiency_STD_'+str(opfilevar)+'.xlsx') as writer:
    openingstock.to_excel(writer, sheet_name='OPENING_STOCK',engine='xlsxwriter')
    incoming12stock.to_excel(writer, sheet_name='INCOMING_STOCK',engine='xlsxwriter')
    deliveredstock.to_excel(writer, sheet_name='DELIVERED',engine='xlsxwriter')
    closingstockfull.to_excel(writer, sheet_name='CLOSING_STOCK',engine='xlsxwriter')