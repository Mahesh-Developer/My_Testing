
# coding: utf-8

# In[ ]:

import pandas as pd
import Utilities
from datetime import date,timedelta ,datetime
d=date.today()
today_date=datetime.strftime(d,'%d-%b-%y')
date1=date.today()-timedelta(1)
yest_date=datetime.strftime(date1,'%d-%b-%y')
pickup_date1=datetime.strftime(date1,'%Y-%m-%d')
pickup_date2=pickup_date1+' 23:59'
print (today_date,yest_date,pickup_date1,pickup_date2)


#Pickup count numbers
query=("""SELECT COUNT(*) Pick_Cons FROM dbo.DOCKET WHERE DOCKDT BETWEEN '{0}' AND '{1}' AND PAYBAS <> 6""").format(pickup_date1,pickup_date2)
query
print (Utilities.cnxn)

df=pd.read_sql(query,Utilities.cnxn)
print (df)