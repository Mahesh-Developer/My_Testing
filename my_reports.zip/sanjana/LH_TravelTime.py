
# coding: utf-8

# In[ ]:

import pandas as pd
from datetime import datetime , timedelta, time

import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import os
# In[ ]:

lhdata = pd.read_excel('http://spoton.co.in/downloads/PMDLH/PMDLH_30DAYS.xls')


# In[ ]:

lhdata.columns


# In[ ]:

datefilter=(datetime.today()-timedelta(hours=24)).date()
datefilter1 = datetime.combine(datefilter, time(9,0))


# In[ ]:

datefilter1


# In[ ]:

#lhdata['THC Finish Date'] = lhdata.apply(lambda x: datetime.strptime(x['THC Finish Date'], '%Y-%m-%d %H:%M:%S'), axis=1)


# In[ ]:

#print len(lhdata)
lhdatay = lhdata[lhdata['THC Finish Date']>datefilter1]
#print len(lhdatay)


# In[ ]:

print len(lhdatay), len(lhdata)


# In[ ]:

lhdatay['Act_TT'] = lhdatay.apply(lambda x: pd.np.round((x['THC Finish Date']-x['THC DATE']).total_seconds()*1.0/3600, 0), axis=1)


# In[ ]:

lhdatay = lhdatay[['ROUTE CODE','THC NUMBER','Act_TT']]


# In[ ]:

tracker = pd.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\TransitTime_Tracker.csv')


# In[ ]:

monitor = pd.merge(tracker, lhdatay, on=['ROUTE CODE'], how='left')


# In[ ]:

monitor['Diff'] = monitor.apply(lambda x: x['Act_TT']-x['Revised TT'], axis=1)
monitor['Diff%'] = monitor.apply(lambda x: round(x['Diff']*100.0/x['Revised TT'],0), axis=1)


# In[ ]:

monitor = monitor.sort_values('Diff%', ascending=False)


# In[ ]:

monitor.to_csv(r'D:\Data\LH_travel_time\Transit_time_tracking_'+str(datefilter)+'.csv')
oppath_tt = r'D:\Data\LH_travel_time\Transit_time_tracking_'+str(datefilter)+'.csv'

# In[ ]:
filePath = oppath_tt
def sendEmail(#TO = ["rajeesh.vr@spoton.co.in","Ankit@iepfunds.com","prasanna.hegde@spoton.co.in"],
            TO = ["raghavendra.rao@spoton.co.in","cnm@spoton.co.in","prasanna.hegde@spoton.co.in"],
            #TO = ["vishwas.j@spoton.co.in"],
            #CC = ["rajeesh.vr@spoton.co.in"],
            CC = ["sqtf@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "SERVER ETA FTP" + " - " + str(reportts)
    msg["Subject"] = "LH Transit Time Tracking " + "- "+ str(datefilter)
    body_text = """
    Dear All,

    PFA the Transit time tracking Report for """ + str(datefilter)+"""

    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    #server=smtplib.SMTP('124.7.138.249', 587)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()


