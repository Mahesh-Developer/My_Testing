
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta,datetime
import sys
import Utilities
reload(sys).setdefaultencoding("ISO-8859-1")

# In[2]:


# cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")


# # In[3]:


# cursor=cnxn.cursor()

#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
#cursor = cnxn.cursor()


# In[4]:


query=("""EXEC dbo.USP_BLRCSTOCK_SQ 'S'""")


# In[5]:


query


# In[6]:


stock_df=pd.read_sql(query,Utilities.cnxn)


# In[7]:


stock_df


# In[8]:


query1=("""EXEC dbo.USP_BLRCSTOCK_SQ 'D'""")
query1


# In[9]:


delivery_df=pd.read_sql(query1,Utilities.cnxn)


# In[10]:


delivery_df


# In[11]:


query2=("""EXEC dbo.USP_BLRCSTOCK_SQ 'I'""")
query2


# In[12]:


incoming_df=pd.read_sql(query2,Utilities.cnxn)


# In[13]:


incoming_df


# In[14]:
if len(incoming_df)==0:
    Cons_Total=0
    weight_Total=0
else:
    Cons_Total = incoming_df['In_CONS'].sum()
    weight_Total = incoming_df['Wt in Tons'].sum()

# Cons_Total = incoming_df['In_CONS'].sum()
# weight_Total = incoming_df['Wt in Tons'].sum()
#print (Cons_Total,pd.np.round(weight_Total,1))


# In[15]:


f1=['Total','','',Cons_Total,weight_Total]
f2=['Coming_From','THC_NO','Arrival_Date','In_CONS','Wt in Tons']
total_df=pd.DataFrame(data=[f1],columns=f2)


# In[16]:


total_df


# In[17]:


incoming_df=pd.concat([incoming_df,total_df],ignore_index=True)


# In[18]:


incoming_df


# In[19]:


y_date=date.today()-timedelta(1)
yest_date=datetime.strftime(y_date,'%Y-%m-%d')
yest_date


# In[21]:


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

from_addr = 'mis.ho@spoton.co.in'
to_addr = ['abhik.mitra@spoton.co.in','krishna.chandrasekar@spoton.co.in','rajesh.kumar@spoton.co.in','sasikumar.kannan@spoton.co.in','dominic.sathish@spoton.co.in']
#to_addr = ['maheshmahesh11464@gmail.com','mahesh.reddy@spoton.co.in']
#cc_addr=['sqtf@spoton.co.in','ashwani.gangwar@spoton.co.in','SQ_SPOT@spoton.co.in','pramod.pandey@spoton.co.in','md.zaya@spoton.co.in']
#bcc_addr = ['maheshmahesh11464@gmail.com','mahesh.reddy@spoton.co.in']
bcc_addr=['shivananda.p@spoton.co.in','mahesh.reddy@spoton.co.in','anitha.thyagarajan@spoton.co.in']


msg = MIMEMultipart()

msg['From'] = from_addr
# msg['To'] = ', '.join(to_addr)
msg['bcc'] = ', '.join(to_addr)
msg['bcc'] = ', '.join(bcc_addr)
msg['Subject'] = 'Blrc Stock Details -'+str(yest_date)
html='''<html>
<h4>Dear All,</h4>
<p>Pls find attached BLRC Stock details as of $date.</p>
</html>'''

html1='''<h5>Thanks & Regards</h5></b>
<h5>HO-SQ</h5>'''
    
#  msg.attach(part10)
s = Template(html).safe_substitute(date=yest_date)
report=""
report+=s
report+='<br>'
report+='Stock Available as of '+str(yest_date)
report+='<br>'+stock_df.to_html()+'<br>'
report+='<br>'
report+='Delivered on '+str(yest_date)
report+='<br>'+delivery_df.to_html()+'<br>'
report+='<br>'
report+='Incoming details of '+str(yest_date)
report+='<br>'+incoming_df.to_html()+'<br>'
report+='<br>'
# report+=html4
# report+='<br>'
report+=html1
abc=MIMEText(report,'html')
msg.attach(abc)
server = smtplib.SMTP('smtp.sendgrid.net',587)
part=MIMEBase('application','octet-stream')
# part1=MIMEBase('application','octet-stream')
# part.set_payload(open(filepath,'rb').read())
# # part1.set_payload(open(filepath1,'rb').read())
# encoders.encode_base64(part)
# # Encoders.encode_base64(part1)
# part.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath))
# # part1.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath1))
# msg.attach(part)
# msg.attach(part1)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
server.sendmail(from_addr,to_addr+bcc_addr,msg.as_string())
print ('mail sent succesfully')
server.quit()

