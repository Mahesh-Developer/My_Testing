
# coding: utf-8

# In[1]:

import pandas as pd
from sqlalchemy import *
from selenium import webdriver
import time
import pandas as pd
from selenium.webdriver.support.ui import Select
from datetime import datetime
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
#import datetime
import os


# In[2]:

# engine = create_engine("mysql+pymysql://spotonhr:spoton54321@104.199.198.197/LH30days")
# df = pd.read_sql("SELECT * FROM LH30days WHERE `THC DATE` >='2017-10-01'",engine).loc[:,['THC DATE','VEHICLE NUMBER','VENDOR NAME','ORIGIN','DESTINATION','THC Finish Date']]


# In[3]:

df1=pd.read_excel(r'http://spoton.co.in/downloads/RunningVehicleGPSDetails/THCVehicleGPSDetails.xls',sheetname=0)


# In[4]:

df1['FLAG']='CNM TEAM'


# In[5]:

df2=pd.read_excel('http://spoton.co.in/downloads/TCR_UND_2HRS/TCR_UND_ISDEPART_YES_2HRS_NEXT_TO_NEXT.xls').loc[:,['Vendor Name','Vendor Code','Vehicle No.','THC ROUTE NAME','THC DEST','THC SOURC','DEPARTED FRM CURRLOC THCNO','DEPARTURE TO LOC FRM CURLOC','CURR BRANCHCODE','DEPARTED FRM CURRLOC ROUTECD','DEPARTURE TIME FRM CURLOC','THC Cost','TIME STAMP']]


# In[6]:

df2=df2.rename_axis({'THC ROUTE NAME':'Route Name','THC DEST':'Destination Hub','THC SOURC':'Source Hub','DEPARTED FRM CURRLOC THCNO':'THC No','DEPARTURE TO LOC FRM CURLOC':'To Hub','CURR BRANCHCODE':'From Hub','DEPARTED FRM CURRLOC ROUTECD':'Route Code','DEPARTURE TIME FRM CURLOC':'THC Date','TIME STAMP':'Timestamp'},axis=1)


# In[7]:

df2['FLAG']='TRANSIT REPORT'


# In[8]:

df2=df2[df2['Vehicle No.']!='DATA-VEH']


# In[9]:

df2=df2.drop_duplicates('Vehicle No.')


# In[10]:

frames =[df1,df2]
df=pd.concat(frames)


# In[11]:

df=df.drop_duplicates('Vehicle No.')


# In[12]:

df=df.reset_index()


# In[13]:

df['Vehicle Status']=df['Vehicle Status'].fillna('Na')


# In[14]:

abc=['Na','GPS Not Working']
dff=df[(df['Vehicle Status'].isin(abc))]


# In[15]:

dffa=df[(~df['Vehicle Status'].isin(abc))]


# In[16]:

del dff['GPS Captured Time']
del dff['Vehicle Status']
del dff['Speed']
del dff['index']


# In[ ]:

superindialist = ['AAVCS5376B','8735']
vendors=['AAVCS5376B','8735','8185','8235','8158','8230','8252','8005']


# In[ ]:

transdf=dff[dff['Vendor Code']=='8185'].reset_index()
mahenderdf=dff[dff['Vendor Code']=='8158'].reset_index()
mehtadf=dff[dff['Vendor Code']=='8230'].reset_index()
superdf=dff[dff['Vendor Code'].isin(superindialist)].reset_index()
radientdf=dff[dff['Vendor Code']=='8252'].reset_index()
dtscargodf=dff[dff['Vendor Code']=='8005']
santdf=dff[dff['Vendor Code']=='8235'].reset_index()
othervendorsdf=dff[~dff['Vendor Code'].isin(vendors)]


# In[ ]:

driver = webdriver.Chrome(r'D:/Chromedriver')


# In[ ]:
#driver.maximize_window()
vehicleno,vehicle,lastupdate,location,speed=[],[],[],[],[]

# ### Mehta Vehicle

# In[ ]:
try:
    driver.get('http://login.trackerbox.co.in/index.php/sessions/login')


    # In[ ]:

    username = driver.find_element_by_id("username_id")
    password = driver.find_element_by_id("password")


    # In[ ]:

    username.send_keys("mehta")
    password.send_keys("mehta")


    # In[ ]:

    button=driver.find_element_by_name("btn_submit")


    # In[ ]:

    time.sleep(5)


    # In[ ]:

    button.click()


    # In[ ]:

    time.sleep(10)


    # In[ ]:

    checkbox=driver.find_element_by_id('checkboxToggle')


    # In[ ]:

    checkbox.click()


    # In[ ]:

    time.sleep(15)


    # In[ ]:

    table=driver.find_element_by_xpath('//*[@id="lastpoint_grid"]/tbody')


    # In[ ]:

    


    # In[ ]:

    for row in table.find_elements_by_xpath('.//tr'):
        cell=row.find_elements_by_tag_name('td')[5]
        vehicle.append(cell.text)
        cell=row.find_elements_by_tag_name('td')[17]
        lastupdate.append(cell.text)
        cell=row.find_elements_by_tag_name('td')[18]
        location.append(cell.text)
        cell=row.find_elements_by_tag_name('td')[23]
        speed.append(cell.text)


    # In[ ]:

    dfmehta=pd.DataFrame(vehicle[1:-1],columns=['Vehicle No.'])
    dfmehta['GPS Captured Time'],dfmehta['Vehicle Status'],dfmehta['Speed']=lastupdate[1:-1],location[1:-1],speed[1:-1]


    # In[ ]:

    for i in vehicle[1:-1]:
        j=i.split(" ")
        if len(j[0])>len(j[1]):
            vehicleno.append(j[0])
        else:
            vehicleno.append(j[1][1:-1])


    # In[ ]:

    del dfmehta['Vehicle No.']
    dfmehta['Vehicle No.'] = vehicleno


    # In[ ]:

    mehtadff=pd.merge(mehtadf,dfmehta,on=['Vehicle No.'],how='left')


    # In[ ]:

    del lastupdate[:]
    del location[:]
    del speed[:]
    del vehicleno[:]
    mehta=len(mehtadff)
except:
    mehta='mehta not working'
    mehtadff=mehtadf


# #### Super India vehicle status
# def superindia(vehicleno):
#     try:
#         VehicleNo=driver.find_element_by_id("name")
#         VehicleNo.send_keys(vehicleno)
#         button=driver.find_element_by_name('submit')
#         button.click()
#         table=driver.find_element_by_xpath('//*[@id="section"]/div/div/div/div/div[2]/div/table/tbody')
#         cell=table.find_element_by_xpath('//*[@id="section"]/div/div/div/div/div[2]/div/table/tbody/tr[2]/td[3]')
#         location=cell.tex
#         cell=table.find_element_by_xpath('//*[@id="section"]/div/div/div/div/div[2]/div/table/tbody/tr[2]/td[4]')
#         speed=cell.text
#         cell=table.find_element_by_xpath('//*[@id="section"]/div/div/div/div/div[2]/div/table/tbody/tr[2]/td[5]')
#         lastupdate=cell.text
#     except:
#         lastupdate='-'
#         location='-'
#         speed='-'
#     return lastupdate,location,speed    
# In[ ]:
try:
    driver.get('http://www.superindia.co.in/vechilelocation.php?vehname=HR55W1346&token=4539437783&submit=Vehicle+Tracking')
    for i in range(0,len(superdf)):
        try:
            VehicleNo=driver.find_element_by_id("name")
            VehicleNo.send_keys(superdf['Vehicle No.'][i])
            button=driver.find_element_by_name('submit')
            button.click()
            table=driver.find_element_by_xpath('//*[@id="section"]/div/div/div/div/div[2]/div/table/tbody')
            cell=table.find_element_by_xpath('//*[@id="section"]/div/div/div/div/div[2]/div/table/tbody/tr[2]/td[3]')
            location.append(cell.text)
            cell=table.find_element_by_xpath('//*[@id="section"]/div/div/div/div/div[2]/div/table/tbody/tr[2]/td[4]')
            speed.append(cell.text)
            cell=table.find_element_by_xpath('//*[@id="section"]/div/div/div/div/div[2]/div/table/tbody/tr[2]/td[5]')
            lastupdate.append(cell.text)
        except:
            lastupdate.append('-')
            location.append('-')
            speed.append('-')    
    superdf['GPS Captured Time'],superdf['Vehicle Status'],superdf['Speed']=lastupdate,location,speed
    superind=len(superdf)
except:
    superind='superindia is not working'

# In[ ]:

del lastupdate[:]
del location[:]
del speed[:]
del vehicleno[:]


# ### Transcargo India Vehicles

# In[ ]:
try:
    driver.get('http://www.transcargoindia.in')


    # In[ ]:

    select=Select(driver.find_element_by_class_name('searching'))
    select.select_by_visible_text('Lorry No')


    # In[ ]:

    VehicleNo=driver.find_elements_by_class_name('searching')[1]


    # In[ ]:

    VehicleNo.send_keys(transdf['Vehicle No.'][0])


    # In[ ]:

    button=driver.find_elements_by_class_name('submit')[0]


    # In[ ]:

    button.click()


    # In[ ]:

    time.sleep(10)


    # In[ ]:

    try:
        cell1=driver.find_element_by_xpath('//*[@id="my_postwidget-3"]/div/div/div[2]/ul/li[2]')
        cell2=driver.find_element_by_xpath('//*[@id="my_postwidget-3"]/div/div/div[2]/ul/li[3]/span')
        lastupdate.append(cell1.text+' '+cell2.text)
        cell3=driver.find_element_by_xpath('//*[@id="my_postwidget-3"]/div/div/div[2]/ul/li[4]/span')
        location.append(cell3.text)
        cell4=driver.find_element_by_xpath('//*[@id="my_postwidget-3"]/div/div/div[2]/ul/li[5]/span')
        speed.append(cell4.text)
    except:
        lastupdate.append('-')
        location.append('-')
        speed.append('-')


    # In[ ]:

    for i in range(1,len(transdf)):
        try:
            VehicleNo=driver.find_elements_by_xpath('//*[@id="numberr"]')[1]
            VehicleNo.clear()
            VehicleNo.send_keys(transdf['Vehicle No.'][i])
            button=driver.find_element_by_class_name('submit')
            button.click()
            time.sleep(15)
            cell1=driver.find_element_by_xpath('//*[@id="my_postwidget-3"]/div/div/div[2]/ul/li[2]')
            cell2=driver.find_element_by_xpath('//*[@id="my_postwidget-3"]/div/div/div[2]/ul/li[3]/span')
            lastupdate.append(cell1.text+' '+cell2.text)
            cell3=driver.find_element_by_xpath('//*[@id="my_postwidget-3"]/div/div/div[2]/ul/li[4]/span')
            location.append(cell3.text)
            cell4=driver.find_element_by_xpath('//*[@id="my_postwidget-3"]/div/div/div[2]/ul/li[5]/span')
            speed.append(cell4.text)
        except:
            lastupdate.append('-')
            location.append('-')
            speed.append('-')


    # In[ ]:

    transdf['GPS Captured Time'],transdf['Vehicle Status'],transdf['Speed']=lastupdate,location,speed
    trans=len(transdf)
except:
    trans='Trans is not working'

# ### Mahender Vehicle
del lastupdate[:]
del location[:]
del speed[:]
del vehicleno[:]
# In[ ]:
try:
    driver.get('http://nandiniexim.stepinone.com/')


    # In[ ]:

    time.sleep(5)


    # In[ ]:

    username=driver.find_element_by_xpath('//*[@id="user_login"]')


    # In[ ]:

    username.send_keys('MAHENDER')


    # In[ ]:

    password=driver.find_element_by_xpath('//*[@id="user_password"]')


    # In[ ]:

    password.send_keys('123456')


    # In[ ]:

    button=driver.find_element_by_xpath('/html/body/div[2]/form/div[4]/button')


    # In[ ]:

    button.click()


    # In[ ]:

    time.sleep(10)


    # In[ ]:

    table=driver.find_element_by_xpath('//*[@id="gridContent"]/table/tbody')


    # In[ ]:

    


    # In[ ]:

    for row in table.find_elements_by_xpath('.//tr'):
        cell=row.find_elements_by_tag_name('td')[1]
        vehicleno.append(''.join(cell.text.split()))
        cell=row.find_elements_by_tag_name('td')[4]
        lastupdate.append(' '.join(cell.text.split()))
        cell=row.find_elements_by_tag_name('td')[7]
        location.append(''.join(cell.text.split()))
        cell=row.find_elements_by_tag_name('td')[6]
        speed.append(''.join(cell.text.split()))


    # In[ ]:
    try:
        button=driver.find_element_by_xpath('//*[@id="gridContent"]/div[2]/div[2]/a[2]')


        # In[ ]:

        button.click()


        # In[ ]:

        time.sleep(5)


        # In[ ]:

        table=driver.find_element_by_xpath('//*[@id="gridContent"]/table/tbody')


        # In[ ]:

        for row in table.find_elements_by_xpath('.//tr'):
            cell=row.find_elements_by_tag_name('td')[1]
            vehicleno.append(''.join(cell.text.split()))
            cell=row.find_elements_by_tag_name('td')[4]
            lastupdate.append(' '.join(cell.text.split()))
            cell=row.find_elements_by_tag_name('td')[7]
            location.append(''.join(cell.text.split()))
            cell=row.find_elements_by_tag_name('td')[6]
            speed.append(''.join(cell.text.split()))
    except:
        pass

    # In[ ]:

    dfmahender=pd.DataFrame(vehicleno,columns=['Vehicle No.'])
    dfmahender['GPS Captured Time'],dfmahender['Vehicle Status'],dfmahender['Speed']=lastupdate,location,speed


    # In[ ]:

    mahenderdff=pd.merge(mahenderdf,dfmahender,on=['Vehicle No.'],how='left')


    # In[ ]:

    mahenderdff['Vehicle Status']=mahenderdff['Vehicle Status'].fillna('Na')


    # In[ ]:

    mahender2df=mahenderdff[mahenderdff['Vehicle Status']=='Na']
    mahenderdff=mahenderdff[mahenderdff['Vehicle Status']!='Na']
    mahender=len(mahenderdff)
except:
    mahender='mahender is not working'
    mahender2df=mahenderdf
    mahenderdff=pd.DataFrame(vehicleno,columns=['Vehicle No.'])
    mahenderdff['GPS Captured Time'],mahenderdff['Vehicle Status'],mahenderdff['Speed']=lastupdate,location,speed

# ### Radient Logistics

# In[ ]:
try:
    driver.get('http://www.trakntell.com/login.html')


    # In[ ]:

    username=driver.find_element_by_xpath('/html/body/div[4]/div/form/label[1]/input')


    # In[ ]:

    password=driver.find_element_by_xpath('/html/body/div[4]/div/form/label[2]/input')


    # In[ ]:

    username.send_keys('9971815566')


    # In[ ]:


    password.send_keys('17101964')


    # In[ ]:

    button=driver.find_element_by_xpath('/html/body/div[4]/div/form/input[4]')


    # In[ ]:

    button.click()


    # In[ ]:

    iframe=driver.find_element_by_tag_name('iframe')


    # In[ ]:

    driver.switch_to_frame(iframe)


    # In[ ]:

    del lastupdate[:]
    del location[:]
    del speed[:]
    del vehicleno[:]


    # In[ ]:

    table=driver.find_element_by_tag_name('table')


    # In[ ]:

    for i in range(19,len(table.find_elements_by_xpath('.//tr'))-5,3):
        row=table.find_elements_by_xpath('.//tr')[i]
        cell=row.find_elements_by_tag_name('td')[0]
        vehicleno.append(cell.text.replace(" ", ""))
        cell=row.find_elements_by_tag_name('td')[3]
        lastupdate.append(cell.text)
        cell=row.find_elements_by_tag_name('td')[2]
        location.append(cell.text)
        cell=row.find_elements_by_tag_name('td')[1]
        speed.append(cell.text)


    # In[ ]:

    dfradient=pd.DataFrame(vehicleno,columns=['Vehicle No.'])
    dfradient['GPS Captured Time'],dfradient['Vehicle Status'],dfradient['Speed']=lastupdate,location,speed


    # In[ ]:

    radientdff=pd.merge(radientdf,dfradient,on=['Vehicle No.'],how='left')
    radient=len(radientdff)
except:
    radient='Radient is not working'
    radientdff=radientdf

# ### DTS CARGOS

# In[ ]:
try:
    driver.get('http://mmgeotracker.com/login.aspx')
    time.sleep(5)


    # In[ ]:

    username=driver.find_element_by_xpath('//*[@id="ctl00_ContentPlaceHolder1_txtuserID"]')
    password=driver.find_element_by_xpath('//*[@id="ctl00_ContentPlaceHolder1_txtpassword"]')


    # In[ ]:

    username.send_keys('dtscargo')
    password.send_keys('dts12345')


    # In[ ]:

    button=driver.find_element_by_xpath('//*[@id="ctl00_ContentPlaceHolder1_btnLogin"]')


    # In[ ]:

    button.click()


    # In[ ]:

    time.sleep(5)


    # In[ ]:

    checkbox=driver.find_element_by_xpath('//*[@id="ctl00_ContentPlaceHolder1_trvVehiclen0CheckBox"]')


    # In[ ]:

    checkbox.click()


    # In[ ]:

    time.sleep(5)


    # In[ ]:

    del lastupdate[:]
    del location[:]
    del speed[:]
    del vehicleno[:]


    # In[ ]:

    table=driver.find_element_by_xpath('//*[@id="ctl00_ContentPlaceHolder1_grddata"]/tbody')


    # In[ ]:

    for row in table.find_elements_by_xpath('.//tr'):
        cell=row.find_elements_by_tag_name('td')[2]
        vehicleno.append(cell.text)
        cell=row.find_elements_by_tag_name('td')[1]
        lastupdate.append(cell.text)
        cell=row.find_elements_by_tag_name('td')[5]
        location.append(cell.text)
        cell=row.find_elements_by_tag_name('td')[4]
        speed.append(cell.text)


    # In[ ]:

    dfdtscargo=pd.DataFrame(vehicleno,columns=['Vehicle No.'])
    dfdtscargo['GPS Captured Time'],dfdtscargo['Vehicle Status'],dfdtscargo['Speed']=lastupdate,location,speed


    # In[ ]:

    dtscargodff=pd.merge(dtscargodf,dfdtscargo,on=['Vehicle No.'],how='left')
    dts=len(dtscargodff)
except:
    dts='dts cargo not working'
    dtscargodff=dtscargodf

# ### Mahender 2nd site

# In[ ]:
try:
    del mahender2df['GPS Captured Time']
    del mahender2df['Vehicle Status']
    del mahender2df['Speed']
    del mahender2df['index']
except:
    pass
del lastupdate[:]
del location[:]
del speed[:]
del vehicleno[:]
try:
    driver.get('http://flitrack.com/jsp/login.jsp')


    # In[ ]:

    username=driver.find_element_by_xpath('//*[@id="username"]')
    password=driver.find_element_by_xpath('//*[@id="form"]/table/tbody/tr[2]/td/input')


    # In[ ]:

    username.send_keys('MCD')
    password.send_keys('654321')


    # In[ ]:

    button=driver.find_element_by_id('button1')


    # In[ ]:

    button.click()


    # In[ ]:

    button=driver.find_element_by_name('divframe')


    # In[ ]:

    driver.switch_to_frame(button)


    # In[ ]:

    button1=driver.find_element_by_id('trigger-overlay')


    # In[ ]:

    button1.click()


    # In[ ]:

    img=driver.find_element_by_xpath('//*[@id="tree-ul"]/li[2]/a')


    # In[ ]:

    img.click()


    # In[ ]:

    iframe=driver.find_element_by_id('windowframe')


    # In[ ]:

    driver.switch_to_frame(iframe)


    # In[ ]:

    frame=driver.find_element_by_id('main_container')


    # In[ ]:

    bottomframe=frame.find_element_by_id('bottomframe')


    # In[ ]:

    driver.switch_to_frame(bottomframe)


    # In[ ]:

    select=Select(driver.find_element_by_id('recordsperpages'))
    select.select_by_visible_text('1000')


    # In[ ]:

    driver.switch_to.parent_frame()


    # In[ ]:

    frame1=frame.find_element_by_id('contentframe')


    # In[ ]:

    driver.switch_to_frame(frame1)


    # In[ ]:

    table=driver.find_element_by_xpath('//*[@id="dataTable"]/tbody')


    # In[ ]:
    str1='CD'
    for row in table.find_elements_by_xpath('.//tr'):
        cell=row.find_elements_by_tag_name('td')[2]
        vehicle=cell.text.split('-')[0][0:-1]
        if vehicle.find(str1)!=-1:
            vehicleno.append(vehicle[0:-3])
        else:
            vehicleno.append(vehicle)   
        cell=row.find_elements_by_tag_name('td')[10]
        lastupdate.append(cell.text)
        cell=row.find_elements_by_tag_name('td')[8]
        location.append(cell.text)
        cell=row.find_elements_by_tag_name('td')[7]
        speed.append(cell.text)


    # In[ ]:

    dfmh2=pd.DataFrame(vehicleno,columns=['Vehicle No.'])
    dfmh2['GPS Captured Time'],dfmh2['Vehicle Status'],dfmh2['Speed']=lastupdate,location,speed

    mh2dff=pd.merge(mahender2df,dfmh2,on=['Vehicle No.'],how='left')
    mh2=len(mh2dff)
except:
    mh2='mahender 2nd site not working'
    mh2dff=mahender2df    
# In[ ]:

try:
    driver.get('http://www.trackyourfleet.biz')
    username=driver.find_element_by_xpath('//*[@id="txtUN"]')
    password=driver.find_element_by_xpath('//*[@id="txtPwd"]')
    username.send_keys('sant123')
    password.send_keys('sant123')

    button=driver.find_element_by_xpath('//*[@id="btnLogin"]')
    button.click()

    lastupdate[:]
    location[:]
    speed[:]
    vehicleno[:]
    table=driver.find_element_by_xpath('//*[@id="tblData"]/tbody')
    for row in table.find_elements_by_xpath('.//tr'):
        cell=row.find_elements_by_tag_name('td')[2]
        vehicleno.append(cell.text)
        cell=row.find_elements_by_tag_name('td')[3]
        lastupdate.append(cell.text)
        cell=row.find_elements_by_tag_name('td')[8]
        location.append(cell.text)
        cell=row.find_elements_by_tag_name('td')[9]
        speed.append(cell.text)
    dfsant=pd.DataFrame(vehicleno,columns=['Vehicle No.'])
    dfsant['GPS Captured Time'],dfsant['Vehicle Status'],dfsant['Speed']=lastupdate,location,speed    
    santdff=pd.merge(santdf,dfsant,on=['Vehicle No.'],how='left')
    sant=len(santdff)
except:
    sant='Sant is not working'
    santdff=santdf    
# In[ ]:
frames=[transdf,superdf,mahenderdff,radientdff,dtscargodff,mh2dff,mehtadff,santdff]
resultdf=pd.concat(frames)


# In[ ]:

total=[resultdf,dffa,othervendorsdf]
totaldf=pd.concat(total)


# In[ ]:

totaldf['CurrentTime']=datetime.now()


# In[ ]:

ts= datetime.now()
opfilevar=ts.date()
opfilevar1=ts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=pd.np.floor(float(currhrs)/60)
totaldf['Vehicle Status']=totaldf['Vehicle Status'].fillna('Na')
abc=['-','Na']
totaldf.to_excel(r'D:/Data/Selenium_vehicle_tracking/Final_Output/Final_Output_'+str(opfilevar)+str('_')+str(opfilevar2)+'.xlsx')
totaldf.to_excel(r'D:/Data/Selenium_vehicle_tracking/Final_Output.xlsx')
oppath1 = r'D:/Data/Selenium_vehicle_tracking/Final_Output.xlsx'

# In[ ]:

statusdf=totaldf[~totaldf['Vehicle Status'].isin(abc)]
df1raw=pd.read_excel(r'http://spoton.co.in/downloads/RunningVehicleGPSDetails/THCVehicleGPSDetails.xls',sheetname=0)
df1raw.to_csv(r'D:/Data/Selenium_vehicle_tracking/Backend_Raw'+str(opfilevar)+str('_')+str(opfilevar2)+'.csv')

# In[ ]:

df2raw=pd.read_excel('http://spoton.co.in/downloads/TCR_UND_2HRS/TCR_UND_ISDEPART_YES_2HRS_NEXT_TO_NEXT.xls')
df2raw.to_csv(r'D:/Data/Selenium_vehicle_tracking/Transit_Raw'+str(opfilevar)+str('_')+str(opfilevar2)+'.csv')

# In[ ]:

driver.close()


filePath = oppath1
def sendEmail(TO = ["shashvat.suhane@spoton.co.in"],
            #TO = ["rajeesh.vr@spoton.co.in"],
            #TO = ["vishwas.j@spoton.co.in"],
            #CC = ["vishwas.j@spoton.co.in"],
            CC = ["vishwas.j@spoton.co.in"],
            BCC = ["shashvat.suhane@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    msg["Subject"] = "Selenium_vehicle_tracking " + '- ' + str(opfilevar)+str('-')+ str(opfilevar2)
    body_text = """

    Dear All,
    
    Total vehicles = """+str(len(totaldf))+"""
    Total vehicles with status = """+str(len(statusdf))+"""
    mehta = """+str(mehta)+"""
    superindia= """+str(superind)+"""
    transcargo = """+str(trans)+"""
    mahender = """+str(mahender)+"""
    Radient = """+str(radient)+"""
    dtscargo = """+str(dts)+"""
    mahender 2nd site = """+str(mh2)+"""
    sant = """+str(sant)+"""

    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()


