
# coding: utf-8

# In[ ]:

import pandas as pd
import pyodbc
from datetime import datetime,timedelta
from datetime import datetime,timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
import ftplib
import Utilities
from calendar import monthrange
import smtplib


# In[ ]:

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


# In[ ]:

cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()


# In[ ]:

startdate=datetime.strftime((datetime.now()-timedelta(days=1)).replace(day=1),"%Y-%m-%d")
startdate


# In[ ]:

enddate=datetime.strftime(datetime.now()-timedelta(days=1),"%Y-%m-%d")
enddate


# In[ ]:

query=("""SELECT  A.Dockno COnNumber,
C.BrCode BranchCode,
C.HandMFNO ManifestNumber,
D.AckId AcknowledgementNumber,
A.PISNO PISNumber,
F.DOCKDT PickupDate,
G.DELY_DT DeliveryDate,
A.ShipmentType,
A.CollectedAmt,
E.DocketWiseInvoiceAmount,
A.BankName,
B.ReceivedOn SCReceiveddate,
D.AckDate,
C.CreatedOn ManifestDate,
A.PISGenerated
FROM    dbo.tblCashFTCCollectionDtls A WITH ( NOLOCK )
        INNER JOIN dbo.TblCashFTCHandOverDTLS B WITH ( NOLOCK ) ON B.Dockno = A.Dockno
        INNER JOIN dbo.TBLCashFTCHandOverHDR C WITH ( NOLOCK ) ON C.HandOverid = B.HandOverid
        LEFT JOIN dbo.TblCashFTCHandOver_Ack D WITH ( NOLOCK ) ON D.AckId = B.AckId
        LEFT JOIN dbo.tblInvoiceConMap E WITH (NOLOCK) ON A.Dockno = E.DocketNumber
        LEFT JOIN DOCKET F WITH (NOLOCK) ON A.Dockno = F.DOCKNO
        LEFT JOIN dbo.DKT_DELY G WITH (NOLOCK) ON A.Dockno = G.DOCKNO""")


# In[ ]:

df1=pd.read_sql(query,Utilities.cnxn)


# In[ ]:

df1=df1[~df1['DeliveryDate'].isnull()]
df1['DocketWiseInvoiceAmount']=df1['DocketWiseInvoiceAmount'].apply(lambda x: pd.np.round(x*118)/100,0)
df1['PISNumber']=df1['PISNumber'].fillna(0)

# In[ ]:

df1['Del_Date']=df1['DeliveryDate'].apply(lambda x:str(x).split(' ')[0])


# In[ ]:

df1['Del_cons']=df1['DeliveryDate'].apply(lambda x: 0 if pd.isnull(x) else 1)


# In[ ]:

df1['Manifest']=df1['ManifestDate'].apply(lambda x:0 if x==None else 1)


# In[ ]:

df1['SCReceived']=df1['SCReceiveddate'].apply(lambda x: 0 if pd.isnull(x) else 1)


# In[ ]:

df1['PISGenerate']=df1['PISNumber'].apply(lambda x:0 if x==0 else 1)


# In[ ]:

df1['Ackndge']=df1['AckDate'].apply(lambda x: 0 if pd.isnull(x) else 1)


# In[ ]:

deldf=df1[df1['ShipmentType']=='D']
len(deldf)


# In[ ]:

deldf=deldf[deldf['Del_Date']>=startdate]
len(deldf)


# In[ ]:

mtddelvsummary=deldf.pivot_table(index=['Del_Date'],aggfunc={"Del_cons":sum,'Manifest':sum,"Ackndge":sum,'SCReceived':sum,'PISGenerate':sum}).reset_index()


# In[ ]:

mtddelvsummary=mtddelvsummary[['Del_Date','Del_cons','Manifest','SCReceived','Ackndge','PISGenerate']]


# In[ ]:

mtddelvsummary.loc['Total']=mtddelvsummary[['Del_cons','Manifest','SCReceived','Ackndge','PISGenerate']].sum(axis=0)


# In[ ]:

mtddelvsummary=mtddelvsummary.fillna(0)


# In[ ]:

mtddelvsummary


# In[ ]:

##Yester delivery summary


# In[ ]:

yestdelvdf=deldf[deldf['Del_Date']==enddate]
len(yestdelvdf)


# In[ ]:

ystdelvsummary=yestdelvdf.pivot_table(index=['Del_Date'],aggfunc={"Del_cons":sum,'Manifest':sum,"Ackndge":sum,'SCReceived':sum,'PISGenerate':sum}).reset_index()


if len(ystdelvsummary)>0:
    ystdelvsummary=ystdelvsummary[['Del_Date','Del_cons','Manifest','SCReceived','Ackndge','PISGenerate']]
    ystdelvsummary.loc['Total']=ystdelvsummary[['Del_cons','Manifest','SCReceived','Ackndge','PISGenerate']].sum(axis=0)
    ystdelvsummary=ystdelvsummary.fillna(0)
else:
    ystdelvsummary=pd.DataFrame()
# In[ ]:



# In[ ]:

## MTD Exceptions


# In[ ]:

mtdexceptionsummary=mtddelvsummary


# In[ ]:

mtdexceptionsummary['Delivered but Manifest not done']=mtdexceptionsummary['Del_cons']-mtdexceptionsummary['Manifest']


# In[ ]:

mtdexceptionsummary['Manifet done but SCReceived not done']=mtdexceptionsummary['Manifest']-mtdexceptionsummary['SCReceived']


# In[ ]:

mtdexceptionsummary['SCReceived but Ackndge not done']=mtdexceptionsummary['SCReceived']-mtdexceptionsummary['Ackndge']


# In[ ]:

mtdexceptionsummary['Ackndge done but PISGenerate not done']=mtdexceptionsummary['Ackndge']-mtdexceptionsummary['PISGenerate']


# In[ ]:

mtdexceptionsummary


# In[ ]:

mtdexceptionsummary=mtdexceptionsummary[['Del_Date','Delivered but Manifest not done','Manifet done but SCReceived not done','SCReceived but Ackndge not done','Ackndge done but PISGenerate not done']]


# In[ ]:

mtdexceptionsummary


# In[ ]:

mtddelvsummary=mtddelvsummary[['Del_Date','Del_cons','Manifest','SCReceived','Ackndge','PISGenerate']]


# In[ ]:

df1.to_csv(r'D:\Data\FTC\FTC_Conwise_Data.csv')


# In[ ]:

filepath=r'D:\Data\FTC\FTC_Conwise_Data.csv'


# In[ ]:




# In[ ]:

## Pickup part will start


# In[ ]:

query=("""SELECT  A.Dockno COnNumber,
C.BrCode BranchCode,
C.HandMFNO ManifestNumber,
D.AckId AcknowledgementNumber,
A.PISNO PISNumber,
F.DOCKDT PickupDate,
G.DELY_DT DeliveryDate,
A.ShipmentType,
A.CollectedAmt,
E.DocketWiseInvoiceAmount,
A.BankName,
B.ReceivedOn SCReceiveddate,
D.AckDate,
C.CreatedOn ManifestDate,
A.PISGenerated
FROM    dbo.tblCashFTCCollectionDtls A WITH ( NOLOCK )
        INNER JOIN dbo.TblCashFTCHandOverDTLS B WITH ( NOLOCK ) ON B.Dockno = A.Dockno
        INNER JOIN dbo.TBLCashFTCHandOverHDR C WITH ( NOLOCK ) ON C.HandOverid = B.HandOverid
        LEFT JOIN dbo.TblCashFTCHandOver_Ack D WITH ( NOLOCK ) ON D.AckId = B.AckId
        LEFT JOIN dbo.tblInvoiceConMap E WITH (NOLOCK) ON A.Dockno = E.DocketNumber
        LEFT JOIN DOCKET F WITH (NOLOCK) ON A.Dockno = F.DOCKNO
        LEFT JOIN dbo.DKT_DELY G WITH (NOLOCK) ON A.Dockno = G.DOCKNO""")


# In[ ]:

df1=pd.read_sql(query,Utilities.cnxn)
df1['PISNumber']=df1['PISNumber'].fillna(0)


# In[ ]:

df1['Pickpup_Date']=df1['PickupDate'].apply(lambda x:str(x).split(' ')[0])
df1['Pickup_cons']=df1['PickupDate'].apply(lambda x: 0 if pd.isnull(x) else 1)
df1['Manifest']=df1['ManifestDate'].apply(lambda x:0 if x==None else 1)
df1['SCReceived']=df1['SCReceiveddate'].apply(lambda x: 0 if pd.isnull(x) else 1)
df1['PISGenerate']=df1['PISNumber'].apply(lambda x:0 if x==0 else 1)
df1['Ackndge']=df1['AckDate'].apply(lambda x: 0 if pd.isnull(x) else 1)


# In[ ]:

pkpdf=df1[df1['ShipmentType']=='P']
len(pkpdf)


# In[ ]:

pkpdf=pkpdf[pkpdf['Pickpup_Date']>=startdate]
len(pkpdf)


# In[ ]:

mtddpkpsummary=pkpdf.pivot_table(index=['Pickpup_Date'],aggfunc={"Pickup_cons":sum,'Manifest':sum,"Ackndge":sum,'SCReceived':sum,'PISGenerate':sum}).reset_index()


# In[ ]:

mtddpkpsummary=mtddpkpsummary[['Pickpup_Date','Pickup_cons','Manifest','SCReceived','Ackndge','PISGenerate']]
mtddpkpsummary.loc['Total']=mtddpkpsummary[['Pickup_cons','Manifest','SCReceived','Ackndge','PISGenerate']].sum(axis=0)
mtddpkpsummary=mtddpkpsummary.fillna(0)


# In[ ]:

yestpkpdf=pkpdf[pkpdf['Pickpup_Date']==enddate]
len(yestpkpdf)
ystpkpsummary=yestpkpdf.pivot_table(index=['Pickpup_Date'],aggfunc={"Pickup_cons":sum,'Manifest':sum,"Ackndge":sum,'SCReceived':sum,'PISGenerate':sum}).reset_index()


# In[ ]:

if len(ystpkpsummary)>0:
    ystpkpsummary=ystpkpsummary[['Pickpup_Date','Pickup_cons','Manifest','SCReceived','Ackndge','PISGenerate']]
    ystpkpsummary.loc['Total']=ystpkpsummary[['Pickup_cons','Manifest','SCReceived','Ackndge','PISGenerate']].sum(axis=0)
    ystpkpsummary=ystpkpsummary.fillna(0)
else:
    ystpkpsummary=pd.DataFrame()
mtdpkpexceptionsummary=mtddpkpsummary


# In[ ]:

mtdpkpexceptionsummary['Pickup done but Manifest not done']=mtdpkpexceptionsummary['Pickup_cons']-mtdpkpexceptionsummary['Manifest']
mtdpkpexceptionsummary['Manifet done but SCReceived not done']=mtdpkpexceptionsummary['Manifest']-mtdpkpexceptionsummary['SCReceived']
mtdpkpexceptionsummary['SCReceived but Ackndge not done']=mtdpkpexceptionsummary['SCReceived']-mtdpkpexceptionsummary['Ackndge']
mtdpkpexceptionsummary['Ackndge done but PISGenerate not done']=mtdpkpexceptionsummary['Ackndge']-mtdpkpexceptionsummary['PISGenerate']
mtdpkpexceptionsummary=mtdpkpexceptionsummary[['Pickpup_Date','Pickup done but Manifest not done','Manifet done but SCReceived not done','SCReceived but Ackndge not done','Ackndge done but PISGenerate not done']]


# In[ ]:

mtddpkpsummary=mtddpkpsummary[['Pickpup_Date','Pickup_cons','Manifest','SCReceived','Ackndge','PISGenerate']]






## Report2 Starts

startdate=datetime.strftime((datetime.now()-timedelta(days=1)).replace(day=1),"%Y-%m-%d")
startdate


# In[4]:

enddate=datetime.strftime(datetime.now()-timedelta(days=1),"%Y-%m-%d")
enddate


# In[5]:

query=("""SELECT  A.Dockno COnNumber,
C.BrCode BranchCode,
C.HandMFNO ManifestNumber,
D.AckId AcknowledgementNumber,
D.CreatedBy ACK_PIS_by,
A.PISNO PISNumber,
F.DOCKDT PickupDate,
G.DELY_DT DeliveryDate,
A.ShipmentType,
A.CollectedAmt,
E.DocketWiseInvoiceAmount,
A.BankName,
B.ReceivedOn SCReceiveddate,
C.HandOverEmpcd Manifest_HandOverEmpcd,
B.ReceivedBy,
D.AckDate,
C.CreatedOn ManifestDate,
A.ANDROIDUSERID vendordetails,
A.PISGenerated
FROM    dbo.tblCashFTCCollectionDtls A WITH ( NOLOCK )
        INNER JOIN dbo.TblCashFTCHandOverDTLS B WITH ( NOLOCK ) ON B.Dockno = A.Dockno
        INNER JOIN dbo.TBLCashFTCHandOverHDR C WITH ( NOLOCK ) ON C.HandOverid = B.HandOverid
        LEFT JOIN dbo.TblCashFTCHandOver_Ack D WITH ( NOLOCK ) ON D.AckId = B.AckId
        LEFT JOIN dbo.tblInvoiceConMap E WITH (NOLOCK) ON A.Dockno = E.DocketNumber
        LEFT JOIN DOCKET F WITH (NOLOCK) ON A.Dockno = F.DOCKNO
        LEFT JOIN dbo.DKT_DELY G WITH (NOLOCK) ON A.Dockno = G.DOCKNO
WHERE   G.DELY_DT BETWEEN '{0}'
                  AND    '{1}'
 

""").format (startdate, enddate) 


# In[6]:

df2=pd.read_sql(query,cnxn)


# In[7]:

df1=df2[df2['ShipmentType']=='D']


# In[8]:

df1=df1[~df1['DeliveryDate'].isnull()]
df1['DocketWiseInvoiceAmount']=df1['DocketWiseInvoiceAmount'].apply(lambda x: pd.np.round(x*118)/100,0)


# In[10]:

df1['PISNumber']=df1['PISNumber'].fillna(0)


# In[12]:

df1['Del_Date']=df1['DeliveryDate'].apply(lambda x:str(x).split(' ')[0])


# In[ ]:

df1['Del_cons']=df1['DeliveryDate'].apply(lambda x: 0 if pd.isnull(x) else 1)


# In[ ]:

df1['Manifest']=df1['ManifestDate'].apply(lambda x:0 if x==None else 1)


# In[ ]:

df1['SCReceived']=df1['SCReceiveddate'].apply(lambda x: 0 if pd.isnull(x) else 1)


# In[ ]:

df1['PISGenerate']=df1['PISNumber'].apply(lambda x:0 if x==0 else 1)


# In[ ]:

df1['Ackndge']=df1['AckDate'].apply(lambda x: 0 if pd.isnull(x) else 1)


# In[ ]:

deldf=df1[df1['ShipmentType']=='D']
len(deldf)


# In[ ]:

deldf=deldf[deldf['Del_Date']>=startdate]
len(deldf)


# In[13]:

def a(Manifest,SCReceived,Ackndge,PISGenerate):
    if Manifest==0:
        return 'Delivered but manifest not done'
    else:
        if SCReceived==0:
            return 'Manifest done but not received by SC'
        else:
            if Ackndge==0:
                return 'Received by SC but Acknwledgement not done'
            else:
                if PISGenerate==0:
                    return 'Acknowlegdement done but PIS not done'
                else:
                    return 'PIS Done'
        


# In[14]:

df1['Status']=df1.apply(lambda x:a (x['Manifest'],x['SCReceived'],x['Ackndge'],x['PISGenerate']),axis=1)


# In[15]:




# In[16]:

dd1=df1[df1['Status']=='Delivered but manifest not done']
dd2=df1[df1['Status']=='Manifest done but not received by SC']
dd3=df1[df1['Status']=='Received by SC but Acknwledgement not done']
dd4=df1[df1['Status']=='Acknowlegdement done but PIS not done']


# In[17]:

dd11=dd1.pivot_table(index=['BranchCode','vendordetails'],values=['COnNumber'],aggfunc={'COnNumber':len}).reset_index()
dd21=dd2.pivot_table(index=['BranchCode','Manifest_HandOverEmpcd'],values=['COnNumber'],aggfunc={'COnNumber':len}).reset_index()
dd31=dd3.pivot_table(index=['BranchCode','ReceivedBy'],values=['COnNumber'],aggfunc={'COnNumber':len}).reset_index()
dd41=dd4.pivot_table(index=['BranchCode','ACK_PIS_by'],values=['COnNumber'],aggfunc={'COnNumber':len}).reset_index()


# # Delivered but manifest not done

# In[18]:

dd11


# # Manifest done but not received by SC(Delivery)

# In[19]:

dd21


# # Received by SC but Acknwledgement not done(Delivery)

# In[20]:

dd31


# # Acknowlegdement done but PIS not done(Delivery)

# In[21]:

dd41


# In[22]:

cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()


# In[23]:

startdate=datetime.strftime((datetime.now()-timedelta(days=1)).replace(day=1),"%Y-%m-%d")
startdate


# In[5]:

enddate=datetime.strftime(datetime.now()-timedelta(days=1),"%Y-%m-%d")
enddate


# In[27]:

query=("""SELECT  A.Dockno COnNumber,
C.BrCode BranchCode,
C.HandMFNO ManifestNumber,
D.AckId AcknowledgementNumber,
D.CreatedBy ACK_PIS_by,
A.PISNO PISNumber,
F.DOCKDT PickupDate,
G.DELY_DT DeliveryDate,
A.ShipmentType,
A.CollectedAmt,
E.DocketWiseInvoiceAmount,
A.BankName,
B.ReceivedOn SCReceiveddate,
C.HandOverEmpcd Manifest_HandOverEmpcd,
B.ReceivedBy,
D.AckDate,
C.CreatedOn ManifestDate,
A.ANDROIDUSERID vendordetails,
A.PISGenerated
FROM    dbo.tblCashFTCCollectionDtls A WITH ( NOLOCK )
        INNER JOIN dbo.TblCashFTCHandOverDTLS B WITH ( NOLOCK ) ON B.Dockno = A.Dockno
        INNER JOIN dbo.TBLCashFTCHandOverHDR C WITH ( NOLOCK ) ON C.HandOverid = B.HandOverid
        LEFT JOIN dbo.TblCashFTCHandOver_Ack D WITH ( NOLOCK ) ON D.AckId = B.AckId
        LEFT JOIN dbo.tblInvoiceConMap E WITH (NOLOCK) ON A.Dockno = E.DocketNumber
        LEFT JOIN DOCKET F WITH (NOLOCK) ON A.Dockno = F.DOCKNO
        LEFT JOIN dbo.DKT_DELY G WITH (NOLOCK) ON A.Dockno = G.DOCKNO
WHERE   F.DOCKDT BETWEEN '{0}'
                  AND    '{1}'
 

""").format (startdate, enddate) 


# In[28]:

df3=pd.read_sql(query,cnxn)


# In[29]:

df4=df3[df3['ShipmentType']=='P']


# In[30]:




# In[31]:

df4=df4[~df4['DeliveryDate'].isnull()]
df4['DocketWiseInvoiceAmount']=df4['DocketWiseInvoiceAmount'].apply(lambda x: pd.np.round(x*118)/100,0)


# In[32]:

df4['PISNumber']=df4['PISNumber'].fillna(0)


# In[33]:

df4['pick_Date']=df4['PickupDate'].apply(lambda x:str(x).split(' ')[0])


# In[ ]:

df4['pick_cons']=df4['PickupDate'].apply(lambda x: 0 if pd.isnull(x) else 1)


# In[ ]:

df4['Manifest']=df4['ManifestDate'].apply(lambda x:0 if x==None else 1)


# In[ ]:

df4['SCReceived']=df4['SCReceiveddate'].apply(lambda x: 0 if pd.isnull(x) else 1)


# In[ ]:

df4['PISGenerate']=df4['PISNumber'].apply(lambda x:0 if x==0 else 1)


# In[ ]:

df4['Ackndge']=df4['AckDate'].apply(lambda x: 0 if pd.isnull(x) else 1)





# In[34]:

def b(Manifest,SCReceived,Ackndge,PISGenerate):
    if Manifest==0:
        return 'Pickedup but manifest not done'
    else:
        if SCReceived==0:
            return 'Manifest done but not received by SC'
        else:
            if Ackndge==0:
                return 'Received by SC but Acknwledgement not done'
            else:
                if PISGenerate==0:
                    return 'Acknowlegdement done but PIS not done'
                else:
                    return 'PIS Done'


# In[35]:

df4['Status']=df4.apply(lambda x:b (x['Manifest'],x['SCReceived'],x['Ackndge'],x['PISGenerate']),axis=1)


# In[36]:

dp1=df4[df4['Status']=='Pickedup but manifest not done']
dp2=df4[df4['Status']=='Manifest done but not received by SC']
dp3=df4[df4['Status']=='Received by SC but Acknwledgement not done']
dp4=df4[df4['Status']=='Acknowlegdement done but PIS not done']


# In[37]:

dp11=dp1.pivot_table(index=['BranchCode','vendordetails'],values=['COnNumber'],aggfunc={'COnNumber':len}).reset_index()
dp21=dp2.pivot_table(index=['BranchCode','Manifest_HandOverEmpcd'],values=['COnNumber'],aggfunc={'COnNumber':len}).reset_index()
dp31=dp3.pivot_table(index=['BranchCode','ReceivedBy'],values=['COnNumber'],aggfunc={'COnNumber':len}).reset_index()
dp41=dp4.pivot_table(index=['BranchCode','ACK_PIS_by'],values=['COnNumber'],aggfunc={'COnNumber':len}).reset_index()


# # Picked up but manifest not done

# In[38]:

dp11


# # Manifest done but not received by SC(Pickup)

# In[39]:

dp21


# # Received by SC but Acknwledgement not done(Pickup)

# In[40]:

dp31


# # Acknowlegdement done but PIS not done(Pickup)

# In[41]:

dp41


# In[42]:

df1
df4

df1.to_csv(r'D:\Data\FTC\Report2\Delivery_data.csv')
df4.to_csv(r'D:\Data\FTC\Report2\Pickup_data.csv')


# In[36]:


filepath1=r'D:\Data\FTC\Report2\Delivery_data.csv'
filepath2=r'D:\Data\FTC\Report2\Pickup_data.csv'

# In[ ]:
# TO=['saptarshi.pathak@spoton.co.in']
TO=['badan.singh@spoton.co.in','saptarshi.pathak@spoton.co.in','dillip.padhi@spoton.co.in','banusanketh.dc@spoton.co.in','abhik.mitra@spoton.co.in','krishna.chandrasekar@spoton.co.in','scincharge_spot@spoton.co.in','ROM_SPOT@spoton.co.in','AOM_SPOT@spoton.co.in','DOM_SPOT@spoton.co.in','pawan.sharma@spoton.co.in','rajesh.kumar@spoton.co.in','suman.kumar@spoton.co.in','manjunath.swamy@spoton.co.in','mahesh.reddy@spoton.co.in']
CC=['mahesh.reddy@spoton.co.in']
FROM="reports.ie@spoton.co.in"
# FROM="mahesh.reddy@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "Cash HOTO Summary & Exceptions Report(YST & MTD)" + " - " + str(enddate)

report=""
report+="Dear All,"
report+='<br>'
report+='Please find the FTC Summary & Exceptions Report'
report+='<br>'
report+='YST Delivery Summary. '
report+='<br>'
report+='<br>'+ystdelvsummary.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='Yesterday Pickup Summary. '
report+='<br>'
report+='<br>'+ystpkpsummary.to_html()+'<br>'
report+='<br>'
report+='MTD Delivery Exceptions '
report+='<br>'
report+='<br>'+mtdexceptionsummary.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='MTD Pickup Exceptions '
report+='<br>'
report+='<br>'+mtdpkpexceptionsummary.to_html()+'<br>'
report+='<br>'
report+='MTD Delivered but manifest not done. '
report+='<br>'
report+='<br>'+dd11.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='MTD Manifest done but not received by SC(Delivery). '
report+='<br>'
report+='<br>'+dd21.to_html()+'<br>'
report+='<br>'
report+='MTD Received by SC but Acknwledgement not done(Delivery) '
report+='<br>'
report+='<br>'+dd31.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='MTD Acknowlegdement done but PIS not done(Delivery) '
report+='<br>'
report+='<br>'+dd41.to_html()+'<br>'
report+='<br>'

report+='MTD Picked up but manifest not done '
report+='<br>'
report+='<br>'+dp11.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='MTD Manifest done but not received by SC(Pickup) '
report+='<br>'
report+='<br>'+dp21.to_html()+'<br>'
report+='<br>'
report+='MTD Received by SC but Acknwledgement not done(Pickup) '
report+='<br>'
report+='<br>'+dp31.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='MTD Acknowlegdement done but PIS not done(Pickup) '
report+='<br>'
report+='<br>'+dp41.to_html()+'<br>'
report+='<br>'

abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(filepath1,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
msg.attach(part1)

part2 = MIMEBase('application', "octet-stream")
part2.set_payload( open(filepath2,"rb").read() )
encoders.encode_base64(part2)
part2.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath2))
msg.attach(part2)



# server=smtplib.SMTP('smtp.sendgrid.net', 587)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("mahesh.reddy@spoton.co.in", "Nov@2018")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()


# In[ ]:



