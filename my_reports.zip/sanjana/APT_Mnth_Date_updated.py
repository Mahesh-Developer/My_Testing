
# coding: utf-8

# In[1]:


from datetime import datetime,date,timedelta
import sys
reload(sys).setdefaultencoding("ISO-8859-1")


# In[2]:


startdate=date.today().replace(day=1)


# In[3]:


startdate


# In[4]:


dates=[]
#dates.append(premnthlastdate)


# In[5]:


enddate=date.today()
enddate


# In[6]:


delta=enddate-startdate


# In[7]:


delta


# In[8]:


for i in range(delta.days+1):
    a=datetime.strftime(startdate+timedelta(days=i),"%Y-%m-%d")
    dates.append(a)


# In[9]:


len(dates)


# In[10]:


tomorrowdate=datetime.strftime(enddate+timedelta(1),"%Y-%m-%d")


# In[11]:


dates.append(tomorrowdate)


# In[12]:


dates


# In[13]:


for i in range(len(dates)):
    try:
        print (dates[i],dates[i+1])
    except:
        pass


# In[14]:


import pandas as pd
from datetime import datetime, timedelta
import numpy as np
from sqlalchemy import *
pd.set_option("display.max_columns",100)


# In[15]:


engine = create_engine("mysql+pymysql://spotonhr:spoton54321@104.199.198.197/hourlyinventory")


# In[16]:


for i in range(len(dates)-1):
    ff=pd.DataFrame()
perfpivot3=pd.DataFrame()
l=[]
#dates=['2018-02-01','2018-02-02','2018-02-03','2018-02-04','2018-02-05','2018-02-06','2018-02-07','2018-02-08','2018-02-09','2018-02-10','2018-02-11','2018-02-12','2018-02-13','2018-02-14','2018-02-15','2018-02-16','2018-02-17','2018-02-18','2018-02-19','2018-02-20','2018-02-21','2018-02-22','2018-02-23','2018-02-24','2018-02-25','2018-02-26','2018-02-27','2018-02-28','2018-03-01','2018-03-02']
for i in range(0,len(dates)):
    try:
        a1=str(dates[i])
        a2=str(dates[i+1])
        a3=str(dates[i+2])
        c=(dates[i].split('-'))
        c1=c[2]+'/'+c[1]+'/'+c[0]
        startdate="'"+str(dates[i])+"'"
        enddate="'"+str(dates[i+1])+"'"
        enddate2="'"+str(dates[i+2])+"'"
        print (startdate,enddate,enddate2)
        #dd=frame[(frame['Timestate Date']>=a1)&(frame['Timestate Date']<=a2)&(frame['Con Status Code']=='APT')&(frame['Appointment Date']==c1)]
        query=("SELECT * FROM destsc WHERE `Timestate Date` >= {0} AND `Timestate Date` < {1} AND `Con Status Code`='APT' AND `Appointment Date` LIKE {2}".format(startdate,enddate,"'"+eval(startdate)+"%%")+"'")
        dd=pd.read_sql(query,engine)
        doclist=dd["DOCKNO"].tolist()
        doclist2=tuple(str(tup) for tup in doclist)
        print ('dd',len(dd))
#         #todd=frame[(frame['Timestate Date']>=a2)&(frame['Timestate Date']<=a3)&(frame['DOCKNO'].isin(doclist2))] 
        todd=pd.read_sql("SELECT * FROM destsc WHERE `Timestate Date` >= {0} AND `Timestate Date` < {1} AND `DOCKNO` IN {2}".format(enddate,enddate2,str(doclist2)),engine)
        print ('todd',len(todd))
        today=datetime.today().replace(hour=0,minute=0,second=0,microsecond=0)
        todd["Remarks"]=todd.apply(lambda x: "Undelivered" if pd.isnull(x["Appointment Date"])==True or x["Appointment Date"]>=today else "Missed",axis=1)
        
        dd=dd.merge(todd.loc[:,["DOCKNO","Remarks"]],on="DOCKNO",how="left")
        print ('dd1',len(dd))
        dd["Remarks"]=dd["Remarks"].fillna("Delivered")
        perfpivot=dd.loc[:,["DEST DEPOT","Remarks","DOCKNO"]].pivot_table(index=["DEST DEPOT"],columns=["Remarks"],values=['DOCKNO'],aggfunc={"DOCKNO": len},margins=True)#.fillna(0.0)#.sort_values(("DOCKNO","All"),ascending=False)
        #print (perfpivot)
        perfpivot.columns = [' '.join(col).strip() for col in perfpivot.columns.values]
        perfpivot1=perfpivot.reset_index()
        print (perfpivot1)
        perfpivot2=perfpivot1
        dd['Date']=a1
        perfpivot3=pd.concat([perfpivot3,dd],ignore_index=True)
        perfpivot1=perfpivot1[perfpivot1['DEST DEPOT']!='All']
        dff=pd.DataFrame()
        for col in ['DOCKNO Delivered','DOCKNO Undelivered','DOCKNO All']:
            if col in perfpivot1.columns:
                print ('y')
            else:
                perfpivot1[col]=0
        if 'Missed' in dd['Remarks'].unique():
            di={'Date':a1,'Delivered':perfpivot1['DOCKNO Delivered'].sum(),'Missed':perfpivot1['DOCKNO Missed'].sum(),'Undelivered':perfpivot1['DOCKNO Undelivered'].sum(),'Total':perfpivot1['DOCKNO All'].sum()}
            dff=pd.DataFrame([di])
            ff=pd.concat([ff,dff],ignore_index=True)
        else:
            di={'Date':a1,'Delivered':perfpivot1['DOCKNO Delivered'].sum(),'Undelivered':perfpivot1['DOCKNO Undelivered'].sum(),'Total':perfpivot1['DOCKNO All'].sum()}
            dff=pd.DataFrame([di])
            ff=pd.concat([ff,dff],ignore_index=True)
        
        
    except:
        pass
# # ff=pd.concat(l)
# #ff['Delivery%']=pd.np.round((ff['Delivered']*100.0/ff['Total']),1)


print (ff)
print (perfpivot3)


# In[ ]:


#calculating APT Performance
# data1=['All',ff['Delivered'].sum(),ff['Undelivered'].sum(),ff['Total'].sum(),pd.np.round(ff['Delivered'].sum()*100.0/ff['Total'].sum())]
# colu=['Date','Delivered','Undelivered','Total','APT Performance']
# total_df=pd.DataFrame(data=[data1],columns=colu)
# total_df['Delivered']=total_df['Delivered'].astype(int)
# total_df['Undelivered']=total_df['Undelivered'].astype(int)
# # total_df['Missed']=total_df['Missed'].astype(int)
# total_df['Total']=total_df['Total'].astype(int)
# total_df['APT Performance%']=total_df['APT Performance'].astype(int).astype(str)+'%'
# del total_df['APT Performance']


# In[17]:


ff


# In[18]:

ff=ff.fillna(0)


# In[19]:


perfpivot3['Remarks'].unique()


# In[20]:


#calculating total for datewise and concating to original dataframe
if 'Missed' in ff.columns:
    data2=['Total',ff['Delivered'].sum(),ff['Missed'].sum(),ff['Undelivered'].sum(),ff['Total'].sum()]
    colu2=['Date','Delivered','Missed','Undelivered','Total']
    ff1=pd.DataFrame(data=[data2],columns=colu2)
    ff=pd.concat([ff,ff1],ignore_index=True)
    ff['Delivered']=ff['Delivered'].astype(int)
    ff['Missed']=ff['Missed'].astype(int)
    ff['Total']=ff['Total'].astype(int)
    ff['Undelivered']=ff['Undelivered'].astype(int)
else:
    data2=['Total',ff['Delivered'].sum(),ff['Undelivered'].sum(),ff['Total'].sum()]
    colu2=['Date','Delivered','Undelivered','Total']
    ff1=pd.DataFrame(data=[data2],columns=colu2)
    print (ff1)
    ff=pd.concat([ff,ff1],ignore_index=True)
    ff['Delivered']=ff['Delivered'].astype(int)
    # ff['Missed']=ff['Missed'].astype(int)
    ff['Total']=ff['Total'].astype(int)
    ff['Undelivered']=ff['Undelivered'].astype(int)


# In[21]:


ff


# In[22]:


perfpivot3=perfpivot3[perfpivot3['DEST DEPOT']!='All']


# In[23]:


pivot1=pd.pivot_table(perfpivot3,index=['DEST DEPOT'],columns=['Date','Remarks'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,fill_value=0)


# In[24]:


for i in range(0,len(pivot1.columns.tolist())-1,2):
    pivot1[('DOCKNO',pivot1.columns.tolist()[i][1],'Total')]=pivot1[pivot1.columns.tolist()[i]]+pivot1[pivot1.columns.tolist()[i+1]]


# In[25]:


datetime.strftime(date.today()-timedelta(1),'%Y-%m-%d')


# In[26]:


pivot2=pivot1.reindex_axis(sorted(pivot1.columns), axis=1)


# In[27]:


pivot3=pd.pivot_table(perfpivot3,index=['DEST DEPOT'],columns=['Remarks'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total')


# In[28]:


pivot3


# In[29]:


pivot3[('DOCKNO','APT_DE%')]=pd.np.round(pivot3[('DOCKNO','Delivered')]*100.0/pivot3[('DOCKNO','Total')],0)
pivot3=pivot3.fillna(0)


# In[33]:

try:
    pivot3[('DOCKNO','Delivered')]=pivot3[('DOCKNO','Delivered')].astype(int)
    pivot3[('DOCKNO','Undelivered')]=pivot3[('DOCKNO','Undelivered')].astype(int)
    pivot3[('DOCKNO','Total')]=pivot3[('DOCKNO','Total')].astype(int)
    pivot3[('DOCKNO','APT_DE%')]=pivot3[('DOCKNO','APT_DE%')].astype(int)
    pivot3[('DOCKNO','Missed')]=pivot3[('DOCKNO','Missed')].astype(int)
except:
    pivot3[('DOCKNO','Delivered')]=pivot3[('DOCKNO','Delivered')].astype(int)
    pivot3[('DOCKNO','Undelivered')]=pivot3[('DOCKNO','Undelivered')].astype(int)
    pivot3[('DOCKNO','Total')]=pivot3[('DOCKNO','Total')].astype(int)
    pivot3[('DOCKNO','APT_DE%')]=pivot3[('DOCKNO','APT_DE%')].astype(int)
    #pivot3[('DOCKNO','Missed')]=pivot3[('DOCKNO','Missed')].astype(int)


# In[34]:


#APT for yesterday
yest_perfpivot=perfpivot3[perfpivot3['Date']==(datetime.strftime(date.today()-timedelta(1),'%Y-%m-%d'))]
len(yest_perfpivot)


# In[35]:

print (yest_perfpivot[['DEST DEPOT','Remarks','DOCKNO']])

try:
    yest_perfpivot1=pd.pivot_table(yest_perfpivot,index=['DEST DEPOT'],columns=['Remarks'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total')
except:
    yest_perfpivot1=pd.DataFrame()
    yest_perfpivot1['Delivered']=0
    yest_perfpivot1['Undelivered']=0
    yest_perfpivot1['Total']=0
# In[36]:


yest_perfpivot1=yest_perfpivot1.fillna(0)


# In[37]:


yest_perfpivot1


# In[38]:

try:
    yest_perfpivot1[('DOCKNO','APT_DE%')]=pd.np.round(yest_perfpivot1[('DOCKNO','Delivered')]*100.0/yest_perfpivot1[('DOCKNO','Total')],0)
    yest_perfpivot1[('DOCKNO','Delivered')]=yest_perfpivot1[('DOCKNO','Delivered')].astype(int)
    yest_perfpivot1[('DOCKNO','Undelivered')]=yest_perfpivot1[('DOCKNO','Undelivered')].astype(int)
    yest_perfpivot1[('DOCKNO','Total')]=yest_perfpivot1[('DOCKNO','Total')].astype(int)
    yest_perfpivot1[('DOCKNO','APT_DE%')]=yest_perfpivot1[('DOCKNO','APT_DE%')].astype(int)
except:
    yest_perfpivot1['APT_DE%']=pd.np.round(yest_perfpivot1['Delivered']*100.0/yest_perfpivot1['Total'],0)
    yest_perfpivot1['Delivered']=yest_perfpivot1['Delivered'].astype(int)
    yest_perfpivot1['Undelivered']=yest_perfpivot1['Undelivered'].astype(int)
    yest_perfpivot1['Total']=yest_perfpivot1['Total'].astype(int)
    yest_perfpivot1['APT_DE%']=yest_perfpivot1['APT_DE%'].astype(int)

# In[39]:


#APT for date and depot wise
perfpivot4_pivot=pd.pivot_table(perfpivot3,index=['Date','DEST DEPOT'],columns=['Remarks'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total',fill_value=0)


# In[40]:


ff.columns


# In[41]:


if 'Missed' in ff.columns:
    ff2=ff[['Date','Delivered','Missed','Undelivered','Total']]
    ff2['APT_DE%']=ff2['Delivered']*100.0/ff2['Total']
    ff2['APT_DE%']=ff2['APT_DE%'].astype(int)
else:
    ff2=ff[['Date','Delivered','Undelivered','Total']]
    ff2['APT_DE%']=ff2['Delivered']*100.0/ff2['Total']
    ff2['APT_DE%']=ff2['APT_DE%'].astype(int)


# In[42]:



ff2


# In[43]:


undelivered_cons_df=perfpivot3[perfpivot3['Remarks']=='Undelivered']
delivered_cons_df=perfpivot3[perfpivot3['Remarks']=='Delivered']
len(delivered_cons_df)


# In[44]:
from datetime import date,timedelta
todate=date.today()-timedelta(1)
today_date=datetime.strftime(todate,'%d-%m-%Y')
today_date

from pandas import ExcelWriter
with ExcelWriter(r'D:\Data\APT_Month_Date\APT_Month_To_Date'+str(today_date)+'.xlsx') as writer:
    yest_perfpivot1.to_excel(writer,engine='xlsxwriter',sheet_name='Yesterday Summary')
    perfpivot4_pivot.to_excel(writer,engine='xlsxwriter',sheet_name='APT DATA Date&Depot Wise')
    pivot3.to_excel(writer,engine='xlsxwriter',sheet_name='Depot Wise Summary')
    perfpivot3.to_excel(writer,engine='xlsxwriter',sheet_name='Data')




# In[45]:


filePath=r'D:\Data\APT_Month_Date\APT_Month_To_Date'+str(today_date)+'.xlsx'


# In[46]:



#vishwas.j@spoton.co.in
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template
TO=['mahesh.reddy@spoton.co.in']
#TO=['ankit@iepfunds.com','supratim@iepfunds.com','pawan.sharma@spoton.co.in','krishna.chandrasekar@spoton.co.in','abhik.mitra@spoton.co.in','vishwas.j@spoton.co.in','jothi.menon@spoton.co.in','sharmistha.majumdar@spoton.co.in','sq_spot@spoton.co.in','aom_spot@spoton.co.in','dom_spot@spoton.co.in','rom_spot@spoton.co.in','ganesh.m@spoton.co.in','vinit.tiwari@spoton.co.in','raghavendra.rao@spoton.co.in','mani.kumar@spoton.co.in']
FROM='reports.ie@spoton.co.in'
BCC=['mahesh.reddy@spoton.co.in']
# BCC=['maheshmahesh11464@gmail.com']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
#msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = "APT Performance Month to Date as of" + " : " + str(today_date)
html='''<html>
<style>
p
{
  margin:0;
  margin-top: 5px;
  padding:0;
  font-size:17px;
    line-height:20px;
}
</style>
<h4>Dear All,</h4>
<p>PFA,APT Performance Month to Date as of $date</p>
<h3>APT Performance Month for Yesterday</h3>
</html>'''

html3='''
<h3>APT Performance Month to Date</h3>

'''
s = Template(html).safe_substitute(date=today_date)
report=""
report+=s
report+='<br>'+yest_perfpivot1.fillna(0).to_html()+'<br>'
report+=html3
report+='<br>'+pivot3.fillna(0).to_html()+'<br>'
report+='<br>'+ff2.fillna(0).to_html()+'<br>'
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filePath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+BCC, msg.as_string())
server.quit()


# In[ ]:


pivot3

