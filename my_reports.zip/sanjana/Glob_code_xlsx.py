# -*- coding: utf-8 -*-
"""
Created on Mon Nov 28 15:10:32 2016

@author: rajeeshv
"""

import pandas as pd
import glob
from pandas import ExcelWriter

#path =r'D:\Data\Load_available_archives\All\Oct_load_available' # use your path
#
#allFiles = glob.glob(path + "/*.xlsx")
#frame = pd.DataFrame()
#list_ = []
#for file_ in allFiles:
#    df = pd.read_csv(file_,index_col=None, header=0)
#    list_.append(df)
#frame = pd.concat(list_)
#frame.to_csv(r'D:\Data\Load_available_glob_Oct16.csv')



glob.glob("D:\Data\Load_available_archives\All\Sep-2017\Load*.xlsx")


#mainloclist = ['DELH-DELC','DELH-DELB','DELH-DELT','DELH-DELM','DELH-NDAB','DELH-GTBB','DELH-DWKB','DELH-DELT']
#mainloclist = ['PNQH','DELH','BLRH','HYDH','BOMH']
all_data = pd.DataFrame()
for f in glob.glob("D:\Data\Load_available_archives\All\Sep-2017\Load*.xlsx"):
    df = pd.read_excel(f,"Data")
    #df = pd.DataFrame(df, columns=['Con Number','Hub SC Location','Next Loc','Act Wt In Tonnes','Arrival Date Hub','Observation','TIMESTAMP'])
    print df.TIMESTAMP.unique()
    #df = df[(df['Hub SC Location'].isin(mainloclist))]
    all_data = all_data.append(df,ignore_index=True)
print len(all_data)
#all_data.drop('Latest Status Reason',axis=1,inplace=True)

all_data.to_csv(r'D:\Data\Load-available_Sep2017_1-15.csv',encoding='cp1252')

#with ExcelWriter(r'D:\Data\Load_availabel_DEL_BLR_Dec16.xlsx') as writer:
#    ###orginal_cancel_basedata.to_excel(writer, sheet_name='Sheet1',engine='xlsxwriter')
#    all_data.to_excel(writer, sheet_name='All_Data',engine='xlsxwriter')
    
"""

path =r'D:\Data\Duedate_diagnostic\Basedata' # use your path
#
allFiles = glob.glob(path + "/*.csv")
frame = pd.DataFrame()
list_ = []
for file_ in allFiles:
    df = pd.read_csv(file_,index_col=None, header=0)
    list_.append(df)
frame = pd.concat(list_)
frame.to_csv(r'D:\Data\DueDateDiagnostic_Glob.csv')
"""