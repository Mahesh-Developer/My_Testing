
# coding: utf-8

# In[1]:


import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
from datetime import datetime, timedelta, date

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
import traceback


# In[2]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


df = pd.read_sql("""SELECT  AutoID , 
                                [Serving PinCodes Pincode] , 
                                [Current Serving Branch] , 
                                [Proposed Serving Branch] , 
                                [Controlling Hub] , 
                                [Zone] , 
                                [proposed SC(Yes No)] proposedSC, 
                                UpdatedBy,
                                br.ControlArea
                        FROM    TBL_ODA_SERVING_BRANCH SB WITH ( NOLOCK ) 
                                INNER JOIN dbo.brms BR WITH ( NOLOCK ) ON BR.BRCD = SB.[Current Serving Branch] 
                                LEFT OUTER JOIN dbo.EMPMST EM WITH ( NOLOCK ) ON SB.UpdatedBy = EM.EMPCD  """,Utilities.cnxn) 

# df = pd.read_sql("""SELECT TOP 10 * FROM BRMS WITH (NOLOCK)""",cnxn) 


# In[4]:


df.columns.tolist()


# In[5]:


df.rename(columns={'Serving PinCodes Pincode':'Pincode'},inplace=True)


# In[8]:


df.UpdatedBy.fillna('-',inplace=True)


# In[9]:


df['UpdatedBy'].unique()


# In[10]:


blanklist= ['-','']


# In[11]:


def updation(updatedby):
    if updatedby in blanklist:
        return 'No'
    else:
        return 'Yes'


# In[12]:


df['Updated_Yes/No'] = df.apply(lambda x:updation(x['UpdatedBy']),axis=1)


# In[13]:


df['Updated_Yes/No'].unique()


dfsum = pd.pivot_table(df,index=['ControlArea'], columns =['Updated_Yes/No'], values=['Pincode'], aggfunc=len, fill_value=0 ,margins=True).reset_index()

dfsum['Pincode'] = dfsum['Pincode'].astype(int)


# In[16]:


dfsum.fillna(0,inplace=True)

dfsum.round(2)

today=date.today()
today_date=datetime.strftime(today,'%d-%m-%Y')


df.to_csv(r'D:\Data\ODA Pincode Update\ODA_Updated_'+str(today)+'.csv')

filepath = 'D:\Data\ODA Pincode Update\ODA_Updated_'+str(today)+'.csv'


# TO=['vishwas.j@spoton.co.in']
# CC=['vishwas.j@spoton.co.in']
# BCC=['vishwas.j@spoton.co.in']
TO=["dom_spot@spoton.co.in","rom_spot@spoton.co.in",'aom_spot@spoton.co.in']
BCC = ['mahesh.reddy@spoton.co.in']
CC=['rajesh.kumar@spoton.co.in','pawan.sharma@spoton.co.in','abhik.mitra@spoton.co.in','satya.pal@spoton.co.in','shivananda.p@spoton.co.in','anto.paul@spoton.co.in','mahesh.reddy@spoton.co.in','saptarshi.pathak@spoton.co.in']
FROM='reports.ie@spoton.co.in'
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "ODA Pincode Serving Branch Update Status -"+ str(today)

report=""
# report+='<br>'
report+='PFB the summary areawise where ODA serving branch is updated or not'
report+='<br>'
report+=''
report+='<br>'+dfsum.to_html()+'<br>'

# klm=MIMEText(report,'html')
# msg.attach(klm)
# bcd=MIMEText(senddf1.to_html(),'html')
# msg.attach(bcd)
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()
