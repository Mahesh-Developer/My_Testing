# -*- coding: utf-8 -*-
"""
Created on Wed Oct 26 10:44:10 2016

@author: rajeeshv
"""


# coding: utf-8

# In[1]:

import graphlab as gl
import graphlab.aggregate as agg
import pandas as pd
from datetime import datetime, timedelta
import networkx as nx
import time

import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
import os


# In[2]:
#condata = gl.SFrame(r'D:\Python\Scripts and Files\Path and Graph Files\Con_data_201016.csv')
condata = gl.SFrame(r'http://spoton.co.in/downloads/IEP_CON_DATA_TO_SQ/IEP_CON_DATA_TO_SQ.csv')
condata = condata.rename({'\xef\xbb\xbfDOCKNO': 'DOCKNO'})


#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
#cursor = cnxn.cursor()
#
#condataquery = ("""
#        EXEC USP_CON_DATA_SQ_IE
#        """)
##
##condatadf = pd.read_sql(condataquery, cnxn)
##condatadf.to_csv(r'D:\Python\Scripts and Files\Path and Graph Files\Condata18Oct_test.csv')
##print 'condatadf',type(condatadf)
##print condatadf['Pickupdate'].values[0]
##
##
##condata = gl.SFrame(data=condatadf)
##print type (condata)
##print condata['Pickupdate'][0]
#
#condata = gl.SFrame.from_sql(cnxn, condataquery)
#
##condata = gl.SFrame(r'D:\Python\Scripts and Files\Path and Graph Files\Condata18Oct_test.csv')
#print 'condata',type(condata)
#
#print condata.column_names()
#
##condata = condata.remove_column('X1')
#
#print condata.column_names()
# In[3]:

condata['pkphr'] = condata.apply(lambda x: int(x['Pickupdate'].split(' ')[1].split(':')[0]))
dayzero = datetime.strptime('01/01/2016','%d/%m/%Y')
timeformat2 = '%Y-%m-%d'
timeformat3 = '%d/%m/%y'
timeformat4 = '%d-%b-%y'
timeformat5 = '%d-%m-%Y'

def convertdate2(*vars):
    x = vars[0]
    flag = vars[1]
    timeformata = timeformat2
    timeformatb = timeformat3
    timeformatc = timeformat4
    timeformatd = timeformat5
    
    try:       
        x = x.split(' ')[0]
        return datetime.strptime(x,timeformata)
    except:
        try:
            x = x.split(' ')[0]
            return datetime.strptime(x,timeformatb)
        except:
            try:
                x = x.split(' ')[0]
                return datetime.strptime(x,timeformatc)
            except:
                try:
                    x = x.split(' ')[0]
                    return datetime.strptime(x,timeformatd)    
                except:
                    if flag=='today':
                        return datetime.today()
                    else:
                        return dayzero
condata['PickupDate'] = condata.apply(lambda x: convertdate2(x['Pickupdate'],'dayz'))


# In[4]:

#last 30 days short data
#shortdata = gl.SFrame.read_csv_with_errors(r'D:\Python\Scripts and Files\Path and Graph Files\Deps_data_201016.csv')
shortdata = gl.SFrame(r'http://spoton.co.in/downloads/IEP_DAMAGE_DATA_TO_SQ/IEP_DAMAGE_DATA_TO_SQ.csv')
shortdata.rename({'\xef\xbb\xbfDOCKNO': 'DOCKNO'})
print 'damage data columns', shortdata.column_names()


#shortdata = shortdata.rename({'\xef\xbb\xbfDOCKNO': 'DOCKNO'})

#including only bad POD Union as asked by Supratim
badpoddata = gl.SFrame(r'http://spoton.co.in/downloads/IE_BADPOD_DATA_TO_SQ/IE_BADPOD_DATA_TO_SQ.csv')

## To handle blanks in CSGECD. Edit on 27-02-2-17
badpoddata = badpoddata.fillna('CSGECD', 123456789)
## To handle blanks in CSGECD. Edit on 27-02-2-17

#badpoddata.rename({'\xef\xbb\xbfDOCKNO': 'DOCKNO'})

### Edit for renaming Code to CODE  on 12-12-2016
badpoddata.rename({'\xef\xbb\xbfDOCKNO': 'DOCKNO','CODE':'Code'})
### Edit for renaming Code to CODE  on 12-12-2016


badpoddata['CSGECD'] = badpoddata.apply(lambda x:int(x['CSGECD']))
badpoddata = badpoddata.remove_column('DEPS')

print 'badpod columns', badpoddata.column_types()

print 'shortdata columns', shortdata.column_types()


shortdata = shortdata.append(badpoddata)
#including only bad POD Union as asked by Supratim

#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
#cursor = cnxn.cursor()
#
#shortconquery = ("""
#        EXEC dbo.USP_DEPS_DATA_TO_SQ_IE
#        """)
#
#shortdatadf = pd.read_sql(shortconquery, cnxn)
##shortdatadf.to_csv(r'D:\Python\Scripts and Files\Path and Graph Files\Deps18Oct_test.csv')
#print 'shortdatadf',type(shortdatadf)

#shortdata = gl.SFrame(data=shortdatadf)
#
##shortdata = gl.SFrame.read_csv_with_errors(r'D:\Python\Scripts and Files\Path and Graph Files\Deps18Oct_test.csv')
##shortdata = gl.SFrame(r'D:\Python\Scripts and Files\Path and Graph Files\Deps18Oct_test.csv')
#print 'shortdata',type(shortdata)
#
#print shortdata.column_names()
#
##shortdata = shortdata.remove_column('X1')
#
#print shortdata.column_names()

#shortdata = shortdata[0]
shortdata.rename({'CapturedLocation': 'dest', 'COMING_FROM':'org'})


def daysdiff(a,b):
    return (a-b).days

shortdata['PickupDate'] = shortdata.apply(lambda x: convertdate2(x['DOCKDT'],'dayz'))
shortdata['statusdate'] = shortdata.apply(lambda x: convertdate2(x['ConStatusDate'],'dayz'))

#shiv will give data later#shortdata['resdate'] = shortdata.apply(lambda x: convertdate2(x['Resolution Date'],'today'))
#shiv will give data later#shortdata['days_to_res'] = shortdata.apply(lambda x: daysdiff(x['resdate'],x['statusdate']))
                                          
shortgrp = shortdata.groupby(['org','dest'],{'D_Con': agg.COUNT_DISTINCT('DOCKNO'),'D_Pcs': agg.SUM('PKGSNO')})


# In[5]:

datetoday = datetime.today().date()
yestrdy = datetoday-timedelta(days=1)
lastweek = datetoday-timedelta(days=7)

print shortdata['ConStatusDate'].unique
print shortdata['ConStatusDate'][0], shortdata['statusdate'][0], yestrdy
print type(shortdata['ConStatusDate'][0]), type(shortdata['statusdate'][0]), type(yestrdy)
# In[6]:

#yesterday short data
shortdata_yst = shortdata[shortdata['statusdate']==yestrdy]
shortgrp_yst = shortdata_yst.groupby(['org','dest'],{'D_Con_Y': agg.COUNT_DISTINCT('DOCKNO'),'D_Pcs_Y': agg.SUM('PKGSNO')})


# In[7]:

#last 7 days short data
shortdata_week = shortdata[shortdata['statusdate']>=lastweek]
shortgrp_week = shortdata_week.groupby(['org','dest'],{'D_Con_Wk': agg.COUNT_DISTINCT('DOCKNO'),'D_Pcs_Wk': agg.SUM('PKGSNO')})


# In[8]:

## weight = concount, length = piece count, label = month (removed)

def movementgraphops(path,pcs):
    path = path+str('-PUD')
    conpath = path.split('-')
    for step in range(0,len(conpath)-1):
        org = conpath[step]
        dest = conpath[step+1]
        if movementgraph.has_edge(org,dest):
            wt = movementgraph.get_edge_data(org,dest)['weight']
            pieces = movementgraph.get_edge_data(org,dest)['length']
            pieces = pcs+pieces
            movementgraph.add_edge(org,dest,weight =wt+1,length = pieces)
        else:
            movementgraph.add_edge(org,dest,weight =1, length = pcs)
    return 'done'


# In[9]:

movementmastersf = gl.SFrame({'org': ['test'], 'dest': ['test'], 'totalcon': [0], 'Pieces': [0]})
movementgraph = nx.DiGraph()
for cons in condata:
    movementgraphops(cons['OD_PATH'],cons['PKGSNO'])
movementdict = {}
for i in movementgraph.edges():
    wt = movementgraph.get_edge_data(i[0],i[1])['weight']
    pieces = movementgraph.get_edge_data(i[0],i[1])['length']
    movementdict.update({(i[0],i[1]):(wt,pieces)})
orgarray= gl.SArray(zip(*movementdict.keys())[0])
destarray= gl.SArray(zip(*movementdict.keys())[1])
wtarray = gl.SArray(zip(*movementdict.values())[0])
pcarray = gl.SArray(zip(*movementdict.values())[1])
movementsf = gl.SFrame({'org': orgarray, 'dest': destarray, 'totalcon': wtarray, 'Pieces': pcarray})


movementsf.save(r'D:\Python\Scripts and Files\Path and Graph Files\movementsf.csv')

movementmastersf = movementmastersf.append(movementsf)
movementmastersf.save(r'D:\Python\Scripts and Files\Path and Graph Files\movementmastersf.csv')

# In[10]:

shortgrp.save(r'D:\Python\Scripts and Files\Path and Graph Files\shortgrp.csv')
joinsf = movementmastersf.join(shortgrp, on = ['org','dest']) #default join is inner join
joinsf.save(r'D:\Python\Scripts and Files\Path and Graph Files\joinsf.csv')
joinsf1 = joinsf.join(shortgrp_week,on = ['org','dest'], how = 'left')
finalsf = joinsf1.join(shortgrp_yst,on = ['org','dest'], how = 'left')

finalsf = finalsf.fillna('D_Con_Wk', 0)
finalsf = finalsf.fillna('D_Con_Y', 0)


# In[11]:

finalsf


# In[12]:

finalsf['%'] = finalsf.apply(lambda x: round(x['D_Con']*100.0/x['totalcon'],2))
finalsf['%Wk'] = finalsf.apply(lambda x: round((x['D_Con_Wk']*100.0)/(x['totalcon']*7.0/29.0),2))
finalsf['%Y'] = finalsf.apply(lambda x: round((x['D_Con_Y']*100.0)/(x['totalcon']/29.0),2))


# In[14]:

finalsf = finalsf.sort_values([('D_Con',False),('%',False)])


# In[15]:

finalsf = finalsf['org','dest','totalcon','Pieces','D_Con','D_Pcs','D_Con_Wk','D_Pcs_Wk','D_Con_Y','D_Pcs_Y','%','%Wk','%Y']
#finalsf = finalsf['org','dest','totalcon','D_Con','D_Con_Wk','D_Con_Y','perc','perc_Wk','perc_Y']


# In[16]:
datetoday = datetime.today()
datefilter = datetoday-timedelta(hours=24)
datefilter=datefilter.date()
datefilter


#finalsf.save('finalsf_new.csv') #to write it into attachment + save it using ts
finaldf = finalsf.to_dataframe()

shortcons_30 = finaldf['D_Con'].sum()
shortcons_7 = finaldf['D_Con_Wk'].sum()
shortcons_y = finaldf['D_Con_Y'].sum()
totalcons = finaldf['totalcon'].sum()

shortperc_30 = pd.np.round((shortcons_30*1.0/totalcons)*100.0,2)
shortperc_7 = pd.np.round((shortcons_7*1.0/(totalcons*7.0/29.0))*100.0,2)
shortperc_y = pd.np.round((shortcons_y*1.0/(totalcons/29.0))*100.0,2)

#### Edit to change column names as per Jothi Mam's request
finaldf.rename(columns={'D_Con': 'D_Con_M', 'D_Con_Y': 'D_Con_dy','D_Pcs': 'D_Pcs_M', 'D_Pcs_Y': 'D_Pcs_dy','%':'%M','%Y':'%dy'}, inplace=True)

finalsf = finalsf.rename({'D_Con': 'D_Con_M', 'D_Con_Y': 'D_Con_dy','D_Pcs': 'D_Pcs_M', 'D_Pcs_Y': 'D_Pcs_dy','%':'%M','%Y':'%dy'})
#### Edit to change column names as per Jothi Mam's request
finaldf.loc[finaldf.index,'Date'] = datefilter

finaldf.to_csv(r'D:\Data\Damage_report\Damage_report_'+str(datefilter)+'.csv')
oppath1 = r'D:\Data\Damage_report\Damage_report_'+str(datefilter)+'.csv'
# In[17]:

#####$$$$ finalsf_mail = finalsf['org','dest','D_Con_M','D_Con_Wk','D_Con_dy','%','%Wk','%Y'] ## Before changing column names on 21112016
finalsf_mail = finalsf['org','dest','D_Con_M','D_Con_Wk','D_Con_dy','%M','%Wk','%dy']
finalsf_mail #mail body
finaldf_mail = finalsf_mail.to_dataframe().head(15)
#finaldf_mail.rename(columns={'org':'Origin'}, inplace=True)

finaldf_mail = finaldf_mail.to_string(index=False)



# In[ ]:
filePath = oppath1
def sendEmail(TO = ["sq_spot@spoton.co.in"],
             #TO = ["vishwas.j@spoton.co.in"],
             #BCC =  ["vishwas.j@spoton.co.in","shivananda.p@spoton.co.in"],
             CC =  ["sqtf@spoton.co.in"],
             #CC =  ["vishwas.j@spoton.co.in"],
             BCC =  ["mahesh.reddy@spoton.co.in"],
            #FROM="mis.ho@spoton.co.in"):
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
    #HOST = "smpt.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DEPOTWISE OPS Bucket Stock  - "+ str(datefilter)
    msg["Subject"] = "Damage Report - "+ str(datefilter)
    body_text = """
    Dear All,
    
    PFB the Damage Report as of """ + str(datefilter) +"""
    
    Overall reported Transhipment Damage %-ge for last 30 days = """ +str(shortperc_30)+""" %
    Overall reported Transhipment Damage %-ge for last 7 days = """ +str(shortperc_7)+""" %
    Overall reported Transhipment Damage %-ge for yesterday = """ +str(shortperc_y)+""" %
    
"""+str(finaldf_mail)+"""
     
    Note:
    D_Con_M : No of cons updated Damage status during last 30 days
    D_Con_Wk : No of cons updated Damage status during last 7 days
    D_Con_dy : No of cons updated Damage status yesterday
    
    """
    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    #server.login("mis.ho@spoton.co.in", "Mis@2019")
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
#print('Email sent')


