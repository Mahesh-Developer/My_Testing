
# coding: utf-8

# In[ ]:

import pandas.io.sql
import pandas as pd
import sys
import numpy as np
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta


# In[ ]:

# cnxn1 = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor1 = cnxn1.cursor()

cnxn1 = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor1 = cnxn1.cursor()


# In[ ]:

htrquery = ("""EXEC USP_HUB_THROUGHPUT_DETAILS_SALES_ONEHOUR""")
invdf = pd.read_sql(htrquery, Utilities.cnxn)
invdf.rename(columns={'Hub/SC Location':"Hub SC Location",'Arrival Date @ Hub':"Arrival Date Hub",'DestnBranch':"Destn Branch",'Act.WtInTonnes':"Act Wt In Tonnes",'LatestStatusCode':"Latest Status Code",'OriginArea':"Origin Area",'DestnArea':'Destn Area'},inplace=True)


# In[ ]:

stockquery1 = ("""SELECT     *
 
 
  FROM tblTimeConnectionReport_Undelivered_2HRS   
    WHERE ISDEPARTED_FRM_CURRLOC='YES'""")
print (stockquery1)

intransitdf=pd.read_sql(stockquery1,Utilities.cnxn)
intransitdf.rename(columns={'CDELDT':'DUE DATE','ORIGIN_BRCODE':'ORIGIN BRCODE','CURR_BRANCHCODE':'CURR BRANCHCODE','ISDEPARTED_FRM_CURRLOC':'IS DEPARTED FRM CURRLOC','DEPARTURE_TIME_FRM_CURLOC':'DEPARTURE TIME FRM CURLOC','DEPARTURE_TO_LOC_FRM_CURLOC':'DEPARTURE TO LOC FRM CURLOC','DEPARTED_FRM_CURRLOC_THCNO':'DEPARTED FRM CURRLOC THCNO','DEPARTED_FRM_CURRLOC_ROUTECD':'DEPARTED FRM CURRLOC ROUTECD','DEPARTED_FRM_CURRLOC_VEHNO':'DEPARTED FRM CURRLOC VEHNO','DOCKDT':'PICKUP DATE','LatestConStatusCode':'Latest Con Status Code','TCNO_FROM_HUB':'TCNO FROM HUB','THC_VENDOR_TYPE':'THC VENDOR TYPE','THC_SOURC':'THC SOURC','THC_DEST':'THC DEST','THC_ETA':'THC ETA','THC_ARRI_ENTRY':'THC ARRI ENTRY','THC_LAST_UPDATE_HR':'THC LAST UPDATE HR','THC_ROUTE_NAME':'THC ROUTE NAME','THC_LAST_TIME':'THC LAST TIME','ApptmntDelDate':'Apptmnt Del Date','TIME_STAMP':'TIMESTAMP'},inplace=True)


# In[ ]:

invdf['OD']=zip(invdf['Hub SC Location'],invdf['Destn Branch'])
import pickle
try:
    pkl_file = open(r'D:\Path Dict\path_dict.pkl', 'rb')
except:
    pkl_file = open(r'C:\Users\ankit\Dropbox\Python\testrest\Async2\Async2\path_dict.pkl', 'rb')
path_dict = pickle.load(pkl_file)
pkl_file.close()
invdf["Resid_Path"]=invdf['OD'].map(lambda x: path_dict.get((x[0],x[1]))[0] if path_dict.get((x[0],x[1]))!=None else [0,0])

def getNextLoc(pth,con):
    try:
        nxtloc=pth[1]
        return nxtloc
    except:
        return '-'
invdf['NextLoc']=invdf.apply(lambda x: getNextLoc(x['Resid_Path'],x['Con Number']),axis=1)

#invdf['NextLoc']=invdf['Resid_Path'].map(lambda x: x[1])
mergedf = pd.merge(invdf,intransitdf,left_on=['Con Number'], right_on=['DOCKNO'], how='inner')
invdf_correct=invdf[~invdf['Con Number'].isin(mergedf['Con Number'])]
invdf_correct['cooling']=(invdf_correct['TIMESTAMP']-invdf_correct['Arrival Date Hub'])/np.timedelta64(1,'h')
depspaperworkcodelist = ['SRE','SRD','SRS','SRP','DLP','SWP','PWS','HCM','HPM','MOP','SRH','HOC','ONR','SPH','SPO','DBO','DIP','SHS','SSC','HIP','RNX','APT','APN','SHD','SMT','SPL','MSH','UCG','RRA','HPE','WIA','UG1','UG2','UG3','HMP','HWC','NPE','HIM']
virtualhub=pd.read_excel(r'C:\Users\rajeeshv\Downloads\Virtual Hub.xlsx')
invdf_correct['OD']=invdf_correct.apply(lambda x:str(x['Hub SC Location'])+'-'+str(x['NextLoc']),axis=1)


# In[ ]:

amch_df=invdf_correct[(invdf_correct['Hub SC Location'].isin(['AMCH'])) & (invdf_correct['NextLoc'].isin(['SXRF']))]
#print (amch_df.columns)
amch_df["Delay_Hours"]=np.round((amch_df["TIMESTAMP"]-amch_df["Arrival Date Hub"])/np.timedelta64(1, 'h'),0)
amch_df= amch_df.assign(delaygrp=pd.cut(amch_df.Delay_Hours,bins=[-np.inf,24,48,96,np.inf],labels=['0-24','24-48','48-96','96+']))


# In[ ]:

amch_df['delaycat']=amch_df['delaygrp'].astype(str)
loadavailabledf=amch_df.pivot_table(index=['Hub SC Location','NextLoc'],columns=['delaycat'],aggfunc={'Act Wt In Tonnes':sum,'Con Number':len})
loadavailabledf=loadavailabledf.fillna(0)


# In[ ]:

loadavailabledf


# In[ ]:

loadavailabledf['Con Number']=loadavailabledf['Con Number'].astype(int)
loadavailabledf['Act Wt In Tonnes']=pd.np.round(loadavailabledf['Act Wt In Tonnes'],1)


# In[ ]:

type(loadavailabledf)


# In[ ]:

amch_df.to_csv(r'D:\Data\AMCH Loads\AMCH_Data.csv')
loadavailabledf.to_csv(r'D:\Data\AMCH Loads\AMCH_Loads_Summary.csv')


# In[ ]:

oppath1=r'D:\Data\AMCH Loads\AMCH_Data.csv'
oppath2=r'D:\Data\AMCH Loads\AMCH_Loads_Summary.csv'


# In[ ]:

reportts = datetime.now()
opfilevar=reportts.date()
opfilevar1=reportts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=pd.np.round((float(currhrs)/60),0)


# In[ ]:

import os


# In[ ]:

FROM='mis.ho@spoton.co.in'

TO=['onkar.sharma@spoton.co.in','avinash.singh@spoton.co.in']
CC=['rajesh.kumar@spoton.co.in','shivananda.p@spoton.co.in','mahesh.reddy@spoton.co.in','anitha.thyagarajan@spoton.co.in']

msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "AMCH Loads Report Srinagar-" + str(opfilevar)

report=""
report+='Dear All,'

report+='<br>'
report+='<br>'
report+= 'PFA Loads Summary'
report+='<br>'
report+='<br>'
report+='<br>'+loadavailabledf.to_html()+'<br>'

abc=MIMEText(report,'html')
msg.attach(abc)

part = MIMEBase('application', "octet-stream")
part.set_payload( open(oppath1,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
#msg.attach(part)

part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(oppath2,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath2))
#msg.attach(part1)


server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()


# In[ ]:



