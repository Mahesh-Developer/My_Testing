
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
from datetime import datetime
import pyodbc
import smtplib
import os
import ftplib
import traceback
import Utilities

# In[2]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")


# In[3]:


# query=("Security_Portal_SQ_Anitha '2018-04-01'")
query=("EXEC dbo.usp_Security_Portal_SQ '2018-04-01' ")


# In[4]:


df=pd.read_sql(query,Utilities.cnxn)


# In[5]:

df=df[df['Status']!='Close']
len(df)


# In[6]:


df=df[df['IncidentLoc']!='BLHO']


# In[7]:


len(df)


# In[8]:


df['Month']=df['CaseDate'].apply(lambda x : datetime.strftime(x,'%b'))


# In[9]:


cols=df['Month'].unique().tolist()
from datetime import datetime
days_sorted = sorted(cols, key=lambda day: datetime.strptime(day, "%b"))


# In[10]:


days_sorted


# In[11]:


months_list=[]
for i in days_sorted:
    months_list.append(('ConNo',i))


# In[13]:


months_list


# In[22]:


summary=df.pivot_table(index=[' Assigned To','Status'],columns=['Month'],values=['ConNo'],aggfunc={'ConNo':len}).fillna(0).reindex(columns=months_list)


# In[23]:


summary=summary.fillna(0)


# In[25]:
print (summary)

summary['ConNo']=summary['ConNo'].astype(int)


# In[24]:


summary['Total']=summary['ConNo'].sum(axis=1)


# In[26]:


depotdftots = summary.groupby(level=' Assigned To').sum()
depotdftots.index = [depotdftots.index, ['total'] * len(depotdftots)]
        


# In[27]:


depotdftots


# In[28]:


summary1 = np.round(pd.concat([summary,depotdftots]).sort_index().append(summary.sum().rename(('Grand', 'Total'))),2)


# In[29]:


summary1


# In[30]:


date=datetime.strftime(datetime.now(),'%Y-%m-%d')
date
df.to_csv(r'D:\Data\security_portal_report\Portal_Report_Data'+str(date)+'.csv')
df.to_csv(r'D:\Data\security_portal_report\Portal_Report_Data.csv')
filepath=r'D:\Data\security_portal_report\Portal_Report_Data.csv'

# In[31]:

print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = filepath
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

TO=['spot_security@spoton.co.in','SQ_SPOT@spoton.co.in']
# TO=['mahesh.reddy@spoton.co.in','anitha.thyagarajan@spoton.co.in']
FROM="mis.ho@spoton.co.in"
CC=['jothi.menon@spoton.co.in','anitha.thyagarajan@spoton.co.in','shivananda.p@spoton.co.in','mahesh.reddy@spoton.co.in']
# CC=['mahesh.reddy@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
msg["Subject"] = "Security Portal Report " + " : " + date
html='''<html>
<style>
p
{
  margin:0;
  margin-top: 5px;
  padding:0;
  font-size:17px;
    line-height:20px;
}
</style>
<h3>Dear All,</h3>
<p>Please Find POD's Summary.</p>
</html>'''


s = Template(html).safe_substitute()
report=""
#report+=s
#report+='<br>'+final_dff5.to_html()+'<br>'
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='Please Find the Security Portal Report Update :'
report+='<br>'
report+='<br>'+summary1.to_html()+'<br>'
report+='<br>'
html5='''
<h5> To download the data , Please click the link below </h5>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Portal_Report_Data.csv"</a>http://spoton.co.in/downloads/IEProjects/ETA/Portal_Report_Data.csv</p></b>
    '''
report+=html5
abc=MIMEText(report,'html')
msg.attach(abc)
# part = MIMEBase('application', "octet-stream")
# part.set_payload( open(filePath,"rb").read() )
# encoders.encode_base64(part)
# part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
# msg.attach(part)
# part1 = MIMEBase('application', "octet-stream")
# part1.set_payload( open(filePath1,"rb").read() )
# encoders.encode_base64(part1)
# part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath1))
# msg.attach(part1)

server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()

