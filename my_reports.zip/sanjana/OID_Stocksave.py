# -*- coding: utf-8 -*-
"""
Created on Tue Nov 24 12:53:55 2015

@author: rajeeshv
"""
import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
import calendar
import datetime
from pandas import ExcelWriter
import pyodbc
import Utilities

# openingstock = pd.io.excel.read_excel('http://10.109.230.50/downloads/OCID/OCID.xls','OPENING STOCK')
# incomingstock = pd.io.excel.read_excel('http://10.109.230.50/downloads/OCID/OCID.xls','INCOMING')
# delivered = pd.io.excel.read_excel('http://10.109.230.50/downloads/OCID/OCID.xls','DELIVERED')
# closingstock = pd.io.excel.read_excel('http://10.109.230.50/downloads/OCID/OCID.xls','CLOSING STOCK')

query = ("""
EXEC UBESP_PUD_ANALYSIS_OPEN_CLOSE_STOCK_ARRV_DELV_SSRS_OS
""")

openingstock=pd.read_sql(query, Utilities.cnxn)

query1 = ("""
EXEC UBESP_PUD_ANALYSIS_OPEN_CLOSE_STOCK_ARRV_DELV_SSRS_IN
""")

incomingstock=pd.read_sql(query1, Utilities.cnxn)

query2 = ("""
EXEC UBESP_PUD_ANALYSIS_OPEN_CLOSE_STOCK_ARRV_DELV_SSRS_DL
""")

delivered=pd.read_sql(query2, Utilities.cnxn)


query3 = ("""
EXEC UBESP_PUD_ANALYSIS_OPEN_CLOSE_STOCK_ARRV_DELV_SSRS_CS
""")


closingstock=pd.read_sql(query3, Utilities.cnxn)

print len(openingstock), len(incomingstock), len(delivered), len(closingstock)

openingstock.rename(columns={'CDELDT':'DUE DATE','DeliveryStatus': 'Delivery Status','REPORTDATE_MIN_ARRVDT':'REPORTDATE MIN ARRVDT','ConStatusCode':'Con Status Code','DEL_LOCATION_TYPE':'DEL LOCATION TYPE','DEST_BRCD':'DEST BRCD','DEST_AREA':'DEST AREA'},inplace=True)
incomingstock.rename(columns={'INC_ARRV_CATEGORY':'INC ARRV CATEGORY','ConStatusCode':'Con Status Code','DEL_LOCATION_TYPE':'DEL LOCATION TYPE','DEST_BRCD':'DEST BRCD','DEST_AREA':'DEST AREA'},inplace=True)
delivered.rename(columns={'CDELDT':'DUE DATE','DELY_DT':'DELY DT','ConStatusCode':'Con Status Code','DEL_LOCATION_TYPE':'DEL LOCATION TYPE','DEST_BRCD':'DEST BRCD','DEST_AREA':'DEST AREA'},inplace=True)
closingstock.rename(columns={ 'CDELDT':'DUE DATE','REPORTDATE_MIN_ARRVDT':'REPORTDATE MIN ARRVDT','IS_FREE_CON':'Is Free Con','ARRV_AT_DEST_SC':'ARRV AT DEST SC','ConStatusCategory':'Con Status Category','ConStatusCode':'Con Status Code','DEL_LOCATION_TYPE':'DEL LOCATION TYPE','DEST_BRCD':'DEST BRCD','DEST_AREA':'DEST AREA'},inplace=True)


datenow = date.today()
dateyest = datenow-timedelta(hours=24)
openingstock.loc[openingstock.index,'Timestamp'] = dateyest
incomingstock.loc[incomingstock.index,'Timestamp'] = dateyest
delivered.loc[delivered.index,'Timestamp'] = dateyest
closingstock.loc[closingstock.index,'Timestamp'] = dateyest

openingstock.to_csv(r'D:\\Data\\eta_rank\Destination_sc_openingstock\\Opening_Stock_'+str(dateyest)+'.csv')
print 'Opening stock saving done'
incomingstock.to_csv(r'D:\\Data\\eta_rank\Destination_sc_incoming\\Incoming_Stock_'+str(dateyest)+'.csv')
print 'Incoming saving done'
delivered.to_csv(r'D:\\Data\\eta_rank\Destination_sc_delivered\\Delivered_'+str(dateyest)+'.csv')
print 'Delivered saving done'
closingstock.to_csv(r'D:\\Data\\eta_rank\Destination_sc_closingstock\\Closing_Stock_'+str(dateyest)+'.csv')
print 'Closing saving done'