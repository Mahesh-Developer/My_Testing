
# coding: utf-8

# In[1]:

import pandas as pd
from datetime import datetime, timedelta, date
import numpy as np
import zipfile as zf
from urllib import urlopen
import io
from calendar import monthrange
from sqlalchemy import *
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template


try:
    engine = create_engine("mysql+pymysql://spotonhr:spoton54321@104.199.198.197/revenuebkg")



    startdate="'"+datetime.strftime((datetime.now()-timedelta(days=1)).replace(day=1),"%Y-%m-%d")+"'"
    enddate="'"+datetime.strftime(datetime.now(),"%Y-%m-%d")+"'"
    df = pd.read_sql("SELECT `PARENTNAME`,`AccountType`,`PICKUP_DATE`,`CUSTOMERCODE`,`CUSTOMER_SIGNED_AT_DEPOT`,`CUSTOMER_REGION`,`Actual_Weight`,`NetRev`,`ORG_REGION`,`DEST_REGION`,`Source_Branch`,`Destination_Branch`,`SaleDepott` FROM revenuebkg WHERE `PICKUP_DATE` >= {0} AND `PICKUP_DATE` < {1}".format(startdate,enddate),engine) 
    print (df.columns,df.dtypes)
    print (df.head())

    yeststart = datetime.combine((datetime.now()-timedelta(days=1)).date(), datetime.min.time())
    # blhdlist=[29910, 30784, 44929, 50163, 50592, 51306, 51558, 56105, 63465, 64858, 65139, 66235, 66788, 67313, 67514, 67862, 68027, 68029, 68031, 68032, 68033, 68034, 68035, 68036, 68037, 68038, 68039, 68040, 68041, 68042, 68043, 68044, 68045, 68046, 68047, 68048, 68049, 68051, 68052, 68055, 68058, 68060, 68061, 68062, 68063, 68064, 68065, 68066, 68067, 68069, 68077, 68078, 68080, 68081, 68082, 68084, 68085, 68087, 68089, 68093, 68094, 68095, 68096, 68098, 68099, 68101, 68102, 68103, 68104, 68105, 68106, 68107, 68108, 68111, 68113, 68114, 68115, 68116, 68117, 68118, 68119, 68120, 68121, 68122, 68123, 69950, 72155, 73084, 73085, 73086, 73087, 75818, 75954, 76360, 77029, 79107, 80663, 81244, 83074, 83579, 85314, 85315, 86387, 86782, 87167, 87201, 87205, 87206, 87207, 87208, 87209, 87210, 87211, 87212, 87213, 87296, 87297, 87298, 87338, 87340, 87342, 87356, 87437, 87854, 88131, 88165, 88489, 89425, 89824, 90150, 90187, 90203, 90642, 91124, 91125, 92325, 92569, 92570, 93450, 94560, 95302, 95657, 95658, 95659, 95660, 95662, 95663, 95664, 95665, 95666, 95667, 95668, 96045, 96119, 96297, 96307, 96333, 96334, 96725, 96828, 96970, 96971, 97174, 97175, 98464, 99041, 99393, 99394, 99551, 99707, 99708, 99709, 99710, 99804, 99813, 99814, 99815, 100226, 100227, 100228, 100229, 100230, 100231, 100232, 100233, 100234, 100235, 100374, 101109, 102557, 102956, 103064, 103348, 103914, 104374, 104375, 104376, 104377, 105974, 106156, 106415, 106657, 106658, 107495, 107923, 108058, 108083, 108274, 109003, 112951, 112952, 112953, 112954, 112955, 113823, 113824, 115924, 116216, 116615, 114288, 111617, 106472, 106625,108619]
    # df.loc[df["CUSTOMERCODE"].isin(blhdlist),['CUSTOMER_SIGNED_AT_DEPOT']]="BLHD"
    regcleandict = {'AHMEDABAD':'W', 'BENGALURU':'S', 'CHANDIGARH':'N','CHENNAI':'S', 'HEAD OFFICE':'H', 'HO TNT':'H','HYDERABAD':'S','INDORE':'W','KOLKATA':'E','MUMBAI':'W','NEW DELHI':'N','PUNE':'W','ROTN/KL':'S','UP':'N','UTTARAKHAND':'N'}
    df["Region"] = df["SaleDepott"].map(regcleandict)
    depocleandict = {'AHMEDABAD':'AMDD', 'BENGALURU':'BLRD', 'CHANDIGARH':'IXCD','CHENNAI':'MAAD', 'HEAD OFFICE':'BLHD', 'HO TNT':'BLHD','HYDERABAD':'HYDD','INDORE':'IDRD','KOLKATA':'CCUD','MUMBAI':'BOMD','NEW DELHI':'NCRD','PUNE':'PNQD','ROTN/KL':'RTKD','UP':'LKOD','UTTARAKHAND':'UKND'}
    df.replace({"SaleDepott":depocleandict},inplace=True)


    # In[30]:

    mtdrevenue = round(df["NetRev"].sum()*0.9645/100000.0,1)
    yestrevenue=round(df[df["PICKUP_DATE"]>=yeststart]["NetRev"].sum()*0.9645/100000.0,1)


    # In[31]:

    regpivot=np.round(df.pivot_table(index="ORG_REGION",columns="DEST_REGION",values=["NetRev"],aggfunc={"NetRev":lambda x: (x*0.9645/1e5).sum()*100.0/mtdrevenue},margins=True),1)
    regpivot.columns=pd.MultiIndex(levels=[[""],['All','E','N','S','W']],labels=[[0, 0, 0, 0, 0],[1, 2, 3, 4, 0]],names=[None,None])


    # In[32]:

    try:
        targetdf = pd.read_excel(r'C:\Users\rajeeshv\Downloads\revenue target.xlsx',sheetname=0,skiprows=3,index_col=0,parse_cols=range(0,monthrange(yeststart.year,yeststart.month)[1]+1)).T.rename_axis({'UP':'LKOD','UTTARAKHAND':'UKND','DELD':'NCRD'},axis=1)
        depotdf = df.pivot_table(index=["Region","SaleDepott"],values=["NetRev"],aggfunc={"NetRev":lambda x: (x*1.0/1e5).sum()},margins=False)
        depotdf = depotdf.rename_axis({'NetRev':'GrossRev'},axis=1)
        depotdf["Target"]=depotdf.apply(lambda x: targetdf.ix[0:yeststart.day,[x.name[1]]].values.sum()*1.0/0.9645,axis=1)
        depotdftots = depotdf.groupby(level='Region').sum()
        depotdftots.index = [depotdftots.index, [' Total'] * len(depotdftots)]
        depotpivot = np.round(pd.concat([depotdf,depotdftots]).sort_index().append(depotdf.sum().rename(('Grand', 'Total'))),2)
        depotpivot['%Ach']=depotpivot.apply(lambda x: round(x["GrossRev"]*100.0/x["Target"],1),axis=1)
        depotpivot['%Ach']=pd.np.round(depotpivot['%Ach'],1)

        yesttarget=round(targetdf.loc[yeststart,'Grand Total'],1)
        mtdtarget=round(targetdf.loc[yeststart,'Cumulative'],1)
    except:
        yesttarget='unavailable'
        mtdtarget = 'unavailable'
        depotdf=df.pivot_table(index=["Region","SaleDepott"],values=["NetRev"],aggfunc={"NetRev":lambda x: (x*1.0/1e5).sum()},margins=False)
        depotdf = depotdf.rename_axis({'NetRev':'GrossRev'},axis=1)
        depotdftots = depotdf.groupby(level='Region').sum()
        depotdftots.index = [depotdftots.index, ['Total'] * len(depotdftots)]
        depotpivot = np.round(pd.concat([depotdf,depotdftots]).sort_index().append(depotdf.sum().rename(('Grand', 'Total'))),2)

    depotpivot=depotpivot.replace([np.inf,-np.inf],np.nan).fillna(0)
    
    depotpivot.index.rename(['Region','Depot'],inplace=True)
    print (regpivot)
    print (depotpivot)

    # In[ ]:

    # import os
    # import smtplib
    # from email import Encoders
    # from email.MIMEBase import MIMEBase
    # from email.Utils import formatdate
    # from email.mime.text import MIMEText
    # from email import encoders
    # from email.MIMEMultipart import MIMEMultipart
    # from email.MIMEImage import MIMEImage

    #     msgText = MIMEText('Revenue for yesterday is Rs. <b>'+str(round(yestrevenue,2))+'</b> lakhs (Target Rs. '+str(yesttarget)+' lakhs @3.55% CN);<br>MTD Revenue is Rs. <b>'+str(mtdrevenue)+'</b> lakhs (Target Rs. '+str(mtdtarget)+' lakhs @3.55% CN); <br><br><b>A. MTD REGION TO REGION TRADING PATTERN (%)<b>'
    #                        +regpivot.to_html()+'<br><b>B. DEPOTWISE TRADING:<b>'+depotpivot.to_html(), 'html')

        
    #     msgAlternative.attach(msgText)
    #     
    from datetime import date,timedelta
    todate=date.today()
    today_date=datetime.strftime(todate,'%d-%m')
    today_date

    df.to_csv(r'D:\Data\Revenue Reports\Data\Revenue_Data_'+str(today_date)+'.csv')
    depotpivot.to_csv(r'D:\Data\Revenue Reports\Summaries\Depot_Summary_'+str(today_date)+'.csv')
    regpivot.to_csv(r'D:\Data\Revenue Reports\Summaries\Region_Summary_'+str(today_date)+'.csv')


    #TO=['vishwas.j@spoton.co.in','saptarshi.pathak@spoton.co.in','satya.pal@spoton.co.in']
    #TO=["Ankit@iepfunds.com",'vishwas.j@spoton.co.in','satya.pal@spoton.co.in']
    FROM="reports.ie@spoton.co.in"
    TO=['mahesh.reddy@spoton.co.in']
    CC=['mahesh.reddy@spoton.co.in']
    BCC=['mahesh.reddy@spoton.co.in']
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    msg["Subject"] = "Revenue Variance Report" + " - " + str(today_date)
    html='''<html>
    <style>
    p
    {
      margin:0;
      margin-top: 5px;
      padding:0;
      font-size:17px;
        line-height:20px;
    }
    </style>
    </html>'''

    report="Dear All,"
    report+='<br>'
    report+='<br>'
    report+="Revenue for yesterday is Rs. "+str(round(yestrevenue,2))+' lakhs (Target Rs. '+str(yesttarget)+' lakhs @3.55% CN)'
    report+='<br>'
    report+='<br>'
    report+="MTD Revenue is Rs. "+str(mtdrevenue)+' lakhs (Target Rs. '+str(mtdtarget)+' lakhs @3.55% CN)'
    report+='<br>'
    report+='<br>'
    report+='A. MTD REGION TO REGION TRADING PATTERN (%)'
    report+='<br>'
    report+='<br>'+regpivot.to_html()+'<br>'
    report+='<br>'
    report+='<br>'
    report+='DEPOTWISE TRADING:'
    report+='<br>'
    report+='<br>'+depotpivot.to_html()+'<br>'

    #report+=html3
    abc=MIMEText(report,'html')
    msg.attach(abc)
    # part = MIMEBase('application', "octet-stream")
    # part.set_payload( open(filepath,"rb").read() )
    # encoders.encode_base64(part)
    # part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
    # msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
    server.quit()

except:
  TO=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  #msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "Revenue Variance Report Error in Execution" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in Revenue Variance Report'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO, msg.as_string())
  server.quit()
