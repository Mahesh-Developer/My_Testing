
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import pyodbc
from IPython import display
from datetime import datetime
from datetime import datetime,timedelta
from datetime import datetime, timedelta
import smtplib
import ftplib
import traceback
import calendar
from fuzzywuzzy import fuzz,process
from fuzzywuzzy import fuzz
import os
# import Utilities


# In[2]:


todate=datetime.strftime(datetime.now(),'%Y-%m-%d')
todate


# In[3]:


cnxn =pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
cursor = cnxn.cursor()


# In[4]:


query=("""
SELECT A.DOCKNO,A.CSGECD,A.CSGNNM,A.CSGENM,A.CSGECD
FROM dbo.DOCKET A WITH (NOLOCK) 
LEFT OUTER JOIN dbo.TBLDocketEcomAmazon B WITH (NOLOCK) ON B.Dockno = A.DOCKNO
WHERE DOCKDT >= '2019-08-01'
AND B.Dockid IS NULL
""")


# In[5]:


df=pd.read_sql(query,cnxn)


# In[6]:


len(df)


# In[7]:


dff3=df
dff3.columns


# In[8]:


def fuzzyLogic(x):
    if x==None:
        return None
    elif (fuzz.partial_ratio('AMAZON'.lower(),x.lower()))>80:
#         v=fuzz.partial_ratio('Amazon'.lower(),x.lower())
        return "Amazon"
    elif (fuzz.partial_ratio('Cloudtail'.lower(),x.lower()))>80:
        return "CLOUDTAIL"
    else:
        return "Non-Amazon"


# In[9]:


dff3['Shipment Type']=dff3.apply(lambda x:fuzzyLogic(x['CSGENM']),axis=1)
dff3['CreatedOn']= todate
# dff3


# In[10]:


dff3.rename(columns={'DOCKNO':'Dockno'},inplace=True)
dff3['dockid'] = dff3.index


# In[12]:


fin=dff3[['dockid','Dockno','Shipment Type','CreatedOn']]
fin


# In[13]:


fin123=fin
fin123


# # INSERT INTO SQL #####

# In[14]:


import pandas as pd
import pyodbc
from sqlalchemy import create_engine


# In[15]:


check=('''
                select * from TBLDocketEcomAmazon
               
                ''')
one=pd.read_sql(check,cnxn)


# In[16]:


one


# In[17]:


for index,row in fin123.iterrows():
    q= (''' INSERT INTO TBLDocketEcomAmazon ([Dockno],[ShipmentType],[CreatedOn]) values ( '{0}','{1}','{2}')
    ''').format(row['Dockno'],row['Shipment Type'],row['CreatedOn'])
    cursor.execute (q)
    cnxn.commit()

cursor.close()
cnxn.close()


# In[18]:


cnxn =pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
cursor = cnxn.cursor()


# In[19]:


check2=('''
                select * from TBLDocketEcomAmazon
               
                ''')
TWO=pd.read_sql(check2,cnxn)


# In[20]:


TWO


# In[27]:


A= len(TWO) - len(one)


# In[31]:


def check():
    if A == len(fin123):
        return  "data transfer successful"
    else:
        return "total data transfer was not compeleted"
    


# In[32]:


check()


# In[29]:


if A == len(fin123):
    print( "data transfer successful")
else:
    print( "total data transfer was not compeleted")


# In[37]:


from glob import glob
from IPython import display
from datetime import datetime,timedelta
import pyodbc

# date=datetime.strftime(datetime.now()-timedelta(2),'%Y-%m-%d-%H')
date=datetime.strftime(datetime.now(),'%Y-%m-%d-%H')
date

# ----------- E M A I L --------------------------    
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template                    



TO = ['sanjana.narayana@spoton.co.in']
# CC=['anitha.thyagarajan@spoton.co.in']
FROM="sanjana.narayana@spoton.co.in"
BCC = ['sanjana.narayana@spoton.co.in']



msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
# msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = "amazon Data Transfer " + " - " + str(date)
html='''<html>
<style>        
p
 {
   margin:0;
   margin-top: 5px;
   padding:0;
   font-size:15px;
   line-height:20px;
 }
</style>                


'''
# html3='''
# <h5> To download File, Please click the link below </h5>
# <p><a href= http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/BA_TREND.xlsx </a>
# http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/BA_TREND.xlsx </p>
# '''
report=""
report+='<br>'
report+='Hey!'
report+='<br>'
report+=' Amazon Data transfer'
report+='<br>'
report+='<br>'
try:
    report+='<br>'+ check() +'<br>' 
                        
except:
     report+='ERROR in Amazon Data transfer'
    

report+='<br>'

abc=MIMEText(report,'html')
msg.attach(abc)
# part = MIMEBase('application', "octet-stream")
# part.set_payload( open(oppath1,"rb").read() )
# encoders.encode_base64(part)
# part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
# msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login('spoton.net.in', 'Star@123#')
failed = server.sendmail(FROM, 
                         BCC+
#                          CC+
                         TO, msg.as_string())
print ('mail sent')
server.quit()

