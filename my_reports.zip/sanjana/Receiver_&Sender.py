
# coding: utf-8

# In[ ]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta
import Utilities
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.MIMEBase import MIMEBase
from email import Encoders
import os

# In[ ]:

try:
    # cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")


    # In[ ]:


    import sys

    reload(sys).setdefaultencoding("ISO-8859-1")


    # In[ ]:


    # cursor=cnxn.cursor()


    # In[ ]:


    query=(""" SELECT  A.*, CASE WHEN ( CON_BLOCKED_FOR_PAY_ISSUES = 'YES' ) THEN 'A3_PAYMENT_ISSUE'  
                 WHEN ( ConStatusCode IN( 'SSC','SHS' )) THEN 'A4_Seized by Sales Tax'  
                 WHEN ( ConStatusCode IN ('UCG','UG1','UG2','UG3' )) THEN '8_UCG'  
                 WHEN (CON_BLOCKED_FOR_DEMURRAGE = 'YES' AND DEMURRAGE_RESPONSIBILITY = 'CS') THEN '2_CS Dem_Pin Drs Block'--'CS Dem Drs Block'  
                 WHEN (CON_BLOCKED_FOR_DEMURRAGE = 'YES' AND DEMURRAGE_RESPONSIBILITY = 'OPS' AND LatestTicketStatus != 'Open') THEN '5_OPS Dem Drs Block'  
                 WHEN (CON_BLOCKED_FOR_ODA_PIN_ISSUES =  'YES') THEN '2_CS Dem_Pin Drs Block' --'CS PIN DRS BLOCK'  
                 WHEN (REPORTDATE_MIN_ARRVDT > 1440 ) THEN 'A1_DEAD STOCK'  
                 WHEN (IsTTSTicketRaised = 'YES' AND LatestTicketStatus = 'CLOSED' AND LatestTicketStatusCode = ConStatusCode AND REPORTDATE_MIN_ARRVDT >= 40) THEN '3_OPS/Free Con Bucket-Old'  
                 WHEN (IsTTSTicketRaised = 'YES' AND LatestTicketStatus = 'CLOSED' AND LatestTicketStatusCode = ConStatusCode AND REPORTDATE_MIN_ARRVDT < 40) THEN '4_OPS/Free Con Bucket-NEW'  
                 WHEN (IS_FREE_CON_NEW = 'YES' AND REPORTDATE_MIN_ARRVDT >= 40) THEN '3_OPS/Free Con Bucket-Old'  
                 WHEN (IS_FREE_CON_NEW = 'YES' AND REPORTDATE_MIN_ARRVDT < 40) THEN '4_OPS/Free Con Bucket-New'  
                 WHEN (IsTTSTicketRaised = 'YES' AND LatestTicketStatus = 'OPEN') THEN '1_CS Bucket'  
                 WHEN (ConStatusCategory = 'DEPS' AND REPORTDATE_MIN_ARRVDT > 168 ) THEN '9_DEPS-SQ'  
                 WHEN (ConStatusCategory = 'DEPS' AND REPORTDATE_MIN_ARRVDT <= 168 ) THEN '6_DEPS-OPS'  
                 WHEN (ConStatusCategory IN ( 'RECEIVER FAILURE','SENDER FAILURE') )THEN 'A2_CCF without Tickets'   
                 ELSE '7_Others/Timelag'             
            END STATUS1   
    FROM    dbo.tblOCIDClosingStock A  
    WHERE   LogDate >= CONVERT(DATE,GETDATE()-0)  
    """)


    # In[ ]:


    data=pd.read_sql(query,Utilities.cnxn)


    # In[ ]:


    len(data)


    # In[ ]:


    filter1 = ['RECEIVER FAILURE','SENDER FAILURE']


    # In[ ]:


    afdata = data[data['ConStatusCategory'].isin(filter1)]


    # In[ ]:


    # len(data1)


    # In[ ]:


    agdata = afdata[afdata['ConStatusCode']!='UCG']


    # In[ ]:


    len(agdata)


    # In[ ]:


    filter2 = ['8_UCG','A1_DEAD STOCK']


    # In[ ]:


    btdata = agdata[~agdata['STATUS1'].isin(filter2)]


    # In[ ]:


    len(btdata)


    # In[ ]:


    pivot1=pd.pivot_table(btdata,index=["PARENTNAME"],columns=["DEST_AREA"],values=["DOCKNO"],aggfunc={"DOCKNO":len},fill_value=0,margins=True)


    # In[ ]:


    pivot1.head(5)


    # In[ ]:


    pivot2=pd.pivot_table(btdata,index=["ConStatusDesc"],columns=["DEST_AREA"],values=["DOCKNO"],aggfunc={"DOCKNO":len},fill_value=0,margins=True)


    # In[ ]:


    pivot2.head(5)


    # In[ ]:


    pivot3 = pd.pivot_table(btdata,index=["DEST_AREA"],columns=["STATUS1"],values=["DOCKNO"],aggfunc={"DOCKNO":len},fill_value=0,margins=True)


    # In[ ]:


    pivot3.head(5)


    # In[ ]:


    from pandas import ExcelWriter


    # In[ ]:


    with ExcelWriter(r'D:\Data\ODA_Loads_Ton_wise\Sender_Receiver.xlsx') as writer:
           pivot1.to_excel(writer, sheet_name='Parent_customerwise',engine='xlsxwriter')
           pivot2.to_excel(writer, sheet_name='Status_code wise',engine='xlsxwriter')
           pivot3.to_excel(writer, sheet_name='DRS blocked',engine='xlsxwriter')
           btdata.to_excel(writer, sheet_name='Data',engine='xlsxwriter')


    # In[ ]:


    filepath=r'D:\Data\ODA_Loads_Ton_wise\Due_date_cons.xlsx'


    # In[ ]:


    import numpy as np
    import pandas as pd
    import itertools
    import json
    from pandas import ExcelWriter
    from pandas import pivot_table
    from datetime import datetime
    import os
    import ftplib
    import traceback

    oppath1=filepath
    #FTP Upload starts
    print ('Logging in...')
    ftp = ftplib.FTP()  
    ftp.connect('10.109.230.50')  
    print (ftp.getwelcome())
    try:  
        try:  
            ftp.login('HOSQTeam', 'Te@mH0$q')
            print ('login done')
            ftp.cwd('Auto_reports')  
            #ftp.cwd('FIFO')
            # move to the desired upload directory  
            print ("Currently in:", ftp.pwd()) 
            print ('Uploading...')  
            fullname = oppath1
            name = os.path.split(fullname)[1]  
            f = open(fullname, "rb")  
            ftp.storbinary('STOR ' + name, f)  
            f.close()  
            print ("OK"  )
            print ("Files:")  
            print (ftp.retrlines('LIST'))
        finally:  
            print ("Quitting...")
            ftp.quit()  
    except:  
        traceback.print_exc()


    # In[ ]:




    from_addr = 'mis.ho@spoton.co.in'
    to_addr = ['shivananda.p@spoton.co.in','jothi.menon@spoton.co.in']
    #to_addr = ['rajesh.mp@spoton.co.in','vishwas.j@spoton.co.in']
    #cc_addr = ['banusanketh484@gmail.com']
    # cc_addr = ['shivananda.p@spoton.co.in']
    bcc_addr = ['sreedhar.m@spoton.co.in','anitha.thyagarajan@spoton.co.in']

    username = 'mis.ho@spoton.co.in'
    password = 'Mis@2019'

    msg = MIMEMultipart()

    msg['From'] = from_addr
    msg['To'] = ', '.join(to_addr)
    msg['bcc'] = ', '.join(bcc_addr)
    msg['Subject'] = 'Receiver & sender cons.'
    html='''<html>
    <h4>Dear All,PFA </h4>
    <p> " Receiver & Sender cons" details.</p>
    </html>'''

    html1='''<h5>Thanks & Regards</h5></b>
    <h5>HO-SQ</h5>'''

    # part10=MIMEText(html1,'html')
    #  <h5>Rajesh M P </h5></b>
    # msg.attach(part10)
    html3='''
    <h5> To download the Cons Details of "Receiver & Failure", Please click the link below </h5>
    <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Sender_receiver.xlsx"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Sender_receiver.xlsx</p></b>
    '''

    report=""
    report+=html
    report+='<br>'
    report+=html3
    report+='<br>'
    report+=html1
    abc=MIMEText(report,'html')
    msg.attach(abc)

    
    part=MIMEBase('application','octet-stream')
    # for attachment insted of link
    # part.set_payload(open(filepath,'rb').read())
    # Encoders.encode_base64(part)
    # part.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath))
    # msg.attach(part)


    # server = smtplib.SMTP('smtp.spoton.co.in',587)
    # server.ehlo()
    # server.starttls()
    # server.ehlo()
    # server.login('mis.ho@spoton.co.in','Mis@2019')
    # server.sendmail(from_addr,to_addr+bcc_addr,msg.as_string())
    # print ('mail sent succesfully')
    # server.quit()


    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(from_addr,to_addr+bcc_addr, msg.as_string())
    print ('mail sent succesfully')
    server.quit()
    
except:

  TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in'] 
  CC=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "Receiver & sender cons. Error in Execution" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in Receiver & sender cons.'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO+CC, msg.as_string())
  server.quit()


