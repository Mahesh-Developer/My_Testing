
# coding: utf-8

# In[1]:

import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
import Utilities

# In[2]:

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()

# In[3]:

query=("""EXEC USP_EWAYBILL_MOTIONCONS_MGMT_SQ""")
print (query)

# In[4]:

df=pd.read_sql(query,Utilities.cnxn)

ewbna=df[(df['IS_EWAYBILL_REQUIRE']=="YES")&(df['IS_EWAYBILL_AVLB']=="NO")]
# In[5]:

partbewbna=df[(df['IS_EWAYBILL_REQUIRE']=="YES")&(df['IS_EWAYBILL_AVLB']=="YES")&(df['IS_UPDATED']=='NO')]
df1=df[df['IS_EWAYBILL_REQUIRE']!='NO']
final_pivot=pd.pivot_table(df1,index=['TYPE'],columns=['IS_EWAYBILL_REQUIRE','IS_UPDATED'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True)

# In[13]:

hubtohub=df[df['TYPE']=='HUB-HUB']
len(hubtohub)


# In[14]:

ewbntavb_hub=hubtohub[(hubtohub['IS_EWAYBILL_REQUIRE']=='YES')&(hubtohub['IS_EWAYBILL_AVLB']=="NO")]
len(ewbntavb_hub)


# In[15]:

hubtohubewnnt=ewbntavb_hub.pivot_table(index=['TCBR'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True)


# In[16]:

hubtohubewnnt=hubtohubewnnt.sort_values(by='DOCKNO',ascending=False)


# In[17]:

hubtohubewnnt


# In[18]:

ewbpartntavb_hub=hubtohub[(hubtohub['IS_EWAYBILL_REQUIRE']=='YES')&(hubtohub['IS_EWAYBILL_AVLB']=='YES')&(hubtohub['IS_UPDATED']=="NO")]


# In[19]:

len(ewbpartntavb_hub)


# In[20]:

ewbpartnthubtohub=ewbpartntavb_hub.pivot_table(index=['TCBR'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True)


# In[21]:

ewbpartnthubtohub=ewbpartnthubtohub.sort_values(by='DOCKNO',ascending=False)


# In[22]:

ewbpartnthubtohub


# In[23]:

hubtosc=df[df['TYPE']=='HUB-SC']
len(hubtosc)


# In[24]:

ewbntavb_hubtosc=hubtosc[(hubtosc['IS_EWAYBILL_REQUIRE']=='YES')&(hubtosc['IS_EWAYBILL_AVLB']=="NO")]
len(ewbntavb_hubtosc)


# In[25]:

pivot_hubtoscewbnt=pd.pivot_table(ewbntavb_hubtosc,index=['TCBR'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True)


# In[26]:

pivot_hubtoscewbnt=pivot_hubtoscewbnt.sort_values(by='DOCKNO',ascending=False)


# In[27]:

ewbpartbntavb_hubtosc=hubtosc[(hubtosc['IS_EWAYBILL_REQUIRE']=='YES')&(hubtosc['IS_EWAYBILL_AVLB']=='YES')&(hubtosc['IS_UPDATED']=="NO")]


# In[28]:

pivot_hubtoscewbpartbnt=pd.pivot_table(ewbpartbntavb_hubtosc,index=['TCBR'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True)


# In[29]:

pivot_hubtoscewbpartbnt=pivot_hubtoscewbpartbnt.sort_values(by='DOCKNO',ascending=False)


# In[30]:

sctohub=df[df['TYPE']=='SC-HUB']
len(sctohub)


# In[31]:

ewbntavb_sctohub=sctohub[(sctohub['IS_EWAYBILL_REQUIRE']=='YES')&(sctohub['IS_EWAYBILL_AVLB']=="NO")]
len(ewbntavb_sctohub)


# In[32]:

pivot_sctohubewbnt=pd.pivot_table(ewbntavb_sctohub,index=['TCBR'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True)


# In[33]:

pivot_sctohubewbnt=pivot_sctohubewbnt.sort_values(by='DOCKNO',ascending=False)


# In[34]:

ewbpartbntavb_sctohub=sctohub[(sctohub['IS_EWAYBILL_REQUIRE']=='YES')&(sctohub['IS_EWAYBILL_AVLB']=='YES')&(sctohub['IS_UPDATED']=="NO")]


# In[35]:

pivot_sctohubewbpartbnt=pd.pivot_table(ewbpartbntavb_sctohub,index=['TCBR'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True)


# In[36]:

pivot_sctohubewbpartbnt=pivot_sctohubewbpartbnt.sort_values(by='DOCKNO',ascending=False)


# In[37]:

sctosc=df[df['TYPE']=='SC-SC']
len(sctosc)


# In[38]:

ewbntavb_sctosc=sctosc[(sctosc['IS_EWAYBILL_REQUIRE']=='YES')&(sctosc['IS_EWAYBILL_AVLB']=="NO")]
len(ewbntavb_sctosc)


# In[39]:

pivot_sctoscewbnt=pd.pivot_table(ewbntavb_sctosc,index=['TCBR'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True)


# In[40]:

ewbpartbntavb_sctosc=sctosc[(sctosc['IS_EWAYBILL_REQUIRE']=='YES')&(sctosc['IS_EWAYBILL_AVLB']=='YES')&(sctosc['IS_UPDATED']=="NO")]


# In[41]:

pivot_sctoscewbpartbnt=pd.pivot_table(ewbpartbntavb_sctosc,index=['TCBR'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True)


# In[42]:

pivot_sctoscewbpartbnt=pivot_sctoscewbpartbnt.sort_values(by='DOCKNO',ascending=False)


# In[43]:


reportts = datetime.now()
opfilevar=reportts.date()
opfilevar1=reportts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=pd.np.round((float(currhrs)/60),0)


# In[44]:


ewbna.to_csv(r'D:\Data\Ewaybill\Cons Booked\EWB_Cons_Booked_Not_available_Data'+str(opfilevar)+'_'+str(opfilevar2)+'.csv')
partbewbna.to_csv(r'D:\Data\Ewaybill\Cons Booked\EWB_Cons_Booked_PartB_Not_updated_Data'+str(opfilevar)+'_'+str(opfilevar2)+'.csv')


ewbna.to_csv(r'D:\Data\Ewaybill\Cons Booked\EWB_Cons_Booked_Not_available_Data.csv')
partbewbna.to_csv(r'D:\Data\Ewaybill\Cons Booked\EWB_Cons_Booked_PartB_Not_updated_Data.csv')


oppath1 = r'D:\Data\Ewaybill\Cons Booked\EWB_Cons_Booked_Not_available_Data.csv'
oppath2 = r'D:\Data\Ewaybill\Cons Booked\EWB_Cons_Booked_PartB_Not_updated_Data.csv'


# In[45]:


for i in [oppath1,oppath2]:
    import numpy as np
    import pandas as pd
    import itertools
    import json
    from pandas import ExcelWriter
    from pandas import pivot_table
    from datetime import datetime
    import os
    import ftplib
    import traceback

    oppath1=i
    #FTP Upload starts
    print ('Logging in...')
    ftp = ftplib.FTP()  
    ftp.connect('10.109.230.50')  
    print (ftp.getwelcome())
    try:  
        try:  
            ftp.login('HOSQTeam', 'Te@mH0$q')
            print ('login done')
            ftp.cwd('Auto_reports')  
            #ftp.cwd('FIFO')
            # move to the desired upload directory  
            print ("Currently in:", ftp.pwd()) 
            print ('Uploading...')  
            fullname = oppath1
            name = os.path.split(fullname)[1]  
            f = open(fullname, "rb")  
            ftp.storbinary('STOR ' + name, f)  
            f.close()  
            print ("OK"  )
            print ("Files:")  
            print (ftp.retrlines('LIST'))
        finally:  
            print ("Quitting...")
            ftp.quit()  
    except:  
        traceback.print_exc()


# In[46]:

ewbill_req_count=df[df['IS_EWAYBILL_REQUIRE']=='YES']
len(ewbill_req_count)


# In[47]:


ewbill_avlb_count=df[(df['IS_EWAYBILL_REQUIRE']=='YES') & (df['IS_EWAYBILL_AVLB']=='YES')]
#print (ewb_na['IS_EWAYBILL_AVLB'].unique())
print (len(ewbill_avlb_count))


# In[48]:

ewbill_notavlb_count=df[(df['IS_EWAYBILL_REQUIRE']=='YES') &(df['IsExempted']=='N')& (df['IS_EWAYBILL_AVLB']=='NO')]
len(ewbill_notavlb_count)


# In[49]:

ewbill_PARTB_updt_count=df[(df['IS_EWAYBILL_REQUIRE']=='YES') & (df['IS_EWAYBILL_AVLB']=='YES')&(df['IS_UPDATED']=='YES')]
len(ewbill_PARTB_updt_count)


# In[50]:

ewbill_PARTB_notupdt_count=df[(df['IS_EWAYBILL_REQUIRE']=='YES') &(df['IsExempted']=='N')& (df['IS_EWAYBILL_AVLB']=='YES')&(df['IS_UPDATED']=='NO')]
len(ewbill_PARTB_notupdt_count)


# In[76]:

s=(len(ewbill_notavlb_count))
s1=(len(ewbill_req_count))


# In[62]:

per_ewb_not_avlb=((len(ewbill_notavlb_count)/len(ewbill_req_count))*100.0)
per_ewb_not_avlb=pd.np.round(per_ewb_not_avlb,1)

per_ewb_not_avlb


# In[60]:

per_ewb_partb_nt_updt=(len(ewbill_PARTB_notupdt_count)/len(ewbill_req_count)*100.0)
per_ewb_partb_nt_updt=pd.np.round(per_ewb_partb_nt_updt,1)


# In[61]:

per_ewb_partb_nt_updt


# In[ ]:

exit(0)
FROM='mis.ho@spoton.co.in'

TO=["dom_spot@spoton.co.in","rom_spot@spoton.co.in","sq_spot@spoton.co.in","aom_spot@spoton.co.in",'scincharge_spot@spoton.co.in',"hubmgr_spot@spoton.co.in","cnm@spoton.co.in"]
CC=['sqtf@spoton.co.in','rajesh.kapase@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in','shashvat.suhane@spoton.co.in','gireesh.kumar@spoton.co.in','ajesh.c@spoton.co.in','devakumar.d@spoton.co.in','shejeer.b@spoton.co.in']


msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "Ewaybill Compliance Report for Cons In Motion -" + str(opfilevar)+"-"+str(opfilevar2)
html3='''
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EWB_Cons_Booked_Not_available_Data.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EWB_Cons_Booked_Not_available_Data.csv</p></b>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EWB_Cons_Booked_PartB_Not_updated_Data.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EWB_Cons_Booked_PartB_Not_updated_Data.csv</p></b>
'''
report=""
report+='Dear All,'

report+='<br>'
report+='Total Cons = '+str(len(df))
report+='<br>'
report+= 'Cons in Motion where Ewaybill required = '+str(len(ewbill_req_count))
report+='<br>'
report+= 'Cons in Motion where Ewaybill Available = '+str(len(ewbill_avlb_count))
report+='<br>'
report+= 'Cons in Motion where Ewaybill Not Available = '+str(len(ewbill_notavlb_count))
report+='<br>'
report+= 'Cons in Motion where Ewaybill Part B Updated = '+str(len(ewbill_PARTB_updt_count))
report+='<br>'
report+= 'Cons in Motion where Ewaybill Part B Not Updated = '+str(len(ewbill_PARTB_notupdt_count))
report+='<br>'
report+='NOTE: Download the Attachment from the Below link'
report+='<br>'
report+='<br>'
report+='Final Summary'
report+='<br>'+final_pivot.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='HUB-HUB'
report+='<br>'
report+='EwayBill Not Available'
report+='<br>'
report+='<br>'+hubtohubewnnt.to_html()+'<br>'
report+='<br>'
report+='EwayBill PartB Not Updated'
report+='<br>'
report+='<br>'+ewbpartnthubtohub.to_html()+'<br>'
report+='<br>'

report+='HUB-SC'
report+='<br>'
report+='EwayBill Not Available'
report+='<br>'
report+='<br>'+pivot_hubtoscewbnt.to_html()+'<br>'
report+='<br>'
report+='EwayBill PartB Not Updated'
report+='<br>'
report+='<br>'+pivot_hubtoscewbpartbnt.to_html()+'<br>'
report+='<br>'

report+='SC-HUB'
report+='<br>'
report+='EwayBill Not Available'
report+='<br>'
report+='<br>'+pivot_sctohubewbnt.to_html()+'<br>'
report+='<br>'
report+='EwayBill PartB Not Updated'
report+='<br>'+pivot_sctohubewbpartbnt.to_html()+'<br>'
report+='<br>'

report+='SC-SC'
report+='<br>'
report+='EwayBill Not Available'
report+='<br>'
report+='<br>'+pivot_sctoscewbnt.to_html()+'<br>'
report+='<br>'
report+='EwayBill PartB Not Updated'
report+='<br>'+pivot_sctoscewbpartbnt.to_html()+'<br>'
report+='<br>'



report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)

part = MIMEBase('application', "octet-stream")
part.set_payload( open(oppath1,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
#msg.attach(part)

part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(oppath2,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath2))
#msg.attach(part1)


server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()




# In[ ]:



