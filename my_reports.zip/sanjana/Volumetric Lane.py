
import pandas as pd
import pandas.io.sql
import sys
from datetime import datetime,timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import smtplib
cnxn_estl = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
intransitquery = ("""SELECT * FROM tblTimeConnectionReport_Undelivered_2HRS WHERE ISDEPARTED_FRM_CURRLOC='YES' """)
intransitdf = pd.read_sql(intransitquery, cnxn_estl)
print (len(intransitdf))
vol=intransitdf[intransitdf['DEPARTED_FRM_CURRLOC_ROUTECD']=='U2273']
print (len(vol))
vol['AdjstWt']=pd.np.round(pd.np.maximum(vol['ACTUAL_WEIGHT'],vol['VOLUME']*5.5),2)
vol['Stat']=pd.np.where(vol['ACTUAL_WEIGHT']==vol['AdjstWt'],'Dense','Volumetric')
grp=vol.pivot_table(index=['DEPARTED_FRM_CURRLOC_THCNO','Stat'],aggfunc={'ACTUAL_WEIGHT':sum,'VOLUME':sum}).reset_index()
grp['Vehicle Vol']=2650
grp['%']=pd.np.round(grp['VOLUME']/grp['Vehicle Vol']*100,2)
todate=datetime.strftime(datetime.now(),"%Y-%m-%d")

TO=['pawan.sharma@spoton.co.in','prasanna.hegde@spoton.co.in','ramachandran.p@spoton.co.in','satya.pal@spoton.co.in',"shashvat.suhane@spoton.co.in"]
# TO=['abhik.mitra@spoton.co.in','alok.b@spoton.co.in','satya.pal@spoton.co.in','banusanketh.dc@spoton.co.in']
CC=['mahesh.reddy@spoton.co.in']

FROM='reports.ie@spoton.co.in'
msg = MIMEMultipart()
msg["From"] = FROM
msg["TO"] = ",".join(TO)
msg["CC"] = ",".join(CC)

msg["Subject"] = "Volumetric Lane "+ '- ' + str(todate)

report=""
report+='Dear All,'

report+='<br>'
report+='<br>'
report+='PFB the concentration of consignment in Volumetric lane'
report+='<br>'
report+='<br>'
report+='<br>'+grp.to_html()+'<br>'



abc=MIMEText(report,'html')
msg.attach(abc)
# part1 = MIMEBase('application', "octet-stream")
# part1.set_payload( open(filepath,"rb").read() )
# encoders.encode_base64(part1)
# part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
# msg.attach(part1)



#msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, CC+TO, msg.as_string())
server.quit()


