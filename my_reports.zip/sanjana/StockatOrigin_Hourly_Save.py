# -*- coding: utf-8 -*-
"""
Created on Mon Feb 01 09:12:30 2016

@author: rajeeshv
"""


# coding: utf-8

# In[1]:

import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
import calendar
import datetime
from pandas import ExcelWriter


# In[7]:
originstock = pd.read_csv('http://10.109.230.50/downloads/IEProjects/STOCKOrigin/StockOrigin.csv')

datetimenow = datetime.datetime.now()

opfilevar=datetimenow.date()
opfilevar1=datetimenow.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=np.round((float(currhrs)/60),0)


originstock.to_csv(r'D:\Data\Stock_at_origin_hourly\Origin_Hourly_Stock_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv', encoding="utf-8")


# In[ ]:



