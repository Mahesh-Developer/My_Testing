
# coding: utf-8

# In[ ]:

from lhplanning import lhplanning
import numpy as np
import pandas as pd

from glob import glob
from IPython import display
from datetime import datetime,timedelta
import pyodbc
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
import smtplib
import ftplib
import traceback
import calendar
import os
import Utilities


# In[ ]:

#t1=pd.read_csv('TCdata.csv')


# In[ ]:

startdate=datetime.strftime(datetime.now()-timedelta(7),'%Y-%m-%d')+' 00:00:00'
startdate


# In[ ]:

enddate=datetime.strftime(datetime.now(),'%Y-%m-%d')+' 10:30:00'
enddate


# In[ ]:

query=("""SELECT  DISTINCT TH.thcno ,

        TH.thcdt ,

        TH.routety ,

        TH.sourcehb ,

        TH.tobh_code ,

        TH.routecd ,

        TH.routename ,

        TH.scharrv_dt + ' ' + TH.scharrv_tm ScheArr ,

        TH.actarrv_dt + ' ' + TH.actarrv_tm ActArr ,

        TH.sehedept_dt + ' ' + TH.schedept_tm ScheDept ,

        TH.actdept_dt + ' ' + TH.actdept_tm ActDept ,

        VH.VEHTONS   ,

        TH.ld_actuwt

FROM    dbo.THCHDR TH WITH ( NOLOCK )

        INNER JOIN dbo.THC_SUMMARY TC WITH ( NOLOCK ) ON TC.thcno = TH.thcno

        LEFT OUTER JOIN dbo.VEHMAS VH WITH ( NOLOCK ) ON VH.VEHNO = TH.vehno

                                                         AND VH.ROUTECD = TH.routecd

WHERE   TC.thcdt BETWEEN '2018-09-23 00:00:00'

                 AND     '2018-09-23 23:59:00'

       -- AND TC.thcno = 'STBLRHX0063943'

        AND TH.routety <> 'D'

ORDER BY TH.thcno ,

        TH.thcdt""").format(startdate,enddate)


# In[ ]:

#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")


# In[ ]:

t1=pd.read_sql(query,Utilities.cnxn)


# In[ ]:

len(t1)


# In[ ]:

t1['ScheArr']=pd.to_datetime(t1['ScheArr'])


# In[ ]:

t1['ScheDept']=pd.to_datetime(t1['ScheDept'])


# In[ ]:

t1['ActDept']=pd.to_datetime(t1['ActDept'])


# In[ ]:

t1['ActArr']=pd.to_datetime(t1['ActArr'])


# In[ ]:

t1['ActArr-ActDept']=(t1['ActDept']-t1['ActArr']).astype('timedelta64[m]')


# In[ ]:

t1['ActArr-ActDept']=t1['ActArr-ActDept']/60


# In[ ]:

t1['scheArr-actArr']=(t1['ActArr']-t1['ScheArr']).astype('timedelta64[m]')


# In[ ]:

t1['scheArr-actArr']=t1['scheArr-actArr']/60


# In[ ]:

t1['ScheArr-ScheDept']=(t1['ScheDept']-t1['ScheArr']).astype('timedelta64[m]')


# In[ ]:

t1['ScheArr-ScheDept']=t1['ScheArr-ScheDept']/60


# In[ ]:

def a(source,route):
    if source==route.replace(' ','').split('-')[0]:
        return 'O'
    elif source==route.replace(' ','').split('-')[-1]:
        return 'D'
    else:
        return 'I'


# In[ ]:

t1['stat']=t1.apply(lambda x:a(x['sourcehb'],x['routename']),axis=1)


# In[ ]:

t1['Destination']=t1.routename.map(lambda x:x.replace(' ','').split('-')[-1])


# In[ ]:

t1


# In[ ]:

t2=t1[t1['stat']=='I']


# In[ ]:

t2


# In[ ]:

t3=t2.sort_values(['ActArr-ActDept'],ascending=False)


# In[ ]:

t3


# In[ ]:

t3=t3[pd.np.isfinite(t3['ActArr-ActDept'])]


# In[ ]:

t3=t3[pd.np.isfinite(t3['ScheArr-ScheDept'])]


# In[ ]:

t3


# In[ ]:

t3=t3.sort_values(['ScheArr-ScheDept'],ascending=False)


# In[ ]:

def d(schArrschDept):
    if schArrschDept<0:
        return schArrschDept+12
    else:
        return schArrschDept


# In[ ]:

t3['ScheArr-ScheDept']=t3.apply(lambda x:d(x['ScheArr-ScheDept']),axis=1)


# In[ ]:

t3=t3.sort_values(['ScheArr-ScheDept'],ascending=False)


# In[ ]:

def e(schArrschDept):
    if schArrschDept<0:
        return schArrschDept+12
    else:
        return schArrschDept


# In[ ]:

t3['ScheArr-ScheDept']=t3.apply(lambda x:e(x['ScheArr-ScheDept']),axis=1)


# In[ ]:

def f(schArrschDept):
    if schArrschDept>9:
        return 12-schArrschDept
    else:
        return schArrschDept


# In[ ]:

t3['ScheArr-ScheDept']=t3.apply(lambda x:f(x['ScheArr-ScheDept']),axis=1)


# In[ ]:

t3


# In[ ]:

def b(ActArrActDept):
    if ActArrActDept<0:
        return ActArrActDept+12
    else:
        return ActArrActDept


# In[ ]:

t3['ActArr-ActDept']=t3.apply(lambda x:b(x['ActArr-ActDept']),axis=1)


# In[ ]:

def c(ActArrActDept):
    if ActArrActDept<0:
        return ActArrActDept+12
    else:
        return ActArrActDept


# In[ ]:

t3['ActArr-ActDept']=t3.apply(lambda x:c(x['ActArr-ActDept']),axis=1)


# In[ ]:

t4=t3[t3['ActArr-ActDept']>0]


# In[ ]:

t4=t4.sort_values(['ScheArr-ScheDept'],ascending=False)


# In[ ]:

t4


# In[ ]:

pivot_Act=t4.pivot_table(index=['sourcehb'],values=['ActArr-ActDept'],aggfunc={'ActArr-ActDept':pd.np.mean}).reset_index()


# In[ ]:

pivot_Act=pivot_Act.sort_values(['ActArr-ActDept'],ascending=False)


# In[ ]:

pivot_Act


# In[ ]:

pivot_Sch=t4.pivot_table(index=['sourcehb'],values=['ScheArr-ScheDept'],aggfunc={'ScheArr-ScheDept':pd.np.mean}).reset_index()


# In[ ]:

pivot_source=pd.merge(pivot_Act,pivot_Sch, on='sourcehb')


# In[ ]:

pivot_source


# In[ ]:

pivot_source.rename(columns={'sourcehb':'BRCD'},inplace=True)


# In[ ]:

pivot_source


# In[ ]:

t5=pd.read_csv(r'C:\Users\rajeeshv\Downloads\BA_PUD Touching Location details.csv')


# In[ ]:

t51=t5[~t5['BRCD'].isin(pivot_source['BRCD'])]


# In[ ]:

t51


# In[ ]:

t6=pd.merge(t5,pivot_source, on='BRCD')


# In[ ]:

t7=t6.sort_values(['ActArr-ActDept'],ascending=False)


# In[ ]:

t7.rename(columns={'ActArr-ActDept':'Actual Handling time(Hrs)'},inplace=True)


# In[ ]:

t7.rename(columns={'ScheArr-ScheDept':'Scheduled Handling time(Hrs)'},inplace=True)


# In[ ]:

t8=t7[['BRCD','BRNM','BR_TYPE','Actual Handling time(Hrs)','Scheduled Handling time(Hrs)']]


# In[ ]:

t8


# In[ ]:

t8['Time difference(Hrs)']=(t8['Actual Handling time(Hrs)']-t8['Scheduled Handling time(Hrs)'])


# In[ ]:

t8


# In[ ]:

t9=t8.sort_values(['Time difference(Hrs)'],ascending=False)


# In[ ]:

t9['Actual Handling time(Hrs)']=pd.np.round(t9['Actual Handling time(Hrs)'],1)
t9['Scheduled Handling time(Hrs)']=pd.np.round(t9['Scheduled Handling time(Hrs)'],1)
t9['Time difference(Hrs)']=pd.np.round(t9['Time difference(Hrs)'],1)


# In[ ]:

t10=t9[t9['Time difference(Hrs)']>=1]


# In[ ]:

reportts = datetime.now()
opfilevar=reportts.date()
opfilevar1=reportts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60
opfilevar2=np.round((float(currhrs)/60),0)

h1=pd.read_sql(query,Utilities.cnxn)


# In[4]:

len(h1)


# In[5]:

h1['ScheArr']=pd.to_datetime(h1['ScheArr'])


# In[6]:

h1['ScheDept']=pd.to_datetime(h1['ScheDept'])


# In[7]:

h1['ActDept']=pd.to_datetime(h1['ActDept'])


# In[8]:

h1['ActArr']=pd.to_datetime(h1['ActArr'])


# In[9]:

h1['ActArr-ActDept']=(h1['ActDept']-h1['ActArr']).astype('timedelta64[m]')


# In[10]:

h1['ActArr-ActDept']=h1['ActArr-ActDept']/60


# In[11]:

h1['scheArr-actArr']=(h1['ActArr']-h1['ScheArr']).astype('timedelta64[m]')


# In[12]:

h1['scheArr-actArr']=h1['scheArr-actArr']/60


# In[13]:

h1['ScheArr-ScheDept']=(h1['ScheDept']-h1['ScheArr']).astype('timedelta64[m]')


# In[14]:

h1['ScheArr-ScheDept']=h1['ScheArr-ScheDept']/60


# In[15]:

def a(source,route):
    if source==route.replace(' ','').split('-')[0]:
        return 'O'
    elif source==route.replace(' ','').split('-')[-1]:
        return 'D'
    else:
        return 'I'


# In[16]:

h1['stat']=h1.apply(lambda x:a(x['sourcehb'],x['routename']),axis=1)


# In[17]:

h1['Destination']=h1.routename.map(lambda x:x.replace(' ','').split('-')[-1])


# In[18]:

h1


# In[19]:

h2=h1[h1['stat']=='I']


# In[20]:

h2


# In[21]:

h3=h2.sort_values(['ActArr-ActDept'],ascending=False)


# In[22]:

h3


# In[23]:

h3=h3[pd.np.isfinite(h3['ActArr-ActDept'])]


# In[24]:

h3=h3[pd.np.isfinite(h3['ScheArr-ScheDept'])]


# In[25]:

h3


# In[26]:

h3=h3.sort_values(['ScheArr-ScheDept'],ascending=False)


# In[27]:

def d(schArrschDept):
    if schArrschDept<0:
        return schArrschDept+12
    else:
        return schArrschDept


# In[28]:

h3['ScheArr-ScheDept']=h3.apply(lambda x:d(x['ScheArr-ScheDept']),axis=1)


# In[29]:

h3=h3.sort_values(['ScheArr-ScheDept'],ascending=False)


# In[30]:

def e(schArrschDept):
    if schArrschDept<0:
        return schArrschDept+12
    else:
        return schArrschDept


# In[31]:

h3['ScheArr-ScheDept']=h3.apply(lambda x:e(x['ScheArr-ScheDept']),axis=1)


# In[32]:

def f(schArrschDept):
    if schArrschDept>9:
        return 12-schArrschDept
    else:
        return schArrschDept


# In[33]:

h3['ScheArr-ScheDept']=h3.apply(lambda x:f(x['ScheArr-ScheDept']),axis=1)


# In[34]:

h3


# In[35]:

def b(ActArrActDept):
    if ActArrActDept<0:
        return ActArrActDept+12
    else:
        return ActArrActDept


# In[36]:

h3['ActArr-ActDept']=h3.apply(lambda x:b(x['ActArr-ActDept']),axis=1)


# In[37]:

def c(ActArrActDept):
    if ActArrActDept<0:
        return ActArrActDept+12
    else:
        return ActArrActDept


# In[38]:

h3['ActArr-ActDept']=h3.apply(lambda x:c(x['ActArr-ActDept']),axis=1)


# In[39]:

h4=h3[h3['ActArr-ActDept']>0]


# In[40]:

h4=h4.sort_values(['ScheArr-ScheDept'],ascending=False)


# In[41]:

h4


# In[42]:

pivot_Act=h4.pivot_table(index=['sourcehb'],values=['ActArr-ActDept'],aggfunc={'ActArr-ActDept':pd.np.mean}).reset_index()


# In[43]:

pivot_Act=pivot_Act.sort_values(['ActArr-ActDept'],ascending=False)


# In[44]:

pivot_Act


# In[45]:

pivot_Sch=h4.pivot_table(index=['sourcehb'],values=['ScheArr-ScheDept'],aggfunc={'ScheArr-ScheDept':pd.np.mean}).reset_index()


# In[46]:

pivot_source=pd.merge(pivot_Act,pivot_Sch, on='sourcehb')


# In[47]:

pivot_source


# In[48]:

pivot_source.rename(columns={'sourcehb':'Touching Hub'},inplace=True)


# In[49]:

h6=pivot_source


# In[50]:

h6


# In[51]:

h7=h6.sort_values(['ActArr-ActDept'],ascending=False)


# In[52]:

h7.rename(columns={'ActArr-ActDept':'Actual Handling time(Hrs)'},inplace=True)


# In[53]:

h7.rename(columns={'ScheArr-ScheDept':'Scheduled Handling time(Hrs)'},inplace=True)


# In[54]:

h7['Time difference(Hrs)']=(h7['Actual Handling time(Hrs)']-h7['Scheduled Handling time(Hrs)'])


# In[55]:

h7['Hub/SC']=h7['Touching Hub'].apply(lambda x:x[-1])


# In[56]:

h7


# In[57]:

h8=h7[h7['Hub/SC']=='H']


# In[58]:

h8=h8.sort_values(['Time difference(Hrs)'],ascending=False)


# In[59]:

h8


# In[60]:

h9=h8[h8['Time difference(Hrs)']>=1]


# In[61]:

h9['Actual Handling time(Hrs)']=pd.np.round(h9['Actual Handling time(Hrs)'],1)
h9['Scheduled Handling time(Hrs)']=pd.np.round(h9['Scheduled Handling time(Hrs)'],1)
h9['Time difference(Hrs)']=pd.np.round(h9['Time difference(Hrs)'],1)
# In[62]:

s1=pd.read_sql(query,Utilities.cnxn)


# In[63]:

len(s1)


# In[64]:

s1['ScheArr']=pd.to_datetime(s1['ScheArr'])


# In[65]:

s1['ScheDept']=pd.to_datetime(s1['ScheDept'])


# In[66]:

s1['ActDept']=pd.to_datetime(s1['ActDept'])


# In[67]:

s1['ActArr']=pd.to_datetime(s1['ActArr'])


# In[68]:

s1['ActArr-ActDept']=(s1['ActDept']-s1['ActArr']).astype('timedelta64[m]')


# In[69]:

s1['ActArr-ActDept']=s1['ActArr-ActDept']/60


# In[70]:

s1['scheArr-actArr']=(s1['ActArr']-s1['ScheArr']).astype('timedelta64[m]')


# In[71]:

s1['scheArr-actArr']=s1['scheArr-actArr']/60


# In[72]:

s1['ScheArr-ScheDept']=(s1['ScheDept']-s1['ScheArr']).astype('timedelta64[m]')


# In[73]:

s1['ScheArr-ScheDept']=s1['ScheArr-ScheDept']/60


# In[74]:

def a(source,route):
    if source==route.replace(' ','').split('-')[0]:
        return 'O'
    elif source==route.replace(' ','').split('-')[-1]:
        return 'D'
    else:
        return 'I'


# In[75]:

s1['stat']=s1.apply(lambda x:a(x['sourcehb'],x['routename']),axis=1)


# In[76]:

s1['Destination']=s1.routename.map(lambda x:x.replace(' ','').split('-')[-1])


# In[77]:

s2=s1[s1['stat']=='I']


# In[78]:

s3=s2.sort_values(['ActArr-ActDept'],ascending=False)


# In[79]:

s3=s3[pd.np.isfinite(s3['ActArr-ActDept'])]


# In[80]:

s3=s3[pd.np.isfinite(s3['ScheArr-ScheDept'])]


# In[81]:

s3=s3.sort_values(['ScheArr-ScheDept'],ascending=False)


# In[82]:

def d(schArrschDept):
    if schArrschDept<0:
        return schArrschDept+12
    else:
        return schArrschDept


# In[83]:

s3['ScheArr-ScheDept']=s3.apply(lambda x:d(x['ScheArr-ScheDept']),axis=1)


# In[84]:

s3=s3.sort_values(['ScheArr-ScheDept'],ascending=False)


# In[85]:

def e(schArrschDept):
    if schArrschDept<0:
        return schArrschDept+12
    else:
        return schArrschDept


# In[86]:

s3['ScheArr-ScheDept']=s3.apply(lambda x:e(x['ScheArr-ScheDept']),axis=1)


# In[87]:

def f(schArrschDept):
    if schArrschDept>9:
        return 12-schArrschDept
    else:
        return schArrschDept


# In[88]:

s3['ScheArr-ScheDept']=s3.apply(lambda x:f(x['ScheArr-ScheDept']),axis=1)


# In[89]:

def b(ActArrActDept):
    if ActArrActDept<0:
        return ActArrActDept+12
    else:
        return ActArrActDept


# In[90]:

s3['ActArr-ActDept']=s3.apply(lambda x:b(x['ActArr-ActDept']),axis=1)


# In[91]:

def c(ActArrActDept):
    if ActArrActDept<0:
        return ActArrActDept+12
    else:
        return ActArrActDept


# In[92]:

s3['ActArr-ActDept']=s3.apply(lambda x:c(x['ActArr-ActDept']),axis=1)


# In[93]:

s4=s3[s3['ActArr-ActDept']>0]


# In[94]:

s4=s4.sort_values(['ScheArr-ScheDept'],ascending=False)


# In[ ]:

pivot_Act=s4.pivot_table(index=['sourcehb'],values=['ActArr-ActDept'],aggfunc={'ActArr-ActDept':pd.np.mean}).reset_index()


# In[ ]:

pivot_Act=pivot_Act.sort_values(['ActArr-ActDept'],ascending=False)


# In[ ]:

pivot_Sch=s4.pivot_table(index=['sourcehb'],values=['ScheArr-ScheDept'],aggfunc={'ScheArr-ScheDept':pd.np.mean}).reset_index()


# In[ ]:

pivot_source=pd.merge(pivot_Act,pivot_Sch, on='sourcehb')


# In[ ]:

pivot_source.rename(columns={'sourcehb':'Touching Hub'},inplace=True)


# In[ ]:

s6=pivot_source


# In[ ]:

s7=s6.sort_values(['ActArr-ActDept'],ascending=False)


# In[ ]:

s7.rename(columns={'ActArr-ActDept':'Actual Handling time(Hrs)'},inplace=True)


# In[ ]:

s7.rename(columns={'ScheArr-ScheDept':'Scheduled Handling time(Hrs)'},inplace=True)


# In[ ]:

s7['Time difference(Hrs)']=(s7['Actual Handling time(Hrs)']-s7['Scheduled Handling time(Hrs)'])


# In[ ]:

s7['Hub/SC']=s7['Touching Hub'].apply(lambda x:x[-1])


# In[ ]:

s7.rename(columns={'Touching Hub':'BRCD'},inplace=True)


# In[ ]:

s8=pd.read_csv(r'C:\Users\rajeeshv\Downloads\BA_PUD Touching Location details.csv')


# In[ ]:

s9=s7[~s7['BRCD'].isin(s8['BRCD'])]


# In[ ]:

s9=s9[s9['Hub/SC']!='H']


# In[ ]:

s9=s9.sort_values(['Time difference(Hrs)'],ascending=False)


# In[ ]:

s10=s9[s9['Time difference(Hrs)']>=1]


# In[ ]:

s10=s10[['BRCD','Actual Handling time(Hrs)','Scheduled Handling time(Hrs)','Time difference(Hrs)']]
s10['Actual Handling time(Hrs)']=pd.np.round(s10['Actual Handling time(Hrs)'],1)
s10['Scheduled Handling time(Hrs)']=pd.np.round(s10['Scheduled Handling time(Hrs)'],1)

# In[ ]:

t9.to_csv(r'D:\Data\DelayInTransit\BA_Handling_Delay'+str(opfilevar)+'.csv')
t9.to_csv(r'D:\Data\DelayInTransit\BA_Handling_Delay.csv')


# In[ ]:

filepath=r'D:\Data\DelayInTransit\BA_Handling_Delay.csv'


# In[ ]:

# In[52]:
TO=['raghavendra.rao@spoton.co.in','cnm@spoton.co.in','HUBMGR_SPOT@spoton.co.in','ashok.dwivedi@spoton.co.in','kamlesh.sharma@spoton.co.in','sqtf@spoton.co.in','AOM_SPOT@spoton.co.in','DOM_SPOT@spoton.co.in','ROM_SPOT@spoton.co.in']
CC=['pawan.sharma@spoton.co.in','satya.pal@spoton.co.in','mahesh.reddy@spoton.co.in','shashvat.suhane@spoton.co.in','saptarshi.pathak@spoton.co.in']
#TO=['mahesh.reddy@spoton.co.in','rajesh.kapase@spoton.co.in','praveen.cv@spoton.co.in','ganesh.raut@spoton.co.in']
#CC=['mahesh.reddy@spoton.co.in']
#CC=['saptarshi.pathak@spoton.co.in']
FROM="reports.ie@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = " Handling Delay for BA/PUD Locations, Hubs & Service Centres " + '- ' + str(opfilevar)+str('-')+ str(opfilevar2)
html3='''
<h5> To download the data , Please click the link below </h5>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Hub_Perfor_Data.csv"</a>http://spoton.co.in/downloads/IEProjects/ETA/Hub_Perfor_Data.csv</p></b>

'''
report=""
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='Please find the following report on the average(Last 7 days) handling delay. '
report+='<br>'
report+='<br>'
report+='The defaulters listed in this  delay report can be considered as consistent defaulters for  the past 7 days.'
report+='<br>'
report+='<br>'
report+='<br>'+t10.to_html()+'<br>'
report+='PFA The Hub Handling Delay .'
report+='<br>'
report+='<br>'
report+='<br>'+h9.to_html()+'<br>'
report+='PFA The SC Handling Delay .'
report+='<br>'
report+='<br>'
report+='<br>'+s10.to_html()+'<br>'
report+='<br>'
report+='<br>'


abc=MIMEText(report,'html')
msg.attach(abc)

part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)



server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()


# In[ ]:



