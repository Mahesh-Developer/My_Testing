# -*- coding: utf-8 -*-
"""
Created on Wed Sep 07 16:21:28 2016

@author: rajeeshv
"""
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import os

recipients = ["vishwas.j@spoton.co.in","rajeesh.vr@spoton.co.in"]
#recipients = ["vishwas.j@spoton.co.in"]
sender = "reports.ie@spoton.co.in"
subject = "Change Reports ID password"
body = """

The password of reports.ie@spoton.co.in will expire in next 4 days.Change the password now

"""

# make up message
msg = MIMEText(body)
msg['Subject'] = subject
msg['From'] = sender
msg['To'] = ", ".join(recipients)

# sending
session = smtplib.SMTP('smtp.spoton.co.in', 587)
session.starttls()
session.login(sender, 'Reports@2019')
send_it = session.sendmail(sender, recipients, msg.as_string())