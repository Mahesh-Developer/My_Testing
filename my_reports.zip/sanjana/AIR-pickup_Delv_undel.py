
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import pyodbc
from IPython import display
from datetime import datetime
from datetime import datetime,timedelta
from datetime import datetime, timedelta
import smtplib
import ftplib
import traceback
import calendar
import os
import Utilities
try:
    
    
    
    
    # In[2]:
    
    
    cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=SQTeam;PWD=eSp0T@321$Sq")
    cursor = cnxn.cursor()
    
    
    # In[5]:
    
    
    yest=datetime.now()-timedelta(0)
    enddate=yest.date()
    enddate=str(enddate)
    enddate
    
    
    # In[11]:
    
    
    Squery=(""" EXEC USP_stock_delv_SQ_AIR_Anitha '2019-04-01' """).format(enddate)
    Dquery= ("""      SELECT  A.DOCKNO ,

        DOCKDT ,

        A.CDELDT ,

        LM.PinCode ,

        RGALPH ,

        DEPOT_CODE ,

        ControlArea ,

        ORGNCD ,

        BRNM ,

        REASSIGN_DESTCD ,

        B.[Customer Code] ,

        [Customer Name] ,

        ACTUWT ,

        CASE WHEN (dd.DOCKNO IS NOT NULL ) THEN DD.DELY_DT 

        WHEN (fs.DOCKNO IS NOT NULL) THEN fs.FIN_STATUSDATE END DELY_DATE

FROM    dbo.DOCKET A WITH ( NOLOCK )

        LEFT OUTER JOIN dbo.tblLocationMst LM ON A.OrgnLocID = LM.LocationID

        LEFT OUTER JOIN dbo.Con_BalanceSheet_Sales B ON A.DOCKNO = B.[Con Number]

                    --INNER JOIN dbo.Con_BalanceSheet_Element C ON a.DOCKNO = c.[Con Number]

        LEFT OUTER JOIN dbo.brms D ON ORGNCD = BRCD

        LEFT OUTER JOIN dbo.DKT_DELY DD WITH ( NOLOCK ) ON A.DOCKNO = DD.DOCKNO

        LEFT OUTER JOIN dbo.tblDocketFinalStatus FS WITH ( NOLOCK ) ON A.DOCKNO = FS.DOCKNO

WHERE   DOCKDT BETWEEN '2019-04-01' AND GETDATE()

        AND PAYBAS <> 6

        AND A.ProductID = 2

        --AND A.DOCKNO = '600006405'

ORDER BY A.DOCKDT
    """).format(enddate)
    
    
    # In[12]:
    
    
    summaryQ=pd.read_sql(Squery,Utilities.cnxn)
    DataQ=pd.read_sql(Dquery,Utilities.cnxn)
    
    
    
    summaryQ
    
    
    # In[17]:
    
    
    # DataQ
    
    
    # In[19]:
    
    
    DataQ.to_csv(r'D:\Data\undel_mgt_air\Undel_Sanjana\AIR-pickup_Delv_undel_Data'+str(enddate)+'.csv')
    DataQ.to_csv(r'D:\Data\undel_mgt_air\Undel_Sanjana\AIR-pickup_Delv_undel_DATA.csv')
    
    
    # In[24]:
    
    
    import numpy as np
    import pandas as pd
    import itertools
    import json
    from pandas import ExcelWriter
    from pandas import pivot_table
    from datetime import datetime
    import os
    import ftplib
    import traceback
    from glob import glob
    from IPython import display
    from datetime import datetime,timedelta
    import pyodbc
    
    date=datetime.strftime(datetime.now(),'%Y-%m-%d-%H')
    
    
    filepath=(r'D:\Data\undel_mgt_air\Undel_Sanjana\AIR-pickup_Delv_undel_DATA.csv')
    
    oppath1=filepath
    #FTP Upload starts
    print ('Logging in...')
    ftp = ftplib.FTP()  
    ftp.connect('10.109.230.50')  
    print (ftp.getwelcome())
    
    try:
     try:
         ftp.login('HOSQTeam', 'Te@mH0$q')
         print ('login done')
         ftp.cwd('Auto_reports')
         #ftp.cwd('FIFO')
         # move to the desired upload directory
         print ("Currently in:", ftp.pwd())
         print ('Uploading...')
         fullname = oppath1
         name = os.path.split(fullname)[1]
         f = open(fullname, "rb")
         ftp.storbinary('STOR ' + name, f)
         f.close()
         print ("OK"  )
         print ("Files:")
         print (ftp.retrlines('LIST'))
     finally:
         print ("Quitting...")
         ftp.quit()
    except:
        traceback.print_exc()
        
    #date=datetime.strftime(datetime.now(),'%Y-%m-%d %H:%M:%S')
    
    
    # ----------- E M A I L --------------------------    
    import smtplib
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    from email.mime.base import MIMEBase
    from email import encoders
    import os
    from string import Template                    
    
    
    TO=['jothi.menon@spoton.co.in','baskar.t@spoton.co.in']
    # TO=['mahesh.reddy@spoton.co.in']
    FROM="anitha.thyagarajan@spoton.co.in"
    BCC = ['anitha.thyagarajan@spoton.co.in']
    
    CC = ['shivananda.p@spoton.co.in','sanjana.narayana@spoton.co.in']
    # CC = ['sanjana.narayana@spoton.co.in']
    
    
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    msg["Subject"] = "Air Pickup/ Delivered/ Undel -Report" + " - " + str(date)
    html='''<html>
    <style>        
    p
     {
       margin:0;
       margin-top: 5px;
       padding:0;
       font-size:15px;
       line-height:20px;
     }
    </style>                
    
    
    '''
    html3='''
    <h5> To download File, Please click the link below </h5>
    <p><a href= http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/AIR-pickup_Delv_undel_DATA.csv </a>
    http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/AIR-pickup_Delv_undel_DATA.csv </p>
    '''
    report=""
    report+='<br>'
    report+='Dear All,'
    report+='<br>'
    report+='Please find below Air-Pickup/ Delivered/ Undel -Report:'
    report+='<br>'
    report+='<br>'
    report+='<br>'+summaryQ.to_html()+'<br>'
    report+='<br>'
    report+='<br>'
    report+=html
    report+=html3
    abc=MIMEText(report,'html')
    msg.attach(abc)
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(oppath1,"rb").read() )
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login('spoton.net.in', 'Star@123#')
    failed = server.sendmail(FROM, 
                             TO+
                             CC+
                             BCC, msg.as_string())
    print ('mail sent')
    server.quit()

except:
    from glob import glob
    from IPython import display
    from datetime import datetime,timedelta
    import pyodbc
    
    date=datetime.strftime(datetime.now(),'%Y-%m-%d-%H')
    
    
    ##################### EMAIL ########################
    
    import smtplib
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    from email.mime.base import MIMEBase
    from email import encoders
    import os
    from string import Template                    
    
    
    
    TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in']
    # TO=['sanjana.narayana@spoton.co.in']
    FROM="mis.ho@spoton.co.in"
    # CC = ['sanjana.narayana@spoton.co.in']
    
    
    BCC = ['sanjana.narayana@spoton.co.in']
    
    
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    # msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    msg["Subject"] = " ***ERROR*** IN SENDING REPORT :Air Pickup/ Delivered/ Undel -Report " + " - " + str(date)
    html='''<html>
    <style>        
    p
     {
       margin:0;
       margin-top: 5px;
       padding:0;
       font-size:15px;
       line-height:20px;
     }
    </style>                
    
    
     '''
    # html3='''
    # <h5> To download File, Please click the link below </h5>
    # <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/APT_DE_"+str(today)+".xlsx"</a>
    # "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/APT_DE.xlsx"</p>
    # '''
    report=""
    report+='<br>'
    report+='Hello,'
    report+='<br>'
    report+='<br>'
    report+=' Please CHECK, ERROR IN SENDING EMAIL.'
    report+='<br>'
    report+='<br>'
    report+=' REPORT NAME: Air Pickup/ Delivered/ Undel -Report  '
    report+='<br>'
    report+='<br>'
    report+='<br>'
    report+='<br>'
    report+='<br>'
    report+='<br>'
    
    # report+=html
    abc=MIMEText(report,'html')
    msg.attach(abc)
    part = MIMEBase('application', "octet-stream")
    # part.set_payload( open(oppath1,"rb").read() )
    # encoders.encode_base64(part)
    # part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
    # msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login('spoton.net.in', 'Star@123#')
    failed = server.sendmail(FROM, TO+BCC, msg.as_string())
    print ('ERROR ***** mail sent')
    server.quit()
