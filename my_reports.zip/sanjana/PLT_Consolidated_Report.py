
# coding: utf-8

# In[1]:

import pandas.io.sql
import pandas as pd
import sys
import numpy as np
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
import smtplib
import ftplib
import traceback
import calendar
import os


# In[2]:

#Shortagedata2018-06-12-0.csv

#try:
yestdate=datetime.strftime(datetime.now()-timedelta(1),'%Y-%m-%d')
yestdate


# In[3]:

df = pd.DataFrame()
list_ = []
for i in range(0,24):
    filename=r'D:\Data\PLT Shortage\Shortagedata'+str(yestdate)+'-'+str(i)+'.csv'
    print (filename)
    try:
        df = pd.read_csv(filename)
        list_.append(df)
    except:
        print ('file not found')
df = pd.concat(list_)


# In[4]:

len(df)


# In[5]:

df=df.fillna(0)


# In[6]:

hubtohubdf=df[df['BRTYPE']=='HUB - HUB']
len(hubtohubdf)


# In[7]:

try:
    hubtohubpivot=pd.pivot_table(hubtohubdf,index=['ComingFrom','PCS SHORT LOCATION','DOCKNO'],values=['PCS SHORT','TOTPTPCS'],aggfunc={'TOTPTPCS':pd.np.mean,'PCS SHORT':lambda x: x.nunique()}).reset_index()
    hubtohubpivot1=pd.pivot_table(hubtohubpivot,index=['ComingFrom','PCS SHORT LOCATION'],values=['PCS SHORT','TOTPTPCS','DOCKNO'],aggfunc={'DOCKNO':len,'TOTPTPCS':sum,'PCS SHORT':sum}).reset_index()
    hubtohubpivot1=hubtohubpivot1.sort_values('PCS SHORT',ascending=False)
    hubtohubpivot11=hubtohubpivot1.pivot_table(index=['ComingFrom'],aggfunc={'DOCKNO':sum,'PCS SHORT':sum,'TOTPTPCS':sum})
    hubtohubpivot11=hubtohubpivot11.sort_values('PCS SHORT',ascending=False)
except:
    hubtohubpivot11=pd.DataFrame()


# In[8]:

hubtohubpivot1


# In[9]:

sctohubdf=df[df['BRTYPE']=='SC - HUB']
len(sctohubdf)


# In[10]:

try:
    sctohubpivot=pd.pivot_table(sctohubdf,index=['ComingFrom','PCS SHORT LOCATION','DOCKNO'],values=['PCS SHORT','TOTPTPCS'],aggfunc={'TOTPTPCS':pd.np.mean,'PCS SHORT':lambda x: x.nunique()}).reset_index()
    sctohubpivot1=pd.pivot_table(sctohubpivot,index=['ComingFrom','PCS SHORT LOCATION'],values=['PCS SHORT','TOTPTPCS','DOCKNO'],aggfunc={'DOCKNO':len,'TOTPTPCS':sum,'PCS SHORT':sum}).reset_index()
    sctohubpivot1=sctohubpivot1.sort_values('PCS SHORT',ascending=False)
    sctohubpivot11=sctohubpivot1.pivot_table(index=['ComingFrom'],aggfunc={'DOCKNO':sum,'PCS SHORT':sum,'TOTPTPCS':sum})
    sctohubpivot11=sctohubpivot11.sort_values('PCS SHORT',ascending=False)

except:
    sctohubpivot11=pd.DataFrame()


# In[11]:

sctohubpivot1


# In[12]:

hubtoscdf=df[df['BRTYPE']=='HUB - SC']
len(hubtoscdf)


# In[13]:

try:
    hubtoscpivot=pd.pivot_table(hubtoscdf,index=['ComingFrom','PCS SHORT LOCATION','DOCKNO'],values=['PCS SHORT','TOTPTPCS'],aggfunc={'TOTPTPCS':pd.np.mean,'PCS SHORT':lambda x: x.nunique()}).reset_index()
    hubtoscpivot1=pd.pivot_table(hubtoscpivot,index=['ComingFrom','PCS SHORT LOCATION'],values=['PCS SHORT','TOTPTPCS','DOCKNO'],aggfunc={'DOCKNO':len,'TOTPTPCS':sum,'PCS SHORT':sum}).reset_index()
    hubtoscpivot1=hubtoscpivot1.sort_values('PCS SHORT',ascending=False)
    hubtoscpivot11=hubtoscpivot1.pivot_table(index=['ComingFrom'],aggfunc={'DOCKNO':sum,'PCS SHORT':sum,'TOTPTPCS':sum})
    hubtoscpivot11=hubtoscpivot11.sort_values('PCS SHORT',ascending=False)

except:
    hubtoscpivot11=pd.DataFrame()


# In[14]:




# In[15]:

sctoscdf=df[df['BRTYPE']=='SC - SC']
len(sctoscdf)


# In[16]:

try:
    sctoscdfpivot=pd.pivot_table(sctoscdf,index=['ComingFrom','PCS SHORT LOCATION','DOCKNO'],values=['PCS SHORT','TOTPTPCS'],aggfunc={'TOTPTPCS':pd.np.mean,'PCS SHORT':lambda x: x.nunique()}).reset_index()
    sctoscdfpivot1=pd.pivot_table(sctoscdfpivot,index=['ComingFrom','PCS SHORT LOCATION'],values=['PCS SHORT','TOTPTPCS','DOCKNO'],aggfunc={'DOCKNO':len,'TOTPTPCS':sum,'PCS SHORT':sum}).reset_index()
    sctoscdfpivot1=sctoscdfpivot1.sort_values('PCS SHORT',ascending=False)
    sctoscdfpivot11=sctoscdfpivot1.pivot_table(index=['ComingFrom'],aggfunc={'DOCKNO':sum,'PCS SHORT':sum,'TOTPTPCS':sum})
    sctoscdfpivot11=sctoscdfpivot11.sort_values('PCS SHORT',ascending=False)
except:
    sctoscdfpivot11=pd.DataFrame()


# In[17]:




# In[18]:

try:
    dfpivot=pd.pivot_table(df,index=['BRTYPE','DOCKNO'],values=['PCS SHORT','TOTPTPCS'],aggfunc={'TOTPTPCS':pd.np.mean,'PCS SHORT':lambda x: x.nunique()}).reset_index()
    dfpivot1=pd.pivot_table(dfpivot,index=['BRTYPE'],values=['DOCKNO','PCS SHORT','TOTPTPCS'],aggfunc={'DOCKNO':len,'PCS SHORT':sum,'TOTPTPCS':sum}).reset_index()
    dfpivot1['Per%']=pd.np.round((dfpivot1['PCS SHORT'])*100.0/dfpivot1['TOTPTPCS'],1)
    docksum=dfpivot1['DOCKNO'].sum()
    pcsshortsum=dfpivot1['PCS SHORT'].sum()
    totptsum=dfpivot1['TOTPTPCS'].sum()
    perfsum=dfpivot1['Per%'].sum()
    values=['Total',docksum,pcsshortsum,totptsum,perfsum]
    col=['BRTYPE','DOCKNO','PCS SHORT','TOTPTPCS','Per%']
    totaldf=pd.DataFrame(data=[values],columns=col)
    dfpivot1=pd.concat([dfpivot1,totaldf],ignore_index=True)
except:
    dfpivot1=pd.DataFrame()


# In[19]:

dfpivot1


# In[20]:

try:
    docksummary=pd.pivot_table(df,index=['DOCKNO','ComingFrom','PCS SHORT LOCATION'],values=['PCS SHORT','TOTPTPCS'],aggfunc={'TOTPTPCS':pd.np.mean,'PCS SHORT':lambda x: x.nunique()}).reset_index()
    docksummary1=pd.pivot_table(docksummary,index=['DOCKNO','ComingFrom','PCS SHORT LOCATION'],values=['PCS SHORT','TOTPTPCS'],aggfunc={'PCS SHORT':sum,'TOTPTPCS':sum}).reset_index()
    docksummary1['Scanned PCS']=docksummary1['TOTPTPCS']-docksummary1['PCS SHORT']
    docksummary1=docksummary1[['DOCKNO','ComingFrom','TOTPTPCS','PCS SHORT LOCATION','Scanned PCS','PCS SHORT']]
except:
    docksummary1=pd.DataFrame()


# In[21]:

docksummary1


# In[22]:

import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
from string import Template
import sys
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
reload(sys).setdefaultencoding("ISO-8859-1")


# In[23]:

reportts = datetime.now()
opfilevar=reportts.date()
opfilevar1=reportts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=pd.np.round((float(currhrs)/60),0)


# In[24]:

df.to_csv(r'D:\Data\PLT Shortage\Consolidated Reports\Data\Shortagedata'+ str(opfilevar)+"-"+str(int(opfilevar2))+'.csv')
docksummary1.to_csv(r'D:\Data\PLT Shortage\Consolidated Reports\Docksummary'+ str(opfilevar)+"-"+str(int(opfilevar2))+'.csv')

filepath=r'D:\Data\PLT Shortage\Consolidated Reports\Data\Shortagedata'+ str(opfilevar)+"-"+str(int(opfilevar2))+'.csv'
filepath1=r'D:\Data\PLT Shortage\Consolidated Reports\Docksummary'+ str(opfilevar)+"-"+str(int(opfilevar2))+'.csv'


# In[25]:

#TO=['mahesh.reddy@spoton.co.in']
#CC=['mahesh.reddy@spoton.co.in']
#BCC=['mahesh.reddy@spoton.co.in']
TO=['plt.vigilance_sw@spoton.co.in','plt.vigilance_ne@spoton.co.in','HUBMGR_SPOT@spoton.co.in','AOM_SPOT@spoton.co.in','DOM_SPOT@spoton.co.in','ROM_SPOT@spoton.co.in','scincharge_spot@spoton.co.in','RIM_Spot@spoton.co.in','mangesh.gaikwad@spoton.co.in','Maruti.nandan@spoton.co.in','nitin.gaikwad@spoton.co.in','sb.pawar@spoton.co.in','amit.sharma@spoton.co.ins','purna.panda@spoton.co.in','Atul.Khare@spoton.co.in','ugresh.kanth@spoton.co.in','ashok.sahu@spoton.co.in','rakesh.sonawane@spoton.co.in','naresh.yemujala@spoton.co.in','sanjeet.kumar@spoton.co.in','ramakrishna.v@spoton.co.in','rajkumar@spoton.co.in','sb.pawar@spoton.co.in','chethan.h@spoton.co.in','yogesh.singh@spoton.co.in','samarjeet.dubey@spoton.co.in','dinesh.s@spoton.co.in','rajesh.mishra@spoton.co.in','chidananda.biswal@spoton.co.in']
CC=['abhik.mitra@spoton.co.in','rajesh.kapase@spoton.co.in','pawan.sharma@spoton.co.in','jothi.menon@spoton.co.in','rajesh.kumar@spoton.co.in','alok.b@spoton.co.in','sharanagouda.biradar@spoton.co.in','satya.pal@spoton.co.in','shivananda.p@spoton.co.in','mahesh.reddy@spoton.co.in','saptarshi.pathak@spoton.co.in','banusanketh.dc@spoton.co.in','anitha.thyagarajan@spoton.co.in']
#BCC=['mahesh.reddy@spoton.co.in']
# BCC=['plt.vigilance_sw@spoton.co.in','plt.vigilance_ne@spoton.co.in','HUBMGR_SPOT@spoton.co.in','AOM_SPOT@spoton.co.in','DOM_SPOT@spoton.co.in','ROM_SPOT@spoton.co.in','scincharge_spot@spoton.co.in','RIM_Spot@spoton.co.in','mangesh.gaikwad@spoton.co.in','Maruti.nandan@spoton.co.in','nitin.gaikwad@spoton.co.in','sb.pawar@spoton.co.in','amit.sharma@spoton.co.ins','purna.panda@spoton.co.in','Atul.Khare@spoton.co.in','ugresh.kanth@spoton.co.in','ashok.sahu@spoton.co.in','rakesh.sonawane@spoton.co.in','naresh.yemujala@spoton.co.in','sanjeet.kumar@spoton.co.in','ramakrishna.v@spoton.co.in','rajkumar@spoton.co.in','sb.pawar@spoton.co.in','chethan.h@spoton.co.in','yogesh.singh@spoton.co.in','samarjeet.dubey@spoton.co.in','dinesh.s@spoton.co.in','rajesh.mishra@spoton.co.in','chidananda.biswal@spoton.co.in']



FROM='reports.ie@spoton.co.in'
msg = MIMEMultipart()
msg["From"] = FROM
msg["TO"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "PLT Consolidated Shortage Exception Report " + str(opfilevar)
html3='''
<h5> To download the cons data , Please click the link below </h5>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EwayBill_NotAvl_Hub.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EwayBill_NotAvl_Hub.csv</p></b>
'''
report=""
report+='Dear All,'

report+='<br>'
report+='<br>'
report+='PFA Consolidated Exception on PLT Shortage'
report+='<br>'
report+='<br>'
report+='NOTE: Date Range between '+str(yestdate)+' 00:00:00'+' - '+str(yestdate)+' 23:59:00'
report+='<br>'
report+='<br>'
report+='Total Movement wise PLT Shortage'
report+='<br>'
report+='<br>'
report+='<br>'+dfpivot1.to_html()+'<br>'

report+='HUB-HUB PLT Consolidated Shortage'
report+='<br>'
report+='<br>'
report+='<br>'+hubtohubpivot11.to_html()+'<br>'
report+='HUB-SC PLT Consolidated Shortage'
report+='<br>'
report+='<br>'
report+='<br>'+hubtoscpivot11.to_html()+'<br>'
report+='SC-HUB PLT Consolidated Shortage'
report+='<br>'
report+='<br>'
report+='<br>'+sctohubpivot11.to_html()+'<br>'
report+='SC-SC PLT Consolidated Shortage'
report+='<br>'
report+='<br>'
report+='<br>'+sctoscdfpivot11.to_html()+'<br>'

abc=MIMEText(report,'html')
msg.attach(abc)
part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(filepath,"rb").read() )
Encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part1)

part2 = MIMEBase('application', "octet-stream")
part2.set_payload( open(filepath1,"rb").read() )
Encoders.encode_base64(part2)
part2.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
msg.attach(part2)

#msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, CC+TO, msg.as_string())
server.quit()

# except:
#   TO=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
#   FROM="mahesh.reddy@spoton.co.in"
#   msg = MIMEMultipart()
#   msg["From"] = FROM
#   msg["To"] = ",".join(TO)
#   #msg["CC"] = ",".join(CC)
#   #msg["BCC"] = ",".join(BCC)
#   #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
#   msg["Subject"] = "PLT Consolidated Shortage Exception Report Error in Execution" 
#   report=""
#   report+='Hi,'

#   report+='<br>'
#   report+='There was some error in PLT Consolidated Shortage Exception Report'
#   report+='<br>'

#   abc=MIMEText(report.encode('utf-8'),'html')
#   msg.attach(abc)
#   server=smtplib.SMTP('smtp.sendgrid.net', 587)
#   server.ehlo()
#   server.starttls()
#   server.ehlo()
#   server.login("spoton.net.in", "Star@123#")
#   failed = server.sendmail(FROM, TO, msg.as_string())
#   server.quit()



# In[ ]:



