
# coding: utf-8

# In[1]:

import pandas as pd
import smtplib
import os
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import datetime
from datetime import datetime
from datetime import timedelta
from pandas import ExcelWriter


# In[2]:

pudrmsdata = pd.read_csv(r'http://spoton.co.in/downloads/IEProjects/PRCU/PRCU.csv')
print len(pudrmsdata)
pudrmsdata = pudrmsdata.dropna(subset=['VehicleType'])
print len(pudrmsdata)
pudrmsdata = pudrmsdata.rename(columns={'\xef\xbb\xbfDy':'Date'})


# In[3]:

def utilcalc(vehcap,ofdwt,pkpwt):
    totalwt = ofdwt+pkpwt
    try:
        util = (pd.np.round((totalwt/vehcap),4))*100
        return util
    except:
        return 0

def distancecalc(deldist,pickdist):
    totaldist = deldist+pickdist
    return totaldist


# In[4]:

pudrmsdata['Total_distance'] = pudrmsdata.apply(lambda x:distancecalc(x['DEL_TRAVELDISTANCE'],x['PKP_TRAVELDISTANCE']),axis=1)


# In[5]:

pudrmsdatagrp = pudrmsdata.groupby(['Date','Brcd','VehicleNo','VEHICLECAPACITY']).agg({'OFD_CONS':sum,'OFD_ACTWT':sum,'PKP_ACTWT':sum,'DLV_UNIQUEPINCODES':sum,'MISSPICKUPS':sum,'NONDLV_CONS':sum,'Total_distance':sum}).reset_index()


# In[6]:

pudrmsdatagrp['VEHICLE_CAPACITY_NEW'] = pudrmsdatagrp.apply(lambda x:abs(x['VEHICLECAPACITY']),axis=1)


# In[7]:

pudrmsdatagrp['Utilization'] = pudrmsdatagrp.apply(lambda x:utilcalc(x['VEHICLE_CAPACITY_NEW'],x['OFD_ACTWT'],x['PKP_ACTWT']),axis=1)


# In[8]:

def utilcutoff(utilzn):
    if utilzn >= 300:
        return 'High_utilization'
    elif utilzn <= 50 :
        return 'Low_utilization'
    else:
        return 'NA'


# In[9]:

pudrmsdatagrp['Utilization_Remarks'] = pudrmsdatagrp.apply(lambda x:utilcutoff(x['Utilization']),axis=1)


# In[10]:

now = datetime.now()
yestday = now-timedelta(hours=24)
yestdate = yestday.date()


# In[11]:

#pudrmsdatagrp.to_csv(r'C:\Data\PUD_RMS\PUD_RMS_Report_Vehiclewise_'+str(yestdate)+'.csv')
#oppath1 = r'C:\Data\PUD_RMS\PUD_RMS_Report_Vehiclewise_'+str(yestdate)+'.csv'


# In[12]:

pudrmsdatagrphighutil = pudrmsdatagrp[pudrmsdatagrp['Utilization_Remarks']=='High_utilization']
pudrmsdatagrplowutil = pudrmsdatagrp[pudrmsdatagrp['Utilization_Remarks']=='Low_utilization']


# In[13]:

with ExcelWriter(r'D:\Data\PUD_RMS\Vehiclewise\PUD_RMS_Report_Vehiclewise_'+str(yestdate)+'.xlsx') as writer:
    ###orginal_cancel_basedata.to_excel(writer, sheet_name='Sheet1',engine='xlsxwriter')
    pudrmsdatagrp.to_excel(writer, sheet_name='All_vehicles',engine='xlsxwriter')
    pudrmsdatagrphighutil.to_excel(writer, sheet_name='High_Utilization',engine='xlsxwriter')
    pudrmsdatagrplowutil.to_excel(writer, sheet_name='Low_Utilization',engine='xlsxwriter')
    
oppath2 = r'D:\Data\PUD_RMS\Vehiclewise\PUD_RMS_Report_Vehiclewise_'+str(yestdate)+'.xlsx'


# In[14]:

filePath = oppath2
def sendEmail(TO = ["goutam.barik@spoton.co.in","sukumar.sakthivel@spoton.co.in"],
              #TO = ["vishwas.j@spoton.co.in"],
             #TO = ["rajeesh.vr@spoton.co.in"],
             CC = ["abhik.mitra@spoton.co.in","rajeesh.vr@spoton.co.in"],
             #CC = ["vishwas.j@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "Vehicle wise PUD RMS Report - "+ str(yestdate)
    body_text = """
    Dear All,
    
    PFA the PUD RMS report vehiclewise for """+str(yestdate)+"""
    
    
    Note:
    1) 'Utilization_Remarks' column indicates how well the vehicle has been utilized. If the utilization is more than 300%, a remark of High utilization is given. 
    If the utilization is less than 50%, a remark of Low utilization is given.
    
    2) There are 3 sheets in the report
    
    a) All_Vehicles : This contains complete vehicle wise tuilization details
    b) High_Utilization : This sheet contains all the vehicles which has been utilized more than 300%
    c) Low_Utilization : This sheet contains all the vehicles which has been utilized less than 50%
    
    """
    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("vishwas.j@spoton.co.in", "Startrek!123")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends

