# -*- coding: utf-8 -*-
"""
Created on Wed Feb 10 16:53:37 2016

@author: rajeeshv
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
import calendar
import datetime
from pandas import ExcelWriter


# In[7]:
cancelled = pd.read_csv(r'http://10.109.230.50/downloads/pickup/Pickup_CurMonth_Onetime_Cancel.csv')
success = pd.read_csv(r'http://10.109.230.50/downloads/pickup/Pickup_CurMonth_Onetime_Success.csv')

datetimenow = datetime.datetime.now()

opfilevar=datetimenow.date()
opfilevar1=datetimenow.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=np.round((float(currhrs)/60),0)


cancelled.to_csv(r'D:\Data\Onetime_Mispickups_rawfiles\Cancelled\Cancelled_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv', encoding="utf-8")
success.to_csv(r'D:\Data\Onetime_Mispickups_rawfiles\Success\Success_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv', encoding="utf-8")