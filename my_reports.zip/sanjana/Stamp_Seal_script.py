
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta,datetime
from string import Template
import sys
import Utilities
pd.set_option('display.max_columns', 40)
reload(sys).setdefaultencoding("ISO-8859-1")

# In[2]:


# cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")


# # In[3]:


# cursor=cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()
# In[4]:


date='2017-06-01'
date1=datetime.today()-timedelta(1)
date2=datetime.strftime(date1,'%Y-%m-%d ')
time='23:59:00'
date3=date2+time
print (date3)
today=datetime.strftime(date1,'%d-%b-%y ')
print (today)
query=("""EXEC USP_BADPOD_NOSEAL_SQ_syed  '{0}' , '{1}'""".format(date,date3))
# query=("""EXEC USP_BADPOD_NOSEAL_SQ_syed '2017-06-01','2018-01-01 23:59:00'""")
print (query)


# In[7]:


stamp_df_data=pd.read_sql(query,Utilities.cnxn)
#stamp_df_data=pd.read_excel(r'C:\Users\S2769MAH\Downloads\SQ\sharan\Book2.xlsx')


# In[8]:




# In[ ]:


stamp_df=stamp_df_data[stamp_df_data['BAD_OPEN_OR_CLOSE_STATUS']=='OPEN']
stamp_df['MONTH']=stamp_df['VIEWED_DATE'].apply(lambda x:x.split(' ')[1]+'-'+x.split(' ')[2])
print (stamp_df['MONTH'].unique())
# In[ ]:




# In[ ]:


len(stamp_df)


# In[ ]:


pivot_stamp_df=pd.pivot_table(stamp_df,index=['CONTROL_AREA'],columns=['MONTH'],values=['CON_NUMBER'],aggfunc={'CON_NUMBER':len},fill_value='0',margins=True)
pivot_stamp_df2=pivot_stamp_df['CON_NUMBER']
del pivot_stamp_df2['All']
pivot_branch_df=pd.pivot_table(stamp_df,index=['CONTROL_AREA','DELIVERY_BRANCH_CODE'],columns=['MONTH'],values=['CON_NUMBER'],aggfunc={'CON_NUMBER':len},fill_value='0',margins=True)
pivot_stamp_df=pivot_stamp_df.astype(int)
pivot_branch_df=pivot_branch_df.astype(int)
pivot_branch_df1=pivot_branch_df['CON_NUMBER']
del pivot_branch_df1['All']


days=pivot_stamp_df2.columns.tolist()
print (days)
days_sorted=sorted(days,key=lambda day:datetime.strptime(day,'%b-%Y'))
pivot_stamp_df3=pivot_stamp_df2[days_sorted]

for i in days_sorted:
    pivot_stamp_df3[i]=pivot_stamp_df3[i].astype(int)

# In[ ]:

pivot_branch_df2=pivot_branch_df1[days_sorted]
from pandas import ExcelWriter
from pandas import ExcelWriter
with ExcelWriter(r'D:\Data\ODA_Loads_Ton_wise\No_Stamp_Seal_BAD_POD_Summaries.xlsx') as writer:
    pivot_stamp_df3.to_excel(writer,engine='xlsxwriter',sheet_name='Area wise')
    pivot_branch_df2.to_excel(writer,engine='xlsxwriter',sheet_name='Delivery Branch Wise')
    

# In[ ]:

stamp_df_data.to_csv(r'D:\Data\ODA_Loads_Ton_wise\No_Stamp_Seal_BAD_POD_Data.CSV')

filepath=r'D:\Data\ODA_Loads_Ton_wise\No_Stamp_Seal_BAD_POD_Summaries.xlsx'
filepath1=r'D:\Data\ODA_Loads_Ton_wise\No_Stamp_Seal_BAD_POD_Data.csv'



# In[ ]:

# In[ ]:


import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback
for i in [filepath,filepath1]:
    oppath1=i
    #FTP Upload starts
    print ('Logging in...')
    ftp = ftplib.FTP()  
    ftp.connect('10.109.230.50')  
    print (ftp.getwelcome())
    try:  
        try:  
            ftp.login('HOSQTeam', 'Te@mH0$q')
            print ('login done')
            ftp.cwd('Auto_reports')  
            #ftp.cwd('FIFO')
            # move to the desired upload directory  
            print ("Currently in:", ftp.pwd()) 
            print ('Uploading...')  
            fullname = oppath1
            name = os.path.split(fullname)[1]  
            f = open(fullname, "rb")  
            ftp.storbinary('STOR ' + name, f)  
            f.close()  
            print ("OK"  )
            print ("Files:")  
            print (ftp.retrlines('LIST'))
        finally:  
            print ("Quitting...")
            ftp.quit()  
    except:  
        traceback.print_exc()



import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os

from_addr = 'mis.ho@spoton.co.in'
#to_addr = ['rajesh.mp@spoton.co.in','banusanketh.dc@spoton.co.in','mahesh.reddy@spoton.co.in']
#to_addr = ['sharanagouda.biradar@spoton.co.in','mahesh.reddy@spoton.co.in']
#cc_addr = ['sharanagouda.biradar@spoton.co.in','mahesh.reddy@spoton.co.in']
cc_addr=['SQ_SPOT@spoton.co.in','rajesh.kumar@spoton.co.in','jothi.menon@spoton.co.in','manzil.bhattacharya@spoton.co.in','krishna.chandrasekar@spoton.co.in']
#bcc_addr = ['rajesh.mp@spoton.co.in']
bcc_addr=['AOM_SPOT@spoton.co.in','dom_spot@spoton.co.in','rom_spot@spoton.co.in','scincharge_spot@spoton.co.in','mahesh.reddy@spoton.co.in']

username = 'mis.ho@spoton.co.in'
password = 'Spot@123'

msg = MIMEMultipart()

msg['From'] = from_addr
# msg['To'] = ', '.join(to_addr)
msg['cc'] = ', '.join(cc_addr)
msg['bcc'] = ', '.join(bcc_addr)
msg['Subject'] = 'No Stamp/Seal Pending BAD POD closure report'
html='''<html>
<h4>Dear All</h4>
<p>Pls find the attached No Stamp/Seal Pending BAD POD closure summary details as on $date</p>
<p>Please ensure to followup and closed all No stamp/seal pending BAD PODs in IBS doubt pod module as Success with C'nee stamp/seal on POD copy.</p>
<p>Please Note : No stamp/seal BAD POD should be close as Success only with C'nee stamp/seal on POD copy without fail.</p>
</html>'''
html3='''
<h5> Note : For data please open below link.</h5>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/No_Stamp_Seal_BAD_POD_Summaries.xlsx"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/No_Stamp_Seal_BAD_POD_Summaries.xlsx</p></b>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/No_Stamp_Seal_BAD_POD_Data.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/No_Stamp_Seal_BAD_POD_Data.csv</p></b>
'''
html1='''<h5>Thanks & Regards</h5></b>
<h5>HO-SQ</h5>'''
    
#  msg.attach(part10)
s = Template(html).safe_substitute(date=today)
report=""
report+=s
report+='<br>'
report+='<br>'+pivot_stamp_df3.to_html()+'<br>'
# report+='<br>'
report+=html3
report+='<br>'
report+=html1
abc=MIMEText(report,'html')
msg.attach(abc)
# server = smtplib.SMTP('smtp.spoton.co.in',587)
server = smtplib.SMTP('smtp.sendgrid.net',587)
part=MIMEBase('application','octet-stream')
# part1=MIMEBase('application','octet-stream')
part.set_payload(open(filepath,'rb').read())
# part1.set_payload(open(filepath1,'rb').read())
encoders.encode_base64(part)
# Encoders.encode_base64(part1)
part.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath))
# part1.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath1))
#msg.attach(part)
# msg.attach(part1)
server.ehlo()
server.starttls()
server.ehlo()
server.login('spoton.net.in','Star@123#')
server.sendmail(from_addr,cc_addr+bcc_addr,msg.as_string())
print ('mail sent succesfully')
server.quit()

