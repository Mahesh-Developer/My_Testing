
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta,datetime
import sys
import Utilities
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

reload(sys).setdefaultencoding("ISO-8859-1")


# In[2]:


# cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")


# # In[3]:


# cursor=cnxn.cursor()
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()

# In[4]:

try:
    query=("""EXEC dbo.USP_DESTN_HUB_FEEDER_OTP_REPORT_VIRTUAL_ALL""")


    # In[5]:


    hoto_df=pd.read_sql(query,Utilities.cnxn)
    len(hoto_df)


    # In[23]:


    #hoto_df=pd.read_excel(r'C:\Users\S2769MAH\Downloads\SQ\sreedhar\Book3.xlsx')
    date=datetime.now()
    date1=datetime.strftime(date,'%Y-%m-%d')
    date1


    # In[6]:


    hoto_df['SC_Arrv_Hours']=hoto_df['SC_Arrv_Hours'].apply(lambda x: ('Blank' if pd.isnull(x) else x))
    print (hoto_df['SC_Arrv_Hours'].unique())
    hoto_df['SC_Arrv_Hours']=hoto_df['SC_Arrv_Hours'].astype(str)


    # In[7]:


    hoto_df['ARRVDT_AT_HUB']=hoto_df['ARRVDT_AT_HUB'].dt.date


    # In[8]:


    def getDate(arrdt,flag):
        if str(arrdt)!='NaT':
            date=arrdt.date()
            return date
        else:
            return flag


    # In[9]:


    hoto_df['Date']=hoto_df.apply(lambda x: getDate(x['ARRV_DT_AT_NEXT_LOC'],x['OTPFLAG']),axis=1)
    hoto_df['Date']=hoto_df['Date'].astype(str)
    #print (hoto_df[hoto_df['Date']=='NOT CONNECTED FROM HUB'])
    hoto_df['Date'].unique()


    # In[18]:


    pivot_hoto_df=pd.pivot_table(hoto_df,index=['LOCATION','ARRVDT_AT_HUB','HUB_Arrv_Hours'],values=['DOCKNO'],columns=['Date','SC_Arrv_Hours'],fill_value='',aggfunc={'DOCKNO':len},margins=True)
    # ff=hoto_df.groupby(['LOCATION','ARRVDT_AT_HUB','HUB_Arrv_Hours']).agg({'DOCKNO':'count'}).reset_index()
    # ff=hoto_df['LOCATION','ARRVDT_AT_HUB','HUB_Arrv_Hours'].groupby(hoto_df['DOCKNO']).count()
    # pivot_hoto_df=pivot_hoto_df[('DOCKNO','All')].astype(int)
    # pivot_hoto_df=pivot_hoto_df.fillna(0)
    # pivot_hoto_df=pivot_hoto_df.sort_values([('DOCKNO', 'All')], ascending=False).astype(int)
    pivot_hoto_df=pivot_hoto_df
    pivot_hoto_df1=pivot_hoto_df
    pivot_hoto_df1['DOCKNO','All']=pivot_hoto_df1['DOCKNO','All'].astype(int)
    # pivot_hoto_df1=pd.np.round(pivot_hoto_df1[('DOCKNO','All')])
    pivot_hoto_df


    # In[19]:


    from pandas import ExcelWriter
    with ExcelWriter(r'D:\Data\ODA_Loads_Ton_wise\hoto_inbound.xlsx') as writer:
        pivot_hoto_df.to_excel(writer,engine='xlsxwriter',sheet_name='pivot')
        hoto_df.to_excel(writer,engine='xlsxwriter',sheet_name='Data')


    # In[20]:


    filepath=r'D:\Data\ODA_Loads_Ton_wise\hoto_inbound.xlsx'


    # In[21]:


    import numpy as np
    import pandas as pd
    import itertools
    import json
    from pandas import ExcelWriter
    from pandas import pivot_table
    from datetime import datetime
    import os
    import ftplib
    import traceback

    oppath1=filepath
    #FTP Upload starts
    print ('Logging in...')
    ftp = ftplib.FTP()  
    ftp.connect('10.109.230.50')  
    print (ftp.getwelcome())
    try:  
        try:  
            ftp.login('HOSQTeam', 'Te@mH0$q')
            print ('login done')
            ftp.cwd('Auto_reports')  
            #ftp.cwd('FIFO')
            # move to the desired upload directory  
            print ("Currently in:", ftp.pwd()) 
            print ('Uploading...')  
            fullname = oppath1
            name = os.path.split(fullname)[1]  
            f = open(fullname, "rb")  
            ftp.storbinary('STOR ' + name, f)  
            f.close()  
            print ("OK"  )
            print ("Files:")  
            print (ftp.retrlines('LIST'))
        finally:  
            print ("Quitting...")
            ftp.quit()  
    except:  
        traceback.print_exc()



    # In[22]:




    from_addr = 'mis.ho@spoton.co.in'
    # to_addr = ['rajesh.mp@spoton.co.in','banusanketh.dc@spoton.co.in','mahesh.reddy@spoton.co.in','shivananda.p@spoton.co.in']
    # to_addr = ['sreedhar.m@spoton.co.in','mahesh.reddy@spoton.co.in']
    #cc_addr = ['maheshmahesh11464@gmail.com','mahesh.reddy@spoton.co.in']
    cc_addr=['sq_spot@spoton.co.in','jothi.menon@spoton.co.in','pawan.sharma@spoton.co.in','prasanna.hedge@spoton.co.in']
    #bcc_addr = ['rajesh.mp@spoton.co.in']
    bcc_addr=['AOM_SPOT@spoton.co.in','dom_spot@spoton.co.in','rom_spot@spoton.co.in','hubmgr_spot@spoton.co.in','scincharge_spot@spoton.co.in','anitha.thyagarajan@spoton.co.in','mahesh.reddy@spoton.co.in']

    username = 'mis.ho@spoton.co.in'
    password = 'Raj@spot12.mp'

    msg = MIMEMultipart()

    msg['From'] = from_addr
    # msg['To'] = ', '.join(to_addr)
    msg['bcc'] = ', '.join(cc_addr)
    msg['bcc'] = ', '.join(bcc_addr)
    msg['Subject'] = 'Hoto Report - Destination HUB To SC'
    html='''<html>
    <h4>Dear ,All</h4>
    <p>PFA,Hoto Report - Destination HUB To SC for the dated $date  . </p>
    </html>'''
    html3='''
    <h5> To download the notconnected cons details, Please click the link below </h5>
    <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/hoto_inbound.xlsx"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/hoto_inbound.xlsx</p></b>
    '''
    html1='''<h5>Thanks & Regards</h5></b>
    <h5>HO-SQ</h5>'''
        
    #  msg.attach(part10)
    s = Template(html).safe_substitute(date=date1)
    report=""
    report+=s
    report+='<br>'
    report+='<br>'+pivot_hoto_df1.to_html()+'<br>'
    # report+='<br>'
    report+=html3
    report+='<br>'
    report+=html1
    abc=MIMEText(report,'html')
    msg.attach(abc)
    
    part=MIMEBase('application','octet-stream')
    # part1=MIMEBase('application','octet-stream')
    part.set_payload(open(filepath,'rb').read())
    # part1.set_payload(open(filepath1,'rb').read())
    encoders.encode_base64(part)
    # Encoders.encode_base64(part1)
    part.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath))
    # part1.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath1))
    msg.attach(part)
    # msg.attach(part1)

    # server = smtplib.SMTP('smtp.spoton.co.in',587)
    # server.ehlo()
    # server.starttls()
    # server.ehlo()
    # server.login('mis.ho@spoton.co.in','Mis@2019')
    # server.sendmail(from_addr,cc_addr+bcc_addr,msg.as_string())    
    # server.quit()

    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(from_addr,cc_addr+bcc_addr, msg.as_string())
    print ('mail sent succesfully')
    server.quit()

except:

  TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in']  
  CC=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "ERROR Report" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in Hoto Report - Destination HUB To SC'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO+CC, msg.as_string())
  server.quit()

