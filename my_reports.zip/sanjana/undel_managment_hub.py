
# coding: utf-8

# In[ ]:


#from Networkmeeting_Reach import lhplanning
import numpy as np
import pandas as pd
import pyodbc
from IPython import display
from datetime import datetime
from datetime import datetime,timedelta
from datetime import datetime, timedelta
import smtplib
import ftplib
import traceback
import calendar
import os
import Utilities

# In[ ]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


# In[ ]:


query=("""USP_STOCK_ALL_SQ""")


# In[ ]:


df=pd.read_sql(query,Utilities.cnxn)


# In[ ]:


len(df)


# In[ ]:


df.head()


# In[ ]:


df1=df


# In[ ]:


df1.columns


# In[ ]:


df1['CurLocConStatusCode'].unique()


# In[ ]:

df1=df1[df1['HUBCENTER']=='Y']
df1=df1[~df1['CurLocConStatusCode'].isin(['ADC','APT','APN'])]
len(df1)


# In[ ]:


all_cust_summary=df1.pivot_table(index=['CURR_AREA'],columns=['DAYS_BUCKET'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').fillna(0)


# In[ ]:


all_cust_summary.head()


# In[ ]:


all_cust_summary1=all_cust_summary[[('DOCKNO','<=7DAYS'),('DOCKNO','7-15 DAYS'),('DOCKNO','15-30 DAYS'),('DOCKNO','>30DAYS'),('DOCKNO','Total')]]


# In[ ]:


all_cust_summary1['DOCKNO']=all_cust_summary1['DOCKNO'].astype(int)


# In[ ]:


df1['CUSTOMER_TYPE'].unique()


# In[ ]:


special_df=df1[df1['CUSTOMER_TYPE']=='SPECIAL_CUSTOMER']
len(special_df)


# In[ ]:


special_cust_summary=special_df.pivot_table(index=['CURR_AREA'],columns=['DAYS_BUCKET'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').fillna(0)


# In[ ]:


special_cust_summary1=special_cust_summary[[('DOCKNO','<=7DAYS'),('DOCKNO','7-15 DAYS'),('DOCKNO','15-30 DAYS'),('DOCKNO','>30DAYS'),('DOCKNO','Total')]]


# In[ ]:


special_cust_summary1['DOCKNO']=special_cust_summary1['DOCKNO'].astype(int)


# In[ ]:


other_df=df1[df1['CUSTOMER_TYPE']=='OTHER_CUSTOMER']
len(other_df)


# In[ ]:


other_cust_summary=other_df.pivot_table(index=['CURR_AREA'],columns=['DAYS_BUCKET'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').fillna(0)


# In[ ]:


other_cust_summary1=other_cust_summary[[('DOCKNO','<=7DAYS'),('DOCKNO','7-15 DAYS'),('DOCKNO','15-30 DAYS'),('DOCKNO','>30DAYS'),('DOCKNO','Total')]]


# In[ ]:


other_cust_summary1['DOCKNO']=other_cust_summary1['DOCKNO'].astype(int)


# In[ ]:


other_cust_summary1


# In[ ]:


#dd=df1.pivot_table(index=['orgareaname'],columns=['CUSTOMER_TYPE','DAYS_BUCKET'],values=['DOCKNO'],aggfunc={'DOCKNO':len}).fillna(0)


# In[ ]:


#dd['DOCKNO','OTHER_CUSTOMER','Total']=dd['DOCKNO','OTHER_CUSTOMER'].sum(axis=1)


# In[ ]:


#dd['DOCKNO','Total']=dd['DOCKNO','OTHER_CUSTOMER','<=7DAYS']+dd['DOCKNO','OTHER_CUSTOMER','7-15 DAYS']+dd['DOCKNO','OTHER_CUSTOMER','>15DAYS']


# In[ ]:


todate=datetime.strftime(datetime.now(),'%Y-%m-%d')
todate


# In[ ]:


# from pandas import ExcelWriter
# with ExcelWriter(r'D:\Data\Undel_Managment\Undel_Management_'+str(todate)+'.xlsx') as writer:
#     df1.to_excel(writer,engine='xlsxwriter',sheet_name='Data')
#     all_cust_summary1.to_excel(writer,engine='xlsxwriter',sheet_name='Over_All_Summary')
#     special_cust_summary1.to_excel(writer,engine='xlsxwriter',sheet_name='Special_Cust_summary')
#     other_cust_summary1.to_excel(writer,engine='xlsxwriter',sheet_name='Other_cust_summary')


# In[ ]:
df1.to_csv(r'D:\Data\Undel_Managment\Undel_Management_Data_'+str(todate)+'.csv')
all_cust_summary1.to_csv(r'D:\Data\Undel_Managment\Over_All_Summary_'+str(todate)+'.csv')
special_cust_summary1.to_csv(r'D:\Data\Undel_Managment\Special_Cust_Summary_'+str(todate)+'.csv')
other_cust_summary1.to_csv(r'D:\Data\Undel_Managment\Other_Cust_Summary_'+str(todate)+'.csv')


df1.to_csv(r'D:\Data\Undel_Managment\Undel_Management_Data.csv')
all_cust_summary1.to_csv(r'D:\Data\Undel_Managment\Over_All_Summary.csv')
special_cust_summary1.to_csv(r'D:\Data\Undel_Managment\Special_Cust_Summary.csv')
other_cust_summary1.to_csv(r'D:\Data\Undel_Managment\Other_Cust_Summary.csv')



# from pandas import ExcelWriter
# with ExcelWriter(r'D:\Data\Undel_Managment\Undel_Management.xlsx') as writer:
#     df1.to_excel(writer,engine='xlsxwriter',sheet_name='Data')
#     all_cust_summary1.to_excel(writer,engine='xlsxwriter',sheet_name='Over_All_Summary')
#     special_cust_summary1.to_excel(writer,engine='xlsxwriter',sheet_name='Special_Cust_summary')
#     other_cust_summary1.to_excel(writer,engine='xlsxwriter',sheet_name='Other_cust_summary')


# In[ ]:


filepath=r'D:\Data\Undel_Managment\Undel_Management_Data.csv'
filepath1=r'D:\Data\Undel_Managment\Over_All_Summary.csv'
filepath2=r'D:\Data\Undel_Managment\Special_Cust_Summary.csv'
filepath3=r'D:\Data\Undel_Managment\Other_Cust_Summary.csv'


# In[ ]:


import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback
for i in [filepath,filepath1,filepath2,filepath3]:
    oppath1=i
    #FTP Upload starts
    print ('Logging in...')
    ftp = ftplib.FTP()  
    ftp.connect('10.109.230.50')  
    print (ftp.getwelcome())
    try:  
        try:  
            ftp.login('HOSQTeam', 'Te@mH0$q')
            print ('login done')
            ftp.cwd('Auto_reports')  
            #ftp.cwd('FIFO')
            # move to the desired upload directory  
            print ("Currently in:", ftp.pwd()) 
            print ('Uploading...')  
            fullname = oppath1
            name = os.path.split(fullname)[1]  
            f = open(fullname, "rb")  
            ftp.storbinary('STOR ' + name, f)  
            f.close()  
            print ("OK"  )
            print ("Files:")  
            print (ftp.retrlines('LIST'))
        finally:  
            print ("Quitting...")
            ftp.quit()  
    except:  
        traceback.print_exc()


# In[ ]:


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

# TO=['mahesh.reddy@spoton.co.in']
TO=['aom_spot@spoton.co.in','dom_spot@spoton.co.in','rom_spot@spoton.co.in','hubmgr_spot@spoton.co.in','scincharge_spot@spoton.co.in','sq_spot@spoton.co.in','spot_cstl@spoton.co.in']
FROM="mis.ho@spoton.co.in"
CC=['abhik.mitra@spoton.co.in','jothi.menon@spoton.co.in','rajesh.kumar@spoton.co.in','pawan.sharma@spoton.co.in','sharmistha.majumdar@spoton.co.in','anitha.thyagarajan@spoton.co.in','shivananda.p@spoton.co.in','mahesh.reddy@spoton.co.in']
# CC=['mahesh.reddy@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
msg["Subject"] = "Stock Managment for - HUB " + " : " + todate
html='''<html>
<style>
p
{
  margin:0;
  margin-top: 5px;
  padding:0;
  font-size:17px;
    line-height:20px;
}
</style>
<h3>Dear All,</h3>
<p>Please Find POD's Summary.</p>
</html>'''


s = Template(html).safe_substitute()
report=""
#report+=s
#report+='<br>'+final_dff5.to_html()+'<br>'
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='Please Find attached Stock Managment Summary for HUB :'
report+='<br>'
report+='<br>'
#report+='NOTE : The below data is excluding Appointment Cons'
#report+='<br>'
report+='Over All Summary : '
report+='<br>'
report+='<br>'+all_cust_summary1.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='Special Customer Summary : '
report+='<br>'
report+='<br>'+special_cust_summary1.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='Other Customer Summary : '
report+='<br>'
report+='<br>'+other_cust_summary1.to_html()+'<br>'
report+='<br>'
report+='<br>'

html5='''
<h5> To download the data , Please click the link below </h5>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Undel_Management_Data.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Undel_Management_Data.csv</p></b>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Over_All_Summary.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Over_All_Summary.csv</p></b>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Special_Cust_Summary.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Special_Cust_Summary.csv</p></b>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Other_Cust_Summary.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Other_Cust_Summary.csv</p></b>

    '''
report+=html5
abc=MIMEText(report,'html')
msg.attach(abc)
# part = MIMEBase('application', "octet-stream")
# part.set_payload( open(filePath,"rb").read() )
# encoders.encode_base64(part)
# part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
# msg.attach(part)
# part1 = MIMEBase('application', "octet-stream")
# part1.set_payload( open(filePath1,"rb").read() )
# encoders.encode_base64(part1)
# part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath1))
# msg.attach(part1)

server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()

