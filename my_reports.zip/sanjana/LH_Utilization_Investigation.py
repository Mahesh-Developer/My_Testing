
# coding: utf-8

# In[1]:

import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
from pandas import ExcelWriter

import os
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from pandas import ExcelWriter
from email import encoders

# In[2]:

#ippath1 = 'C:/Users/s1738raj/Desktop/LHUtilization/THC_LINEHAUL_DAILY_IEP.xls'


# In[3]:

#x1 = pd.ExcelFile(ippath1)
#header1 = x1.parse("THC UTILIZATION HEADER")
#xl2 = pd.ExcelFile(ippath1)
#data1 = xl2.parse('THC_UTILIZATION_DETAILS')

data1 = pd.io.excel.read_excel('http://10.109.230.50/downloads/THC_LINEHAUL_DAILY_IEP/THC_LINEHAUL_DAILY_IEP.xls','THC_UTILIZATION_DETAILS')
header1 = pd.io.excel.read_excel('http://10.109.230.50/downloads/THC_LINEHAUL_DAILY_IEP/THC_LINEHAUL_DAILY_IEP.xls','THC UTILIZATION HEADER')
# In[4]:

header = header1[header1['Is Source Loc THCOrgin']=='Y']
data = data1[data1['Is Source Loc THCOrgin']=='Y']


# In[5]:

totalthcsprep = len(header)
#len(data)
#add line from Manjus update


# In[6]:

potentialthc  = header[(header['Remaining Pay Load']>0) & (header['Remaining Volume']>0) & (header['Tot Left Cons']>0)]
possiblethclist = potentialthc['THCNO'].tolist()
data_potentialthc = data[(data['THCNO'].isin(possiblethclist)) & (data['Is Loaded']=='N') & (data['Con Allowed For Loading']=='Y')]
len(data_potentialthc)


# In[7]:

def consavailable(hdrid, thcno, rem_wt, rem_vol):
    df = data_potentialthc[(data_potentialthc['hdrid']==hdrid) & (data_potentialthc['THCNO']==thcno) & (data_potentialthc['ACTUWT']<=rem_wt) & (data_potentialthc['ACTUWT']<=rem_vol)]
    return len(df)
    


# In[8]:

potentialthc['Cons_Available'] = potentialthc.apply(lambda x: consavailable(x['hdrid'],x['THCNO'],x['Remaining Pay Load'],x['Remaining Volume']), axis=1)


# In[9]:

thc_Verification = potentialthc[potentialthc['Cons_Available']>0]


# In[10]:
yesterdate=date.today()-timedelta(hours=24)

thc_Verification.to_csv(r'D:\Data\LH_utilization_Verification\THC_Verification_'+str(yesterdate)+'.csv')
oppath = r'D:\Data\LH_utilization_Verification\THC_Verification_'+str(yesterdate)+'.csv'

thcVerification = len(thc_Verification)

filePath = oppath
def sendEmail(#TO = ["prasanna.hegde@spoton.co.in"],
            TO = ["rajeesh.vr@spoton.co.in"],
            CC = ["vishwas.j@spoton.co.in"],
            #CC = ["supratim@iepfunds.com","pawan.sharma@spoton.co.in","Ankit@iepfunds.com","vishwas.j@spoton.co.in","rajeesh.vr@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "LH Utilization Verification " + '- ' + str(yesterdate)
    body_text = """
    Dear All,
    
    PFA the LH Utilization verification for """+str(yesterdate)+ """
    
    Total THCs prepared on """+str(yesterdate)+""" = """+str(totalthcsprep)+"""
    Pictures of THCs to be verified = """+str(thcVerification)+"""
    
    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("vishwas.j@spoton.co.in", "Startrek!123")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends
