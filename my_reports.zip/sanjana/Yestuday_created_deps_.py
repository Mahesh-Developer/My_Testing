
# coding: utf-8

# In[ ]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta
import Utilities
import sys
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.MIMEBase import MIMEBase
from email import Encoders
import os
reload(sys).setdefaultencoding("ISO-8859-1")
# In[ ]:


# cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")


# # In[ ]:


# cursor=cnxn.cursor()
try:
    cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
    cursor = cnxn.cursor()
    # In[ ]:


    querydate=date.today()-timedelta(1)


    # In[ ]:


    query=(""" EXEC USP_CON_SHORTAGE_EXCESS_REPORT 'ALL','ALL','ALL','{0}','{1}', ''""".format(querydate,querydate))


    # In[ ]:


    data=pd.read_sql(query,Utilities.cnxn)
    print (len(data))
    damage_data=data[data['CON STATUS CODE DESCP']=='Shipment Received Damage']
    len(damage_data)
    damage_data=damage_data.sort_values('CON STATUS DATE',ascending=False)
    damage_data1=damage_data.drop_duplicates('CONNumber',keep='last')
    short_data=data[data['CON STATUS CODE DESCP']=='Shipment Received Short']
    len(short_data)
    short_data=short_data.sort_values('CON STATUS DATE',ascending=False)
    short_data1=short_data.drop_duplicates('CONNumber',keep='last')
    excess_data=data[data['CON STATUS CODE DESCP']=='Shipment Received Excess']
    len(excess_data)
    excess_data=excess_data.sort_values('CON STATUS DATE',ascending=False)
    excess_data1=excess_data.drop_duplicates('CONNumber',keep='last')
    pff_data=data[data['CON STATUS CODE DESCP']=='Shipment Received with Pilferage']
    len(pff_data)
    pff_data=pff_data.sort_values('CON STATUS DATE',ascending=False)
    pff_data1=pff_data.drop_duplicates('CONNumber',keep='last')
    dfff=pd.concat([damage_data1,excess_data1,pff_data1,short_data1],ignore_index=True)

    # In[ ]:


    #data['CON STATUS CODE DESCP'].unique()


    # In[ ]:


    list_of_hub=['AMCH', 'AMDH', 'BBIH','BDQH', 'BGMH', 'BHOH', 'BLRH', 'BOMH', 'BRGH', 'CCUH', 'CJBH', 'DELH', 'GZBH', 'HYDH', 'IDRH', 'JAIH', 'JBLH', 'KNPH', 'LKOH', 'MAAH', 'NAGH', 'PATH', 'PGTH', 'PNQH', 'RPRH', 'SMBH', 'SNRH', 'SXVF', 'VPIH', 'VZAH', 'GAUH']


    # In[ ]:


    def hubORsc(h):
        print (h)
        if h in list_of_hub:
            return 'Hub'
        else:
            return 'SC'


    # In[ ]:


    dfff['captured_loc_type']=dfff.apply(lambda x:hubORsc(x['CAPTURED LOCATION']),axis=1)


    # In[ ]:


    def hubORsc(h):
        print (h)
        if h in list_of_hub:
            return 'Hub'
        else:
            return 'SC'


    # In[ ]:


    dfff['coming_from_loc_type']=dfff.apply(lambda x:hubORsc(x['COMING FROM']),axis=1)


    # In[ ]:


    dataH = dfff[dfff['coming_from_loc_type']=='Hub']


    # In[ ]:


    dataS= dfff[dfff['coming_from_loc_type']=='SC']


    # In[ ]:


    pivotH=pd.pivot_table(dataH,index=["COMING FROM","captured_loc_type"],columns=["CON STATUS CODE DESCP"],values=["CONNumber"],aggfunc={"CONNumber":len},fill_value='',margins=True)


    # In[ ]:


    pivotS=pd.pivot_table(dataS,index=["COMING FROM","captured_loc_type"],columns=["CON STATUS CODE DESCP"],values=["CONNumber"],aggfunc={"CONNumber":len},fill_value='',margins=True)


    # In[ ]:
    data12=dfff[dfff['COMING FROM'].isin(list_of_hub)]
    len(data12)
    summary=data12.pivot_table(index=['COMING FROM'],columns=['CON STATUS CODE DESCP'],aggfunc={'CONNumber':len}).fillna(0)
    summary['Total']=summary['CONNumber'].sum(axis=1)
    summary['Total']=summary['Total'].astype(int)
    summary['CONNumber']=summary['CONNumber'].astype(int)
    summary=summary.sort_values('Total',ascending=False)
    summary1=summary.head(10)
    from pandas import ExcelWriter


    # In[ ]:


    with ExcelWriter(r'D:\Data\ODA_Loads_Ton_wise\yesturday_deps_created.xlsx') as writer:
        pivotH.to_excel(writer, sheet_name='Created_Hub',engine='xlsxwriter')
        pivotS.to_excel(writer, sheet_name='Created_SC',engine='xlsxwriter')
        dfff.to_excel(writer,sheet_name='data',engine='xlsxwriter')
        summary.to_excel(writer,sheet_name='summary',engine='xlsxwriter')


    # In[ ]:


    filepath= r'D:\Data\ODA_Loads_Ton_wise\yesturday_deps_created.xlsx'


    # In[ ]:


    import numpy as np
    import pandas as pd
    import itertools
    import json
    from pandas import ExcelWriter
    from pandas import pivot_table
    from datetime import datetime
    import os
    import ftplib
    import traceback

    oppath1=filepath
    #FTP Upload starts
    print ('Logging in...')
    ftp = ftplib.FTP()  
    ftp.connect('10.109.230.50')  
    print (ftp.getwelcome())
    try:  
        try:  
            ftp.login('HOSQTeam', 'Te@mH0$q')
            print ('login done')
            ftp.cwd('Auto_reports')  
            #ftp.cwd('FIFO')
            # move to the desired upload directory  
            print ("Currently in:", ftp.pwd()) 
            print ('Uploading...')  
            fullname = oppath1
            name = os.path.split(fullname)[1]  
            print ('os path ok')
            f = open(fullname, "rb")  
            ftp.storbinary('STOR ' + name, f)  
            f.close()  
            print ("OK"  )
            print ("Files:")  
            print (ftp.retrlines('LIST'))
        finally:  
            print ("Quitting...")
            ftp.quit()  
    except:  
        traceback.print_exc()


    # In[ ]:




    from_addr = 'mis.ho@spoton.co.in'
    #to_addr = ['sreedhar.m@spoton.co.in']
    #to_addr = ['sreedhar.m@spoton.co.in','sharanagouda.biradar@spoton.co.in']
    # cc_addr = ['mahesh.reddy@spoton.co.in','abhishek.cv@spoton.co.in']
    cc_addr = ['pawan.sharma@spoton.co.in','harish.kumar@spoton.co.in','spot_security@spoton.co.in','spot_cstl@spoton.co.in','sqtf@spoton.co.in','SQ_SPOT@spoton.co.in','alok.p@spoton.co.in']
    # bcc_addr = ['rajesh.mp@spoton.co.in']
    bcc_addr =['AOM_SPOT@spoton.co.in','abhishek.cv@spoton.co.in','dom_spot@spoton.co.in','rom_spot@spoton.co.in','hubmgr_spot@spoton.co.in','scincharge_spot@spoton.co.in','sb.pawar@spoton.co.in','sandeep.agarwal@spoton.co.in','rajesh.prajapati@spoton.co.in','jaswant.gusain@spoton.co.in','satyaprakash.vishwakarma@spoton.co.in','sukesh.mishra@spoton.co.in','gayatreya.trivedi@spoton.co.in','OPS.hub.blrh.1@spoton.co.in','ops.hub.delh.1@spoton.co.in','anand.singh@spoton.co.in','vinayak.kumbar@spoton.co.in','mahesh.reddy@spoton.co.in']
    username = 'mis.ho@spoton.co.in'
    password = 'Mis@2019'

    msg = MIMEMultipart()

    msg['From'] = from_addr
    #msg['To'] = ', '.join(to_addr)
    msg['bcc'] = ', '.join(bcc_addr)
    msg['cc'] = ', '.join(cc_addr)
    msg['Subject'] = 'Yesterday reported DEPS by HUB & SC'
    html='''<html>
    <h4>Dear All,</h4>
    <h4>Please find the attached HUB & SC DEPS Reported on yesterday</h4>
    <h4>Dear AOM / DOM / HUB Manager's, </h4>
    <p>Shortage shipments are getting more by your end, Hence please check the material before loading & unloading.
    Pls speak to the concern transit HUB / SC and clear the Shortage cases immediately. </p>
    <p>Also if you receive any excess shipment should be forwarded the same to the actual locations by next available Line-haul vehicle</p>
    </html>'''


    html3='''
    <h5> To download the Details of "Yesterday reported DEPS by Hub & SC", Please click the link below </h5>
    <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/yesturday_deps_created.xlsx"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/yesturday_deps_created.xlsx</p></b>
    '''

    # html5='''
    # <h4> 1.Yesterday Created DEPS by SC</h4>
    # '''
    # html6='''
    # <h4> 2.Yesterday Created DEPS by HUB</h4>
    # '''


    html4='''<h5>Thanks & Regards</h5></b>
    <h5>HO-SQ</h5>'''
    report=""
    report="Dear All,"
    report+='<br>'
    report+='Please find the attached HUB & SC DEPS Reported on yesterday'
    report+='<br>'
    report+='<br>'
    report+='<h4> Dear AOM / DOM / HUB Managers </h4>'
    report+='<br>'
    report+='<br>'
    report+='Shortage shipments are getting more by your end, Hence please check the material before loading & unloading.'
    report+='<br>'
    report+='<br>'
    report+='Pls speak to the concern transit HUB / SC and clear the Shortage cases immediately.'
    report+='<br>'
    report+='<br>'
    report+='Also if you receive any excess shipment should be forwarded the same to the actual locations by next available Line-haul vehicle'
    report+='<br>'
    report+='<br>'
    # report+=html
    report+='Top 10 Hubs DEPS Reported on Yesterday'
    report+='<br>'
    report+='<br>'
    report+='<br>'+summary1.to_html()+'<br>'
    # report+=html1
    report+=html3
    # report+=html5
    # report+='<br>'+pivotH.to_html()+'<br>'
    # # report+='<br>'
    # report+=html6
    # # report+='<br>'
    # report+='<br>'+pivotS.to_html()+'<br>'
    report+=html4
    report+='<br>'
    abc=MIMEText(report,'html')
    msg.attach(abc)

    server = smtplib.SMTP('smtp.sendgrid.net',587)
    part=MIMEBase('application','octet-stream')


    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    server.sendmail(from_addr,cc_addr+bcc_addr,msg.as_string())
    print ('mail sent succesfully')
    server.quit()

except:

  TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in','sharanagouda.biradar@spoton.co.in'] 
  #TO=['mahesh.reddy@spoton.co.in']
  CC=['mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "ERROR Report" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in Yesturday reported DEPS by HUB & SC'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO+CC, msg.as_string())
  server.quit()

# In[ ]:

