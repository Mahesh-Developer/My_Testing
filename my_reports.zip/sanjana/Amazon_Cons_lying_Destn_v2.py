
# coding: utf-8

# In[92]:


import numpy as np
import pandas as pd
import pyodbc
from IPython import display
from datetime import datetime
from datetime import datetime,timedelta
from datetime import datetime, timedelta
import smtplib
import ftplib
import traceback
import calendar
from fuzzywuzzy import fuzz,process
from fuzzywuzzy import fuzz
import os
import Utilities


# In[93]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
cursor = cnxn.cursor()


# In[94]:


query=("""SELECT --TOP 100              
        A.DOCKNO ,
        A.CDELDT ,

        --A.DC ,

        --A.DACCC ,

        --A.VTC ,

        --A.FTC ,
        A.BOOKING_REGION ,
        A.ACTUAL_WEIGHT ,
        A.PKGSNO ,
        A.VOLUME ,
        A.ORIGIN_BRCODE ,
        A.ORIGIN_BRNAME ,
        A.orgareaname ,
        A.ORGLOCTYPE ,
        A.DESTCD ,
        A.destareaname ,
        A.DESTHUB ,
        A.DESTLOCTYPE ,
        A.PINCODE ,
        A.DOCKDT ,
        A.DEFAULTHUB ,
        A.CURR_AREA ,
        A.CURR_BRANCHCODE ,
        A.CURR_BRANCHNAME ,
        BR.RGALPH CURR_REGION ,
        ISNULL(A.ARRV_AT_CURR_LOCATION, A.DOCKDT) ARRV_AT_CURR_LOCATION ,
        A.HOURS_LYING_AT_CURR_LOCATION ,
        BR.HUBCENTER ,
        A.ISDEPARTED_FRM_CURRLOC ,
        A.DEPARTURE_TO_LOC_FRM_CURLOC ,
        A.CurLocConStatusCategory ,
        A.CurLocConStatusCode ,
        A.CurLocConStatusDesc ,
        A.CurLocConStatusReason ,
        A.CurLocConStatusDate ,
        A.CurLocConStatusMasterCategory ,
        A.CSGNCD ,

        --REPLACE(A.CSGNNM, '"', '') CSGNNM ,
        REPLACE(DK.CSGNNM, '"', '') DK_CSGNNM ,
        A.CSGECD ,

        --REPLACE(A.CSGENM, '"', '') CSGENM ,
        REPLACE(DK.CSGENM, '"', '') DK_CSGENM ,
        A.TIME_STAMP ,
        A.DLV_PINCODE ,
        D.CustCode ,
        D.CustName ,
        D.ParentCode ,
        D.ParentName ,
        CASE WHEN ( A.CURR_BRANCHCODE = A.ORIGIN_BRCODE
                    AND A.ISDEPARTED_FRM_CURRLOC = 'NO'
                  ) THEN 'At_Origin_SC'
             WHEN ( A.CURR_BRANCHCODE = A.ORIGIN_BRCODE
                    AND A.ISDEPARTED_FRM_CURRLOC = 'YES'
                  ) THEN 'At_Origin_SC_Departed'
             WHEN ( A.CURR_BRANCHCODE = A.DEFAULTHUB
                    AND A.ISDEPARTED_FRM_CURRLOC = 'NO'
                  ) THEN 'At_Origin_HUB'
             WHEN ( A.CURR_BRANCHCODE = A.DEFAULTHUB
                    AND A.ISDEPARTED_FRM_CURRLOC = 'YES'
                  ) THEN 'At_Origin_HUB_Departed'
             WHEN ( A.CURR_BRANCHCODE = A.DESTHUB
                    AND A.ISDEPARTED_FRM_CURRLOC = 'NO'
                  ) THEN 'At_Destn_HUB'
             WHEN ( A.CURR_BRANCHCODE = A.DESTHUB
                    AND A.ISDEPARTED_FRM_CURRLOC = 'YES'
                  ) THEN 'At_Destn_HUB_Departed'
             WHEN ( A.CURR_BRANCHCODE = A.DESTCD
                    AND A.ISDEPARTED_FRM_CURRLOC = 'NO'
                  ) THEN 'At_Destn'
             WHEN ( A.ISDEPARTED_FRM_CURRLOC = 'NO' ) THEN 'At_Intransit_HUB'
             WHEN ( A.ISDEPARTED_FRM_CURRLOC = 'YES' ) THEN 'INTRANSIT_MOVING'
        END CON_LOC_TYPE ,
        A.ApptmntDelDate
FROM    dbo.tblTimeConnectionReport_Undelivered_2Hrs A
        CROSS APPLY dbo.UFN_GET_CUSTCODE_FOR_CON(A.DOCKNO) D
        INNER JOIN dbo.brms BR WITH ( NOLOCK ) ON A.CURR_BRANCHCODE = BR.BRCD
        LEFT OUTER JOIN dbo.tblETAData ET WITH ( NOLOCK ) ON A.DOCKNO = ET.ConNo
        LEFT OUTER JOIN dbo.DKT_TRACK DK WITH ( NOLOCK ) ON A.DOCKNO = DK.DOCKNO
                                                            AND DK.srno = 1
--WHERE A.CURR_AREA = 'pnqa' AND A.DESTCD IN ('KLHF','SGLF','STRF')
WHERE   A.CURR_BRANCHCODE = A.DESTCD AND A.CURR_BRANCHCODE NOT LIKE '%UCG%' """)


# In[ ]:


df=pd.read_sql(query,Utilities.cnxn)


# In[95]:


dff3=df
dff3.columns


# In[96]:


# choices


# In[97]:


def fuzzyLogic(x):
    if x==None:
        return None
    elif (fuzz.partial_ratio('AMAZON'.lower(),x.lower()))>80:
#         v=fuzz.partial_ratio('Amazon'.lower(),x.lower())
        return "Amazon"
    elif (fuzz.partial_ratio('Cloudtail'.lower(),x.lower()))>80:
        return "CLOUDTAIL"
    else:
        return 0


# In[98]:


dff3['Test']=dff3.apply(lambda x:fuzzyLogic(x['DK_CSGENM']),axis=1)
dff3


# In[99]:


off=['a','AM','A','ANIL','n','D','IBD AMAZING BUY','m',
     'SANTOSH HANAMAGOND','l','C','CLOUD PACKERS MOVERS','SHAH ZAHEER BILAL SHAH (KHAMGAON)(MAIN)',
'AM',
'M',
'SLKA AMAZON SLLER SERVICE',
'MA',
'A',
'A T S DREAMZONE ',
'N','ANIL',
'D',
'C',
'ADIL',
'LO',
'U']
off


# In[100]:


REMOVE= dff3[~dff3['DK_CSGENM'].isin(off)]
dff4=REMOVE[((REMOVE.Test== 'Amazon')|(REMOVE.Test== 'CLOUDTAIL')) ]
dff4.columns
# len(dff4)


# In[101]:


dff4['ApptmntDelDate'] = dff4['ApptmntDelDate'].fillna('0')
# dff4.dtypes
dff4.head(2)


# In[102]:


def APTTAG (AP):
    if AP == '0'  :
        return 'APT not Take'
    else:
        return 'APT Taken'
    
dff4['APT_APN']=dff4.apply(lambda x:APTTAG(x['ApptmntDelDate']),axis=1)
# dff4.head(10)    


# In[103]:


APT_df=dff4[dff4.APT_APN == 'APT Taken']
APT_df


# In[104]:


APNdf=dff4[dff4.APT_APN == 'APT not Take']
APNdf


# In[105]:


table_APT=pd.pivot_table(APT_df,index=["CURR_AREA"],  
                  values= ['DOCKNO'],
                  aggfunc={'DOCKNO':len}).fillna(0)
# df['DOCKNO']=df['DOCKNO'].astype(int)
# table_APT


# In[106]:



table_APT['Total']=table_APT.sum(axis=1)

table_APT.sort_values('Total',ascending=False,inplace=True)

table_APT.loc['Total']=table_APT.sum(axis=0)




table_APT=table_APT.drop(columns=['Total'])
table_APT


# In[107]:


table_APN=pd.pivot_table(APNdf,index=["CURR_AREA"], 
                  values= ['DOCKNO'],
                  aggfunc={'DOCKNO':len} ).fillna(0)
# df['DOCKNO']=df['DOCKNO'].astype(int)
table_APN


table_APN['Total']=table_APN.sum(axis=1)

table_APN.sort_values('Total',ascending=False,inplace=True)

table_APN.loc['Total']=table_APN.sum(axis=0)




table_APN=table_APN.drop(columns=['Total'])
table_APN


# In[108]:


from pandas import ExcelWriter
# with ExcelWriter(r'D:\Data\Amazon\Amazon_Destn.xlsx') as writer:

# #     table_APT.to_excel(writer,engine='xlsxwriter',sheet_name='APT SUMMARY')
# #     table_APN.to_excel(writer,engine='xlsxwriter',sheet_name='APN SUMMARY')
#     APT_df.to_excel(writer,engine='xlsxwriter',sheet_name='Appointment Taken')
#     APNdf.to_excel(writer,engine='xlsxwriter',sheet_name='Appointment not Taken')
    
"done!!!"    


# In[117]:


APT_df.to_csv(r'D:\Data\Amazon\Appointment_Taken.csv')
APNdf.to_csv(r'D:\Data\Amazon\Appointment_not_Taken.csv')


# In[118]:


filePath=(r'D:\Data\Amazon\Appointment_Taken.csv')
filePath1=(r'D:\Data\Amazon\Appointment_not_Taken.csv')

for i in [filePath,filePath1]:
    
    oppath1=i

    
    #FTP Upload starts
    print ('Logging in...')
    ftp = ftplib.FTP()  
    ftp.connect('10.109.230.50')  
    print (ftp.getwelcome())

    try:
     try:
         ftp.login('HOSQTeam', 'Te@mH0$q')
         print ('login done')
         ftp.cwd('Auto_reports')
         #ftp.cwd('FIFO')
         # move to the desired upload directory
         print ("Currently in:", ftp.pwd())
         print ('Uploading...')
         fullname = oppath1
         name = os.path.split(fullname)[1]
         f = open(fullname, "rb")
         ftp.storbinary('STOR ' + name, f)
         f.close()
         print ("OK"  )
         print ("Files:")
         print (ftp.retrlines('LIST'))
     finally:
         print ("Quitting...")
         ftp.quit()
    except:
        traceback.print_exc()

    #date=datetime.strftime(datetime.now(),'%Y-%m-%d %H:%M:%S')


# In[119]:


from glob import glob
from IPython import display
from datetime import datetime,timedelta
import pyodbc

# date=datetime.strftime(datetime.now()-timedelta(2),'%Y-%m-%d-%H')
date=datetime.strftime(datetime.now(),'%Y-%m-%d-%H')
date

# ----------- E M A I L --------------------------    
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template                    


TO=['sharmistha.majumdar@spoton.co.in','reena.singhania@spoton.co.in',
'swati.sharma@spoton.co.in','spot_cstl@spoton.co.in','amazondeliveries@spoton.co.in']
# TO = ['sanjana.narayana@spoton.co.in']
CC=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in']
# CC= ['sanjana.narayana@spoton.co.in']
FROM="mis.ho@spoton.co.in"
BCC = ['sanjana.narayana@spoton.co.in']



msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = "Amazon Cons_lying @ Destn " + " - " + str(date)
html='''<html>
<style>        
p
 {
   margin:0;
   margin-top: 5px;
   padding:0;
   font-size:15px;
   line-height:20px;
 }
</style>                


'''
# html3='''
# <h5> To download File, Please click the link below </h5>
# <p><a href= http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/BA_TREND.xlsx </a>
# http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/BA_TREND.xlsx </p>
# '''
report=""
report+='<br>'
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='Appointment Taken- Summary '
report+='<br>'
report+='<br>'+table_APT.to_html()+'<br>'
report+='<br>'
report+='Appointment not Taken- Summary '
report+='<br>'
report+='<br>'+table_APN.to_html()+'<br>'
report+='<br>'
report+=html
# report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)

part = MIMEBase('application', "octet-stream")
part.set_payload( open(filePath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
msg.attach(part)

part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(filePath1,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath1))
msg.attach(part1)


server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login('spoton.net.in', 'Star@123#')
failed = server.sendmail(FROM, 
                         CC+
                         TO+
                         
                         BCC, msg.as_string())
print ('mail sent')
server.quit()


# In[ ]:


# dff3[dff3['CSGENM']=='AMAZONE RETAIL INDIA PVT LTD'][['CSGENM','CSGENM_2']]


# In[ ]:


# dff3[['CSGENM',"CSGENM_2"]]


# In[ ]:


# df.to_csv(r'E:\Undel_Data.csv')

