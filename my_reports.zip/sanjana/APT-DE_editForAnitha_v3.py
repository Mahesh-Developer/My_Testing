
# coding: utf-8

# In[11]:


import numpy as np
import pandas as pd
# import matplotlib.pyplot as plt
# import seaborn
from glob import glob
from IPython import display
from datetime import datetime,timedelta
import pyodbc
# import geopy
import pandas as pd
import Utilities


# In[12]:

# try:

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


# In[13]:
try:

  month1=int(datetime.strftime(datetime.now(),'%m'))
  month1


  # In[14]:


  Year1=int(datetime.strftime(datetime.now(),'%Y'))
  Year1


  # In[5]:


  yest=datetime.now()-timedelta(1)
  enddate=yest.date()
  enddate=str(enddate)

  startdate=datetime.strftime((datetime.today().replace(day=1,month=month1,year=Year1)),'%Y-%m-%d')
  # startdate
  [[enddate,startdate]]


  # In[6]:


  query= """ EXEC dbo.USP_APT_DELV_PERFRMC_DAILY_SQ '{0}','{1}'   """ .format(startdate,enddate)
  # query= """ EXEC dbo.USP_APT_DELV_PERFRMC_DAILY_SQ '{0}','{1}'   """ .format('2019-03-05','2019-03-07')
  print (query)


  # In[7]:


  rawDATA=pd.read_sql(query,Utilities.cnxn)
  rawDATA.head()


  # In[8]:


  Q1=pd.read_sql(query,Utilities.cnxn)
  Q2=pd.read_sql(query,Utilities.cnxn)


  # In[9]:


  Q1=Q1[Q1.Con_Category == 'e-Commerce']


  # In[10]:


  Q1.rename(columns={'PERFORMANCE':'Perf_Y_N'}, inplace=True)

  Q1['APT_DATE']=pd.to_datetime(Q1['APT_DATE'])

  Q1['APT_DATE1']=Q1['APT_DATE'].apply(lambda x:(datetime.strftime(x,'%A')[:3]))

  Q1['APT_DATE']=Q1['APT_DATE'].astype(str)+' '+Q1['APT_DATE1']
  Q1['APT_DATE']


  # In[11]:



  def tagPERF (PERF):     
  #### tag is the name of the function, z is the variable which inherits the values in 'APORDER' column, 
  ###  then it goes on to test the condition
      if PERF== 'YES' :
          return 'SUCCESS'
      else:
          return 'FAILURE'
      


  # In[12]:


  Q1['E-Commerce PERFORMANCE'] = Q1.apply(lambda x:tagPERF(x['Perf_Y_N']), axis=1)


  # In[13]:


  Q1['E-Commerce PERFORMANCE'].head()


  # In[14]:


  # DF=pd.DataFrame(data=Q1, index=[ 'APT_DATE'], columns=['PERFORMANCE'])

  # class pandas.DataFrame(data=None, index=None, columns=None, dtype=None, copy=False)


  # In[15]:


  # DF


  # In[16]:


  df=pd.pivot_table(Q1, index=["APT_DATE"], columns=["E-Commerce PERFORMANCE"], values=['DOCKNO'], aggfunc={'DOCKNO':len},margins=True)
  df


  # In[17]:


  df['SUCCESS Total %']=pd.np.round((df['DOCKNO','SUCCESS']/df['DOCKNO','All'])*100,0).astype(int)
  df['FAILURE Total %']=pd.np.round((df['DOCKNO','FAILURE']/df['DOCKNO','All'])*100,0).astype(int)
  df['FAILURE Total %']=df['FAILURE Total %'].astype(str)+'%'
  df['SUCCESS Total %']=df['SUCCESS Total %'].astype(str)+'%'
  Ecom=df[['SUCCESS Total %','FAILURE Total %']].tail(2)
  Ecom


  # In[18]:


  Q2.rename(columns={'PERFORMANCE':'Perf_Y_N'}, inplace=True)

  Q2['APT_DATE']=pd.to_datetime(Q2['APT_DATE'])

  Q2['APT_DATE1']=Q2['APT_DATE'].apply(lambda x:(datetime.strftime(x,'%A')[:3]))

  Q2['APT_DATE']=Q2['APT_DATE'].astype(str)+' '+Q2['APT_DATE1']
  Q2['APT_DATE']


  # In[19]:


  Q2=Q2[Q2.Con_Category == 'Non e-Commerce']
  Q2.rename(columns={'PERFORMANCE':'Perf_Y_N'}, inplace=True)


  # In[20]:


  def tagPERF2 (PERF2):     
  #### tag is the name of the function, z is the variable which inherits the values in 'APORDER' column, 
  ###  then it goes on to test the condition
      if PERF2 == 'YES' :
          return 'SUCCESS'
      else:
          return 'FAILURE'


  # In[21]:


  Q2['Non e-Commerce PERFORMANCE'] = Q2.apply(lambda x:tagPERF2(x['Perf_Y_N']), axis=1)


  # In[22]:


  df2=pd.pivot_table(Q2, index=["APT_DATE"], columns=["Non e-Commerce PERFORMANCE"], values=['DOCKNO'], aggfunc={'DOCKNO':len},margins=True)
  df2


  # In[23]:


  df2['SUCCESS Total %']=pd.np.round((df2['DOCKNO','SUCCESS']/df2['DOCKNO','All'])*100,0).astype(int)
  df2['FAILURE Total %']=pd.np.round((df2['DOCKNO','FAILURE']/df2['DOCKNO','All'])*100,0).astype(int)
  df2['FAILURE Total %']=df2['FAILURE Total %'].astype(str)+'%'
  df2['SUCCESS Total %']=df2['SUCCESS Total %'].astype(str)+'%'
  nonEcom=df2[['SUCCESS Total %','FAILURE Total %']].tail(2)
  nonEcom


  # In[24]:


  from glob import glob
  from IPython import display
  from datetime import datetime,timedelta
  import pyodbc

  date=datetime.strftime(datetime.now(),'%Y-%m-%d-%H')


  # In[25]:


  import smtplib
  from email.mime.multipart import MIMEMultipart
  from email.mime.text import MIMEText
  from email.mime.base import MIMEBase
  from email import encoders
  import os
  from string import Template                    


  TO=['sharanagouda.biradar@spoton.co.in','anitha.thyagarajan@spoton.co.in']
  # TO=['sanjana.narayana@spoton.co.in']
  FROM="mis.ho@spoton.co.in"
  # CC = ['sanjana.narayana@spoton.co.in']


  BCC = ['sanjana.narayana@spoton.co.in']


  msg = MIMEMultipart()
  msg["From"] = FROM
  # msg["To"] = ",".join(TO)
  # msg["CC"] = ",".join(CC)
  msg["BCC"] = ",".join(BCC)
  msg["Subject"] = " APT_DE- summary " + " - " + str(date)
  html='''<html>
  <style>        
  p
   {
     margin:0;
     margin-top: 5px;
     padding:0;
     font-size:15px;
     line-height:20px;
   }
  </style>                


   '''
  # html3='''
  # <h5> To download File, Please click the link below </h5>
  # <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/APT_DE_"+str(today)+".xlsx"</a>
  # "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/APT_DE.xlsx"</p>
  # '''
  report=""
  report+='<br>'
  report+='Hello,'
  report+='<br>'
  report+='<br>'
  report+=' Please find below, summary of Appointment DE for your reference.'
  report+='<br>'
  report+='<br>'
  report+='E- COMMERCE.'
  report+='<br>'
  report+='<br>'+Ecom.to_html()+'<br>'
  report+='<br>'
  report+='<br>'
  report+='NON- E COMMERCE.'
  report+='<br>'
  report+='<br>'+nonEcom.to_html()+'<br>'
  report+='<br>'
  report+='<br>'

  report+=html
  abc=MIMEText(report,'html')
  msg.attach(abc)
  part = MIMEBase('application', "octet-stream")
  # part.set_payload( open(oppath1,"rb").read() )
  # encoders.encode_base64(part)
  # part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
  # msg.attach(part)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login('spoton.net.in', 'Star@123#')
  failed = server.sendmail(FROM, TO+BCC, msg.as_string())
  print ('mail sent')
  server.quit()

except:

  #TO=['sharanagouda.biradar@spoton.co.in','anitha.thyagarajan@spoton.co.in']
  TO=['sanjana.narayana@spoton.co.in']
  FROM="mis.ho@spoton.co.in"
  # CC = ['sanjana.narayana@spoton.co.in']


  BCC = ['sanjana.narayana@spoton.co.in']


  msg = MIMEMultipart()
  msg["From"] = FROM
  # msg["To"] = ",".join(TO)
  # msg["CC"] = ",".join(CC)
  # msg["BCC"] = ",".join(BCC)
  msg["Subject"] = " ***ERROR REPORT***- APT_DE- summary " + " - " + str(date)
  html='''<html>
  <style>        
  p
   {
     margin:0;
     margin-top: 5px;
     padding:0;
     font-size:15px;
     line-height:20px;
   }
  </style>                


   '''
  # html3='''
  # <h5> To download File, Please click the link below </h5>
  # <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/APT_DE_"+str(today)+".xlsx"</a>
  # "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/APT_DE.xlsx"</p>
  # '''
  report=""
  report+='<br>'
  report+='Hello,'
  report+='<br>'
  report+='<br>'
  report+=' THIS EMAIL HAS NOT BEEN SENT. PLEASE CHECK!'
  report+='<br>'
  report+='<br>'
  report+= "***ERROR REPORT***- APT_DE- summary " + " - " + str(date)
  report+='<br>'

  report+=html
  #abc=MIMEText(report,'html')
  msg.attach(abc)
  part = MIMEBase('application', "octet-stream")
  # part.set_payload( open(oppath1,"rb").read() )
  # encoders.encode_base64(part)
  # part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
  # msg.attach(part)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login('spoton.net.in', 'Star@123#')
  failed = server.sendmail(FROM, TO+BCC, msg.as_string())
  print ('ERROR ***** mail sent')
  server.quit()



