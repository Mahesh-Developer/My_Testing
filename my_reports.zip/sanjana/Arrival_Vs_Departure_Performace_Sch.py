
# coding: utf-8

# In[ ]:


import pandas as pd
import numpy as np
from datetime import datetime,timedelta
import pyodbc
from fuzzywuzzy import fuzz
import pandas as pd
import pyodbc
from datetime import datetime,timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
import ftplib
# import Utilities
from calendar import monthrange
import smtplib


# In[ ]:


todate=datetime.strftime(datetime.now()-timedelta(days=1),"%d/%m/%Y")


# In[ ]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")


# In[ ]:


df=pd.read_sql("EXEC dbo.Pro_CNM_Daily_Report_New",cnxn)


# In[ ]:


print (len(df))


# In[ ]:


df=df[df['RouteCode']!='9888']
print (len(df))


# In[ ]:


def getStrip(x):
    vals=x.split('-')
    f=[i.strip(' ') for i in vals]
    f2='-'.join(f)
    return f2


# In[ ]:


df['Route Path1']=df.apply(lambda x:getStrip(x['Route Path']),axis=1)


# In[ ]:


selected_routes=['DELH-BLRH','CJBH-SXVF-BLRH-JAIH-DELH','MAAH-HYDH-JAIH-DELH','DELH-SXVF-CJBH','CCUH-NAGH-BOMH','MAAH-NDAH','DELH-MAAB','BLRH-HYDH-AMCH',
'MAAH-DELH','NDAH-BLRH','BOMH-CCUH','DELH-HYDH-MAAB','CCUH-BLSF-BBIH-BLRH','KNPH-HYDH-BLRH','BLRH-BBIH-BLSF-CCUH','MAAH-AMCH','CCUH-IXRB-PNQH',
'BLRH-HYDH-GLBF-BOMH','AMCH-HYDH-MAAB','BLRH-HYDH-KNPH','AMCH-BLRH','BOMH-CJBH-COKH','AMCH-SNRH-PNQH','COKH-CJBH-SXVF-BOMH','PNQH-NAGH-CCUH',
'PNQH-SNRH-KNPH-LKOH','BLRH-AMDH','CCUH-KNPH-DELH','AMCH-IDRH-BOMH','BBIH-ANGL-SMBH-NAGH','MAAH-HYDH-VPIH-AMDH','DELH-VPIH-BOMH','PNQH-SNRH-DELH',
'NDAH-VPIH-BOMH','DELH-CCUH','CCUH-BBIH-VZAH-MAAB','AMDH-BLRH','BLRH-DELH','MAAH-HYDH-PNQH','LKOH-KNPH-SNRH-PNQH','VZAH-HYDH-BOMH','BLRH-JAIH-NDAH',
'PATH-KNPH-BOMH','DELH-IDRH-PTMF-BOMH','DELH-HYDH','HYDH-DELH','NAGH-SMBH-BBIH','DELH-PNQH','PNQH-MAAB','NAGH-IDRH-JAIH-DELH','PNQH-SXVF-CJBH',
'MAAH-BOMH','DELH-IDRH-NAGH','NDAH-CCUH','BOMH-BLRH-SXVF','DELH-BOMH','BOMH-IDRH-KNPH-LKOH','BOMH-VPIH-DELH','DELH-SNRH-PNQH','CJBH-SXVF-BLRH-PNQH','BOMH-BLRH',
'HYDH-BOMH','BLRH-BOMH','BOMH-MAAB','JAIH-BOMH','AMDH-DELH','PNQH-BGMH-GOIB','BLRH-PNQH','BOMH-HYDH','DELH-AMDH','PNQH-BLRH','PNQH-SNRH-IDRH',
'SXVF-BLRH-BOMH','AMDH-BDQH-BOMH','BLRH-BLRT-MAAB','AMCH-NDAH','MAAH-BLRT-BLRH','GOIB-BGMH-STRF-BOMH','LKOH-KNPH-IDRH-BOMH','BOMH-DELH','AMDH-VPIH-HYDH-MAAB',
'BOMH-BDQH-AMDH','NDAH-HYDH-MAAB','DELH-KNPH-CCUH','MAAH-BLRH','BOMH-BGMH-GOIB','BLRH-BGMH-BOMH','BOMH-HYDH-VZAH','PNQH-SNRH-AMCH','GOIB-BGMH-PNQH',
'BLRH-MAAB','PNQH-DELH']


# In[ ]:


df.columns


# In[ ]:


# df.drop_duplicates('THC Number',inplace=True)


# In[ ]:


# selected_routes=['NDAH-HYDH-MAAB','CCUH-NAGH-BOMH','BOMH-CCUH','MAAH-HYDH-JAIH-DELH','BLRH-HYDH-AMCH','PNQH-NAGH-CCUH','CCUH-BLSF-BBIH-BLRH',
# 'CCUH-IXRB-PNQH','KNPH-HYDH-BLRH','BOMH-PATH','COKH-CJBH-SXVF-BOMH','BLRH-DELH','PATH-KNPH-BOMH','CCUH-KNPH-DELH','AMDH-VPIH-HYDH-MAAB',
# 'DELH-BOMH','MAAH-HYDH-VPIH-AMDH','MAAH-BOMH','DELH-CCUH','CCUH-BBIH-VZAH-MAAB','NDAH-BLRH','BLRH-HYDH-KNPH','DELH-IDRH-NAGH',
# 'PATH-KNPH-BOMH','LKOH-KNPH-SNRH-PNQH','PNQH-SNRH-KNPH-LKOH','AMDH-BLRH','BOMH-CJBH-COKH','BOMH-IDRH-KNPH-LKOH','PNQH-SNRH-AMCH',
# 'BOMH-JAIH','NDAH-CCUH','DELH-VPIH-BOMH','BOMH-PATH','BOMH-VPIH-AMCH','DELH-SNRH-PNQH','AMCH-IDRH-BOMH','MAAH-HYDH-PNQH','DELH-KNPH-CCUH',
# 'DELH-HYDH','BOMH-HYDH-VZAH','COKH-CJBH-SXVF-BOMH','BOMH-MAAB','BOMH-DELH','CJBH-SXVF-BLRH-PNQH','BOMH-BLRH','GOIB-BGMH-STRF-BOMH',
# 'BBIH-ANGL-SMBH-NAGH','HYDH-BOMH','BOMH-VPIH-DELH','PNQH-DELH','DELH-AMDH','BLRH-BOMH','VZAH-HYDH-BOMH','NAGH-SMBH-BBIH','BOMH-BLRH',
# 'LKOH-KNPH-SNRH-PNQH','PNQH-BGMH-GOIB','BOMH-DELH','BOMH-HYDH','BOMH-BLRH','PNQH-BLRH','BOMH-BDQH-AMDH','DELH-BOMH','BLRH-PNQH','MAAH-BOMH',
# 'PNQH-DELH','DELH-PNQH','MAAH-HYDH-PNQH','BOMH-MAAB','HYDH-DELH','JAIH-BOMH','DELH-AMDH','PNQH-SNRH-IDRH','BOMH-DELH','BOMH-BGMH-GOIB',
# 'DELH-BOMH','PNQH-MAAB','BLRH-PNQH','BLRH-BGMH-BOMH','DELH-AMDH','PNQH-BLRH','GOIB-BGMH-PNQH','BLRH-BLRT-MAAB','GOIB-BGMH-PNQH',
# 'PNQH-BLRH','BLRH-AMDH','BOMH-DELH','HYDH-BOMH','PNQH-DELH','DELH-CCUH','AMDH-DELH','BLRH-BOMH','MAAH-HYDH-VPIH-AMDH','BOMH-BLRH',
# 'DELH-HYDH','CCUH-NAGH-BOMH','BOMH-VPIH-DELH','HYDH-DELH','MAAH-NDAH','CCUH-KNPH-DELH','VZAH-HYDH-BOMH','DELH-MAAB','PNQH-BGMH-GOIB','BLRH-HYDH-AMCH',
# 'BOMH-BDQH-AMDH','DELH-AMDH','BOMH-BLRH','BBIH-ANGL-SMBH-NAGH','AMDH-VPIH-HYDH-MAAB','BLRH-PNQH','MAAH-DELH','CJBH-SXVF-BLRH-JAIH-DELH','NDAH-BLRH',
# 'DELH-VPIH-BOMH','BOMH-HYDH','PNQH-BLRH','BLRH-JAIH-NDAH','AMDH-BLRH','DELH-PNQH','CJBH-SXVF-BLRH-PNQH','CCUH-BBIH-VZAH-MAAB','NDAH-VPIH-BOMH',
# 'PNQH-SNRH-DELH','PNQH-SNRH-KNPH-LKOH','BOMH-CCUH','MAAH-BOMH','DELH-BLRH','BLRH-AMDH','LKOH-KNPH-SNRH-PNQH','BOMH-MAAB','AMDH-BDQH-BOMH',
# 'MAAH-HYDH-PNQH','DELH-KNPH-CCUH','PATH-KNPH-BOMH','BLRH-MAAB','BOMH-DELH','DELH-HYDH-MAAB','MAAH-BLRH','DELH-IDRH-NAGH','CCUH-BLSF-BBIH-BLRH',
# 'LKOH-KNPH-IDRH-BOMH','KNPH-HYDH-BLRH','PNQH-SNRH-IDRH','BLRH-BBIH-BLSF-CCUH','MAAH-AMCH','NAGH-IDRH-JAIH-DELH','CCUH-IXRB-PNQH','BOMH-BGMH-GOIB',
# 'JAIH-BOMH','BLRH-HYDH-GLBF-BOMH','PNQH-MAAB','PNQH-SNRH-AMCH','AMCH-HYDH-MAAB','SXVF-BLRH-BOMH','DELH-BOMH','BOMH-HYDH-VZAH','BLRH-HYDH-KNPH',
# 'BLRH-PNQH','DELH-HYDH-MAAB','BLRH-BGMH-BOMH','AMCH-BLRH','MAAH-HYDH-JAIH-DELH','BOMH-BLRH-SXVF','BOMH-CJBH-COKH','NAGH-SMBH-BBIH',
# 'BOMH-PATH','DELH-SXVF-CJBH','DELH-AMDH','NDAH-CCUH','DELH-IDRH-PTMF-BOMH','AMDH-BLRH','BOMH-IDRH-KNPH-LKOH','PNQH-BLRH','AMCH-SNRH-PNQH',
# 'DELH-SNRH-PNQH','PNQH-MAAB','AMCH-NDAH','NDAH-BLRH','MAAH-BLRT-BLRH','COKH-CJBH-SXVF-BOMH','BOMH-BLRH','AMCH-HYDH-MAAB','DELH-BLRH',
# 'BOMH-DELH','DELH-IDRH-NAGH','AMCH-BLRH','BLRH-BLRT-MAAB','PNQH-SXVF-CJBH','GOIB-BGMH-PNQH','AMDH-DELH','GOIB-BGMH-STRF-BOMH','PNQH-NAGH-CCUH','PNQH-SNRH-KNPH-LKOH'
# ]


# In[ ]:


df=df[df['Route Path1'].isin(selected_routes)]
print ('df',len(df))


# In[ ]:

print (df['ACT_Arr_Date'].unique())
arrvdf=df[df['CNM_ArrDate']==todate]
print ('arrvdf',len(arrvdf))


# In[ ]:


## Arrival Summary 


# In[ ]:


advance_exception=['Money','Advance Issue','Advance Payment Issue','Advance Payment']
accident_exception=['Accidents','Turn Down On','Out Of Coverage Area','Hold At Same Place']
weather_exception=['Heavy Rain','Rainy','Rain']
breakdown_exception=['Veh Breakdown','Vehicle Breakdown','Breakdown','Break down','Break Down','Repair','Starting','tarting']
rto_exception=['RTO','Rto','rto']
driver_exception=['Late Arrived','Driver Not Pick The Phone','Number Is Not Connecting','Driver Number Is Not Connecting','Not Getting Address','Driver Issue','Driver Not Given Delay Reason','Delay Reason Driver Not Given','Vehicle Delay Due To Breakdown','Its Getting Delay Due To Second Driver Not Felling Well']
driver_delay_exception=['Vehicle Late Arrived','Driver Not Given Delay','Driver Not Given Delay Reason','Driver Not Pick The Phone']
festival_exception=['Festival']
touching_excepton=['Vehicle Hold At','Extra Touching','EXTRA TOUCHING','touching point','Touching Location','extra touching given','Extra Hold','Due To Extra Hold']
noentry_exception=['No Entry']
roadblock_exception=['Road Block','Road Blocked By Police','Road Blocked']
routedivert_exception=['Route Divert']
singledriver_exception=['Single Driver','Driver No. Continues Busy']
traficjam_exception=['Heavy Jam','Vehicle Late Arrived Due To Traffic Jam','Face Jam','Traffic','traffic','traffic jam','Traffic Jam']
salestax_exception=['Sale Tax Officer','Sale']
ontime_exception=['Ontime','ontime']


# In[ ]:


def getArrvExc(x):
    if x=='-':
        return x
    elif any(ele in x for ele in advance_exception):
        return "Advance Money"
    elif any(ele in x for ele in accident_exception):
        return "Accident"
    elif any (ele in x for ele in weather_exception):
        return "Bad Weather"
    elif any (ele in x for ele in breakdown_exception):
        return "Breakdown"
    elif any (ele in x for ele in rto_exception):
        return "Caught By RTO"
    elif any (ele in x for ele in driver_delay_exception):
        return "Driver Not Given Delay Reason"
    elif any (ele in x for ele in festival_exception):
        return "Festival"
    elif any (ele in x for ele in touching_excepton):
        return "Extra Hold At Touching Loc"
    elif any (ele in x for ele in noentry_exception):
        return "No Entry"
    elif any (ele in x for ele in roadblock_exception):
        return "Road Block"
    elif any (ele in x for ele in routedivert_exception):
        return "Route Divert"
    elif any (ele in x for ele in singledriver_exception):
        return "Single Driver"
    elif any (ele in x for ele in traficjam_exception):
        return "Traffic Jam"
    elif any (ele in x for ele in driver_exception):
        return "Driver issue"
    elif any (ele in x for ele in salestax_exception):
        return "Caught By Sale Tax Officer"
#     elif any (ele in x for ele in ontime_exception):
#         return "Ontime"
    else:
        pass


# In[ ]:


arrvdf['Arrival_Exception']=arrvdf.apply(lambda x:getArrvExc(x['Remarks']),axis=1)


# In[ ]:


arrvdf['Lane']=arrvdf['THC_Origin']+'-'+arrvdf['THC_DEST']


# In[ ]:


def f1(x,y):
    if x=='OnTime Arrival' and y=='Extra Hold At Touching Loc':
        return None
    else:
        return y


# In[ ]:


arrvdf['Arrival_Exception']=arrvdf.apply(lambda x:f1(x['Is Ontime  Arrival'],x['Arrival_Exception']),axis=1)


# In[ ]:


arrvsummary=arrvdf[arrvdf['Is Ontime  Arrival']!='-'].pivot_table(index=['THC_DEST'],columns=['Is Ontime  Arrival'],values=['THC Number'],aggfunc={'THC Number':len}).fillna(0)


# In[ ]:


arrvsummary


# In[ ]:


if 'Reached Early' in df['Is Ontime  Arrival'].unique().tolist():
    pass
else:
    arrvsummary[('THC Number','Reached Early')]=0.0


# In[ ]:


# arrvsummary[('THC Number','ONTIME ARRIVAL')]=arrvsummary[('THC Number','ONTIME ARRIVAL')]+arrvsummary[('THC Number','EARLY_ARRIVAL')]
arrvsummary[('THC Number','OnTime Arrival')]=arrvsummary[('THC Number','OnTime Arrival')]+arrvsummary[('THC Number','Reached Early')]


# In[ ]:


# del arrvsummary[('THC Number','EARLY_ARRIVAL')]
del arrvsummary[('THC Number','Reached Early')]


# In[ ]:


# arrvsummary[('THC Number','Total')]=arrvsummary[('THC Number','ONTIME ARRIVAL')]+arrvsummary[('THC Number','LATE ARRIVAL')]
arrvsummary[('THC Number','Total')]=arrvsummary[('THC Number','OnTime Arrival')]+arrvsummary[('THC Number','Delayed')]


# In[ ]:


arrvsummary.loc['Total']=arrvsummary.sum(axis=0)


# In[ ]:


arrvsummary[('THC Number','Ontime%')]=pd.np.round(arrvsummary[('THC Number','OnTime Arrival')]*100.0/arrvsummary[('THC Number','Total')],0)


# In[ ]:


arrvsummary.sort_values(('THC Number','Ontime%'),ascending=True,inplace=True)


# In[ ]:


##Lane wise Arrival Performance


# In[ ]:


arrvlanesummary=arrvdf.pivot_table(index=['Lane'],columns=['Is Ontime  Arrival'],values=['THC Number'],aggfunc={'THC Number':len}).fillna(0)


# In[ ]:


if 'Reached Early' in df['Is Ontime  Arrival'].unique().tolist():
    pass
else:
    arrvlanesummary[('THC Number','Reached Early')]=0.0


# In[ ]:


arrvlanesummary[('THC Number','ONTIME ARRIVAL')]=arrvlanesummary[('THC Number','OnTime Arrival')]+arrvlanesummary[('THC Number','Reached Early')]
del arrvlanesummary[('THC Number','Reached Early')]

arrvlanesummary[('THC Number','Total')]=arrvlanesummary[('THC Number','OnTime Arrival')]+arrvlanesummary[('THC Number','Delayed')]
arrvlanesummary.loc['Total']=arrvlanesummary.sum(axis=0)
arrvlanesummary[('THC Number','Ontime%')]=pd.np.round(arrvlanesummary[('THC Number','OnTime Arrival')]*100.0/arrvlanesummary[('THC Number','Total')],0)


# In[ ]:


# arrvlanesummary.sort_values(('THC Number','Ontime%'),ascending=True,inplace=True)


# In[ ]:


arrvlaneexcepsummary=arrvdf.pivot_table(index=['Lane'],columns=['Arrival_Exception'],values=['THC Number'],aggfunc={'THC Number':len}).fillna(0)


# In[ ]:


arrvlaneexcepsummary.loc['Total']=arrvlaneexcepsummary.sum(axis=0)


# In[ ]:


## Departure Summary


# In[ ]:


deptdf=df[df['ActDept_Date']==todate]
len(deptdf)


# In[ ]:


deptdf['THC_DEST']=deptdf['Route Path1'].apply(lambda x:x.split('-')[-1])

excess_load=['due to excess load','touching','EARLY DUE TO EXCESS LOAD','EARLY','second vehicle operate same day same route','EXTRA VEH OPERATED DUE TO HEAVY LOAD','DUE TO EXTRA VEH DEPARTED DUE TO EXCESS LOAD','second veh operate same day same route','excess load','second vehicle operate same route due to excess load..','2ND VEH OPERAT SAME ROUTE','same rout second vehicle operated due to excess load','due to excess load','DUE TO EXCESS LOAD','2ND VEH OPRATE IN SAME ROUTE','Central seal no','second vehicle operated due to excess load','DUE TO 2ND VEH','2nd vehicle operated due to excess loaded','due to excess load','2ND VEH OPRATED DUE TO EXCESS LOAD','extra veh operate due to excess load']


def zyx(x,y):
    if (x=='LATE DEPARTURE') and (any(ele in y for ele in excess_load)):
        return 'ONTIME DEPARTURE'
    else:
        return x

deptdf['DEPARTURE_STATUS']=deptdf.apply(lambda x: zyx(x['DEPARTURE_STATUS'],x['Departure Delay Reason']),axis=1)


deptsummary=deptdf.pivot_table(index=['THC_Origin'],columns=['DEPARTURE_STATUS'],values=['THC Number'],aggfunc={'THC Number':len}).fillna(0)


# In[ ]:
print (deptsummary.head())

if 'EARLY_DEPARTURE' in deptdf['DEPARTURE_STATUS'].unique().tolist():
    pass
else:
    deptsummary[('THC Number','EARLY_DEPARTURE')]=0.0


# In[ ]:


deptsummary[('THC Number','ONTIME DEPARTURE')]=deptsummary[('THC Number','EARLY_DEPARTURE')]+deptsummary[('THC Number','ONTIME DEPARTURE')]


# In[ ]:


del deptsummary[('THC Number','EARLY_DEPARTURE')]


# In[ ]:


deptsummary[('THC Number','Total')]=deptsummary[('THC Number','ONTIME DEPARTURE')]+deptsummary[('THC Number','LATE DEPARTURE')]


# In[ ]:


deptsummary.loc['Total']=deptsummary.sum(axis=0)


# In[ ]:


deptsummary[('THC Number','Ontime%')]=pd.np.round(deptsummary[('THC Number','ONTIME DEPARTURE')]*100.0/deptsummary[('THC Number','Total')],0)


# In[ ]:


deptdf['Lane']=deptdf['THC_Origin']+'-'+deptdf['THC_DEST']


# In[ ]:


deptlanesummary=deptdf.pivot_table(index=['Lane'],columns=['DEPARTURE_STATUS'],values=['THC Number'],aggfunc={'THC Number':len}).fillna(0)


# In[ ]:


if 'EARLY_DEPARTURE' in deptdf['DEPARTURE_STATUS'].unique().tolist():
    pass
else:
    deptlanesummary[('THC Number','EARLY_DEPARTURE')]=0.0


# In[ ]:


deptlanesummary[('THC Number','ONTIME DEPARTURE')]=deptlanesummary[('THC Number','EARLY_DEPARTURE')]+deptlanesummary[('THC Number','ONTIME DEPARTURE')]


# In[ ]:


del deptlanesummary[('THC Number','EARLY_DEPARTURE')]


# In[ ]:


deptlanesummary[('THC Number','Total')]=deptlanesummary[('THC Number','ONTIME DEPARTURE')]+deptlanesummary[('THC Number','LATE DEPARTURE')]


# In[ ]:


deptlanesummary.loc['Total']=deptlanesummary.sum(axis=0)


# In[ ]:


deptlanesummary[('THC Number','Ontime%')]=pd.np.round(deptlanesummary[('THC Number','ONTIME DEPARTURE')]*100.0/deptlanesummary[('THC Number','Total')],0)


# In[ ]:


#no_remarks=['ok','OK.','OK','Ok']
same_veh_load_unload=['SAME VEH UNLOAD & LOAD']
less_load=['less load','DUE TO LESSLOAD','VEH LATE DEPT DUE TO LESS LOAD','veh less load showing','due to less load']
second_vehicle=['second vehicle operate same route code','due to second vehicle']
excess_load=['due to excess load','DUE TO EXCESS LOAD']
route_ven_not_standing=['route veh not standing','route veh not standing','standing vehicle not available']
vendor_issue=['DUE TO VENDOR LATE PROVIDE']
vehicle_late_arrived=['VEH LATE ARRIVAL','veh late arrival due to veh late departure','vech late depart due to vech late provided','vech late depart due to vech late arriv']


# In[ ]:


def depRemarks(x,y):
    if (y=='LATE DEPARTURE') and (any(ele in x for ele in same_veh_load_unload)):
        return "SAME VEH UNLOAD  LOAD"
    elif (y=='LATE DEPARTURE') and (any(ele in x for ele in less_load)):
        return "Late Dep Due to less load"
    elif (y=='LATE DEPARTURE') and (any(ele in x for ele in second_vehicle)):
        return "Second Vehicle Operated"
    elif (y=='LATE DEPARTURE') and (any(ele in x for ele in excess_load)):
        return "Excess Load"
    elif (y=='LATE DEPARTURE') and (any(ele in x for ele in vendor_issue)):
        return "Vendor Issue"
    elif (y=='LATE DEPARTURE') and (any(ele in x for ele in vehicle_late_arrived)):
        return "route veh not standing"
    elif y in ['EARLY_DEPARTURE','ONTIME DEPARTURE']:
        return None
    else:
        return "No Remarks in THC"
    


# In[ ]:


deptdf['Departure_Exception']=deptdf.apply(lambda x:depRemarks(x['Departure Delay Reason'],x['DEPARTURE_STATUS']),axis=1)


# In[ ]:


# deptdf[deptdf['DEPARTURE_STATUS']=='LATE DEPARTURE'][['THC Number','DEPARTURE_STATUS','Departure Delay Reason','Departure_Exception']].to_csv(r'Dep_exce.csv')


# In[ ]:


deptdf_exce_summary=deptdf[deptdf['DEPARTURE_STATUS']=='LATE DEPARTURE'].pivot_table(index=['THC_Origin','Route Path1','THC Number','DelayTime','Departure_Exception']).fillna(0).reset_index()


# In[ ]:


deptdf_exce_summary=deptdf_exce_summary[['THC_Origin','Route Path1','THC Number','DelayTime','Departure_Exception']]


# In[ ]:

from pandas import ExcelWriter
#writer = pd.ExcelWriter(r'D:\Data\CNM_Arrv_Dep\Arrv vs Departure\CNM_Depar_Arrival_Report_'+str(todate)+'.xlsx', engine='xlsxwriter')
todate1=datetime.strftime(datetime.now()-timedelta(days=1),"%Y-%m-%d")
df.to_csv(r'D:\Data\CNM_Arrv_Dep\Arrv vs Departure\Data'+str(todate1)+'.csv')
arrvsummary.to_csv(r'D:\Data\CNM_Arrv_Dep\Arrv vs Departure\HubWise_late_arrival'+str(todate1)+'.csv')
arrvlanesummary.to_csv(r'D:\Data\CNM_Arrv_Dep\Arrv vs Departure\Lanewise_late_arrival'+str(todate1)+'.csv')
arrvlaneexcepsummary.to_csv(r'D:\Data\CNM_Arrv_Dep\Arrv vs Departure\Arrival_Exception_summary'+str(todate1)+'.csv')
deptsummary.to_csv(r'D:\Data\CNM_Arrv_Dep\Arrv vs Departure\HubWise_Departure_summary'+str(todate1)+'.csv')
deptlanesummary.to_csv(r'D:\Data\CNM_Arrv_Dep\Arrv vs Departure\Lanewise_Departure_summary'+str(todate1)+'.csv')
deptdf_exce_summary.to_csv(r'D:\Data\CNM_Arrv_Dep\Arrv vs Departure\Dep_Exception_summary'+str(todate1)+'.csv')


df.to_csv(r'D:\Data\CNM_Arrv_Dep\Arrv vs Departure\Data.csv')
arrvsummary.to_csv(r'D:\Data\CNM_Arrv_Dep\Arrv vs Departure\HubWise_late_arrival.csv')
arrvlanesummary.to_csv(r'D:\Data\CNM_Arrv_Dep\Arrv vs Departure\Lanewise_late_arrival.csv')
arrvlaneexcepsummary.to_csv(r'D:\Data\CNM_Arrv_Dep\Arrv vs Departure\Arrival_Exception_summary.csv')
deptsummary.to_csv(r'D:\Data\CNM_Arrv_Dep\Arrv vs Departure\HubWise_Departure_summary.csv')
deptlanesummary.to_csv(r'D:\Data\CNM_Arrv_Dep\Arrv vs Departure\Lanewise_Departure_summary.csv')
deptdf_exce_summary.to_csv(r'D:\Data\CNM_Arrv_Dep\Arrv vs Departure\Dep_Exception_summary.csv')



filepath=r'D:\Data\CNM_Arrv_Dep\Arrv vs Departure\Data.csv'
filepath1=r'D:\Data\CNM_Arrv_Dep\Arrv vs Departure\HubWise_late_arrival.csv'
filepath2=r'D:\Data\CNM_Arrv_Dep\Arrv vs Departure\Lanewise_late_arrival.csv'
filepath3=r'D:\Data\CNM_Arrv_Dep\Arrv vs Departure\Arrival_Exception_summary.csv'
filepath4=r'D:\Data\CNM_Arrv_Dep\Arrv vs Departure\HubWise_Departure_summary.csv'
filepath5=r'D:\Data\CNM_Arrv_Dep\Arrv vs Departure\Lanewise_Departure_summary.csv'
filepath6=r'D:\Data\CNM_Arrv_Dep\Arrv vs Departure\Dep_Exception_summary.csv'


# with ExcelWriter(r'D:\Data\CNM_Arrv_Dep\Arrv vs Departure\CNM_Depar_Arrival_Report_'+str(todate)+'.xlsx') as writer:
#     df.to_excel(writer,sheet_name='Data')
#     arrvsummary.to_excel(writer,sheet_name='HubWise_late_arrival')
#     arrvlanesummary.to_excel(writer,sheet_name='Lanewise_late_arrival')
#     arrvlaneexcepsummary.to_excel(writer,sheet_name='Arrival_Exception_summary')
#     deptsummary.to_excel(writer,sheet_name='HubWise_Departure_summary')
#     deptlanesummary.to_excel(writer,sheet_name='Lanewise_Departure_summary')
#     deptdf_exce_summary.to_excel(writer,sheet_name='Dep_Exception_summary')
# writer.save()

# writer = pd.ExcelWriter(r'D:\Data\CNM_Arrv_Dep\Arrv vs Departure\CNM_Depar_Arrival_Report.xlsx', engine='xlsxwriter')
# df.to_excel(writer,sheet_name='Data')
# arrvsummary.to_excel(writer,sheet_name='HubWise_late_arrival')
# arrvlanesummary.to_excel(writer,sheet_name='Lanewise_late_arrival')
# arrvlaneexcepsummary.to_excel(writer,sheet_name='Arrival_Exception_summary')
# deptsummary.to_excel(writer,sheet_name='HubWise_Departure_summary')
# deptlanesummary.to_excel(writer,sheet_name='Lanewise_Departure_summary')
# deptdf_exce_summary.to_excel(writer,sheet_name='Dep_Exception_summary')
# writer.save()

# # In[ ]:




# In[ ]:

# TO=["mahesh.reddy@spoton.co.in"]
# CC=["mahesh.reddy@spoton.co.in"]
TO=['deepak.sharma@spoton.co.in','raghavendra.rao@spoton.co.in','soham.kakade@spoton.co.in']
#,"satya.pal@spoton.co.in","abhik.mitra@spoton.co.in","prasanna.hegde@spoton.co.in","shivananda.p@spoton.co.in"
CC=["mahesh.reddy@spoton.co.in"]
FROM="reports.ie@spoton.co.in"
# FROM="mahesh.reddy@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "Arrival & Departure Performance Report On " + " - " + str(todate)

report=""
report+="Dear All,"
report+='<br>'
report+='Kindly Find the  Arrival/Departure performance report on dated '+str(todate)+' For Reference find the attachment.'
report+='<br>'
report+=' NOTE:-   Second Vehicle late Depart due to Excess load is Consider As ONTIME DEP'
report+='<br>'
report+='Departue Summary :'
report+='<br>'+deptsummary.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='Arrival Summary :'
report+='<br>'+arrvsummary.to_html()+'<br>'
report+='<br>'
report+='<br>'

abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath1,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
msg.attach(part)

part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath2,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath2))
msg.attach(part)

part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath3,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath3))
msg.attach(part)

part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath4,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath4))
msg.attach(part)

part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath5,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath5))
msg.attach(part)

part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath6,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath6))
msg.attach(part)



# server=smtplib.SMTP('smtp.sendgrid.net', 587)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("mahesh.reddy@spoton.co.in", "Nov@2018")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()

