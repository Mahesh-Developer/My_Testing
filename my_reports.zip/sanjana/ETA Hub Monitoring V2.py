# -*- coding: utf-8 -*-
"""
Created on Wed Oct 07 16:46:58 2015

@author: rajeeshv
"""
import numpy as np
import pandas as pd
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime,timedelta,time
import urllib2
import os
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText


# In[2]:

oppath1 = r'D:/Data/eta_rank/ETA_FIFO_Violation.xlsx'

###ippath0 = r'C:\Data\eta_rank\hub_monitor\HTR_29_0830.xls'
###xl0 = pd.ExcelFile(ippath0)
###htrdata = xl0.parse('HUB_THROUGHPUT_REPORT_SALES')

htrdata = pd.io.excel.read_excel(r'http://10.109.230.50//downloads//HTR//HTR.xls','HUB_THROUGHPUT_REPORT_SALES')

###ippath1 = r'C:\Data\eta_rank\hub_monitor\TCR_UND_29_0830.xls'
###xl1 = pd.ExcelFile(ippath1)
###tcrbasedata = xl1.parse('TIME_CONNECTION_REPORT_ALL_UNDE')

tcrbasedata = pd.io.excel.read_excel(r'http://10.109.230.50/downloads/TCR_UND/TCR_UND.xls','TIME_CONNECTION_REPORT_ALL_UNDE')

ippath2 = r'D:/Python/Scripts and Files/Path and Graph Files/Path_Final_July15.xlsx'
xl2 = pd.ExcelFile(ippath2)
pathdf = xl2.parse('Sheet1')

dbcombined = pd.read_csv(r'D:/Data/eta_rank/Combined.csv')
conlist= htrdata['Con Number'].tolist()


# In[3]:

def save_xls(list_dfs, name_dfs, xls_path):
   i = 0
   writer = ExcelWriter(xls_path)
   for dataframe in list_dfs:
       sheetname = name_dfs[i]
       dataframe.to_excel(writer, sheetname, merge_cells = True)
       i = i+1
   writer.save()


# In[4]:

tcrbaseconlist=tcrbasedata['DOCKNO'].tolist()
tcrcutdata=tcrbasedata[(tcrbasedata['IS DEPARTED FRM CURRLOC'] == 'YES')]
tcrcutconlist=tcrcutdata['DOCKNO'].tolist()


# In[5]:

htrcurrenttime=htrdata.iloc[0]['Time Stampp']
k = 0
for k in range(0,len(tcrbaseconlist)):
    connumbertcr = tcrbasedata.iloc[k]['DOCKNO']
    #print connumbertcr
    if connumbertcr in tcrcutconlist:
        pass
    else:
        continue
    arrivaltimeintcr=tcrbasedata.iloc[k]['ARRV AT CURR LOCATION']
    departuretimeintcr=tcrbasedata.iloc[k]['DEPARTURE TIME FRM CURLOC']
    if arrivaltimeintcr > departuretimeintcr:
        tcrbasedata.loc[k,'TCR_file_issue1'] = 'Issue found'
    else:
        tcrbasedata.loc[k,'TCR_file_issue1'] = 'No_issues'

    if departuretimeintcr > htrcurrenttime:
        tcrbasedata.loc[k,'TCR_THC_issue1'] = 'Future THC Issue found'
    else:
        tcrbasedata.loc[k,'TCR_THC_issue1'] = 'Future THC No_issues'

tcrdata=tcrbasedata[(tcrbasedata['TCR_file_issue1'] == 'No_issues') & (tcrbasedata['TCR_THC_issue1'] == 'Future THC No_issues')]


# In[6]:

htrcutdata= htrdata[(htrdata['Arrival Date @ Hub'] >= datetime.strptime('01/01/2015 00:00:00 AM', '%d/%m/%Y %H:%M:%S %p'))]
cutconlist= htrcutdata['Con Number'].tolist()
print 'len con is', len(cutconlist)
virtualprosstime=3
coolingtime=0
virtbranchlist=['AMCF','AMDO','BBIB','BDQB','IXGF','BLRF','BWDB','BRGO','CCUC','CJBC','GZBB','HYDO','IDRB','JAIC','JLRB','KNUB','LKOB','MAAC','NAGB','PLGB','PNQO','PNQK','RPRB','SMBF','SNRB','VPIB','VGAF']
depspaperworkcodelist=['SRE','DIR','EIR','SIR','SRD','SRS','SRP','DLP','SWP','PWS','HCM','HPM','MOP','SRH','HOC','ONR','SPH','SPO','DBO','DIP','SHS','SSC','HIP']
u=0
for u in range (0,len(conlist)):
    connumber = htrdata.iloc[u]['Con Number']
    if connumber in cutconlist:
        pass
    else:
        continue
    origin = htrdata.iloc[u]['Origin Branch']
    destination = htrdata.iloc[u]['Dest. Branch']
    currloc = htrdata.iloc[u]['Hub/SC Location']
    arrivaltime = htrdata.iloc[u]['Arrival Date @ Hub']
    ##conpriority= htrdata.iloc[u]['Is Priority Con']
    currenttime=htrdata.iloc[u]['Time Stampp']
    statuscodes=htrdata.iloc[u]['Con Status Code At Hub Loc']
    customername=htrdata.iloc[u]['Customer Name']
    arrivaltime = arrivaltime+timedelta(hours=coolingtime)

    if statuscodes in depspaperworkcodelist:
        htrdata.loc[u,'DEPS/Paperworks'] = 'YES'
    else:
        htrdata.loc[u,'DEPS/Paperworks'] = 'NO'

    df3= pathdf[(pathdf['Destination']== destination ) & (pathdf['Path1'].str.contains(currloc))]
    if df3.empty:
        htrdata.loc[u,'OTHER_OBSERVATIONS'] = 'No path available'
    else:
        path = df3['Path1'].values[0]        
        #pathlist1 = df3['Path1'].tolist()
        #print('Pathlist is ',pathlist1 )
        if htrdata.loc[u,'DEPS/Paperworks'] == 'NO' and customername != 'COMPANY MAIL - STL TO STL':
            #path=pathlist1[0]
            #print('Path is',path)
            parts = path.split('-')
            #print('parts is', parts)
            lenparts=len(parts)
            statuslist1=[]          #Appending statuses of all the cons in single
            conjumplist1 =[]
            etajumplist = []    
            if currloc in parts:
                matching = [j for j, x in enumerate(parts) if x == currloc]
                post= matching[0]                           #Matching the position of current element in path
                ###to_improve_later##path_in1 = parts[parts.index(filter(lambda x: x==currloc,parts)[0]):]
                #print('OD conbination is', origin,'-',destination)
                #print ('Current loc is', currloc)
                nextloc = parts[post+1]
                #print('Next loc is', nextloc)
                htrdata.loc[u,'Next Location'] = nextloc
                ###if conpriority == 'Priority': (Removed for Calculating NEW ETA Violation)
                tcrdata1=tcrdata[(tcrdata['CURR BRANCHCODE']==currloc) & (tcrdata['DEPARTURE TO LOC FRM CURLOC']== nextloc)]
                ###else:
                ###tcrdata1=tcrdata[(tcrdata['CURR BRANCHCODE']==currloc) & (tcrdata['DEPARTURE TO LOC FRM CURLOC']== nextloc)  & (tcrdata['Is Priority Con']== 'Normal')]
                if tcrdata1.empty:
                    #print('tcr df empty')
                    statuslist1.append('No previous connections')
                else:
                    arrivaltimetcrlist = tcrdata1['ARRV AT CURR LOCATION'].tolist()
                    conviolatedlist=tcrdata1['DOCKNO'].tolist()
                    #print('arrivaltime of htr is',arrivaltime,len(arrivaltimetcrlist))
                    #print('arrivaltimetcrlist is',arrivaltimetcrlist)
                    for v in range (0,len(arrivaltimetcrlist)):
                        if arrivaltimetcrlist[v] <= arrivaltime:
                            #print('Fifo not violated')
                            statuslist1.append('ETA not violated')
                        else:
                            checkdftcr = dbcombined[(dbcombined['Con Number_x']==conviolatedlist[v]) & (dbcombined['Hub SC Location']==currloc)] #currloc add pending
                            if checkdftcr.empty:
                                htrdata.loc[u,'Help2'] = 'Empty'
                            else:
                                tslist = checkdftcr['TIMESTAMP'].tolist()
                                maxts = max(tslist)
                                checkdf2tcr = dbcombined[(dbcombined['Con Number_x']==conviolatedlist[v]) & (dbcombined['TIMESTAMP']==maxts)]
                                checkdfhtr = dbcombined[(dbcombined['Con Number_x']==connumber) & (dbcombined['TIMESTAMP']==maxts)]
                                if checkdf2tcr.empty or checkdfhtr.empty:
                                    htrdata.loc[u,'Help'] = 'Empty'
                                else:      
                                    ##print checkdf2tcr['Rank'].values[0]
                                    ##print checkdfhtr['Rank'].values[0]
                                    if checkdf2tcr['Rank'].values[0] > checkdfhtr['Rank'].values[0]:
                                        ##print connumber, checkdfhtr['Rank'].values[0], conviolatedlist[v], checkdf2tcr['Rank'].values[0]
                                        htrdata.loc[u,'ETA_violation'] = 'ETA violated'
                                        etajumplist.append(conviolatedlist[v])
                                        statuslist1.append('ETA violated')

            else:
                statuslist1.append('Possibly misrouted')
                pass
            htrdata.loc[u,'ETA No of jumped cons'] = "".join(str((etajumplist)))
            if 'ETA violated' in statuslist1:
                pass
            elif 'ETA not violated' in statuslist1:
                htrdata.loc[u,'OTHER_OBSERVATIONS'] = 'ETA not violated'   
            elif 'No previous connections' in statuslist1:
                htrdata.loc[u,'OTHER_OBSERVATIONS'] = 'No previous connections'
            elif 'Possibly misrouted' in statuslist1:
                htrdata.loc[u,'OTHER_OBSERVATIONS'] = 'Possibly misrouted'
            else:
                htrdata.loc[u,'OTHER_OBSERVATIONS'] = 'Check1'


htrdata = htrdata.drop(['Help2','Help'], axis=1)
# In[7]:

etavio= htrdata[(htrdata['ETA_violation']== 'ETA violated') & (htrdata['Is HUB']== 'Y')]
PT1=pivot_table(etavio,index=['Hub/SC Location'],values=['ETA_violation'],aggfunc='count',fill_value=0,margins=True)

printlist =  [htrdata,PT1]
namelist = ['Data','Pivot']
save_xls (printlist, namelist, oppath1)

filePath = oppath1
def sendEmail(#TO = ["ashwani.gangwar@spoton.co.in","krishna.kumar.bhardwaj@spoton.co.in","jaisingh.chauhan@spoton.co.in","joseph.arul.seelan@spoton.co.in","dhiraj.patil@spoton.co.in","krishan.kaushik@spoton.co.in","ramniwas.sharma@spoton.co.in","sopanrao.bhoite@spoton.co.in","ramachandran.p@spoton.co.in","manoj.pareek@spoton.co.in","pramod.pandey@spoton.co.in","surendra.pandey@spoton.co.in","onkar.sharma@spoton.co.in","ajay.kumar.singh@spoton.co.in","satyaprakash.vishwakarma@spoton.co.in","sandesh.patade@Spoton.co.in","cnm@spoton.co.in","cstl_spot@spoton.co.in"],
            #TO = ["rajeesh.vr@spoton.co.in"],
            TO = ["vishwas.j@spoton.co.in"],
            CC = ["vishwas.j@spoton.co.in"],
            #CC = ["sqtf@spoton.co.in","sq_spot@spoton.co.in","supratim@iepfunds.com","rajesh.kumar@spoton.co.in","pawan.sharma@spoton.co.in","vishwas.j@spoton.co.in","prasanna.hegde@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "ETA Hub Monitoring Report" + " - " + str(htrcurrenttime)
    msg["Subject"] = "ETA Hub Monitoring Report" + " - " + str(htrcurrenttime)
    body_text = """
    Dear All,

    PFA the ETA Hub Monitoring Report as on """ + str(htrcurrenttime) +"""
    
    To check the cons which jumped ETA, please follow the below steps,.
    a) Go to the Data sheet and select your hub in the 'Hub/SC Location' 
    b) Select 'ETA violated' in 'ETA_violation'
    c) In the column 'ETA No of jumped cons', the cons which jumped ETA (Lower delaydays at the time of loading) are mentioned. These are the cons which had lower slipdays
    at the time of loading compared to the con which stayed back. 
    
    """+ str(PT1) +"""
    
    NOTE1 : DEPS/PAPERWORK Issues have been excluded in the report 

    ETA Violation example:
    Lets consider 2 cons 'x' and 'y' at a current location 'A' and next location being 'B'. Con 'x' arrived earlier than con 'y' where con 'x' had higher ETA delaydays
    than con 'y' at the time of stock. If con 'y' moves and con 'x' stays back, then there is a ETA violation against con 'x'


    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')

#Sending output file via mail ends



# In[ ]:




# In[ ]:



