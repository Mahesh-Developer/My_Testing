
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
# from pymongo import MongoClient
from string import Template
import smtplib
import os
from datetime import datetime, timedelta
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import Utilities
server = '10.109.230.18\estl,49280'
database = 'ESTL_CRP2'
username = 'sa'
password = 'password@123'

loading = 3*60 
unloading = 3*60
virtualmovement = 3*60
odadays = 3*24*60


# In[2]:



# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()
#

# In[2]:



# htrlink = 'http://spoton.co.in/downloads/HTR_1HR/HTR_1HR.xls'
# htr = pd.read_excel(htrlink)
htrquery = ("""EXEC USP_HUB_THROUGHPUT_DETAILS_SALES_ONEHOUR""")
print (htrquery)
htr = pd.read_sql(htrquery, Utilities.cnxn)
print ('inv',len(htr))

htr=htr.rename(columns={'Con Number':'DOCKNO'}).set_index('DOCKNO')

print (htr[htr['Hub/SC Location']=='AMCH']['Act.WtInTonnes'].sum())
# In[4]:

htr.rename(columns={'Hub/SC Location':"Location",'Arrival Date @ Hub':"Arrival Date Hub",'DestnBranch':"Destn Branch",'Act.WtInTonnes':"Wt",'LatestStatusCode':"Latest Status Code",'OriginArea':"Origin Area",'DestnArea':'Destn Area'},inplace=True)

# htr.rename(columns={'Hub SC Location': 'Location','Destn Branch': 'Destination','Origin Branch': 'Origin','Act Wt In Tonnes': 'Wt','Del Location Type': 'DestType','TIMESTAMP': 'Ts','Arrival Date Hub':'ArrTs','Due Date': 'DueDate','Next Frwd Loc': 'NextLoc'},inplace=True)


pivot_inv_hub_df=pd.pivot_table(htr,index=['Location'],values=['Wt'],aggfunc={'Wt':sum}).reset_index()


# In[3]:


pivot_inv_hub_df


# In[4]:


pivot_inv_hub_df.rename(columns={'Wt':'Curr_Wt'},inplace=True)
print (pivot_inv_hub_df[pivot_inv_hub_df['Location']=='AMCH'])


# In[5]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


# In[6]:


today=datetime.now()


# In[7]:


today=datetime.now()
tomorrow=today.date()+timedelta(1)


# In[8]:


today1=today.date()
today1


# In[9]:


yest_day=today.date()-timedelta(1)
yest_day=str(yest_day)+' 23:59:00'
yest_day


# In[10]:


start_day=today.date()-timedelta(7)
start_day=str(start_day)+' 00:00:00'


# In[11]:


start_day


# In[12]:


query1=("""-------------------------HUB-HUB Inbound (Incoming to Hub from Hub)
--SELECT  CONVERT(VARCHAR(10), A.actarrv_dt, 103) actarrv_dt ,
--SELECT  CONVERT(VARCHAR(10), A.actdept_dt, 121)+' '+CONVERT(VARCHAR(10), A.actdept_tm, 108) actdept_dt ,
SELECT  CONVERT(VARCHAR(10), A.actarrv_dt, 121)+' '+CONVERT(VARCHAR(10), 
A.actarrv_tm, 108) actarrv_dt ,
         C.DOCKNO ,
         B.TCBR ,
         br.BRNM ,
         A.tobh_code ,
         bd.BRNM ,
         CBS.ACTUWT ,
         CBS.PKGSNO ,
         CBS.CFT_TOTAL ,
         A.thcno AS INBOUND_THC ,
         A.vehno,
         A.vehtons ,
         UT.UTY_NAME
FROM    dbo.THC_SUMMARY A WITH ( NOLOCK )
         INNER JOIN TCHDR B ON A.thcno = B.THCNO
         INNER JOIN TCTRN C WITH ( NOLOCK ) ON C.TCNO = B.TCNO
         INNER JOIN DOCKET CBS WITH ( NOLOCK ) ON C.DOCKNO = CBS.DOCKNO
         INNER JOIN dbo.brms br WITH ( NOLOCK ) ON br.BRCD = B.TCBR
         INNER JOIN brms bd WITH ( NOLOCK ) ON bd.BRCD = A.tobh_code
         INNER JOIN dbo.UTYMAST UT WITH ( NOLOCK ) ON UT.UTY_ID = CBS.PRODCD
WHERE   A.tobh_code IN ( 'AMCH','AMDH','BBIH','BDQH','BGMH','BHOH','BLRH','BOMH','BRGH','CCUH','CJBH','DELH','GZBH','HYDH','IDRH','JAIH','JBLH','KNPH','LKOH','MAAB','MAAH','NAGH','NDAH','PATH','PGTH','PNQH','RPRH','SMBH','SNRH','SXVF','VPIH','VZAH','COKB' )
         AND A.actarrv_dt BETWEEN '{0}'
                          AND     '{1}'
         AND br.DEFAULTHUB <> A.tobh_code
         AND bd.HUBCENTER='Y'
         AND BR.HUBCENTER='Y'
 """).format(start_day,yest_day)


# In[13]:


df1=pd.read_sql(query1,Utilities.cnxn)


# In[14]:


len(df1)


# In[ ]:


df1.columns


# In[15]:


df1.drop_duplicates(['DOCKNO','TCBR','tobh_code'],inplace=True)


# In[17]:


len(df1)


# In[16]:


df1['Date']=df1['actarrv_dt'].apply(lambda x: x.split(' ')[0])


# In[ ]:


df1.head()


# In[18]:


hub_hub_inbound=df1.pivot_table(index=['tobh_code','Date'],values=['ACTUWT'],aggfunc={'ACTUWT':sum}).reset_index()


# In[19]:


hub_hub_inbound


# In[20]:


hub_hub_inbound.rename(columns={'tobh_code':'Location','ACTUWT':'H-H_Inbound_WT'},inplace=True)


# In[21]:


hub_hub_inboundperc = pd.pivot_table(hub_hub_inbound,index=['Location'], values=['H-H_Inbound_WT'], aggfunc=[lambda x:pd.np.percentile(x,95),max,np.mean]).reset_index()


# In[22]:


hub_hub_inboundperc


# In[23]:


query2=("""--------------------------SC-HUB (Incoming to Hub from SC) 
--SELECT  CONVERT(VARCHAR(10), A.actarrv_dt, 103) actarrv_dt , 
SELECT  CONVERT(VARCHAR(10), A.actarrv_dt, 121)+' '+CONVERT(VARCHAR(10), A.actarrv_tm, 108) actarrv_dt ,
         C.DOCKNO ,
         B.TCBR ,
         br.BRNM ,
         A.tobh_code ,
         bd.BRNM ,
         CBS.ACTUWT ,
         CBS.PKGSNO ,
         CBS.CFT_TOTAL ,
         A.thcno AS INBOUND_THC ,
         A.vehno,
         A.vehtons ,
         UT.UTY_NAME
FROM    dbo.THC_SUMMARY A WITH ( NOLOCK )
         INNER JOIN TCHDR B ON A.thcno = B.THCNO
         INNER JOIN TCTRN C WITH ( NOLOCK ) ON C.TCNO = B.TCNO
         INNER JOIN DOCKET CBS WITH ( NOLOCK ) ON C.DOCKNO = CBS.DOCKNO
         INNER JOIN dbo.brms br WITH ( NOLOCK ) ON br.BRCD = B.TCBR
         INNER JOIN brms bd WITH ( NOLOCK ) ON bd.BRCD = A.tobh_code
         INNER JOIN dbo.UTYMAST UT WITH ( NOLOCK ) ON UT.UTY_ID = CBS.PRODCD WHERE   A.tobh_code IN ( 'AMCH','AMDH','BBIH','BDQH','BGMH','BHOH','BLRH','BOMH','BRGH','CCUH','CJBH','DELH','GZBH','HYDH','IDRH','JAIH','JBLH','KNPH','LKOH','MAAB','MAAH','NAGH','NDAH','PATH','PGTH','PNQH','RPRH','SMBH','SNRH','SXVF','VPIH','VZAH','COKB' )
         AND A.actarrv_dt BETWEEN '{0}'
                          AND     '{1}'
         AND br.DEFAULTHUB = A.tobh_code
         AND bd.HUBCENTER='Y'
 """).format(start_day,yest_day)


# In[24]:


df2=pd.read_sql(query2,Utilities.cnxn)


# In[25]:


len(df2)


# In[ ]:


df2.columns


# In[26]:


df2.drop_duplicates(['DOCKNO','TCBR','tobh_code'],inplace=True)


# In[27]:


len(df2)


# In[28]:


df2['Date']=df2['actarrv_dt'].apply(lambda x: x.split(' ')[0])


# In[ ]:


df2.head()


# In[29]:


sc_hub_inbound=df2.pivot_table(index=['tobh_code','Date'],values=['ACTUWT'],aggfunc={'ACTUWT':sum}).reset_index()


# In[30]:


sc_hub_inbound.rename(columns={'tobh_code':'Location','ACTUWT':'S-H_Inbound_WT'},inplace=True)


# In[31]:


sc_hub_inboundperc = pd.pivot_table(sc_hub_inbound,index=['Location'], values=['S-H_Inbound_WT'], aggfunc=[lambda x:pd.np.percentile(x,95),max,np.mean]).reset_index()


# In[32]:


sc_hub_inboundperc


# In[33]:


hub_hub_inboundperc=pd.merge(hub_hub_inboundperc,sc_hub_inboundperc,on='Location',how='outer')


# In[34]:


hub_hub_inboundperc=hub_hub_inboundperc.fillna(0)


# In[35]:


hub_hub_inboundperc


# In[36]:


hub_hub_inboundperc['Total_Avg_Inbound_max']=hub_hub_inboundperc['max','H-H_Inbound_WT']+hub_hub_inboundperc['max','S-H_Inbound_WT']


# In[37]:


hub_hub_inboundperc['Total_Avg_Inbound_mean']=hub_hub_inboundperc['mean','H-H_Inbound_WT']+hub_hub_inboundperc['mean','S-H_Inbound_WT']


# In[38]:


hub_hub_inboundperc['Total_Avg_Inbound_per']=hub_hub_inboundperc['<lambda>','H-H_Inbound_WT']+hub_hub_inboundperc['<lambda>','S-H_Inbound_WT']


# In[39]:


hub_hub_inboundperc


# # Calculating Avg Outgoing

# In[40]:


query3=("""-------------------------HUB-SC (Outgoing from Hub to SC)
--SELECT  CONVERT(VARCHAR(10), A.actarrv_dt, 121)+' '+CONVERT(VARCHAR(10), A.actarrv_tm, 108) actarrv_dt ,
SELECT  CONVERT(VARCHAR(10), A.actdept_dt, 121)+' '+CONVERT(VARCHAR(10), 
A.actdept_tm, 108) actdept_dt ,
         C.DOCKNO ,
         B.TCBR ,
         br.BRNM ,
         A.tobh_code ,
         bd.BRNM ,
         CBS.ACTUWT ,
         CBS.PKGSNO ,
         CBS.CFT_TOTAL ,
         A.thcno AS INBOUND_THC ,
         A.vehno,
         A.vehtons ,
         UT.UTY_NAME
FROM    dbo.THC_SUMMARY A WITH ( NOLOCK )
         INNER JOIN TCHDR B ON A.thcno = B.THCNO
         INNER JOIN TCTRN C WITH ( NOLOCK ) ON C.TCNO = B.TCNO
         INNER JOIN DOCKET CBS WITH ( NOLOCK ) ON CBS.DOCKNO = C.DOCKNO
         INNER JOIN dbo.brms br WITH ( NOLOCK ) ON br.BRCD = B.TCBR
         INNER JOIN brms bd WITH ( NOLOCK ) ON bd.BRCD = A.tobh_code
         INNER JOIN dbo.UTYMAST UT WITH ( NOLOCK ) ON UT.UTY_ID = CBS.PRODCD
WHERE   A.sourcehb IN ('AMCH','AMDH','BBIH','BDQH','BGMH','BHOH','BLRH','BOMH','BRGH','CCUH','CJBH','DELH','GZBH','HYDH','IDRH','JAIH','JBLH','KNPH','LKOH','MAAB','MAAH','NAGH','NDAH','PATH','PGTH','PNQH','RPRH','SMBH','SNRH','SXVF','VPIH','VZAH','COKB')
         AND A.actdept_dt BETWEEN '{0}'
                          AND     '{1}'
         --AND br.DEFAULTHUB = A.tobh_code
         AND bd.HUBCENTER <> 'Y'
         AND br.HUBCENTER = 'Y'
 """).format(start_day,yest_day)


# In[41]:


df3=pd.read_sql(query3,Utilities.cnxn)


# In[42]:


len(df3)


# In[ ]:


df3.columns


# In[43]:


df3.drop_duplicates(['DOCKNO','TCBR','tobh_code'],inplace=True)


# In[44]:


len(df3)


# In[45]:


df3['Date']=df3['actdept_dt'].apply(lambda x: x.split(' ')[0])


# In[46]:


hub_sc_outgoing=df3.pivot_table(index=['TCBR','Date'],values=['ACTUWT'],aggfunc={'ACTUWT':sum}).reset_index()


# In[ ]:


#hub_sc_outgoing[hub_sc_outgoing['Location']=='DELH']


# In[47]:


hub_sc_outgoing.rename(columns={'TCBR':'Location','ACTUWT':'H-S_Outbound_WT'},inplace=True)


# In[48]:


hub_sc_outgoingperc = pd.pivot_table(hub_sc_outgoing,index=['Location'], values=['H-S_Outbound_WT'], aggfunc=[lambda x:pd.np.percentile(x,95),max,np.mean]).reset_index()


# In[49]:


hub_sc_outgoingperc


# In[50]:


query=("""------------------------HUB-HUB Outbound (Outgoing from Hub to Hub)
--SELECT  CONVERT(VARCHAR(10), A.actarrv_dt, 103) actarrv_dt ,
--SELECT  CONVERT(VARCHAR(10), A.actarrv_dt, 121)+' '+CONVERT(VARCHAR(10), A.actarrv_tm, 108) actarrv_dt ,
SELECT  CONVERT(VARCHAR(10), A.actdept_dt, 121)+' '+CONVERT(VARCHAR(10), 
A.actdept_tm, 108) actdept_dt ,
         C.DOCKNO ,
         B.TCBR ,
         br.BRNM ,
         A.tobh_code ,
         bd.BRNM ,
         CBS.ACTUWT ,
         CBS.PKGSNO ,
         CBS.CFT_TOTAL ,
         A.thcno AS INBOUND_THC ,
         A.vehno,
         A.vehtons ,
         UT.UTY_NAME
FROM    dbo.THC_SUMMARY A WITH ( NOLOCK )
         INNER JOIN TCHDR B ON A.thcno = B.THCNO AND B.TCBR = A.sourcehb
         INNER JOIN TCTRN C WITH ( NOLOCK ) ON C.TCNO = B.TCNO
         INNER JOIN DOCKET CBS WITH ( NOLOCK ) ON CBS.DOCKNO = C.DOCKNO
         INNER JOIN dbo.brms br WITH ( NOLOCK ) ON br.BRCD = B.TCBR
         INNER JOIN brms bd WITH ( NOLOCK ) ON bd.BRCD = A.tobh_code
         INNER JOIN dbo.UTYMAST UT WITH ( NOLOCK ) ON UT.UTY_ID = CBS.PRODCD
WHERE   A.sourcehb IN ('AMCH','AMDH','BBIH','BDQH','BGMH','BHOH','BLRH','BOMH','BRGH','CCUH','CJBH','DELH','GZBH','HYDH','IDRH','JAIH','JBLH','KNPH','LKOH','MAAB','MAAH','NAGH','NDAH','PATH','PGTH','PNQH','RPRH','SMBH','SNRH','SXVF','VPIH','VZAH','COKB')
         AND A.actdept_dt BETWEEN '{0}'
                          AND     '{1}'
         AND br.DEFAULTHUB <> A.tobh_code
         AND bd.HUBCENTER = 'Y'
         AND br.HUBCENTER = 'Y'
 """).format(start_day,yest_day)


# In[51]:


df=pd.read_sql(query,Utilities.cnxn)


# In[52]:


len(df)


# In[ ]:


df.columns


# In[53]:


df.drop_duplicates(['DOCKNO','TCBR','tobh_code'],inplace=True)


# In[54]:


len(df)


# In[55]:


df['Date']=df['actdept_dt'].apply(lambda x: x.split(' ')[0])


# In[56]:


hub_hub_outgoing=df.pivot_table(index=['TCBR','Date'],values=['ACTUWT'],aggfunc={'ACTUWT':sum}).reset_index()


# In[57]:


hub_hub_outgoing.rename(columns={'TCBR':'Location','ACTUWT':'H-H_Outbound_WT'},inplace=True)


# In[58]:


hub_hub_outgoinggperc = pd.pivot_table(hub_hub_outgoing,index=['Location'], values=['H-H_Outbound_WT'], aggfunc=[lambda x:pd.np.percentile(x,95),max,np.mean]).reset_index()


# In[59]:


hub_hub_outgoinggperc


# In[60]:


hub_hub_outgoinggperc=pd.merge(hub_hub_outgoinggperc,hub_sc_outgoingperc,on='Location',how='outer')


# In[61]:


hub_hub_outgoinggperc['Total_Avg_Outbound_max']=hub_hub_outgoinggperc['max','H-H_Outbound_WT']+hub_hub_outgoinggperc['max','H-S_Outbound_WT']


# In[62]:


hub_hub_outgoinggperc['Total_Avg_Outbound_mean']=hub_hub_outgoinggperc['mean','H-H_Outbound_WT']+hub_hub_outgoinggperc['mean','H-S_Outbound_WT']


# In[63]:


hub_hub_outgoinggperc['Total_Avg_Outbound_per']=hub_hub_outgoinggperc['<lambda>','H-H_Outbound_WT']+hub_hub_outgoinggperc['<lambda>','H-S_Outbound_WT']


# In[64]:


hub_hub_outgoinggperc['Total_Avg_Outbound_per']=pd.np.round(hub_hub_outgoinggperc['Total_Avg_Outbound_per']/1000.0,2)
hub_hub_outgoinggperc['Total_Avg_Outbound_mean']=pd.np.round(hub_hub_outgoinggperc['Total_Avg_Outbound_mean']/1000.0,2)
hub_hub_outgoinggperc['Total_Avg_Outbound_max']=pd.np.round(hub_hub_outgoinggperc['Total_Avg_Outbound_max']/1000.0,2)


# In[65]:


hub_hub_inboundperc['Total_Avg_Inbound_per']=pd.np.round(hub_hub_inboundperc['Total_Avg_Inbound_per']/1000.0,2)
hub_hub_inboundperc['Total_Avg_Inbound_mean']=pd.np.round(hub_hub_inboundperc['Total_Avg_Inbound_mean']/1000.0,2)
hub_hub_inboundperc['Total_Avg_Inbound_max']=pd.np.round(hub_hub_inboundperc['Total_Avg_Inbound_max']/1000.0,2)


# In[66]:


hub_hub_inboundperc=pd.merge(hub_hub_inboundperc,hub_hub_outgoinggperc,on='Location',how='outer')


# In[67]:


hub_hub_inboundperc


# In[68]:


hub_hub_inboundperc=pd.merge(hub_hub_inboundperc,pivot_inv_hub_df,on='Location',how='left')


# In[69]:


hub_hub_inboundperc['Total_Wt_per']=hub_hub_inboundperc['Total_Avg_Inbound_per','']+hub_hub_inboundperc['Curr_Wt']
hub_hub_inboundperc['Total_Wt_mean']=hub_hub_inboundperc['Total_Avg_Inbound_mean','']+hub_hub_inboundperc['Curr_Wt']
hub_hub_inboundperc['Total_Wt_max']=hub_hub_inboundperc['Total_Avg_Inbound_max','']+hub_hub_inboundperc['Curr_Wt']


# In[70]:


hub_hub_inboundperc['Left_Stock_per']=hub_hub_inboundperc['Total_Wt_per']-hub_hub_inboundperc['Total_Avg_Outbound_per', '']
hub_hub_inboundperc['Left_Stock_mean']=hub_hub_inboundperc['Total_Wt_mean']-hub_hub_inboundperc['Total_Avg_Outbound_mean', '']
hub_hub_inboundperc['Left_Stock_max']=hub_hub_inboundperc['Total_Wt_max']-hub_hub_inboundperc['Total_Avg_Outbound_max', '']


# In[71]:


hub_hub_inboundperc


# In[72]:


del hub_hub_inboundperc['Location','']


# In[73]:


hub_hub_inboundperc.rename(columns={('Total_Avg_Outbound_mean',''):'Total_Avg_Outbound',('Total_Avg_Inbound_mean',''):'Total_Avg_Inbound'},inplace=True)


# In[74]:


hub_hub_inboundperc1=hub_hub_inboundperc[['Location','Total_Avg_Outbound','Total_Avg_Inbound','Curr_Wt']]


# In[75]:


hub_hub_inboundperc1[tomorrow]=hub_hub_inboundperc1['Total_Avg_Inbound']


# In[76]:


hub_hub_inboundperc1['Stock_left']=(hub_hub_inboundperc1[tomorrow]+hub_hub_inboundperc1['Curr_Wt'])-hub_hub_inboundperc1['Total_Avg_Outbound']


# In[77]:


hub_hub_inboundperc1


# In[78]:


space_df=pd.read_excel(r'C:\Users\rajeeshv\Downloads\Hub_Capacity12.xls')
len(space_df)


# In[79]:


hub_hub_inboundperc1=pd.merge(hub_hub_inboundperc1,space_df,on='Location',how='outer')


# In[80]:


hub_hub_inboundperc1['%Area_Uti']=pd.np.round(hub_hub_inboundperc1['Stock_left']*100.0/hub_hub_inboundperc1['New Capacity'],2)


# In[81]:


hub_hub_inboundperc1['Curr_Wt']=pd.np.round(hub_hub_inboundperc1['Curr_Wt'],2)
hub_hub_inboundperc1['New Capacity']=pd.np.round(hub_hub_inboundperc1['New Capacity'],2)
hub_hub_inboundperc1['Stock_left']=pd.np.round(hub_hub_inboundperc1['Stock_left'],2)


# In[82]:


hub_hub_inboundperc1.to_csv(r'D:\Data\Hub_Location_Criticality\Space_Criticality_'+str(today1)+'.csv')
hub_hub_inboundperc1.to_csv(r'D:\Data\Hub_Location_Criticality\Space_Criticality.csv')


# In[83]:


hub_hub_inboundperc1=hub_hub_inboundperc1.fillna(0)


# In[84]:


hub_hub_inboundperc1.rename(columns={'New Capacity':'Hub_Capacity(T)'},inplace=True)


# In[86]:


hub_hub_inboundperc1=hub_hub_inboundperc1[['Location','Curr_Wt',tomorrow,'Hub_Capacity(T)','%Area_Uti']]


# In[87]:


hub_hub_inboundperc2=hub_hub_inboundperc1[hub_hub_inboundperc1['%Area_Uti']>80.0]


# In[88]:


hub_hub_inboundperc2


# In[89]:


filePath=r'D:\Data\Hub_Location_Criticality\Space_Criticality.csv'


# In[90]:


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

TO=['hubmgr_spot@spoton.co.in','sqtf@spoton.co.in']
#'vishwas.j@spoton.co.in','satya.pal@spoton.co.in','saptarshi.pathak@spoton.co.in'
CC=['rajesh.kumar@spoton.co.in','pawan.sharma@spoton.co.in','abhik.mitra@spoton.co.in','jyothi.menon@spoton.co.in','satya.pal@spoton.co.in','shivananda.p@spoton.co.in','mahesh.reddy@spoton.co.in','syed.hussain@spoton.co.in','saptarshi.pathak@spoton.co.in']
# TO=['mahesh.reddy@spoton.co.in']
FROM="reports.ie@spoton.co.in"
# CC=['syed.hussain@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in','syed.hussain@spoton.co.in','saptarshi.pathak@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = "Location Criticality for Hub" + " : " + str(today1)
html='''<html>
<style>
p
{
  margin:0;
  margin-top: 5px;
  padding:0;
  font-size:17px;
    line-height:20px;
}
</style>
<h3>Dear All,</h3>
<p>Please Find the Location Criticality for SC.</p>
</html>'''


s = Template(html).safe_substitute()
report=""
#report+=s
#report+='<br>'+final_dff5.to_html()+'<br>'
report+='Dear All,'
report+='<br>'
report+='Please Find the Location Criticality for Hub.'
report+='<br>'
report+='<br>'+hub_hub_inboundperc2.to_html()+'<br>'
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filePath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
msg.attach(part)
# part1 = MIMEBase('application', "octet-stream")
# part1.set_payload( open(filePath1,"rb").read() )
# encoders.encode_base64(part1)
# part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath1))
# msg.attach(part1)

server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()

