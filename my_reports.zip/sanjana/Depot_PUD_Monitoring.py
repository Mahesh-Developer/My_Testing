
# coding: utf-8

# In[1]:


import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
import ftplib
import Utilities
from calendar import monthrange

# In[2]:

query=("""EXEC USP_PUD_YEST_MTD_DATA 'M' """)
cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()
print ('yes')
#df=pd.read_sql(query,Utilities.cnxn)
dff=pd.read_sql(query,cnxn)

# In[3]:
print (len(dff))
dff.rename(columns={'DATE':'DATE2','DEPOT':'DEPOT2','PUDTYPE':'PUDTYPE2','ACT_WT':'ACT_WT2','COST':'COST2','con_id':'CON_ID2'},inplace=True)

# In[4]:


dff['TYPE']='MTD'


# In[5]:


#dict={'Jul':'07','Aug':'08'}
dict = {'Jan': '01','Feb': '02','Mar': '03','Apr':'04','May':'05','Jun':'06','Jul':'07','Aug':'08','Sep':'09','Oct':'10','Nov':'11','Dec':'12'}



# In[6]:


def getDate(dt):
    dtt=dt.split(' ')[2]+'-'+dict.get(dt.split(' ')[1])+'-'+dt.split(' ')[0]
    return dtt


# In[7]:


dff['DATE2']=dff.apply(lambda x:getDate(x['DATE2']),axis=1)


# In[8]:


yesterdate=datetime.strftime(datetime.now()-timedelta(1),'%Y-%m-%d')
yesterdate


# In[9]:


dff['DATE2'].unique()


# In[10]:


yest_dff=dff[dff['DATE2']==yesterdate]
#yest_dff=dff[dff['DATE2']=='2018-07-17']
len(yest_dff)


# In[11]:


yest_dff['TYPE']='YST'


# In[12]:


final_dff=pd.concat([yest_dff,dff])


# In[13]:


final_dff_pivot=final_dff.pivot_table(index=['DEPOT2','PUDTYPE2'],columns=['TYPE'],values=['ACT_WT2','COST2','CON_ID2'],aggfunc={'ACT_WT2':sum,'COST2':sum,'CON_ID2':len})


# In[14]:


tab_tots=final_dff_pivot.groupby(level='DEPOT2').sum()
tab_tots


# In[15]:


tab_tots.index = [tab_tots.index, ['Total'] * len(tab_tots)]


# In[16]:


final_dff_pivot_total=pd.concat(
[final_dff_pivot, tab_tots]
).sort_index().append(
final_dff_pivot.sum().rename(('Grand', 'Total'))
)


# In[17]:


final_dff_pivot_total['CPKG','YST']=pd.np.round(final_dff_pivot_total['COST2','YST']/final_dff_pivot_total['ACT_WT2','YST'],2)


# In[18]:


final_dff_pivot_total['CPKG','MTD']=pd.np.round(final_dff_pivot_total['COST2','MTD']/final_dff_pivot_total['ACT_WT2','MTD'],2)


# In[19]:


tab_tots1=tab_tots.reset_index()


# In[20]:


yest_final_pivot2=pd.DataFrame()
for i in final_dff_pivot_total.index.get_level_values(level=0).unique():
    yest_final_pivot1=final_dff_pivot_total[final_dff_pivot_total.index.get_level_values(level=0)==i]
    a=tab_tots1[tab_tots1['DEPOT2']==i]['ACT_WT2','YST']
    b=tab_tots1[tab_tots1['DEPOT2']==i]['ACT_WT2','MTD']
    try:
        yest_final_pivot1['Total','YST']=a.values[0]
        yest_final_pivot1['Total','MTD']=b.values[0]
        yest_final_pivot2=pd.concat([yest_final_pivot2,yest_final_pivot1])
    except:
        pass


# In[21]:


yest_final_pivot2['Wt%','YST']=pd.np.round(yest_final_pivot2['ACT_WT2','YST']*100.0/yest_final_pivot2['Total','YST'],2)


# In[22]:


yest_final_pivot2['Wt%','MTD']=pd.np.round(yest_final_pivot2['ACT_WT2','MTD']*100.0/yest_final_pivot2['Total','MTD'],2)


# In[23]:


del yest_final_pivot2['Total']


# In[24]:
yest_final_pivot2.to_csv(r'D:\Data\PMD_Save\DepotWise Data & Summaries\All_Depots_Summary_'+str(datetime.strftime(datetime.now(),'%Y-%m-%d'))+'.csv')

yest_final_pivot3=yest_final_pivot2[['CPKG','Wt%']]


# In[25]:


yest_final_pivot3


# In[26]:


# depot_dict={'CCUD':{'TO':['mahesh.reddy@spoton.co.in'],'CC':['mahesh.reddy@spoton.co.in']},
#             'BLRD':{'TO':['mahesh.reddy@spoton.co.in'],'CC':['mahesh.reddy@spoton.co.in']},
#             'HYDD':{'TO':['mahesh.reddy@spoton.co.in'],'CC':['mahesh.reddy@spoton.co.in']},
#             'MAAD':{'TO':['mahesh.reddy@spoton.co.in'],'CC':['mahesh.reddy@spoton.co.in']},
#            'RTKD':{'TO':['mahesh.reddy@spoton.co.in'],'CC':['mahesh.reddy@spoton.co.in']},
#            'NCRD':{'TO':['mahesh.reddy@spoton.co.in'],'CC':['mahesh.reddy@spoton.co.in']},
#            'IXCD':{'TO':['mahesh.reddy@spoton.co.in'],'CC':['mahesh.reddy@spoton.co.in']},
#            'LKOD':{'TO':['mahesh.reddy@spoton.co.in'],'CC':['mahesh.reddy@spoton.co.in']},
#            'PNQD':{'TO':['mahesh.reddy@spoton.co.in'],'CC':['mahesh.reddy@spoton.co.in']},
#            'BOMD':{'TO':['mahesh.reddy@spoton.co.in'],'CC':['mahesh.reddy@spoton.co.in']},
#            'AMDD':{'TO':['mahesh.reddy@spoton.co.in'],'CC':['mahesh.reddy@spoton.co.in']},
#             'IDRD':{'TO':['mahesh.reddy@spoton.co.in'],'CC':['mahesh.reddy@spoton.co.in']}
#            }


# In[ ]:


depot_dict={'CCUD':{'TO':["avinash.singh@spoton.co.in"],'CC':["Rajesh.kumar@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","rajesh.kumar@spoton.co.in","mahesh.reddy@spoton.co.in"]},
        'BLRD':{'TO':["dominic.sathish@spoton.co.in"],'CC':["Rajesh.kumar@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","sasikumar.kannan@spoton.co.in","mahesh.reddy@spoton.co.in"]},
        'HYDD':{'TO':["jacob.mathew@spoton.co.in"],'CC':["Rajesh.kumar@spoton.co.in","Anto.Paul@Spoton.Co.In","sasikumar.kannan@spoton.co.in","goutam.barik@spoton.co.in","mahesh.reddy@spoton.co.in"]},
        'MAAD':{'TO':["joseph.arul.seelan@spoton.co.in","anish.kumar@spoton.co.in"],'CC':["Rajesh.kumar@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","sasikumar.kannan@spoton.co.in","mahesh.reddy@spoton.co.in"]},
       'RTKD':{'TO':["suresh.kp@spoton.co.in"],'CC':["Rajesh.kumar@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","sasikumar.kannan@spoton.co.in","mahesh.reddy@spoton.co.in"]},
       'NCRD':{'TO':["dinesh.kumar.sharma@spoton.co.in"],'CC':["pawan.sharma@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","mahesh.reddy@spoton.co.in"]},
        'IXCD':{'TO':["chhabil.singh@spoton.co.in","dinesh.kumar.sharma@spoton.co.in"],'CC':["pawan.sharma@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","mahesh.reddy@spoton.co.in"]},
        'LKOD':{'TO':["dinesh.kumar.sharma@spoton.co.in","pramod.pandey@spoton.co.in"],'CC':["pawan.sharma@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","mahesh.reddy@spoton.co.in"]},
        'PNQD':{'TO':["ramniwas.sharma@spoton.co.in"],'CC':["pawan.sharma@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","Rajesh.Debnath@Spoton.Co.In","mahesh.reddy@spoton.co.in"]},
        'BOMD':{'TO':["harish.bobade@spoton.co.in"],'CC':["pawan.sharma@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","Rajesh.Debnath@Spoton.Co.In","mahesh.reddy@spoton.co.in"]},
        'AMDD':{'TO':["balakrishnan.r@spoton.co.in"],'CC':["pawan.sharma@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","Rajesh.Debnath@Spoton.Co.In","mahesh.reddy@spoton.co.in"]},
        'IDRD':{'TO':["rajesh.mishra@spoton.co.in","Chhabil.Singh@spoton.co.in"],'CC':["pawan.sharma@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","Rajesh.Debnath@Spoton.Co.In","mahesh.reddy@spoton.co.in"]}
       }


# In[28]:

# ['CCUD','BLRD','MAAD','HYDD','RTKD','NCRD','IXCD','LKOD','PNQD','BOMD','AMDD','IDRD']
FROM="reports.ie@spoton.co.in"
#['CCUD','BLRD','MAAD','HYDD']
for i in ['CCUD','BLRD','MAAD','HYDD','RTKD','NCRD','IXCD','LKOD','PNQD','BOMD','AMDD','IDRD']:
    data_dff=dff[dff['DEPOT2']==i]
    data_dff.to_csv(r'D:\Data\PMD_Save\DepotWise Data & Summaries\\'+str(i)+'_Data.csv')
    filepa=r'D:\Data\PMD_Save\DepotWise Data & Summaries\\'+str(i)+'_Data.csv'
    depot_wise_df=yest_final_pivot2[yest_final_pivot2.index.get_level_values(level=0)==i]
    depot_wise_df.to_csv(r'D:\Data\PMD_Save\DepotWise Data & Summaries\\'+str(i)+'_Summary.csv')
    depot_wise_summary=yest_final_pivot3[yest_final_pivot3.index.get_level_values(level=0)==i]
    depot_wise_summary=depot_wise_summary.fillna(0)
    oppath1=r'D:\Data\PMD_Save\DepotWise Data & Summaries\\'+str(i)+'_Summary.csv'
    print ('Logging in...')
    ftp = ftplib.FTP()
    ftp.connect('10.109.230.50')
    print (ftp.getwelcome())
    try:
        try:
            ftp.login('IEPROJECTUSER', 'spotStar@123')
            ftp.cwd('ETA')
            # move to the desired upload directory
            print ("Currently in:", ftp.pwd())
            print ('Uploading...')
            fullname = filepa
            name = os.path.split(fullname)[1]
            f = open(fullname, "rb")
            ftp.storbinary('STOR ' + name, f)
            f.close()
            print ("OK"  )
            print ("Files:")
            print (ftp.retrlines('LIST'))
        finally:
            print ("Quitting...")
            ftp.quit()
    except:
        traceback.print_exc()
    TO=depot_dict[i]["TO"]
    CC=depot_dict[i]["CC"]


    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "PUD Monitoring Report-"+str(i) + '- ' + str(yesterdate)

    report=""
    report+='Dear All,'
    report+='<br>'
    report+='<br>'
    report+="PFB the "+str(i)+" PUD Monitoring Report as of "+str(yesterdate)
    report+='<br>'
    report+='<br>'
    report+= "PFB tthe summary"
    report+='<br>'
    report+='<br>'
    report+='<br>'+depot_wise_summary.to_html()+'<br>'
    report+='<br>'
    report+='<br>'
    report+='For Conwise data, please download from the link below'
    report+='<br>'
    report+='<br>'
    report+='http://spoton.co.in/downloads/IEProjects/ETA/'+str(i)+'_Data.csv'


    abc=MIMEText(report,'html')
    msg.attach(abc)

    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(oppath1,"rb").read() )
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
    msg.attach(part)



    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO+CC, msg.as_string())
    server.quit()



current_first_date=datetime.strftime(datetime.now(),'%Y-%m-%d')
yy=datetime.strftime(datetime.now()-timedelta(1),'%Y-%m-%d')
last_month=int(datetime.strftime(datetime.now(),'%m'))-1
curr_year=int(datetime.strftime(datetime.now(),'%Y'))
from calendar import monthrange
dm=monthrange(curr_year, last_month)[1]

lastmnth_last_date=datetime.strftime((datetime.now()-timedelta(days=30)).replace(day=dm),'%Y-%m-%d')

if yy==lastmnth_last_date:
    dff.to_csv(r'D:\Data\PMD_Save\DepotWise Data & Summaries\PMD_'+str(yy)+'.csv')
else:
    print ('Not last date')

# except:
#   TO=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
#   FROM="mahesh.reddy@spoton.co.in"
#   msg = MIMEMultipart()
#   msg["From"] = FROM
#   msg["To"] = ",".join(TO)
#   #msg["CC"] = ",".join(CC)
#   #msg["BCC"] = ",".join(BCC)
#   #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
#   msg["Subject"] = "ERROR Report" 
#   report=""
#   report+='Hi,'

#   report+='<br>'
#   report+='There was some error in PUD Monitoring Report'
#   report+='<br>'

#   abc=MIMEText(report.encode('utf-8'),'html')
#   msg.attach(abc)
#   server=smtplib.SMTP('smtp.sendgrid.net', 587)
#   server.ehlo()
#   server.starttls()
#   server.ehlo()
#   server.login("spoton.net.in", "Star@123#")
#   failed = server.sendmail(FROM, TO, msg.as_string())
#   server.quit()