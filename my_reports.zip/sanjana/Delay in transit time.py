
# coding: utf-8

# In[ ]:

from Networkmeeting_Reach import lhplanning
import numpy as np
import pandas as pd

from IPython import display
from datetime import datetime
from datetime import datetime,timedelta
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
import smtplib
import ftplib
import traceback
import calendar
import os
import Utilities


# In[ ]:

startdate=str(datetime.today().date()-timedelta(days=10))
enddate=str(datetime.today().date())

print (startdate,enddate)

a1=lhplanning(startdate,enddate)


# In[ ]:

d1=a1.thcdatapd

print (d1.columns)

# In[ ]:

d1['Transit time']=(d1['THC Finish Date']-d1['THC DATE']).astype('timedelta64[m]')

d1['Transit time(Hrs)']=pd.np.round(d1['Transit time']/60.0,1)

# In[ ]:

d1


# In[ ]:

pivot_df=d1.pivot_table(index=['ROUTE NAME'],values=['AdjWt','Transit time','THC NUMBER'],aggfunc={'Transit time':pd.np.mean,'AdjWt':sum,'THC NUMBER':len}).reset_index()


# In[ ]:

pivot_df['Transit time(Hrs)']=pivot_df['Transit time']/60

# In[ ]:

pivot_df


# In[ ]:

d2=a1.schedules_thc


# In[ ]:

d2.rename(columns={'Route Details':'ROUTE NAME'},inplace=True)
d2=d2.pivot_table(index=['ROUTE NAME'],values=['TT','Transit Distance'],aggfunc={'TT':pd.np.mean,'Transit Distance':pd.np.mean}).reset_index()

print (d2['ROUTE NAME'].values[0])
def changeValue(rname,tt):
	if rname=='BLRH-VZAH-IXWB-IXRB':
		return 67
	else:
		return tt
d2['TT']=d2.apply(lambda x:changeValue(x['ROUTE NAME'],x['TT']),axis=1)


d4=pd.merge(pivot_df,d2,on='ROUTE NAME')


# In[ ]:

d4['Delay in transit']=(d4['Transit time(Hrs)']-d4['TT'])


# In[ ]:

d5=d4.sort_values(['Delay in transit','Transit Distance'],ascending=False)


# In[ ]:

d6=d5[d5['Transit Distance']>=1000]

# In[ ]:

d6.rename(columns={'Delay in transit':'Average Delay in Transit Time(Hrs)'},inplace=True)
#d6['TimeStamp']=datetime.today()

# In[ ]:

d7=d6[d6['Average Delay in Transit Time(Hrs)']>5]


# In[ ]:

d8=d7[['ROUTE NAME','Transit Distance','AdjWt','Transit time(Hrs)','TT','Average Delay in Transit Time(Hrs)','THC NUMBER']]


# In[ ]:

d8['Average Delay in Transit Time(Hrs)']=pd.np.round(d8['Average Delay in Transit Time(Hrs)'],1)
d8['Transit time(Hrs)']=pd.np.round(d8['Transit time(Hrs)'],1)
d8['Transit Distance']=pd.np.round(d8['Transit Distance'],1)


# In[ ]:

reportts = datetime.now()
opfilevar=reportts.date()
opfilevar1=reportts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60
opfilevar2=np.round((float(currhrs)/60),0)


# In[ ]:

d6.to_csv(r'D:\Data\DelayInTransit\DelayInTransit_'+str(opfilevar)+'.csv')
d6.to_csv(r'D:\Data\DelayInTransit\DelayInTransit.csv')
d1.to_csv(r'D:\Data\DelayInTransit\Data_'+str(opfilevar)+'.csv')
d1.to_csv(r'D:\Data\DelayInTransit\Data.csv')

# In[ ]:

filepath=r'D:\Data\DelayInTransit\DelayInTransit.csv'
filepath1=r'D:\Data\DelayInTransit\Data.csv'
# In[ ]:

# In[52]:

TO=['jothi.menon@spoton.co.in']
# TO=['raghavendra.rao@spoton.co.in','cnm@spoton.co.in','HUBMGR_SPOT@spoton.co.in','ashok.dwivedi@spoton.co.in','kamlesh.sharma@spoton.co.in','sqtf@spoton.co.in','AOM_SPOT@spoton.co.in','DOM_SPOT@spoton.co.in','ROM_SPOT@spoton.co.in']
# CC=['pawan.sharma@spoton.co.in','satya.pal@spoton.co.in','mahesh.reddy@spoton.co.in','shashvat.suhane@spoton.co.in','saptarshi.pathak@spoton.co.in']
CC=['satya.pal@spoton.co.in','mahesh.reddy@spoton.co.in']
# CC=['mahesh.reddy@spoton.co.in']
FROM="reports.ie@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "Delay in Transit Time for Major Routes " + '- ' + str(opfilevar)+str('-')+ str(opfilevar2)
# msg["Subject"] = "Delay in Transit Time for Major Routes Consolidated "

html3='''
<h5> To download the data , Please click the link below </h5>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Hub_Perfor_Data.csv"</a>http://spoton.co.in/downloads/IEProjects/ETA/Hub_Perfor_Data.csv</p></b>

'''
report=""
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='Please find the below report on the average Transit Time delay(Last 10 Days) for major lanes.'
# report+='Please find the below consolidated report on the average Transit Time delay for major lanes.'

report+='<br>'
report+='<br>'
report+='<br>'+d8.to_html()+'<br>'
report+='<br>'
report+='<br>'


abc=MIMEText(report,'html')
msg.attach(abc)

part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(filepath1,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
msg.attach(part1)


server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()


# In[ ]:



