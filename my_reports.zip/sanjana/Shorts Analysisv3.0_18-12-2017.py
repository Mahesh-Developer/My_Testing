
# coding: utf-8

# In[1]:

import sframe as gl
import sframe.aggregate as agg
import pandas as pd
from datetime import datetime, timedelta
import networkx as nx
import time

import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
import os
import Utilities

# In[2]:
#condata = gl.SFrame(r'D:\Python\Scripts and Files\Path and Graph Files\Con_data_201016.csv')
condata = gl.SFrame(r'http://spoton.co.in/downloads/IEP_CON_DATA_TO_SQ/IEP_CON_DATA_TO_SQ.csv')
condata = condata.rename({'\xef\xbb\xbfDOCKNO': 'DOCKNO'})


#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
#cursor = cnxn.cursor()
#
#condataquery = ("""
#        EXEC USP_CON_DATA_SQ_IE
#        """)
##
##condatadf = pd.read_sql(condataquery, cnxn)
##condatadf.to_csv(r'D:\Python\Scripts and Files\Path and Graph Files\Condata18Oct_test.csv')
##print 'condatadf',type(condatadf)
##print condatadf['Pickupdate'].values[0]
##
##
##condata = gl.SFrame(data=condatadf)
##print type (condata)
##print condata['Pickupdate'][0]
#
#condata = gl.SFrame.from_sql(cnxn, condataquery)
#
##condata = gl.SFrame(r'D:\Python\Scripts and Files\Path and Graph Files\Condata18Oct_test.csv')
#print 'condata',type(condata)
#
#print condata.column_names()
#
##condata = condata.remove_column('X1')
#
#print condata.column_names()
# In[3]:

condata['pkphr'] = condata.apply(lambda x: int(x['Pickupdate'].split(' ')[1].split(':')[0]))
dayzero = datetime.strptime('01/01/2016','%d/%m/%Y')
timeformat2 = '%Y-%m-%d'
timeformat3 = '%d/%m/%y'
timeformat4 = '%d-%b-%y'
timeformat5 = '%d-%m-%Y'

def convertdate2(*vars):
    x = vars[0]
    flag = vars[1]
    timeformata = timeformat2
    timeformatb = timeformat3
    timeformatc = timeformat4
    timeformatd = timeformat5
    
    try:       
        x = x.split(' ')[0]
        return datetime.strptime(x,timeformata)
    except:
        try:
            x = x.split(' ')[0]
            return datetime.strptime(x,timeformatb)
        except:
            try:
                x = x.split(' ')[0]
                return datetime.strptime(x,timeformatc)
            except:
                try:
                    x = x.split(' ')[0]
                    return datetime.strptime(x,timeformatd)    
                except:
                    if flag=='today':
                        return datetime.today()
                    else:
                        return dayzero
condata['PickupDate'] = condata.apply(lambda x: convertdate2(x['Pickupdate'],'dayz'))


# In[4]:

#last 30 days short data
#shortdata = gl.SFrame.read_csv_with_errors(r'D:\Python\Scripts and Files\Path and Graph Files\Deps_data_201016.csv')
shortdata = gl.SFrame(r'http://spoton.co.in/downloads/IEP_DEPS_DATA_TO_SQ/IEP_DEPS_DATA_TO_SQ.csv')
shortdata.rename({'\xef\xbb\xbfDOCKNO': 'DOCKNO'})
print 'len(shortdata)', len(shortdata)
#shortdata = shortdata.rename({'\xef\xbb\xbfDOCKNO': 'DOCKNO'})

#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
#cursor = cnxn.cursor()
#
#shortconquery = ("""
#        EXEC dbo.USP_DEPS_DATA_TO_SQ_IE
#        """)
#
#shortdatadf = pd.read_sql(shortconquery, cnxn)
##shortdatadf.to_csv(r'D:\Python\Scripts and Files\Path and Graph Files\Deps18Oct_test.csv')
#print 'shortdatadf',type(shortdatadf)

#shortdata = gl.SFrame(data=shortdatadf)
#
##shortdata = gl.SFrame.read_csv_with_errors(r'D:\Python\Scripts and Files\Path and Graph Files\Deps18Oct_test.csv')
##shortdata = gl.SFrame(r'D:\Python\Scripts and Files\Path and Graph Files\Deps18Oct_test.csv')
#print 'shortdata',type(shortdata)
#
#print shortdata.column_names()
#
##shortdata = shortdata.remove_column('X1')
#
#print shortdata.column_names()

#shortdata = shortdata[0]
shortdata.rename({'CapturedLocation': 'dest', 'COMING_FROM':'org'})
print shortdata.column_names()

def daysdiff(a,b):
    return (a-b).days

shortdata['PickupDate'] = shortdata.apply(lambda x: convertdate2(x['DOCKDT'],'dayz'))
shortdata['statusdate'] = shortdata.apply(lambda x: convertdate2(x['ConStatusDate'],'dayz'))
#shiv will give data later#shortdata['resdate'] = shortdata.apply(lambda x: convertdate2(x['Resolution Date'],'today'))
#shiv will give data later#shortdata['days_to_res'] = shortdata.apply(lambda x: daysdiff(x['resdate'],x['statusdate']))
                                          
shortgrp = shortdata.groupby(['org','dest'],{'S_Con': agg.COUNT_DISTINCT('DOCKNO'),'S_Pcs': agg.SUM('PKGSNO'),'Pieces_30':agg.SUM('DEPSPcs')})


# In[5]:

datetoday = datetime.today().date()
yestrdy = datetoday-timedelta(days=1)
lastweek = datetoday-timedelta(days=7)

print shortdata['ConStatusDate'].unique
print shortdata['ConStatusDate'][0], shortdata['statusdate'][0], yestrdy
print type(shortdata['ConStatusDate'][0]), type(shortdata['statusdate'][0]), type(yestrdy)
# In[6]:

#yesterday short data
shortdata_yst = shortdata[shortdata['statusdate']==yestrdy]
#print 'shortdata_yst', shortdata['statusdate'][0], type(shortdata['statusdate'][0]),yestrdy, type(yestrdy), len(shortdata_yst)
shortgrp_yst = shortdata_yst.groupby(['org','dest'],{'S_Con_Y': agg.COUNT_DISTINCT('DOCKNO'),'S_Pcs_Y': agg.SUM('PKGSNO'),'Pieces_Y':agg.SUM('DEPSPcs')})


# In[7]:

#last 7 days short data
shortdata_week = shortdata[shortdata['statusdate']>=lastweek]
#print 'shortdata_week', shortdata['statusdate'][0], type(shortdata['statusdate'][0]),lastweek, type(lastweek), len(shortdata_week)
shortgrp_week = shortdata_week.groupby(['org','dest'],{'S_Con_Wk': agg.COUNT_DISTINCT('DOCKNO'),'S_Pcs_Wk': agg.SUM('PKGSNO'),'Pieces_7':agg.SUM('DEPSPcs')})
# In[8]:

## weight = concount, length = piece count, label = month (removed)

def movementgraphops(path,pcs):
    conpath = path.split('-')
    for step in range(0,len(conpath)-1):
        org = conpath[step]
        dest = conpath[step+1]
        if movementgraph.has_edge(org,dest):
            wt = movementgraph.get_edge_data(org,dest)['weight']
            pieces = movementgraph.get_edge_data(org,dest)['length']
            pieces = pcs+pieces
            movementgraph.add_edge(org,dest,weight =wt+1,length = pieces)
        else:
            movementgraph.add_edge(org,dest,weight =1, length = pcs)
    return 'done'


# In[9]:

movementmastersf = gl.SFrame({'org': ['test'], 'dest': ['test'], 'totalcon': [0], 'Pieces': [0]})
movementgraph = nx.DiGraph()
for cons in condata:
    movementgraphops(cons['OD_PATH'],cons['PKGSNO'])
movementdict = {}
for i in movementgraph.edges():
    wt = movementgraph.get_edge_data(i[0],i[1])['weight']
    pieces = movementgraph.get_edge_data(i[0],i[1])['length']
    movementdict.update({(i[0],i[1]):(wt,pieces)})
orgarray= gl.SArray(zip(*movementdict.keys())[0])
destarray= gl.SArray(zip(*movementdict.keys())[1])
wtarray = gl.SArray(zip(*movementdict.values())[0])
pcarray = gl.SArray(zip(*movementdict.values())[1])
movementsf = gl.SFrame({'org': orgarray, 'dest': destarray, 'totalcon': wtarray, 'Pieces': pcarray})

movementmastersf.save(r'D:\Python\Scripts and Files\Path and Graph Files\movementmastersf.csv')
movementsf.save(r'D:\Python\Scripts and Files\Path and Graph Files\movementsf.csv')

movementmastersf = movementmastersf.append(movementsf)


# In[10]:

joinsf = movementmastersf.join(shortgrp, on = ['org','dest']) #default join is inner join
joinsf1 = joinsf.join(shortgrp_week,on = ['org','dest'], how = 'left')
finalsf = joinsf1.join(shortgrp_yst,on = ['org','dest'], how = 'left')
finalsf = finalsf.fillna('S_Con_Wk', 0)
finalsf = finalsf.fillna('S_Con_Y', 0)
finalsf = finalsf.fillna('Pieces_7', 0)
finalsf = finalsf.fillna('Pieces_Y', 0)
finalsf = finalsf.fillna('Pieces_30', 0)

# In[11]:

finalsf


# In[12]:

finalsf['%'] = finalsf.apply(lambda x: round(x['S_Con']*100.0/x['totalcon'],2))
finalsf['%Wk'] = finalsf.apply(lambda x: round((x['S_Con_Wk']*100.0)/(x['totalcon']*7.0/29.0),2))
finalsf['%Y'] = finalsf.apply(lambda x: round((x['S_Con_Y']*100.0)/(x['totalcon']/29.0),2))
finalsf['P_30%'] = finalsf.apply(lambda x: round(x['Pieces_30']*100.0/x['Pieces'],2))
finalsf['P_%Wk'] = finalsf.apply(lambda x: round((x['Pieces_7']*100.0)/(x['Pieces']*7.0/29.0),2))
finalsf['P_%Y'] = finalsf.apply(lambda x: round((x['Pieces_Y']*100.0)/(x['Pieces']/29.0),2))


# In[14]:

finalsf = finalsf.sort([('S_Con',False),('%',False)])


# In[15]:

finalsf = finalsf['org','dest','totalcon','Pieces','S_Con','S_Pcs','S_Con_Wk','S_Pcs_Wk','S_Con_Y','S_Pcs_Y','%','%Wk','%Y','P_30%','P_%Wk','P_%Y','Pieces_30','Pieces_7','Pieces_Y']
#finalsf = finalsf['org','dest','totalcon','S_Con','S_Con_Wk','S_Con_Y','perc','perc_Wk','perc_Y']
sheet_list=pd.ExcelFile(r'C:\Users\rajeeshv\Downloads\Shortage trend Jan-Dec_2017.xlsx')
phase1_df=pd.read_excel(sheet_list,'Phase 1')
phase2_df=pd.read_excel(sheet_list,'Phase 2')
phase3_df=pd.read_excel(sheet_list,'Phase 3')
phase1_list=phase1_df['BRCD'].tolist()
phase2_list=phase2_df['BRCD'].tolist()
phase3_list=phase3_df['BRCD'].tolist()
print ('len(finalsf)',len(finalsf))
phase1_finalsf=finalsf.filter_by(phase1_list,'org')
phase2_finalsf=finalsf.filter_by(phase2_list,'org')
phase3_finalsf=finalsf.filter_by(phase3_list,'org')
print (phase3_finalsf)

datetoday = datetime.today()
datefilter = datetoday-timedelta(hours=24)
datefilter=datefilter.date()
datefilter

#calculating shortage for phase1
phase1_finaldf = phase1_finalsf.to_dataframe()
phase1_shortcons_30 = phase1_finaldf['S_Con'].sum()
phase1_shortcons_7 = phase1_finaldf['S_Con_Wk'].sum()
phase1_shortcons_y = phase1_finaldf['S_Con_Y'].sum()
phase1_Pieces_30_total=phase1_finaldf['Pieces_30'].sum()
phase1_pieces_7_total=phase1_finaldf['Pieces_7'].sum()
phase1_Pieces_Y_total=phase1_finaldf['Pieces_Y'].sum()

phase1_totalcons = phase1_finaldf['totalcon'].sum()
phase1_totalpieces=phase1_finaldf['Pieces'].sum()

phase1_shortperc_30 = pd.np.round((phase1_shortcons_30*1.0/phase1_totalcons)*100.0,2)
phase1_shortperc_7 = pd.np.round((phase1_shortcons_7*1.0/(phase1_totalcons*7.0/29.0))*100.0,2)
phase1_shortperc_y = pd.np.round((phase1_shortcons_y*1.0/(phase1_totalcons/29.0))*100.0,2)
phase1_piecesper_30=pd.np.round((phase1_Pieces_30_total*1.0/phase1_totalpieces)*100.0,2)
phase1_piecesper_7 = pd.np.round((phase1_pieces_7_total*1.0/(phase1_totalpieces*7.0/29.0))*100.0,2)
phase1_piecesper_Y = pd.np.round((phase1_Pieces_Y_total*1.0/(phase1_totalpieces/29.0))*100.0,2)


phase1_finaldf.loc[phase1_finaldf.index,'Date'] = datefilter


# phase1_finaldf.to_csv(r'D:\Data\Shortage_report\Shortage_report_'+str(datefilter)+'.csv')
# oppath1 = r'D:\Data\Shortage_report\Shortage_report_'+str(datefilter)+'.csv'
# In[17]:

phase1_finaldf_mail1 = phase1_finaldf[['org','dest','totalcon','Pieces','S_Con','S_Con_Wk','S_Con_Y','%','%Wk','%Y','P_30%','P_%Wk','P_%Y','Pieces_30','Pieces_7','Pieces_Y']]

 #mail body
phase1_finaldf_mail = phase1_finaldf_mail1.head(15)

#finaldf_mail.rename(columns={'org':'Origin'}, inplace=True)
phase1_finaldf_mail = phase1_finaldf_mail.to_string(index=False)




#end of phase1

#calculating shortage for phase2
phase2_finaldf = phase2_finalsf.to_dataframe()
phase2_shortcons_30 = phase2_finalsf['S_Con'].sum()
phase2_shortcons_7 = phase2_finalsf['S_Con_Wk'].sum()
phase2_shortcons_y = phase2_finalsf['S_Con_Y'].sum()
phase2_Pieces_30_total=phase2_finalsf['Pieces_30'].sum()
phase2_pieces_7_total=phase2_finalsf['Pieces_7'].sum()
phase2_Pieces_Y_total=phase2_finalsf['Pieces_Y'].sum()

phase2_totalcons = phase2_finalsf['totalcon'].sum()
phase2_totalpieces=phase2_finalsf['Pieces'].sum()

phase2_shortperc_30 = pd.np.round((phase2_shortcons_30*1.0/phase2_totalcons)*100.0,2)
phase2_shortperc_7 = pd.np.round((phase2_shortcons_7*1.0/(phase2_totalcons*7.0/29.0))*100.0,2)
phase2_shortperc_y = pd.np.round((phase2_shortcons_y*1.0/(phase2_totalcons/29.0))*100.0,2)
phase2_piecesper_30=pd.np.round((phase2_Pieces_30_total*1.0/phase2_totalpieces)*100.0,2)
phase2_piecesper_7 = pd.np.round((phase2_pieces_7_total*1.0/(phase2_totalpieces*7.0/29.0))*100.0,2)
phase2_piecesper_Y = pd.np.round((phase2_Pieces_Y_total*1.0/(phase2_totalpieces/29.0))*100.0,2)


phase2_finaldf.loc[phase2_finaldf.index,'Date'] = datefilter


# phase1_finaldf.to_csv(r'D:\Data\Shortage_report\Shortage_report_'+str(datefilter)+'.csv')
# oppath1 = r'D:\Data\Shortage_report\Shortage_report_'+str(datefilter)+'.csv'
# In[17]:

phase2_finaldf_mail1 = phase2_finaldf[['org','dest','totalcon','Pieces','S_Con','S_Con_Wk','S_Con_Y','%','%Wk','%Y','P_30%','P_%Wk','P_%Y','Pieces_30','Pieces_7','Pieces_Y']]

 #mail body
phase2_finaldf_mail = phase2_finaldf_mail1.head(15)
#finaldf_mail.rename(columns={'org':'Origin'}, inplace=True)
phase2_finaldf_mail = phase2_finaldf_mail.to_string(index=False)




#end of phase2

#calculating shortage for phase3
phase3_finaldf = phase3_finalsf.to_dataframe()
phase3_shortcons_30 = phase3_finalsf['S_Con'].sum()
phase3_shortcons_7 = phase3_finalsf['S_Con_Wk'].sum()
phase3_shortcons_y = phase3_finalsf['S_Con_Y'].sum()
phase3_Pieces_30_total=phase3_finalsf['Pieces_30'].sum()
phase3_pieces_7_total=phase3_finalsf['Pieces_7'].sum()
phase3_Pieces_Y_total=phase3_finalsf['Pieces_Y'].sum()

phase3_totalcons = phase3_finalsf['totalcon'].sum()
phase3_totalpieces=phase3_finalsf['Pieces'].sum()

phase3_shortperc_30 = pd.np.round((phase3_shortcons_30*1.0/phase3_totalcons)*100.0,2)
phase3_shortperc_7 = pd.np.round((phase3_shortcons_7*1.0/(phase3_totalcons*7.0/29.0))*100.0,2)
phase3_shortperc_y = pd.np.round((phase3_shortcons_y*1.0/(phase3_totalcons/29.0))*100.0,2)
phase3_piecesper_30=pd.np.round((phase3_Pieces_30_total*1.0/phase3_totalpieces)*100.0,2)
phase3_piecesper_7 = pd.np.round((phase3_pieces_7_total*1.0/(phase3_totalpieces*7.0/29.0))*100.0,2)
phase3_piecesper_Y = pd.np.round((phase3_Pieces_Y_total*1.0/(phase3_totalpieces/29.0))*100.0,2)


phase3_finaldf.loc[phase3_finaldf.index,'Date'] = datefilter


# phase1_finaldf.to_csv(r'D:\Data\Shortage_report\Shortage_report_'+str(datefilter)+'.csv')
# oppath1 = r'D:\Data\Shortage_report\Shortage_report_'+str(datefilter)+'.csv'
# In[17]:

phase3_finaldf_mail1 = phase3_finaldf[['org','dest','totalcon','Pieces','S_Con','S_Con_Wk','S_Con_Y','%','%Wk','%Y','P_30%','P_%Wk','P_%Y','Pieces_30','Pieces_7','Pieces_Y']]
print (type(phase3_finaldf_mail1))
 #mail body
phase3_finaldf_mail = phase3_finaldf_mail1.head(15)
#finaldf_mail.rename(columns={'org':'Origin'}, inplace=True)
phase3_finaldf_mail = phase3_finaldf_mail.to_string(index=False)




#end of phase3



# In[16]:



#finalsf.save('finalsf_new.csv') #to write it into attachment + save it using ts
finaldf = finalsf.to_dataframe()
shortcons_30 = finaldf['S_Con'].sum()
shortcons_7 = finaldf['S_Con_Wk'].sum()
shortcons_y = finaldf['S_Con_Y'].sum()
Pieces_30_total=finaldf['Pieces_30'].sum()
pieces_7_total=finaldf['Pieces_7'].sum()
Pieces_Y_total=finaldf['Pieces_Y'].sum()

totalcons = finaldf['totalcon'].sum()
totalpieces=finaldf['Pieces'].sum()

shortperc_30 = pd.np.round((shortcons_30*1.0/totalcons)*100.0,2)
shortperc_7 = pd.np.round((shortcons_7*1.0/(totalcons*7.0/29.0))*100.0,2)
shortperc_y = pd.np.round((shortcons_y*1.0/(totalcons/29.0))*100.0,2)
piecesper_30=pd.np.round((Pieces_30_total*1.0/totalpieces)*100.0,2)
# piecesper_7=pd.np.round((pieces_7_total*1.0/totalpieces)*100.0,2)
# piecesper_Y=pd.np.round((Pieces_Y_total*1.0/totalpieces)*100.0,2)
piecesper_7 = pd.np.round((pieces_7_total*1.0/(totalpieces*7.0/29.0))*100.0,2)
piecesper_Y = pd.np.round((Pieces_Y_total*1.0/(totalpieces/29.0))*100.0,2)


finaldf.loc[finaldf.index,'Date'] = datefilter



# In[17]:
#finalsf['Phase1']=finalsf[finalsf.filter_by(phase1_list,'org')]

finalsf_mail = finalsf['org','dest','totalcon','Pieces','S_Con','S_Con_Wk','S_Con_Y','%','%Wk','%Y','P_30%','P_%Wk','P_%Y','Pieces_30','Pieces_7','Pieces_Y']

df_phase_list=pd.read_excel(r'C:\Users\rajeeshv\Downloads\Phase_list.xlsx')
df_phase_list=df_phase_list.rename(columns={'BRCD':'org'})
finaldf_mail_all = finalsf_mail.to_dataframe()
finaldf_mail_phase_list=finaldf_mail_all.merge(df_phase_list,on='org',how='inner')
#print (finaldf_mail_phase_list)
#print (type(phase1_finaldf_mail))

#
#mail body
finaldf_mail = finalsf_mail.to_dataframe().head(15)
finaldf_mail = finalsf_mail.to_dataframe().head(15)
finaldf_mail1 = finaldf_mail.merge(phase1_finaldf_mail1, on = ['org','dest'], suffixes=['','_phase1'],how='outer')
finaldf_mail2 = finaldf_mail1.merge(phase2_finaldf_mail1, on = ['org','dest'], suffixes=['','_phase2'],how='outer')
finaldf_mail3 = finaldf_mail2.merge(phase3_finaldf_mail1, on = ['org','dest'], suffixes=['','_phase3'],how='outer')
print (len(finaldf_mail3))

# dfs=[finaldf_mail,phase1_finaldf_mail1,phase2_finaldf_mail1,phase3_finaldf_mail1]
# df_final=reduce(lambda left, right :pd.merge(left,right,on='org'),dfs)
final_dd=finaldf_mail.merge(phase1_finaldf_mail1,on=['org'],how='outer')
final_dd1=final_dd.merge(phase2_finaldf_mail1,on=['org'],how='outer')
finaldf_mail1=final_dd1.merge(phase3_finaldf_mail1,on=['org'],how='outer')
#finaldf_mail['new'] = finaldf_mail.org.isin(phase3_finaldf_mail1.org)
finaldf_mail3=finaldf_mail3.fillna(0)
#finaldf['phase1']=pd.Series(phase1_list)
with ExcelWriter(r'D:\Data\Shortage_report\Shortage_report_'+str(datefilter)+'.xlsx') as writer:
    finaldf_mail_phase_list.to_excel(writer,sheet_name='Shortage_report',engine='xlsxwriter')
    phase1_finaldf_mail1.to_excel(writer,sheet_name='Phase1_Shortage_report',engine='xlsxwriter')
    phase2_finaldf_mail1.to_excel(writer,sheet_name='Phase2_Shortage_report',engine='xlsxwriter')
    phase3_finaldf_mail1.to_excel(writer,sheet_name='Phase3_Shortage_report',engine='xlsxwriter')
#finaldf_mail3.to_csv(r'D:\Data\Shortage_report\Shortage_report_'+str(datefilter)+'.csv')
oppath1 = r'D:\Data\Shortage_report\Shortage_report_'+str(datefilter)+'.xlsx'
# print (finaldf)
finaldf_mail = finaldf_mail.to_string(index=False)



# In[ ]:
filePath = oppath1
def sendEmail(#TO = ["sq_spot@spoton.co.in"],
             TO = ["mahesh.reddy@spoton.co.in"],
             #BCC =  ["vishwas.j@spoton.co.in","shivananda.p@spoton.co.in"],
             #CC =  ["sqtf@spoton.co.in"],
             CC =  ["mahesh.reddy@spoton.co.in"],
             BCC =  ["mahesh.reddy@spoton.co.in"],
            #FROM="mis.ho@spoton.co.in"):
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
    #HOST = "smpt.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)
#reports.ie@spoton.co.in
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DEPOTWISE OPS Bucket Stock  - "+ str(datefilter)
    msg["Subject"] = "Shortage Report - "+ str(datefilter)
    body_text = """
    Dear All,
    
    PFB the Shortage Report as of """ + str(datefilter) +"""
    
    Shortage reported % on the basis number of cons

    Overall reported Transhipment Shortage %-ge for last 30 days = """ +str(shortperc_30)+""" %
    Overall reported Transhipment Shortage %-ge for last 7 days = """ +str(shortperc_7)+""" %
    Overall reported Transhipment Shortage %-ge for yesterday = """ +str(shortperc_y)+""" %


    Shortage reported % on the basis number of pieces

    Overall reported Transhipment Shortage %-ge for last 30 days = """ +str(piecesper_30)+""" %
    Overall reported Transhipment Shortage %-ge for last 7 days = """ +str(piecesper_7)+""" %
    Overall reported Transhipment Shortage %-ge for yesterday = """ +str(piecesper_Y)+""" %

    PHASE-1
    
    Shortage reported % on the basis number of cons

    Overall reported Transhipment Shortage %-ge for last 30 days = """ +str(phase1_shortperc_30)+""" %
    Overall reported Transhipment Shortage %-ge for last 7 days = """ +str(phase1_shortperc_7)+""" %
    Overall reported Transhipment Shortage %-ge for yesterday = """ +str(phase1_shortperc_y)+""" %


    Shortage reported % on the basis number of pieces

    Overall reported Transhipment Shortage %-ge for last 30 days = """ +str(phase1_piecesper_30)+""" %
    Overall reported Transhipment Shortage %-ge for last 7 days = """ +str(phase1_piecesper_7)+""" %
    Overall reported Transhipment Shortage %-ge for yesterday = """ +str(phase1_piecesper_Y)+""" %


    PHASE-2

    Shortage reported % on the basis number of cons

    Overall reported Transhipment Shortage %-ge for last 30 days = """ +str(phase2_shortperc_30)+""" %
    Overall reported Transhipment Shortage %-ge for last 7 days = """ +str(phase2_shortperc_7)+""" %
    Overall reported Transhipment Shortage %-ge for yesterday = """ +str(phase2_shortperc_y)+""" %


    Shortage reported % on the basis number of pieces

    Overall reported Transhipment Shortage %-ge for last 30 days = """ +str(phase2_piecesper_30)+""" %
    Overall reported Transhipment Shortage %-ge for last 7 days = """ +str(phase2_piecesper_7)+""" %
    Overall reported Transhipment Shortage %-ge for yesterday = """ +str(phase2_piecesper_Y)+""" %

    PHASE-3

    Shortage reported % on the basis number of cons

    Overall reported Transhipment Shortage %-ge for last 30 days = """ +str(phase3_shortperc_30)+""" %
    Overall reported Transhipment Shortage %-ge for last 7 days = """ +str(phase3_shortperc_7)+""" %
    Overall reported Transhipment Shortage %-ge for yesterday = """ +str(phase3_shortperc_y)+""" %


    Shortage reported % on the basis number of pieces

    Overall reported Transhipment Shortage %-ge for last 30 days = """ +str(phase3_piecesper_30)+""" %
    Overall reported Transhipment Shortage %-ge for last 7 days = """ +str(phase3_piecesper_7)+""" %
    Overall reported Transhipment Shortage %-ge for yesterday = """ +str(phase3_piecesper_Y)+""" %


    
"""+str(finaldf_mail)+"""
        
    """
    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    #server.login("mis.ho@spoton.co.in", "Mis@2019")
    #server.login("spoton.net.in", "Star@123#")
    server.login("mahesh.reddy@spoton.co.in", "Ma@9441028643")

    try:
        failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
#print('Email sent')


