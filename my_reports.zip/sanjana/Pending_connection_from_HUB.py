
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta
import sys
import Utilities
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
from email.mime.base import MIMEBase
# from email import Encoders
import os
from email import encoders

reload(sys).setdefaultencoding("ISO-8859-1")

# In[2]:


# cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")


# # In[3]:


# cursor=cnxn.cursor()
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()

# In[4]:

# try:
query=(""" SELECT --TOP 20

                    A.DOCKNO ,

                    A.CDELDT ,

                    A.DC ,

                    DACCC ,

                    A.VTC ,

                    A.FTC ,

                    BOOKING_REGION ,

                    ACTUAL_WEIGHT ,

                    PKGSNO ,

                    A.VOLUME ,

                    ORIGIN_BRCODE ,

                    ORIGIN_BRNAME ,

                    orgareaname ,

                    A.DEFAULTHUB ORIGINHUB ,

                    ORGLOCTYPE ,

                    DESTCD ,

                    destareaname ,

                    DESTHUB ,

                    DESTLOCTYPE ,

                    PINCODE ,

                    DOCKDT ,

                    CURR_AREA ,

                    CURR_BRANCHCODE ,

                    CURR_BRANCHNAME ,

                    C.RGALPH CURR_REGION ,

                    ARRV_AT_CURR_LOCATION ,

                    HOURS_LYING_AT_CURR_LOCATION ,

                    ISDEPARTED_FRM_CURRLOC ,

                    A.CurLocConStatusCategory,

                    A.CurLocConStatusCode,

                    A.CurLocConStatusDesc,

                    A.CurLocConStatusReason,

                    A.CurLocConStatusDate ,

                    A.LatestConStatusCategory ,

                    A.LatestConStatusCode ,

                    A.LatestConStatusDesc ,

                    A.LatestConStatusReason ,

                    A.LatestConStatusDate ,

                    A.CSGNCD ,

                    REPLACE(A.CSGNNM,'"','') CSGNNM,

                    A.CSGECD ,

                    REPLACE(A.CSGENM,'"','') CSGENM ,

                    TIME_STAMP ,

                    CSAgentEmpCode ,

                    D.EMPNM ,

                    dbo.UFN_GET_NEXT_NODE_CNNO(A.ORIGIN_BRCODE,A.DESTCD,A.CURR_BRANCHCODE,A.DOCKNO) NEXT_LOC ,

                    DATEDIFF(DAY, A.ARRV_AT_CURR_LOCATION, A.TIME_STAMP) CON_LYING_CURRR_LOCATION ,

                    CASE WHEN A.ISDEPARTED_FRM_CURRLOC = 'NO'

                         THEN CAST(DATEDIFF(HOUR, A.ARRV_AT_CURR_LOCATION,

                                            GETDATE()) AS VARCHAR)

                         ELSE '-'

                    END [COOLING HOURS] ,

                    CASE WHEN A.ISDEPARTED_FRM_CURRLOC = 'NO'

                              AND DATEDIFF(HOUR, A.ARRV_AT_CURR_LOCATION,

                                           GETDATE()) <= 24 THEN '<24 HRS'

                         WHEN A.ISDEPARTED_FRM_CURRLOC = 'NO'

                              AND DATEDIFF(HOUR, A.ARRV_AT_CURR_LOCATION,

                                           GETDATE()) > 24

                              AND DATEDIFF(HOUR, A.ARRV_AT_CURR_LOCATION,

                                           GETDATE()) <= 48

                         THEN '25 to 48 HRS'

                         WHEN A.ISDEPARTED_FRM_CURRLOC = 'NO'

                              AND DATEDIFF(HOUR, A.ARRV_AT_CURR_LOCATION,

                                           GETDATE()) > 48

                              AND DATEDIFF(HOUR, A.ARRV_AT_CURR_LOCATION,

                                           GETDATE()) <= 72

                         THEN '49 to 72 HRS'

                         WHEN A.ISDEPARTED_FRM_CURRLOC = 'NO'

                              AND DATEDIFF(HOUR, A.ARRV_AT_CURR_LOCATION,

                                           GETDATE()) > 72

                              AND DATEDIFF(HOUR, A.ARRV_AT_CURR_LOCATION,

                                           GETDATE()) <= 96

                         THEN '72 to 96 HRS'

                         WHEN A.ISDEPARTED_FRM_CURRLOC = 'NO'

                              AND DATEDIFF(HOUR, A.ARRV_AT_CURR_LOCATION,

                                           GETDATE()) > 96 THEN '> 96 HRS'

                         ELSE '-'

                    END [COOLING BUCKET] ,

                    CASE WHEN ( A.CURR_BRANCHCODE = A.DESTCD ) THEN 'DESTN'

                         WHEN ( A.CURR_BRANCHCODE = A.ORIGIN_BRCODE )

                         THEN 'ORIGIN'

                         WHEN ( C.HUBCENTER = 'Y' ) THEN 'HUB'

                         ELSE 'IN-TRANSIT'

                    END LOCATION

          FROM      dbo.tblTimeConnectionReport_Undelivered_2Hrs A

          INNER JOIN dbo.brms C WITH ( NOLOCK ) ON A.CURR_BRANCHCODE = C.BRCD

          INNER JOIN dbo.EMPMST D WITH ( NOLOCK ) ON A.CSAgentEmpCode = D.EMPCD

          WHERE     A.ISDEPARTED_FRM_CURRLOC = 'NO'

            AND A.CURR_BRANCHCODE != A.DESTCD  """ )


# In[5]:


#data=pd.read_sql(query,Utilities.cnxn)
data=pd.read_sql(query,Utilities.cnxn)
print (len(data),'data')
# In[7]:


data = data[data['LOCATION']=='HUB']



data = data[~data['CurLocConStatusCategory'].isin(['SENDER FAILURE','RECEIVER FAILURE'])]


# In[11]:


data = data[~data['CurLocConStatusCode'].isin(['SRD','SRE','SRP','SRS'])] # doubt any other is there


# In[14]:


final_list=['Paper Works Received Without Shipment',
'Held in Hub Due to Paperwork Missing',
'Shipment Label or boxes Criss - Crossed',
'Held in Checkpost due to missing or incorrect paperwork',
'Shipment Received without Paper Works']


# In[15]:


data=data[~data['CurLocConStatusDesc'].isin(final_list)]


# In[17]:


top11 = data[data['CURR_BRANCHCODE'].isin(['BLRH','CCUH','AMDH','DELH','AMCH','BOMH','PNQH','HYDH','MAAH','NAGH','BRGH'])]
print (len(top11['CURR_BRANCHCODE'].unique()))


# In[19]:


pivot11=pd.pivot_table(top11,index=["CURR_BRANCHCODE"],columns=["COOLING BUCKET"],values=["DOCKNO"],aggfunc={"DOCKNO":len},fill_value='0',margins=True)


# In[20]:


pivot11


# In[21]:


#pivot11.sortlevel(axis=1, level=[1,0], sort_remaining=True)
pivot11=pivot11.sort_values([('DOCKNO', 'All')], ascending=False).astype(int)
print (pivot11)


# In[ ]:


# pivot11=pivot10.sort_values(by='All',ascending=False)
# pivot11.columns
# idx1 = pivot11.sortlevel(level=pivot11.index['All']).index



# In[22]:


top_remains = data[~data['CURR_BRANCHCODE'].isin(['BLRH','CCUH','AMDH','DELH','AMCH','BOMH','PNQH','HYDH','MAAH','NAGH','BRGH'])]


# In[23]:


len(top_remains)
print (len(top_remains['CURR_BRANCHCODE'].unique()))


# In[24]:


pivot_remains=pd.pivot_table(top_remains,index=["CURR_BRANCHCODE"],columns=["COOLING BUCKET"],values=["DOCKNO"],aggfunc={"DOCKNO":len},fill_value='0',margins=True)


# In[25]:


pivot_remains=pivot_remains.sort_values([('DOCKNO', 'All')], ascending=False).astype(int)
pivot_remains


# In[ ]:


#pivot_remains=pivot_remains.sort_values(by='CURR_BRANCHCODE',ascending=False)


# In[ ]:


from pandas import ExcelWriter


# In[ ]:


with ExcelWriter(r'D:\Data\ODA_Loads_Ton_wise\Pen_HUB_Cnctn.xlsx') as writer:
    pivot11.to_excel(writer, sheet_name='top11hubs',engine='xlsxwriter')
    pivot_remains.to_excel(writer, sheet_name='pivot',engine='xlsxwriter')
    data.to_excel(writer,sheet_name='data',engine='xlsxwriter')
    


# In[ ]:


filepath= r'D:\Data\ODA_Loads_Ton_wise\Pen_HUB_Cnctn.xlsx'


# In[ ]:


import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback

oppath1=filepath
#FTP Upload starts
print ('Logging in...')
ftp = ftplib.FTP()  
ftp.connect('10.109.230.50')  
print (ftp.getwelcome())
try:  
    try:  
        ftp.login('HOSQTeam', 'Te@mH0$q')
        print ('login done')
        ftp.cwd('Auto_reports')  
        #ftp.cwd('FIFO')
        # move to the desired upload directory  
        print ("Currently in:", ftp.pwd()) 
        print ('Uploading...')  
        fullname = oppath1
        name = os.path.split(fullname)[1]  
        print ('os path ok')
        f = open(fullname, "rb")  
        ftp.storbinary('STOR ' + name, f)  
        f.close()  
        print ("OK"  )
        print ("Files:")  
        print (ftp.retrlines('LIST'))
    finally:  
        print ("Quitting...")
        ftp.quit()  
except:  
    traceback.print_exc()


# In[ ]:




from_addr = 'mis.ho@spoton.co.in'
# sharanagouda.biradar@spoton.co.in
# cc_addr = ['mahesh.reddy@spoton.co.in','sharanagouda.biradar@spoton.co.in']
#to_addr = ['sreedhar.m@spoton.co.in','sharanagouda.biradar@spoton.co.in']
#cc_addr = ['mahesh.reddy@spoton.co.in']
cc_addr = ['sq_spot@spoton.co.in','abhik.mitra@spoton.co.in','jothi.menon@spoton.co.in','pawan.sharma@spoton.co.in','prasanna.hegde@spoton.co.in']
# cc_addr = ['shivananda.p@spoton.co.in']
# bcc_addr = ['rajesh.mp@spoton.co.in']

bcc_addr = ['HUBMGR_SPOT@spoton.co.in','Omkar.Chorge@spoton.co.in','rajkumar@spoton.co.in','ramachandran.p@spoton.co.in','sureshbabu.y@spoton.co.in','surendra.pandey@spoton.co.in','sopanrao.bhoite@spoton.co.in','samarajeet.dubey@spoton.co.in','satyaprakash.vishwakarma@spoton.co.in','lingaraj.chidambaram@spoton.co.in','Sukesh.Mishra@spoton.co.in','narendra.londhe@spoton.co.in','ramniwas.sharma@spoton.co.in','jaisingh.chauhan@spoton.co.in','AOM_SPOT@spoton.co.in','rom_spot@spoton.co.in','dom_spot@spoton.co.in','venkata.satyanand@spoton.co.in','m.rama.krishna@spoton.co.in','Rajnish.pathak@spoton.co.in','vijay.dubey@spoton.co.in','scincharge_spot@spoton.co.in','anitha.thyagarajan@spoton.co.in','mahesh.reddy@spoton.co.in']

username = 'mis.ho@spoton.co.in'
password = 'Mis@2019'

msg = MIMEMultipart()

msg['From'] = from_addr
# msg['To'] = ', '.join(to_addr)
msg['bcc'] = ', '.join(bcc_addr)
msg['cc'] = ', '.join(cc_addr)
msg['Subject'] = 'Pending Connection from Hub Report'
html='''<html>
<h4>Dear All Hub Coll's, </h4>
<p> Pls find the below Hub wise pending connection summary details as on today </p>
<p> Please do not hold any shipments for internal issue. Please make sure to connect all pending shipments today itself & clear the backlog.</p>
</html>'''

html1='''<h5>Pl Note : Below these numbers are excluding Receiver Failure, Sender Failure & DEPS.</h5></b>
<h5>HO-SQ</h5>'''

# part10=MIMEText(html1,'html')
#  <h5>Rajesh M P </h5></b>
# msg.attach(part10)
html3='''
<h5> To download the Details of "Pending connection from HUB", Please click the link below </h5>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Pen_HUB_Cnctn.xlsx"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Pen_HUB_Cnctn.xlsx</p></b>
'''

html5='''
<h4> Top11 Hub-pending connection shipments</h4>
'''
html6='''
<h4> Other Hub-pending connection shipments</h4>
'''


html4='''<h5>Thanks & Regards</h5></b>
<h5>HO-SQ</h5>'''

report=""
report+=html
report+=html1

report+=html5
# report+='<br>'
report+='<br>'+pivot11.to_html()+'<br>'
# report+='<br>'
report+=html6
# report+='<br>'
report+='<br>'+pivot_remains.to_html()+'<br>'
report+=html4
report+='<br>'
report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)

server = smtplib.SMTP('smtp.sendgrid.net',587)
part=MIMEBase('application','octet-stream')
# for attachment insted of link
# part.set_payload(open(filepath,'rb').read())
# Encoders.encode_base64(part)
# part.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath))
# msg.attach(part)

server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
server.sendmail(from_addr,cc_addr+bcc_addr,msg.as_string())
print ('mail sent succesfully')
server.quit()

# except:

# TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in','sharanagouda.biradar@spoton.co.in'] 
# CC=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
# FROM="mahesh.reddy@spoton.co.in"
# msg = MIMEMultipart()
# msg["From"] = FROM
# msg["To"] = ",".join(TO)
# msg["CC"] = ",".join(CC)
# #msg["BCC"] = ",".join(BCC)
# #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
# msg["Subject"] = "Pending Connection from Hub Report Error in Execution" 
# report=""
# report+='Hi,'
# report+='<br>'
# report+='<br>'
# report+='There was some error in Pending Connection from Hub Report'
# report+='<br>'

# abc=MIMEText(report.encode('utf-8'),'html')
# msg.attach(abc)
# server=smtplib.SMTP('smtp.sendgrid.net', 587)
# server.ehlo()
# server.starttls()
# server.ehlo()
# server.login("spoton.net.in", "Star@123#")
# failed = server.sendmail(FROM, TO+CC, msg.as_string())
# server.quit()


