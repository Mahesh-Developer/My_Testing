
# coding: utf-8

# In[ ]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta
import sys
import Utilities
reload(sys).setdefaultencoding("ISO-8859-1")

# In[ ]:


# cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")


# # In[ ]:


# cursor=cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()


# In[ ]:


query=(""" SELECT  DOCKNO ,
        DOCKDT Pickupdate ,
        CDELDT Duedate ,
        B.ETADate ,
        DC ,
        DACCC ,
        VTC ,
        FTC ,
        BOOKING_REGION ,
        ACTUAL_WEIGHT ,
        PKGSNO ,
        VOLUME ,
        ORIGIN_BRCODE ,
        ORIGIN_BRNAME ,
        orgareaname ,
        DESTCD ,
        destareaname ,
        DESTHUB ,
        DESTLOCTYPE ,
        INVOICEVALUE ,
        CURR_AREA ,
        CURR_BRANCHCODE ,
        CURR_BRANCHNAME ,
        ARRV_AT_CURR_LOCATION ,
        HOURS_LYING_AT_CURR_LOCATION ,
        A.ISDEPARTED_FRM_CURRLOC ,
        A.LatestConStatusCategory ,
        A.LatestConStatusCode ,
        A.LatestConStatusDesc ,
        A.LatestConStatusDate ,
        CSGNCD ,
        REPLACE(REPLACE(CSGENM, CHAR(13) + CHAR(10), ' '), '"', '') CSGENM ,
        CSGECD ,
        REPLACE(REPLACE(CSGENM, CHAR(13) + CHAR(10), ' '), '"', '') CSGENM ,
        DLV_PINCODE ,
        CSAgentEmpCode ,
        C.EMPNM CSAgentName ,
        A.TIME_STAMP
FROM    dbo.tblTimeConnectionReport_Undelivered_2Hrs A
        INNER JOIN dbo.tblETAData B WITH ( NOLOCK ) ON A.DOCKNO = B.ConNo
        INNER JOIN dbo.EMPMST C WITH ( NOLOCK ) ON A.CSAgentEmpCode = C.EMPCD
WHERE   --ISDEPARTED_FRM_CURRLOC = 'NO' AND
        ( ( B.ETADate > A.CDELDT )
          OR A.CDELDT = CONVERT(DATE, GETDATE())
        )
        AND ISNULL(A.LatestConStatusCategory, '') NOT IN ( 'SENDER FAILURE',
                                                           'RECEIVER FAILURE' )
        AND A.CURR_BRANCHCODE NOT LIKE '%UCG%' """)


# In[ ]:


data=pd.read_sql(query,Utilities.cnxn)


# In[ ]:


len(data)


# In[ ]:


from pandas import ExcelWriter


# In[ ]:


with ExcelWriter(r'D:\Data\ODA_Loads_Ton_wise\Due_date_cons.xlsx') as writer:
       data.to_excel(writer, sheet_name='Data',engine='xlsxwriter')


# In[ ]:


filepath=r'D:\Data\ODA_Loads_Ton_wise\Due_date_cons.xlsx'


# In[ ]:


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.MIMEBase import MIMEBase
from email import Encoders
import os

from_addr = 'mis.ho@spoton.co.in'
to_addr = ['spot_cstl@spoton.co.in']
#to_addr = ['rajesh.mp@spoton.co.in','mahesh.reddy@spoton.co.in']
#cc_addr = ['imrajeshmp@gmail.com']
cc_addr = ['SQ_spot@spoton.co.in','sharmistha.majumdar@spoton.co.in']
bcc_addr = ['rajesh.mp@spoton.co.in']

username = 'mis.ho@spoton.co.in'
password = 'Mis@2019'

msg = MIMEMultipart()

msg['From'] = from_addr
msg['To'] = ', '.join(to_addr)
msg['bcc'] = ', '.join(bcc_addr)
msg['cc'] = ', '.join(cc_addr)
msg['Subject'] = 'Due Date Cons STF & NCF.'
html='''<html>
<h4>Dear ALL,</h4>
</html>'''
html3='''
<h5> Pls find attached Due date cons which is under STF & NCF Status.<h5>
'''

html1='''<h5>Thanks & Regards</h5></b>
<h5>HO-SQ</h5>'''

# part10=MIMEText(html1,'html')
#  <h5>Rajesh M P </h5></b>
# msg.attach(part10)

report=""
report+=html
report+=html3
report+='<br>'
report+=html1
abc=MIMEText(report,'html')
msg.attach(abc)

server = smtplib.SMTP('smtp.sendgrid.net',587)
part=MIMEBase('application','octet-stream')

part.set_payload(open(filepath,'rb').read())
Encoders.encode_base64(part)
part.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath))
msg.attach(part)

server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
server.sendmail(from_addr,to_addr+cc_addr+bcc_addr,msg.as_string())
print ('mail sent succesfully')
server.quit()

