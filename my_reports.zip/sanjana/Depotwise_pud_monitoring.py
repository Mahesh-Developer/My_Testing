
# coding: utf-8

# In[1]:

import pandas as pd
from datetime import datetime, timedelta, date
from pandas import ExcelWriter
import sys
import os
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from pandas import ExcelWriter
from email import encoders
import ftplib
import traceback
import pyodbc
import Utilities
from sqlalchemy import create_engine, MetaData, Table, select
# In[2]:

#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
#cursor = cnxn.cursor()
query=("""SELECT CASE WHEN PUDTYPE = 'ADHOC'   

                              AND (( A.MKT_SBA_APPLICABLE = 'Y'   

                                    OR A.MKT_HIRE_REASON = 'DEDICATED FOR SINGLE CUSTOMER'   

                                    OR A.MKT_HIRE_REASON = 'NSL SHIPMENT'   

                                    OR A.MKT_HIRE_REASON = 'LATE NIGHT/EARLY MORNING'   

                                  )   

                              OR ( A.SENDERCODE = '000119837'    

                                   OR A.SENDERCODE = '000118040'   

                                   OR A.SENDERCODE = '000118041'   

                                   OR A.SENDERCODE = '000119721'   

                                   OR A.SENDERCODE = '000120083'   

                                 )) THEN 'ADHOC-Special'   

                         ELSE PUDTYPE   

                    END PUDTYPE_STATUS ,a.* FROM dbo.tblPUDYestMtdData  a  WITH (NOLOCK)""")
print ('yes')

# pmddata=pd.read_sql(query,Utilities.cnxn)
# pmddata.to_csv(r'Depotwise_monitoring_report.csv')
# exit(0)
# In[2]:
try:
    # pmddata = pd.read_csv(r'http://www.spoton.co.in/downloads/PMD/PMD.csv')
    
    pmddata=pd.read_sql(query,Utilities.cnxn)

    #pmddatafull = pd.read_csv(r'http://spoton.co.in/downloads/PMD/PMD.csv')
    pmddata.rename(columns={'CPKG':'CPKG2','TYP':'TYP2','PUD_NAME':'PUD_NAME2','PUD_CODE':'PUD_CODE2','RECEIVERNAME':'RECEIVERNAME2','RECEIVERCODE':'RECEIVERCODE2','SENDERNAME':'SENDERNAME2','SENDERCODE':'SENDERCODE2','BRANCH_NAME':'BRANCH_NAME2','con_id':'CON_ID2','PINCODE':'PINCODE2','DATE':'DATE2','PUDTYPE_STATUS':'PUDTYPE2','REGION':'REGION2','DEPOT':'DEPOT2','AREA':'AREA2','BRANCH_CODE':'BRANCH_CODE2','ACT_WT':'ACT_WT2','COST':'COST2'},inplace=True)
    pmddata['abc']=pmddata['DATE2'].dt.date
    yester=pmddata[pmddata['abc']==(date.today()-timedelta(days=1))].reset_index()
    # pmddata['abc']=pd.to_datetime(pmddata['DATE2'],errors='coerce')
    # pmddata['abc']=pmddata.apply(lambda x:x['abc'].date(),axis=1)
    # yester=pmddata[pmddata['abc']==(datetime.today().date()-timedelta(days=1))].reset_index()
    try:
        yester['abc'][0]
    except:
        def sendEmail(#TO = ["supratim@iepfunds.com","Ankit@iepfunds.com","abhik.mitra@spoton.co.in","krishna.chandrasekar@spoton.co.in","nikhil.saxena@spoton.co.in","Anto.Paul@Spoton.Co.In"],
             TO = ["manjunath.swamy@spoton.co.in"],
             #TO = ["mahesh.reddy@spoton.co.in"],
             # TO = ["ashwani.gangwar@spoton.co.in"],
             CC = ["mahesh.reddy@spoton.co.in","shashvat.suhane@spoton.co.in"],
             #CC= ["mahesh.reddy@spoton.co.in"],
             # CC = ["Anto.Paul@Spoton.Co.In","Nikhil.Saxena@Spoton.Co.In","vishwas.j@spoton.co.in","goutam.barik@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
            HOST = "smtp.spoton.co.in"
        #smtplib.SMTP('smtp.spoton.co.in', 25)

            msg = MIMEMultipart()
            msg["From"] = FROM
            msg["To"] = ",".join(TO)
            msg["CC"] = ",".join(CC)
            #msg["Subject"] = "Monitoring Report " + '- ' + str(yesterdate)
            msg["Subject"] = "PMD DATA" 
            body_text = """
Dear Manju,
In PMD file yesterday data is not Available 
    """

            if body_text:
                msg.attach( MIMEText(body_text) )
            server=smtplib.SMTP('smtp.sendgrid.net', 587)
            server.ehlo()
            server.starttls()
            server.ehlo()
            server.login("spoton.net.in", "Star@123#")

            try:
                failed = server.sendmail(FROM, TO+CC, msg.as_string())
                server.close()
            except Exception, e:
                errorMsg = "Unable to send email. Error: %s" % str(e)

        if __name__ == "__main__":
            sendEmail()
        print('Email sent')
        sys.exit()
except:
    def sendEmail(#TO = ["supratim@iepfunds.com","Ankit@iepfunds.com","abhik.mitra@spoton.co.in","krishna.chandrasekar@spoton.co.in","nikhil.saxena@spoton.co.in","Anto.Paul@Spoton.Co.In"],
             TO = ["shashvat.suhane@spoton.co.in"],
             #TO = ["mahesh.reddy@spoton.co.in"],
             # TO = ["ashwani.gangwar@spoton.co.in"],
             CC = ["vishwas.j@spoton.co.in","shashvat.suhane@spoton.co.in"],
             #CC=["mahesh.reddy@spoton.co.in"],
             # CC = ["Anto.Paul@Spoton.Co.In","Nikhil.Saxena@Spoton.Co.In","vishwas.j@spoton.co.in","goutam.barik@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
        HOST = "smtp.spoton.co.in"
    #smtplib.SMTP('smtp.spoton.co.in', 25)

        msg = MIMEMultipart()
        msg["From"] = FROM
        msg["To"] = ",".join(TO)
        msg["CC"] = ",".join(CC)
        #msg["Subject"] = "Monitoring Report " + '- ' + str(yesterdate)
        msg["Subject"] = "PMD DATA" 
        body_text = """
Dear Manju,
PMD data is not available 
"""

        if body_text:
            msg.attach( MIMEText(body_text) )
        server=smtplib.SMTP('smtp.sendgrid.net', 587)
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login("spoton.net.in", "Star@123#")

        try:
            failed = server.sendmail(FROM, TO+CC, msg.as_string())
            server.close()
        except Exception, e:
            errorMsg = "Unable to send email. Error: %s" % str(e)

    if __name__ == "__main__":
        sendEmail()
    print('Email sent')
    sys.exit()

#pmddata = pd.read_csv(r'PMD.csv')

# In[3]:


# In[3]:

# In[4]:

def adhocstdoda(pudtype,pintype):
    if pudtype == 'ADHOC':
        return 'MKT'+str('-')+str(pintype)
    else:
        return pudtype


# In[5]:

pmddata['PUDTYPES'] = pmddata.apply(lambda x: adhocstdoda (x['PUDTYPE2'],x['PINTYPE']),axis=1)

# In[4]:

pmddatagrp = pmddata.groupby(['REGION2','DEPOT2','PUDTYPES']).agg({'ACT_WT2':sum,'COST2':sum}).reset_index()
pmddatagrp = pmddatagrp.fillna(0)

pmddatagrp['CPKG'] = pmddatagrp.apply(lambda x: round(x['COST2']/x['ACT_WT2'],2),axis=1)


# In[5]:

totalpmdgrp = pmddata.groupby(['REGION2','DEPOT2']).agg({'ACT_WT2':sum}).reset_index()


# In[6]:

totalpmdmtd = pd.merge(totalpmdgrp,pmddatagrp,on=['REGION2','DEPOT2'],how='outer')


# In[7]:

#totalpmdmtd


# In[8]:

totalpmdmtd['% ACT_WT'] = totalpmdmtd.apply(lambda x: round(x['ACT_WT2_y']*100.0/x['ACT_WT2_x'],2),axis=1)
totalpmdmtd = totalpmdmtd.drop(['ACT_WT2_x'], axis=1)
totalpmdmtd = totalpmdmtd.rename(columns={'ACT_WT2_y':'ACT_WT'})


# In[9]:

#totalpmdmtd.to_csv(r'totalpmdmtd.csv')

# In[10]:

def datestring(x):
    fulldate = datetime.strptime(x,'%d %b %Y %H:%M')
    return fulldate

# pmddata['DATE'] = pmddata.apply (lambda x:datestring (x['DATE2']),axis=1)
pmddata['DATE'] = pmddata['DATE2'].dt.date
yesterdate=date.today()-timedelta(hours=24)

yesterdaydf = pmddata[(pmddata['DATE'] >= yesterdate)]
len(yesterdaydf)

pmddatagrpyest = yesterdaydf.groupby(['REGION2','DEPOT2','PUDTYPES']).agg({'ACT_WT2':sum,'COST2':sum}).reset_index()
pmddatagrpyest['CPKG'] = pmddatagrpyest.apply(lambda x: round(x['COST2']/x['ACT_WT2'],2),axis=1)
print (pmddata[['DATE2','DATE']])



# In[11]:

yestpmdgrp = yesterdaydf.groupby(['REGION2','DEPOT2']).agg({'ACT_WT2':sum}).reset_index()


# In[12]:

pmddatagrpyest = pd.merge(yestpmdgrp,pmddatagrpyest,on=['REGION2','DEPOT2'],how='outer')


# In[13]:

pmddatagrpyest['% ACT_WT'] = pmddatagrpyest.apply(lambda x: round(x['ACT_WT2_y']*100.0/x['ACT_WT2_x'],2),axis=1)
pmddatagrpyest = pmddatagrpyest.drop(['ACT_WT2_x'], axis=1)
pmddatagrpyest = pmddatagrpyest.rename(columns={'ACT_WT2_y':'ACT_WT'})


# In[14]:

pmddatagrpyest.head()


# In[15]:

pmddepotsummary = pd.merge(totalpmdmtd,pmddatagrpyest, on=['REGION2','DEPOT2','PUDTYPES'], suffixes=['_MTD','_YDAY'],how='outer')
pmddepotsummary = pmddepotsummary.fillna(0)


# In[16]:

#pmddepotsummary.to_csv(r'pmddepotsummary.csv')


# In[17]:

ccutotaldf = pmddepotsummary[pmddepotsummary['DEPOT2']=='CCUD']
peractwtydayccu = pd.np.round(ccutotaldf['% ACT_WT_YDAY'].sum(),2)
actwtydayccu = ccutotaldf['ACT_WT_YDAY'].sum()
costydayccu = ccutotaldf['COST2_YDAY'].sum()
cpkydayccu = pd.np.round((costydayccu/actwtydayccu),2)
peractwtmtdccu = ccutotaldf['% ACT_WT_MTD'].sum()
actwtmtdccu = ccutotaldf['ACT_WT_MTD'].sum()
costmtdccu = ccutotaldf['COST2_MTD'].sum()
cpkmtdccu = pd.np.round((costmtdccu/actwtmtdccu),2)
sumlistccu = ['E','CCUD_TOTAL','CCUD_All',peractwtydayccu,actwtydayccu,costydayccu,cpkydayccu,peractwtmtdccu,actwtmtdccu,costmtdccu,cpkmtdccu]
col_listccu = ['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST2_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST2_MTD','CPKG_MTD']
totalsdfccu = pd.DataFrame(data=[sumlistccu], columns = col_listccu)
ccutotaldf = ccutotaldf.append(totalsdfccu,ignore_index=True)
ccutotaldf = ccutotaldf[['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST2_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST2_MTD','CPKG_MTD']]


# In[18]:

ixctotaldf = pmddepotsummary[pmddepotsummary['DEPOT2']=='IXCD']
peractwtydayixc = pd.np.round(ixctotaldf['% ACT_WT_YDAY'].sum(),2)
actwtydayixc = ixctotaldf['ACT_WT_YDAY'].sum()
costydayixc = ixctotaldf['COST2_YDAY'].sum()
cpkydayixc = pd.np.round((costydayixc/actwtydayixc),2)
peractwtmtdixc = ixctotaldf['% ACT_WT_MTD'].sum()
actwtmtdixc = ixctotaldf['ACT_WT_MTD'].sum()
costmtdixc = ixctotaldf['COST2_MTD'].sum()
cpkmtdixc = pd.np.round((costmtdixc/actwtmtdixc),2)
sumlistixc = ['N','IXCD_TOTAL','IXCD_All',peractwtydayixc,actwtydayixc,costydayixc,cpkydayixc,peractwtmtdixc,actwtmtdixc,costmtdixc,cpkmtdixc]
col_listixc = ['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST2_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST2_MTD','CPKG_MTD']
totalsdfixc = pd.DataFrame(data=[sumlistixc], columns = col_listixc)
ixctotaldf = ixctotaldf.append(totalsdfixc,ignore_index=True)
ixctotaldf = ixctotaldf[['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST2_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST2_MTD','CPKG_MTD']]


# In[19]:

lkototaldf = pmddepotsummary[pmddepotsummary['DEPOT2']=='LKOD']
peractwtydaylko = pd.np.round(lkototaldf['% ACT_WT_YDAY'].sum(),2)
actwtydaylko = lkototaldf['ACT_WT_YDAY'].sum()
costydaylko = lkototaldf['COST2_YDAY'].sum()
cpkydaylko = pd.np.round((costydaylko/actwtydaylko),2)
peractwtmtdlko = lkototaldf['% ACT_WT_MTD'].sum()
actwtmtdlko = lkototaldf['ACT_WT_MTD'].sum()
costmtdlko = lkototaldf['COST2_MTD'].sum()
cpkmtdlko = pd.np.round((costmtdlko/actwtmtdlko),2)
sumlistlko = ['N','LKOD_TOTAL','LKOD_All',peractwtydaylko,actwtydaylko,costydaylko,cpkydaylko,peractwtmtdlko,actwtmtdlko,costmtdlko,cpkmtdlko]
col_listlko = ['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST2_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST2_MTD','CPKG_MTD']
totalsdflko = pd.DataFrame(data=[sumlistlko], columns = col_listlko)
lkototaldf = lkototaldf.append(totalsdflko,ignore_index=True)
lkototaldf = lkototaldf[['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST2_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST2_MTD','CPKG_MTD']]


# In[20]:

ncrtotaldf = pmddepotsummary[pmddepotsummary['DEPOT2']=='NCRD']
peractwtydayncr = pd.np.round(ncrtotaldf['% ACT_WT_YDAY'].sum(),2)
actwtydayncr = ncrtotaldf['ACT_WT_YDAY'].sum()
costydayncr = ncrtotaldf['COST2_YDAY'].sum()
cpkydayncr = pd.np.round((costydayncr/actwtydayncr),2)
peractwtmtdncr = ncrtotaldf['% ACT_WT_MTD'].sum()
actwtmtdncr = ncrtotaldf['ACT_WT_MTD'].sum()
costmtdncr = ncrtotaldf['COST2_MTD'].sum()
cpkmtdncr = pd.np.round((costmtdncr/actwtmtdncr),2)
sumlistncr = ['N','NCRD_TOTAL','NCRD_All',peractwtydayncr,actwtydayncr,costydayncr,cpkydayncr,peractwtmtdncr,actwtmtdncr,costmtdncr,cpkmtdncr]
col_listncr = ['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST2_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST2_MTD','CPKG_MTD']
totalsdfncr = pd.DataFrame(data=[sumlistncr], columns = col_listncr)
ncrtotaldf = ncrtotaldf.append(totalsdfncr,ignore_index=True)
ncrtotaldf = ncrtotaldf[['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST2_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST2_MTD','CPKG_MTD']]


# In[21]:

ukntotaldf = pmddepotsummary[pmddepotsummary['DEPOT2']=='UKND']
peractwtydayukn = pd.np.round(ukntotaldf['% ACT_WT_YDAY'].sum(),2)
actwtydayukn = ukntotaldf['ACT_WT_YDAY'].sum()
costydayukn = ukntotaldf['COST2_YDAY'].sum()
try:
	cpkydayukn = pd.np.round((costydayukn/actwtydayukn),2)
except:
	cpkydayukn = 0.0
peractwtmtdukn = ukntotaldf['% ACT_WT_MTD'].sum()
actwtmtdukn = ukntotaldf['ACT_WT_MTD'].sum()
costmtdukn = ukntotaldf['COST2_MTD'].sum()
try:
	cpkmtdukn = pd.np.round((costmtdukn/actwtmtdukn),2)
except:
	cpkmtdukn = 0.0
sumlistukn = ['N','UKND_TOTAL','UKND_All',peractwtydayukn,actwtydayukn,costydayukn,cpkydayukn,peractwtmtdukn,actwtmtdukn,costmtdukn,cpkmtdukn]
col_listukn = ['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST2_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST2_MTD','CPKG_MTD']
totalsdfukn = pd.DataFrame(data=[sumlistukn], columns = col_listukn)
ukntotaldf = ukntotaldf.append(totalsdfukn,ignore_index=True)
ukntotaldf = ukntotaldf[['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST2_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST2_MTD','CPKG_MTD']]


# In[22]:

blrtotaldf = pmddepotsummary[pmddepotsummary['DEPOT2']=='BLRD']
peractwtydayblr = pd.np.round(blrtotaldf['% ACT_WT_YDAY'].sum(),2)
actwtydayblr = blrtotaldf['ACT_WT_YDAY'].sum()
costydayblr = blrtotaldf['COST2_YDAY'].sum()
cpkydayblr = pd.np.round((costydayblr/actwtydayblr),2)
peractwtmtdblr = blrtotaldf['% ACT_WT_MTD'].sum()
actwtmtdblr = blrtotaldf['ACT_WT_MTD'].sum()
costmtdblr = blrtotaldf['COST2_MTD'].sum()
cpkmtdblr = pd.np.round((costmtdblr/actwtmtdblr),2)
sumlistblr = ['S','BLRD_TOTAL','BLRD_All',peractwtydayblr,actwtydayblr,costydayblr,cpkydayblr,peractwtmtdblr,actwtmtdblr,costmtdblr,cpkmtdblr]
col_listblr = ['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST2_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST2_MTD','CPKG_MTD']
totalsdfblr = pd.DataFrame(data=[sumlistblr], columns = col_listblr)
blrtotaldf = blrtotaldf.append(totalsdfblr,ignore_index=True)
blrtotaldf = blrtotaldf[['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST2_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST2_MTD','CPKG_MTD']]


# In[23]:

hydtotaldf = pmddepotsummary[pmddepotsummary['DEPOT2']=='HYDD']
peractwtydayhyd = pd.np.round(hydtotaldf['% ACT_WT_YDAY'].sum(),2)
actwtydayhyd = hydtotaldf['ACT_WT_YDAY'].sum()
costydayhyd = hydtotaldf['COST2_YDAY'].sum()
cpkydayhyd = pd.np.round((costydayhyd/actwtydayhyd),2)
peractwtmtdhyd = hydtotaldf['% ACT_WT_MTD'].sum()
actwtmtdhyd = hydtotaldf['ACT_WT_MTD'].sum()
costmtdhyd = hydtotaldf['COST2_MTD'].sum()
cpkmtdhyd = pd.np.round((costmtdhyd/actwtmtdhyd),2)
sumlisthyd = ['S','HYDD_TOTAL','HYDD_All',peractwtydayhyd,actwtydayhyd,costydayhyd,cpkydayhyd,peractwtmtdhyd,actwtmtdhyd,costmtdhyd,cpkmtdhyd]
col_listhyd = ['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST2_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST2_MTD','CPKG_MTD']
totalsdfhyd = pd.DataFrame(data=[sumlisthyd], columns = col_listhyd)
hydtotaldf = hydtotaldf.append(totalsdfhyd,ignore_index=True)
hydtotaldf = hydtotaldf[['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST2_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST2_MTD','CPKG_MTD']]


# In[24]:

maatotaldf = pmddepotsummary[pmddepotsummary['DEPOT2']=='MAAD']
peractwtydaymaa = pd.np.round(maatotaldf['% ACT_WT_YDAY'].sum(),2)
actwtydaymaa = maatotaldf['ACT_WT_YDAY'].sum()
costydaymaa = maatotaldf['COST2_YDAY'].sum()
cpkydaymaa = pd.np.round((costydaymaa/actwtydaymaa),2)
peractwtmtdmaa = maatotaldf['% ACT_WT_MTD'].sum()
actwtmtdmaa = maatotaldf['ACT_WT_MTD'].sum()
costmtdmaa = maatotaldf['COST2_MTD'].sum()
cpkmtdmaa = pd.np.round((costmtdmaa/actwtmtdmaa),2)
sumlistmaa = ['S','MAAD_TOTAL','MAAD_All',peractwtydaymaa,actwtydaymaa,costydaymaa,cpkydaymaa,peractwtmtdmaa,actwtmtdmaa,costmtdmaa,cpkmtdmaa]
col_listmaa = ['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST2_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST2_MTD','CPKG_MTD']
totalsdfmaa = pd.DataFrame(data=[sumlistmaa], columns = col_listmaa)
maatotaldf = maatotaldf.append(totalsdfmaa,ignore_index=True)
maatotaldf = maatotaldf[['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST2_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST2_MTD','CPKG_MTD']]


# In[25]:

rtktotaldf = pmddepotsummary[pmddepotsummary['DEPOT2']=='RTKD']
peractwtydayrtk = pd.np.round(rtktotaldf['% ACT_WT_YDAY'].sum(),2)
actwtydayrtk = rtktotaldf['ACT_WT_YDAY'].sum()
costydayrtk = rtktotaldf['COST2_YDAY'].sum()
cpkydayrtk = pd.np.round((costydayrtk/actwtydayrtk),2)
peractwtmtdrtk = rtktotaldf['% ACT_WT_MTD'].sum()
actwtmtdrtk = rtktotaldf['ACT_WT_MTD'].sum()
costmtdrtk = rtktotaldf['COST2_MTD'].sum()
cpkmtdrtk = pd.np.round((costmtdrtk/actwtmtdrtk),2)
sumlistrtk = ['S','RTKD_TOTAL','RTKD_All',peractwtydayrtk,actwtydayrtk,costydayrtk,cpkydayrtk,peractwtmtdrtk,actwtmtdrtk,costmtdrtk,cpkmtdrtk]
col_listrtk = ['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST2_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST2_MTD','CPKG_MTD']
totalsdfrtk = pd.DataFrame(data=[sumlistrtk], columns = col_listrtk)
rtktotaldf = rtktotaldf.append(totalsdfrtk,ignore_index=True)
rtktotaldf = rtktotaldf[['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST2_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST2_MTD','CPKG_MTD']]


# In[26]:

amdtotaldf = pmddepotsummary[pmddepotsummary['DEPOT2']=='AMDD']
peractwtydayamd = pd.np.round(amdtotaldf['% ACT_WT_YDAY'].sum(),2)
actwtydayamd = amdtotaldf['ACT_WT_YDAY'].sum()
costydayamd = amdtotaldf['COST2_YDAY'].sum()
cpkydayamd = pd.np.round((costydayamd/actwtydayamd),2)
peractwtmtdamd = amdtotaldf['% ACT_WT_MTD'].sum()
actwtmtdamd = amdtotaldf['ACT_WT_MTD'].sum()
costmtdamd = amdtotaldf['COST2_MTD'].sum()
cpkmtdamd = pd.np.round((costmtdamd/actwtmtdamd),2)
sumlistamd = ['W','AMDD_TOTAL','AMDD_All',peractwtydayamd,actwtydayamd,costydayamd,cpkydayamd,peractwtmtdamd,actwtmtdamd,costmtdamd,cpkmtdamd]
col_listamd = ['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST2_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST2_MTD','CPKG_MTD']
totalsdfamd = pd.DataFrame(data=[sumlistamd], columns = col_listamd)
amdtotaldf = amdtotaldf.append(totalsdfamd,ignore_index=True)
amdtotaldf = amdtotaldf[['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST2_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST2_MTD','CPKG_MTD']]


# In[27]:

bomtotaldf = pmddepotsummary[pmddepotsummary['DEPOT2']=='BOMD']
peractwtydaybom = pd.np.round(bomtotaldf['% ACT_WT_YDAY'].sum(),2)
actwtydaybom = bomtotaldf['ACT_WT_YDAY'].sum()
costydaybom = bomtotaldf['COST2_YDAY'].sum()
cpkydaybom = pd.np.round((costydaybom/actwtydaybom),2)
peractwtmtdbom = bomtotaldf['% ACT_WT_MTD'].sum()
actwtmtdbom = bomtotaldf['ACT_WT_MTD'].sum()
costmtdbom = bomtotaldf['COST2_MTD'].sum()
cpkmtdbom = pd.np.round((costmtdbom/actwtmtdbom),2)
sumlistbom = ['W','BOMD_TOTAL','BOMD_All',peractwtydaybom,actwtydaybom,costydaybom,cpkydaybom,peractwtmtdbom,actwtmtdbom,costmtdbom,cpkmtdbom]
col_listbom = ['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST2_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST2_MTD','CPKG_MTD']
totalsdfbom = pd.DataFrame(data=[sumlistbom], columns = col_listbom)
bomtotaldf = bomtotaldf.append(totalsdfbom,ignore_index=True)
bomtotaldf = bomtotaldf[['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST2_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST2_MTD','CPKG_MTD']]


# In[28]:

idrtotaldf = pmddepotsummary[pmddepotsummary['DEPOT2']=='IDRD']
peractwtydayidr = pd.np.round(idrtotaldf['% ACT_WT_YDAY'].sum(),2)
actwtydayidr = idrtotaldf['ACT_WT_YDAY'].sum()
costydayidr = idrtotaldf['COST2_YDAY'].sum()
cpkydayidr = pd.np.round((costydayidr/actwtydayidr),2)
peractwtmtdidr = idrtotaldf['% ACT_WT_MTD'].sum()
actwtmtdidr = idrtotaldf['ACT_WT_MTD'].sum()
costmtdidr = idrtotaldf['COST2_MTD'].sum()
cpkmtdidr = pd.np.round((costmtdidr/actwtmtdidr),2)
sumlistidr = ['W','IDRD_TOTAL','IDRD_All',peractwtydayidr,actwtydayidr,costydayidr,cpkydayidr,peractwtmtdidr,actwtmtdidr,costmtdidr,cpkmtdidr]
col_listidr = ['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST2_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST2_MTD','CPKG_MTD']
totalsdfidr = pd.DataFrame(data=[sumlistidr], columns = col_listidr)
idrtotaldf = idrtotaldf.append(totalsdfidr,ignore_index=True)
idrtotaldf = idrtotaldf[['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST2_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST2_MTD','CPKG_MTD']]


# In[29]:

pnqtotaldf = pmddepotsummary[pmddepotsummary['DEPOT2']=='PNQD']
peractwtydaypnq = pd.np.round(pnqtotaldf['% ACT_WT_YDAY'].sum(),2)
actwtydaypnq = pnqtotaldf['ACT_WT_YDAY'].sum()
costydaypnq = pnqtotaldf['COST2_YDAY'].sum()
cpkydaypnq = pd.np.round((costydaypnq/actwtydaypnq),2)
peractwtmtdpnq = pnqtotaldf['% ACT_WT_MTD'].sum()
actwtmtdpnq = pnqtotaldf['ACT_WT_MTD'].sum()
costmtdpnq = pnqtotaldf['COST2_MTD'].sum()
cpkmtdpnq = pd.np.round((costmtdpnq/actwtmtdpnq),2)
sumlistpnq = ['W','PNQD_TOTAL','PNQD_All',peractwtydaypnq,actwtydaypnq,costydaypnq,cpkydaypnq,peractwtmtdpnq,actwtmtdpnq,costmtdpnq,cpkmtdpnq]
col_listpnq = ['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST2_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST2_MTD','CPKG_MTD']
totalsdfpnq = pd.DataFrame(data=[sumlistpnq], columns = col_listpnq)
pnqtotaldf = pnqtotaldf.append(totalsdfpnq,ignore_index=True)
pnqtotaldf = pnqtotaldf[['REGION2','DEPOT2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST2_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST2_MTD','CPKG_MTD']]


# In[30]:

ccuixc = ccutotaldf.append(ixctotaldf,ignore_index=True)
ccuixclko = ccuixc.append(lkototaldf,ignore_index=True)
ccuixclkoncr = ccuixclko.append(ncrtotaldf,ignore_index=True)
ccuixclkoncrukn = ccuixclkoncr.append(ukntotaldf,ignore_index=True)
ccuixclkoncruknblr = ccuixclkoncrukn.append(blrtotaldf,ignore_index=True)
ccuixclkoncruknblrhyd = ccuixclkoncruknblr.append(hydtotaldf,ignore_index=True)
ccuixclkoncruknblrhydmaa = ccuixclkoncruknblrhyd.append(maatotaldf,ignore_index=True)
ccuixclkoncruknblrhydmaartk = ccuixclkoncruknblrhydmaa.append(rtktotaldf,ignore_index=True)
ccuixclkoncruknblrhydmaartkamd = ccuixclkoncruknblrhydmaartk.append(amdtotaldf,ignore_index=True)
ccuixclkoncruknblrhydmaartkamdbom = ccuixclkoncruknblrhydmaartkamd.append(bomtotaldf,ignore_index=True)
ccuixclkoncruknblrhydmaartkamdbomidr = ccuixclkoncruknblrhydmaartkamdbom.append(idrtotaldf,ignore_index=True)


monitoring_depotwise = ccuixclkoncruknblrhydmaartkamdbomidr.append(pnqtotaldf,ignore_index=True)


# In[31]:

monitoring_depotwise.to_csv(r'D:\Data\Depotwise_monitoring_report\All_depots\PUD_Monitoring_Depotwise_'+str(yesterdate)+'.csv')


# In[32]:

ccukeeplist = ['CCUD','CCUD_TOTAL']
ccudf = monitoring_depotwise[monitoring_depotwise['DEPOT2'].isin(ccukeeplist)]
ccudf_req_cols = ccudf[['PUDTYPES','CPKG_YDAY','% ACT_WT_YDAY','CPKG_MTD','% ACT_WT_MTD']]
ccudf_req_cols = ccudf_req_cols.rename(columns={'CPKG_YDAY':'CPK_Y','% ACT_WT_YDAY':'%WT_Y','CPKG_MTD':'CPK_M','% ACT_WT_MTD':'%WT_M'})
ccudf_req_cols= ccudf_req_cols.to_string(index=False)
ccudf.to_csv(r'D:\Data\Depotwise_monitoring_report\CCUD\CCUD_Monitoring_Report_'+str(yesterdate)+'.csv')
ccuoppath = r'D:\Data\Depotwise_monitoring_report\CCUD\CCUD_Monitoring_Report_'+str(yesterdate)+'.csv'




filePath = ccuoppath
def sendEmail(#TO = ["supratim@iepfunds.com","Ankit@iepfunds.com","abhik.mitra@spoton.co.in","krishna.chandrasekar@spoton.co.in","nikhil.saxena@spoton.co.in","Anto.Paul@Spoton.Co.In"],
             #TO = ["mahesh.reddy@spoton.co.in"],
             TO = ["avinash.singh@spoton.co.in"],
             #CC = ["mahesh.reddy@spoton.co.in"],
             CC = ["Anto.Paul@Spoton.Co.In","vishwas.j@spoton.co.in","goutam.barik@spoton.co.in","rajesh.kumar@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "Monitoring Report " + '- ' + str(yesterdate)
    msg["Subject"] = "PUD Monitoring Report-CCUD" + '- ' + str(yesterdate)
    body_text = """
    Dear All,
    
    PFB the CCUD PUD Monitoring Report as of """+str(yesterdate)+ """
    
    PFB tthe summary
    
"""+str(ccudf_req_cols)+"""

For Conwise data, please download from the link below

http://spoton.co.in/downloads/IEProjects/ETA/CCUD_Data.csv

    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends


# In[33]:

blrkeeplist = ['BLRD','BLRD_TOTAL']
blrdf = monitoring_depotwise[monitoring_depotwise['DEPOT2'].isin(blrkeeplist)]
blrdf_req_cols = blrdf[['PUDTYPES','CPKG_YDAY','% ACT_WT_YDAY','CPKG_MTD','% ACT_WT_MTD']]
blrdf_req_cols = blrdf_req_cols.rename(columns={'CPKG_YDAY':'CPK_Y','% ACT_WT_YDAY':'%WT_Y','CPKG_MTD':'CPK_M','% ACT_WT_MTD':'%WT_M'})
blrdf_req_cols= blrdf_req_cols.to_string(index=False)
blrdf.to_csv(r'D:\Data\Depotwise_monitoring_report\BLRD\BLRD_Monitoring_Report_'+str(yesterdate)+'.csv')
blroppath = r'D:\Data\Depotwise_monitoring_report\BLRD\BLRD_Monitoring_Report_'+str(yesterdate)+'.csv'



filePath = blroppath
def sendEmail(#TO = ["supratim@iepfunds.com","Ankit@iepfunds.com","abhik.mitra@spoton.co.in","krishna.chandrasekar@spoton.co.in","Anto.Paul@Spoton.Co.In"],
             #TO = ["mahesh.reddy@spoton.co.in"],
             TO = ["dominic.sathish@spoton.co.in"],
             #CC = ["mahesh.reddy@spoton.co.in"],
             CC = ["Anto.Paul@Spoton.Co.In","Nikhil.Saxena@Spoton.Co.In","vishwas.j@spoton.co.in","goutam.barik@spoton.co.in","sasikumar.kannan@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "Monitoring Report " + '- ' + str(yesterdate)
    msg["Subject"] = "PUD Monitoring Report-BLRD" + '- ' + str(yesterdate)
    body_text = """
    Dear All,
    
    PFB the BLRD PUD Monitoring Report as of """+str(yesterdate)+ """
    
    PFB tthe summary
    
"""+str(blrdf_req_cols)+"""
For Conwise data, please download from the link below

http://spoton.co.in/downloads/IEProjects/ETA/BLRD_Data.csv
    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends


# In[34]:

hydkeeplist = ['HYDD','HYDD_TOTAL']
hyddf = monitoring_depotwise[monitoring_depotwise['DEPOT2'].isin(hydkeeplist)]
hyddf_req_cols = hyddf[['PUDTYPES','CPKG_YDAY','% ACT_WT_YDAY','CPKG_MTD','% ACT_WT_MTD']]
hyddf_req_cols = hyddf_req_cols.rename(columns={'CPKG_YDAY':'CPK_Y','% ACT_WT_YDAY':'%WT_Y','CPKG_MTD':'CPK_M','% ACT_WT_MTD':'%WT_M'})
hyddf_req_cols= hyddf_req_cols.to_string(index=False)
hyddf.to_csv(r'D:\Data\Depotwise_monitoring_report\HYDD\HYDD_Monitoring_Report_'+str(yesterdate)+'.csv')
hydoppath = r'D:\Data\Depotwise_monitoring_report\HYDD\HYDD_Monitoring_Report_'+str(yesterdate)+'.csv'


filePath = hydoppath
def sendEmail(#TO = ["supratim@iepfunds.com","Ankit@iepfunds.com","abhik.mitra@spoton.co.in","krishna.chandrasekar@spoton.co.in","Anto.Paul@Spoton.Co.In"],
             #TO = ["mahesh.reddy@spoton.co.in"],
             TO = ["jacob.mathew@spoton.co.in"],
             #CC = ["mahesh.reddy@spoton.co.in"],
             CC = ["Anto.Paul@Spoton.Co.In","Nikhil.Saxena@Spoton.Co.In","sasikumar.kannan@spoton.co.in","vishwas.j@spoton.co.in","goutam.barik@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "Monitoring Report " + '- ' + str(yesterdate)
    msg["Subject"] = "PUD Monitoring Report-HYDD" + '- ' + str(yesterdate)
    body_text = """
    Dear All,
    
    PFB the HYDD PUD Monitoring Report as of """+str(yesterdate)+ """
    
    PFB tthe summary
    
"""+str(hyddf_req_cols)+"""

For Conwise data, please download from the link below

http://spoton.co.in/downloads/IEProjects/ETA/HYDD_Data.csv

    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends


# In[35]:

maakeeplist = ['MAAD','MAAD_TOTAL']
maadf = monitoring_depotwise[monitoring_depotwise['DEPOT2'].isin(maakeeplist)]
maadf_req_cols = maadf[['PUDTYPES','CPKG_YDAY','% ACT_WT_YDAY','CPKG_MTD','% ACT_WT_MTD']]
maadf_req_cols = maadf_req_cols.rename(columns={'CPKG_YDAY':'CPK_Y','% ACT_WT_YDAY':'%WT_Y','CPKG_MTD':'CPK_M','% ACT_WT_MTD':'%WT_M'})
maadf_req_cols= maadf_req_cols.to_string(index=False)
maadf.to_csv(r'D:\Data\Depotwise_monitoring_report\MAAD\MAAD_Monitoring_Report_'+str(yesterdate)+'.csv')
maaoppath = r'D:\Data\Depotwise_monitoring_report\MAAD\MAAD_Monitoring_Report_'+str(yesterdate)+'.csv'


filePath = maaoppath
def sendEmail(#TO = ["supratim@iepfunds.com","Ankit@iepfunds.com","abhik.mitra@spoton.co.in","krishna.chandrasekar@spoton.co.in","Anto.Paul@Spoton.Co.In"],
             #TO = ["mahesh.reddy@spoton.co.in"],
             TO = ["joseph.arul.seelan@spoton.co.in","anish.kumar@spoton.co.in"],
             #CC = ["mahesh.reddy@spoton.co.in"],
             CC = ["Anto.Paul@Spoton.Co.In","Nikhil.Saxena@Spoton.Co.In","vishwas.j@spoton.co.in","goutam.barik@spoton.co.in","sasikumar.kannan@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "Monitoring Report " + '- ' + str(yesterdate)
    msg["Subject"] = "PUD Monitoring Report-MAAD" + '- ' + str(yesterdate)
    body_text = """
    Dear All,
    
    PFB the MAAD PUD Monitoring Report as of """+str(yesterdate)+ """
    
    PFB tthe summary
    
"""+str(maadf_req_cols)+"""

For Conwise data, please download from the link below

http://spoton.co.in/downloads/IEProjects/ETA/MAAD_Data.csv
    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends


# In[36]:

rtkkeeplist = ['RTKD','RTKD_TOTAL']
rtkdf = monitoring_depotwise[monitoring_depotwise['DEPOT2'].isin(rtkkeeplist)]
rtkdf_req_cols = rtkdf[['PUDTYPES','CPKG_YDAY','% ACT_WT_YDAY','CPKG_MTD','% ACT_WT_MTD']]
rtkdf_req_cols = rtkdf_req_cols.rename(columns={'CPKG_YDAY':'CPK_Y','% ACT_WT_YDAY':'%WT_Y','CPKG_MTD':'CPK_M','% ACT_WT_MTD':'%WT_M'})
rtkdf_req_cols= rtkdf_req_cols.to_string(index=False)
rtkdf.to_csv(r'D:\Data\Depotwise_monitoring_report\RTKD\RTKD_Monitoring_Report_'+str(yesterdate)+'.csv')
rtkoppath = r'D:\Data\Depotwise_monitoring_report\RTKD\RTKD_Monitoring_Report_'+str(yesterdate)+'.csv'


filePath = rtkoppath
def sendEmail(#TO = ["supratim@iepfunds.com","Ankit@iepfunds.com","abhik.mitra@spoton.co.in","krishna.chandrasekar@spoton.co.in","Anto.Paul@Spoton.Co.In"],
             #TO = ["mahesh.reddy@spoton.co.in"],
             TO = ["suresh.kp@spoton.co.in"],
             #CC = ["mahesh.reddy@spoton.co.in"],
             CC = ["Anto.Paul@Spoton.Co.In","Nikhil.Saxena@Spoton.Co.In","vishwas.j@spoton.co.in","goutam.barik@spoton.co.in","sasikumar.kannan@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "Monitoring Report " + '- ' + str(yesterdate)
    msg["Subject"] = "PUD Monitoring Report-RTKD" + '- ' + str(yesterdate)
    body_text = """
    Dear All,
    
    PFB the RTKD PUD Monitoring Report as of """+str(yesterdate)+ """
    
    PFB tthe summary
    
"""+str(rtkdf_req_cols)+"""

For Conwise data, please download from the link below

http://spoton.co.in/downloads/IEProjects/ETA/RTKD_Data.csv
    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends


# In[37]:

ncrkeeplist = ['NCRD','NCRD_TOTAL']
ncrdf = monitoring_depotwise[monitoring_depotwise['DEPOT2'].isin(ncrkeeplist)]
ncrdf_req_cols = ncrdf[['PUDTYPES','CPKG_YDAY','% ACT_WT_YDAY','CPKG_MTD','% ACT_WT_MTD']]
ncrdf_req_cols = ncrdf_req_cols.rename(columns={'CPKG_YDAY':'CPK_Y','% ACT_WT_YDAY':'%WT_Y','CPKG_MTD':'CPK_M','% ACT_WT_MTD':'%WT_M'})
ncrdf_req_cols= ncrdf_req_cols.to_string(index=False)
ncrdf.to_csv(r'D:\Data\Depotwise_monitoring_report\NCRD\NCRD_Monitoring_Report_'+str(yesterdate)+'.csv')
ncroppath = r'D:\Data\Depotwise_monitoring_report\NCRD\NCRD_Monitoring_Report_'+str(yesterdate)+'.csv'


filePath = ncroppath
def sendEmail(#TO = ["supratim@iepfunds.com","Ankit@iepfunds.com","abhik.mitra@spoton.co.in","krishna.chandrasekar@spoton.co.in","nikhil.saxena@spoton.co.in","Anto.Paul@Spoton.Co.In"],
             #TO = ["mahesh.reddy@spoton.co.in"],
             TO = ["dinesh.kumar.sharma@spoton.co.in"],
             #CC = ["mahesh.reddy@spoton.co.in"],
             CC = ["Anto.Paul@Spoton.Co.In","Nikhil.Saxena@Spoton.Co.In","vishwas.j@spoton.co.in","goutam.barik@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "Monitoring Report " + '- ' + str(yesterdate)
    msg["Subject"] = "PUD Monitoring Report-NCRD" + '- ' + str(yesterdate)
    body_text = """
    Dear All,
    
    PFB the NCRD PUD Monitoring Report as of """+str(yesterdate)+ """
    
    PFB tthe summary
    
"""+str(ncrdf_req_cols)+"""

For Conwise data, please download from the link below

http://spoton.co.in/downloads/IEProjects/ETA/NCRD_Data.csv

    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends


# In[38]:

ixckeeplist = ['IXCD','IXCD_TOTAL']
ixcdf = monitoring_depotwise[monitoring_depotwise['DEPOT2'].isin(ixckeeplist)]
ixcdf_req_cols = ixcdf[['PUDTYPES','CPKG_YDAY','% ACT_WT_YDAY','CPKG_MTD','% ACT_WT_MTD']]
ixcdf_req_cols = ixcdf_req_cols.rename(columns={'CPKG_YDAY':'CPK_Y','% ACT_WT_YDAY':'%WT_Y','CPKG_MTD':'CPK_M','% ACT_WT_MTD':'%WT_M'})
ixcdf_req_cols= ixcdf_req_cols.to_string(index=False)
ixcdf.to_csv(r'D:\Data\Depotwise_monitoring_report\IXCD\IXCD_Monitoring_Report_'+str(yesterdate)+'.csv')
ixcoppath = r'D:\Data\Depotwise_monitoring_report\IXCD\IXCD_Monitoring_Report_'+str(yesterdate)+'.csv'


filePath = ixcoppath
def sendEmail(#TO = ["supratim@iepfunds.com","Ankit@iepfunds.com","abhik.mitra@spoton.co.in","krishna.chandrasekar@spoton.co.in","nikhil.saxena@spoton.co.in","Anto.Paul@Spoton.Co.In"],
             #TO = ["mahesh.reddy@spoton.co.in"],
             TO = ["avinash.singh@spoton.co.in"],
             #CC = ["mahesh.reddy@spoton.co.in"],
             CC = ["Anto.Paul@Spoton.Co.In","Nikhil.Saxena@Spoton.Co.In","vishwas.j@spoton.co.in","goutam.barik@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "Monitoring Report " + '- ' + str(yesterdate)
    msg["Subject"] = "PUD Monitoring Report-IXCD" + '- ' + str(yesterdate)
    body_text = """
    Dear All,
    
    PFB the IXCD PUD Monitoring Report as of """+str(yesterdate)+ """
    
    PFB tthe summary
    
"""+str(ixcdf_req_cols)+"""

For Conwise data, please download from the link below

http://spoton.co.in/downloads/IEProjects/ETA/IXCD_Data.csv

    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends


# In[39]:

lkokeeplist = ['LKOD','LKOD_TOTAL']
lkodf = monitoring_depotwise[monitoring_depotwise['DEPOT2'].isin(lkokeeplist)]
lkodf_req_cols = lkodf[['PUDTYPES','CPKG_YDAY','% ACT_WT_YDAY','CPKG_MTD','% ACT_WT_MTD']]
lkodf_req_cols = lkodf_req_cols.rename(columns={'CPKG_YDAY':'CPK_Y','% ACT_WT_YDAY':'%WT_Y','CPKG_MTD':'CPK_M','% ACT_WT_MTD':'%WT_M'})
lkodf_req_cols= lkodf_req_cols.to_string(index=False)
lkodf.to_csv(r'D:\Data\Depotwise_monitoring_report\LKOD\LKOD_Monitoring_Report_'+str(yesterdate)+'.csv')
lkooppath = r'D:\Data\Depotwise_monitoring_report\LKOD\LKOD_Monitoring_Report_'+str(yesterdate)+'.csv'


filePath = lkooppath
def sendEmail(#TO = ["supratim@iepfunds.com","Ankit@iepfunds.com","abhik.mitra@spoton.co.in","krishna.chandrasekar@spoton.co.in","nikhil.saxena@spoton.co.in","Anto.Paul@Spoton.Co.In"],
             #TO = ["mahesh.reddy@spoton.co.in"],
             TO = ["ashwani.gangwar@spoton.co.in"],
             #CC = ["mahesh.reddy@spoton.co.in"],
             CC = ["Anto.Paul@Spoton.Co.In","Nikhil.Saxena@Spoton.Co.In","vishwas.j@spoton.co.in","goutam.barik@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "Monitoring Report " + '- ' + str(yesterdate)
    msg["Subject"] = "PUD Monitoring Report-LKOD" + '- ' + str(yesterdate)
    body_text = """
    Dear All,
    
    PFB the LKOD PUD Monitoring Report as of """+str(yesterdate)+ """
    
    PFB tthe summary
    
"""+str(lkodf_req_cols)+"""

For Conwise data, please download from the link below

http://spoton.co.in/downloads/IEProjects/ETA/LKOD_Data.csv
    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends


# In[40]:

pnqkeeplist = ['PNQD','PNQD_TOTAL']
pnqdf = monitoring_depotwise[monitoring_depotwise['DEPOT2'].isin(pnqkeeplist)]
pnqdf_req_cols = pnqdf[['PUDTYPES','CPKG_YDAY','% ACT_WT_YDAY','CPKG_MTD','% ACT_WT_MTD']]
pnqdf_req_cols = pnqdf_req_cols.rename(columns={'CPKG_YDAY':'CPK_Y','% ACT_WT_YDAY':'%WT_Y','CPKG_MTD':'CPK_M','% ACT_WT_MTD':'%WT_M'})
pnqdf_req_cols= pnqdf_req_cols.to_string(index=False)
pnqdf.to_csv(r'D:\Data\Depotwise_monitoring_report\PNQD\PNQD_Monitoring_Report_'+str(yesterdate)+'.csv')
pnqoppath = r'D:\Data\Depotwise_monitoring_report\PNQD\PNQD_Monitoring_Report_'+str(yesterdate)+'.csv'


filePath = pnqoppath
def sendEmail(#TO = ["supratim@iepfunds.com","Ankit@iepfunds.com","abhik.mitra@spoton.co.in","krishna.chandrasekar@spoton.co.in","nikhil.saxena@spoton.co.in","Anto.Paul@Spoton.Co.In"],
             #TO = ["mahesh.reddy@spoton.co.in"],
             TO = ["ramniwas.sharma@spoton.co.in"],
             #CC = ["mahesh.reddy@spoton.co.in"],
             CC = ["Anto.Paul@Spoton.Co.In","Nikhil.Saxena@Spoton.Co.In","vishwas.j@spoton.co.in","goutam.barik@spoton.co.in","Rajesh.Debnath@Spoton.Co.In"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "Monitoring Report " + '- ' + str(yesterdate)
    msg["Subject"] = "PUD Monitoring Report-PNQD" + '- ' + str(yesterdate)
    body_text = """
    Dear All,
    
    PFB the PNQD PUD Monitoring Report as of """+str(yesterdate)+ """
    
    PFB tthe summary
    
"""+str(pnqdf_req_cols)+"""

For Conwise data, please download from the link below

http://spoton.co.in/downloads/IEProjects/ETA/PNQD_Data.csv
    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends


# In[41]:

bomkeeplist = ['BOMD','BOMD_TOTAL']
bomdf = monitoring_depotwise[monitoring_depotwise['DEPOT2'].isin(bomkeeplist)]
bomdf_req_cols = bomdf[['PUDTYPES','CPKG_YDAY','% ACT_WT_YDAY','CPKG_MTD','% ACT_WT_MTD']]
bomdf_req_cols = bomdf_req_cols.rename(columns={'CPKG_YDAY':'CPK_Y','% ACT_WT_YDAY':'%WT_Y','CPKG_MTD':'CPK_M','% ACT_WT_MTD':'%WT_M'})
bomdf_req_cols= bomdf_req_cols.to_string(index=False)
bomdf.to_csv(r'D:\Data\Depotwise_monitoring_report\BOMD\BOMD_Monitoring_Report_'+str(yesterdate)+'.csv')
bomoppath = r'D:\Data\Depotwise_monitoring_report\BOMD\BOMD_Monitoring_Report_'+str(yesterdate)+'.csv'


filePath = bomoppath
def sendEmail(#TO = ["supratim@iepfunds.com","Ankit@iepfunds.com","abhik.mitra@spoton.co.in","krishna.chandrasekar@spoton.co.in","nikhil.saxena@spoton.co.in","Anto.Paul@Spoton.Co.In"],
             #TO = ["mahesh.reddy@spoton.co.in"],
             TO = ["harish.bobade@spoton.co.in"],
             #CC = ["mahesh.reddy@spoton.co.in"],
             CC = ["Anto.Paul@Spoton.Co.In","Nikhil.Saxena@Spoton.Co.In","vishwas.j@spoton.co.in","goutam.barik@spoton.co.in","Rajesh.Debnath@Spoton.Co.In"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "Monitoring Report " + '- ' + str(yesterdate)
    msg["Subject"] = "PUD Monitoring Report-BOMD" + '- ' + str(yesterdate)
    body_text = """
    Dear All,
    
    PFB the BOMD PUD Monitoring Report as of """+str(yesterdate)+ """
    
    PFB tthe summary
    
"""+str(bomdf_req_cols)+"""

For Conwise data, please download from the link below

http://spoton.co.in/downloads/IEProjects/ETA/BOMD_Data.csv
    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends


# In[42]:

amdkeeplist = ['AMDD','AMDD_TOTAL']
amddf = monitoring_depotwise[monitoring_depotwise['DEPOT2'].isin(amdkeeplist)]
amddf_req_cols = amddf[['PUDTYPES','CPKG_YDAY','% ACT_WT_YDAY','CPKG_MTD','% ACT_WT_MTD']]
amddf_req_cols = amddf_req_cols.rename(columns={'CPKG_YDAY':'CPK_Y','% ACT_WT_YDAY':'%WT_Y','CPKG_MTD':'CPK_M','% ACT_WT_MTD':'%WT_M'})
amddf_req_cols= amddf_req_cols.to_string(index=False)
amddf.to_csv(r'D:\Data\Depotwise_monitoring_report\AMDD\AMDD_Monitoring_Report_'+str(yesterdate)+'.csv')
amdoppath = r'D:\Data\Depotwise_monitoring_report\AMDD\AMDD_Monitoring_Report_'+str(yesterdate)+'.csv'


filePath = amdoppath
def sendEmail(#TO = ["supratim@iepfunds.com","Ankit@iepfunds.com","abhik.mitra@spoton.co.in","krishna.chandrasekar@spoton.co.in","nikhil.saxena@spoton.co.in","Anto.Paul@Spoton.Co.In"],
             #TO = ["mahesh.reddy@spoton.co.in"],
             TO = ["balakrishnan.r@spoton.co.in"],
             #CC = ["mahesh.reddy@spoton.co.in"],
             CC = ["Anto.Paul@Spoton.Co.In","Nikhil.Saxena@Spoton.Co.In","vishwas.j@spoton.co.in","goutam.barik@spoton.co.in","Rajesh.Debnath@Spoton.Co.In"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "Monitoring Report " + '- ' + str(yesterdate)
    msg["Subject"] = "PUD Monitoring Report-AMDD" + '- ' + str(yesterdate)
    body_text = """
    Dear All,
    
    PFB the AMDD PUD Monitoring Report as of """+str(yesterdate)+ """
    
    PFB tthe summary
    
"""+str(amddf_req_cols)+"""

For Conwise data, please download from the link below

http://spoton.co.in/downloads/IEProjects/ETA/AMDD_Data.csv
    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends


# In[43]:

idrkeeplist = ['IDRD','IDRD_TOTAL']
idrdf = monitoring_depotwise[monitoring_depotwise['DEPOT2'].isin(idrkeeplist)]
idrdf_req_cols = idrdf[['PUDTYPES','CPKG_YDAY','% ACT_WT_YDAY','CPKG_MTD','% ACT_WT_MTD']]
idrdf_req_cols = idrdf_req_cols.rename(columns={'CPKG_YDAY':'CPK_Y','% ACT_WT_YDAY':'%WT_Y','CPKG_MTD':'CPK_M','% ACT_WT_MTD':'%WT_M'})
idrdf_req_cols= idrdf_req_cols.to_string(index=False)
idrdf.to_csv(r'D:\Data\Depotwise_monitoring_report\IDRD\IDRD_Monitoring_Report_'+str(yesterdate)+'.csv')
idroppath = r'D:\Data\Depotwise_monitoring_report\IDRD\IDRD_Monitoring_Report_'+str(yesterdate)+'.csv'


filePath = idroppath
def sendEmail(#TO = ["supratim@iepfunds.com","Ankit@iepfunds.com","abhik.mitra@spoton.co.in","krishna.chandrasekar@spoton.co.in","nikhil.saxena@spoton.co.in","Anto.Paul@Spoton.Co.In"],
             #TO =["mahesh.reddy@spoton.co.in"],
             TO = ["rajesh.mishra@spoton.co.in","Chhabil.Singh@spoton.co.in"],
             #CC = ["mahesh.reddy@spoton.co.in"],
             CC = ["Anto.Paul@Spoton.Co.In","Nikhil.Saxena@Spoton.Co.In","vishwas.j@spoton.co.in","goutam.barik@spoton.co.in","Rajesh.Debnath@Spoton.Co.In"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "Monitoring Report " + '- ' + str(yesterdate)
    msg["Subject"] = "PUD Monitoring Report-IDRD" + '- ' + str(yesterdate)
    body_text = """
    Dear All,
    
    PFB the IDRD PUD Monitoring Report as of """+str(yesterdate)+ """
    
    PFB tthe summary
    
"""+str(idrdf_req_cols)+"""

For Conwise data, please download from the link below

http://spoton.co.in/downloads/IEProjects/ETA/IDRD_Data.csv
    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends



print pmddata.columns.tolist()
## For FTP-ing data of respective DEPOTS
#pmddata = pmddata.rename(columns={'\xef\xbb\xbfCON_ID2':'CON_ID2'})

#pmddata = pmddata[['CON_ID2','DATE2','PINCODE2','PINTYPE','REGION2','DEPOT2','AREA2','BRANCH_CODE2','BRANCH_NAME2','SENDERCODE2','SENDERNAME2','RECEIVERCODE2','RECEIVERNAME2','ACT_WT2','DESTARRV_ARRVDT','PUD_CODE2','PUD_NAME2','PUDTYPE2','COST2','TYP2','CPKG2','BAVEHNO','BAVEHTYPE','BAVEHCAP','CONT_AMOUNT','MarketHireReqId','MKT_PANNO','MKT_PANNAME','CDELDT','RouteName']]
#pmddata_ccu = pmddata[pmddata['DEPOT2']=='CCUD']
#pmddata_ccu.to_csv(r'D:\Data\Depotwise_monitoring_report\CCUD_Data.csv')
#oppathccu = r'D:\Data\Depotwise_monitoring_report\CCUD_Data.csv'



#pmddata = pmddata[['CON_ID2','DATE2','PINCODE2','PINTYPE','REGION2','DEPOT2','AREA2','BRANCH_CODE2','BRANCH_NAME2','SENDERCODE2','SENDERNAME2','RECEIVERCODE2','RECEIVERNAME2','ACT_WT2','DESTARRV_ARRVDT','PUD_CODE2','PUD_NAME2','PUDTYPE2','COST2','TYP2','CPKG2','BAVEHNO','BAVEHTYPE','BAVEHCAP','CONT_AMOUNT','MarketHireReqId','MKT_PANNO','MKT_PANNAME','CDELDT','RouteName']]
pmddata = pmddata[['CON_ID2','DATE2','PINCODE2','PINTYPE','REGION2','DEPOT2','AREA2','BRANCH_CODE2','BRANCH_NAME2','SENDERCODE2','SENDERNAME2','RECEIVERCODE2','RECEIVERNAME2','ACT_WT2','DESTARRV_ARRVDT','PUD_CODE2','PUD_NAME2','PUDTYPE2','COST2','TYP2','CPKG2','BAVEHNO','BAVEHTYPE','BAVEHCAP','CONT_AMOUNT','MarketHireReqId','MKT_PANNO','MKT_PANNAME','RouteName']]

pmddata_ccu = pmddata[pmddata['DEPOT2']=='CCUD']
pmddata_blr = pmddata[pmddata['DEPOT2']=='BLRD']
pmddata_hyd = pmddata[pmddata['DEPOT2']=='HYDD']
pmddata_maa = pmddata[pmddata['DEPOT2']=='MAAD']
pmddata_rtk = pmddata[pmddata['DEPOT2']=='RTKD']
pmddata_amd = pmddata[pmddata['DEPOT2']=='AMDD']
pmddata_bom = pmddata[pmddata['DEPOT2']=='BOMD']
pmddata_idr = pmddata[pmddata['DEPOT2']=='IDRD']
pmddata_pnq = pmddata[pmddata['DEPOT2']=='PNQD']
pmddata_ncr = pmddata[pmddata['DEPOT2']=='NCRD']
pmddata_lko = pmddata[pmddata['DEPOT2']=='LKOD']
pmddata_ixc = pmddata[pmddata['DEPOT2']=='IXCD']
pmddata_ukn = pmddata[pmddata['DEPOT2']=='UKND']

pmddata_ccu.to_csv(r'D:\Data\Depotwise_monitoring_report\CCUD_Data.csv')
oppathccu = r'D:\Data\Depotwise_monitoring_report\CCUD_Data.csv'
pmddata_blr.to_csv(r'D:\Data\Depotwise_monitoring_report\BLRD_Data.csv')
oppathblr = r'D:\Data\Depotwise_monitoring_report\BLRD_Data.csv'
pmddata_hyd.to_csv(r'D:\Data\Depotwise_monitoring_report\HYDD_Data.csv')
oppathhyd = r'D:\Data\Depotwise_monitoring_report\HYDD_Data.csv'
pmddata_maa.to_csv(r'D:\Data\Depotwise_monitoring_report\MAAD_Data.csv')
oppathmaa = r'D:\Data\Depotwise_monitoring_report\MAAD_Data.csv'
pmddata_rtk.to_csv(r'D:\Data\Depotwise_monitoring_report\RTKD_Data.csv')
oppathrtk = r'D:\Data\Depotwise_monitoring_report\RTKD_Data.csv'
pmddata_amd.to_csv(r'D:\Data\Depotwise_monitoring_report\AMDD_Data.csv')
oppathamd = r'D:\Data\Depotwise_monitoring_report\AMDD_Data.csv'
pmddata_bom.to_csv(r'D:\Data\Depotwise_monitoring_report\BOMD_Data.csv')
oppathbom = r'D:\Data\Depotwise_monitoring_report\BOMD_Data.csv'
pmddata_idr.to_csv(r'D:\Data\Depotwise_monitoring_report\IDRD_Data.csv')
oppathidr = r'D:\Data\Depotwise_monitoring_report\IDRD_Data.csv'
pmddata_pnq.to_csv(r'D:\Data\Depotwise_monitoring_report\PNQD_Data.csv')
oppathpnq = r'D:\Data\Depotwise_monitoring_report\PNQD_Data.csv'
pmddata_ncr.to_csv(r'D:\Data\Depotwise_monitoring_report\NCRD_Data.csv')
oppathncr = r'D:\Data\Depotwise_monitoring_report\NCRD_Data.csv'
pmddata_lko.to_csv(r'D:\Data\Depotwise_monitoring_report\LKOD_Data.csv')
oppathlko = r'D:\Data\Depotwise_monitoring_report\LKOD_Data.csv'
pmddata_ixc.to_csv(r'D:\Data\Depotwise_monitoring_report\IXCD_Data.csv')
oppathixc = r'D:\Data\Depotwise_monitoring_report\IXCD_Data.csv'
pmddata_ukn.to_csv(r'D:\Data\Depotwise_monitoring_report\UKND_Data.csv')
oppathukn = r'D:\Data\Depotwise_monitoring_report\UKND_Data.csv'

print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppathccu
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()
    

print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppathblr
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()

print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppathhyd
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()


print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppathmaa
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()
    
print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppathrtk
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()
    
    
print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppathamd
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()
    

print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppathbom
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()
    
    
print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppathidr
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()
    

print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppathpnq
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()
    
print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppathncr
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()
    

print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppathlko
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()
    
    
print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppathixc
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()
    
    
print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppathukn
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()