
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta,datetime

import Utilities
# In[2]:
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

from datetime import date,timedelta 
d=date.today()
today_date=datetime.strftime(d,'%d-%b-%y')
date1=date.today()-timedelta(1)
yest_date=datetime.strftime(date1,'%d-%b-%y')
pickup_date1=datetime.strftime(date1,'%Y-%m-%d')
pickup_date2=pickup_date1+' 23:59'
print (today_date,yest_date,pickup_date1,pickup_date2)


# In[3]:
try:

    #cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")


    # # In[4]:


    # cursor=cnxn.cursor()

    #cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
    #cursor = cnxn.cursor()


    # In[5]:


    #Pickup count numbers
    query=("""SELECT COUNT(*) Pick_Cons FROM dbo.DOCKET WHERE DOCKDT BETWEEN '{0}' AND '{1}' AND PAYBAS <> 6""").format(pickup_date1,pickup_date2)
    query


    # In[6]:


    d={}


    # In[7]:

    #Pkup_count =pd.read_sql(query,cnxn)
    Pkup_count =pd.read_sql(query,Utilities.cnxn)
    Pkup_count['Pick_Cons'][0]


    # In[8]:


    Picked_up=Pkup_count['Pick_Cons']
    d['Picked up']=Pkup_count['Pick_Cons'][0]
    d['Picked up']


    # In[9]:


    #Delivery count numbers
    #SELECT COUNT(*) FROM dbo.DKT_DELY WHERE DELY_DT BETWEEN '2018-01-30' AND '2018-01-30 23:59:00' 
    query1=(""" SELECT COUNT(*) FROM dbo.DKT_DELY WHERE DELY_DT BETWEEN '{0}' and '{1}'""".format(pickup_date1,pickup_date2))
    query1


    # In[10]:

    #Dlry_count=pd.read_sql(query1,cnxn)
    Dlry_count=pd.read_sql(query1,Utilities.cnxn)
    #Delivered=Dlry_count['CONS'].sum()
    Dlry_count[''][0]


    # In[11]:


    d['Delivered']=Dlry_count[''][0]
    d


    # In[12]:


    #Closing stock report
    query2=("""SELECT  A.*, CASE WHEN ( CON_BLOCKED_FOR_PAY_ISSUES = 'YES' ) THEN 'A3_PAYMENT_ISSUE'  
                 WHEN ( ConStatusCode IN( 'SSC','SHS' )) THEN 'A4_Seized by Sales Tax'  
                 WHEN ( ConStatusCode IN ('UCG','UG1','UG2','UG3' )) THEN '8_UCG'  
                 WHEN (CON_BLOCKED_FOR_DEMURRAGE = 'YES' AND DEMURRAGE_RESPONSIBILITY = 'CS') THEN '2_CS Dem_Pin Drs Block'--'CS Dem Drs Block'  
                 WHEN (CON_BLOCKED_FOR_DEMURRAGE = 'YES' AND DEMURRAGE_RESPONSIBILITY = 'OPS' AND LatestTicketStatus != 'Open') THEN '5_OPS Dem Drs Block'  
                 WHEN (CON_BLOCKED_FOR_ODA_PIN_ISSUES =  'YES') THEN '2_CS Dem_Pin Drs Block' --'CS PIN DRS BLOCK'  
                 WHEN (REPORTDATE_MIN_ARRVDT > 1440 ) THEN 'A1_DEAD STOCK'  
                 WHEN (IsTTSTicketRaised = 'YES' AND LatestTicketStatus = 'CLOSED' AND LatestTicketStatusCode = ConStatusCode AND REPORTDATE_MIN_ARRVDT >= 40) THEN '3_OPS/Free Con Bucket-Old'  
                 WHEN (IsTTSTicketRaised = 'YES' AND LatestTicketStatus = 'CLOSED' AND LatestTicketStatusCode = ConStatusCode AND REPORTDATE_MIN_ARRVDT < 40) THEN '4_OPS/Free Con Bucket-NEW'  
                 WHEN (IS_FREE_CON_NEW = 'YES' AND REPORTDATE_MIN_ARRVDT >= 40) THEN '3_OPS/Free Con Bucket-Old'  
                 WHEN (IS_FREE_CON_NEW = 'YES' AND REPORTDATE_MIN_ARRVDT < 40) THEN '4_OPS/Free Con Bucket-New'  
                 WHEN (IsTTSTicketRaised = 'YES' AND LatestTicketStatus = 'OPEN') THEN '1_CS Bucket'  
                 WHEN (ConStatusCategory = 'DEPS' AND REPORTDATE_MIN_ARRVDT > 168 ) THEN '9_DEPS-SQ'  
                 WHEN (ConStatusCategory = 'DEPS' AND REPORTDATE_MIN_ARRVDT <= 168 ) THEN '6_DEPS-OPS'  
                 WHEN (ConStatusCategory IN ( 'RECEIVER FAILURE','SENDER FAILURE') )THEN 'A2_CCF without Tickets'   
                 ELSE '7_Others/Timelag'             
            END STATUS1   
    FROM    dbo.tblOCIDClosingStock A  
    WHERE   LogDate >= CONVERT(DATE,GETDATE()-0)""")


    # In[13]:

    #Closing_df=pd.read_sql(query2,cnxn)
    Closing_df=pd.read_sql(query2,Utilities.cnxn)


    # In[14]:


    pivot_df=pd.pivot_table(Closing_df,index=['STATUS1'],values=['DOCKNO','REPORTDATE_MIN_ARRVDT'],aggfunc={'DOCKNO':len,'REPORTDATE_MIN_ARRVDT':sum}).reset_index()

    pivot_df['Mean']=(pivot_df['REPORTDATE_MIN_ARRVDT']/pivot_df['DOCKNO']).astype(int)
    # In[15]:


    pivot_df['REPORTDATE_MIN_ARRVDT']=np.round(pivot_df['REPORTDATE_MIN_ARRVDT'],1)
    Cons=pivot_df['DOCKNO'].sum()

    # Cons
    Ageing=int(pivot_df['REPORTDATE_MIN_ARRVDT'].sum()/Cons)
    #pivot_df[6:]


    # In[16]:


    tts_tickets=pivot_df[pivot_df['STATUS1']=='1_CS Bucket']
    cs_dem=pivot_df[pivot_df['STATUS1']=='2_CS Dem_Pin Drs Block']
    ops_bucket_old=pivot_df[pivot_df['STATUS1']=='3_OPS/Free Con Bucket-Old']
    ops_bucket_NEW=pivot_df[pivot_df['STATUS1']=='4_OPS/Free Con Bucket-NEW']
    ops_bucket_new=pivot_df[pivot_df['STATUS1']=='4_OPS/Free Con Bucket-New']
    ops_bucket_drs_block=pivot_df[pivot_df['STATUS1']=='5_OPS Dem Drs Block']
    ops_bucket_deps_ops=pivot_df[pivot_df['STATUS1']=='6_DEPS-OPS']
    ops_bucket_others=pivot_df[pivot_df['STATUS1']=='7_Others/Timelag']
    sq_ucg=pivot_df[pivot_df['STATUS1']=='8_UCG']
    sq_deps=pivot_df[pivot_df['STATUS1']=='9_DEPS-SQ']
    sq_dead_stock=pivot_df[pivot_df['STATUS1']=='A1_DEAD STOCK']
    unassigned_ccf_tts=pivot_df[pivot_df['STATUS1']=='A2_CCF without Tickets']
    unassigned_payment_iss=pivot_df[pivot_df['STATUS1']=='A3_PAYMENT_ISSUE']
    unassigned_seized=pivot_df[pivot_df['STATUS1']=='A4_Seized by Sales Tax']


    # In[17]:


    sq_deps


    # In[18]:


    ops_new_cons=ops_bucket_NEW.values[0][1]+ops_bucket_new.values[0][1]
    ops_new_ageing=ops_bucket_NEW.values[0][3]+ops_bucket_new.values[0][3]


    # In[19]:


    print (ops_new_cons,ops_new_ageing)


    # In[20]:


    xls = pd.ExcelFile(r'D:\Data\ODA_Loads_Ton_wise\Closing Stock Summary_'+str(yest_date)+'.xlsx')
    kpi_df = pd.read_excel(xls,sheetname='Sheet1')
    kpi_df1=kpi_df
    kpi_df1['Total Closing Stock_Ageing']=kpi_df1['Total Closing Stock_Ageing'].astype(int)
    kpi_df1['CS Bucket_TTS Tickets_Ageing']=kpi_df1['CS Bucket_TTS Tickets_Ageing'].astype(int)
    kpi_df1['CS Bucket_DRSBlock_Ageing']=kpi_df1['CS Bucket_DRSBlock_Ageing'].astype(int)
    kpi_df1['Ops Bkt_Free_Cons-Old(>=24hrs)_Ageing']=kpi_df1['Ops Bkt_Free_Cons-Old(>=24hrs)_Ageing'].astype(int)
    kpi_df1['Ops Bkt_Free_Cons-New(<24hrs)_Ageing']=kpi_df1['Ops Bkt_Free_Cons-New(<24hrs)_Ageing'].astype(int)
    kpi_df1['Ops Bkt_DRSBlock_Ageing']=kpi_df1['Ops Bkt_DRSBlock_Ageing'].astype(int)
    kpi_df1['Ops Bkt_DEPS<7@Dest_Ageing']=kpi_df1['Ops Bkt_DEPS<7@Dest_Ageing'].astype(int)
    kpi_df1['Ops Bkt_Others_Ageing']=kpi_df1['Ops Bkt_Others_Ageing'].astype(int)
    kpi_df1['SQ Bucket_UCG_Ageing']=kpi_df1['SQ Bucket_UCG_Ageing'].astype(int)
    kpi_df1['SQ Bucket_DEPS_Ageing']=kpi_df1['SQ Bucket_DEPS_Ageing'].astype(int)
    kpi_df1['SQ Bucket_DeadStock_Ageing']=kpi_df1['SQ Bucket_DeadStock_Ageing'].astype(int)
    kpi_df1['Unassgn_Bkt_CCF_TTS_Ageing']=kpi_df1['Unassgn_Bkt_CCF_TTS_Ageing'].astype(int)
    kpi_df1['Unassgn_Bkt_Payment_Ageing']=kpi_df1['Unassgn_Bkt_Payment_Ageing'].astype(int)
    kpi_df1['Unassgn_Bkt_Seized Cases_Ageing']=kpi_df1['Unassgn_Bkt_Seized Cases_Ageing'].astype(int)
    len(kpi_df1.columns)


    # In[21]:


    kpi_df1.head(10)


    # In[22]:


    if len(sq_deps)>0:
        sq_deps=sq_deps
    else:
        f1=['9_DEPS-SQ',0,0,0]
        f2=['STATUS1','DOCKNO','REPORTDATE_MIN_ARRVDT','Mean']
        sq_deps=pd.DataFrame(data=[f1],columns=f2)


    # In[ ]:


    sq_deps


    # In[23]:


    # kpi_df1['Unnamed: 1']=d['Picked up']
    print (sq_deps)
    #kpi_df1=kpi_df1.append({'Date':yest_date,'Picked up_Cons':d['Picked up'],'Delivered_Cons':d['Delivered'],'Total Closing Stock_Cons':Cons,'Total Closing Stock_Ageing':Ageing,'CS Bucket_TTS Tickets_Cons':tts_tickets.values[0][1],'CS Bucket_TTS Tickets_Ageing':tts_tickets.values[0][2],'CS Bucket_DRSBlock_Cons':cs_dem.values[0][1],'CS Bucket_DRSBlock_Ageing':cs_dem.values[0][2],'CS Bucket_Total':(cs_dem.values[0][1]+tts_tickets.values[0][1]),'Ops Bkt_Free_Cons-Old(>=24hrs)_Cons':ops_bucket_old.values[0][1],'Ops Bkt_Free_Cons-Old(>=24hrs)_Ageing':ops_bucket_old.values[0][2],'Ops Bkt_Free_Cons-New(<24hrs)_Cons':ops_new_cons,'Ops Bkt_Free_Cons-New(<24hrs)_Ageing':ops_new_ageing,'Ops Bkt_DRSBlock_Cons':ops_bucket_drs_block.values[0][1],'Ops Bkt_DRSBlock_Ageing':ops_bucket_drs_block.values[0][2],'Ops Bkt_DEPS<7@Dest_Cons':ops_bucket_deps_ops.values[0][1],'Ops Bkt_DEPS<7@Dest_Ageing':ops_bucket_deps_ops.values[0][2],'Ops Bkt_Others_Cons':ops_bucket_others.values[0][1],'Ops Bkt_Others_Ageing':ops_bucket_others.values[0][2],'Ops Bkt_Others_Total':(ops_bucket_old.values[0][1]+ops_new_cons+ops_bucket_drs_block.values[0][1]+ops_bucket_deps_ops.values[0][1]+ops_bucket_others.values[0][1]),'SQ Bucket_UCG_Cons':sq_ucg.values[0][1],'SQ Bucket_UCG_Ageing':sq_ucg.values[0][2],'SQ Bucket_DEPS_Cons':sq_deps.values[0][1],'SQ Bucket_DEPS_Ageing':sq_deps.values[0][2],'SQ Bucket_DeadStock_Cons':sq_dead_stock.values[0][1],'SQ Bucket_DeadStock_Ageing':sq_dead_stock.values[0][2],'SQ Bucket_Total':(sq_ucg.values[0][1]+sq_deps.values[0][1]+sq_dead_stock.values[0][1]),'Unassgn_Bkt_CCF_TTS_Cons':unassigned_ccf_tts.values[0][1],'Unassgn_Bkt_CCF_TTS_Ageing':unassigned_ccf_tts.values[0][2],'Unassgn_Bkt_Payment_Cons':unassigned_payment_iss.values[0][1],'Unassgn_Bkt_Payment_Ageing':unassigned_payment_iss.values[0][2],'Unassgn_Bkt_Seized Cases_Cons':unassigned_seized.values[0][1],'Unassgn_Bkt_Seized Cases_Ageing':unassigned_seized.values[0][2],'Unassigned Bucket_Total':(unassigned_ccf_tts.values[0][1]+unassigned_payment_iss.values[0][1]+unassigned_seized.values[0][1])},ignore_index=True)
    f3=[yest_date,d['Picked up'],d['Delivered'],Cons,Ageing,tts_tickets.values[0][1],tts_tickets.values[0][3],cs_dem.values[0][1],cs_dem.values[0][3],(cs_dem.values[0][1]+tts_tickets.values[0][1]),ops_bucket_old.values[0][1],ops_bucket_old.values[0][3],ops_new_cons,ops_new_ageing,ops_bucket_drs_block.values[0][1],ops_bucket_drs_block.values[0][3],ops_bucket_deps_ops.values[0][1],ops_bucket_deps_ops.values[0][3],ops_bucket_others.values[0][1],ops_bucket_others.values[0][3],(ops_bucket_old.values[0][1]+ops_new_cons+ops_bucket_drs_block.values[0][1]+ops_bucket_deps_ops.values[0][1]+ops_bucket_others.values[0][1]),sq_ucg.values[0][1],sq_ucg.values[0][3],sq_deps.values[0][1],sq_deps.values[0][3],sq_dead_stock.values[0][1],sq_dead_stock.values[0][3],(sq_ucg.values[0][1]+sq_deps.values[0][1]+sq_dead_stock.values[0][1]),unassigned_ccf_tts.values[0][1],unassigned_ccf_tts.values[0][3],unassigned_payment_iss.values[0][1],unassigned_payment_iss.values[0][3],unassigned_seized.values[0][1],unassigned_seized.values[0][3],(unassigned_ccf_tts.values[0][1]+unassigned_payment_iss.values[0][1]+unassigned_seized.values[0][1])]
    f4=['Date','Picked up_Cons','Delivered_Cons','Total Closing Stock_Cons','Total Closing Stock_Ageing','CS Bucket_TTS Tickets_Cons','CS Bucket_TTS Tickets_Ageing','CS Bucket_DRSBlock_Cons','CS Bucket_DRSBlock_Ageing','CS Bucket_Total','Ops Bkt_Free_Cons-Old(>=24hrs)_Cons','Ops Bkt_Free_Cons-Old(>=24hrs)_Ageing','Ops Bkt_Free_Cons-New(<24hrs)_Cons','Ops Bkt_Free_Cons-New(<24hrs)_Ageing','Ops Bkt_DRSBlock_Cons','Ops Bkt_DRSBlock_Ageing','Ops Bkt_DEPS<7@Dest_Cons','Ops Bkt_DEPS<7@Dest_Ageing','Ops Bkt_Others_Cons','Ops Bkt_Others_Ageing','Ops Bkt_Others_Total','SQ Bucket_UCG_Cons','SQ Bucket_UCG_Ageing','SQ Bucket_DEPS_Cons','SQ Bucket_DEPS_Ageing','SQ Bucket_DeadStock_Cons','SQ Bucket_DeadStock_Ageing','SQ Bucket_Total','Unassgn_Bkt_CCF_TTS_Cons','Unassgn_Bkt_CCF_TTS_Ageing','Unassgn_Bkt_Payment_Cons','Unassgn_Bkt_Payment_Ageing','Unassgn_Bkt_Seized Cases_Cons','Unassgn_Bkt_Seized Cases_Ageing','Unassigned Bucket_Total']


    # In[24]:


    print (len(f3),len(f4))
    daily_df=pd.DataFrame(data=[f3],columns=f4)


    # In[ ]:


    daily_df


    # In[25]:


    kpi_df1=pd.concat([kpi_df1,daily_df],ignore_index=True)


    # In[ ]:


    type(kpi_df1)


    # In[26]:


    sty=kpi_df1.style.applymap(lambda x:"background-color: yellow",subset=['Picked up_Cons','Delivered_Cons','Total Closing Stock_Cons','CS Bucket_TTS Tickets_Cons','CS Bucket_DRSBlock_Cons','Ops Bkt_Free_Cons-Old(>=24hrs)_Cons','Ops Bkt_Free_Cons-New(<24hrs)_Cons','Ops Bkt_DRSBlock_Cons','Ops Bkt_DEPS<7@Dest_Cons','Ops Bkt_Others_Cons','SQ Bucket_UCG_Cons','SQ Bucket_DEPS_Cons','SQ Bucket_DeadStock_Cons','Unassgn_Bkt_CCF_TTS_Cons','Unassgn_Bkt_Payment_Cons','Unassgn_Bkt_Seized Cases_Cons'])


    # In[27]:


    style2=sty.applymap(lambda x:"background-color: #87CEFA",subset=['CS Bucket_Total','Ops Bkt_Others_Total','SQ Bucket_Total','Unassigned Bucket_Total'])


    # In[ ]:


    style2


    # In[28]:


    from pandas import ExcelWriter
    # with ExcelWriter(r'C:\Users\S2769MAH\Downloads\SQ\sreedhar\Closing Stock Summary_'+str(today_date)+'.xlsx') as writer:
    #     kpi_df1.to_excel(writer,engine='xlsxwriter')
    #r"D:\Data\ODA_Loads_Ton_wise\Closing Stock Summary_"+str(today_date)+".xlsx",engine='openpyxl'
    writer = pd.ExcelWriter(r"D:\Data\ODA_Loads_Ton_wise\Closing Stock Summary_"+str(today_date)+".xlsx")
    style2.to_excel(writer, startrow=0, startcol=0, index = False)

    writer.save()


    # In[ ]:


    # filepath=r'C:\Users\rajeeshv\Downloads\Rajesh\mahesh\Closing Stock Summary_'+str(today_date)+'.xlsx'
    filepath=r'D:\Data\ODA_Loads_Ton_wise\Closing Stock Summary_'+str(today_date)+'.xlsx'


    # In[ ]:


    import numpy as np
    import pandas as pd
    import itertools
    import json
    from pandas import ExcelWriter
    from pandas import pivot_table
    from datetime import datetime
    import os
    import ftplib
    import traceback

    oppath1=filepath
    #FTP Upload starts
    print ('Logging in...')
    ftp = ftplib.FTP()  
    ftp.connect('10.109.230.50')  
    print (ftp.getwelcome())
    try:  
        try:  
            ftp.login('HOSQTeam', 'Te@mH0$q')
            print ('login done')
            ftp.cwd('Auto_reports')  
            #ftp.cwd('FIFO')
            # move to the desired upload directory  
            print ("Currently in:", ftp.pwd()) 
            print ('Uploading...')  
            fullname = oppath1
            name = os.path.split(fullname)[1]  
            f = open(fullname, "rb")  
            ftp.storbinary('STOR ' + name, f)  
            f.close()  
            print ("OK"  )
            print ("Files:")  
            print (ftp.retrlines('LIST'))
        finally:  
            print ("Quitting...")
            ftp.quit()  
    except:  
        traceback.print_exc()


    # In[ ]:


    import smtplib
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    # from email.MIMEBase import MIMEBase
    # from email import Encoders
    from email.mime.base import MIMEBase
    from email import encoders
    import os
    from string import Template

    from_addr = 'mis.ho@spoton.co.in'

    cc_addr = ['maheshmahesh11464@gmail.com','mahesh.reddy@spoton.co.in']
    # bcc_addr = ['maheshmahesh11464@gmail.com','mahesh.reddy@spoton.co.in']
    bcc_addr=['smt_spot@spoton.co.in','pawan.sharma@spoton.co.in','rajesh.kumar@spoton.co.in','shivananda.p@spoton.co.in','prafulla.masurkar@spoton.co.in','sharanagouda.biradar@spoton.co.in','anitha.thyagarajan@spoton.co.in','mahesh.reddy@spoton.co.in']

    username = 'mis.ho@spoton.co.in'
    password = 'Raj@spot12.mp'

    msg = MIMEMultipart()

    msg['From'] = from_addr
    # msg['To'] = ', '.join(to_addr)
    #msg['bcc'] = ', '.join(cc_addr)
    msg['bcc'] = ', '.join(bcc_addr)
    msg['Subject'] = 'Closing Stock Summary -'+str(yest_date)
    html='''<html>
    <h4>Dear All,</h4>
    <p>Pls find attached Closing Stock Summary.</p>
    </html>'''
    # html4='''
    # <h5> Note : For data please click on the below link: </h5>
    # <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Origin SC Connection - On-Time Performance.xlsx"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Origin SC Connection - On-Time Performance.xlsx</p></b>
    # '''
    html1='''<h5>Thanks & Regards</h5></b>
    <h5>HO-SQ</h5>'''
        
    #  msg.attach(part10)
    s = Template(html).safe_substitute()
    report=""
    report+=s
    report+='<br>'
    # report+='<br>'
    # report+=html3
    # report+='<br>'
    # report+=html4
    # report+='<br>'
    report+=html1
    abc=MIMEText(report,'html')
    msg.attach(abc)
    server = smtplib.SMTP('smtp.sendgrid.net',587)
    part=MIMEBase('application','octet-stream')
    # part1=MIMEBase('application','octet-stream')
    part.set_payload(open(filepath,'rb').read())
    # part1.set_payload(open(filepath1,'rb').read())
    encoders.encode_base64(part)
    # Encoders.encode_base64(part1)
    part.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath))
    # part1.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath1))
    msg.attach(part)
    # msg.attach(part1)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    server.sendmail(from_addr,bcc_addr,msg.as_string())
    print ('mail sent succesfully')
    server.quit()


    

except:
    TO=['mahesh.reddy@spoton.co.in','shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in','vishwas.j@spoton.co.in']
    #TO=['mahesh.reddy@spoton.co.in']
    FROM='mis.ho@spoton.co.in'
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    #msg["CC"] = ",".join(CC)
    #msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "ERROR Report - Closing Stock Summary Report" 
    report=""
    report+='Hi,'

    report+='<br>'
    report+='There was some error in Closing Stock Summary Report'
    report+='<br>'
    
    abc=MIMEText(report.encode('utf-8'),'html')
    msg.attach(abc)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO, msg.as_string())
    server.quit()