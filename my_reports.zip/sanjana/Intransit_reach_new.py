
# coding: utf-8

# In[ ]:


import pandas as pd
import numpy as np
from pymongo import MongoClient
from string import Template
import smtplib
import os
from datetime import datetime, timedelta
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import smtplib
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
import Utilities

# In[ ]:


client = MongoClient('mongodb://localhost:27017/')
#path_schedule_master_may_30
db = client['path_schedule_master_May11_19']


# In[ ]:


loading = 1*90 
unloading = 1*90
virtualmovement = 3*60
odadays = 3*24*60


# In[ ]:



cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()
stockquery = ("""SELECT  A.* ,
        CASE WHEN ( B.ETADate IS NULL ) THEN A.CDELDT
             ELSE B.ETADate
        END ETADATE
FROM    tblTimeConnectionReport_Undelivered_2Hrs A
        LEFT OUTER JOIN dbo.tblETAData B WITH ( NOLOCK ) ON A.DOCKNO =
B.ConNo AND ( B.CreatedOn >='2019-07-01' or B.UpdatedOn >='2019-07-01') 
WHERE   A.ISDEPARTED_FRM_CURRLOC = 'YES' """)
tcr = pd.read_sql_query(stockquery, Utilities.cnxn)
print (len(tcr))
tcr.rename(columns={'CURR_BRANCHCODE':'CURR BRANCHCODE','DEPARTURE_TIME_FRM_CURLOC':'DEPARTURE TIME FRM CURLOC','ACTUAL_WEIGHT':'Wt'},inplace=True)

tcr = tcr.set_index('DOCKNO')
tcr=tcr.rename(columns={'ISDEPARTED_FRM_CURRLOC': 'Departed'})
totalcons=len(tcr)

# In[ ]:




# In[ ]:


depspaperworkcodelist = ['SRE','SRD','SRS','SRP','DLP','SWP','PWS','HCM','HPM','MOP','SRH','HOC','ONR','SPH','SPO','DBO','DIP','SHS','SSC','HIP','RNX','APT','APN','SHD','SMT','SPL','MSH','UCG','RRA','HPE','WIA','UG1','UG2','UG3','HMP','HWC','NPE','HIM']
tcr = tcr[~tcr['CurLocConStatusCode'].isin(depspaperworkcodelist)]
len(tcr)
aftremdepscons=len(tcr)
aftremdepscons

# In[ ]:


# tcr['CDELDT']=tcr['CDELDT'].astype(str)+' 12:00:00'


# In[ ]:

odadays = 2*24*60
# tcr['CDELDT']=pd.to_datetime(tcr['CDELDT'])
tcr['CDELDT'] = [dd if dest=='STD' else dd-np.timedelta64(odadays,'m') for dd,dest in zip(tcr.CDELDT,tcr.DESTLOCTYPE)]

# In[ ]:


tcr=tcr[tcr['CURR BRANCHCODE']!=tcr['DESTCD']]
len(tcr)


# In[ ]:


def oldcon(arrv):
    if arrv< tcr['TIME_STAMP'][0]-timedelta(days=30):
        return 'Old'
    else:
        return 'New'


# In[ ]:


tcr['Obsev_1']=tcr.apply(lambda x: oldcon(x['CDELDT']),axis=1)


# In[ ]:


tcr=tcr[tcr['Obsev_1']=='New']
len(tcr)


# In[ ]:


errordict1 = {}
def geteta(origin,destination,currts):
    global virtualmovement, loading, unloading, errordict
    currdt = np.datetime64(str(currts).split('T')[0]+' 00:00:00','ms')
    schdict = db.master.find_one({'origin': origin,'destination': destination})
    retdict = {}
    if schdict:
        schedules = schdict['legdata']
        path = schdict['conpath']
        journeydict = {}
        for legno in range(1,len(schedules)+1):
            step=schedules.get(str(legno))
            journeydict[(step[0],step[1])] = []
            options = step[2]
            if options:
                try:
                    transithours = [np.timedelta64(int((option[0]).split(':')[1])+60*int((option[0]).split(':')[0]),'m') for option in options] #this is actually mins from day beginning
                    hours = min([int(option[1]) for option in options]) #this is actually mins from day beginning
                    if legno==1:
                        arrtime=currts+(np.timedelta64(hours*60,'m'))+np.timedelta64(unloading,'m')
                        journeydict[(step[0],step[1])] = (currts,arrtime)
                    else:
                        convertedoptions = currdt+transithours
                        convertedoptionsbool = [option for option in convertedoptions if option>=currts+np.timedelta64(loading,'m')]
                        if not convertedoptionsbool:
                            convertedoptions = np.timedelta64(24*60,'m') + convertedoptions
                        convertedoptionsbool = [option for option in convertedoptions if option>=currts+np.timedelta64(loading,'m')]
                        if not convertedoptionsbool:
                            convertedoptions = np.timedelta64(24*60,'m') + convertedoptions #two steps needed since for 12:30am etc it is still beyond loading time
                        timeoptions = [(conv,conv+np.timedelta64(int(opt[1])*60,'m')+np.timedelta64(unloading,'m')) for opt,conv in zip(options,convertedoptions) if conv>=currts+np.timedelta64(loading,'m')] #+np.timedelta64(loading,'m') - cnt add loading
                        try:
                            optimaloption = sorted(timeoptions, key=lambda x: x[1])[0]
                        except:
                            print (convertedoptionsbool,convertedoptions,timeoptions)
                        journeydict[(step[0],step[1])] = optimaloption
                        arrtime = optimaloption[1]
                except:
                    retdict['path'] = path
                    retdict['journey'] = {'error': options}
                    errordict1[(step[0],step[1])] = 'error in time of schedule'
                    return retdict
                    
            else:
                deptime = currts
                arrtime = currts+np.timedelta64(virtualmovement,'m')
                journeydict[(step[0],step[1])] = (deptime,arrtime)
            currts = arrtime
            currdt = np.datetime64(str(currts).split('T')[0]+' 00:00:00','ms')
        retdict['path'] = path
        retdict['journey'] = journeydict
        journeytimes = journeydict.values()
        try:
            eta = sorted(journeytimes, key=lambda x: x[1], reverse=True)[0][1]
            retdict['eta'] = eta
        except:
            # print (retdict)
            pass
        
        return retdict
    else:
        print (schdict, origin, destination)
        errordict1[(origin,destination)] = 'no path'
        return False


# In[ ]:


tcr['journeydict'] = [geteta(loc,dest,ts) for loc,dest,ts in zip(tcr['CURR BRANCHCODE'].values,tcr['DEPARTURE_TO_LOC_FRM_CURLOC'].values,tcr['DEPARTURE TIME FRM CURLOC'].values)]


# In[ ]:


tcr['path'] = [i.get('path') if i else i for i in tcr.journeydict.values]
tcr['eta'] = [i.get('eta') if i else i for i in tcr.journeydict.values]


# In[ ]:


len(tcr)


# In[ ]:


tcr=tcr[tcr['eta']!=False]
tcr=tcr[~tcr['eta'].isnull()]
len(tcr)


# In[ ]:


tcr['eta']=pd.to_datetime(tcr['eta'])


# In[ ]:


errordict = {}
def geteta2(origin,destination,currts):
    #print (origin,destination,currts)
    #print (type(currts))
    #print (currts)
    global virtualmovement, loading, unloading, errordict
    currdt = np.datetime64(str(currts).split('T')[0]+' 00:00:00','ms')
    schdict = db.master.find_one({'origin': origin,'destination': destination})
    retdict = {}
    if schdict:
        schedules = schdict['legdata']
        #print ('schedules',schedules,len(schedules))
        path = schdict['conpath']
        #print ('path',path)
        journeydict = {}
        for legno in range(1,len(schedules)+1):
            step=schedules.get(str(legno))
            journeydict[(step[0],step[1])] = []
            options = step[2]
            if options:
                try:
                    transithours = [np.timedelta64(int((option[0]).split(':')[1])+60*int((option[0]).split(':')[0]),'m') for option in options] #this is actually mins from day beginning
                    convertedoptions = currdt+transithours
                    # convertedoptionsbool = [option for option in convertedoptions if option>=currts+np.timedelta64(loading,'m')]
                    convertedoptions = [option if option>=currts+np.timedelta64(loading,'m') else option+np.timedelta64(24*60,'m') for option in convertedoptions  ]
                    convertedoptionsbool = [option if option>=currts+np.timedelta64(loading,'m') else option+np.timedelta64(24*60,'m') for option in convertedoptions  ]

                    if not convertedoptionsbool:
                        convertedoptions = np.timedelta64(24*60,'m') + convertedoptions
                    convertedoptionsbool = [option for option in convertedoptions if option>=currts+np.timedelta64(loading,'m')]
                    if not convertedoptionsbool:
                        convertedoptions = np.timedelta64(24*60,'m') + convertedoptions #two steps needed since for 12:30am etc it is still beyond loading time
                    timeoptions = [(conv,conv+np.timedelta64(int(opt[1])*60,'m')+np.timedelta64(unloading,'m')) for opt,conv in zip(options,convertedoptions) if conv>=currts+np.timedelta64(loading,'m')] #+np.timedelta64(loading,'m') - cnt add loading
                    try:
                        optimaloption = sorted(timeoptions, key=lambda x: x[1])[0]
                    except:
                        print (convertedoptionsbool,convertedoptions,timeoptions)
                    journeydict[(step[0],step[1])] = optimaloption
                    arrtime = optimaloption[1]
                except:
                    retdict['path'] = path
                    retdict['journey'] = {'error': options}
                    errordict[(step[0],step[1])] = 'error in time of schedule'
                    return retdict
                    
            else:
                deptime = currts
                arrtime = currts+np.timedelta64(virtualmovement,'m')
                journeydict[(step[0],step[1])] = (deptime,arrtime)
            currts = arrtime
            currdt = np.datetime64(str(currts).split('T')[0]+' 00:00:00','ms')
        retdict['path'] = path
        retdict['journey'] = journeydict
        journeytimes = journeydict.values()
        try:
            eta = sorted(journeytimes, key=lambda x: x[1], reverse=True)[0][1]
            retdict['eta'] = eta
        except:
            print ('retdict',retdict)
        #print ('retdict',retdict)
        return retdict
    else:
        print (schdict, origin, destination)
        errordict[(origin,destination)] = 'no path'
        return False


# In[ ]:


tcr['journeydict_1'] = [geteta2(loc,dest,ts) for loc,dest,ts in zip(tcr['DEPARTURE_TO_LOC_FRM_CURLOC'].values,tcr['DESTCD'].values,tcr['eta'].values)]


# In[ ]:


tcr['path_1'] = [i.get('path') if i else i for i in tcr.journeydict_1.values]
tcr['eta_1'] = [i.get('eta') if i else i for i in tcr.journeydict_1.values]


# In[ ]:


len(tcr)


# In[ ]:


tcr=tcr[tcr['eta_1']!=False]
len(tcr)


# In[ ]:


def getEta(toloc,dest,eta,eta1):
    if toloc==dest:
        return eta
    else:
        return eta1


# In[ ]:


tcr['Final_ETA']=tcr.apply(lambda x:getEta(x['DEPARTURE_TO_LOC_FRM_CURLOC'],x['DESTCD'],x['eta'],x['eta_1']),axis=1)


# In[ ]:


tcr['eta_1']=pd.to_datetime(tcr['eta_1'])
tcr['Final_ETA']=pd.to_datetime(tcr['Final_ETA'])

# In[ ]:


tcr['neweta']=tcr['Final_ETA'].apply(lambda x: x+timedelta(days=1) if x.hour>12 else x)

tcr['neweta']=tcr['neweta'].apply(lambda x: str(x).split(' ')[0])
# tcr['CDELDT']=tcr['CDELDT'].dt.date
# tcr['CDELDT']=tcr['CDELDT'].astype(str)

tcr['neweta']=pd.to_datetime(tcr['neweta'])

tcr['ETA_Slip']=[1 if eta<=duedate else 0 for eta,duedate in zip(tcr['neweta'],tcr['CDELDT'])]
tcr['Days_Diff']=tcr['neweta']-tcr['CDELDT']
tcr['Days']=tcr['Days_Diff'].apply(lambda x: int(str(x).split(' ')[0]))
greter2dayscons=len(tcr[tcr['Days']>=2])

# In[ ]:


len(tcr[tcr['ETA_Slip']==1])


# In[ ]:


len(tcr)
eta_slipped_consdf=tcr[tcr['ETA_Slip']==0]
eta_slipped_cons=len(tcr[tcr['ETA_Slip']==0])
eta_slipped_cons

# In[ ]:


reached_cons=len(tcr[tcr['ETA_Slip']==1])
total_cons=len(tcr)
reached_cons,total_cons


# In[ ]:


reach_perc=pd.np.round(reached_cons*100.0/total_cons,0)
reach_perc

print (reached_cons,total_cons,reach_perc)


todate=datetime.strftime(datetime.now(),'%Y-%m-%d %H')
todate


# In[ ]:


tcr=tcr.reset_index()


# In[ ]:


def diffhr(curtime,arrvtime):
    diff=curtime-arrvtime
    return pd.np.round(diff.total_seconds()/3600,1)


# In[ ]:


tcr['pu_diff']=tcr.apply(lambda x:diffhr(x['TIME_STAMP'],x['DOCKDT']),axis=1)


# In[ ]:


avghraftpkp=pd.np.ceil(tcr['pu_diff'].sum()*1.0/len(tcr))
avghraftpkp


# In[ ]:


tcr['due_diff']=tcr.apply(lambda x:diffhr(x['CDELDT'],x['TIME_STAMP']),axis=1)


# In[ ]:


avghrduedt=pd.np.ceil(tcr['due_diff'].sum()*1.0/len(tcr))
avghrduedt

mail_summary=tcr.pivot_table(index=['CURR BRANCHCODE','DEPARTURE_TO_LOC_FRM_CURLOC'],aggfunc={'DOCKNO':len,'ETA_Slip':sum,'Wt':sum}).reset_index()
mail_summary['Failed_Cons']=mail_summary['DOCKNO']-mail_summary['ETA_Slip']
mail_summary['Failed%']=pd.np.round(mail_summary['Failed_Cons']*100.0/mail_summary['DOCKNO'],0)
mail_summary.rename(columns={'CURR BRANCHCODE':'DepartLoc','DEPARTURE_TO_LOC_FRM_CURLOC':'thcdest','ETA_Slip':'Reached_Cons'},inplace=True)
mail_summary['Wt(T)']=pd.np.round(mail_summary['Wt']/1000.0,1)
mail_summary=mail_summary[['DepartLoc','thcdest','DOCKNO','Reached_Cons','Failed_Cons','Wt(T)','Failed%']]
mail_summary.sort_values('Failed_Cons',ascending=False,inplace=True)

# In[ ]:


summary=tcr.pivot_table(index=['DEPARTED_FRM_CURRLOC_THCNO','DEPARTED_FRM_CURRLOC_VEHNO','DEPARTED_FRM_CURRLOC_ROUTECD','CURR BRANCHCODE','DEPARTURE_TO_LOC_FRM_CURLOC','DEPARTURE TIME FRM CURLOC','THC_ETA'],
               aggfunc={'DOCKNO':len,'ETA_Slip':sum}).reset_index()


# In[ ]:


summary['Reach%']=pd.np.round(summary['ETA_Slip']*100.0/summary['DOCKNO'])


# In[ ]:


summary.rename(columns={'DEPARTED_FRM_CURRLOC_THCNO':'THCNO','DEPARTED_FRM_CURRLOC_VEHNO':'VehNo','DEPARTED_FRM_CURRLOC_ROUTECD':'RouteCode','CURR BRANCHCODE':'DepartLoc','DEPARTURE_TO_LOC_FRM_CURLOC':'thcdest','DEPARTURE TIME FRM CURLOC':'DepartTime','DOCKNO':'con','ETA_Slip':'Reach'},inplace=True)


# In[ ]:


summary.sort_values('con',ascending=False,inplace=True)


# In[ ]:


summary1=summary[['DepartLoc','thcdest','RouteCode','DepartTime','con','Reach','Reach%']]


failed_df=tcr[tcr['ETA_Slip']==0].pivot_table(index=['DEPARTED_FRM_CURRLOC_THCNO','DEPARTED_FRM_CURRLOC_VEHNO','DEPARTED_FRM_CURRLOC_ROUTECD','CURR BRANCHCODE','DEPARTURE_TO_LOC_FRM_CURLOC','DEPARTURE TIME FRM CURLOC','THC_ETA'],
               aggfunc={'DOCKNO':len,'ETA_Slip':sum,'Wt':sum}).reset_index()
failed_df.rename(columns={'DEPARTED_FRM_CURRLOC_THCNO':'THCNO','DEPARTED_FRM_CURRLOC_VEHNO':'VehNo','DEPARTED_FRM_CURRLOC_ROUTECD':'RouteCode','CURR BRANCHCODE':'DepartLoc','DEPARTURE_TO_LOC_FRM_CURLOC':'thcdest','DEPARTURE TIME FRM CURLOC':'DepartTime','DOCKNO':'con','ETA_Slip':'Reach'},inplace=True)
failed_df['Wt(T)']=pd.np.round(failed_df['Wt']/1000.0,1)
failed_df.sort_values('Wt(T)',ascending=False)[['DepartLoc','thcdest','RouteCode','DepartTime','con','Wt(T)']]
failed_df1=failed_df.head(20)


tcr.to_csv(r'D:\Data\Intransit_New_Report\Intransit'+str(todate)+'.csv')
summary.to_csv(r'D:\Data\Intransit_New_Report\summary'+str(todate)+'.csv')
mail_summary.to_csv(r'D:\Data\Intransit_New_Report\Failed_summary'+str(todate)+'.csv')


tcr.to_csv(r'D:\Data\Intransit_New_Report\Intransit.csv')
summary.to_csv(r'D:\Data\Intransit_New_Report\summary.csv')
mail_summary.to_csv(r'D:\Data\Intransit_New_Report\Failed_summary.csv')

from pandas import ExcelWriter
# writer = pd.ExcelWriter(r'D:\Data\Intransit_New_Report\Intransit'+str(todate)+'.xlsx', engine='xlsxwriter')
# tcr.to_excel(writer,sheet_name='Data',encoding='cp1252')
# mail_summary.to_excel(writer,sheet_name='Failed_Cons',encoding='cp1252')
# summary.to_excel(writer,sheet_name='Reached_Cons',encoding='cp1252')
# writer.save()
# tcr=tcr.set_index("DOCKNO")
# writer = pd.ExcelWriter(r'D:\Data\Intransit_New_Report\Intransit.xlsx', engine='xlsxwriter')
# tcr.to_excel(writer,sheet_name='Data')
# mail_summary.to_excel(writer,sheet_name='Failed_Cons')
# summary.to_excel(writer,sheet_name='Reached_Cons')
# writer.save()

# filepath=r'D:\Data\Intransit_New_Report\Intransit.xlsx'

filepath1=r'D:\Data\Intransit_New_Report\Intransit.csv'
filepath2=r'D:\Data\Intransit_New_Report\summary.csv'
filepath3=r'D:\Data\Intransit_New_Report\Failed_summary.csv'

import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback
for i in [filepath1,filepath2,filepath3]:
    oppath1=i
    #FTP Upload starts
    print ('Logging in...')
    ftp = ftplib.FTP()
    ftp.connect('10.109.230.50')
    print (ftp.getwelcome())
    try:
        try:
            ftp.login('IEPROJECTUSER', 'spotStar@123')
            ftp.cwd('ETA')
            # move to the desired upload directory
            print ("Currently in:", ftp.pwd())
            print ('Uploading...')
            fullname = oppath1
            name = os.path.split(fullname)[1]
            f = open(fullname, "rb")
            ftp.storbinary('STOR ' + name, f)
            f.close()
            print ("OK"  )
            print ("Files:")
            print (ftp.retrlines('LIST'))
        finally:
            print ("Quitting...")
            ftp.quit()
    except:
        traceback.print_exc()

# TO=['vishwas.j@spoton.co.in']
TO=['abhik.mitra@spoton.co.in','jothi.menon@spoton.co.in','pawan.sharma@spoton.co.in','shivananda.p@spoton.co.in','satya.pal@spoton.co.in','HUBMGR_SPOT@spoton.co.in']
CC=['mahesh.reddy@spoton.co.in']
#BCC=['mahesh.reddy@spoton.co.in']
FROM="reports.ie@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "Intransit reach percentage-W" + '-' +todate+ ' is '+ str(reach_perc)+'%'
html3='''
<h5> To download the data , Please click the link below </h5>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Intransit.csv"</a>http://spoton.co.in/downloads/IEProjects/ETA/Intransit.csv</p></b>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/summary.csv"</a>http://spoton.co.in/downloads/IEProjects/ETA/summary.csv</p></b>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Failed_summary.csv"</a>http://spoton.co.in/downloads/IEProjects/ETA/Failed_summary.csv</p></b>


'''
report=""
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='PFA the Intransit reach percentage at '+todate
report+='<br>'
report+='Total cons in Intransit = '+str(totalcons)
report+='<br>'
#report+='Total cons after excluding Deps = '+str(aftremdepscons)
#report+='<br>'
report+='Total expected Intransit Reach% = '+str(reach_perc)+ '%'
report+='<br>'
report+='Total ETA Slipped Cons = '+str(eta_slipped_cons)
report+='<br>'
report+='ETA Slipped Cons >2days = '+str(greter2dayscons)
report+='<br>'
report+='Average Hours after pickup = '+str(avghraftpkp)
report+='<br>'
report+='Average Hours to due date = '+str(avghrduedt)
report+='<br>'

report+='<br>'
#report+='Total cons in urgent status ='+str(len(urgent_cons))
#report+='<br>'
#report+='Total expected Reach % of urgent status cons ='+str(urgnt_perc)+'%'
#report+='<br>'
#report+='Total cons in other status ='+str(reached_cons)
#report+='<br>'
#report+='Total expected Reach % of other status cons ='+str(perce)+'%'
report+='<br>'
report+='<br>'+mail_summary.head(25).to_html()+'<br>'
report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)

# part = MIMEBase('application', "octet-stream")
# part.set_payload( open(filepath1,"rb").read() )
# encoders.encode_base64(part)
# part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
# msg.attach(part)

# part2 = MIMEBase('application', "octet-stream")
# part2.set_payload( open(filepath2,"rb").read() )
# encoders.encode_base64(part2)
# part2.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath2))
# msg.attach(part2)



server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
# server.login('spoton.net.in', 'Star@123#')
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()

cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")

cnxn.autocommit = True
cursor = cnxn.cursor()

# tcr['DOCKNO']=tcr['DOCKNO'].apply(lambda x:x.strip(' '))
# tcr['THC_ETA']=tcr['THC_ETA'].fillna('-')
eta_slipped_consdf=eta_slipped_consdf.reset_index()
eta_slipped_consdf['DOCKNO']=eta_slipped_consdf['DOCKNO'].apply(lambda x:x.strip(' '))
# eta_slipped_cons['THC_ETA']=eta_slipped_cons['THC_ETA'].astype(str)
eta_slipped_consdf['THC_ETA']=eta_slipped_consdf['THC_ETA'].fillna('-')

db_df=eta_slipped_consdf
db_df['ETA']=db_df['neweta']

len(conlist)
db_df=db_df[db_df['ETA']>db_df['ETADATE']]
db_df.rename(columns={'DOCKNO':'Con Number','DESTCD':'DEST','ORIGIN_BRCODE':'ORIGIN','TIME_STAMP':'TIMESTAMP','CURR BRANCHCODE':'HUB_SC','DEPARTURE_TO_LOC_FRM_CURLOC':'NEXT_LOC','DEPARTED_FRM_CURRLOC_THCNO':'THCNO'},inplace=True)
db_df['FLAG']="Intransit"
conlist= db_df['Con Number'].values.tolist()
print (len(db_df))

try:
    for u in range (0,len(conlist)):
        connumber = db_df.iloc[u]['Con Number']
        connumber=str(connumber)
        #print('Con number is ',connumber)
        destbr = db_df.iloc[u]['DEST']
        #print ('destbr',destbr)
        conflag = db_df.iloc[u]['FLAG']
        hubscloc = db_df.iloc[u]['HUB_SC']
        orgbr= db_df.iloc[u]['ORIGIN']
        thceta= db_df.iloc[u]['THC_ETA']
        thcno  = db_df.iloc[u]['THCNO']
        timest  =db_df.iloc[u]['TIMESTAMP']
        etaofcon  = str(db_df.iloc[u]['ETA'])
        nextloc  = db_df.iloc[u]['NEXT_LOC']
        #print ("""INSERT INTO TBLDOCKETETADATA_PYTHON (ConNo, DEST, FLAG, HUB_SC, ORIGIN, THC_ETA, THCNO, TIMESTAMP, ETA, NEXT_LOC) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",(connumber, destbr, conflag, hubscloc, orgbr, thceta, thcno, timest, etaofcon, nextloc))
        
        cursor.execute("""
        INSERT INTO TBLDOCKETETADATA_PYTHON (ConNo, DEST, FLAG, HUB_SC, ORIGIN, THC_ETA, THCNO, TIMESTAMP, ETA, NEXT_LOC) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,(connumber, destbr, conflag, hubscloc, orgbr, thceta, thcno, timest, etaofcon, nextloc))

except:
    TO=['mahesh.reddy@spoton.co.in']
    FROM="mahesh.reddy@spoton.co.in"
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    #msg["CC"] = ",".join(CC)
    #msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "Intransit Data Not Uploaded "+str(len(db_df) )
    report=""
    report+='Hi,'

    report+='<br>'
    report+='Intransit Data Not Uploaded'
    report+='<br>'

    abc=MIMEText(report.encode('utf-8'),'html')
    msg.attach(abc)
    # part = MIMEBase('application', "octet-stream")
    # part.set_payload( open(filepath,"rb").read() )
    # encoders.encode_base64(part)
    # part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
    # msg.attach(part)

    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO, msg.as_string())
    server.quit()


