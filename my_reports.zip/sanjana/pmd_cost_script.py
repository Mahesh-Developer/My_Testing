
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta,datetime
import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
from pandas import ExcelWriter
import os
import smtplib
import ftplib
import traceback
import Utilities
# In[2]:

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()


query=("""SELECT * FROM dbo.tblPUDYestMtdData""")
df=pd.read_sql(query,Utilities.cnxn)

# fullname=r'http://spoton.co.in/downloads/IEProjects/ETA/PMD.csv'
# print ('Logging in...')
# ftp = ftplib.FTP()
# ftp.connect('10.109.230.50')
# print (ftp.getwelcome())
# try:
#     try:
#         ftp.login('IEPROJECTUSER', 'spotStar@123')
#         ftp.cwd('ETA')
#         # move to the desired upload directory
#         print ("Currently in:", ftp.pwd())
#         print ('Uploading...')
#         fullname = fullname
#         name = os.path.split(fullname)[1]
#         f = open(fullname, "rb")
#         ftp.storbinary('STOR ' + name, f)
#         f.close()
#         print ("OK"  )
#         print ("Files:")
#         print (ftp.retrlines('LIST'))
#     finally:
#         print ("Quitting...")
#         ftp.quit()
# except:
#     traceback.print_exc()
#df=pd.read_csv(r'http://spoton.co.in/downloads/PMD/PMD.csv')

#df=pd.read_csv(r'http://spoton.co.in/downloads/PUD_MTD_REPORT.zip')


# In[3]:


print len(df)
print (df.head(5))
print (df.columns)
# In[4]:


def dateconv(date):
    # val=date.split(' ')
    # date1=val[0]+'-'+val[1]+'-'+val[2]
    try:
        dt = datetime.strftime(date, '%d-%b-%Y')
        return dt
    except:
        pass


# In[5]:


df["DATE2"]=df.apply(lambda x: dateconv(x["DATE"]),axis=1)


# In[6]:


def getPUDTYPE(pintype,pudtype2):
    if ((pintype=='STD')& (pudtype2=='STD')):
        return "STD"
    elif ((pintype=='STD')& (pudtype2!='STD')):
        return "Non-STD"
    elif ((pintype=='ODA')):
        return "All"
    else:
        return "Check"
    


# In[7]:


df['PUDTYPES']=df.apply(lambda x: getPUDTYPE(x['PINTYPE'],x['PUDTYPE']),axis=1)


# In[8]:


#df[['PUDTYPES','PUDTYPE2','PINTYPE']].head()


# In[9]:


total_pivot=pd.pivot_table(df,index=['PINTYPE','PUDTYPES'],values=['ACT_WT','COST'],aggfunc={'ACT_WT':sum,'COST':sum},margins=True,margins_name='Total')


# In[10]:


total_pivot


# In[11]:


total_pivot['CPKG']=total_pivot['COST']/total_pivot['ACT_WT']


# In[12]:


total_pivot['COST'] = total_pivot['COST'].apply(lambda x: '{:.2f}'.format(x))
total_pivot['ACT_WT'] = total_pivot['ACT_WT'].apply(lambda x: '{:.2f}'.format(x))
total_pivot['CPKG'] = total_pivot['CPKG'].apply(lambda x: '{:.3f}'.format(x))


# In[13]:


#month to date pivot 
total_pivot['ACT_WT(T)']=((total_pivot['ACT_WT'].astype(float))/1000).astype(int)
total_pivot['COST(Lakhs)']=pd.np.round((total_pivot['COST'].astype(float))/100000,1)

total_pivot


# In[14]:


booking_df=df[df['TYP']=='BKG']


# In[15]:


len(booking_df)


# In[16]:


booking_pivot=pd.pivot_table(booking_df,index=['PINTYPE','PUDTYPES'],values=['ACT_WT','COST'],aggfunc={'ACT_WT':sum,'COST':sum},margins=True,margins_name='Total')


# In[17]:


booking_pivot['CPKG']=booking_pivot['COST']/booking_pivot['ACT_WT']


# In[18]:


booking_pivot['COST'] = booking_pivot['COST'].apply(lambda x: '{:.2f}'.format(x))
booking_pivot['ACT_WT'] = booking_pivot['ACT_WT'].apply(lambda x: '{:.2f}'.format(x))
booking_pivot['CPKG'] = booking_pivot['CPKG'].apply(lambda x: '{:.3f}'.format(x))


# In[19]:


#month to date booking pivot
booking_pivot['ACT_WT(T)']=((booking_pivot['ACT_WT'].astype(float))/1000).astype(int)
booking_pivot['COST(Lakhs)']=pd.np.round((booking_pivot['COST'].astype(float))/100000,1)

booking_pivot


# In[20]:


delivery_df=df[df['TYP']=='DLV']


# In[21]:


len(delivery_df)


# In[22]:


delivery_pivot=pd.pivot_table(delivery_df,index=['PINTYPE','PUDTYPES'],values=['ACT_WT','COST'],aggfunc={'ACT_WT':sum,'COST':sum},margins=True,margins_name='Total')


# In[23]:


delivery_pivot['CPKG']=delivery_pivot['COST']/delivery_pivot['ACT_WT']


# In[24]:


delivery_pivot['COST'] = delivery_pivot['COST'].apply(lambda x: '{:.2f}'.format(x))
delivery_pivot['ACT_WT'] = delivery_pivot['ACT_WT'].apply(lambda x: '{:.2f}'.format(x))
delivery_pivot['CPKG'] = delivery_pivot['CPKG'].apply(lambda x: '{:.3f}'.format(x))
print ('done')

# In[25]:


#month to date delivery pivot
delivery_pivot['ACT_WT2(T)']=((delivery_pivot['ACT_WT2'].astype(float))/1000).astype(int)
delivery_pivot['COST(Lakhs)']=pd.np.round((delivery_pivot['COST2'].astype(float))/100000,1)

delivery_pivot


# In[26]:


# to_date=date.today()-timedelta(1)
# yest_date=datetime.strftime(to_date,'%Y-%m-%d')
# yest_date
to_date=date.today()-timedelta(1)
to_date1=date.today()-timedelta(2)
yest_date=datetime.strftime(to_date,'%Y-%m-%d')
yest_date1=datetime.strftime(to_date1,'%Y-%m-%d')
print (yest_date,yest_date1)


# In[29]:


#yester day operations starts from here
yest_df=df[df['DATE2']==yest_date]
#yest_df=df[df['DATE2']=='2018-02-06']
print ('length of Yesterday data ',yest_df)

# In[30]:
# if (len(yest_df)==0):
#     print ('len is zero')
#     yest_df=df[df['DATE2']==yest_date1]
# else:
#     print ('len is not zero')
#     yest_df=yest_df



# In[31]:


yest_total_pivot=pd.pivot_table(yest_df,index=['PINTYPE','PUDTYPE'],values=['ACT_WT2','COST2'],aggfunc={'ACT_WT2':sum,'COST2':sum},margins=True,margins_name='Total')


# In[32]:


yest_total_pivot['CPKG']=yest_total_pivot['COST2']/yest_total_pivot['ACT_WT2']


# In[33]:


yest_total_pivot['COST2'] = yest_total_pivot['COST2'].apply(lambda x: '{:.2f}'.format(x))
yest_total_pivot['ACT_WT2'] = yest_total_pivot['ACT_WT2'].apply(lambda x: '{:.2f}'.format(x))
yest_total_pivot['CPKG'] = yest_total_pivot['CPKG'].apply(lambda x: '{:.3f}'.format(x))


# In[34]:


#yester day total pivot
yest_total_pivot['ACT_WT2(T)']=((yest_total_pivot['ACT_WT2'].astype(float))/1000).astype(int)
yest_total_pivot['COST(Lakhs)']=pd.np.round((yest_total_pivot['COST2'].astype(float))/100000,1)

yest_total_pivot


# In[35]:


yest_bkng_df=yest_df[yest_df['TYP2']=='BKG']


# In[36]:


len(yest_bkng_df)


# In[37]:


pivot_yest_bkng_df=pd.pivot_table(yest_bkng_df,index=['PINTYPE','PUDTYPE'],values=['ACT_WT2','COST2'],aggfunc={'ACT_WT2':sum,'COST2':sum},margins=True,margins_name='Total')


# In[38]:


pivot_yest_bkng_df['CPKG']=pivot_yest_bkng_df['COST2']/pivot_yest_bkng_df['ACT_WT2']


# In[39]:


pivot_yest_bkng_df['COST2'] = pivot_yest_bkng_df['COST2'].apply(lambda x: '{:.2f}'.format(x))
pivot_yest_bkng_df['ACT_WT2'] = pivot_yest_bkng_df['ACT_WT2'].apply(lambda x: '{:.2f}'.format(x))
pivot_yest_bkng_df['CPKG'] = pivot_yest_bkng_df['CPKG'].apply(lambda x: '{:.3f}'.format(x))


# In[40]:


#yester day booking pivot
pivot_yest_bkng_df['ACT_WT2(T)']=((pivot_yest_bkng_df['ACT_WT2'].astype(float))/1000).astype(int)
pivot_yest_bkng_df['COST(Lakhs)']=pd.np.round((pivot_yest_bkng_df['COST2'].astype(float))/100000,1)

pivot_yest_bkng_df


# In[41]:


yest_dlry_df=yest_df[yest_df['TYP2']=='DLV']


# In[42]:


len(yest_dlry_df)


# In[43]:


pivot_yest_dlry_df=pd.pivot_table(yest_dlry_df,index=['PINTYPE','PUDTYPE'],values=['ACT_WT2','COST2'],aggfunc={'ACT_WT2':sum,'COST2':sum},margins=True,margins_name='Total')


# In[44]:


pivot_yest_dlry_df['CPKG']=pivot_yest_dlry_df['COST2']/pivot_yest_dlry_df['ACT_WT2']


# In[45]:


pivot_yest_dlry_df['COST2'] = pivot_yest_dlry_df['COST2'].apply(lambda x: '{:.2f}'.format(x))
pivot_yest_dlry_df['ACT_WT2'] =pivot_yest_dlry_df['ACT_WT2'].apply(lambda x: '{:.2f}'.format(x))
pivot_yest_dlry_df['CPKG'] = pivot_yest_dlry_df['CPKG'].apply(lambda x: '{:.3f}'.format(x))


# In[46]:


pivot_yest_dlry_df['ACT_WT2(T)']=((pivot_yest_dlry_df['ACT_WT2'].astype(float))/1000).astype(int)
pivot_yest_dlry_df['COST(Lakhs)']=pd.np.round((pivot_yest_dlry_df['COST2'].astype(float))/100000,1)


# In[47]:


#yester day delivery pivot
pivot_yest_dlry_df


# In[48]:
today=date.today()
firstday=today.replace(day=1)

lastmnth_lastdate1=firstday-timedelta(1)
lastmnth_lastdate2=firstday-timedelta(2)
lastmnth_lastdate1

lastdate1=datetime.strftime(lastmnth_lastdate1,"%Y-%m-%d")
lastdate2=datetime.strftime(lastmnth_lastdate2,"%Y-%m-%d")

print (lastdate1,lastdate2)

#previous month operations starts from here
#previous_df=pd.read_csv(r'D:\Data\PMD_Save\PMD_2018-01-31.csv')

try:
    previous_df=pd.read_csv(r'D:\Data\PMD_Save\PMD_'+str(lastdate1)+'.csv')
except:
    previous_df=pd.read_csv(r'D:\Data\PMD_Save\PMD_'+str(lastdate2)+'.csv')

# In[49]:


previous_df['PUDTYPE']=previous_df.apply(lambda x: getPUDTYPE(x['PINTYPE'],x['PUDTYPE2']),axis=1)


# In[50]:


len(previous_df)


# In[51]:


previous_pivot=pd.pivot_table(previous_df,index=['PINTYPE','PUDTYPE'],values=['ACT_WT2','COST2'],aggfunc={'ACT_WT2':sum,'COST2':sum},margins=True,margins_name='Total')


# In[52]:


previous_pivot['CPKG']=previous_pivot['COST2']/previous_pivot['ACT_WT2']


# In[53]:


previous_pivot['COST2'] = previous_pivot['COST2'].apply(lambda x: '{:.2f}'.format(x))
previous_pivot['ACT_WT2'] = previous_pivot['ACT_WT2'].apply(lambda x: '{:.2f}'.format(x))
previous_pivot['CPKG'] = previous_pivot['CPKG'].apply(lambda x: '{:.3f}'.format(x))


# In[54]:


#previous month total pivot
previous_pivot['ACT_WT2(T)']=((previous_pivot['ACT_WT2'].astype(float))/1000).astype(int)
previous_pivot['COST(Lakhs)']=pd.np.round((previous_pivot['COST2'].astype(float))/100000,1)
previous_pivot


# In[55]:


prevs_mnth_bkng_df=previous_df[previous_df['TYP2']=='BKG']


# In[56]:


len(prevs_mnth_bkng_df)


# In[57]:


pivot_prevs_mnth_bkng_df=pd.pivot_table(prevs_mnth_bkng_df,index=['PINTYPE','PUDTYPE'],values=['ACT_WT2','COST2'],aggfunc={'ACT_WT2':sum,'COST2':sum},margins=True,margins_name='Total')


# In[58]:


pivot_prevs_mnth_bkng_df['CPKG']=pivot_prevs_mnth_bkng_df['COST2']/pivot_prevs_mnth_bkng_df['ACT_WT2']


# In[59]:


pivot_prevs_mnth_bkng_df['COST2'] = pivot_prevs_mnth_bkng_df['COST2'].apply(lambda x: '{:.2f}'.format(x))
pivot_prevs_mnth_bkng_df['ACT_WT2'] = pivot_prevs_mnth_bkng_df['ACT_WT2'].apply(lambda x: '{:.2f}'.format(x))
pivot_prevs_mnth_bkng_df['CPKG'] = pivot_prevs_mnth_bkng_df['CPKG'].apply(lambda x: '{:.3f}'.format(x))


# In[60]:


#previous month booking pivot data
pivot_prevs_mnth_bkng_df['ACT_WT2(T)']=((pivot_prevs_mnth_bkng_df['ACT_WT2'].astype(float))/1000).astype(int)
pivot_prevs_mnth_bkng_df['COST(Lakhs)']=pd.np.round((pivot_prevs_mnth_bkng_df['COST2'].astype(float))/100000,1)
pivot_prevs_mnth_bkng_df


# In[61]:


prevs_mnth_dlry_df=previous_df[previous_df['TYP2']=='DLV']


# In[62]:


len(prevs_mnth_dlry_df)


# In[63]:


pivot_prevs_mnth_dlry_df=pd.pivot_table(prevs_mnth_dlry_df,index=['PINTYPE','PUDTYPE'],values=['ACT_WT2','COST2'],aggfunc={'ACT_WT2':sum,'COST2':sum},margins=True,margins_name='Total')


# In[64]:


pivot_prevs_mnth_dlry_df['CPKG']=pivot_prevs_mnth_dlry_df['COST2']/pivot_prevs_mnth_dlry_df['ACT_WT2']


# In[65]:


pivot_prevs_mnth_dlry_df['COST2'] = pivot_prevs_mnth_dlry_df['COST2'].apply(lambda x: '{:.2f}'.format(x))
pivot_prevs_mnth_dlry_df['ACT_WT2'] = pivot_prevs_mnth_dlry_df['ACT_WT2'].apply(lambda x: '{:.2f}'.format(x))
pivot_prevs_mnth_dlry_df['CPKG'] = pivot_prevs_mnth_dlry_df['CPKG'].apply(lambda x: '{:.3f}'.format(x))


# In[66]:


#previous month delivery pivot data
pivot_prevs_mnth_dlry_df['ACT_WT2(T)']=((pivot_prevs_mnth_dlry_df['ACT_WT2'].astype(float))/1000).astype(int)
pivot_prevs_mnth_dlry_df['COST(Lakhs)']=pd.np.round((pivot_prevs_mnth_dlry_df['COST2'].astype(float))/100000,1)

pivot_prevs_mnth_dlry_df


# In[67]:


pivot_prevs_mnth_dlry_df.columns = [''.join(col).strip() for col in pivot_prevs_mnth_dlry_df.columns.values]


# In[68]:


pivot_prevs_mnth_dlry_df1=pivot_prevs_mnth_dlry_df.reset_index()


# In[69]:


total_pivot.columns = [''.join(col).strip() for col in total_pivot.columns.values]


# In[70]:


total_pivot1=total_pivot.reset_index()


# In[71]:


yest_total_pivot.columns = [''.join(col).strip() for col in yest_total_pivot.columns.values]


# In[72]:


yest_total_pivot1=yest_total_pivot.reset_index()


# In[73]:


previous_pivot.columns = [''.join(col).strip() for col in previous_pivot.columns.values]


# In[74]:


previous_pivot1=previous_pivot.reset_index()


# In[75]:


#merging month to date with yester day
pivot_mnth_yest_df=pd.merge(total_pivot1,yest_total_pivot1,on=['PINTYPE','PUDTYPE'],suffixes=('-MTD','-YST'))


# In[76]:


pivot_mnth_yest_df


# In[77]:


pivot_prvs_mnth_yest_df=pd.merge(pivot_mnth_yest_df,previous_pivot1,on=['PINTYPE','PUDTYPE'])


# In[78]:


# mnth=date.today()-timedelta(30)
current_mnth=datetime.strftime(lastmnth_lastdate1,'%b')
print (current_mnth)


# In[79]:

#print (pivot_prvs_mnth_yest_df.columns)
#this is final pivot for total (with BKG & DLV)
pivot_prvs_mnth_yest_df.rename(columns={'ACT_WT2':'ACT_WT2_'+current_mnth,'COST2':'COST2_'+current_mnth,'ACT_WT2(T)':'ACT_WT2(T)_'+current_mnth,'COST(Lakhs)':'COST(Lakhs)-'+current_mnth,'CPKG':'CPKG-'+current_mnth},inplace=True)
#print ('%%%%%%%%%%%%%%%%%%%%')

# In[80]:


#print (pivot_prvs_mnth_yest_df.columns)


# In[81]:


pivot_prvs_mnth_yest_df1=pivot_prvs_mnth_yest_df[['PINTYPE','PUDTYPE','COST(Lakhs)-YST','CPKG-YST','COST(Lakhs)-MTD','CPKG-MTD','COST(Lakhs)-'+current_mnth,'CPKG-'+current_mnth]]


# In[82]:


#total wise pivot data
pivot_prvs_mnth_yest_df1


# In[83]:


booking_pivot.columns = [''.join(col).strip() for col in booking_pivot.columns.values]


# In[84]:


booking_pivot1=booking_pivot.reset_index()


# In[85]:


pivot_yest_bkng_df.columns = [''.join(col).strip() for col in pivot_yest_bkng_df.columns.values]


# In[86]:


pivot_yest_bkng_df1=pivot_yest_bkng_df.reset_index()


# In[87]:


pivot_prevs_mnth_bkng_df.columns = [''.join(col).strip() for col in pivot_prevs_mnth_bkng_df.columns.values]


# In[88]:


pivot_prevs_mnth_bkng_df1=pivot_prevs_mnth_bkng_df.reset_index()


# In[89]:


pivot_bkng_mtd_yest_df=pd.merge(booking_pivot1,pivot_yest_bkng_df1,on=['PINTYPE','PUDTYPE'],suffixes=('-MTD','-YST'))


# In[90]:


pivot_bkng_prvs_mtd_yest_df=pd.merge(pivot_bkng_mtd_yest_df,pivot_prevs_mnth_bkng_df1,on=['PINTYPE','PUDTYPE'])


# In[91]:


#this is final pivot for BKG
pivot_bkng_prvs_mtd_yest_df.rename(columns={'ACT_WT2':'ACT_WT2_'+current_mnth,'COST2':'COST2_'+current_mnth,'ACT_WT2(T)':'ACT_WT2(T)_'+current_mnth,'COST(Lakhs)':'COST(Lakhs)-'+current_mnth,'CPKG':'CPKG-'+current_mnth},inplace=True)


# In[92]:


pivot_bkng_prvs_mtd_yest_df1=pivot_bkng_prvs_mtd_yest_df[['PINTYPE','PUDTYPE','COST(Lakhs)-YST','CPKG-YST','COST(Lakhs)-MTD','CPKG-MTD','COST(Lakhs)-'+current_mnth,'CPKG-'+current_mnth]]


# In[93]:


pivot_bkng_prvs_mtd_yest_df1


# In[94]:


delivery_pivot.columns = [''.join(col).strip() for col in delivery_pivot.columns.values]


# In[95]:


delivery_pivot1=delivery_pivot.reset_index()


# In[96]:


pivot_yest_dlry_df.columns = [''.join(col).strip() for col in pivot_yest_dlry_df.columns.values]


# In[97]:


pivot_yest_dlry_df1=pivot_yest_dlry_df.reset_index()


# In[98]:


pivot_prevs_mnth_dlry_df.columns = [''.join(col).strip() for col in pivot_prevs_mnth_dlry_df.columns.values]


# In[99]:


pivot_prevs_mnth_dlry_df1=pivot_prevs_mnth_dlry_df.reset_index()


# In[100]:


pivot_dlry_mtd_yest_df=pd.merge(delivery_pivot1,pivot_yest_dlry_df1,on=['PINTYPE','PUDTYPE'],suffixes=('-MTD','-YST'))


# In[101]:


pivot_prvs_mtd_yest_df=pd.merge(pivot_dlry_mtd_yest_df,pivot_prevs_mnth_dlry_df1,on=['PINTYPE','PUDTYPE'])


# In[102]:


#this is final pivot for DLV
pivot_prvs_mtd_yest_df.rename(columns={'ACT_WT2':'ACT_WT2_'+current_mnth,'COST2':'COST2_'+current_mnth,'ACT_WT2(T)':'ACT_WT2(T)_'+current_mnth,'COST(Lakhs)':'COST(Lakhs)-'+current_mnth,'CPKG':'CPKG-'+current_mnth},inplace=True)


# In[103]:


pivot_prvs_mtd_yest_df1=pivot_prvs_mtd_yest_df[['PINTYPE','PUDTYPE','COST(Lakhs)-YST','CPKG-YST','COST(Lakhs)-MTD','CPKG-MTD','COST(Lakhs)-'+current_mnth,'CPKG-'+current_mnth]]


# In[104]:


pivot_prvs_mtd_yest_df1


# In[105]:


from pandas import ExcelWriter
with ExcelWriter(r'C:\Users\rajeeshv\Downloads\Rajesh\mahesh\Cost Monitoring Reports\Cost_Monitoring_Report.xlsx') as writer:
    pivot_prvs_mnth_yest_df1.to_excel(writer,engine='xlsxwriter',sheet_name='Cost with BKG&DLV')
    pivot_bkng_prvs_mtd_yest_df1.to_excel(writer,engine='xlsxwriter',sheet_name='Cost with BKG')
    pivot_prvs_mtd_yest_df1.to_excel(writer,engine='xlsxwriter',sheet_name='Cost with DLV')


# In[109]:


filepath=r'C:\Users\rajeeshv\Downloads\Rajesh\mahesh\Cost Monitoring Reports\Cost_Monitoring_Report.xlsx'


# In[111]:


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template
#vishwas.j@spoton.co.in
TO=['vishwas.j@spoton.co.in']
#TO=['mahesh.reddy@spoton.co.in','vishwas.j@spoton.co.in']
FROM='vishwas.j@spoton.co.in'
CC=['mahesh.reddy@spoton.co.in','vishwas.j@spoton.co.in']
#CC=["mahesh.reddy@spoton.co.in"]
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "Monitoring Report" + " - " + str(yest_date)
html='''<html>
<h4>Dear All,</h4>
<p>PFA the Monitoring Report for $date</p>
</html>'''
s = Template(html).safe_substitute(date=yest_date)
report=""
report+=s
report+='<br>'
report+='Cost summary including Booking and Delivery - Yesterday, MTD and Previous month'
report+='<br>'
report+='<br>'+pivot_prvs_mnth_yest_df1.to_html()+'<br>'
report+='<br>'
report+='Cost summary Booking - Yesterday, MTD and Previous month'
report+='<br>'
report+='<br>'+pivot_bkng_prvs_mtd_yest_df1.to_html()+'<br>'
report+='<br>'
report+='Cost summary Delivery - Yesterday, MTD and Previous month'
report+='<br>'
report+='<br>'+pivot_prvs_mtd_yest_df1.to_html()+'<br>'
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
#failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()

