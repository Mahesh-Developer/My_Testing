
# coding: utf-8

# In[1]:

import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta,datetime
import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
from pandas import ExcelWriter
import os
import smtplib
import ftplib
import traceback
import calendar
from time import strptime
import Utilities
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os

#import sys
# reload(sys)
# sys.setdefaultencoding('utf8')
# In[2]:

#try:
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


# In[3]:

query=("""EXEC USP_PUD_YEST_MTD_DATA 'M' """)


# In[4]:
#df=pd.read_csv(r'D:\Data\PMD_Save\DepotWise Data & Summaries\PMD_2018-08-31.csv')
df=pd.read_sql(query,Utilities.cnxn)
df=df[df['PTYPE']!='AR']
print (df.dtypes)


# In[5]:

print (len(df))
#df.to_csv(r'PMD_Pro_Data.csv')
# In[6]:

m = {'Jan': '01','Feb': '02','Mar': '03','Apr':'04','May':'05','Jun':'06','Jul':'07','Aug':'08','Sep':'09','Oct':'10','Nov':'11','Dec':'12'}


# In[7]:

def dateconv(date):
    dt = date.split(' ')[2]+'-'+str(m.get(date.split(' ')[1]))+'-'+date.split(' ')[0]
    #print (dt)
    return dt


# In[8]:

df["DateOnly"]=df.apply(lambda x: dateconv(x["DATE"]),axis=1)


# In[9]:

fixed_df=df[df['PUDTYPE']=='FIXED']


# In[10]:

fixed_df[(fixed_df['BRANCH_CODE']=='DELC') & (fixed_df['BAVEHNO']=='DL01LAA5647')][['DEPOT','BAVEHNO','BAVEHCAP']]


# In[11]:

len(fixed_df)


# In[12]:

veh_master_df=pd.read_excel(r'C:\Users\rajeeshv\Downloads\fix-vendor master-Mahesh.xlsx')


# In[13]:

#veh_master_df.rename(columns={'BRN CODE':'BRANCH_CODE'},inplace=True)
veh_master_df.rename(columns={'BRAN':'BRANCH_CODE','BAVEHCAP':'VEH CAP'},inplace=True)


# In[14]:

fixed_df=pd.merge(fixed_df,veh_master_df,on=['BRANCH_CODE','BAVEHNO'])


# In[15]:

#fixed_df[fixed_df['BAVEHNO']=='DL01LAA5647'][['DEPOT','BAVEHNO','VEH CAP']]


# In[16]:

fixed_df=fixed_df[fixed_df['BAVEHNO']!='TVS000001']


# In[17]:

#fixed_df[fixed_df['VEH CAP'].isnull()][['DEPOT','BRANCH_CODE','BAVEHNO','VEH CAP']]


# In[18]:

#fixed df pivot
fixed_pivot=pd.pivot_table(fixed_df,index=['DateOnly','DEPOT','AREA','BRANCH_CODE','BAVEHNO','VEH CAP'],
                           values=['con_id','ACT_WT','VOLUME','COST'],
                           aggfunc={"con_id":len,'ACT_WT':sum,'VOLUME':sum,'COST':sum}).reset_index()


# In[19]:

#fixed_pivot['VEH CAP']=fixed_pivot['VEH CAP'].replace('-',0)


# In[20]:

fixed_pivot['VEH CAP']=fixed_pivot['VEH CAP'].astype(float)


# In[21]:

#getting max value from veh capacity
final_fixed_df_pivot=pd.pivot_table(fixed_pivot,index=['DateOnly','DEPOT','AREA','BRANCH_CODE','BAVEHNO'],
                                    values=['VEH CAP','con_id','ACT_WT','VOLUME','COST'],
                                    aggfunc={'VEH CAP':max,'ACT_WT':sum,'con_id':sum,'VOLUME':sum,'COST':sum}).reset_index()


# In[22]:

final_fixed_df_pivot['ACT_WT(T)']=pd.np.round(final_fixed_df_pivot['ACT_WT']/1000.0,2)


# In[23]:

final_fixed_df_pivot['Wt-Util%']=pd.np.round(final_fixed_df_pivot['ACT_WT(T)']*100.0/final_fixed_df_pivot['VEH CAP'],2)


# In[24]:

final_fixed_df_pivot1=final_fixed_df_pivot.replace([-np.inf,np.inf],np.nan).fillna(0)


# In[25]:

vehicle_summary=final_fixed_df_pivot1.pivot_table(index=['DateOnly','DEPOT','BRANCH_CODE','BAVEHNO'],
                                 values=['VEH CAP','con_id','COST','ACT_WT'],
                                 aggfunc={'VEH CAP':sum,'con_id':sum,'COST':sum,'ACT_WT':sum})


# In[26]:

vehicle_summary=vehicle_summary.reset_index()


# In[27]:

vehicle_summary['Wt_Util%']=pd.np.round(vehicle_summary['ACT_WT']*100.0/vehicle_summary['VEH CAP'],1)


# In[28]:

vehicle_summary


# In[29]:
#yest_date='2018-07-31'
yest_date=datetime.strftime(datetime.now()-timedelta(1),'%Y-%m-%d')
yest_date


# # YesterDay summary for Fixed

# In[30]:

#Yesterday summary for fixed
yest_df=final_fixed_df_pivot1[final_fixed_df_pivot1['DateOnly']==yest_date]


# In[31]:

yest_df['Type']='YST'


# In[32]:

len(yest_df)


# In[33]:

#depot and branch wise fixed summary
yest_summary=pd.pivot_table(yest_df,index=['DEPOT','BRANCH_CODE'],values=['BAVEHNO','VEH CAP','con_id','ACT_WT','VOLUME','COST'],
                            aggfunc={'BAVEHNO':len,'VEH CAP':sum,'ACT_WT':sum,'con_id':sum,'VOLUME':sum,'COST':sum}).reset_index()


# In[34]:

yest_summary['CPKG']=pd.np.round(yest_summary['COST']/yest_summary['ACT_WT'],1)


# In[35]:

yest_summary['ACT_WT(T)']=pd.np.round(yest_summary['ACT_WT']/1000.0,1)
yest_summary['VEH CAP(T)']=pd.np.round(yest_summary['VEH CAP']/1000.0,1)


# In[36]:

yest_summary['Wt_Util%']=pd.np.round(yest_summary['ACT_WT(T)']*100.0/yest_summary['VEH CAP(T)'],1)


# In[37]:

yest_summary=yest_summary.replace([np.inf,-np.inf],np.nan).fillna(0)


# In[38]:

yest_summary['Wt_Util%']=pd.np.round(yest_summary['Wt_Util%'],1)


# In[39]:

yest_summary.rename(columns={'VEH CAP':'CAPACITY','BAVEHNO':'NO.of Veh','con_id':'Cons','VEH CAP(T)':'CAPACITY(T)',
                             'ACT_WT(T)':'Wt(T)','ACT_WT':'Wt'},inplace=True)


# In[40]:

yest_summary.head()


# # MTD Summary for Fixed

# In[41]:

final_fixed_df_pivot1['Type']='MTD'


# In[42]:

mtd_summary=pd.pivot_table(final_fixed_df_pivot1,index=['DEPOT','BRANCH_CODE'],
                           values=['BAVEHNO','VEH CAP','con_id','ACT_WT','VOLUME','COST'],
                           aggfunc={'BAVEHNO':lambda x:len(x.unique()),'VEH CAP':sum,'ACT_WT':sum,'con_id':sum,'VOLUME':sum,'COST':sum}).reset_index()


# In[43]:

#mtd_summary
mtd_summary['CPKG']=pd.np.round(mtd_summary['COST']/mtd_summary['ACT_WT'],1)


# In[44]:

mtd_summary['ACT_WT(T)']=pd.np.round(mtd_summary['ACT_WT']/1000.0,1)


# In[45]:

mtd_summary['VEH CAP(T)']=pd.np.round(mtd_summary['VEH CAP']/1000.0,1)


# In[46]:

mtd_summary['Wt_Util%']=pd.np.round(mtd_summary['ACT_WT(T)']*100.0/mtd_summary['VEH CAP(T)'],1)


# In[47]:

mtd_summary.rename(columns={'VEH CAP':'CAPACITY','BAVEHNO':'NO.of Veh','con_id':'Cons','VEH CAP(T)':'CAPACITY(T)',
                             'ACT_WT(T)':'Wt(T)','ACT_WT':'Wt'},inplace=True)


# In[48]:

mtd_summary.head()


# In[49]:

final_summary=pd.concat([final_fixed_df_pivot1,yest_df],ignore_index=True)


# In[50]:

def getType(d):
    if d==yest_date:
        return "YST"
    else:
        return "MTD"


# In[51]:

#final_fixed_df_pivot1['Type']=final_fixed_df_pivot1.apply(lambda x:getType(x['DateOnly']),axis=1)


# In[52]:

final_fixed_summary=pd.pivot_table(final_summary,index=['DEPOT'],columns=['Type'],
                                   values=['BAVEHNO','VEH CAP','con_id','ACT_WT','COST'],
                                   aggfunc={'BAVEHNO':lambda x:len(x.unique()),'VEH CAP':sum,'ACT_WT':sum,'con_id':sum,'COST':sum}).reset_index()


# In[53]:

final_fixed_summary['ACT_WT(T)','YST']=pd.np.round(final_fixed_summary['ACT_WT','YST']/1000.0,1)


# In[54]:

final_fixed_summary['ACT_WT(T)','MTD']=pd.np.round(final_fixed_summary['ACT_WT','MTD']/1000.0,1)


# In[55]:

#final_fixed_summary['COST(L)','YST']=pd.np.round(final_fixed_summary['COST','YST']/100000.0,2)
final_fixed_summary['COST','YST']=pd.np.round(final_fixed_summary['COST','YST'],0)

# In[56]:

final_fixed_summary['COST','MTD']=pd.np.round(final_fixed_summary['COST','MTD'],0)


# In[57]:

final_fixed_summary['VEH CAP(T)','MTD']=pd.np.round(final_fixed_summary['VEH CAP','MTD']/1000.0,1)


# In[58]:

final_fixed_summary['VEH CAP(T)','YST']=pd.np.round(final_fixed_summary['VEH CAP','YST']/1000.0,1)


# In[59]:

final_fixed_summary['Wt_Util%','YST']=pd.np.round(final_fixed_summary['ACT_WT(T)','YST']*100.0/final_fixed_summary['VEH CAP(T)','YST'],1)


# In[60]:

final_fixed_summary['Wt_Util%','MTD']=pd.np.round(final_fixed_summary['ACT_WT(T)','MTD']*100.0/final_fixed_summary['VEH CAP(T)','MTD'],1)


# In[61]:

#final_fixed_summary1=final_fixed_summary[['DEPOT','ACT_WT(T)','COST(L)','Wt_Util%','con_id','VEH CAP(T)','BAVEHNO']]
final_fixed_summary1=final_fixed_summary[['DEPOT','ACT_WT(T)','COST','Wt_Util%','con_id','VEH CAP(T)','BAVEHNO']]


# In[62]:

final_fixed_summary1=final_fixed_summary1.fillna(0)


# In[63]:

final_fixed_summary1.rename(columns={'con_id':'CONS','ACT_WT(T)':'WT(T)','VEH CAP(T)':'CAPACITY(T)','BAVEHNO':'NO.of Veh'},inplace=True)


# In[64]:

#final_fixed_summary2=final_fixed_summary1[['DEPOT','CONS','WT(T)','CAPACITY(T)','NO.of Veh','COST(L)','Wt_Util%']]
final_fixed_summary2=final_fixed_summary1[['DEPOT','CONS','WT(T)','CAPACITY(T)','NO.of Veh','COST','Wt_Util%']]


# In[65]:

final_fixed_summary2['Wt_Util%','YST']=pd.np.round(final_fixed_summary2['Wt_Util%','YST'],1)


# In[66]:

# final_fixed_summary2=final_fixed_summary2[[('DEPOT',''),('CONS','YST'),('CONS','MTD'),('WT(T)','YST'),('WT(T)','MTD'),
#                                            ('COST(L)','YST'),('COST(L)','MTD'),('CAPACITY(T)','YST'),('CAPACITY(T)','MTD'),
#                                           ('NO.of Veh','YST'),('NO.of Veh','MTD'),('Wt_Util%','YST'),
#                                            ('Wt_Util%','MTD') ]]
final_fixed_summary2=final_fixed_summary2[[('DEPOT',''),('CONS','YST'),('CONS','MTD'),('WT(T)','YST'),('WT(T)','MTD'),
                                           ('COST','YST'),('COST','MTD'),('CAPACITY(T)','YST'),('CAPACITY(T)','MTD'),
                                          ('NO.of Veh','YST'),('NO.of Veh','MTD'),('Wt_Util%','YST'),
                                           ('Wt_Util%','MTD') ]]


# In[67]:

#Adhoc
adhoc_df=df[df['PUDTYPE']=='ADHOC-Special']
len(adhoc_df)


# In[68]:

adhoc_df1=adhoc_df[adhoc_df['MKT_SBA_AMT']>0]


# In[69]:

len(adhoc_df1)


# In[70]:

adhoc_pivot=pd.pivot_table(adhoc_df1,index=['DateOnly','DEPOT','AREA','BRANCH_CODE'],values=['con_id','ACT_WT','VOLUME','COST','MKT_SBA_AMT'],aggfunc={"con_id":len,'ACT_WT':sum,'VOLUME':sum,'COST':sum,'MKT_SBA_AMT':sum}).reset_index()


# # YesterDay summary for ADHOC SBA

# In[71]:

yest_adhoc_summary=adhoc_pivot[adhoc_pivot['DateOnly']==yest_date]
len(yest_adhoc_summary)


# In[72]:

yest_adhoc_summary=pd.pivot_table(yest_adhoc_summary,index=['DEPOT','BRANCH_CODE'],values=['con_id','ACT_WT','VOLUME','COST','MKT_SBA_AMT'],aggfunc={'MKT_SBA_AMT':sum,'ACT_WT':sum,'con_id':sum,'VOLUME':sum,'COST':sum}).reset_index()


# In[73]:

try:
    yest_adhoc_summary['CPKG']=pd.np.round(yest_adhoc_summary['COST']/yest_adhoc_summary['ACT_WT'],1)
except:
    yest_adhoc_summary['CPKG']=0.0


# In[74]:

#yest_adhoc_summary.rename(columns={'ACT_WT':'Wt','con_id':'Cons'},inplace=True)


# In[75]:

yest_adhoc_summary.head()


# # MTD summary for ADHOC SBA

# In[76]:

yest_adhoc_summary['Type']='YST'


# In[77]:

adhoc_mtd_summary=pd.pivot_table(adhoc_pivot,index=['DEPOT','BRANCH_CODE'],values=['con_id','ACT_WT','VOLUME','COST','MKT_SBA_AMT'],aggfunc={'ACT_WT':sum,'con_id':sum,'VOLUME':sum,'COST':sum,'MKT_SBA_AMT':sum}).reset_index()


# In[78]:

adhoc_pivot['Type']='MTD'


# In[79]:

#adhoc_pivot['Type']=adhoc_pivot.apply(lambda x:getType(x['DateOnly']),axis=1)
final_adhoc_df=pd.concat([adhoc_pivot,yest_adhoc_summary],ignore_index=True)


# In[80]:

final_adhoc_summary=pd.pivot_table(final_adhoc_df,index=['DEPOT'],columns=['Type'],values=['con_id','ACT_WT','COST','MKT_SBA_AMT'],aggfunc={'ACT_WT':sum,'con_id':sum,'COST':sum,'MKT_SBA_AMT':sum}).reset_index()


# In[81]:

try:
    final_adhoc_summary['ACT_WT(T)','YST']=pd.np.round(final_adhoc_summary['ACT_WT','YST']/1000.0,1)
except:
    final_adhoc_summary['ACT_WT(T)','YST']=0.0


# In[82]:

final_adhoc_summary['ACT_WT(T)','MTD']=pd.np.round(final_adhoc_summary['ACT_WT','MTD']/1000.0,1)


# In[ ]:

# try:
#     final_adhoc_summary['COST(L)','YST']=pd.np.round(final_adhoc_summary['COST','YST']/100000.0,2)
# except:
#     final_adhoc_summary['COST(L)','YST']=0.0


# In[ ]:

# try:
#     final_adhoc_summary['MKT_SBA_AMT(L)','YST']=pd.np.round(final_adhoc_summary['MKT_SBA_AMT','YST']/100000.0,2)
# except:
#     final_adhoc_summary['MKT_SBA_AMT(L)','YST']=0.0


# In[ ]:

# final_adhoc_summary['MKT_SBA_AMT(L)','MTD']=pd.np.round(final_adhoc_summary['MKT_SBA_AMT','MTD']/100000.0,2)


# In[ ]:

# final_adhoc_summary['COST(L)','MTD']=pd.np.round(final_adhoc_summary['COST','MTD']/100000.0,2)


# In[83]:

#final_adhoc_summary['CPKG','YST']=pd.np.round(final_adhoc_summary['COST(L)','YST']/final_adhoc_summary['ACT_WT(T)','YST'],1)
final_adhoc_summary['CPKG','YST']=pd.np.round(final_adhoc_summary['COST','YST']/final_adhoc_summary['ACT_WT(T)','YST'],1)


# In[84]:

#final_adhoc_summary['CPKG','MTD']=pd.np.round(final_adhoc_summary['COST(L)','MTD']/final_adhoc_summary['ACT_WT(T)','MTD'],1)
final_adhoc_summary['CPKG','MTD']=pd.np.round(final_adhoc_summary['COST','MTD']/final_adhoc_summary['ACT_WT(T)','MTD'],1)


# In[85]:

#final_adhoc_summary1=final_adhoc_summary[['DEPOT','con_id','ACT_WT(T)','COST(L)','MKT_SBA_AMT(L)','CPKG']]
final_adhoc_summary1=final_adhoc_summary[['DEPOT','con_id','ACT_WT(T)','COST','MKT_SBA_AMT','CPKG']]


# In[86]:

final_adhoc_summary1=final_adhoc_summary1.fillna(0)


# In[87]:

final_adhoc_summary1.rename(columns={'con_id':'Cons','ACT_WT(T)':'Wt(T)'},inplace=True)


# In[88]:

final_adhoc_summary1['Cons']=final_adhoc_summary1['Cons'].astype(int)


# In[89]:

final_adhoc_summary1


# In[ ]:

# if ('Cons', 'YST') in final_adhoc_summary1.columns.values:
#     print ('yes')
# else:
#     final_adhoc_summary1['Cons','YST']=0


# # Calculating COST for ADHOC

# In[90]:

addhoc_df=df[df['PUDTYPE']=='ADHOC']
len(addhoc_df)


# In[91]:

addhoc_df['Type']='MTD'


# In[92]:

yest_addhoc_df=addhoc_df[addhoc_df['DateOnly']==yest_date]
len(yest_addhoc_df)


# In[93]:

yest_addhoc_df['Type']='YST'


# In[94]:

#addhoc_df['Type']=addhoc_df.apply(lambda x:getType(x['DateOnly']),axis=1)
final_adhoc_df_total=pd.concat([addhoc_df,yest_addhoc_df],ignore_index=True)


# In[95]:

final_adhoc_summary_total=final_adhoc_df_total.pivot_table(index=['DEPOT'],columns=['Type'],values=['COST'],aggfunc={'COST':sum},
                                                           margins='True',margins_name='Total')


# In[96]:

final_adhoc_summary_total1=final_adhoc_summary_total.reset_index()


# In[97]:

final_adhoc_summary_total1.rename(columns={'COST':'ADHOC_COST'},inplace=True)


# In[98]:

final_adhoc_summary_total1=final_adhoc_summary_total1.fillna(0)
final_adhoc_summary_total1['ADHOC_COST','MTD']=pd.np.round(final_adhoc_summary_total1['ADHOC_COST','MTD'],0)
final_adhoc_summary_total1['ADHOC_COST','YST']=pd.np.round(final_adhoc_summary_total1['ADHOC_COST','YST'],0)
final_adhoc_summary_total1['ADHOC_COST','Total']=pd.np.round(final_adhoc_summary_total1['ADHOC_COST','Total'],0)

# In[ ]:

#final_adhoc_summary_total1['ADHOC_COST(L)','MTD']=pd.np.round(final_adhoc_summary_total1['ADHOC_COST','MTD']/100000.0,2)


# In[ ]:

#final_adhoc_summary_total1['ADHOC_COST(L)','YST']=pd.np.round(final_adhoc_summary_total1['ADHOC_COST','YST']/100000.0,2)


# In[99]:

# final_adhoc_summary_total1['ADHOC_COST(L)','Total']=pd.np.round(final_adhoc_summary_total1['ADHOC_COST(L)','YST']+
#                                                                 final_adhoc_summary_total1['ADHOC_COST(L)','MTD'],2)

final_adhoc_summary_total1['ADHOC_COST','Total']=pd.np.round(final_adhoc_summary_total1['ADHOC_COST','YST']+
                                                                final_adhoc_summary_total1['ADHOC_COST','MTD'],2)


# In[ ]:

#del final_adhoc_summary_total1['ADHOC_COST']


# In[100]:

final_adhoc_summary_total1=final_adhoc_summary_total1.fillna(0)


# In[101]:

final_adhoc_summary_total1


# # calculating COST for ADHOC Special without SBA

# In[102]:

adhoc_df_without_sba=df[df['PUDTYPE']=='ADHOC-Special']


# In[103]:

len(adhoc_df_without_sba)


# In[104]:

adhoc_df_yest_without_sba=adhoc_df_without_sba[adhoc_df_without_sba['DateOnly']==yest_date]


# In[105]:

adhoc_df_yest_without_sba['Type']='YST'


# In[106]:

len(adhoc_df_yest_without_sba)


# In[107]:

adhoc_df_without_sba['Type']='MTD'


# In[108]:

#adhoc_df_without_sba['Type']=adhoc_df_without_sba.apply(lambda x:getType(x['DateOnly']),axis=1)
final_adhoc_df_without_sba=pd.concat([adhoc_df_without_sba,adhoc_df_yest_without_sba],ignore_index=True)


# In[109]:

final_adhoc_without_sba_summary=final_adhoc_df_without_sba.pivot_table(index=['DEPOT'],columns=['Type'],values=['COST'],
                                                                       aggfunc={'COST':sum},margins='True',margins_name='Total')


# In[110]:

final_adhoc_without_sba_summary1=final_adhoc_without_sba_summary.reset_index()


# In[111]:

final_adhoc_without_sba_summary1.rename(columns={'COST':'ADH_Spl_COST'},inplace=True)


# In[112]:

final_adhoc_without_sba_summary1=final_adhoc_without_sba_summary1.fillna(0)


# In[ ]:

# try:
#     final_adhoc_without_sba_summary1['ADH_Spl_COST(L)','YST']=pd.np.round(final_adhoc_without_sba_summary1['ADH_Spl_COST','YST']/100000.0,2)
# except:
#     final_adhoc_without_sba_summary1['ADH_Spl_COST(L)','YST']=0.0


# In[ ]:

#final_adhoc_without_sba_summary1['ADH_Spl_COST(L)','MTD']=pd.np.round(final_adhoc_without_sba_summary1['ADH_Spl_COST','MTD']/100000.0,2)


# In[113]:

# final_adhoc_without_sba_summary1['ADH_Spl_COST(L)','Total']=pd.np.round(final_adhoc_without_sba_summary1['ADH_Spl_COST(L)','YST']+
#                                                                       final_adhoc_without_sba_summary1['ADH_Spl_COST(L)','MTD'],2 )


final_adhoc_without_sba_summary1['ADH_Spl_COST','Total']=pd.np.round(final_adhoc_without_sba_summary1['ADH_Spl_COST','YST']+
                                                                      final_adhoc_without_sba_summary1['ADH_Spl_COST','MTD'],2 )


# In[114]:

###Adhoc and Adhoc Special Merging
adhoc_adhocspl_summary=pd.merge(final_adhoc_summary_total1,final_adhoc_without_sba_summary1,on='DEPOT')
adhoc_adhocspl_summary['ADH_Spl_COST','YST']=pd.np.round(adhoc_adhocspl_summary['ADH_Spl_COST','YST'],0)
adhoc_adhocspl_summary['ADH_Spl_COST','MTD']=pd.np.round(adhoc_adhocspl_summary['ADH_Spl_COST','MTD'],0)
adhoc_adhocspl_summary['ADH_Spl_COST','Total']=pd.np.round(adhoc_adhocspl_summary['ADH_Spl_COST','Total'],0)

# In[115]:

adhoc_adhocspl_summary


# In[ ]:




# In[ ]:

#del final_adhoc_without_sba_summary1['ADH_Spl_COST']


# In[116]:

final_adhoc_summary1=pd.merge(final_adhoc_summary1,final_adhoc_summary_total1,on='DEPOT')


# In[117]:

final_adhoc_summary1=pd.merge(final_adhoc_summary1,final_adhoc_without_sba_summary1,on='DEPOT')


# In[118]:

final_adhoc_summary1.head()


# In[119]:

# final_adhoc_summary1=final_adhoc_summary1[[('DEPOT',''),('Cons','YST'),('Cons','MTD'),('Wt(T)','YST'),('Wt(T)','MTD'),
#                                            ('COST(L)','YST'),('COST(L)','MTD'),('MKT_SBA_AMT(L)','YST'),('MKT_SBA_AMT(L)','MTD'),
#                                           ('ADHOC_COST(L)','YST'),('ADHOC_COST(L)','MTD'),('ADHOC_COST(L)','Total'),
#                                            ('ADH_Spl_COST(L)','YST'),('ADH_Spl_COST(L)','MTD'),('ADH_Spl_COST(L)','Total') ]]


final_adhoc_summary1=final_adhoc_summary1[[('DEPOT',''),('Cons','YST'),('Cons','MTD'),('Wt(T)','YST'),('Wt(T)','MTD'),
                                           ('COST','YST'),('COST','MTD'),('MKT_SBA_AMT','YST'),('MKT_SBA_AMT','MTD'),
                                          ('ADHOC_COST','YST'),('ADHOC_COST','MTD'),('ADHOC_COST','Total'),
                                           ('ADH_Spl_COST','YST'),('ADH_Spl_COST','MTD'),('ADH_Spl_COST','Total') ]]


# In[120]:

final_adhoc_summary1['COST','YST']=pd.np.round(final_adhoc_summary1['COST','YST'],0)
final_adhoc_summary1['COST','MTD']=pd.np.round(final_adhoc_summary1['COST','MTD'],0)
final_adhoc_summary1['MKT_SBA_AMT','YST']=pd.np.round(final_adhoc_summary1['MKT_SBA_AMT','YST'],0)
final_adhoc_summary1['MKT_SBA_AMT','MTD']=pd.np.round(final_adhoc_summary1['MKT_SBA_AMT','MTD'],0)
final_adhoc_summary1['ADHOC_COST','YST']=pd.np.round(final_adhoc_summary1['ADHOC_COST','YST'],0)
final_adhoc_summary1['ADHOC_COST','MTD']=pd.np.round(final_adhoc_summary1['ADHOC_COST','MTD'],0)
final_adhoc_summary1['ADHOC_COST','Total']=pd.np.round(final_adhoc_summary1['ADHOC_COST','Total'],0)

final_adhoc_summary1['ADH_Spl_COST','YST']=pd.np.round(final_adhoc_summary1['ADH_Spl_COST','YST'],0)
final_adhoc_summary1['ADH_Spl_COST','MTD']=pd.np.round(final_adhoc_summary1['ADH_Spl_COST','MTD'],0)
final_adhoc_summary1['ADH_Spl_COST','Total']=pd.np.round(final_adhoc_summary1['ADH_Spl_COST','Total'],0)



# In[ ]:




# ##Adhoc vehicles STD Routes

# In[174]:

std_df=df[df['PUDTYPE']=='STD']
len(std_df)


# In[175]:

yest_std_df=std_df[std_df['DateOnly']==yest_date]
len(yest_std_df)


# In[176]:

yest_std_df['Type']='YST'


# In[177]:

std_df['Type']='MTD'


# In[178]:

#std_df['Type']=std_df.apply(lambda x:getType(x['DateOnly']),axis=1)
final_std_df=pd.concat([std_df,yest_std_df],ignore_index=True)


# In[179]:

final_std_summary=final_std_df.pivot_table(index=['PINCODE','CUSTOMERCODE','DEPOT','BRANCH_CODE'],columns=['Type'],values=['ACT_WT','COST','con_id'],
                                          aggfunc={'ACT_WT':sum,'COST':sum,'con_id':len}).reset_index()


# In[180]:

final_std_summary1=final_std_summary.fillna(0)


# In[181]:

final_std_summary1.rename(columns={'con_id':'Cons'},inplace=True)


# In[182]:

final_std_summary1['Cons']=final_std_summary1['Cons'].astype(int)


# In[183]:

final_std_summary1['CPKG','YST']=pd.np.round(final_std_summary1['COST','YST']/final_std_summary1['ACT_WT','YST'],1)


# In[184]:

final_std_summary1['CPKG','MTD']=pd.np.round(final_std_summary1['COST','MTD']/final_std_summary1['ACT_WT','MTD'],1)


# In[185]:

final_std_summary1=final_std_summary1.fillna(0)


# In[186]:

final_std_summary1.head()


# In[187]:

final_std_summary_pudname=final_std_df.pivot_table(index=['PINCODE','CUSTOMERCODE','DEPOT','BRANCH_CODE','PUD_NAME'],columns=['Type'],values=['ACT_WT','COST','con_id'],
                                          aggfunc={'ACT_WT':sum,'COST':sum,'con_id':len}).reset_index()


# In[188]:

yest_std_pivot=yest_std_df.pivot_table(index=['PINCODE','CUSTOMERCODE','PUDTYPE','PUD_NAME','TYP'],values=['COST','ACT_WT','con_id'],
                             aggfunc={'COST':sum,'ACT_WT':sum,'con_id':len}
                            ).reset_index()


# In[189]:

df_adhoc=df[df['PUDTYPE']=='ADHOC']
len(df_adhoc)


# In[190]:

yest_df_adhoc=df_adhoc[df_adhoc['DateOnly']==yest_date]
yest_df_adhoc["Type"]='YST'


# In[191]:

df_adhoc['Type']='MTD'


# In[192]:

#df_adhoc['Type']=df_adhoc.apply(lambda x: getType(x['DateOnly']),axis=1)
df_adhoc_final_df1=pd.concat([df_adhoc,yest_df_adhoc],ignore_index=True)


# In[193]:

final_adhoc_summary_pincode=df_adhoc_final_df1.pivot_table(index=['PINCODE','CUSTOMERCODE','DEPOT','BRANCH_CODE'],columns=['Type'],
                                                           values=['ACT_WT','COST','con_id'],
                                          aggfunc={'ACT_WT':sum,'con_id':len,'COST':sum}).reset_index()


# In[194]:

final_adhoc_summary_pincode=final_adhoc_summary_pincode.fillna(0)


# In[195]:

final_adhoc_summary_pincode['CPKG','MTD']=pd.np.round(final_adhoc_summary_pincode['COST','MTD']/final_adhoc_summary_pincode['ACT_WT','MTD'],1)


# In[196]:

final_adhoc_summary_pincode['CPKG','YST']=pd.np.round(final_adhoc_summary_pincode['COST','YST']/final_adhoc_summary_pincode['ACT_WT','YST'],1)


# In[197]:

final_adhoc_summary_pincode1=final_adhoc_summary_pincode.fillna(0)


# In[198]:

final_adhoc_summary_pincode=final_adhoc_summary_pincode.fillna(0)


# In[199]:

final_adhoc_summary_pincode.rename(columns={'con_id':'Cons'},inplace=True)


# In[200]:

final_adhoc_summary_pincode['Cons']=final_adhoc_summary_pincode['Cons'].astype(int)


# In[201]:

final_adhoc_summary_pincode.head()


# In[202]:

final_adhoc_summary_pincode_pudname=df_adhoc_final_df1.pivot_table(index=['PINCODE','CUSTOMERCODE','DEPOT','BRANCH_CODE','PUD_NAME'],columns=['Type'],
                                                           values=['ACT_WT','COST','con_id'],
                                          aggfunc={'ACT_WT':sum,'con_id':len,'COST':sum}).reset_index()


# In[203]:

final_std_summary_pudname=pd.merge(final_std_summary_pudname,final_adhoc_summary_pincode_pudname,
                            on=['PINCODE','CUSTOMERCODE','DEPOT','BRANCH_CODE'],how='inner',suffixes=('_STD','_ADHOC'))


# In[204]:

final_std_summary_pudname=final_std_summary_pudname.fillna(0)


# In[205]:

final_std_summary_pudname['CPK_STD','MTD']=pd.np.round(final_std_summary_pudname['COST_STD','MTD']/final_std_summary_pudname['ACT_WT_STD','MTD'],1)
final_std_summary_pudname['CPK_STD','YST']=pd.np.round(final_std_summary_pudname['COST_STD','YST']/final_std_summary_pudname['ACT_WT_STD','YST'],1)


# In[206]:

final_std_summary_pudname['CPK_ADHOC','MTD']=pd.np.round(final_std_summary_pudname['COST_ADHOC','MTD']/final_std_summary_pudname['ACT_WT_ADHOC','MTD'],1)
final_std_summary_pudname['CPK_ADHOC','YST']=pd.np.round(final_std_summary_pudname['COST_ADHOC','YST']/final_std_summary_pudname['ACT_WT_ADHOC','YST'],1)


# In[207]:

final_std_summary_pudname=final_std_summary_pudname.replace([np.inf,-np.inf],np.nan).fillna(0)


# In[208]:

final_std_summary1=pd.merge(final_std_summary1,final_adhoc_summary_pincode,on=['PINCODE','CUSTOMERCODE','DEPOT','BRANCH_CODE'],how='inner',suffixes=('_STD','_ADHOC'))


# In[209]:

final_std_summary1['CPK_STD','MTD']=pd.np.round(final_std_summary1['COST_STD','MTD']/final_std_summary1['ACT_WT_STD','MTD'],1)
final_std_summary1['CPK_STD','YST']=pd.np.round(final_std_summary1['COST_STD','YST']/final_std_summary1['ACT_WT_STD','YST'],1)


# In[210]:

final_std_summary1['CPK_ADHOC','MTD']=pd.np.round(final_std_summary1['COST_ADHOC','MTD']/final_std_summary1['ACT_WT_ADHOC','MTD'],1)
final_std_summary1['CPK_ADHOC','YST']=pd.np.round(final_std_summary1['COST_ADHOC','YST']/final_std_summary1['ACT_WT_ADHOC','YST'],1)


# In[211]:

final_std_summary1=final_std_summary1.replace([np.inf,-np.inf],np.nan).fillna(0)


# In[212]:

final_std_summary2=final_std_summary1.sort_values(('COST_ADHOC','MTD'),ascending=False)


# In[213]:

final_std_summary2.head()


# In[214]:

final_std_summary2['CODE']=final_std_summary2['PINCODE'].astype(int).astype(str)+final_std_summary2['CUSTOMERCODE'].astype(int).astype(str)


# In[215]:

final_std_summary2.columns=[''.join(col).strip() for col in final_std_summary2.columns]


# In[216]:

final_std_summary2.head()


# In[217]:
pincode_cstmcode_list=final_std_summary2['CODE'].unique().tolist()
final_std_summary3=final_std_summary2.pivot_table(index=['DEPOT','BRANCH_CODE'],values=['CODE','COST_STDMTD','COST_STDYST',
                                            'Cons_STDMTD','Cons_STDYST','COST_ADHOCMTD','COST_ADHOCYST','Cons_ADHOCMTD','Cons_ADHOCYST'],
                        aggfunc={'CODE':lambda x:len(x.unique()),'COST_STDMTD':sum,'COST_STDYST':sum,
                                            'Cons_STDMTD':sum,'Cons_STDYST':sum,'COST_ADHOCMTD':sum,'COST_ADHOCYST':sum,
                                 'Cons_ADHOCMTD':sum,'Cons_ADHOCYST':sum})


# In[218]:

final_std_summary4=final_std_summary3.reset_index()


# In[219]:

final_std_summary4['COST%']=pd.np.round(final_std_summary4['COST_ADHOCMTD']*100.0/final_std_summary4['COST_STDMTD'],1)


# In[220]:

final_std_summary4=final_std_summary4.replace([np.inf,-np.inf],np.nan).fillna(0)


# In[221]:

final_std_summary5=final_std_summary4[final_std_summary4['COST_STDMTD']>0.0]


# In[222]:

final_std_summary6=final_std_summary5.sort_values('COST_ADHOCMTD',ascending=False)
final_std_summary6['COST_ADHOCMTD']=pd.np.round(final_std_summary6['COST_ADHOCMTD'],0)
final_std_summary6['COST_ADHOCYST']=pd.np.round(final_std_summary6['COST_ADHOCYST'],0)
final_std_summary6['COST_STDMTD']=pd.np.round(final_std_summary6['COST_STDMTD'],0)
final_std_summary6['COST_STDYST']=pd.np.round(final_std_summary6['COST_STDYST'],0)

# In[223]:

final_std_summary6


# In[172]:

# final_std_summary6['COST_ADHOCMTD(L)']=pd.np.round(final_std_summary6['COST_ADHOCMTD']/100000.0,2)
# final_std_summary6['COST_ADHOCYST(L)']=pd.np.round(final_std_summary6['COST_ADHOCYST']/100000.0,2)
# final_std_summary6['COST_STDMTD(L)']=pd.np.round(final_std_summary6['COST_STDMTD']/100000.0,2)
# final_std_summary6['COST_STDYST(L)']=pd.np.round(final_std_summary6['COST_STDYST']/100000.0,2)


# In[224]:

# final_std_summary7=final_std_summary6[['DEPOT','BRANCH_CODE','CODE','COST_ADHOCMTD(L)','Cons_ADHOCMTD',
#                                        'COST_ADHOCYST(L)','Cons_ADHOCYST','COST_STDMTD(L)','Cons_STDMTD',
#                                      'COST_STDYST(L)','Cons_STDMTD','COST%']]


final_std_summary7=final_std_summary6[['DEPOT','BRANCH_CODE','CODE','COST_ADHOCMTD','Cons_ADHOCMTD',
                                       'COST_ADHOCYST','Cons_ADHOCYST','COST_STDMTD','Cons_STDMTD',
                                     'COST_STDYST','Cons_STDMTD','COST%']]


# In[225]:
df_adhoc=df_adhoc.replace([np.inf,-np.inf],np.nan).fillna(0)
df_adhoc['PINCODE']=df_adhoc['PINCODE'].astype(int).astype(str)
df_adhoc['CUSTOMERCODE']=df_adhoc['CUSTOMERCODE'].astype(int).astype(str)
df_adhoc['CODE']=df_adhoc['PINCODE']+df_adhoc['CUSTOMERCODE']
df_adhoc_excluding=df_adhoc[~df_adhoc['CODE'].isin(pincode_cstmcode_list)]
len(df_adhoc_excluding)
df_adhoc_excluding_pivot=df_adhoc_excluding.pivot_table(index=['DateOnly','DEPOT','BRANCH_CODE','MKT_PANNAME','BAVEHNO'],values=['ACT_WT','COST','con_id'],
                                                       aggfunc={'ACT_WT':sum,'COST':sum,'con_id':len})

df_adhoc_excluding_pivot['COST']=pd.np.round(df_adhoc_excluding_pivot['COST'],0)




# ##Summaries Storing to Files

# In[226]:

today1=datetime.strftime(datetime.now(),'%Y-%m-%d')
today1


# In[227]:

##Part1 summaries
with ExcelWriter(r'D:\Data\Market Vehicle Cost\Fixed_Vehicle_Util_per.xlsx') as writer:
    yest_summary.to_excel(writer, sheet_name='YesterDay_Sumary',engine='xlsxwriter')
    mtd_summary.to_excel(writer, sheet_name='MTD_Sumary',engine='xlsxwriter')
    vehicle_summary.to_excel(writer, sheet_name='VehicleWise_Sumary',engine='xlsxwriter')
    final_fixed_summary2.to_excel(writer, sheet_name='Final_Sumary',engine='xlsxwriter')
    
with ExcelWriter(r'D:\Data\Market Vehicle Cost\Fixed_Vehicle_Util_per_'+today1+'.xlsx') as writer:
    yest_summary.to_excel(writer, sheet_name='YesterDay_Sumary',engine='xlsxwriter')
    mtd_summary.to_excel(writer, sheet_name='MTD_Sumary',engine='xlsxwriter')
    final_fixed_summary2.to_excel(writer, sheet_name='Final_Sumary',engine='xlsxwriter')
    

# with ExcelWriter(r'D:\Data\Market Vehicle Cost\ConWise_Data_'+today1+'.xlsx') as writer:
#     fixed_df.to_excel(writer, sheet_name='Fixed Data',engine='xlsxwriter')
#     std_df.to_excel(writer, sheet_name='STD Data',engine='xlsxwriter')
#     addhoc_df.to_excel(writer, sheet_name='ADHOC Data',engine='xlsxwriter')


# In[228]:

##Part2 Summaries

with ExcelWriter(r'D:\Data\Market Vehicle Cost\Adhoc_Special_SBA.xlsx') as writer:
    yest_adhoc_summary.to_excel(writer, sheet_name='YST_Summary(with SBA)',engine='xlsxwriter')
    adhoc_mtd_summary.to_excel(writer, sheet_name='MTD_Sumary(with SBA)',engine='xlsxwriter')
    #final_adhoc_summary_total1.to_excel(writer, sheet_name='Total ADHOC COST',engine='xlsxwriter')
    #final_adhoc_without_sba_summary1.to_excel(writer, sheet_name='ADHOC-Special_COST(without SBA)',engine='xlsxwriter')
    adhoc_adhocspl_summary.to_excel(writer, sheet_name='ADHOC&ADHOC_SPL(Without SBA)',engine='xlsxwriter')
    final_adhoc_summary1.to_excel(writer, sheet_name='Final_Summary',engine='xlsxwriter')

with ExcelWriter(r'D:\Data\Market Vehicle Cost\Adhoc_Special_SBA_'+today1+'.xlsx') as writer:
    yest_adhoc_summary.to_excel(writer, sheet_name='YST_Summary(with SBA)',engine='xlsxwriter')
    adhoc_mtd_summary.to_excel(writer, sheet_name='MTD_Sumary(with SBA)',engine='xlsxwriter')
    #final_adhoc_summary_total1.to_excel(writer, sheet_name='Total ADHOC COST',engine='xlsxwriter')
    #final_adhoc_without_sba_summary1.to_excel(writer, sheet_name='ADHOC-Special_COST(without SBA)',engine='xlsxwriter')
    adhoc_adhocspl_summary.to_excel(writer, sheet_name='ADHOC&ADHOC_SPL(Without SBA)',engine='xlsxwriter')
    final_adhoc_summary1.to_excel(writer, sheet_name='Final_Summary',engine='xlsxwriter')


# In[229]:

##Part3 summaries
with ExcelWriter(r'D:\Data\Market Vehicle Cost\Adhoc_Vehicle_STD_Routes.xlsx') as writer:
    final_std_summary1.to_excel(writer, sheet_name='STD_ADHOC_Summary',engine='xlsxwriter')
    #final_adhoc_summary_pincode.to_excel(writer, sheet_name='ADHOC_Sumary',engine='xlsxwriter')
    final_std_summary_pudname.to_excel(writer, sheet_name='Pudname-Wise_Sumary',engine='xlsxwriter')
    
    
    
with ExcelWriter(r'D:\Data\Market Vehicle Cost\Adhoc_Vehicle_STD_Routes_'+today1+'.xlsx') as writer:
    final_std_summary1.to_excel(writer, sheet_name='STD_ADHOC_Summary',engine='xlsxwriter')
    #final_adhoc_summary_pincode.to_excel(writer, sheet_name='ADHOC_Sumary',engine='xlsxwriter')
    #final_std_summary2.to_excel(writer, sheet_name='Final_Sumary',engine='xlsxwriter')
    final_std_summary_pudname.to_excel(writer, sheet_name='Pudname-Wise_Sumary',engine='xlsxwriter')
    
    #final_std_summary4.to_excel(writer, sheet_name='DEPOT&Branchwise_summary',engine='xlsxwriter')
    
# with ExcelWriter(r'D:\Data\Market Vehicle Cost\ConWise_Data_.xlsx') as writer:
#     fixed_df.to_excel(writer, sheet_name='Fixed_Data',engine='xlsxwriter')
#     std_df.to_excel(writer, sheet_name='STD_Data',engine='xlsxwriter')
#     df_adhoc.to_excel(writer, sheet_name='ADHOC_Data',engine='xlsxwriter')
#     adhoc_df.to_excel(writer, sheet_name='ADHOC_Special_Data',engine='xlsxwriter')

df_adhoc_excluding_pivot.to_csv(r'D:\Data\Market Vehicle Cost\Adhoc_Spend.csv')
df_adhoc_excluding_pivot.to_csv(r'D:\Data\Market Vehicle Cost\Adhoc_Spend_'+today1+'.csv')

# In[ ]:

df.to_csv(r'D:\Data\Market Vehicle Cost\PMD_ConWise_Data.csv')


# In[230]:

filepath1=r'D:\Data\Market Vehicle Cost\Adhoc_Special_SBA.xlsx'
filepath2=r'D:\Data\Market Vehicle Cost\Adhoc_Vehicle_STD_Routes.xlsx'
filepath3=r'D:\Data\Market Vehicle Cost\Fixed_Vehicle_Util_per.xlsx'
filepath4=r'D:\Data\Market Vehicle Cost\Adhoc_Spend.csv'
filepath5=r'D:\Data\Market Vehicle Cost\PMD_ConWise_Data.csv'

# In[231]:

for i in [filepath1,filepath2,filepath3,filepath4,filepath5]:
    import numpy as np
    import pandas as pd
    import itertools
    import json
    from pandas import ExcelWriter
    from pandas import pivot_table
    from datetime import datetime
    import os
    import ftplib
    import traceback

    print ('Logging in...')
    ftp = ftplib.FTP()
    ftp.connect('10.109.230.50')
    print (ftp.getwelcome())
    try:
        try:
            ftp.login('IEPROJECTUSER', 'spotStar@123')
            ftp.cwd('ETA')
            # move to the desired upload directory
            print ("Currently in:", ftp.pwd())
            print ('Uploading...')
            fullname = i
            name = os.path.split(fullname)[1]
            f = open(fullname, "rb")
            ftp.storbinary('STOR ' + name, f)
            f.close()
            print ("OK"  )
            print ("Files:")
            print (ftp.retrlines('LIST'))
        finally:
            print ("Quitting...")
            ftp.quit()
    except:
        traceback.print_exc()


# In[232]:

reportts = datetime.now()
opfilevar=reportts.date()
opfilevar1=reportts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=pd.np.round((float(currhrs)/60),0)
#<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/ConWise_Data_.xlsx"</a>http://spoton.co.in/downloads/IEProjects/ETA/ConWise_Data_.xlsx</p></b>

#

# In[233]:




# In[234]:

TO=['sasikumar.kannan@spoton.co.in','joseph.arul.seelan@spoton.co.in','jacob.mathew@spoton.co.in','suresh.kp@spoton.co.in','Dominic.sathish@spoton.co.in','harish.bobade@spoton.co.in','rajesh.debnath@spoton.co.in','ramniwas.sharma@spoton.co.in','chhabil.singh@spoton.co.in','pramod.kumar@spoton.co.in','abani.behera@spoton.co.in','Avinash.Singh@spoton.co.in','dinesh.kumar.sharma@spoton.co.in','ashwani.gangwar@spoton.co.in']
#TO=['mahesh.reddy@spoton.co.in']
CC=['anto.paul@spoton.co.in','goutam.barik@spoton.co.in','mani.kumar@spoton.co.in','rajesh.kumar@spoton.co.in','pawan.sharma@spoton.co.in']
#CC=['mahesh.reddy@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in']
FROM="reports.ie@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)

msg["Subject"] = "PUD Monitoring on FIXED,ADHOC & MIXED -" + str(opfilevar)
html3='''
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Adhoc_Special_SBA.xlsx"</a>http://spoton.co.in/downloads/IEProjects/ETA/Adhoc_Special_SBA.xlsx</p></b>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Adhoc_Vehicle_STD_Routes.xlsx"</a>http://spoton.co.in/downloads/IEProjects/ETA/Adhoc_Vehicle_STD_Routes.xlsx</p></b>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Fixed_Vehicle_Util_per.xlsx"</a>http://spoton.co.in/downloads/IEProjects/ETA/Fixed_Vehicle_Util_per.xlsx</p></b>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Adhoc_Spend.csv"</a>http://spoton.co.in/downloads/IEProjects/ETA/Adhoc_Spend.csv</p></b>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/ConWise_Data_.xlsx"</a>http://spoton.co.in/downloads/IEProjects/ETA/ConWise_Data_.xlsx</p></b>

'''
report=""
report+='Dear All,'

report+='<br>'
report+='<br>'
report+='PFA Market Vehicles Summary.'
report+='<br>'
report+='<br>'
report+='Depot Wise Fixed Vehicle Utilization (YST & MTD)'
report+='<br>'
report+='<br>'+final_fixed_summary2.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='DepotWise Adhoc-Special SBA (YST & MTD)'
report+='<br>'
report+='<br>'+final_adhoc_summary1.to_html()+'<br>'
report+='<br>'
report+='Adhoc vehicles Used in STD Routes (YST & MTD)'
report+='<br>'
report+='<br>'+final_std_summary7.head(10).to_html()+'<br>'
report+='<br>'

report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)




server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()

#except:
TO=['mahesh.reddy@spoton.co.in']
FROM="mahesh.reddy@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
#msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "PUD Monitoring on FIXED,ADHOC & MIXED Error in Execution" 
report=""
report+='Hi,'

report+='<br>'
report+='There was some error in PUD Monitoring on FIXED,ADHOC & MIXED'
report+='<br>'

abc=MIMEText(report.encode('utf-8'),'html')
msg.attach(abc)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO, msg.as_string())
server.quit()


# In[ ]:

exit(0)


# In[ ]:



