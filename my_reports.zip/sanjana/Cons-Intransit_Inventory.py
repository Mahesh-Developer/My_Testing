
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
from datetime import datetime


# In[2]:


closing_df=pd.read_excel(r'http://spoton.co.in/downloads/OCID_CLOSINGSTOCK_1HR/OCID_CLOSINGSTOCK_1HR.xls')
len(closing_df)


# In[3]:


intransit_df=pd.read_excel(r'http://spoton.co.in/downloads/TCR_UND_2HRS/TCR_UND_ISDEPART_YES_2HRS.xls')
len(intransit_df)


# In[4]:


inventory_df=pd.read_excel(r'http://spoton.co.in/downloads/HTR_1HR/HTR_1HR.xls')
len(inventory_df)


# In[5]:


timestamp=datetime.strftime(datetime.now(),'%Y-%m-%d.%H')
timestamp

intransit_df.columns

closing_actwt=pd.np.round((closing_df['ACTUWT'].sum()/1000),1)
closing_cons=len(closing_df)
print (closing_actwt,closing_cons)
inventory_actwt=pd.np.round(inventory_df['Act Wt In Tonnes'].sum(),1)
inventory_cons=len(inventory_df)
print (inventory_actwt,inventory_cons)
#intransit_actwt=intransit_df['ACTUWT'].sum()
intransit_cons=len(intransit_df)
print (intransit_cons)


# In[7]:


d={'Dest_Cons':closing_cons,'Dest_Wt(T)':closing_actwt,'Inventory_Cons':inventory_cons,'Inventory_Wt(T)':inventory_actwt,'Intransit_Wt(T)':'','Intransit_Cons':intransit_cons,'Total Wt(T)':(closing_actwt+inventory_actwt),'Total Cons':(intransit_cons+inventory_cons+closing_cons)}
result_df=pd.DataFrame([d],index=[timestamp])

dec_summary_df=pd.read_csv(r'D:\Data\Cons_Intransit_Inventory_Stock_Summary\Dec_Cons_Summary.csv')
print (dec_summary_df)


from datetime import date,timedelta
todate=date.today()-timedelta(1)
today_date=datetime.strftime(todate,'%d-%m-%Y')
today_date
#vishwas.j@spoton.co.in
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

TO=['supratim@iepfunds.com','ankit@iepfunds.com','krishna.chandrasekar@spoton.co.in']
#TO=['mahesh.reddy@spoton.co.in']
FROM="reports.ie@spoton.co.in"
#CC=['mahesh.reddy@spoton.co.in']
CC=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
#BCC=['maheshmahesh11464@gmail.com']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
msg["Subject"] = "Cons- Intransit & Inventory as of" + " : " + str(timestamp)
html='''<html>
<style>
p
{
  margin:0;
  margin-top: 5px;
  padding:0;
  font-size:17px;
    line-height:20px;
}
</style>
<h4>Dear All,</h4>
<p>PFA,Cons at Stock,Hub Inventory and Intransit as of $date</p>
</html>'''


s = Template(html).safe_substitute(date=timestamp)
report=""
report+=s
report+='<br>'+result_df.fillna(0).to_html()+'<br>'
report+='December Summary as of 2017-12-31.23:00:00'
report+='<br>'+dec_summary_df.fillna(0).to_html()+'<br>'
abc=MIMEText(report,'html')
msg.attach(abc)
# part = MIMEBase('application', "octet-stream")
# part.set_payload( open(filePath,"rb").read() )
# encoders.encode_base64(part)
# part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
# msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()

