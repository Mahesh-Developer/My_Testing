
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta
import sys
import Utilities
# In[ ]:
reload(sys).setdefaultencoding("ISO-8859-1")

# if date.today()-timedelta(1)==7:
#     querydate=date.today()-timedelta(2)
# else:
querydate=date.today()-timedelta(2)


# In[2]:


# cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")


# # In[3]:


# cursor=cnxn.cursor()
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()

# In[4]:



query=("""EXEC dbo.USP_ODA_PIN_LOAD_FACTOR '{0}' , '{1}'""".format(querydate,querydate))


# In[5]:


query


# In[6]:


data=pd.read_sql(query,Utilities.cnxn)
print (data)


# In[7]:


#data = pd.read_excel(r'E:\RAJESH M P\RAJESH M P\a Rajesh M P\Reports\ton wise delivery\ODA_Pincodewise - Free Conss_.xlsx','Data')


# In[8]:


data = data[data['IS_OPS_FREE']=='YES']


# In[9]:


data.rename(columns={'DOCKNO': 'CONS', 'ACTUWT': 'WEIGHT'}, inplace=True)


# In[10]:


pivot=pd.pivot_table(data,index=["DEST_AREA","DEST_BRNM","DEST_PINCODE"],columns=["CON_TYPE"],values=["CONS","WEIGHT"],aggfunc={"CONS":len,"WEIGHT":sum},
              fill_value=0,margins=True)


# In[11]:


pivot.CONS = pivot.CONS.astype(int)


# In[12]:


pivot.WEIGHT = pivot.WEIGHT.astype(int)


# In[13]:


pivot.columns = pivot.columns.swaplevel(0, 1)


# In[14]:


pivot.sortlevel(0, axis=1, inplace=True)


# In[15]:


pivot = pivot[['New','Old','All']]


# In[16]:


pivot1=pd.pivot_table(data,index=["DEST_AREA"],columns=["CON_TYPE"],values=["CONS","WEIGHT"],aggfunc={"CONS":len,"WEIGHT":sum},
              fill_value=0,margins=True)


# In[17]:


pivot1.CONS = pivot1.CONS.astype(int)


# In[18]:


pivot1.WEIGHT = pivot1.WEIGHT.astype(int)


# In[19]:


pivot1 = pivot1[['CONS','WEIGHT']]


# In[20]:


pivot1.columns = pivot1.columns.swaplevel(0, 1)


# In[21]:


pivot1.sortlevel(0, axis=1, inplace=True)


# In[22]:


pivot1 = pivot1[['New','Old','All']]


# In[23]:


from pandas import ExcelWriter


# In[24]:


with ExcelWriter(r'D:\Data\ODA_Loads_Ton_wise\odaloads.xlsx') as writer:
   pivot.to_excel(writer, sheet_name='Pivot',engine='xlsxwriter')
   data.to_excel(writer, sheet_name='data',engine='xlsxwriter')
   
   
   


# In[25]:


filepath=r'D:\Data\ODA_Loads_Ton_wise\odaloads.xlsx'


# In[30]:


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.MIMEBase import MIMEBase
from email import Encoders
import os

from_addr = 'mis.ho@spoton.co.in'
# to_addr = ['aom_spot@spoton.co.in','dom_spot@spoton.co.in','rom_spot@spoton.co.in']
# cc_addr = ['abhik.mitra@spoton.co.in','jothi.menon@spoton.co.in','rajesh.kumar@spoton.co.in','shivananda.p@spoton.co.in','rajesh.mp@spoton.co.in']
# bcc_addr = ['scincharge_spot@spoton.co.in']
to_addr = ['rajesh.mp@spoton.co.in']
cc_addr = ['mahesh.reddy@spoton.co.in']
bcc_addr = ['shashvat.suhane@spoton.co.in']
msg = MIMEMultipart('related')
msg['From'] = from_addr
msg['To'] = ', '.join(to_addr)
msg['cc'] = ', '.join(cc_addr)
msg['bcc'] = ', '.join(bcc_addr)
msg['Subject'] = 'ODA_Pin_codewise - Free Cons'

username = 'mis.ho@spoton.co.in'
password = 'Mis@2019'
msg = MIMEMultipart()
#msg['From'] = from_addr
#msg['To'] = ', '.join(to_addr)
msg['Subject'] = 'ODA_Pin_codewise - Free Cons'
html='''<html>
<h4>Dear All PFA</h4>
<p>Pin-code wise Load factor available for delivery.</p>
</html>'''

# part11=MIMEText(html,'html')
# msg.attach(part11)
# part12=MIMEText('<br>'+pivot1.to_html()+'<br>','html')

html1='''<h5>Thanks & Regards</h5></b>

<h5>HO-SQ</h5>'''
report=""
report+=html
report+='<br>'
report+='<br>'+pivot1.to_html()+'<br>'
report+=html1
abc=MIMEText(report,'html')
msg.attach(abc)
# part10=MIMEText('<br>'+html1+'<br>','html')
#  <h5>Rajesh M P </h5></b>
# msg.attach(part10)
server = smtplib.SMTP('smtp.spoton.co.in',587)
part=MIMEBase('application','octet-stream')
# part1=MIMEBase('application','octet-stream')
part.set_payload(open(filepath,'rb').read())
# part1.set_payload(open(filepath1,'rb').read())
Encoders.encode_base64(part)
# Encoders.encode_base64(part1)
part.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath))
# part1.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath1))
msg.attach(part)
# msg.attach(part1)
server.ehlo()
server.starttls()
server.ehlo()
server.login('mis.ho@spoton.co.in','Mis@2019')
server.sendmail(from_addr,to_addr+cc_addr+bcc_addr,msg.as_string())
print ('mail sent succesfully  ')
server.quit()

