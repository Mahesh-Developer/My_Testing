
# coding: utf-8

# In[1]:

import pandas as pd
from datetime import datetime, date
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import os


# In[2]:

fullinvoicedata = pd.read_csv('http://spoton.co.in/downloads/INVOICE_TRACKER_IEP/INVOICE_TRACKER_IEP_REPORT.csv')
print len(fullinvoicedata)

#fullinvoicedata = fullinvoicedata[fullinvoicedata['Type_of_Invoice']=='Freight']
#print len(fullinvoicedata)
# In[3]:




# In[4]:

# timeformat1 = '%d/%m/%y'
# dayzero1 = '30/12/11'

timeformat1 = '%d/%m/%Y'
dayzero1 = '30/12/2011'
dayzero = datetime.strptime(dayzero1,timeformat1)


# In[5]:

fullinvoicedata = fullinvoicedata.rename(columns={'\xef\xbb\xbfRegion':'Region'})
fullinvoicedata.columns.tolist()


# In[6]:

fullinvoicedata['HO_RO_Despatch_Date'].values[0]


# In[7]:

fullinvoicedata.CC_Recv_Date.fillna(dayzero1, inplace=True)
fullinvoicedata.Physically_Received_by_Authorized_Customer_Date.fillna(dayzero1, inplace=True)
fullinvoicedata.PIS_Date.fillna(dayzero1, inplace=True)
fullinvoicedata.Invoice_Date.fillna(dayzero1, inplace=True)
fullinvoicedata.Submission_to_the_Customer_Date.fillna(dayzero1, inplace=True)
fullinvoicedata['HO_RO_Despatch_Date'] = fullinvoicedata['HO_RO_Despatch_Date'].str.replace('-',dayzero1)
#stdvehinadhocsummarymerge.PUDTYPE2.fillna('STD',inplace=True)


# In[8]:

#fullinvoicedata.to_csv('fullinvoicedata.csv')


# In[9]:

#datecols = [i for i in fullinvoicedata.columns if 'Date' in i]
datecols = ['CC_Recv_Date','Physically_Received_by_Authorized_Customer_Date','PIS_Date','Invoice_Date','HO_RO_Despatch_Date','Submission_to_the_Customer_Date']
type(datecols)


# In[10]:

def convertdate(x):
    try:
        
        x = x.split(' ')[0]
        return datetime.strptime(x,timeformat1)
    except:
        return dayzero


# In[11]:

for datecol in datecols:
    #invoice = invoice.fillna(datecol, dayzero1)
    #invoice = invoice[(invoice[datecol]!='-') or (invoice[datecol]) or (invoice[datecol]!='N') or (invoice[datecol]!='')]
    fullinvoicedata[datecol] = fullinvoicedata.apply(lambda x: convertdate(x[datecol]),axis=1)
    print datecol, len(fullinvoicedata)


# In[12]:

fullinvoicedata['HO_RO_Despatch_Date'].values[0]


# In[13]:

#fullinvoicedata.to_csv('fullinvoicedata.csv')


# In[14]:

stage1df = fullinvoicedata[fullinvoicedata['HO_RO_Despatch_Date']==dayzero]
stage2df = fullinvoicedata[(fullinvoicedata['HO_RO_Despatch_Date']!=dayzero) & (fullinvoicedata['Submission_to_the_Customer_Date']==dayzero)]
stage3df = fullinvoicedata[(fullinvoicedata['Submission_to_the_Customer_Date']!=dayzero) & (fullinvoicedata['PIS_Date']==dayzero)]
#len(stage1df), dayzero, type(dayzero), fullinvoicedata['HO_RODespatchDate'].values[0], type(fullinvoicedata['HO_RODespatchDate'].values[0])
#stage1df.to_csv('D:\Data\Invoice_tracker\stage1df.csv')
#stage2df.to_csv('D:\Data\Invoice_tracker\stage2df.csv')
#stage3df.to_csv('D:\Data\Invoice_tracker\stage3df.csv')

len(stage1df),len(stage2df),len(stage3df)


# In[15]:

todaydate1 = datetime.today()
def diffdate(passdate):
    #passdate = fullinvoicedata['InvoiceDate'].values[0]
    a1 = pd.to_datetime(str(passdate)).replace(tzinfo=None)
    diffdays = int((todaydate1-a1).days)
    return diffdays


# In[16]:

##fullinvoicedata.to_csv('fullinvoicedata.csv')


# In[17]:

stage1df['Stage1_diffdays'] =  stage1df.apply(lambda x : diffdate(x['Invoice_Date']),axis=1)
stage2df['Stage2_diffdays'] =  stage2df.apply(lambda x : diffdate(x['HO_RO_Despatch_Date']),axis=1)
stage3df['Stage3_diffdays'] =  stage3df.apply(lambda x : diffdate(x['Submission_to_the_Customer_Date']),axis=1)


# In[21]:

def tatstage1(podtype):
    if podtype == 'CD Copy':
        return 7
    elif podtype == 'Hard Copy':
        return 12
    elif podtype == 'Soft Copy':
        return 7
    elif podtype == 'Not Required':
        return 1
    else:
        return 'check'


# In[22]:

stage1df['TAT'] = stage1df.apply(lambda x:tatstage1(x['Category']),axis=1)


# In[23]:

stage2df.loc[stage2df.index,'TAT'] = 5
#stage3df.loc[stage3df.index,'TAT'] = 30


# In[24]:

stage1df['DSO_value'] = stage1df.apply(lambda x :pd.np.round((x['Stage1_diffdays'])*(x['Invoice_Amt']),0),axis=1)
stage2df['DSO_value'] = stage2df.apply(lambda x :pd.np.round((x['Stage2_diffdays'])*(x['Invoice_Amt']),0),axis=1)
stage3df['DSO_value'] = stage3df.apply(lambda x :pd.np.round((x['Stage3_diffdays'])*(x['Invoice_Amt']),0),axis=1)


# In[25]:

def crosstat(tat1,diffdays1):
    if diffdays1>tat1:
        return 'YES'
    else:
        return 'NO'


# In[26]:

stage1df['Crossed_TAT'] = stage1df.apply(lambda x :crosstat(x['TAT'],x['Stage1_diffdays']),axis=1)
stage2df['Crossed_TAT'] = stage2df.apply(lambda x :crosstat(x['TAT'],x['Stage2_diffdays']),axis=1)
stage3df['Crossed_TAT'] = stage3df.apply(lambda x :crosstat(x['CreditPeriod'],x['Stage3_diffdays']),axis=1)


# In[28]:

stage1dfgrp = stage1df.groupby(['Category']).agg({'Invoice_No':len,'Invoice_Amt':sum,'DSO_value':sum}).reset_index()
stage2dfgrp = stage2df.groupby(['Depot']).agg({'Invoice_No':len,'Invoice_Amt':sum,'DSO_value':sum}).reset_index()
stage3dfgrp = stage3df.groupby(['Depot']).agg({'Invoice_No':len,'Invoice_Amt':sum,'DSO_value':sum}).reset_index()


# In[29]:

stage1tatyes = stage1df[stage1df['Crossed_TAT']=='YES']
stage2tatyes = stage2df[stage2df['Crossed_TAT']=='YES']
stage3tatyes = stage3df[stage3df['Crossed_TAT']=='YES']


# In[30]:

stage1tatyesgrp = stage1tatyes.groupby(['Category']).agg({'Invoice_No':len,'Invoice_Amt':sum,'DSO_value':sum}).reset_index()
stage2tatyesgrp = stage2tatyes.groupby(['Depot']).agg({'Invoice_No':len,'Invoice_Amt':sum,'DSO_value':sum}).reset_index()
stage3tatyesgrp = stage3tatyes.groupby(['Depot']).agg({'Invoice_No':len,'Invoice_Amt':sum,'DSO_value':sum}).reset_index()


# In[31]:

stage1final = pd.merge(stage1dfgrp,stage1tatyesgrp,on=['Category'],suffixes=['_total','_crossed_TAT'],how='inner')
stage2final = pd.merge(stage2dfgrp,stage2tatyesgrp,on=['Depot'],suffixes=['_total','_crossed_TAT'],how='inner')
stage3final = pd.merge(stage3dfgrp,stage3tatyesgrp,on=['Depot'],suffixes=['_total','_crossed_TAT'],how='inner')


# In[32]:

# stage1final.to_csv('stage1final.csv')
# stage2final.to_csv('stage2final.csv')
# stage3final.to_csv('stage3final.csv')
stage1final['Weighted_avg_DSO'] = stage1final.apply(lambda x:pd.np.round(x['DSO_value_total']/x['Invoice_Amt_total'],0),axis=1)
stage2final['Weighted_avg_DSO'] = stage2final.apply(lambda x:pd.np.round(x['DSO_value_total']/x['Invoice_Amt_total'],0),axis=1)
stage3final['Weighted_avg_DSO'] = stage3final.apply(lambda x:pd.np.round(x['DSO_value_total']/x['Invoice_Amt_total'],0),axis=1)

# In[33]:

stage1final['Weighted_avg_DSO_crossedTAT'] = stage1final.apply(lambda x:pd.np.round(x['DSO_value_crossed_TAT']/x['Invoice_Amt_crossed_TAT'],0),axis=1)
stage2final['Weighted_avg_DSO_crossedTAT'] = stage2final.apply(lambda x:pd.np.round(x['DSO_value_crossed_TAT']/x['Invoice_Amt_crossed_TAT'],0),axis=1)
stage3final['Weighted_avg_DSO_crossedTAT'] = stage3final.apply(lambda x:pd.np.round(x['DSO_value_crossed_TAT']/x['Invoice_Amt_crossed_TAT'],0),axis=1)


# In[34]:

stage1final = pd.DataFrame(stage1final,columns=['Category','Invoice_No_total','Invoice_Amt_total','Weighted_avg_DSO','Invoice_No_crossed_TAT','Invoice_Amt_crossed_TAT','DSO_value_crossed_TAT','Weighted_avg_DSO_crossedTAT'])
stage2final = pd.DataFrame(stage2final,columns=['Depot','Invoice_No_total','Invoice_Amt_total','Weighted_avg_DSO','Invoice_No_crossed_TAT','Invoice_Amt_crossed_TAT','DSO_value_crossed_TAT','Weighted_avg_DSO_crossedTAT'])
stage3final = pd.DataFrame(stage3final,columns=['Depot','Invoice_No_total','Invoice_Amt_total','Weighted_avg_DSO','Invoice_No_crossed_TAT','Invoice_Amt_crossed_TAT','DSO_value_crossed_TAT','Weighted_avg_DSO_crossedTAT'])


# In[35]:

# stage1final.to_csv('stage1final.csv')
# stage2final.to_csv('stage2final.csv')
# stage3final.to_csv('stage3final.csv')


# In[36]:

stage1final


# In[37]:

stage2final


# In[38]:

stage3final


# In[39]:

todaydate = date.today() 
with ExcelWriter(r'D:\Data\Invoice_tracker\Invoice_tracker_summary\Invoice_tracker_summary_'+str(todaydate)+'.xlsx') as writer:
    stage1final.to_excel(writer, sheet_name='Invoiced_not_dispatched',engine='xlsxwriter')
    stage2final.to_excel(writer, sheet_name='Dispatched_not_submitted',engine='xlsxwriter')
    stage3final.to_excel(writer, sheet_name='Submitted_not_collected',engine='xlsxwriter')


# In[40]:

oppath1 = r'D:\Data\Invoice_tracker\Invoice_tracker_summary\Invoice_tracker_summary_'+str(todaydate)+'.xlsx'


# In[42]:

filePath = oppath1
def sendEmail(#TO = ["Supratim@iepfunds.com","rajeesh.vr@spoton.co.in"],
              TO = ["vishwas.j@spoton.co.in"],
              CC = ["vishwas.j@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "Invoice Tracker Summary" + ' - ' + str(todaydate)
    body_text = """
    Dear All,
    
    PFA the Invoice Tracker Summary as of """+str(todaydate)+"""
    

    """ 

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')


# In[ ]:



