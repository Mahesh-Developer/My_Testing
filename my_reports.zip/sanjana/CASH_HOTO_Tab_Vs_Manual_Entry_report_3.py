
# coding: utf-8

# In[1]:


import pandas as pd
import pyodbc
from datetime import datetime,timedelta
from datetime import datetime,timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
import ftplib
from calendar import monthrange
import smtplib


# In[ ]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()


# In[ ]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()


# In[2]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
cursor = cnxn.cursor()


# In[3]:


# startdate=datetime.strftime((datetime.now()-timedelta(days=1)).replace(day=1),"%Y-%m-%d")
startdate='2019-08-01'


# In[4]:


enddate=datetime.strftime(datetime.now()-timedelta(days=1),"%Y-%m-%d")
enddate


# In[5]:


query1=("""SELECT  A.Dockno DOCKNO,
A.PISGenerated TabPISgenerated
FROM    dbo.tblCashFTCCollectionDtls A WITH ( NOLOCK )
        INNER JOIN dbo.TblCashFTCHandOverDTLS B WITH ( NOLOCK ) ON B.Dockno = A.Dockno
        INNER JOIN dbo.TBLCashFTCHandOverHDR C WITH ( NOLOCK ) ON C.HandOverid = B.HandOverid
        LEFT JOIN dbo.TblCashFTCHandOver_Ack D WITH ( NOLOCK ) ON D.AckId = B.AckId
        LEFT JOIN dbo.tblInvoiceConMap E WITH (NOLOCK) ON A.Dockno = E.DocketNumber
        LEFT JOIN DOCKET F WITH (NOLOCK) ON A.Dockno = F.DOCKNO
        LEFT JOIN dbo.DKT_DELY G WITH (NOLOCK) ON A.Dockno = G.DOCKNO
WHERE   G.DELY_DT BETWEEN '{0}'
                  AND    '{1}'
 

""").format (startdate, enddate) 


# In[6]:


query2=("""SELECT  A.DOCKNO ,

        A.DOCKDT Pickupdate ,

        A.CDELDT Deliverydate ,

        A.PAYBAS ,

        A.ORGNCD ,

        A.DESTCD ,

        TV.TotalInvoiceAmount ,

        B.InvoiceId ,

        D.PISNO ,

        C.CollectedAmnt ,

        B.InvoiceId

FROM    dbo.DOCKET A WITH ( NOLOCK )

        LEFT OUTER JOIN dbo.DKT_DELY DD WITH ( NOLOCK ) ON DD.DOCKNO = A.DOCKNO

        LEFT OUTER JOIN dbo.tblInvoiceConMap B WITH ( NOLOCK ) ON B.DocketNumber = A.DOCKNO

              LEFT OUTER JOIN dbo.tblInvoice TV WITH (NOLOCK) ON TV.InvoiceId = B.InvoiceId AND TV.SupplementaryInvoiceType IS NULL AND TV.Reinvoice = 0

        LEFT OUTER JOIN espeedage.dbo.Collectiondtls_iep C WITH ( NOLOCK ) ON SUBSTRING(C.conNo,

                                                              1, 10) = CONVERT(VARCHAR(10), B.InvoiceId)

                                                              AND C.CollectionTyp NOT IN (

                                                              'DEM', 'OCT',

                                                              'ETX' )

        LEFT OUTER JOIN espeedage.dbo.CollectionMain_iep D WITH ( NOLOCK ) ON D.InternalNo = C.InternalNo

        LEFT OUTER JOIN dbo.tblCashFTCCollectionDtls E WITH ( NOLOCK ) ON E.Dockno = A.DOCKNO

WHERE   A.PAYBAS IN ( 4 )

        AND A.CDELDT BETWEEN '{0}'
                     AND     '{1}'

""").format (startdate, enddate)


# In[7]:


df1=pd.read_sql(query1,cnxn)


# In[8]:


df2=pd.read_sql(query2,cnxn)


# In[9]:


df1['Entry Type']='TAB'


# In[10]:


df1['DOCKNO']=df1['DOCKNO'].astype(int)


# In[11]:


df2['DOCKNO']=df2['DOCKNO'].astype(int)


# In[12]:


df3=pd.merge(df2,df1,how='left',on='DOCKNO')


# In[13]:


df3['Entry Type']=df3['Entry Type'].fillna('Manual/IBS')


# In[14]:


df4=df3[df3['DESTCD'].isin(['BLRB','BLRT','BLRF','BLRR','BLRN'])]


# In[15]:


df4['PISNO']=df4['PISNO'].fillna(0)


# In[18]:


def a(PISNO):
   
    if PISNO!=0:
        return 'PIS Done'
    else:
        return 'PIS Not Done'
                 


# In[19]:


df4['Status']=df4.apply(lambda x:a (x['PISNO']),axis=1)


# In[20]:


df4


# In[21]:


df5=df4.pivot_table(index=['Deliverydate'],columns=['Entry Type','Status'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True).fillna(0)


# 
# # CASH Delivery

# In[38]:


df5


# In[23]:


query11=("""SELECT  A.Dockno DOCKNO,
A.PISGenerated TabPISgenerated
FROM    dbo.tblCashFTCCollectionDtls A WITH ( NOLOCK )
        INNER JOIN dbo.TblCashFTCHandOverDTLS B WITH ( NOLOCK ) ON B.Dockno = A.Dockno
        INNER JOIN dbo.TBLCashFTCHandOverHDR C WITH ( NOLOCK ) ON C.HandOverid = B.HandOverid
        LEFT JOIN dbo.TblCashFTCHandOver_Ack D WITH ( NOLOCK ) ON D.AckId = B.AckId
        LEFT JOIN dbo.tblInvoiceConMap E WITH (NOLOCK) ON A.Dockno = E.DocketNumber
        LEFT JOIN DOCKET F WITH (NOLOCK) ON A.Dockno = F.DOCKNO
        LEFT JOIN dbo.DKT_DELY G WITH (NOLOCK) ON A.Dockno = G.DOCKNO
WHERE   F.DOCKDT BETWEEN '{0}'
                  AND    '{1}'
 

""").format (startdate, enddate) 


# In[24]:


query21=("""SELECT  A.DOCKNO ,

        A.DOCKDT Pickupdate ,

        A.CDELDT Deliverydate ,

        A.PAYBAS ,

        A.ORGNCD ,

        A.DESTCD ,

        TV.TotalInvoiceAmount ,

        B.InvoiceId ,

        D.PISNO ,

        C.CollectedAmnt ,

        B.InvoiceId

FROM    dbo.DOCKET A WITH ( NOLOCK )

        LEFT OUTER JOIN dbo.DKT_DELY DD WITH ( NOLOCK ) ON DD.DOCKNO = A.DOCKNO

        LEFT OUTER JOIN dbo.tblInvoiceConMap B WITH ( NOLOCK ) ON B.DocketNumber = A.DOCKNO

              LEFT OUTER JOIN dbo.tblInvoice TV WITH (NOLOCK) ON TV.InvoiceId = B.InvoiceId AND TV.SupplementaryInvoiceType IS NULL AND TV.Reinvoice = 0

        LEFT OUTER JOIN espeedage.dbo.Collectiondtls_iep C WITH ( NOLOCK ) ON SUBSTRING(C.conNo,

                                                              1, 10) = CONVERT(VARCHAR(10), B.InvoiceId)

                                                              AND C.CollectionTyp NOT IN (

                                                              'DEM', 'OCT',

                                                              'ETX' )

        LEFT OUTER JOIN espeedage.dbo.CollectionMain_iep D WITH ( NOLOCK ) ON D.InternalNo = C.InternalNo

        LEFT OUTER JOIN dbo.tblCashFTCCollectionDtls E WITH ( NOLOCK ) ON E.Dockno = A.DOCKNO

WHERE   A.PAYBAS IN ( 1 )

        AND A.DOCKDT BETWEEN '{0}'
                     AND     '{1}'

""").format (startdate, enddate)


# In[25]:


df11=pd.read_sql(query11,cnxn)


# In[26]:


df21=pd.read_sql(query21,cnxn)


# In[27]:


df11['Entry Type']='TAB'


# In[28]:


df11['DOCKNO']=df11['DOCKNO'].astype(int)


# In[29]:


df21['DOCKNO']=df21['DOCKNO'].astype(int)


# In[30]:


df31=pd.merge(df21,df11,how='left',on='DOCKNO')


# In[31]:


df31['Entry Type']=df31['Entry Type'].fillna('Manual/IBS')


# In[32]:


df41=df31[df31['ORGNCD'].isin(['BLRB','BLRT','BLRF','BLRR','BLRN'])]


# In[33]:


df41['PISNO']=df41['PISNO'].fillna(0)


# In[34]:


def b(PISNO):
    
    if PISNO!=0:
        return 'PIS Done'
    else:
        return 'PIS Not Done'


# In[35]:


df41['Status']=df41.apply(lambda x:b (x['PISNO']),axis=1)


# In[36]:


df51=df41.pivot_table(index=['Deliverydate'],columns=['Entry Type','Status'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True).fillna(0)


# # CASH Pick-up

# In[45]:


df51


# In[233]:


df4
df41

# # CASH Pick-up

# In[ ]:


df51


# In[35]:


df4.to_csv(r'D:\Data\FTC\Tab_vs_Manual\Cash_Delivery_Data.csv')
df41.to_csv(r'D:\Data\FTC\Tab_vs_Manual\Cash_Pickup_Data.csv')


# In[36]:


filepath=r'D:\Data\FTC\Tab_vs_Manual\Cash_Delivery_Data.csv'
filepath1=r'D:\Data\FTC\Tab_vs_Manual\Cash_Pickup_Data.csv'


# In[37]:


TO=['badan.singh@spoton.co.in','saptarshi.pathak@spoton.co.in','dillip.padhi@spoton.co.in','banusanketh.dc@spoton.co.in','abhik.mitra@spoton.co.in','krishna.chandrasekar@spoton.co.in','scincharge_spot@spoton.co.in','AOM_SPOT@spoton.co.in','DOM_SPOT@spoton.co.in','pawan.sharma@spoton.co.in','rajesh.kumar@spoton.co.in','suman.kumar@spoton.co.in','manjunath.swamy@spoton.co.in','mahesh.reddy@spoton.co.in']
# TO=['saptarshi.pathak@spoton.co.in']
CC=['mahesh.reddy@spoton.co.in']
FROM="reports.ie@spoton.co.in"
# FROM="mahesh.reddy@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "Cash HOTO Tab VS Manual Entry Report 3" + " - " + str(enddate)

report=""
report+="Dear All,"
report+='<br>'
report+='Please find the Cash HOTO Tab VS Manual Entry Report 3'
report+='<br>'
report+='Cash Delivery'
report+='<br>'
report+='<br>'+df5.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='Cash Pickup '
report+='<br>'
report+='<br>'+df51.to_html()+'<br>'
report+='<br>'


abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(filepath1,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
msg.attach(part1)


# server=smtplib.SMTP('smtp.sendgrid.net', 587)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("mahesh.reddy@spoton.co.in", "Nov@2018")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()


