
# coding: utf-8

# In[16]:


import numpy as np
import pandas as pd
# import matplotlib.pyplot as plt
# import seaborn
from glob import glob
from IPython import display
from datetime import datetime,timedelta
import pyodbc
# import geopy
import pandas as pd
import calendar
import os
import Utilities

# In[17]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=SQTeam;PWD=eSp0T@321$Sq")
cursor = cnxn.cursor()


# In[18]:


query= """ EXEC USP_STOCK_SQ_Raghav   """ 


# In[19]:


DATA=pd.read_sql(query,Utilities.cnxn)


# # email  ############################## 

# In[20]:


from pandas import ExcelWriter
# with ExcelWriter(r"D:\Data\OverAll_Stock\STOCK_SQ.xlsx") as writer:
#     DATA.to_excel(writer, sheet_name='DATA',
#                      engine='xlsxwriter',startrow=0 , startcol=0)

DATA.to_csv(r"D:\Data\OverAll_Stock\STOCK_SQ.csv")
# In[21]:


filepath=(r'D:\Data\OverAll_Stock\STOCK_SQ.csv')


# In[22]:


import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback
from glob import glob
from IPython import display
from datetime import datetime,timedelta
import pyodbc

date=datetime.strftime(datetime.now(),'%Y-%m-%d-%H')



oppath1=filepath
#FTP Upload starts
print ('Logging in...')
ftp = ftplib.FTP()  
ftp.connect('10.109.230.50')  
print (ftp.getwelcome())

try:
 try:
     ftp.login('HOSQTeam', 'Te@mH0$q')
     print ('login done')
     ftp.cwd('Auto_reports')
     #ftp.cwd('FIFO')
     # move to the desired upload directory
     print ("Currently in:", ftp.pwd())
     print ('Uploading...')
     fullname = oppath1
     name = os.path.split(fullname)[1]
     f = open(fullname, "rb")
     ftp.storbinary('STOR ' + name, f)
     f.close()
     print ("OK"  )
     print ("Files:")
     print (ftp.retrlines('LIST'))
 finally:
     print ("Quitting...")
     ftp.quit()
except:
    traceback.print_exc()
    
#date=datetime.strftime(datetime.now(),'%Y-%m-%d %H:%M:%S')


# ----------- E M A I L --------------------------    
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template                    



# TO=['sanjana.narayana@spoton.co.in']
TO=['shivananda.p@spoton.co.in', 'raghavendra.rao@spoton.co.in','anitha.thyagarajan@spoton.co.in']

FROM="mis.ho@spoton.co.in"

BCC = ['sanjana.narayana@spoton.co.in']




msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["Bcc"] = ",".join(BCC)

msg["Subject"] = "Overall Stock" + " - " + str(date)
html='''<html>
<style>        
p
 {
   margin:0;
   margin-top: 5px;
   padding:0;
   font-size:15px;
   line-height:20px;
 }
</style>                


'''
html3='''
<h5> To download the data, Please click the link below </h5>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/STOCK_SQ.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/STOCK_SQ.csv</p></b>
'''
report=""
report+='<br>'
report+='Dear All,'
report+='<br>'
report+='<br>'
report+=' PFA, Overall Stock Data ' + " - " + str(date)

report+='<br>'
report+='<br>'
report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)
# part = MIMEBase('application', "octet-stream")
# part.set_payload( open(oppath1,"rb").read() )
# encoders.encode_base64(part)
# part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
# msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login('spoton.net.in', 'Star@123#')
failed = server.sendmail(FROM, TO+BCC, msg.as_string())
print ('mail sent')
server.quit()

