
# coding: utf-8

# In[1]:

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import calendar
import datetime
from pandas import ExcelWriter
# -- coding: utf-8 --
import os
import traceback
import math
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import sys
from email import encoders
#reload(sys)
#sys.setdefaultencoding("UTF8")
import traceback
import ftplib


# In[2]:

"""
def save_xls(list_dfs, name_dfs, xls_path):
   i = 0
   writer = ExcelWriter(xls_path)   
   for dataframe in list_dfs:
       sheetname = name_dfs[i]
       dataframe.to_excel(writer, sheetname, merge_cells = True,engine='xlsxwriter')
       i = i+1
   writer.save()
"""
now = datetime.datetime.now()
today = now.strftime("%a")
print today
# In[3]:

oppath1 = (r'D:\Data\Onetime_Mispickups_rawfiles\Summary_Mispickups_Dec16.xlsx')
#oppath2 = (r'C:\Data\eMispickups\March_16_MTD\Cancelled_Mispickups_May16_11.csv')

#if today =='Mon':
#    print 'Its Monday !! Do you have to do that??! '
#    cancelled = pd.read_csv(r'http://www.spoton.co.in/downloads/pickupMonday_dontrun.csv')   
#else:
##cancelled = pd.read_csv(r'http://10.109.230.50/downloads/pickup/Pickup_CurMonth_Onetime_Cancel.csv')
cancelled = pd.read_csv(r'D:\Data\Onetime_Mispickups_rawfiles\Cancelled\Cancelled_2017-01-01_13.0.csv')
##$$cancelled = pd.read_csv(r'http://www.spoton.co.in/downloads/pickup1/Dec/Pickup_CurMonth_Onetime_Cancel.csv')


#####cancelled['CustCode'] = cancelled['CustCode'].str.replace('/','-')
#cancelled = cancelled.replace({'/':''},regex=True) 

parentcodesstr = ['000111752','000102793','000111753','000111738','000116867','000108779','000108158','000116964','000117197','000111500','000110163','000110740','000110162','000110759','000094305','000111492','000110379','000106128','000110761','000115324','000116884','000112020','000117017','000113938','000113940','000110760','000111382','000115331','000113888','000111044','000114808','000114083','000116382','000115133','000111554','000108238']

parentcodesfloat = [111752.0,102793.0,111753.0,111738.0,116867.0,108779.0,108158.0,116964.0,117197.0,111500.0,110163.0,110740.0,110162.0,110759.0,094305.0,111492.0,110379.0,106128.0,110761.0,115324.0,116884.0,112020.0,117017.0,113938.0,113940.0,110760.0,111382.0,115331.0,113888.0,111044.0,114808.0,114083.0,116382.0,115133.0,111554.0,108238.0]

cancelled=cancelled[cancelled['PartyType']!='HO TNT']
print len(cancelled)
cancelled = cancelled[cancelled['PTCD']!='000105055']
cancelled = cancelled[~cancelled['PTCD'].isin(parentcodesstr)]
#cancelled.to_csv(r'D:\Python\Scripts and Files\Path and Graph Files\Cancelled_dupsremove.csv')
print len(cancelled)
cancelled=cancelled[cancelled['Reason']!='Duplicate Order'] #to remove duplicates
cancelledunique = cancelled.drop_duplicates(subset='REFNO')

##success = pd.read_csv(r'http://10.109.230.50/downloads/pickup/Pickup_CurMonth_Onetime_Success.csv')
success = pd.read_csv(r'D:\Data\Onetime_Mispickups_rawfiles\Success\Success_2017-01-01_13.0.csv')
##$$success = pd.read_csv(r'http://www.spoton.co.in/downloads/pickup1/Dec/Pickup_CurMonth_Onetime_Success.csv')

#success = success.replace({'/':''},regex=True)

#####success['CustCode'] = success['CustCode'].replace('/','-',inplace=True)
success=success[success['PartyType']!='HO TNT']
success = success[success['PTCD']!=105055.0]
success = success[~success['PTCD'].isin(parentcodesfloat)]
successunique = success.drop_duplicates(subset='REFNO')


branchdf = pd.read_csv('D:\Python\Scripts and Files\Path and Graph Files\Branchlist.csv')
branchdf = pd.DataFrame(branchdf,columns=['BRANCH CODE','Depot','Region'])


# In[4]:

def getunique(x):
    a = list(set(x))
    return len(a)

def getlist(x):
    a = set(x)
    return a


# In[5]:

cancelledPivot = cancelledunique.groupby(['ScheduleDate','BRCD','CustCode','Pincode']).agg({'REFNO': lambda x: getunique(x)}).reset_index()
successPivot = successunique.groupby(['ScheduleDate','BRCD','CustCode','Pincode']).agg({'REFNO': lambda x: getunique(x),'Docketno': lambda x: getunique(x),'Pickupdate': lambda x: getlist(x)}).reset_index()


# <b> Datetime Conversions </b>

# In[6]:

def getdate(x): 
    a = x.split(' ')[0]
    date_object = datetime.datetime.strptime(a,'%d-%m-%Y')
    mondigit = date_object.month
    month = calendar.month_abbr[mondigit]
    return month
    
def datestring(x):
    a = x.split(' ')[0]
    fulldate = datetime.datetime.strptime(a,'%d-%m-%Y')
    #fulldate = pd.to_datetime(date1, '%Y-%m-%d')
    #print type(fulldate)
    return fulldate
    


# In[7]:

totalPivot = pd.merge(cancelledPivot,successPivot, on = ['ScheduleDate','BRCD','CustCode','Pincode'], suffixes = ['Cancel','Success'],how = 'outer')
###totalPivot['Month'] = totalPivot.apply(lambda x: getdate(x['ScheduleDate']),axis = 1)


# In[8]:

iz = totalPivot[totalPivot['REFNOCancel']>=1].index
ix = totalPivot[totalPivot['REFNOSuccess']>=1][totalPivot['REFNOCancel']>=1].index
iy = totalPivot[totalPivot['REFNOSuccess']>=1].index


# In[9]:

totalPivot.loc[totalPivot.index,'ActSuccess'] = 0
totalPivot.loc[iy,'ActSuccess'] = 1

totalPivot.loc[totalPivot.index,'ActFailure'] = 0
totalPivot.loc[iz,'ActFailure'] = 1
totalPivot.loc[ix,'ActFailure'] = 0
totalPivot=pd.merge(totalPivot,branchdf,left_on=['BRCD'],right_on=['BRANCH CODE'], how = 'inner')
###totalPivot.to_csv('C:\Data\Mispickups\Sep\Sep_forshiv\mergetotalpbrcd_sto19oct.csv')


# <b>For vendor wise MTD </b>

# In[10]:

totalPivotfail = totalPivot[(totalPivot['ActFailure']==1)]
totalPivotsucc = totalPivot[(totalPivot['ActSuccess']==1)]

orginal_cancel_basedata=pd.merge(totalPivotfail,cancelledunique,on=['ScheduleDate','BRCD','CustCode','Pincode'],left_index=True,how='left')
orginal_success_basedata=pd.merge(totalPivotsucc,successunique,on=['ScheduleDate','BRCD','CustCode','Pincode'],left_index=True,how='left')


orginal_cancel_basedata=orginal_cancel_basedata.drop_duplicates(['ScheduleDate','BRCD','CustCode','Pincode'])

#External and Internal Category addition

extlist = ['PICKUP LOST - EXTERNAL','CS CANCELLATION - EXTERNAL','PICKUP LOST - NON CONTROLLABLE']
def getintext(x):
    if x in extlist:
        return 'External'
    else:
        return 'Internal'

orginal_cancel_basedata['Cancellation_category'] = orginal_cancel_basedata.apply(lambda x: getintext(x['FINAL_STATUS']),axis = 1)

#External and Internal Category addition

##orginal_cancel_basedata.to_csv(r'C:\Data\eMispickups\Feb16\Cancelled_Mispickups_Apr16_25th.csv')

orginal_success_basedata=orginal_success_basedata.drop_duplicates(['ScheduleDate','BRCD','CustCode','Pincode'])


orginal_cancel_vendor=orginal_cancel_basedata.groupby(['forward_toname','BRCD']).agg({'REFNO': 'count'}).reset_index()
orginal_success_vendor=orginal_success_basedata.groupby(['forward_toname','BRCD']).agg({'REFNO': 'count'}).reset_index()

merge_vendor=pd.merge(orginal_success_vendor,orginal_cancel_vendor,on=['forward_toname','BRCD'],suffixes = ['Success','Cancel'],how='outer')
merge_vendor = merge_vendor.fillna(0)

merge_vendor['Failure_Rate%']= np.round(merge_vendor.apply(lambda x: (((x['REFNOCancel'])*1.0/((x['REFNOCancel'])+(x['REFNOSuccess'])))*100),axis = 1),2)
merge_vendor = merge_vendor.sort_values(['REFNOCancel', 'Failure_Rate%'], ascending=False)

##@@merge_vendor.to_csv(r'C:\Data\eMispickups\Final_report\vndormtd.csv')
orginal_cancel_basedata.to_csv(r'D:\Data\Onetime_Mispickups_rawfiles\orginal_cancel_basedata.csv')
orginal_success_basedata.to_csv(r'D:\Data\Onetime_Mispickups_rawfiles\orginal_success_basedata.csv')

# <b>For vendor wise Yesterday </b>

# In[11]:

datetoday=datetime.datetime.today()
datefilter = datetoday-timedelta(hours=720)
datefilter=datefilter.date()
print datefilter
filterday1 = datetime.datetime.strftime(datefilter,'%d/%m/%Y')

print orginal_cancel_basedata['ScheduleDate'].values[0]

yorginal_cancel_basedata = orginal_cancel_basedata[orginal_cancel_basedata['ScheduleDate']==filterday1]
print len(yorginal_cancel_basedata)
yorginal_succes_basedata = orginal_success_basedata[orginal_success_basedata['ScheduleDate']==filterday1]
print len(yorginal_succes_basedata)
yorginal_cancel_basedata.to_csv(r'D:\Data\Onetime_Mispickups_rawfiles\yorginal_cancel_basedata.csv')
yorginal_succes_basedata.to_csv(r'D:\Data\Onetime_Mispickups_rawfiles\yorginal_succes_basedata.csv')


yorginal_cancel_vendor=yorginal_cancel_basedata.groupby(['forward_toname','BRCD']).agg({'REFNO': 'count'}).reset_index()
yorginal_success_vendor=yorginal_succes_basedata.groupby(['forward_toname','BRCD']).agg({'REFNO': 'count'}).reset_index()

ymerge_vendor=pd.merge(yorginal_success_vendor,yorginal_cancel_vendor,on=['forward_toname','BRCD'],suffixes = ['Success','Cancel'],how='outer')

### Filling the dataframe with zero in order to avoid not dividing when either cancelled or success is zero
ymerge_vendor = ymerge_vendor.fillna(0)

ymerge_vendor['Failure_Rate%']=np.round(ymerge_vendor.apply(lambda x: (((x['REFNOCancel'])*1.0/((x['REFNOCancel'])+(x['REFNOSuccess'])))*100),axis = 1),2)
ymerge_vendor = ymerge_vendor.sort_values(['REFNOCancel', 'Failure_Rate%'], ascending=False)

###ymerge_vendor.to_csv(r'C:\Data\Mispickups\Sep\Mispickup_report\test\ymergeccansucc.csv')

totalvendor_merge = pd.merge(merge_vendor, ymerge_vendor, on=['forward_toname','BRCD'],suffixes = ['_MTD','_Yday'],how='outer')
##@@totalvendor_merge.to_csv(r'C:\Data\eMispickups\Sep\Sepforshiv\VendorWise_Mispickups_Sep15.csv')

# <b> For Saving Cancellations and Success to local folders </b>

# In[47]:

#orginal_cancel_basedata.to_csv(r'D:\\Data\\eta_rank\\Mispickups_archives\\mispickups_cancellations\\Cancelled_Mispickups-'+str(datefilter)+'.csv',encoding="utf-8")
#orginal_success_basedata.to_csv(r'D:\\Data\\eta_rank\\Mispickups_archives\\mispickups_success\\Success_Orders-'+str(datefilter)+'.csv',encoding="utf-8")


# <b> To calculate Customerwise MTD data </b>

# In[12]:

orginal_cancel_cust=orginal_cancel_basedata.groupby(['BRCD','CustCode','PartyType']).agg({'REFNO': 'count'}).reset_index()
orginal_success_cust=orginal_success_basedata.groupby(['BRCD','CustCode','PartyType']).agg({'REFNO': 'count'}).reset_index()

merge_cust=pd.merge(orginal_success_cust,orginal_cancel_cust,on=['BRCD','CustCode','PartyType'],suffixes = ['Success','Cancel'],how='outer')
merge_cust['Failure_Rate%']= np.round(merge_cust.apply(lambda x:(((x['REFNOCancel'])*1.0/((x['REFNOCancel'])+(x['REFNOSuccess'])))*100),axis = 1),2)
merge_cust = merge_cust.sort_values(['REFNOCancel', 'Failure_Rate%'], ascending=False)

##merge_cust.to_csv(r'C:\Data\Mispickups\Sep\Mispickup_report\test\mergeccansucc_custmtd.csv')


# <b> To calculate Customerwise Yesterday data </b>

# In[13]:

yorginal_cancel_cust=yorginal_cancel_basedata.groupby(['BRCD','CustCode','PartyType']).agg({'REFNO': 'count'}).reset_index()
yorginal_success_cust=yorginal_succes_basedata.groupby(['BRCD','CustCode','PartyType']).agg({'REFNO': 'count'}).reset_index()

ymerge_cust=pd.merge(yorginal_success_cust,yorginal_cancel_cust,on=['BRCD','CustCode','PartyType'],suffixes = ['Success','Cancel'],how='outer')
ymerge_cust['Failure_Rate%']= np.round(ymerge_cust.apply(lambda x: (((x['REFNOCancel'])*1.0/((x['REFNOCancel'])+(x['REFNOSuccess'])))*100),axis = 1),2)
ymerge_cust = ymerge_cust.sort_values(['REFNOCancel', 'Failure_Rate%'], ascending=False)

##ymerge_cust.to_csv(r'C:\Data\Mispickups\Sep\Mispickup_report\test\ymergeccansucc_cust.csv')

totalcust_merge = pd.merge(merge_cust, ymerge_cust, on=['BRCD','CustCode','PartyType'],suffixes = ['_MTD','_Yday'],how='outer')
##@@totalcust_merge.to_csv(r'C:\Data\eMispickups\Sep\Sepforshiv\CustomerWise_Mispickups_Sep15.csv')


# <b> To calculate Region DepotWise MTD data </b>

# In[14]:
"""
orginal_cancel_rdwise=orginal_cancel_basedata.groupby(['Region','Depot']).agg({'REFNO': 'count'}).reset_index()
orginal_success_rdwise=orginal_success_basedata.groupby(['Region','Depot']).agg({'REFNO': 'count'}).reset_index()

merge_rdwise=pd.merge(orginal_success_rdwise,orginal_cancel_rdwise,on=['Region','Depot'],suffixes = ['Success','Cancel'],how='outer')
merge_rdwise['Failure_Rate%']= np.round(merge_rdwise.apply(lambda x:(((x['REFNOCancel'])*1.0/((x['REFNOCancel'])+(x['REFNOSuccess'])))*100),axis = 1),2)

##merge_rdwise.to_csv(r'C:\Data\Mispickups\Sep\Mispickup_report\test\mergeccansucc_rdwise.csv')


# <b> To calculate Region DepotWise Yesterday data </b>

# In[40]:

yorginal_cancel_rdwise=yorginal_cancel_basedata.groupby(['Region','Depot']).agg({'REFNO': 'count'}).reset_index()
yorginal_success_rdwise=yorginal_succes_basedata.groupby(['Region','Depot']).agg({'REFNO': 'count'}).reset_index()

ymerge_rdwise=pd.merge(yorginal_success_rdwise,yorginal_cancel_rdwise,on=['Region','Depot'],suffixes = ['Success','Cancel'],how='outer')
ymerge_rdwise['Failure_Rate%']= np.round(ymerge_rdwise.apply(lambda x: (((x['REFNOCancel'])*1.0/((x['REFNOCancel'])+(x['REFNOSuccess'])))*100),axis = 1),2)

##ymerge_rdwise.to_csv(r'C:\Data\Mispickups\Sep\Mispickup_report\test\ymergeccansucc_rdwise.csv')

totalrdwise_merge = pd.merge(merge_rdwise, ymerge_rdwise, on=['Region','Depot'],suffixes = ['_MTD','_Yday'],how='outer')


totalrdwise_merge['Total_MTD'] = totalrdwise_merge.apply(lambda x: ((x['REFNOCancel_MTD'])+(x['REFNOSuccess_MTD'])),axis = 1)
totalrdwise_merge['Total_Yday'] = totalrdwise_merge.apply(lambda x: ((x['REFNOCancel_Yday'])+(x['REFNOSuccess_Yday'])),axis = 1)
totalrdwise_merge = totalrdwise_merge[['Region','Depot', 'REFNOSuccess_MTD','REFNOCancel_MTD','Total_MTD','Failure_Rate%_MTD','REFNOSuccess_Yday','REFNOCancel_Yday','Total_Yday','Failure_Rate%_Yday']]

#### MTD success and failure
mtdsuccess = totalrdwise_merge['REFNOSuccess_MTD'].sum()
mtdcancel = totalrdwise_merge['REFNOCancel_MTD'].sum()
totalmtd = mtdsuccess+mtdcancel

mtdfailure = np.round(((mtdcancel)*1.0/(mtdcancel+mtdsuccess)*100),2)

ydaysuccess = totalrdwise_merge['REFNOSuccess_Yday'].sum()
ydaycancel = totalrdwise_merge['REFNOCancel_Yday'].sum()
totalyday = ydaysuccess+ydaycancel

ydayfailure = np.round(((ydaycancel)*1.0/(ydaycancel+ydaysuccess)*100),2)


extfailuremtd = len(orginal_cancel_basedata[orginal_cancel_basedata['Cancellation_category']=='External'])
try:
    intfailuremtd = len(orginal_cancel_basedata[orginal_cancel_basedata['Cancellation_category']=='Internal'])
except:
    print 'No Internal failures 1'

extfailureyday = len(orginal_cancel_basedata[(orginal_cancel_basedata['Cancellation_category']=='External') & (orginal_cancel_basedata['ScheduleDate']==filterday1)])
try:
    intfailureyday = len(orginal_cancel_basedata[(orginal_cancel_basedata['Cancellation_category']=='Internal') & (orginal_cancel_basedata['ScheduleDate']==filterday1)])
except:
    print 'No Internal failures 2'
#### MTD success and failure


# In[41]:

####Only for Displaying in Mail body Start

mail_totalrdwise_merge = totalrdwise_merge.drop(['Total_MTD','Total_Yday'],axis=1)
mail_totalrdwise_merge

"""
####Only for Displaying in Mail body End

##### BRRANCH WISE - TEMPORARY
extlist = ['PICKUP LOST - EXTERNAL','CS CANCELLATION - EXTERNAL','PICKUP LOST - NON CONTROLLABLE']

orginal_cancel_basedata['Cancellation_category'] = orginal_cancel_basedata.apply(lambda x: getintext(x['FINAL_STATUS']),axis = 1)
#orginal_success_basedata['Cancellation_category'] = orginal_success_basedata.apply(lambda x: getintext(x['FINAL_STATUS']),axis = 1)

orginal_cancel_brcd=orginal_cancel_basedata.groupby(['BRCD','Cancellation_category']).agg({'REFNO': 'count'}).reset_index()
orginal_success_brcd=orginal_success_basedata.groupby(['BRCD']).agg({'REFNO': 'count'}).reset_index()

merge_brcd=pd.merge(orginal_success_brcd,orginal_cancel_brcd,on=['BRCD'],suffixes = ['Success','Cancel'],how='outer')
merge_brcd['Failure_Rate%']= np.round(merge_brcd.apply(lambda x: (((x['REFNOCancel'])*1.0/((x['REFNOCancel'])+(x['REFNOSuccess'])))*100),axis = 1),2)
merge_brcd = merge_brcd.sort_values(['REFNOCancel', 'Failure_Rate%'], ascending=False)

##@@merge_vendor.to_csv(r'C:\Data\eMispickups\Final_report\vndormtd.csv')

yorginal_cancel_basedata = orginal_cancel_basedata[orginal_cancel_basedata['ScheduleDate']==filterday1]
yorginal_succes_basedata = orginal_success_basedata[orginal_success_basedata['ScheduleDate']==filterday1]


yorginal_cancel_brcd=yorginal_cancel_basedata.groupby(['BRCD','Cancellation_category']).agg({'REFNO': 'count'}).reset_index()
yorginal_success_brcd=yorginal_succes_basedata.groupby(['BRCD']).agg({'REFNO': 'count'}).reset_index()

ymerge_brcd=pd.merge(yorginal_success_brcd,yorginal_cancel_brcd,on=['BRCD'],suffixes = ['Success','Cancel'],how='outer')
ymerge_brcd['Failure_Rate%']=np.round(ymerge_brcd.apply(lambda x: (((x['REFNOCancel'])*1.0/((x['REFNOCancel'])+(x['REFNOSuccess'])))*100),axis = 1),2)
ymerge_brcd = ymerge_brcd.sort_values(['REFNOCancel', 'Failure_Rate%'], ascending=False)

###ymerge_vendor.to_csv(r'C:\Data\Mispickups\Sep\Mispickup_report\test\ymergeccansucc.csv')

totalbrcd_merge = pd.merge(merge_brcd, ymerge_brcd, on=['BRCD'],suffixes = ['_MTD','_Yday'],how='outer')


##### BRRANCH WISE - TEMPORARY

# In[16]:
# <b> To calculate Schedule date </b>

# In[14]:

orginal_cancel_rdwisedate=orginal_cancel_basedata.groupby(['ScheduleDate','BRCD']).agg({'REFNO': 'count'}).reset_index()
orginal_success_rdwisedate=orginal_success_basedata.groupby(['ScheduleDate','BRCD']).agg({'REFNO': 'count'}).reset_index()

merge_rdwisedate=pd.merge(orginal_success_rdwisedate,orginal_cancel_rdwisedate,on=['ScheduleDate','BRCD'],suffixes = ['Success','Cancel'],how='outer')
merge_rdwisedate['Failure_Rate%']= np.round(merge_rdwisedate.apply(lambda x:(((x['REFNOCancel'])*1.0/((x['REFNOCancel'])+(x['REFNOSuccess'])))*100),axis = 1),2)

##merge_rdwise.to_csv(r'C:\Data\Mispickups\Sep\Mispickup_report\test\mergeccansucc_rdwise.csv')


# <b> To calculate Schedule date Yesterday data </b>

# In[40]:

yorginal_cancel_rdwisedate=yorginal_cancel_basedata.groupby(['ScheduleDate','BRCD']).agg({'REFNO': 'count'}).reset_index()
yorginal_success_rdwisedate=yorginal_succes_basedata.groupby(['ScheduleDate','BRCD']).agg({'REFNO': 'count'}).reset_index()

ymerge_rdwisedate=pd.merge(yorginal_success_rdwisedate,yorginal_cancel_rdwisedate,on=['ScheduleDate','BRCD'],suffixes = ['Success','Cancel'],how='outer')
ymerge_rdwisedate['Failure_Rate%']= np.round(ymerge_rdwisedate.apply(lambda x: (((x['REFNOCancel'])*1.0/((x['REFNOCancel'])+(x['REFNOSuccess'])))*100),axis = 1),2)

##ymerge_rdwise.to_csv(r'C:\Data\Mispickups\Sep\Mispickup_report\test\ymergeccansucc_rdwise.csv')

totalrdwise_mergedate = pd.merge(merge_rdwisedate, ymerge_rdwisedate, on=['ScheduleDate','BRCD'],suffixes = ['_MTD','_Yday'],how='outer')


totalrdwise_mergedate['Total_MTD'] = totalrdwise_mergedate.apply(lambda x: ((x['REFNOCancel_MTD'])+(x['REFNOSuccess_MTD'])),axis = 1)
totalrdwise_mergedate['Total_Yday'] = totalrdwise_mergedate.apply(lambda x: ((x['REFNOCancel_Yday'])+(x['REFNOSuccess_Yday'])),axis = 1)
totalrdwise_mergedate = totalrdwise_mergedate[['ScheduleDate','BRCD', 'REFNOSuccess_MTD','REFNOCancel_MTD','Total_MTD','Failure_Rate%_MTD','REFNOSuccess_Yday','REFNOCancel_Yday','Total_Yday','Failure_Rate%_Yday']]

# In[42]:

with ExcelWriter(r'D:\Data\Onetime_Mispickups_rawfiles\Summary_Mispickups_Dec16.xlsx') as writer:
    totalrdwise_mergedate.to_excel(writer, sheet_name='Schedule_datewise',engine='xlsxwriter')
    totalvendor_merge.to_excel(writer, sheet_name='VENDOR_WISE',engine='xlsxwriter')
    totalcust_merge.to_excel(writer, sheet_name='CUSTOMER_WISE',engine='xlsxwriter')
    totalbrcd_merge.to_excel(writer, sheet_name='BRCD_WISE',engine='xlsxwriter')
    writer.save()


# In[18]:
"""
ftp = ftplib.FTP()
ftp.connect('10.109.250.50')
#print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        #print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppath2
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        #print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        #print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()
"""

# In[43]:

filePath = oppath1
def sendEmail(#TO = ["ashwani.gangwar@spoton.co.in","trilochan.panda@spoton.co.in","sunil.nakte@spoton.co.in","shivananda.p@spoton.co.in","rom_spot@spoton.co.in","dom_spot@spoton.co.in","aom_spot@spoton.co.in","chandrima.banerjee@spoton.co.in","raghavendra.rao@spoton.co.in"],
            #TO = ["rajeesh.vr@spoton.co.in","shivananda.p@spoton.co.in"],
            CC = ["vishwas.j@spoton.co.in"],
            TO = ["vishwas.j@spoton.co.in"],
             #CC = ["sqtf@spoton.co.in","sq_spot@spoton.co.in","supratim@iepfunds.com","abhik.mitra@spoton.co.in","Ankit@iepfunds.com","uday.sharma@spoton.co.in","rajesh.kumar@spoton.co.in","pawan.sharma@spoton.co.in","nikhil.saxena@spoton.co.in","jitendra.jog@spoton.co.in","vishwas.j@spoton.co.in","rajeesh.vr@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "Onetime Mispickups Report MTD & as on - "+str(filterday1)
    body_text = """
    Dear All,

    The Onetime Mispickup Failure rate for MTD is """+str(0)+ """% and for Yesterday is """+str(0)+"""%   
    
    PFA the Onetime Mispickups Report as of """+str(filterday1)+"""
    
    Depot-Wise Onetime Mispickups Report
    

    
    The data for cancellations can be downloaded from the below link and this link will be published along with the report everyday

    http://spoton.co.in/downloads/IEProjects/ETA/Cancelled_Mispickups.csv
    
    Note:
    1) An instance of success or cancelled onetime pickup is defined as unique combination of Customer, SC Branch, Schedule date and Pincode
    2) A pickup order is considered to be a success if there is atleast 1 pickup  against the combination mentioned above
    3) A pickup order is considered to be a failure if there is no pickup done against the combination mentioned above
    4) All the cancelled orders for the above combination is considered irrespective of the author of cancellation
    5) The open/rescheduled orders are not considered and eventually this will be considered when the order no reaches a conclusion of success or cancellation
    6) TNT has been excluded from this report     
    
    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
mailend = datetime.datetime.now().time()
print 'mailend is', mailend

#
## Email only for Shivanand
#
##recipients = ["shivananda.p@spoton.co.in","vishwas.j@spoton.co.in"]
#recipients = ["vishwas.j@spoton.co.in"]
#sender = "vishwas.j@spoton.co.in"
#subject = "Onetime Mispickup Report Summary - "+str(filterday1)
#body = """
#Dear Shiv,
#    Please find below the Mispickup figures as of MTD and of """+str(filterday1)+"""
#    
#    Total orders MTD = """+str(totalmtd) +"""
#    Orders success MTD = """+str(mtdsuccess)+"""
#    Orders cancel MTD = """+str(mtdcancel)+"""
#    External Cancel MTD = """+str(extfailuremtd)+"""
#    Internal Cancel MTD = """+str(intfailuremtd)+"""
#    MTD Failure % = """+str(mtdfailure)+"""
#    Total orders Yday = """+str(totalyday)+"""
#    Orders success Yday = """+str(ydaysuccess)+"""
#    Orders Cancel Yday = """+str(ydaycancel)+"""
#    Yday Failure % = """+str(ydayfailure)+"""
#    External Cancel Yday = """+str(extfailureyday)+"""
#    Internal Cancel Yday = """+str(intfailureyday)+"""
#
#"""
#
## make up message
#msg = MIMEText(body)
#msg['Subject'] = subject
#msg['From'] = sender
#msg['To'] = ", ".join(recipients)
#
## sending
#session = smtplib.SMTP('smtp.spoton.co.in', 587)
#session.starttls()
#session.login(sender, 'Spoton#123')
#send_it = session.sendmail(sender, recipients, msg.as_string())
#session.quit()
#
## Email only for Shivanand
