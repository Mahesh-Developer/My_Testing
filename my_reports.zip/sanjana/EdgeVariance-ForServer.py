
# coding: utf-8

# In[1]:

import sframe as gl
import sframe.aggregate as agg

# import graphlab as gl
# import graphlab.aggregate as agg

import numpy as np
from datetime import datetime, timedelta
from itertools import repeat,imap
import copy
import pandas as pd
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import os
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
# In[2]:

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()
query = ("""EXEC USP_CONDATE_CEM_CATEGORY_IEP """)
print (query)
# condata=pd.read_sql(query,cnxn)
# print (len(condata))
# condata.rename(columns={'Customer Code':'Customer_Code','Customer Name':'Customer_Name'},inplace=True)
ipfilename = r'D:\Python\Scripts and Files\Path and Graph Files\Edge_variance_files\instruction_v30input.csv'


# In[3]:

#condata = gl.SFrame(masters+'/Feb Condata.csv')
condata = gl.SFrame('http://spoton.co.in/downloads/IEP_CONDATA_CEM_CATEGORY/IEP_CONDATA_CEM_CATEGORY.csv')


# In[4]:

dayzero = datetime.strptime('01/01/2016','%d/%m/%Y')
timeformat1 = '%m-%d-%Y'
timeformat2 = '%m/%d/%Y'  
timeformat3 = '%m-%d-%Y'
separator = " "
def convertdate2(x,y,z): 
    try:       
        x = str(x).split(separator)[0]
        return datetime.strptime(x,y)
    except:
        try:
            x = str(x).split(separator)[0]
            return datetime.strptime(x,z)
        except:
            return dayzero

condata['Pickupdate'] = condata['Pickupdate'].apply(lambda x: convertdate2(x,timeformat1, timeformat2))


# In[5]:

condata = condata[condata['Pickupdate']>datetime.strptime('01/07/2016','%d/%m/%Y')]
# condata = condata.rename({'Origin_area': 'Org_Area'})
condata = condata.rename(columns={'Origin_area': 'Org_Area'})
# condata.rename({'\xef\xbb\xbfDOCKNO':'DOCKNO'})


# In[6]:

totaldayslist = condata['Pickupdate'].unique()
workingdaylist = [i for i in totaldayslist if i.weekday()!=6]
workingdays = len(workingdaylist)
#print workingdays
td = len(totaldayslist)


# In[7]:

brsf = gl.SFrame.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\Edge_variance_files\brsf38.csv')
try:
    brlist = {}
    for ele in zip(brsf['areakey'],brsf['arealist']):
        brlist.update({ele[0]:ele[1]})
except:
    print 'brsf error'


# In[8]:

def getopp(x):
    if x=='YES':
        return 1
    else:
        return 0
condata['OPP'] = condata.apply(lambda x: getopp(x['OPP']))
condata['Reach'] = condata.apply(lambda x: getopp(x['Reach']))


# In[9]:

scgrp = condata.groupby(['Orgin','Destn'],{'ACTUAL_WEIGHT':agg.SUM('ACTUAL_WEIGHT'),'Con': agg.COUNT_DISTINCT('DOCKNO'),'Reach': agg.SUM('Reach'),'Volume': agg.SUM('VOLUME')})
scgrp['AdjWt'] = scgrp.apply(lambda x: max(x['ACTUAL_WEIGHT'],0))


# In[10]:

condata['day'] = condata.apply(lambda x: int(str(x['Pickupdate']).split(" ")[0].split("-")[2]))


# In[11]:

dayfilter = (datetime.today()-timedelta(days=1)).date().day
#dayfilter = int(datetime.strftime((datetime.today()-timedelta(days=1)),"%d"))
print dayfilter
condata2 = condata[condata['day']==dayfilter]
len(condata2)


# In[12]:

scgrp2 = condata2.groupby(['Orgin','Destn'],{'ACTUAL_WEIGHT':agg.SUM('ACTUAL_WEIGHT'),'Con': agg.COUNT_DISTINCT('DOCKNO'),'Reach': agg.SUM('Reach'),'Volume': agg.SUM('VOLUME')})
scgrp2['AdjWt'] = scgrp2.apply(lambda x: max(x['ACTUAL_WEIGHT'],0))


# In[13]:

instructions = gl.SFrame.read_csv(ipfilename)
instructions['Origin'] = instructions.apply(lambda x: x['Origin'].split(','))
instructions['Destination'] = instructions.apply(lambda x: x['Destination'].split(','))
try:
    instructions['Path'] = instructions.apply(lambda x: x['Path'].split(','))
except:
    pass
#print len(instructions)


# In[14]:

instructiondict = {}
for instruction in instructions:
    instructiondict.update({(instruction['Origin'][0],instruction['Destination'][0]):instruction['Path']})


# In[15]:

routinglist1 = [i[0] for i in instructiondict.keys()]
routinglist2 = [i[1] for i in instructiondict.keys()]
routinglist = list(set(routinglist1+routinglist2))
brsfrouting = brsf.filter_by(routinglist,'areakey')


# In[16]:

def getpath(orgarea,destarea):
    try:
        pathlist = instructiondict.get((orgarea,destarea))
        orglist = pathlist[0:-1]
        destlist = pathlist[1:]
        retlist = []
        for i in range(0,len(pathlist)-1):
            retitem = [orglist[i],destlist[i]]
            retlist.append(retitem)
        return retlist
    except:
        #print orgarea,destarea
        return ['error']


# In[17]:

routingbranches = brsfrouting.stack('arealist',new_column_name='branch')
routingdict = {}
for branch,area in zip(routingbranches['branch'],routingbranches['areakey']):
    routingdict[branch] = area
scgrp['Org_area'] = scgrp.apply(lambda x: routingdict.get(x['Orgin']))
scgrp['Dest_area'] = scgrp.apply(lambda x: routingdict.get(x['Destn']))
areagrp = scgrp.groupby(['Org_area','Dest_area'],{'Wt': agg.SUM('AdjWt'),'Cons': agg.SUM('Con'),'Reach': agg.SUM('Reach')})
areagrp = areagrp.filter_by(routinglist,'Org_area').filter_by(routinglist,'Dest_area')
areagrp = areagrp[areagrp['Org_area']!=areagrp['Dest_area']]
areagrp['Path'] = areagrp.apply(lambda x: getpath(x['Org_area'],x['Dest_area']))
stackareagrp= areagrp.stack('Path','Edge')
edgesf = stackareagrp.groupby(['Edge'],{'Wt': agg.SUM('Wt'),'Cons': agg.SUM('Cons'),'Reach': agg.SUM('Reach')})


# In[18]:

edgesf2 = edgesf.dropna(columns=['Edge','Wt'])


# In[19]:

edgesf2['Origin'] = edgesf2.apply(lambda x: x['Edge'][0])
edgesf2['Destn'] = edgesf2.apply(lambda x: x['Edge'][1])


# In[20]:

edgesf2["Wt_day"]=edgesf2.apply(lambda x: round(x['Wt']/(workingdays)*1.0/1000,1))


# In[21]:

edgesf3 = edgesf2.select_columns(['Origin','Destn','Wt_day'])


# In[22]:

scgrp2['Org_area'] = scgrp2.apply(lambda x: routingdict.get(x['Orgin']))
scgrp2['Dest_area'] = scgrp2.apply(lambda x: routingdict.get(x['Destn']))
areagrp2 = scgrp2.groupby(['Org_area','Dest_area'],{'Wt': agg.SUM('AdjWt'),'Cons': agg.SUM('Con'),'Reach': agg.SUM('Reach')})


# In[23]:

areagrp2 = areagrp2.filter_by(routinglist,'Org_area').filter_by(routinglist,'Dest_area')
areagrp2 = areagrp2[areagrp2['Org_area']!=areagrp2['Dest_area']]
areagrp2['Path'] = areagrp2.apply(lambda x: getpath(x['Org_area'],x['Dest_area']))
stackareagrp2= areagrp2.stack('Path','Edge')
yestedge = stackareagrp2.groupby(['Edge'],{'Wt': agg.SUM('Wt'),'Cons': agg.SUM('Cons'),'Reach': agg.SUM('Reach')})


# In[24]:

yestedge2 = yestedge.dropna(columns=['Edge','Wt'])
yestedge2['Origin'] = yestedge2.apply(lambda x: x['Edge'][0])
yestedge2['Destn'] = yestedge2.apply(lambda x: x['Edge'][1])
yestedge2["Wt_day"]=yestedge2.apply(lambda x: round(x['Wt']*1.0/1000,1))
yestedge3 = yestedge2.select_columns(['Origin','Destn','Wt_day'])


# In[26]:

lastmonthfilename = r'D:\Python\Scripts and Files\Path and Graph Files\Edge_variance_files\edgepart_Apr.csv' #the file nameto be named in this format edgepart_Month.csv. Dynamic usage of month name
febedge = gl.SFrame(lastmonthfilename)


# In[27]:

lastmonth= lastmonthfilename.split("edgepart_")[1].split('.')[0]


# In[28]:

febedge.head(2)


# In[29]:

febedge = febedge[['Origin','Destn','Wt_day']]


# In[30]:

mergedsf=febedge.join(edgesf3,on=["Origin","Destn"],how='outer').join(yestedge3,on=["Origin","Destn"],how='outer')
len(mergedsf)


# In[31]:
mergedsf = mergedsf.fillna('Wt_day', 0)
mergedsf = mergedsf.fillna('Wt_day.1', 0)
mergedsf = mergedsf.fillna('Wt_day.2', 0)


# In[32]:

mergedsf2 = mergedsf.rename({'Wt_day':lastmonth,"Wt_day.1":"MTD","Wt_day.2":"Yest"})
mergedsf2.save(r'D:\Data\Edge_variance_report\Edge_Variance_debug.csv')

# In[33]:

mergedsf2['diff_Yst'] = mergedsf2.apply(lambda x: x["Yest"]-x[lastmonth])
mergedsf2['diff_MTD'] = mergedsf2.apply(lambda x: x["MTD"]-x[lastmonth])

datetoday = datetime.today()
datefilter = datetoday-timedelta(hours=24)
datefilter=datefilter.date()
datefilter
# In[34]:
mergedsf2_df = mergedsf2.to_dataframe()
mergedsf2_df.to_csv(r'D:\Data\Edge_variance_report\Summary\Edge_Variance_'+str(datefilter)+'.csv') #attachment
mergedsf2_df.to_csv(r'D:\Data\Edge_variance_report\Edge_Variance.csv') #attachment
oppath2 = r'D:\Data\Edge_variance_report\Edge_Variance.csv'
# In[35]:

mailsf1 = mergedsf2[(mergedsf2["diff_MTD"]>1)]
mailsf2 = mergedsf2[(mergedsf2["diff_MTD"]<-1)]
mailsf = mailsf1.append(mailsf2)
#or (mergedsf2["diff_MTD"]<-1)


# In[36]:
maildf = mailsf.to_dataframe()
maildf = maildf.to_string(index=False)
#mailsf.save("deviance.csv") #mailbody

exit(0)
filePath = oppath2
def sendEmail(#TO = ["ashwani.gangwar@spoton.co.in","krishna.kumar.bhardwaj@spoton.co.in","jaisingh.chauhan@spoton.co.in","joseph.arul.seelan@spoton.co.in","dhiraj.patil@spoton.co.in","krishan.kaushik@spoton.co.in","ramniwas.sharma@spoton.co.in","sopanrao.bhoite@spoton.co.in","ramachandran.p@spoton.co.in","manoj.pareek@spoton.co.in","pramod.pandey@spoton.co.in","surendra.pandey@spoton.co.in","onkar.sharma@spoton.co.in","ajay.kumar.singh@spoton.co.in","satyaprakash.vishwakarma@spoton.co.in","sandesh.patade@Spoton.co.in","cnm@spoton.co.in","cstl_spot@spoton.co.in"],
            TO = ["rajeesh.vr@spoton.co.in"],
            #TO = ["vishwas.j@spoton.co.in"],
            CC = ["vishwas.j@spoton.co.in"],
            #CC = ["sqtf@spoton.co.in","sq_spot@spoton.co.in","supratim@iepfund.com","rajesh.kumar@spoton.co.in","pawan.sharma@spoton.co.in","vishwas.j@spoton.co.in","prasanna.hegde@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "SERVER ETA FTP" + " - " + str(reportts)
    msg["Subject"] = "Edge Variance Report" + " - " + str(datefilter)
    body_text = """
    Dear All,

    PFA the Edge Variance Report for """ + str(datefilter) +"""
    
    PFB the summary."""+str()+"""

"""+str(maildf)+"""

    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    #server=smtplib.SMTP('124.7.138.249', 587)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
#print('Email sent')



