
# coding: utf-8

# In[1]:


import pandas as pd
from datetime import datetime, timedelta
import numpy as np
from sqlalchemy import *
import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import sys
import Utilities
reload(sys).setdefaultencoding("ISO-8859-1")
pd.set_option("display.max_columns",100)
from fuzzywuzzy import fuzz
from fuzzywuzzy import process
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.87;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
#cursor = cnxn.cursor() 
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
#cursor = cnxn.cursor()

try:
  query = ("""
          EXEC USP_CLOSINGSTOCK_REPORT_1HR_IE
          """)
  df = pd.read_sql(query, Utilities.cnxn) 

  df.rename(columns={'Is_ADC':'Is ADC','CustomerName':'Customer Name','DEST_BRCD':'DEST BRCD','DRS_PREPARED':'DRS PREPARED','DEST_DEPOT':'DEST DEPOT',"TimestateDate":'Timestate Date',"ARRV_AT_DEST_SC":'ARRV AT DEST SC',"ConStatusCode":'Con Status Code',"CON_BLOCKED_FOR_ODA_PIN_ISSUES":'CON BLOCKED FOR ODA PIN ISSUES',"CON_BLOCKED_FOR_PAY_ISSUES":'CON BLOCKED FOR PAY ISSUES',"CON_BLOCKED_FOR_DEMURRAGE":'CON BLOCKED FOR DEMURRAGE'},inplace=True)

  #df=pd.read_excel(r'http://spoton.co.in/downloads/OCID_CLOSINGSTOCK_1HR/OCID_CLOSINGSTOCK_1HR.xls')
  df["PARENTCODE"]=df["PARENTCODE"].fillna(0.0).astype(int).astype(str)
  apnstatcodes=['APN', 'APT']
  df["APNCons"]=df.apply(lambda x: True if x["Con Status Code"] in apnstatcodes else False,axis=1)
  dff=df[(df["APNCons"]==True)|(df['Is ADC']=="YES")]
  dff=dff[(dff["CON BLOCKED FOR ODA PIN ISSUES"]!='YES')&(dff["CON BLOCKED FOR PAY ISSUES"]!='YES')&(dff["CON BLOCKED FOR DEMURRAGE"]!='YES')&(dff["CSGNCD"]!=119721)]
  dff["Appointment Date"]=pd.to_datetime(dff["Appointment Date"],format='%d/%m/%Y',errors='coerce',dayfirst=True)
  #print (dff['Appointment Date'].unique())
  dff=dff[(dff['Appointment Date']>=(pd.to_datetime('today')+timedelta(days=1)))&(dff['Appointment Date']<=(pd.to_datetime('today')+timedelta(days=3)))]
  print (dff['Appointment Date'].unique())
  dff["APNTommorow"]=dff.apply(lambda x: True if x["Appointment Date"] else False,axis=1)
  # dff["APNTommorow"]=dff.apply(lambda x: True if x["Appointment Date"]==(pd.to_datetime('today')+timedelta(days=1)) else False,axis=1)


  dff2=dff[(dff["APNTommorow"]==True)&dff["APNCons"]==True]
  print (len(dff2))

  import sys;
  reload(sys);
  sys.setdefaultencoding("utf8")
  # potccflist["Key"]=potccflist["Destn"].astype(str)+potccflist["Customer Name"].astype(str)
  # potccflist=potccflist["Key"].values.tolist() 
  dff2["Key"]=dff2["DEST BRCD"].astype(str)+dff2["Customer Name"].astype(str)
  # dff2["PotSBA"]=dff2.apply(lambda x: True if x["Key"] in potccflist else False,axis=1)
  dff2['Appointment Date']=dff2['Appointment Date'].apply(lambda x: (datetime.strftime(x,format='%Y-%m-%d')))
  appdf=dff2.pivot_table(index=["DEST DEPOT"],columns=['Appointment Date'],values=["DOCKNO"],aggfunc={"DOCKNO":len},margins=True).reset_index()
  appdf=appdf.fillna(0)
  appdf=appdf.set_index("DEST DEPOT")
  appdf=appdf.fillna(0.0).astype(int)
  appdf=appdf.sort_values(by=[('DOCKNO','All')],ascending=False)
  dff2["CSGENM_2"]=dff2["CSGENM"].astype(str).str[0:12]
  matchdict={}
  choices = dff2["CSGENM_2"].tolist()
  knownlist=["Harish","Vodafone","Decathlon","Victorinox","Adidas","Aurobindo","Britannia","Coffee Day","Globus","Prestige","Bharti","Cloudtail","Avenue","Max","Trent","Aditya Birla", "Fine tech","S Chand","Walmart","Bosch","BOROSIL","TATA","Future","Johnson","Uflex","Luxor","Reliable","Freudenberg","BOSCH","Myntra","Reliance","Amazon","Crossword","Metro","Pantaloons","Narendra","Flipkart"]
  for i in knownlist:
      for j in process.extract(i,choices,scorer=fuzz.ratio):
          if j[1]>55:
              matchdict.update({j[0]:i})
  dff2["CSGENM_2"]=dff2["CSGENM_2"].map(matchdict)
  dff2.CSGENM_2.fillna(dff2["CSGENM"].astype(str).str[0:12],inplace=True)
  csgnmdf=dff2.pivot_table(index=["CSGENM_2","DEST DEPOT"],columns=['Appointment Date'],values=["DOCKNO"],aggfunc={"DOCKNO":len},margins=True).reset_index()
  print (csgnmdf)
  print (csgnmdf.columns)
  csgnmdf=csgnmdf.fillna(0)
  csgnmdf=csgnmdf.sort_values(by=[('DOCKNO','All')],ascending=False)[0:15]
  csgnmdf['DOCKNO']=csgnmdf['DOCKNO'].astype(int)
  filepath1=r'D:\Data\Appointment Reports\Tomorrow\apn_tmrw.csv'
  filepath3='D:\Data\Appointment Reports\apn_tmrw.csv'
  try:
      dff2.to_csv(filepath1)
  except:
      dff2.to_csv(filepath3)

  #print (appdf['DOCKNO'][0])

  cons=appdf[('DOCKNO','All')][0]
  print (cons)
  filePath=r'D:\Data\Appointment Reports\Tomorrow\apn_tmrw.csv'
  #exit(0)
  from datetime import date,timedelta
  todate=date.today()-timedelta(1)
  today_date=datetime.strftime(todate,'%d-%m-%Y')
  today_date
  #vishwas.j@spoton.co.in
  

  TO=["pawan.sharma@spoton.co.in","krishna.chandrasekar@spoton.co.in","abhik.mitra@spoton.co.in", "jothi.menon@spoton.co.in","sharmistha.majumdar@spoton.co.in","sq_spot@spoton.co.in", "aom_spot@spoton.co.in", "dom_spot@spoton.co.in", "rom_spot@spoton.co.in","ganesh.m@spoton.co.in","vinit.tiwari@spoton.co.in","amazondeliveries@spoton.co.in",'sachin.tyagi@spoton.co.in']
  #TO=['sharmistha.majumdar@spoton.co.in','amazondeliveries@spoton.co.in','shivananda.p@spoton.co.in','sachin.tyagi@spoton.co.in']
  #TO=['mahesh.reddy@spoton.co.in']
  FROM="reports.ie@spoton.co.in"
  #CC=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
  BCC=['mahesh.reddy@spoton.co.in']
  #BCC=['maheshmahesh11464@gmail.com']
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  #msg["CC"] = ",".join(CC)
  msg["BCC"] = ",".join(BCC)
  msg["Subject"] = "Appointment Cons for next 3 days" + " : " + str(today_date)
  html='''<html>
  <style>
  p
  {
    margin:0;
    margin-top: 5px;
    padding:0;
    font-size:17px;
      line-height:20px;
  }
  </style>
  <h4>Dear Managers,</h4>
  <p>Attached is the list of appointment deliveries for next 3 days. Please plan deliveries of your respective depots in advance.</p>
  <h3>A. Appointment Cons for next 3 days:</h3>
  <p>Total Appointment cons for next 3 days:$cons</p>
  </html>'''

  html3='''
  <h3>B. Top Consignees with Appointments for next 3 days:</h3>

  '''
  s = Template(html).safe_substitute(date=today_date,cons=cons)
  report=""
  report+=s
  report+='<br>'
  report+='<br>'+appdf.to_html()+'<br>'
  report+=html3
  report+='<br>'+csgnmdf.to_html()+'<br>'
  abc=MIMEText(report,'html')
  msg.attach(abc)
  part = MIMEBase('application', "octet-stream")
  part.set_payload( open(filePath,"rb").read() )
  encoders.encode_base64(part)
  part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
  msg.attach(part)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO+BCC, msg.as_string())
  server.quit()

except:
  TO=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  #msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "ERROR Report" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in Appointment Cons for next 3 days'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO, msg.as_string())
  server.quit()
