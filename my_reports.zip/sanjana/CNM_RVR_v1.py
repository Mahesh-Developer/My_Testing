
# coding: utf-8

# In[1]:

from suds.client import Client
import pandas as pd
from datetime import datetime


# In[2]:

gpsdata = pd.read_csv('D:\\Python\\Scripts and Files\\Path and Graph Files\\GPSdetails.csv')


# In[3]:

url_service = 'http://118.67.240.88:5009/Service.asmx?WSDL'
client = Client(url_service)


# In[4]:

for i in range (0, len(gpsdata)):
    simno = gpsdata.iloc[i]['NAME']
    unitno = gpsdata.iloc[i]['Unit No.']
    vehno = gpsdata.iloc[i]['Vehicle number']
    try:
        response = client.service.Get_Information(User_Id="stladmin1", vehicle_Id=str(simno))
        output = response.split('::')
        phone_id = output[0]
        ping_time = output[3]
        lati=output[5]
        longi=output[6]
        speed = output[7]
        
        gpsdata.loc[i,'Ping_Time'] = ping_time
        gpsdata.loc[i,'Latitude'] = lati
        gpsdata.loc[i,'Longitude'] = longi
        gpsdata.loc[i,'Speed'] = speed
        gpsdata.loc[i,'Remarks'] = 'OK'
        
    except:
        gpsdata.loc[i,'Remarks'] = 'Check'
        pass
    
 


# In[8]:

datetimenow = datetime.now()

opfilevar=datetimenow.date()
opfilevar1=datetimenow.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=pd.np.round((float(currhrs)/60),1)

gpsdata.loc[gpsdata.index,'Timestamp'] = datetimenow

gpsdata.to_csv('D:\\Data\\CNM\\GPSdetails_OP_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv', encoding='utf-8')  


# In[7]:

url_service = 'http://118.67.240.88:5009/Service.asmx?WSDL'
client = Client(url_service)

response = client.service.Get_Information(User_Id="stladmin1", vehicle_Id='8861873161')
print response
x = response.split('::')
phone_id = x[0]
ping_time = x[3]
lati=x[5]
longi=x[6]
speed = x[7]
phone_id, ping_time, lati, longi, speed


# In[ ]:




# In[ ]:



