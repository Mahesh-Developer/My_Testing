
# coding: utf-8

# In[1]:


"""
Created on Tue Aug 11 15:09:14 2015

@author: s1602vis
"""
import pandas as pd
import numpy as np
from pandas import ExcelWriter
import urllib
import csv
from datetime import datetime, timedelta, time, date
import os
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import urllib
import ftplib
import traceback


# In[2]:

def datestring(x):
    fulldate = datetime.strptime(x,'%d %b %Y %H:%M')
    return fulldate

def dockno(x):
    return x


# In[3]:

yesterdate=date.today()-timedelta(hours=24)


# In[4]:

pmddata = pd.read_csv(r'http://spoton.co.in/downloads/PMD/PMD.csv')
#pmddata = pd.read_csv(r'C:\Data\OCID_PMD\PMD.csv')
#delivered = pd.io.excel.read_excel(r'C:\Data\OCID_PMD\OCID11D.xls','DELIVERED')

delivered = pd.io.excel.read_excel(r'http://spoton.co.in/downloads/OCID/OCID.xls','DELIVERED')
pmddata.columns.tolist()
pmddata=pmddata.rename(columns={'\xef\xbb\xbfCON_ID2':'DOCKNO'})
pmddata.columns


# In[5]:

pmddata['Condate'] = pmddata.apply(lambda x:datestring(x['DATE2']),axis=1)


# In[6]:

vehlist = ['STD-ADHOC']
yesterdaydf = pmddata[(pmddata['Condate'] >= yesterdate) & (pmddata['PUDTYPE2'].isin(vehlist))& (pmddata['TYP2']=='DLV')]
#yesterdaydf.to_csv(r'C:\Data\OCID_PMD\yesterdaydf.csv')


# In[7]:

opfilevar =date.today() - timedelta(hours=24)
opfilevar


# In[8]:

def roundoff(x):
    a = np.ceil(x)
    return a


# In[9]:

deliveredyest = pd.merge(yesterdaydf,delivered,left_on=['DOCKNO'],right_on=['DOCKNO'],how='inner')
columnsdel = ['DOCKNO','DEST BRCD','DEST AREA','DEST REGION','DEL LOCATION TYPE','ACT_WT2','COST2','DUE DATE','ARRV AT DEST SC','DELY DT','DELDATE MIN ARRVDT','BAVEHTYPE','BAVEHNO','BAVEHCAP'] 
deliveredyest = pd.DataFrame(deliveredyest,columns=columnsdel)

iy = deliveredyest[deliveredyest['DELDATE MIN ARRVDT']<0].index
deliveredyest.loc[iy,'DELDATE MIN ARRVDT'] = 0

deliveredgroupby = deliveredyest.groupby(['DEST BRCD']).agg({'DOCKNO': 'count','DELDATE MIN ARRVDT': np.mean}).reset_index()


# <b> For Cap utilization</b>

# In[10]:

deliveredbacap = deliveredyest.drop_duplicates(cols='BAVEHNO')
deliveredbacapgroupby = deliveredbacap.groupby(['DEST BRCD']).agg({'BAVEHCAP':'sum'}).reset_index()

iz = deliveredbacapgroupby[deliveredbacapgroupby['BAVEHCAP']==0].index
deliveredbacapgroupby.loc[iz,'BAVEHCAP'] = 1

totalbacap = deliveredbacapgroupby['BAVEHCAP'].sum()
totalactwt = deliveredyest['ACT_WT2'].sum()
totalcost = deliveredyest['COST2'].sum()
totalutil = np.round(((totalactwt*100)/totalbacap),2)
totalcpk = np.round((totalcost/totalactwt),2)


deliveredyestwts = deliveredyest.groupby(['DEST BRCD']).agg({'ACT_WT2':'sum','COST2':'sum'}).reset_index()

deliveredcaputil = pd.merge(deliveredyestwts,deliveredbacapgroupby,left_on=['DEST BRCD'],right_on=['DEST BRCD'],how='outer')

deliveredcaputil['Utilization'] = deliveredcaputil.apply(lambda x:roundoff(x['ACT_WT2']*100.0/x['BAVEHCAP']),axis=1)
deliveredcaputil['CPKG'] = deliveredcaputil.apply(lambda x:np.round((x['COST2']/x['ACT_WT2']),2),axis=1)


# In[11]:

deliveredgroupby['Avg Cooling Hrs'] = deliveredgroupby.apply(lambda x : roundoff(x['DELDATE MIN ARRVDT']),axis=1)

deliveredbacapmerge = pd.merge(deliveredcaputil,deliveredgroupby,left_on=['DEST BRCD'],right_on=['DEST BRCD'],how='outer')

columnsdelgrpby = ['DEST BRCD','DOCKNO','Avg Cooling Hrs','ACT_WT2','Utilization','CPKG'] 
deliveredbacapmerge = pd.DataFrame(deliveredbacapmerge,columns=columnsdelgrpby)


# In[12]:

coolinghrs = (deliveredyest['DELDATE MIN ARRVDT'].sum())*1.0
totalcons = (deliveredgroupby['DOCKNO'].sum())*1.0
avgcooling = np.round((coolinghrs/totalcons),2)

# For STD and ODA separate Cooling Hours
stddeliveredyest = deliveredyest[deliveredyest['DEL LOCATION TYPE']=='STD']
stdcoolinghrs = (stddeliveredyest['DELDATE MIN ARRVDT'].sum())*1.0
stdtotalcons = len(stddeliveredyest)
stdavgcooling = np.round((stdcoolinghrs/stdtotalcons),2)

try:
    odadeliveredyest = deliveredyest[deliveredyest['DEL LOCATION TYPE']=='ODA']
    odacoolinghrs = (odadeliveredyest['DELDATE MIN ARRVDT'].sum())*1.0
    odatotalcons = len(odadeliveredyest)
    odaavgcooling = np.round((odacoolinghrs/odatotalcons),2)
except(ZeroDivisionError):
    odaavgcooling = 0

# For STD and ODA separate Cooling Hours

totaldelduecons = deliveredyest[deliveredyest['DUE DATE']>= opfilevar] 
dueconsno = len(totaldelduecons)


# In[13]:

with ExcelWriter(r'D:\Data\Market_vehicle_ageing\Market_Delivered_'+str(opfilevar)+'.xlsx') as writer:
    deliveredbacapmerge.to_excel(writer, sheet_name='SUMMARY',engine='xlsxwriter')
    deliveredyest.to_excel(writer, sheet_name='DATA',engine='xlsxwriter')
    
oppath1 = r'D:\Data\Market_vehicle_ageing\Market_Delivered_'+str(opfilevar)+'.xlsx'


# In[14]:

filePath = oppath1
def sendEmail(TO = ["vishwas.j@spoton.co.in"],
            #TO = ["vishwas.j@spoton.co.in"],
            #CC = ["vishwas.j@spoton.co.in"],
            CC = ["vishwas.j@spoton.co.in","rajeesh.vr@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "Cons Delivered By Market" + " - " + str(opfilevar)
    body_text = """
    Dear All,
    
    PFA the Cons delivered by Market vehicle on """ + str(opfilevar) +"""
    
    Total cons delivered = """+str(totalcons)+"""
    Average cooling hrs = """+str(avgcooling)+""" Hrs
    Average cooling hrs of STD Cons = """+str(stdavgcooling)+""" Hrs
    Average cooling hrs of ODA Cons = """+str(odaavgcooling)+""" Hrs
    Cons having Duedate>= """+str(opfilevar)+""" = """ +str(dueconsno)+"""
    Overall Capacity Utilization = """+str(totalutil)+""" %
    Overall CPKG = """+str(totalcpk)+"""
    
    PFB the Summary Branch wise of cons delivered and their ageing"""+"""
    
    """+str(deliveredbacapmerge)+"""

    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("vishwas.j@spoton.co.in", "Startrek#123")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
#Sending output file via mail ends


# In[ ]:



