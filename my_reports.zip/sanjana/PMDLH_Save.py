# -*- coding: utf-8 -*-
"""
Created on Mon Feb 13 15:13:23 2017

@author: rajeeshv
"""

# -*- coding: utf-8 -*-

import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
import calendar
import datetime
from pandas import ExcelWriter

pmdlh = pd.io.excel.read_excel(r'http://spoton.co.in/downloads/PMDLH/PMDLH.xls','PMD_LINEHAUL_DATA')

datenow = date.today()
dateyest = datenow-timedelta(hours=24)

with ExcelWriter(r'D:\Data\PMDLH_Raw\\PMDLH_'+str(dateyest)+'.xlsx') as writer:
    pmdlh.to_excel(writer, sheet_name='PMDLH',engine='xlsxwriter')

print 'PMDLH saving done'