
# coding: utf-8

# In[1]:

import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
from datetime import datetime, timedelta
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template
from pandas import np
import Utilities

# In[2]:

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


# In[ ]:

dockquery = ("""
        SELECT TOP 10 * FROM PCR_PIECES_DETAIL WITH (NOLOCK)
        
        """)
docknodf = pd.read_sql(dockquery, Utilities.cnxn)


# In[ ]:

len(docknodf)


# In[ ]:

docknodf.columns.tolist()


# In[3]:

pcrquery = ("""
        
        SELECT  --TOP 10

        A.DOCKNO ,
        A.DOCKDT ,
        A.ORGNCD ,
        A.REASSIGN_DESTCD ,
        A.DOC_CURLOC ,
        A.PKGSNO ,
        B.PartNo ,
        B.pcs_curloc ,
        B.pcs_nxtloc ,
        B.isActive ,
        B.pcs_tcno ,
        B.pcs_thcno
FROM    DOCKET A WITH ( NOLOCK )
INNER JOIN PCR_PIECES_Detail B WITH ( NOLOCK ) ON A.DOCKNO = B.Dockno
LEFT OUTER JOIN dbo.DKT_DELY c WITH (NOLOCK) ON a.DOCKNO = c.DOCKNO AND c.DELY_DT IS NOT NULL
WHERE   A.DOCKDT >= '2018-02-23 00:00:00'
        AND B.isActive = 1
        AND c.DOCKNO IS NULL
        AND A.DOC_CURLOC <> B.pcs_curloc
        """)


# In[4]:

pcrdf = pd.read_sql(pcrquery, Utilities.cnxn)


# In[5]:

#pcrdf.to_pickle('pcrdf.pkl')


# In[6]:

expdf = pcrdf[pcrdf.DOC_CURLOC!=pcrdf.pcs_curloc]


# In[7]:

len(expdf)


# In[8]:

len(expdf['DOCKNO'].unique())


# In[10]:

expdf['DOCKDT'] = expdf['DOCKDT'].apply(lambda x:x.date())


# In[11]:

expdf.head()


# In[37]:

expdf1 = expdf[pd.isna(expdf.pcs_nxtloc)]


# In[40]:

len(expdf1.DOCKNO.unique())


# In[30]:

expdf2 = expdf[~pd.isna(expdf.pcs_nxtloc)]


# In[31]:

expdf2


# In[48]:

cols = ['DOC_CURLOC','DOCKNO','pcs_curloc','pcs_nxtloc']
expdfpivt = pd.pivot_table(expdf2[cols],index=['DOC_CURLOC','pcs_curloc','pcs_nxtloc'],aggfunc={'DOCKNO':lambda x:len(set(x))},margins=True).reset_index()


# In[49]:

expdfpivt = expdfpivt.sort_values(('DOCKNO'),ascending=False)


# In[ ]:

pcrdf.columns.tolist()


# In[41]:

# idx=pd.IndexSlice


# # In[47]:

# expdfpivt.loc[idx['HYDH','BLRH',:],:]

reportts = datetime.now()
opfilevar=reportts.date()
opfilevar1=reportts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=np.round((float(currhrs)/60),0)


expdfpivt = expdfpivt.head(20)
# In[ ]:
expdf2.to_csv(r'D:\Data\PPM\Piecewise\PPM_Report_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv')
filepath = r'D:\Data\PPM\Piecewise\PPM_Report_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv'

TO=["hubmgr_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in",'amit.s@spoton.co.in','plt.vigilance_sw@spoton.co.in','plt.vigilance_ne@spoton.co.in']
#TO=['vishwas.j@spoton.co.in']
FROM='reports.ie@spoton.co.in'
CC=['sqtf@spoton.co.in','rajesh.kapase@spoton.co.in','mahesh.reddy@spoton.co.in','shashvat.suhane@spoton.co.in']
BCC=['aditya.shekhar@spoton.co.in','chidananda.biswal@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "PPM-DOC_CURLOC-PCS_CURLOC Mismatch-" + str(opfilevar)+"-"+str(opfilevar2)
html='''<html>
<h4>Dear All,</h4>
<p>PFA the Part piece movement exception summary</p>
</html>'''
report=""
report+='<br>'
report+='Below is the summary of Cons booked after 23rd Feb where Doc_Curloc not same as PCS_Curloc. Have excluded the cons which are already delivered'
report+='<br>'
report+=''
report+='<br>'+expdfpivt.to_html()+'<br>'
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()

