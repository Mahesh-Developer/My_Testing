
# coding: utf-8

# In[1]:

import pandas.io.sql
import pandas as pd
import sys
import numpy as np
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
import os
import Utilities

# In[2]:

reload(sys).setdefaultencoding("ISO-8859-1")
#sys.setdefaultencoding('utf8')


# In[3]:

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor1 = cnxn1.cursor()
# cnxn1 = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn1.cursor()


# In[4]:
try:
	querydate=datetime.strftime(datetime.now()-timedelta(1),'%Y-%m-%d')
	querydate


	# In[5]:

	#query=("""EXEC dbo.USP_PLT_DATAENTRY_Vs_PickupUnloading_SQ '{0}','{1}'""").format()
	query=(""" EXEC dbo.USP_PLT_DATAENTRY_Vs_PickupUnloading_SQ 'S', '{0}','{1}'""".format(querydate,querydate))
	query


	# In[6]:

	df=pd.read_sql(query,Utilities.cnxn)


	# In[7]:

	df['% Not Scan Pieces']=pd.np.round(df['Total PU Pieces Not Scanned']*100.0/df['Total Pcs Count - NormalCons'])
	df=df.replace([np.inf,-np.inf],np.nan).fillna(0)


	# In[8]:

	df['% Not Scan Pieces']=df['% Not Scan Pieces'].astype(int)


	# In[9]:

	df.rename(columns={'ReportDate':'Date','RGALPH':'Region','DEPOT_CODE':'DEPOT','ControlArea':'Area'},inplace=True)


	# In[10]:

	df


	# In[11]:

	query1=(""" EXEC dbo.USP_PLT_DATAENTRY_Vs_PickupUnloading_SQ 'D', '{0}','{1}'""".format(querydate,querydate))
	query1


	# In[12]:

	data=pd.read_sql(query1,Utilities.cnxn)


	# In[13]:

	len(data)


	# In[14]:

	reportts = datetime.now()
	opfilevar=reportts.date()
	opfilevar1=reportts.time()
	ct2= str (opfilevar1)
	currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

	opfilevar2=pd.np.round((float(currhrs)/60),0)


	# In[15]:

	data.to_csv(r'D:\Data\PLT Shortage\PLT Exception Reports\PLT_Exception_Data.csv')
	data.to_csv(r'D:\Data\PLT Shortage\PLT Exception Reports\PLT_Exception_Data-'+str(opfilevar)+'.csv')
	df.to_csv(r'D:\Data\PLT Shortage\PLT Exception Reports\PLT_Exception_Summary.csv')
	df.to_csv(r'D:\Data\PLT Shortage\PLT Exception Reports\PLT_Exception_Summary-'+str(opfilevar)+'.csv')

	#loadavailabledf.to_csv(r'D:\Data\AMCH Loads\AMCH_Loads_Summary.csv')


	# In[16]:

	oppath1=r'D:\Data\PLT Shortage\PLT Exception Reports\PLT_Exception_Data.csv'
	oppath2=r'D:\Data\PLT Shortage\PLT Exception Reports\PLT_Exception_Summary.csv'


	# In[19]:

	FROM='mis.ho@spoton.co.in'

	#TO=['shivananda.p@spoton.co.in','mahesh.reddy@spoton.co.in']
	TO=['AOM_SPOT@spoton.co.in','DOM_SPOT@spoton.co.in','ROM_SPOT@spoton.co.in','scincharge_spot@spoton.co.in']
	#CC=['mahesh.reddy@spoton.co.in']
	CC=['abhik.mitra@spoton.co.in','rajesh.kapase@spoton.co.in','pawan.sharma@spoton.co.in','jothi.menon@spoton.co.in','rajesh.kumar@spoton.co.in','alok.b@spoton.co.in','shivananda.p@spoton.co.in','mahesh.reddy@spoton.co.in','saptarshi.pathak@spoton.co.in']


	msg = MIMEMultipart()
	msg["From"] = FROM
	msg["To"] = ",".join(TO)
	msg["CC"] = ",".join(CC)
	#msg["BCC"] = ",".join(BCC)
	#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
	msg["Subject"] = "PLT Exception Report Data Entry Vs Pickup Unloading -" + str(opfilevar)

	report=""
	report+='Dear All,'

	report+='<br>'
	report+='<br>'
	report+= 'Pls find attached Yesterday exception report for Data Entry Vs Pickup Unloading.'
	report+='<br>'
	report+='<br>'
	report+='<br>'+df.to_html()+'<br>'

	abc=MIMEText(report.encode('utf-8'),'html')
	msg.attach(abc)

	part = MIMEBase('application', "octet-stream")
	part.set_payload( open(oppath1,"rb").read() )
	encoders.encode_base64(part)
	part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
	msg.attach(part)

	part1 = MIMEBase('application', "octet-stream")
	part1.set_payload( open(oppath2,"rb").read() )
	encoders.encode_base64(part1)
	part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath2))
	msg.attach(part1)


	server=smtplib.SMTP('smtp.sendgrid.net', 587)
	server.ehlo()
	server.starttls()
	server.ehlo()
	server.login("spoton.net.in", "Star@123#")
	failed = server.sendmail(FROM, TO+CC, msg.as_string())
	server.quit()

except:

  TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in'] 
  CC=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "PLT Exception Report Data Entry Vs Pickup Unloading Error in Execution" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in PLT Exception Report Data Entry Vs Pickup Unloading'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO+CC, msg.as_string())
  server.quit()



# In[ ]:



