
# coding: utf-8

# In[1]:

import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
import glob
import os
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from pandas import ExcelWriter
import traceback
import ftplib
import os


# In[2]:

path =r'D:\Data\Pickups_yesterday' # use your path
allFiles = glob.glob(path + "/*.csv")
frame = pd.DataFrame()
list_ = []
for file_ in allFiles:
    df = pd.read_csv(file_,index_col=None, header=0)
    list_.append(df)
frame = pd.concat(list_)
frame.to_csv(r'D:\Data\Pickups_CTP.csv')
print len(frame)


# In[3]:

pastdayspickup = pd.read_csv(r'D:\Data\Pickups_CTP.csv')
customerdiffmaster = pd.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\Sales_trigger_report_files\Customer_diff_master1.csv')#has the truncated df which has the avg trading days
analysisdf = pd.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\Sales_trigger_report_files\Analysis.csv') #has custcode-datewise trading info
basecustdb = pd.read_csv(r'http://spoton.co.in/downloads/IEProjects/SCD/SCD.csv')


# In[5]:

#removing unwanted columns in custdb file-start

basecustdb = basecustdb.rename(columns={'CustomerCode':'CUSTOMERCODE'}) #for easy merge later on
basecustdb = basecustdb[basecustdb['CustomerActive']=='Y'] #to exclude inactive customers
columnscustdb = ['CUSTOMERCODE', 'CustSignBranchCode', 'CustSignBranchName','saleArea','saleDepot','saleRegion','TerritoryManagerName']
custdb = pd.DataFrame(basecustdb,columns=columnscustdb)

#removing unwanted columns in custdb file-end


# In[6]:

#rounding off avg_diff to single digit as per salesD request
customerdiffmaster['Avg_Diff'] = customerdiffmaster.apply(lambda x: pd.np.round(x['Avg_Diff'], 0), axis=1)
#rounding off avg_diff to single digit as per salesD request


# In[8]:

#cleaning up low frequency trading-start

ix = customerdiffmaster[customerdiffmaster['AccountTypeNew']=='MA'][customerdiffmaster['PICKUP_DATE']>15].index
iy = customerdiffmaster[customerdiffmaster['AccountTypeNew']=='Integrated Account'][customerdiffmaster['PICKUP_DATE']>10].index
iz = customerdiffmaster[customerdiffmaster['AccountTypeNew']=='SME'][customerdiffmaster['PICKUP_DATE']>7].index
iq = customerdiffmaster[customerdiffmaster['AccountTypeNew']=='Others'][customerdiffmaster['PICKUP_DATE']>10].index

customerdiffmaster.loc[customerdiffmaster.index, 'Frequency'] = 'Low'
customerdiffmaster.loc[ix, 'Frequency'] = 'High'
customerdiffmaster.loc[iy, 'Frequency'] = 'High'
customerdiffmaster.loc[iz, 'Frequency'] = 'High'
customerdiffmaster.loc[iq, 'Frequency'] = 'High'
len(customerdiffmaster[customerdiffmaster['Frequency']=='High'])

#cleaning up low frequency trading-end


# In[9]:

customerdiffmaster['Avg_Wt_perday'] = customerdiffmaster.apply( lambda x: pd.np.round((x['Actual Weight']/x['PICKUP_DATE']),0), axis=1)


# In[10]:

#def datestring(x):
#    try:    
#        fulldate = datetime.strptime(x.split(' ')[0], '%Y-%m-%d').date()
#        return fulldate
#    except:
#        ##$$fulldate = datetime.strptime(x.split(' ')[0], '%d/%m/%Y').date()
#        fulldate = datetime.strptime(x.split(' ')[0], '%d-%m-%Y').date()
#        return fulldate
        
## TO handle different datetime format, modified the above function again
        
def datestring(x):
    try:    
        fulldate = datetime.strptime(x.split(' ')[0], '%Y-%m-%d').date()
        return fulldate
    except:
        try:
            fulldate = datetime.strptime(x.split(' ')[0], '%d/%m/%Y').date()
        except:
            fulldate = datetime.strptime(x.split(' ')[0], '%d-%m-%Y').date()
        return fulldate
# In[11]:

pastdayspickup['Date'] = pastdayspickup.apply(lambda x:datestring(x['Pickup_date']),axis=1)


# In[12]:

pastdayspickup_max = pastdayspickup.groupby(['CUSTOMERCODE']).agg({'Date':max}).reset_index()


# In[13]:

now = datetime.now()
yestday = now-timedelta(hours=24)
yestdate = yestday.date()
print yestdate
pastdayspickup_max.loc[pastdayspickup_max.index,'Date_yesterday'] = yestdate


# In[14]:

def datediffcalc(yesterdate,pickupdate):
    datediff = (yesterdate-pickupdate).days
    if datediff==0:
        return 0
    else:
        return (datediff-1)


# In[15]:

pastdayspickup_max['Date_diff'] = pastdayspickup_max.apply(lambda x:datediffcalc(x['Date_yesterday'],x['Date']),axis=1)
len(pastdayspickup_max)


# In[16]:

pickup_cust_merge = pd.merge(pastdayspickup_max,customerdiffmaster,on=['CUSTOMERCODE'],how='inner')


# In[17]:

def triggerflag(diffdays,masteravg):
    if diffdays > masteravg:
        return 'YES'
    else:
        return 'NO'


# In[18]:

pickup_cust_merge['Trigger'] = pickup_cust_merge.apply(lambda x:triggerflag(x['Date_diff'],x['Avg_Diff']),axis=1)

pickup_cust_merge = pickup_cust_merge.rename(columns={'Date':'Last_traded_date','AccountTypeNew':'AccountType'})
pickup_cust_merge_trig = pickup_cust_merge[pickup_cust_merge['Trigger']=='YES']

columnsop = ['CUSTOMERCODE','CUSTOMERNAME','AccountType','Last_traded_date','Date_diff','Avg_Diff','Avg_Wt_perday']
pickup_cust_merge_trig = pd.DataFrame(pickup_cust_merge_trig,columns=columnsop)
#pickup_cust_merge_trig.head()


# In[20]:

import time
from time import strftime
def weekcalc(x):
    y = time.strptime(x,'%Y-%m-%d')  #have used 'time' instead of 'datetime' for using strftime
    return strftime("%U", y)

def yestweekcalc(x):
    x1 = str(x)
    y = time.strptime(x1,'%Y-%m-%d')  #have used 'time' instead of 'datetime' for using strftime
    return strftime("%U", y)
    


# In[21]:

analysisdf['Annual_Weekno'] = analysisdf.apply( lambda x : weekcalc(x['Date_ID']), axis=1)


# In[22]:

analysisdf['Qtr_Weekno'] = analysisdf.apply( lambda x : int((x['Annual_Weekno']))%13, axis=1)


# In[24]:

def percentilecalc(x):
    p = pd.np.round(np.percentile(x, 50),0)
    return p


# In[25]:

analysisdfgrpby = analysisdf.groupby(['CUSTOMERCODE', 'Qtr_Weekno']).agg({'Actual Weight_y': lambda x: percentilecalc(x), 'Con Number_y': lambda x: percentilecalc(x)}).reset_index()


# In[26]:

currentweekno = int(yestweekcalc(yestdate))
currentweekid = currentweekno%13
weeklyload = analysisdfgrpby[analysisdfgrpby['Qtr_Weekno']==currentweekid]


# In[27]:

len(pickup_cust_merge_trig)


# In[28]:

pickup_cust_weeklyload_merge = pd.merge(pickup_cust_merge_trig,weeklyload,on=['CUSTOMERCODE'],how='inner')
pickup_cust_weeklyload_merge = pickup_cust_weeklyload_merge.sort_values('Actual Weight_y',ascending=False)


# In[29]:

pickup_cust_weeklyload_merge.columns


# In[30]:

len(pickup_cust_weeklyload_merge)


# In[31]:

final_merge = pd.merge(pickup_cust_weeklyload_merge, custdb, on=['CUSTOMERCODE'], how='inner')


# In[32]:

len(final_merge)


# In[33]:

final_merge = final_merge.rename(columns={'Actual Weight_y':'Wt_Avg','Con Number_y':'Cons_Avg'})
columnsfinal = ['CUSTOMERCODE','CUSTOMERNAME','AccountType','Last_traded_date','Date_diff','Avg_Diff','Wt_Avg', 'Cons_Avg', 'CustSignBranchCode', 'CustSignBranchName','saleArea','saleDepot','saleRegion','TerritoryManagerName']
finaldf = pd.DataFrame(final_merge,columns=columnsfinal)
#changing the names for better presentation
finaldf = finaldf.rename(columns={'Wt_Avg':'Kgs_Lost','Cons_Avg':'Cons_Lost', 'saleRegion':'SaleRegion', 'saleArea':'SaleArea', 'saleDepot':'SaleDepot'})


# In[38]:

finalgrp_region = finaldf.groupby(['SaleRegion']).agg({'CUSTOMERCODE': len, 'Kgs_Lost': sum}).reset_index()
finalgrp_depot = finaldf.groupby(['SaleDepot']).agg({'CUSTOMERCODE': len, 'Kgs_Lost': sum}).reset_index()
finalgrp_branch = finaldf.groupby(['SaleDepot','CustSignBranchName']).agg({'CUSTOMERCODE': len, 'Kgs_Lost': sum}).reset_index()
finalgrp_tsm = finaldf.groupby(['SaleDepot','TerritoryManagerName']).agg({'CUSTOMERCODE': len, 'Kgs_Lost': sum}).reset_index()
finalgrp_acctype = finaldf.groupby(['AccountType', 'SaleDepot']).agg({'CUSTOMERCODE': len, 'Kgs_Lost': sum}).reset_index()

#renaming this particular column for having a neat name in basedata file and presentation also
finalgrp_region = finalgrp_region.rename(columns={'CUSTOMERCODE':'Low_Trading_Cust'})
finalgrp_depot = finalgrp_depot.rename(columns={'CUSTOMERCODE':'Low_Trading_Cust'})
finalgrp_branch = finalgrp_branch.rename(columns={'CUSTOMERCODE':'Low_Trading_Cust'})
finalgrp_tsm = finalgrp_tsm.rename(columns={'CUSTOMERCODE':'Low_Trading_Cust'})
finalgrp_acctype = finalgrp_acctype.rename(columns={'CUSTOMERCODE':'Low_Trading_Cust'})

#to bring the column name in order
columnsregion = ['SaleRegion','Kgs_Lost','Low_Trading_Cust']
finalgrp_region = pd.DataFrame(finalgrp_region,columns=columnsregion)

#for giving 'total' variables in mail body
kgslost = finaldf['Kgs_Lost'].sum()
lowtradingcust = len(finaldf['CUSTOMERCODE'])

# For Addidng totals in each dataframe
sumlistregion = ['TOTAL',kgslost,lowtradingcust]
col_listregion = ['SaleRegion','Kgs_Lost','Low_Trading_Cust']
regiontotal = pd.DataFrame(data=[sumlistregion], columns = col_listregion)
finalgrp_region = finalgrp_region.append(regiontotal,ignore_index=True)

sumlistdepot= ['TOTAL',kgslost,lowtradingcust]
col_listdepot= ['SaleDepot','Kgs_Lost','Low_Trading_Cust']
depottotal = pd.DataFrame(data=[sumlistdepot], columns = col_listdepot)
finalgrp_depot = finalgrp_depot.append(depottotal,ignore_index=True)

sumlistbrcd= ['TOTAL','-',kgslost,lowtradingcust]
col_listbrcd= ['SaleDepot','CustSignBranchName','Kgs_Lost','Low_Trading_Cust']
brcdtotal = pd.DataFrame(data=[sumlistbrcd], columns = col_listbrcd)
finalgrp_branch = finalgrp_branch.append(brcdtotal,ignore_index=True)

sumlisttsm= ['TOTAL','-',kgslost,lowtradingcust]
col_listtsm= ['SaleDepot','TerritoryManagerName','Kgs_Lost','Low_Trading_Cust']
tsmtotal = pd.DataFrame(data=[sumlisttsm], columns = col_listtsm)
finalgrp_tsm= finalgrp_tsm.append(tsmtotal,ignore_index=True)

sumlistchannel= ['TOTAL','-',kgslost,lowtradingcust]
col_listchannel= ['SaleDepot','AccountType','Kgs_Lost','Low_Trading_Cust']
channeltotal = pd.DataFrame(data=[sumlistchannel], columns = col_listchannel)
finalgrp_acctype= finalgrp_acctype.append(channeltotal,ignore_index=True)

#To get columns in order
columnsopregion = ['SaleRegion','Kgs_Lost','Low_Trading_Cust']
finalgrp_region = pd.DataFrame(finalgrp_region,columns=columnsopregion)

columnsopdepot= ['SaleDepot','Kgs_Lost','Low_Trading_Cust']
finalgrp_depot = pd.DataFrame(finalgrp_depot,columns=columnsopdepot)

columnsopbrcd= ['SaleDepot','CustSignBranchName','Kgs_Lost','Low_Trading_Cust']
finalgrp_branch = pd.DataFrame(finalgrp_branch,columns=columnsopbrcd)

columnsoptsm= ['SaleDepot','TerritoryManagerName','Kgs_Lost','Low_Trading_Cust']
finalgrp_tsm = pd.DataFrame(finalgrp_tsm,columns=columnsoptsm)

columnsopacttype= ['SaleDepot','AccountType','Kgs_Lost','Low_Trading_Cust']
finalgrp_acctype = pd.DataFrame(finalgrp_acctype,columns=columnsopacttype)
# For Addidng totals in each dataframe

#finaldf.to_csv('data.csv') #to give it as link
#finalgrp_depot.to_csv('Depot_wise.csv') #give it in mail body (after droping index)+ one excel sheet
#finalgrp_branch.to_csv('Branch_wise.csv') #give it in one excel sheet
#finalgrp_tsm.to_csv('TSM_wise.csv') #give it in one excel sheet
#finalgrp_acctype.to_csv('AccType_wise.csv') #give it in one excel sheet
yesterdate=date.today()-timedelta(hours=24)

# Inserting Date in Basefile for saving
datenow = date.today()
dateyest = datenow-timedelta(hours=24)
finaldf.loc[finaldf.index,'Timestamp'] = dateyest

finaldf.to_csv(r'D:\Data\Customer_trading_frequency_trigger\Trigger_basefiles\Trading_pattern_trigger_Basedata_'+str(dateyest)+'.csv')
# Inserting Date in Basefile for saving


finaldf.to_csv(r'D:\Data\Customer_trading_frequency_trigger\Trading_pattern_trigger_Basedata.csv')

oppath2 =  r'D:\Data\Customer_trading_frequency_trigger\Trading_pattern_trigger_Basedata.csv'
filePath = oppath2

ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
#print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        #print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppath2
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        #print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()
    
# In[ ]:
with ExcelWriter(r'D:\Data\Customer_trading_frequency_trigger\Trading_pattern_trigger_'+str(yesterdate)+'.xlsx') as writer:
    ##$$finaldf.to_excel(writer, sheet_name='FINAL',engine='xlsxwriter')
    finalgrp_region.to_excel(writer, sheet_name='REGION_WISE',engine='xlsxwriter')
    finalgrp_depot.to_excel(writer, sheet_name='DEPOT_WISE',engine='xlsxwriter')
    finalgrp_branch.to_excel(writer, sheet_name='BRANCH_WISE',engine='xlsxwriter')
    finalgrp_tsm.to_excel(writer, sheet_name='TSM_WISE',engine='xlsxwriter')
    finalgrp_acctype.to_excel(writer, sheet_name='CHANNEL_WISE',engine='xlsxwriter')


finalgrp_region = finalgrp_region.to_string(index=False)

oppath1 =  r'D:\Data\Customer_trading_frequency_trigger\Trading_pattern_trigger_'+str(yesterdate)+'.xlsx'
filePath = oppath1
def sendEmail(#TO = ["vishwas.j@spoton.co.in"],
              TO = ["mayank.dwivedi@spoton.co.in", "sanjay.nalawade@spoton.co.in","reena.singhania@spoton.co.in","narasimha.murthy@spoton.co.in","spot_is@spoton.co.in","dsm_spot@spoton.co.in","asm_spot@spoton.co.in"],
              #CC = ["vishwas.j@spoton.co.in"],
              CC = ["uday.sharma@spoton.co.in", "abhik.mitra@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "Sales Trigger Report" + '_' + str(yesterdate)
    body_text = """
    Dear All,
    
    PFA the Sales Trigger Report summary as of """+str(yesterdate)+"""
    
    No of customers trading below their respective level of trade frequency = """+str(lowtradingcust)+"""
    Lost opportunity estimated in kgs  = """+str(kgslost)+"""
    
    Please copy paste the below link to your browser for downloading the base file.
    http://spoton.co.in/downloads/IEProjects/ETA/Trading_pattern_trigger_Basedata.csv
    
    If the no of days between yesterday and the last traded day of a customer is more than the avg frequency of trading of that customer, then that customer appears in this report.
    This is a guidance report to follow up with customer in case there are unkown reasons for the low trading of customer.
    
    
""" +str(finalgrp_region)+"""    

    """
    

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')


