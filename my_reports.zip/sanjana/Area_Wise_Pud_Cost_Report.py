
# coding: utf-8

# In[ ]:

import pandas as pd
import pyodbc
from datetime import datetime,timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
import ftplib
import Utilities
from calendar import monthrange
import smtplib


# In[ ]:

cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()


# In[ ]:

query=("""EXEC USP_PUD_YEST_MTD_DATA 'M' """)


#df=pd.read_sql(query,Utilities.cnxn)


# In[ ]:

pmd_df=pd.read_sql(query,cnxn)


# In[ ]:

pmd_df=pmd_df[pmd_df['PTYPE']!='AR']
print (len(pmd_df))


# In[ ]:

pmd_df['Type']='MTD'


# In[ ]:

pmd_df.columns


# In[ ]:

m = {'Jan': '01','Feb': '02','Mar': '03','Apr':'04','May':'05','Jun':'06','Jul':'07','Aug':'08','Sep':'09','Oct':'10','Nov':'11','Dec':'12'}
def dateconv(date):
    dt = date.split(' ')[2]+'-'+str(m.get(date.split(' ')[1]))+'-'+date.split(' ')[0]+' '+date.split(' ')[3]
    #print (dt)
    return dt
pmd_df["DateOnly"]=pmd_df.apply(lambda x: dateconv(x["DATE"]),axis=1)


# In[ ]:

startdate=datetime.strftime(datetime.now()-timedelta(days=7),'%Y-%m-%d')+' 00:00:00'
enddate=datetime.strftime(datetime.now(),'%Y-%m-%d')+' 00:00:00'


# In[ ]:

# area_dict={'CCUA':{'TO':["mahesh.reddy@spoton.co.in"],'CC':["mahesh.reddy@spoton.co.in"]},
#         'GUAA':{'TO':["mahesh.reddy@spoton.co.in"],'CC':["mahesh.reddy@spoton.co.in"]},
#         'NEIA':{'TO':["mahesh.reddy@spoton.co.in"],'CC':["mahesh.reddy@spoton.co.in"]},
#         'JSPA':{'TO':["mahesh.reddy@spoton.co.in"],'CC':["mahesh.reddy@spoton.co.in"]},
#        'ORAA':{'TO':["mahesh.reddy@spoton.co.in"],'CC':["mahesh.reddy@spoton.co.in"]},
       
#            'BLRA':{'TO':["mahesh.reddy@spoton.co.in"],'CC':["mahesh.reddy@spoton.co.in"]},
        
#            'HYDA':{'TO':["mahesh.reddy@spoton.co.in"],'CC':["mahesh.reddy@spoton.co.in"]},
        
#            'VGAA':{'TO':["mahesh.reddy@spoton.co.in"],'CC':["mahesh.reddy@spoton.co.in"]},
        
#            'MAAA':{'TO':["mahesh.reddy@spoton.co.in"],'CC':["mahesh.reddy@spoton.co.in"]},
        
#            'CBEA':{'TO':["mahesh.reddy@spoton.co.in"],'CC':["mahesh.reddy@spoton.co.in"]},
        
           
#         'COKA':{'TO':["mahesh.reddy@spoton.co.in"],'CC':["mahesh.reddy@spoton.co.in"]},
        
#            'IXMA':{'TO':["mahesh.reddy@spoton.co.in"],'CC':["mahesh.reddy@spoton.co.in"]},
#        'AMDA':{'TO':["mahesh.reddy@spoton.co.in"],'CC':["mahesh.reddy@spoton.co.in"]},
#        'BOMA':{'TO':["mahesh.reddy@spoton.co.in"],'CC':["mahesh.reddy@spoton.co.in"]},
#        'GOIA':{'TO':["mahesh.reddy@spoton.co.in"],'CC':["mahesh.reddy@spoton.co.in"]},
#        'IDRA':{'TO':["mahesh.reddy@spoton.co.in"],'CC':["mahesh.reddy@spoton.co.in"]},
#        'NAGA':{'TO':["mahesh.reddy@spoton.co.in"],'CC':["mahesh.reddy@spoton.co.in"]},
#        'PNQA':{'TO':["mahesh.reddy@spoton.co.in"],'CC':["mahesh.reddy@spoton.co.in"]},
#        'IXCA':{'TO':["mahesh.reddy@spoton.co.in"],'CC':["mahesh.reddy@spoton.co.in"]},
#        'LKOA':{'TO':["mahesh.reddy@spoton.co.in"],'CC':["mahesh.reddy@spoton.co.in"]},
#        'JAIA':{'TO':["mahesh.reddy@spoton.co.in"],'CC':["mahesh.reddy@spoton.co.in"]},
       
#            'NCRA':{'TO':["mahesh.reddy@spoton.co.in"],'CC':["mahesh.reddy@spoton.co.in"]},
       
#             'UKNA':{'TO':["mahesh.reddy@spoton.co.in"],'CC':["mahesh.reddy@spoton.co.in"]}
       
         
          
#           }


# In[ ]:

area_dict={'CCUA':{'TO':["saptarshi.mandal@spoton.co.in","abani.behera@spoton.co.in","md.zaya@spoton.co.in"],'CC':["Rajesh.kumar@spoton.co.in","Avinash.Singh@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","rajesh.kumar@spoton.co.in","mahesh.reddy@spoton.co.in"]},
        'GUAA':{'TO':["md.zaya@spoton.co.in"],'CC':["Rajesh.kumar@spoton.co.in","Avinash.Singh@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","rajesh.kumar@spoton.co.in","mahesh.reddy@spoton.co.in"]},
        'NEIA':{'TO':["md.zaya@spoton.co.in"],'CC':["Rajesh.kumar@spoton.co.in","Avinash.Singh@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","rajesh.kumar@spoton.co.in","mahesh.reddy@spoton.co.in"]},
        'JSPA':{'TO':["pramod.kumar@spoton.co.in"],'CC':["Rajesh.kumar@spoton.co.in","Avinash.Singh@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","rajesh.kumar@spoton.co.in","mahesh.reddy@spoton.co.in"]},
       'ORAA':{'TO':["sanjay.padhy@spoton.co.in"],'CC':["Rajesh.kumar@spoton.co.in","Avinash.Singh@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","rajesh.kumar@spoton.co.in","mahesh.reddy@spoton.co.in"]},
       'BLRA':{'TO':["Dominic.sathish@spoton.co.in","vallesha.ms@spoton.co.in","anand.kannur@spoton.co.in"],'CC':["sasikumar.kannan@spoton.co.in","rajesh.kumar@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","mahesh.reddy@spoton.co.in"]},
        'HYDA':{'TO':["jacob.mathew@spoton.co.in","ravi.kg@spoton.co.in"],'CC':["sasikumar.kannan@spoton.co.in","rajesh.kumar@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","mahesh.reddy@spoton.co.in"]},
        'VGAA':{'TO':["jacob.mathew@spoton.co.in","ravindra.ch@spoton.co.in"],'CC':["sasikumar.kannan@spoton.co.in","rajesh.kumar@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","mahesh.reddy@spoton.co.in"]},
        'MAAA':{'TO':["joseph.arul.seelan@spoton.co.in","sivakumar.k@spoton.co.in","prakash.t@spoton.co.in"],'CC':["sasikumar.kannan@spoton.co.in","rajesh.kumar@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","mahesh.reddy@spoton.co.in"]},
        'CBEA':{'TO':["suresh.kp@spoton.co.in"],'CC':["sasikumar.kannan@spoton.co.in","rajesh.kumar@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","mahesh.reddy@spoton.co.in"]},
        'COKA':{'TO':["shan.jalal@spoton.co.in","suresh.kp@spoton.co.in"],'CC':["sasikumar.kannan@spoton.co.in","rajesh.kumar@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","mahesh.reddy@spoton.co.in"]},
        'IXMA':{'TO':["suresh.kp@spoton.co.in"],'CC':["sasikumar.kannan@spoton.co.in","rajesh.kumar@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","mahesh.reddy@spoton.co.in"]},
       'AMDA':{'TO':["balakrishnan.r@spoton.co.in","budhram.kamaram@spoton.co.in","omprakash.singh@spoton.co.in"],'CC':["rajesh.debnath@spoton.co.in","pawan.sharma@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","mahesh.reddy@spoton.co.in"]},
       'BOMA':{'TO':["harish.bobade@spoton.co.in","conrad.furtado@spoton.co.in","sandeep.deshpande@spoton.co.in"],'CC':["rajesh.debnath@spoton.co.in","pawan.sharma@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","mahesh.reddy@spoton.co.in"]},
       'GOIA':{'TO':["harish.bobade@spoton.co.in","rama.sz@spoton.co.in"],'CC':["rajesh.debnath@spoton.co.in","pawan.sharma@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","mahesh.reddy@spoton.co.in"]},
       'IDRA':{'TO':["rajesh.mishra@spoton.co.in"],'CC':["rajesh.debnath@spoton.co.in","pawan.sharma@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","mahesh.reddy@spoton.co.in"]},
       'NAGA':{'TO':["rajesh.mishra@spoton.co.in"],'CC':["rajesh.debnath@spoton.co.in","pawan.sharma@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","mahesh.reddy@spoton.co.in"]},
       'PNQA':{'TO':["ramniwas.sharma@spoton.co.in"],'CC':["rajesh.debnath@spoton.co.in","pawan.sharma@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","mahesh.reddy@spoton.co.in"]},
       'IXCA':{'TO':["chhabil.singh@spoton.co.in","stalanjeet.goraya@spoton.co.in"],'CC':["dinesh.kumar.sharma@spoton.co.in","pawan.sharma@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","mahesh.reddy@spoton.co.in"]},
       'LKOA':{'TO':["chhabil.singh@spoton.co.in","mishra.ak@spoton.co.in"],'CC':["dinesh.kumar.sharma@spoton.co.in","pawan.sharma@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","mahesh.reddy@spoton.co.in"]},
       'JAIA':{'TO':["prem.shankar@spoton.co.in"],'CC':["dinesh.kumar.sharma@spoton.co.in","pawan.sharma@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","mahesh.reddy@spoton.co.in"]},
       'NCRA':{'TO':["Mahesh.Srivastava@spoton.co.in","amit.aggarwal@spoton.co.in","chandra.prakash@spoton.co.in","sandeep.sachdeva@spoton.co.in"],'CC':["dinesh.kumar.sharma@spoton.co.in","pawan.sharma@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","mahesh.reddy@spoton.co.in"]},
       'UKNA':{'TO':["ANAR.SINGH@SPOTON.CO.IN"],'CC':["dinesh.kumar.sharma@spoton.co.in","pawan.sharma@spoton.co.in","Anto.Paul@Spoton.Co.In","goutam.barik@spoton.co.in","mahesh.reddy@spoton.co.in"]}
       }


# In[ ]:

yesterdate=datetime.strftime(datetime.now()-timedelta(1),'%Y-%m-%d')
yesterdate


# In[ ]:

FROM="reports.ie@spoton.co.in"


# In[ ]:

for i in pmd_df['AREA'].unique().tolist():
    pmd_df1=pmd_df[pmd_df['AREA']==i]
    mtdsummary=pmd_df1.pivot_table(index=['AREA','BRANCH_CODE'],columns=['Type','PINTYPE'],values=['COST','ACT_WT'],
                              aggfunc={'COST':sum,'ACT_WT':sum})
    mtdsummary=mtdsummary.swaplevel(i=0,j=1,axis=1)
    mtdsummary.fillna(0,inplace=True)
    print (mtdsummary.head())
    try:
        a=mtdsummary['MTD','ACT_WT','NSL']
    except:
        mtdsummary['MTD','ACT_WT','NSL']=0.0
    try:
        a=mtdsummary['MTD','COST','NSL']
    except:
        mtdsummary['MTD','COST','NSL']=0.0
    mtdsummary['MTD','Total','ACT_WT']=mtdsummary['MTD','ACT_WT','ODA']+mtdsummary['MTD','ACT_WT','STD']+mtdsummary['MTD','ACT_WT','NSL']
    mtdsummary['MTD','Total','COST']=mtdsummary['MTD','COST','ODA']+mtdsummary['MTD','COST','STD']+mtdsummary['MTD','COST','NSL']
    mtdsummary.fillna(0,inplace=True)
    weekdf=pmd_df1[(pmd_df1['DateOnly']>startdate) & (pmd_df1['DateOnly']<enddate)]
    weekdf['Type']='WK'
    wksummary=weekdf.pivot_table(index=['AREA','BRANCH_CODE'],columns=['Type','PINTYPE'],values=['COST','ACT_WT'],
                              aggfunc={'COST':sum,'ACT_WT':sum})
    wksummary=wksummary.swaplevel(i=0,j=1,axis=1)
    wksummary.fillna(0,inplace=True)
    try:
        a=wksummary['WK','ACT_WT','NSL']
    except:
        wksummary['WK','ACT_WT','NSL']=0.0
    try:
        a=wksummary['WK','COST','NSL']
    except:
        wksummary['WK','COST','NSL']=0.0
#     print (wksummary.head())
    wksummary['WK','Total','ACT_WT']=wksummary['WK','ACT_WT','ODA']+wksummary['WK','ACT_WT','STD']+wksummary['WK','ACT_WT','NSL']
    wksummary['WK','Total','COST']=wksummary['WK','COST','ODA']+wksummary['WK','COST','STD']+wksummary['WK','COST','NSL']
    wksummary['WK','CPK','NSL']=pd.np.round(wksummary['WK','COST','NSL']/wksummary['WK','ACT_WT','NSL'],2)
    wksummary['WK','CPK','ODA']=pd.np.round(wksummary['WK','COST','ODA']/wksummary['WK','ACT_WT','ODA'],2)
    wksummary['WK','CPK','STD']=pd.np.round(wksummary['WK','COST','STD']/wksummary['WK','ACT_WT','STD'],2)
    wksummary['WK','CPK','Total']=pd.np.round(wksummary['WK','Total','COST']/wksummary['WK','Total','ACT_WT'],2)
    wksummary.fillna(0,inplace=True)
    finalsummary=pd.merge(wksummary,mtdsummary,left_index=True,right_index=True,how='outer')
    finalsummary.fillna(0,inplace=True)
    TO=area_dict[i]["TO"]
    CC=area_dict[i]["CC"]
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "PUD COST Report - Target vs Achieved"+str(i) + '- ' + str(yesterdate)

    report=""
    report+='Dear All,'
    report+='<br>'
    report+='<br>'
    report+="PFB the "+str(i)+" PUD COST Report - Target vs Achieved "+str(yesterdate)
    report+='<br>'
    report+='<br>'
    report+= "PFB tthe summary"
    report+='<br>'
    report+='<br>'
    report+='<br>'+finalsummary.to_html()+'<br>'
    report+='<br>'
    report+='<br>'
    
    abc=MIMEText(report,'html')
    msg.attach(abc)

#     part = MIMEBase('application', "octet-stream")
#     part.set_payload( open(oppath1,"rb").read() )
#     encoders.encode_base64(part)
#     part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
#     msg.attach(part)



    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO+CC, msg.as_string())
    server.quit()


# In[ ]:

exit(0)


# In[ ]:

mtdsummary=pmd_df.pivot_table(index=['AREA','BRANCH_CODE'],columns=['Type','PINTYPE'],values=['COST','ACT_WT'],
                              aggfunc={'COST':sum,'ACT_WT':sum})


# In[ ]:

mtdsummary=mtdsummary.swaplevel(i=0,j=1,axis=1)
# mtdsummary.head()


# In[ ]:

mtdsummary.fillna(0,inplace=True)


# In[ ]:

mtdsummary['MTD','Total','ACT_WT']=mtdsummary['MTD','ACT_WT','ODA']+mtdsummary['MTD','ACT_WT','STD']+mtdsummary['MTD','ACT_WT','NSL']
mtdsummary['MTD','Total','COST']=mtdsummary['MTD','COST','ODA']+mtdsummary['MTD','COST','STD']+mtdsummary['MTD','COST','NSL']


# In[ ]:

mtdsummary['MTD','CPK','NSL']=pd.np.round(mtdsummary['MTD','COST','NSL']/mtdsummary['MTD','ACT_WT','NSL'],2)


# In[ ]:

mtdsummary['MTD','CPK','ODA']=pd.np.round(mtdsummary['MTD','COST','ODA']/mtdsummary['MTD','ACT_WT','ODA'],2)
mtdsummary['MTD','CPK','STD']=pd.np.round(mtdsummary['MTD','COST','STD']/mtdsummary['MTD','ACT_WT','STD'],2)
mtdsummary['MTD','CPK','Total']=pd.np.round(mtdsummary['MTD','Total','COST']/mtdsummary['MTD','Total','ACT_WT'],2)


# In[ ]:

mtdsummary.fillna(0,inplace=True)


# In[ ]:

m = {'Jan': '01','Feb': '02','Mar': '03','Apr':'04','May':'05','Jun':'06','Jul':'07','Aug':'08','Sep':'09','Oct':'10','Nov':'11','Dec':'12'}
def dateconv(date):
    dt = date.split(' ')[2]+'-'+str(m.get(date.split(' ')[1]))+'-'+date.split(' ')[0]+' '+date.split(' ')[3]
    #print (dt)
    return dt
pmd_df["DateOnly"]=pmd_df.apply(lambda x: dateconv(x["DATE"]),axis=1)


# In[ ]:

enddate=datetime.strftime(datetime.now(),'%Y-%m-%d')+' 00:00:00'


# In[ ]:

startdate=datetime.strftime(datetime.now()-timedelta(days=7),'%Y-%m-%d')+' 00:00:00'


# In[ ]:

weekdf=pmd_df[(pmd_df['DateOnly']>startdate) & (pmd_df['DateOnly']<enddate)]
len(weekdf)


# In[ ]:

weekdf['Type']='WK'


# In[ ]:

wksummary=weekdf.pivot_table(index=['AREA','BRANCH_CODE'],columns=['Type','PINTYPE'],values=['COST','ACT_WT'],
                              aggfunc={'COST':sum,'ACT_WT':sum})


# In[ ]:

wksummary=wksummary.swaplevel(i=0,j=1,axis=1)
# mtdsummary.head()


# In[ ]:

wksummary.fillna(0,inplace=True)


# In[ ]:

wksummary.head()


# In[ ]:

wksummary['WK','Total','ACT_WT']=wksummary['WK','ACT_WT','ODA']+wksummary['WK','ACT_WT','STD']+wksummary['WK','ACT_WT','NSL']
wksummary['WK','Total','COST']=wksummary['WK','COST','ODA']+wksummary['WK','COST','STD']+wksummary['WK','COST','NSL']


# In[ ]:

wksummary['WK','CPK','NSL']=pd.np.round(wksummary['WK','COST','NSL']/wksummary['WK','ACT_WT','NSL'],2)


# In[ ]:

wksummary['WK','CPK','ODA']=pd.np.round(wksummary['WK','COST','ODA']/wksummary['WK','ACT_WT','ODA'],2)
wksummary['WK','CPK','STD']=pd.np.round(wksummary['WK','COST','STD']/wksummary['WK','ACT_WT','STD'],2)
wksummary['WK','CPK','Total']=pd.np.round(wksummary['WK','Total','COST']/wksummary['WK','Total','ACT_WT'],2)


# In[ ]:

wksummary.fillna(0,inplace=True)


# In[ ]:

wksummary.fillna(0,inplace=True)
finalsummary=pd.merge(wksummary,mtdsummary,left_index=True,right_index=True,how='outer')
finalsummary.fillna(0,inplace=True)


# In[ ]:

finalsummary.fillna(0,inplace=True)


# In[ ]:

finalsummary.to_excel(r'Pud_Pintype.xlsx')


# In[ ]:



