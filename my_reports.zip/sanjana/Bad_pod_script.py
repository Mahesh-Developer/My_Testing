
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta,datetime
from string import Template
import sys
import Utilities
reload(sys).setdefaultencoding("ISO-8859-1")


# In[2]:


#cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")


# # In[3]:


# cursor=cnxn.cursor()

#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
#cursor = cnxn.cursor()


# In[4]:


query=("""SELECT DISTINCT  DBR.RGALPH DELIVERY_REGION ,
        DBR.DEPOT_CODE DELIVERY_DEPOT ,
        DBR.ControlArea CONTROL_AREA ,
        DKT.REASSIGN_DESTCD DELIVERY_BRANCH_CODE ,
        DBR.BRNM DELIVERY_BRANCH_NAME ,
        B.dockno CON_NUMBER ,
        CONVERT(VARCHAR, DKT.DOCKDT, 106) AS BOOK_DATE ,
        DKT.ORGNCD BOOKING_BRANCH ,
        ORG.DEPOT_CODE BOOKING_DEPOT ,
        DKT.CSGNCD SENDER_CODE ,
        DKT.CSGNNM SENDER_NAME ,
        DKT.CSGECD RECEIVER_CODE ,
        DKT.CSGENM RECEIVER_NAME ,
        DKT.ACTUWT ACTUAL_WEIGHT ,
        CONVERT(VARCHAR, B.scandate, 106) AS SCAN_DATE ,
        CASE WHEN ( PVL.DOCKNO IS NOT NULL ) THEN 'YES'
             ELSE 'NO'
        END IS_VIEWED_BY_ADMIN ,
        CONVERT(VARCHAR, PVL.ViewDate, 106) AS VIEWED_DATE ,
        CW.WK ,
        CASE WHEN ( SVS.Status IS NOT NULL ) THEN SVS.Status
             WHEN ( PVL.DOCKNO IS NOT NULL ) THEN 'NO STATUS DECLARED'
        END DECLARED_STATUS ,
        SV.StatusCategory [DOUBT_POD_CATEGORY] ,
        SV.NoOfPcs DAMAGE_PCS ,
        STS.SubcategoryName DAMAGE_CLASSIFICATION ,
        SV.Remarks [DOUBT_POD_REMARKS] ,
        CASE WHEN ( SVS.Status = 'DOUBT'
                    AND ISNULL(SV.IsClosed, 0) = 0
                  ) THEN 'OPEN'
             WHEN ( SVS.Status = 'DOUBT'
                    AND ISNULL(SV.IsClosed, 0) = 1
                  ) THEN 'CLOSE'
             ELSE '-'
        END BAD_OPEN_OR_CLOSE_STATUS ,
        SV.CloseStatusId ,
        CASE WHEN ( ISNULL(SV.CloseStatusId, 0) = 1 ) THEN 'SUCCESS'
             WHEN ( ISNULL(SV.CloseStatusId, 0) = 2 ) THEN 'UNSUCCESS'
        END CLOSURE_TYPE ,
        CASE WHEN ( SRC.ConNo IS NOT NULL ) THEN SRC.CommDate
        END BAD_STATUS_CLOSE_COMM_DATE ,
        CASE WHEN ( SRC.ConNo IS NOT NULL ) THEN SRC.EnteredOn
        END BAD_STATUS_CLOSED_ON ,
        CASE WHEN ( SRC.ConNo IS NOT NULL ) THEN SRC.Remarks
        END BAD_STATUS_CLOSED_REMARKS ,
        CASE WHEN ( SRC.ConNo IS NOT NULL ) THEN SRC.CommTo
        END BAD_STATUS_CLOSED_COMM_TO ,
        --ESTL_CRP2.dbo.funcGetConLatestRemarks(B.dockno) FINAL_STATUS ,
                --CONVERT(VARCHAR, fin_date, 106) AS DELIVERY_DATE ,
        CONVERT(VARCHAR, DELY_DT, 106) AS DELIVERY_DATE ,
        DELY.DELY_BACODE ,
        BA.banm AS DELY_BANAME ,
        DKT.PKGSNO AS PIECES ,
        PPT.PTMSPTCD AS PARENTCODE ,
        PPT.PTMSPTNM AS PARENTNAME ,
        REPLACE(REPLACE(REPLACE(indus.SIC, ',', ''), CHAR(13), ''), CHAR(10),
                '') CUSTOMER_INDUSTRY ,
        AccountType ,
        HRC.ScoreValue ,
        CASE WHEN ( HRC.ScoreValue >= 0.8 ) THEN 'YES'
             ELSE 'NO'
        END IS_HRC
               -- E.CONStatusCode,
               -- E.CONStatusReason
FROM    espeedage.dbo.SCAN_DOCKET B WITH ( NOLOCK )
        INNER JOIN espeedage.dbo.gl_delivery DEL WITH ( NOLOCK ) ON B.dockno = DEL.con_id
        INNER JOIN ESTL_CRP2.dbo.DKT_DELY DELY WITH ( NOLOCK ) ON B.dockno = DELY.DOCKNO
        INNER JOIN ESTL_CRP2.dbo.BAMS BA WITH ( NOLOCK ) ON BA.bacd = DELY.DELY_BACODE
                                                            AND BA.babrcd = DELY.DESTCD
        LEFT OUTER JOIN espeedage.dbo.tblPODValidatorLog PVL WITH ( NOLOCK ) ON PVL.DOCKNO = B.dockno
        LEFT OUTER JOIN espeedage.dbo.Scan_Validator SV WITH ( NOLOCK ) ON SV.ConNo = B.dockno
        LEFT OUTER JOIN espeedage.dbo.Scan_Validator_StatusMst SVS WITH ( NOLOCK ) ON SV.Status = SVS.StatusId
        LEFT OUTER JOIN ( SELECT    ConNo ,
                                    MAX(AutoID) AutoID
                          FROM      espeedage.dbo.tblPODScanValidatorRC WITH ( NOLOCK )
                          GROUP BY  ConNo
                        ) PSVRC ON PSVRC.ConNo = SV.ConNo
        LEFT OUTER JOIN espeedage.dbo.tblPODScanValidatorRC SRC WITH ( NOLOCK ) ON SV.ConNo = SRC.ConNo
                                                              AND PSVRC.AutoID = SRC.AutoID
                                                              AND SRC.IsClosed = 1
        INNER JOIN ESTL_CRP2.dbo.DOCKET DKT WITH ( NOLOCK ) ON DKT.DOCKNO = B.dockno
        INNER JOIN dbo.brms DBR WITH ( NOLOCK ) ON DKT.REASSIGN_DESTCD = DBR.BRCD
        INNER JOIN dbo.brms ORG WITH ( NOLOCK ) ON DKT.ORGNCD = ORG.BRCD
        INNER JOIN espeedage.dbo.cm_week_tra CW WITH ( NOLOCK ) ON PVL.ViewDate BETWEEN DTFR AND DTTO
        LEFT OUTER JOIN dbo.Con_BalanceSheet_Sales CBS WITH ( NOLOCK ) ON CBS.[Con Number] = B.dockno
        LEFT OUTER JOIN dbo.ptms PTM WITH ( NOLOCK ) ON CBS.[Customer Code] = PTM.PTMSPTCD
        LEFT OUTER JOIN dbo.ptms PPT WITH ( NOLOCK ) ON PPT.PTMSPTCD = ( CASE
                                                              WHEN ( ISNULL(PTM.isparent,
                                                              0) = 0
                                                              AND PTM.parentptmsptcd <> ''
                                                              )
                                                              THEN PTM.parentptmsptcd
                                                              ELSE PTM.PTMSPTCD
                                                              END )
        LEFT OUTER JOIN dbo.brms BRP WITH ( NOLOCK ) ON PPT.PTMSBRCD = BRP.BRCD
        LEFT OUTER JOIN dbo.PCUST_MAIN PM WITH ( NOLOCK ) ON PM.ptmsptcd = PPT.PTMSPTCD
        LEFT OUTER JOIN dbo.tblSicMst indus WITH ( NOLOCK ) ON indus.sicid = PM.SICID
        LEFT OUTER JOIN dbo.tblAccountTypeMst C WITH ( NOLOCK ) ON C.AccountTypeID = PM.AccountTypeID
        LEFT OUTER JOIN dbo.tblDEPSScoreValues HRC WITH ( NOLOCK ) ON B.dockno = HRC.DOCKNO
        LEFT OUTER JOIN dbo.tblConStatusSubCategoryMst STS ON SV.SubStatusCategoryId = STS.SubCategoryId
WHERE   PVL.ViewDate BETWEEN '2017-10-01'
                     AND     CAST(CONVERT(VARCHAR, GETDATE() - 1, 112)
                             + ' 23:59:00' AS SMALLDATETIME)
        AND SVS.Status = 'DOUBT'
        AND StatusCategory IN ( 'Damage', 'Damge and Theft', 'Pilferage',
                                'Shortage' )



""")
#bad_pod_df=pd.read_excel(r'C:\Users\S2769MAH\Downloads\SQ\sreedhar\Book1.xlsx',sheet_name='Data')


# In[5]:


bad_pod_df=pd.read_sql(query,Utilities.cnxn)


# In[6]:


def getMonth(val):
    try:
        date1=datetime.strptime(val,'%d %b %Y')
        date=datetime.strftime(date1,format='%b-%y')
        return date
    except:
        v=val.split(' ')
        v1=v[0]+'-'+v[1]+'-'+v[2]
        date1=datetime.strptime(v1,'%d-%b-%y')
        date=datetime.strftime(date1,format='%b-%y')
        print (date)
        return date


# In[7]:


bad_pod_df['Month1']=bad_pod_df.apply(lambda x: getMonth(x['VIEWED_DATE']),axis=1)
print (bad_pod_df['Month1'].unique())



# In[8]:


bad_pod_df[['Month1','VIEWED_DATE']].head()
bad_pod_df['DELIVERY_DEPOT'].unique()


# In[9]:


bad_pod_df_toal=pd.pivot_table(bad_pod_df,index=['DELIVERY_DEPOT'],columns=['Month1','BAD_OPEN_OR_CLOSE_STATUS'],values=['CON_NUMBER'],aggfunc={'CON_NUMBER':len},margins=True,fill_value=0)
# val=bad_pod_df_toal.columns.levels[1]
# val=val.drop('All')
# val
# del bad_pod_df_toal[('CON_NUMBER','All')]
# for i in val:
#     bad_pod_df_toal['CON_NUMBER',i,"TOTAL"]=bad_pod_df_toal['CON_NUMBER',i,"OPEN"]+bad_pod_df_toal['CON_NUMBER',i,"CLOSE"]
#     bad_pod_df_toal['CON_NUMBER',i,"Closure Perc%"]=((pd.np.round(bad_pod_df_toal['CON_NUMBER',i,"CLOSE"]*100.0/bad_pod_df_toal['CON_NUMBER',i,"TOTAL"],1).fillna(0)).astype(int))
# pivot_bad_pod_theft_df['TOTAL']=pivot_bad_pod_theft_df['Month1'].CLOSE + pivot_bad_pod_theft_df['Month1'].OPEN
bad_pod_df_toal=bad_pod_df_toal.astype(int)
# bad_pod_df_toal=bad_pod_df_toal.sortlevel([('CON_NUMBER','Month1')],ascending=False)
bad_pod_df_toal


# In[10]:


bad_pod_damage_df=bad_pod_df[bad_pod_df['DOUBT_POD_CATEGORY']=='Damage']
bad_pod_remaining_df=bad_pod_df[bad_pod_df['DOUBT_POD_CATEGORY']!='Damage']

# bad_pod_shortage_df=bad_pod_df[bad_pod_df['DOUBT_POD_CATEGORY']=='Shortage']
# bad_pod_pilferage_df=bad_pod_df[bad_pod_df['DOUBT_POD_CATEGORY']=='Pilferage']
# bad_pod_theft_df=bad_pod_df[bad_pod_df['DOUBT_POD_CATEGORY']=='Damge and Theft']
print (len(bad_pod_damage_df))
print (len(bad_pod_remaining_df))


# In[12]:


pivot_bad_pod_damage_df=pd.pivot_table(bad_pod_damage_df,index=['DELIVERY_DEPOT'],columns=['Month1','BAD_OPEN_OR_CLOSE_STATUS'],values=['CON_NUMBER'],aggfunc={'CON_NUMBER':len},margins=True,fill_value=0)
# val=pivot_bad_pod_damage_df.columns.levels[1]
# val=val.drop('All')
# val
# del pivot_bad_pod_damage_df[('CON_NUMBER','All')]
# for i in val:
#     pivot_bad_pod_damage_df['CON_NUMBER',i,"TOTAL"]=pivot_bad_pod_damage_df['CON_NUMBER',i,"OPEN"]+pivot_bad_pod_damage_df['CON_NUMBER',i,"CLOSE"]
#     pivot_bad_pod_damage_df['CON_NUMBER',i,"Closure Perc%"]=((pd.np.round(pivot_bad_pod_damage_df['CON_NUMBER',i,"CLOSE"]*100.0/pivot_bad_pod_damage_df['CON_NUMBER',i,"TOTAL"],1).fillna(0)).astype(int))
# pivot_bad_pod_theft_df['TOTAL']=pivot_bad_pod_theft_df['Month1'].CLOSE + pivot_bad_pod_theft_df['Month1'].OPEN
pivot_bad_pod_damage_df=pivot_bad_pod_damage_df.astype(int)


# In[13]:


pivot_bad_pod_remaining_df=pd.pivot_table(bad_pod_remaining_df,index=['DELIVERY_DEPOT'],columns=['Month1','BAD_OPEN_OR_CLOSE_STATUS'],values=['CON_NUMBER'],aggfunc={'CON_NUMBER':len},margins=True,fill_value=0)
# val=pivot_bad_pod_remaining_df.columns.levels[1]
# val=val.drop('All')
# val
# del pivot_bad_pod_remaining_df[('CON_NUMBER','All')]
# for i in val:
#     pivot_bad_pod_remaining_df['CON_NUMBER',i,"TOTAL"]=pivot_bad_pod_remaining_df['CON_NUMBER',i,"OPEN"]+pivot_bad_pod_remaining_df['CON_NUMBER',i,"CLOSE"]
#     pivot_bad_pod_remaining_df['CON_NUMBER',i,"Closure Perc%"]=((pd.np.round(pivot_bad_pod_remaining_df['CON_NUMBER',i,"CLOSE"]*100.0/pivot_bad_pod_remaining_df['CON_NUMBER',i,"TOTAL"],1).fillna(0)).astype(int))
# pivot_bad_pod_theft_df['TOTAL']=pivot_bad_pod_theft_df['Month1'].CLOSE + pivot_bad_pod_theft_df['Month1'].OPEN
pivot_bad_pod_remaining_df=pivot_bad_pod_remaining_df.astype(int)


# In[14]:


from pandas import ExcelWriter
with ExcelWriter(r'D:\Data\ODA_Loads_Ton_wise\Month_wise_BADPOD_Closure_Performance_report.xlsx') as writer:
    bad_pod_df_toal.to_excel(writer,engine='xlsxwriter',sheet_name='Depot&Month wise Closure%')
    pivot_bad_pod_damage_df.to_excel(writer,engine='xlsxwriter',sheet_name='Damage Month wise Cls%')
    pivot_bad_pod_remaining_df.to_excel(writer,engine='xlsxwriter',sheet_name='D&T,Pilferage,Shortage Cls%')
    bad_pod_df.to_excel(writer,engine='xlsxwriter',sheet_name='Bad Pod Data')


# In[15]:


filepath=r'D:\Data\ODA_Loads_Ton_wise\Month_wise_BADPOD_Closure_Performance_report.xlsx'


# In[16]:


import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback

oppath1=filepath
#FTP Upload starts
print ('Logging in...')
ftp = ftplib.FTP()  
ftp.connect(Utilities.ie_ip)  
print (ftp.getwelcome())
try:  
    try:  
        ftp.login(Utilities.sq_username, Utilities.sq_pwd)
        print ('login done')
        ftp.cwd('Auto_reports')  
        #ftp.cwd('FIFO')
        # move to the desired upload directory  
        print ("Currently in:", ftp.pwd()) 
        print ('Uploading...')  
        fullname = oppath1
        name = os.path.split(fullname)[1]  
        f = open(fullname, "rb")  
        ftp.storbinary('STOR ' + name, f)  
        f.close()  
        print ("OK"  )
        print ("Files:")  
        print (ftp.retrlines('LIST'))
    finally:  
        print ("Quitting...")
        ftp.quit()  
except:  
    traceback.print_exc()


# In[17]:


start_date='1-Oct-2017'
edt=datetime.now()
end_date=datetime.strftime(edt,'%d-%b-%Y')
end_date


# In[18]:


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os

from_addr = 'mis.ho@spoton.co.in'
#to_addr = ['rajesh.mp@spoton.co.in','banusanketh.dc@spoton.co.in','mahesh.reddy@spoton.co.in']
#to_addr = ['maheshmahesh11464@gmail.com','mahesh.reddy@spoton.co.in']
# cc_addr = ['sharanagouda.biradar@spoton.co.in','mahesh.reddy@spoton.co.in']
cc_addr=['pawan.sharma@spoton.co.in','SQ_spot@spoton.co.in']
# bcc_addr = ['rajesh.mp@spoton.co.in']
bcc_addr=['vishal.gp@spoton.co.in','abhishek.cv@spoton.co.in','dhiraj.patil@spoton.co.in','rom_spot@spoton.co.in','aom_spot@spoton.co.in','dom_spot@spoton.co.in','spot_security@spoton.co.in','shamsher.khan@spoton.co.in','dilip.singh@spoton.co.in','trilochan.panda@spoton.co.in','achintya.paul@spoton.co.in','pramod.pandey@spoton.co.in','awadhesh.kumar.mishra@spoton.co.in','lingaraj.chidambaram@spoton.co.in','vishal.kadam@spoton.co.in','md.zaya@spoton.co.in','suresh.d@spoton.co.in','poornima.v@spoton.co.in','sanjay.padhy@spoton.co.in','ashwani.gangwar@spoton.co.in','anitha.thyagarajan@spoton.co.in']

username = 'mis.ho@spoton.co.in'
password = 'Spot@123'

msg = MIMEMultipart()

msg['From'] = from_addr
msg['cc'] = ', '.join(cc_addr)
msg['bcc'] = ', '.join(bcc_addr)
msg['Subject'] = 'BAD POD Closure Performance Report as on '+str(end_date)
html='''<html>
<h4>Dear All,</h4>
<p>Please find Closure Performance of BAD POD's report from $start_date - $last_date</p>
<p><strong>Closure Process :</strong> In Doubt POD (IBS) every BAD POD reported by customer should have a closure as below.</p>
<p>&#9679; The Con is genuinely Damaged, then Close - <b>Unsuccessfully</b>, We accept this claim.</p>
<p>&#9679; If only the outer package is damaged & inside contents are intact, and if customer is able to give the clean pod, then close it <b>Successfully with Clean POD</b>, if his behavior is to write remarks even small scratch then still close it will Successfully & update the remarks to whom you have spoken & actual condition of delivery.</p>
<p>&#9679; In Case of Short/Pilferage, a primary investigation to be done @ SC, if not resolved the same to be highlighted to HO, and security team will be involved for further investigate to resolve/recovering of the same.</p>
<p>&#9679; In Case of short/Pilferage, if the left out pcs are delivered take the acknowledgment on the POD and convert that to Clean POD.</p>
</html>'''
html3='''
<h5> Note : For data please click on the below link: </h5>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Month_wise_BADPOD_Closure_Performance_report.xlsx"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Month_wise_BADPOD_Closure_Performance_report.xlsx</p></b>
'''
html1='''<h5>Thanks & Regards</h5></b>
<h5>HO-SQ</h5>'''
    
#  msg.attach(part10)
s = Template(html).safe_substitute(last_date=end_date,start_date=start_date)
report=""
report+=s
report+='<br>'
# report+='<br>'+pivot_stamp_df.to_html()+'<br>'
# report+='<br>'
report+=html3
report+='<br>'
report+=html1
abc=MIMEText(report,'html')
msg.attach(abc)
server = smtplib.SMTP('smtp.sendgrid.net',587)
part=MIMEBase('application','octet-stream')
# part1=MIMEBase('application','octet-stream')
part.set_payload(open(filepath,'rb').read())
# part1.set_payload(open(filepath1,'rb').read())
encoders.encode_base64(part)
# Encoders.encode_base64(part1)
part.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath))
# part1.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath1))
# msg.attach(part)
# msg.attach(part1)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
server.sendmail(from_addr,cc_addr+bcc_addr,msg.as_string())
print ('mail sent succesfully')
server.quit()

