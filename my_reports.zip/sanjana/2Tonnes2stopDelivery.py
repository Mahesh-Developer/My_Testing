
# coding: utf-8

# In[1]:

import pandas as pd
import sframe as gl
#import graphlab as gl
from datetime import datetime, timedelta
import sframe.aggregate as agg
#import graphlab.aggregate as agg
from itertools import permutations
import numpy as np

import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import os
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
# In[2]:
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.87;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()

query = ("""EXEC USP_HUB_THROUGHPUT_DETAILS_SALES_ONEHOUR """)
print (query)

df = pd.read_sql(query, cnxn)

inventory_pd=df[['Hub/SC Location','Arrival Date @ Hub',"Next Frwd Loc","Con Number",'DestnBranch','Act.WtInTonnes','LatestStatusCode',"Volume","TIMESTAMP",'OriginArea','DestnArea','AccountName','Dest Pincode']]
inventory_pd.rename(columns={'Hub/SC Location':"Hub SC Location",'Arrival Date @ Hub':"Arrival Date Hub",'DestnBranch':"Destn Branch",'Act.WtInTonnes':"Act Wt In Tonnes",'LatestStatusCode':"Latest Status Code",'OriginArea':"Origin Area",'DestnArea':'Destn Area','AccountName':'Account Name'},inplace=True)
#converters = {col: str for col in range(8)}
#inventory_pd = pd.read_excel('http://spoton.co.in/downloads/HTR_1HR/HTR_1HR.xls',usecols=["Hub SC Location","Arrival Date Hub","Next Frwd Loc","Con Number","Destn Branch","Act Wt In Tonnes","Latest Status Code","Volume","TIMESTAMP","Origin Area",'Destn Area','Account Name','Dest Pincode'])
localcity = pd.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\Active_Local_BRMS.csv')


# In[3]:

inventory_pd.head(2)


# In[4]:

inventory_pd['Latest Status Code'].fillna('OTR',inplace=True)


# In[5]:

len(inventory_pd)


# In[6]:

inventory_pd = inventory_pd[pd.notnull(inventory_pd['Arrival Date Hub'])]
inventory_pd = inventory_pd[pd.notnull(inventory_pd["Next Frwd Loc"])]


# In[7]:

len(inventory_pd)


# In[8]:

localsclist = localcity['BRCD'].tolist()
inventory_pd = inventory_pd[inventory_pd['Destn Branch'].isin(localsclist)]
len(inventory_pd)


# In[9]:

columnlist = inventory_pd.columns.tolist()
for i in columnlist:
    try:
        if inventory_pd[i][0].dtype=="int64":
            inventory_pd[i].fillna(0,inplace=True)
        else:
            if inventory_pd[i][0].dtype=="float64":
                inventory_pd[i].fillna(0.0,inplace=True)
    except:
        pass


# In[10]:

inventory_pd.to_csv(r'D:\Python\Scripts and Files\Path and Graph Files\inventory_DHD.csv') #writing and accessing agan to solve issue with Sframe


# In[11]:

inventory = gl.SFrame.read_csv(r"D:\Python\Scripts and Files\Path and Graph Files\inventory_DHD.csv")


# In[12]:

#inventory.head(2)


# In[13]:

#inventory["Arrival Date Hub"]=inventory.apply(lambda x: datetime.strptime((str(x["Arrival Date Hub"])
#                                                                .split("+")[0]),"%Y-%m-%d %H:%M:%S"))
inventory["Arrival Date Hub"]=inventory.apply(lambda x: datetime.strptime((str(x["Arrival Date Hub"])
                                                                .split(".")[0]),"%Y-%m-%d %H:%M:%S"))
inventory["TIMESTAMP"]=inventory.apply(lambda x: datetime.strptime
                                       ((str(x["TIMESTAMP"]).split(".")[0]),"%Y-%m-%d %H:%M:%S"))
inventory["Ageing_Hours"]=inventory.apply(lambda x: round
                                          ((x["TIMESTAMP"]-x["Arrival Date Hub"]).seconds*1.0/3600,2))
inventory = inventory[inventory["Ageing_Hours"]>2.0]
inventory["Act Wt In Tonnes"] = inventory.apply(lambda x: round(x["Act Wt In Tonnes"],2))

# In[14]:

inventory.head(2)


# In[15]:

depspaperworkcodelist = ['SRE','SRD','SRS','SRP','DLP','SWP','PWS','HCM','HPM','MOP','SRH','HOC','ONR','SPH','SPO','DBO','DIP','SHS','SSC','HIP','RNX','APT','APN','SHD','SMT','SPL','MSH','UCG','RRA','HPE','WIA','UG1','UG2','UG3','HMP','HWC','NPE','HIM']
inventory2 = inventory.filter_by(depspaperworkcodelist,'Latest Status Code', exclude=True)


# In[16]:

inventory_grp0=inventory2.groupby(key_columns=['Hub SC Location','Destn Area','Account Name','Dest Pincode'],operations={'Sum': agg.SUM('Act Wt In Tonnes')})


# In[17]:

inventory_grp0["Sum"] = inventory_grp0.apply(lambda x: round(x["Sum"],2))


# In[18]:

inventory_grp0.head(5)


# In[19]:

inventory_PNQH = inventory_grp0[(inventory_grp0['Hub SC Location']=='PNQH') & (inventory_grp0['Destn Area']=='PNQA')]


# In[20]:

inventory_PNQH = inventory_PNQH.sort(['Dest Pincode','Sum'], ascending=False)


# In[21]:

inventory_PNQH.head()


# In[22]:

inventory_PNQHgrp = inventory_PNQH.groupby(key_columns=['Dest Pincode','Hub SC Location'],
                                  operations={'Sum': agg.SUM('Sum'),'OD':agg.CONCAT('Account Name','Sum')})


# In[23]:

inventory_PNQHgrp


# In[24]:

import operator
def topload(xdict):
    top2dict = dict(sorted(xdict.iteritems(), key=operator.itemgetter(1), reverse=True)[:2])
    ##if sorted(top2dict.values(), reverse=True)[0]>=2:
        ##top2dict = dict(sorted(xdict.iteritems(), key=operator.itemgetter(1), reverse=True)[:1])
    #print top2dict
    return top2dict


# In[25]:

inventory_PNQHgrp['TopLoad'] = inventory_PNQHgrp.apply(lambda x: topload(x['OD']))


# In[26]:

inventory_PNQHgrp['TopCust'] = inventory_PNQHgrp.apply(lambda x: x['TopLoad'].keys())


# In[27]:

inventory_PNQHgrp['TopStopWt'] = inventory_PNQHgrp.apply(lambda x: sum(x['TopLoad'].values()))


# In[28]:

inventory_PNQHgrp = inventory_PNQHgrp[inventory_PNQHgrp['TopStopWt']>=2.0] #to change later to 2Tonnes


# In[29]:
## For saving with time
datetimenow = datetime.now()

opfilevar=datetimenow.date()
opfilevar1=datetimenow.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=np.round((float(currhrs)/60),0)
## For saving with time

print len(inventory_PNQHgrp)
if len(inventory_PNQHgrp)>0:
    inv_grp = inventory_PNQHgrp[['Dest Pincode','Hub SC Location','TopCust']].stack('TopCust', 'Account Name')
    finalinvdata = inventory2.join(inv_grp, on=["Account Name","Dest Pincode","Hub SC Location"], how="inner") 
    finalinvdata = finalinvdata.sort(["Dest Pincode","Account Name","Act Wt In Tonnes"], ascending=False ) #attachment
    finalgrp=finalinvdata.groupby(key_columns=['Dest Pincode'],operations={'Wt': agg.SUM('Act Wt In Tonnes'),'NoOfStops':agg.COUNT_DISTINCT('Account Name')})
    finalgrp = finalgrp.sort('Dest Pincode') #mailbody
else:
    finalgrp = 'No cons available for direct delivery from hub'
    finalinvdata = gl.SFrame()
    


finalinvdatadf = finalinvdata.to_dataframe()
finalinvdatadf.to_csv(r'D:\Data\Direct_hub_delivery\Data\Inventory_data_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv')
finalinvdatadf.to_csv(r'D:\Data\Direct_hub_delivery\Inventory_data.csv')
oppath5 = r'D:\Data\Direct_hub_delivery\Inventory_data.csv'
# In[30]:

print finalgrp

# In[ ]:
#exit(0)
filePath = oppath5
def sendEmail(#TO = ["OPS.HUB.PNQH.1@spoton.co.in"],
            #TO = ["vishwas.j@spoton.co.in"],
            TO = ["rajeesh.vr@spoton.co.in"],
            CC = ["vishwas.j@spoton.co.in"],
            #CC = ["sopanrao.bhoite@spoton.co.in","ramniwas.sharma@spoton.co.in","sqtf@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "SERVER ETA FTP" + " - " + str(reportts)
    msg["Subject"] = "Direct Hub Delivery Report " + "- "+ str(opfilevar)+"-"+str(opfilevar2)
    body_text = """
    Dear All,

    PFA the Direct Hub Delivery Report for """ + str(opfilevar)+"-"+str(opfilevar2) +"""
    
    PFB the summary."""+str()+"""

"""+str(finalgrp)+"""

    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    #server=smtplib.SMTP('124.7.138.249', 587)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()


