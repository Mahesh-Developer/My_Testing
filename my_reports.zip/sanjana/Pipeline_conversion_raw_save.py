# -*- coding: utf-8 -*-
"""
Created on Sat Apr 23 12:06:56 2016

@author: rajeeshv
"""

import pandas as pd
from datetime import date, timedelta

pipelinedata = pd.read_csv(r'http://10.109.230.50/downloads/PIPELINE_LEAD_REPORT/PIPELINE_LEAD_REPORT.csv')


datenow = date.today()
dateyest = datenow-timedelta(hours=24)
pipelinedata.loc[pipelinedata.index,'Date'] = dateyest

pipelinedata.to_csv(r'D:\Data\Sales_lead_management\Pipeline_raw\Pipeline_raw_'+str(dateyest)+'.csv',encoding='utf-8')
print 'Done 1'



conversiondata = pd.read_csv(r'http://10.109.230.50/downloads/CONVERSION_LEAD_REPORT/CONVERSION_LEAD_REPORT.csv')
conversiondata.loc[conversiondata.index,'Date'] = dateyest
conversiondata.to_csv(r'D:\Data\Sales_lead_management\Conversion_raw\Conversion_raw_'+str(dateyest)+'.csv',encoding='utf-8')
print 'Done 2'