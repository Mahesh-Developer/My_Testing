
# coding: utf-8

# In[1]:

import pandas as pd
from datetime import datetime, date
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import os
import traceback
import ftplib


# In[2]:

fullinvoicedata = pd.read_csv('http://spoton.co.in/downloads/INVOICE_TRACKER_IEP/INVOICE_TRACKER_IEP_REPORT.csv')
print len(fullinvoicedata)

#fullinvoicedata = fullinvoicedata[fullinvoicedata['Type_of_Invoice']=='Freight']
#print len(fullinvoicedata)
# In[3]:



fullinvoicedata = fullinvoicedata[fullinvoicedata['CustomerType']!='Cash']
# In[4]:

# timeformat1 = '%d/%m/%y'
# dayzero1 = '30/12/11'

timeformat1 = '%d/%m/%Y'
dayzero1 = '30/12/2011'
dayzero = datetime.strptime(dayzero1,timeformat1)


# In[5]:

fullinvoicedata = fullinvoicedata.rename(columns={'\xef\xbb\xbfRegion':'Region'})
fullinvoicedata.columns.tolist()


# In[6]:

fullinvoicedata['HO_RO_Despatch_Date'].values[0]


# In[7]:

fullinvoicedata.CC_Recv_Date.fillna(dayzero1, inplace=True)
fullinvoicedata.Physically_Received_by_Authorized_Customer_Date.fillna(dayzero1, inplace=True)
fullinvoicedata.PIS_Date.fillna(dayzero1, inplace=True)
fullinvoicedata.Invoice_Date.fillna(dayzero1, inplace=True)
fullinvoicedata.Submission_to_the_Customer_Date.fillna(dayzero1, inplace=True)
fullinvoicedata['HO_RO_Despatch_Date'] = fullinvoicedata['HO_RO_Despatch_Date'].str.replace('-',dayzero1)
#stdvehinadhocsummarymerge.PUDTYPE2.fillna('STD',inplace=True)


# In[8]:

#fullinvoicedata.to_csv('fullinvoicedata.csv')


# In[9]:

#datecols = [i for i in fullinvoicedata.columns if 'Date' in i]
datecols = ['CC_Recv_Date','Physically_Received_by_Authorized_Customer_Date','PIS_Date','Invoice_Date','HO_RO_Despatch_Date','Submission_to_the_Customer_Date']
type(datecols)


# In[10]:

def convertdate(x):
    try:
        
        x = x.split(' ')[0]
        return datetime.strptime(x,timeformat1)
    except:
        return dayzero


# In[11]:

for datecol in datecols:
    #invoice = invoice.fillna(datecol, dayzero1)
    #invoice = invoice[(invoice[datecol]!='-') or (invoice[datecol]) or (invoice[datecol]!='N') or (invoice[datecol]!='')]
    fullinvoicedata[datecol] = fullinvoicedata.apply(lambda x: convertdate(x[datecol]),axis=1)
    print datecol, len(fullinvoicedata)


# In[12]:

fullinvoicedata['HO_RO_Despatch_Date'].values[0]


# In[13]:

# For elimination of all PIS generated invoices
fullinvoicedata = fullinvoicedata[fullinvoicedata['PIS_Date']==dayzero]
print 'pis eliminated', len(fullinvoicedata)
# For elimination of all PIS generated invoices


# For elimination of all invoices except Freight & Octroi
invoicetypelist = ['Freight','Octroi']
fullinvoicedata = fullinvoicedata[fullinvoicedata['Type_of_Invoice'].isin(invoicetypelist)]
# For elimination of all invoices except Freight & Octroi
print len(fullinvoicedata)



ix = fullinvoicedata[fullinvoicedata['Type_of_Invoice']=='Octroi'].index
fullinvoicedata.loc[ix,'Category'] = 'Octroi'

# In[14]:

stage1df = fullinvoicedata[(fullinvoicedata['Invoice_Date']!=dayzero) & (fullinvoicedata['HO_RO_Despatch_Date']==dayzero) & (fullinvoicedata['Submission_to_the_Customer_Date']==dayzero)]
stage2df = fullinvoicedata[(fullinvoicedata['Invoice_Date']!=dayzero) & (fullinvoicedata['HO_RO_Despatch_Date']!=dayzero) & (fullinvoicedata['Submission_to_the_Customer_Date']==dayzero)]
stage3df = fullinvoicedata[(fullinvoicedata['Invoice_Date']!=dayzero) & (fullinvoicedata['HO_RO_Despatch_Date']!=dayzero) & (fullinvoicedata['Submission_to_the_Customer_Date']!=dayzero) & (fullinvoicedata['PIS_Date']==dayzero)]

#stage1df = fullinvoicedata[(fullinvoicedata['Invoice_Date']!=dayzero) & (fullinvoicedata['HO_RO_Despatch_Date']==dayzero) & (fullinvoicedata['Submission_to_the_Customer_Date']==dayzero)]
#stage2df = fullinvoicedata[(fullinvoicedata['Invoice_Date']!=dayzero) & (fullinvoicedata['HO_RO_Despatch_Date']!=dayzero) & (fullinvoicedata['Physically_Received_by_Authorized_Customer_Date']==dayzero)]
#stage3df = fullinvoicedata[(fullinvoicedata['Invoice_Date']!=dayzero) & (fullinvoicedata['HO_RO_Despatch_Date']!=dayzero) & (fullinvoicedata['Physically_Received_by_Authorized_Customer_Date']!=dayzero) & (fullinvoicedata['PIS_Date']==dayzero)]


#len(stage1df), dayzero, type(dayzero), fullinvoicedata['HO_RODespatchDate'].values[0], type(fullinvoicedata['HO_RODespatchDate'].values[0])
#stage1df.to_csv('D:\Data\Invoice_tracker\stage1df.csv')
#stage2df.to_csv('D:\Data\Invoice_tracker\stage2df.csv')
#stage3df.to_csv('D:\Data\Invoice_tracker\stage3df.csv')

len(stage1df),len(stage2df),len(stage3df)


# In[15]:

todaydate1 = datetime.today()
def diffdate(passdate):
    #passdate = fullinvoicedata['InvoiceDate'].values[0]
    a1 = pd.to_datetime(str(passdate)).replace(tzinfo=None)
    diffdays = int((todaydate1-a1).days)
    return diffdays


# In[16]:

##fullinvoicedata.to_csv('fullinvoicedata.csv')


# In[17]:

stage1df['Stage1_diffdays'] =  stage1df.apply(lambda x : diffdate(x['Invoice_Date']),axis=1)
stage2df['Stage2_diffdays'] =  stage2df.apply(lambda x : diffdate(x['HO_RO_Despatch_Date']),axis=1)
stage3df['Stage3_diffdays'] =  stage3df.apply(lambda x : diffdate(x['Submission_to_the_Customer_Date']),axis=1)


# In[21]:

def tatstage1(podtype):
    if podtype == 'CD Copy':
        return 7
    elif podtype == 'Hard Copy':
        return 12
    elif podtype == 'Soft Copy':
        return 7
    elif podtype == 'Not Required':
        return 1
    elif podtype == 'Octroi':
        return 3
    else:
        return 'check'


# In[22]:

stage1df['TAT'] = stage1df.apply(lambda x:tatstage1(x['Category']),axis=1)


# In[23]:
## For TAT for Octroi invoices

def tatstage2(invoicetype):
    if invoicetype == 'Freight':
        return 5
    elif invoicetype == 'Octroi':
        return 7
    else:
        return 'check'

## For TAT for Octroi invoices

stage2df['TAT'] = stage2df.apply(lambda x:tatstage2(x['Type_of_Invoice']),axis=1)
#stage3df.loc[stage3df.index,'TAT'] = 30


# In[24]:

stage1df['DSO_value'] = stage1df.apply(lambda x :pd.np.round((x['Stage1_diffdays'])*(x['Invoice_Amt']),0),axis=1)
stage2df['DSO_value'] = stage2df.apply(lambda x :pd.np.round((x['Stage2_diffdays'])*(x['Invoice_Amt']),0),axis=1)
stage3df['DSO_value'] = stage3df.apply(lambda x :pd.np.round((x['Stage3_diffdays'])*(x['Invoice_Amt']),0),axis=1)


# In[25]:

def crosstat(tat1,diffdays1):
    if diffdays1>tat1:
        return 'Yes'
    else:
        return 'No'


## For TAT for Octroi invoices
iy = stage3df[stage3df['Type_of_Invoice']=='Octroi'].index
stage3df.loc[iy,'CreditPeriod'] = 15
## For TAT for Octroi invoices

# In[26]:

stage1df['Crossed_TAT'] = stage1df.apply(lambda x :crosstat(x['TAT'],x['Stage1_diffdays']),axis=1)
stage2df['Crossed_TAT'] = stage2df.apply(lambda x :crosstat(x['TAT'],x['Stage2_diffdays']),axis=1)
stage3df['Crossed_TAT'] = stage3df.apply(lambda x :crosstat(x['CreditPeriod'],x['Stage3_diffdays']),axis=1)


# In[28]:

stage1dfgrp = stage1df.groupby(['Category']).agg({'Invoice_No':len,'Invoice_Amt':sum,'DSO_value':sum,'Stage1_diffdays':pd.np.mean}).reset_index()
stage2dfgrp = stage2df.groupby(['Depot']).agg({'Invoice_No':len,'Invoice_Amt':sum,'DSO_value':sum,'Stage2_diffdays':pd.np.mean}).reset_index()
stage3dfgrp = stage3df.groupby(['Depot']).agg({'Invoice_No':len,'Invoice_Amt':sum,'DSO_value':sum,'Stage3_diffdays':pd.np.mean}).reset_index()


# In[29]:

stage1tatyes = stage1df[stage1df['Crossed_TAT']=='Yes']
stage2tatyes = stage2df[stage2df['Crossed_TAT']=='Yes']
stage3tatyes = stage3df[stage3df['Crossed_TAT']=='Yes']


# In[30]:

stage1tatyesgrp = stage1tatyes.groupby(['Category']).agg({'Invoice_No':len,'Invoice_Amt':sum,'DSO_value':sum,'Stage1_diffdays':pd.np.mean}).reset_index()
stage2tatyesgrp = stage2tatyes.groupby(['Depot']).agg({'Invoice_No':len,'Invoice_Amt':sum,'DSO_value':sum,'Stage2_diffdays':pd.np.mean}).reset_index()
stage3tatyesgrp = stage3tatyes.groupby(['Depot']).agg({'Invoice_No':len,'Invoice_Amt':sum,'DSO_value':sum,'Stage3_diffdays':pd.np.mean}).reset_index()


# In[31]:

stage1final = pd.merge(stage1dfgrp,stage1tatyesgrp,on=['Category'],suffixes=['_total','_crossed_TAT'],how='outer')
stage2final = pd.merge(stage2dfgrp,stage2tatyesgrp,on=['Depot'],suffixes=['_total','_crossed_TAT'],how='outer')
stage3final = pd.merge(stage3dfgrp,stage3tatyesgrp,on=['Depot'],suffixes=['_total','_crossed_TAT'],how='outer')


# In[32]:

# stage1final.to_csv('stage1final.csv')
# stage2final.to_csv('stage2final.csv')
# stage3final.to_csv('stage3final.csv')
stage1final['Weighted_avg_DSO'] = stage1final.apply(lambda x:pd.np.round(x['DSO_value_total']/x['Invoice_Amt_total'],0),axis=1)
stage2final['Weighted_avg_DSO'] = stage2final.apply(lambda x:pd.np.round(x['DSO_value_total']/x['Invoice_Amt_total'],0),axis=1)
stage3final['Weighted_avg_DSO'] = stage3final.apply(lambda x:pd.np.round(x['DSO_value_total']/x['Invoice_Amt_total'],0),axis=1)

# In[33]:

stage1final['Weighted_avg_DSO_crossedTAT'] = stage1final.apply(lambda x:pd.np.round(x['DSO_value_crossed_TAT']/x['Invoice_Amt_crossed_TAT'],0),axis=1)
stage2final['Weighted_avg_DSO_crossedTAT'] = stage2final.apply(lambda x:pd.np.round(x['DSO_value_crossed_TAT']/x['Invoice_Amt_crossed_TAT'],0),axis=1)
stage3final['Weighted_avg_DSO_crossedTAT'] = stage3final.apply(lambda x:pd.np.round(x['DSO_value_crossed_TAT']/x['Invoice_Amt_crossed_TAT'],0),axis=1)



def roundoff(diffdays):
    diffdays = pd.np.round(diffdays,0)
    return diffdays

def perc_calc(invoices,cross_tat_invoices):
    perc = pd.np.round((cross_tat_invoices*1.0/invoices)*100,0)
    return perc
    

stage1final['Avg_delay_days_crossedTAT'] = stage1final.apply(lambda x:(roundoff(x['Stage1_diffdays_crossed_TAT'])),axis=1)
stage2final['Avg_delay_days_crossedTAT'] = stage2final.apply(lambda x:(roundoff(x['Stage2_diffdays_crossed_TAT'])),axis=1)
stage3final['Avg_delay_days_crossedTAT'] = stage3final.apply(lambda x:(roundoff(x['Stage3_diffdays_crossed_TAT'])),axis=1)

stage1final['%Invoices_crossTAT'] = stage1final.apply(lambda x: perc_calc(x['Invoice_No_total'],x['Invoice_No_crossed_TAT']),axis=1)
stage2final['%Invoices_crossTAT'] = stage2final.apply(lambda x: perc_calc(x['Invoice_No_total'],x['Invoice_No_crossed_TAT']),axis=1)
stage3final['%Invoices_crossTAT'] = stage3final.apply(lambda x: perc_calc(x['Invoice_No_total'],x['Invoice_No_crossed_TAT']),axis=1)

# In[34]:

stage1final = pd.DataFrame(stage1final,columns=['Category','Invoice_No_total','Invoice_Amt_total','Weighted_avg_DSO','Invoice_No_crossed_TAT','%Invoices_crossTAT','Invoice_Amt_crossed_TAT','Weighted_avg_DSO_crossedTAT','Avg_delay_days_crossedTAT'])
stage2final = pd.DataFrame(stage2final,columns=['Depot','Invoice_No_total','Invoice_Amt_total','Weighted_avg_DSO','Invoice_No_crossed_TAT','%Invoices_crossTAT','Invoice_Amt_crossed_TAT','Weighted_avg_DSO_crossedTAT','Avg_delay_days_crossedTAT'])
stage3final = pd.DataFrame(stage3final,columns=['Depot','Invoice_No_total','Invoice_Amt_total','Weighted_avg_DSO','Invoice_No_crossed_TAT','%Invoices_crossTAT','Invoice_Amt_crossed_TAT','Weighted_avg_DSO_crossedTAT','Avg_delay_days_crossedTAT'])


## Invoice data for FTP

def diffdate_others(date1,date2):
    #passdate = fullinvoicedata['InvoiceDate'].values[0]
    a1 = pd.to_datetime(str(date1)).replace(tzinfo=None)
    diffdays = int((date2-a1).days)
    return diffdays

stage2df['Stage2_1_diff'] =  stage2df.apply(lambda x : diffdate_others(x['Invoice_Date'],x['HO_RO_Despatch_Date']),axis=1)
stage3df['Stage3_1_diff'] =  stage3df.apply(lambda x : diffdate_others(x['Invoice_Date'],x['HO_RO_Despatch_Date']),axis=1)
stage3df['Stage3_2_diff'] =  stage3df.apply(lambda x : diffdate_others(x['HO_RO_Despatch_Date'],x['Submission_to_the_Customer_Date']),axis=1)


stage2df['TAT_1_2'] = stage2df.apply(lambda x:tatstage1(x['Category']),axis=1)
stage3df['TAT_1_3'] = stage3df.apply(lambda x:tatstage1(x['Category']),axis=1)
stage3df.loc[stage3df.index,'TAT_2_3'] = 5


stage1df.loc[stage1df.index,'Disptached'] = 'No'
stage1df.loc[stage1df.index,'Submitted'] = 'No'
stage1df.loc[stage1df.index,'Collected'] = 'No'

stage2df.loc[stage2df.index,'Disptached'] = 'Yes'
stage2df.loc[stage2df.index,'Submitted'] = 'No'
stage2df.loc[stage2df.index,'Collected'] = 'No'

stage3df.loc[stage3df.index,'Disptached'] = 'Yes'
stage3df.loc[stage3df.index,'Submitted'] = 'Yes'
stage3df.loc[stage3df.index,'Collected'] = 'No'

stage1df['Disptached_crossedTAT'] = stage1df.apply(lambda x:x['Crossed_TAT'],axis=1)
stage2df['Submitted_crossedTAT'] = stage2df.apply(lambda x:x['Crossed_TAT'],axis=1)
stage3df['Collected_crossedTAT'] = stage3df.apply(lambda x:x['Crossed_TAT'],axis=1)

stage2df['Disptached_crossedTAT'] = stage2df.apply(lambda x :crosstat(x['TAT_1_2'],x['Stage2_1_diff']),axis=1)
stage3df['Disptached_crossedTAT'] = stage3df.apply(lambda x :crosstat(x['TAT_1_3'],x['Stage3_1_diff']),axis=1)
stage3df['Submitted_crossedTAT'] = stage3df.apply(lambda x :crosstat(x['TAT_2_3'],x['Stage3_2_diff']),axis=1)


stage1df.loc[stage1df.index,'Stage'] = 'Invoiced_but_not_dispatched'
stage2df.loc[stage2df.index,'Stage'] = 'Dispatched_but_not_submitted'
stage3df.loc[stage3df.index,'Stage'] = 'Submitted_but_not_collected'

stage12df = stage1df.append(stage2df,ignore_index=True)
allstagedf = stage12df.append(stage3df,ignore_index=True)

allstagedf = pd.DataFrame(allstagedf,columns=['Region','Depot','Invoice_No','Invoice_Date','InvoiceMonth','Invoice_Amt','Type_of_Invoice','Account_Code','Account_Name','Account_Type','POD_NPOD','Category','Customer_Agreed_Perc','POD_Available_Perc','CC_Name','Despatched_From_RO_HO','HO_RO_Despatch_Date','Reason_for_Not_Despatching_from_HO','Courier_No','Courier_Name','Delivery_Date_Update','Delivery_Status_Remarks','Billing_Co_ordinator_Regional_Print','Billing_Co_ordinator_HandOver_Date','Co_Courier_Date','CC_Delv_Type','CC_Recv_Date','CC_Recv_By','Submission_to_the_Customer_Y_N','Submission_to_the_Customer_Date','Physically_Received_by_Authorized_Customer_Y_N','Physically_Received_by_Authorized_Customer_Date','Agreed_to_Pay_Invoice_Date','Agreed_to_Pay_Invoice_Amount','Date_of_Customer_Payment_Acceptence','Date_of_Customer_Payment_Accept','Equery_No','PIS_No','PIS_Date','PIS_Amount','Latest_Record_Communication','Dunning_Letter_1','Dunning_Letter_2','Dunning_Letter_3','CreditPeriod','Stage','Disptached','Disptached_crossedTAT','Submitted','Submitted_crossedTAT','Collected','Collected_crossedTAT'])


todaydate = date.today() 
allstagedf.to_csv(r'D:\Data\Invoice_tracker\Invoice_data\Invoice_data_'+str(todaydate)+'.csv')
allstagedf.to_csv(r'D:\Data\Invoice_tracker\Invoice_data.csv')

oppath_invoice = r'D:\Data\Invoice_tracker\Invoice_data.csv'


print ('Logging in...')
ftp = ftplib.FTP()
#ftp.connect('119.226.230.94')
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppath_invoice
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()
## Invoice data for FTP


with ExcelWriter(r'D:\Data\Invoice_tracker\Invoice_tracker_summary\Invoice_tracker_summary_'+str(todaydate)+'.xlsx') as writer:
    stage1final.to_excel(writer, sheet_name='Invoiced_not_dispatched',engine='xlsxwriter')
    stage2final.to_excel(writer, sheet_name='Dispatched_not_submitted',engine='xlsxwriter')
    stage3final.to_excel(writer, sheet_name='Submitted_not_collected',engine='xlsxwriter')


# In[40]:

oppath1 = r'D:\Data\Invoice_tracker\Invoice_tracker_summary\Invoice_tracker_summary_'+str(todaydate)+'.xlsx'


# In[42]:

filePath = oppath1
def sendEmail(#TO = ["Manzil.Bhattacharya@Spoton.Co.In","sanath.j@spoton.co.in"],
              TO = ["vishwas.j@spoton.co.in"],
              CC = ["vishwas.j@spoton.co.in"],
              #CC = ["Supratim@iepfunds.com","krishna.chandrasekar@spoton.co.in","abhik.mitra@spoton.co.in","rajeesh.vr@spoton.co.in","vishwas.j@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "Invoice Tracker Summary" + ' - ' + str(todaydate)
    body_text = """
    Dear All,
    
    PFA the Invoice Tracker Summary as of """+str(todaydate)+"""
    
    For the invoice level base data, please use the link below
    
    http://10.109.230.50/downloads/IEProjects/ETA/Invoice_data.csv
    
    """ 

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')


# In[ ]:



