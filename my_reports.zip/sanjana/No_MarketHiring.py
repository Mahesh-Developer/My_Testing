
# coding: utf-8

# In[1]:

import pandas as pd
import datetime
from datetime import timedelta

import os
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from pandas import ExcelWriter
from email import encoders
# In[2]:

pmdlh  = pd.io.excel.read_excel('http://spoton.co.in/downloads/PMDLH/PMDLH.xls')


# In[3]:

routes = pd.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\routes.csv')


# In[4]:

datefilter=(datetime.datetime.today()-timedelta(hours=24)).date()
datefilter1 = datetime.datetime.combine(datefilter, datetime.time(9))


# datefilter2=(datetime.datetime.today()-timedelta(hours=48)).date()
# datefilter1 = datetime.datetime.combine(datefilter, datetime.time(9))

print datefilter1


# In[5]:

reqpmdlh1 = pmdlh[(pmdlh['THC DATE']>=datefilter1)]
mktlh = reqpmdlh1[(reqpmdlh1['ROUTE CODE']=='9888')]

## For filtering out markets >50000
mktlh50 = mktlh[mktlh['COST']>=50000]
mktlh50 = mktlh50[['THC NUMBER', 'ROUTE CODE', 'ROUTE NAME', 'VEHICLE PAYLOAD', 'COST']]
print (len(mktlh50))
## For filtering out markets >50000

# In[6]:

issuedf = pd.merge(mktlh,routes, left_on='NEW PATH', right_on = 'Routes', how = 'inner')
issuedf.to_csv(r'D:\Data\No_market_vehicle_hiring\Poor_Market_Hiring_'+str(datefilter)+'.csv') #save link


# In[7]:

issuedf_mail = issuedf[['THC NUMBER', 'ROUTE CODE', 'ROUTE NAME', 'VEHICLE PAYLOAD', 'COST']]
issuedf_mail = issuedf_mail[issuedf_mail['COST']!=0]



## Appending THCs greater than 50000
issuedf_mail = issuedf_mail.append(mktlh50)
issuedf_mail = issuedf_mail.drop_duplicates('THC NUMBER')
## Appending THCs greater than 50000


issuedf_mail = issuedf_mail.sort_values('COST',ascending=False)
# In[8]:

issuedf_mail.to_csv(r'D:\Python\Scripts and Files\Path and Graph Files\No_MKT_Hire_Lanes_Summary.csv')
mkthireoppath = r'D:\Python\Scripts and Files\Path and Graph Files\No_MKT_Hire_Lanes_Summary.csv'

issuedf_mail = issuedf_mail.to_string(index=False)
# In[ ]:
filePath = mkthireoppath
def sendEmail(TO = ["hubmgr_spot@spoton.co.in"],
             #TO = ["rajeesh.vr@spoton.co.in"],
              #TO = ["vishwas.j@spoton.co.in"],   
              #CC = ["vishwas.j@spoton.co.in"],
             CC = ["krishna.chandrasekar@spoton.co.in","sqtf@spoton.co.in",'prasanna.hegde@spoton.co.in','shashvat.suhane@spoton.co.in'],
             BCC=['mahesh.reddy@spoton.co.in'],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "Monitoring Report " + '- ' + str(yesterdate)
    msg["Subject"] = "No Market Hiring Lanes Report " + '- ' + str(datefilter)
    body_text = """
    Dear All,
    
    PFB the No Market Hiring Lanes Report as of """+str(datefilter)+ """
    
"""+str(issuedf_mail)+"""
    
    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends


