
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta,datetime
import sys
import Utilities
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

reload(sys).setdefaultencoding("ISO-8859-1")


# In[2]:


# cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")


# # In[3]:


# cursor=cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()
# In[4]:

try:
    query=("""EXEC USP_HUB_OTP_REPORT_SCH 'Y' """)
    query


    # In[5]:


    yestarday_df=pd.read_sql(query,Utilities.cnxn)


    # In[6]:


    yestarday_df.rename(columns={'RGALPH':'Region','DEPOT_CODE':'Hub','Dkt_Cnt':'Total','PERCEN':'OTP %'},inplace=True)
    yestarday_df


    # In[7]:


    pivot_yest_df=pd.pivot_table(yestarday_df,index=['Region','Hub'])


    # In[8]:


    pivot_yest_df1=pivot_yest_df.reset_index()


    # In[9]:


    pivot_yest_df1


    # In[10]:


    xls = pd.ExcelFile(r'C:\Users\rajeeshv\Downloads\KPI Targets.xlsx')
    kpi_df = pd.read_excel(xls,sheetname='BR',headers=None,index_col=[0])
    kpi_df1=kpi_df.reset_index()


    # In[11]:


    kpi_df2=kpi_df1[['Region','Branch Code','HUB Connection']]


    # In[12]:


    kpi_df3 = kpi_df2.iloc[1:]
    kpi_df3.rename(columns={'Branch Code':'Hub'},inplace=True)


    # In[13]:


    logs_df = pd.merge(pivot_yest_df1, kpi_df3, how='left',
            left_on=['Region','Hub'], right_on=['Region','Hub'])


    # In[14]:


    logs_df.rename(columns={'HUB Connection':'Target'},inplace=True)
    logs_df['Target']=logs_df['Target']*100.0
    logs_df=logs_df[['Region','Hub','Target','Failure','Total','Success','OTP %']]
    logs_df=pd.np.round(logs_df,1)
    logs_df['Target']=logs_df['Target'].astype(float)

    # In[15]:

    final_logs_df_pivot=pd.pivot_table(logs_df,index=['Region','Hub'],values=['Failure','OTP %','Target','Success','Total'],aggfunc={'Failure':sum,'Target':pd.np.mean,'OTP %':pd.np.mean,'Total':sum,'Success':sum},margins=True)
    #final_logs_df_pivot=pd.pivot_table(logs_df,index=['Region','Hub'],values=['Failure','OTP %','Target','Success','Total'],aggfunc={'Failure':'sum','Target':'sum','OTP %':'sum','Total':'sum','Success':'sum'},margins=True)
    final_logs_df_pivot1=final_logs_df_pivot.reset_index()
    final_logs_df_pivot1=final_logs_df_pivot1[['Region','Hub','Target','Failure','Total','Success','OTP %']]
    final_logs_df_pivot=final_logs_df_pivot[['Target','Failure','Total','Success','OTP %']]
    final_logs_df_pivot1=pd.np.round(final_logs_df_pivot1,1)


    # In[16]:


    def highlight_greater(row):
    #     print (type(row['Target']),row['Target'])
        if row['OTP %'] < row['Target']:
            color = 'red'
        else:
            color='green'

        background = ['color: {}'.format(color) for _ in row]

        return background


    # In[17]:


    logs_df['Target']=pd.to_numeric(logs_df['Target'])


    # In[18]:


    style_1= final_logs_df_pivot1.style.apply(highlight_greater,subset=['OTP %','Target'],axis=1)


    # In[19]:


    #style_1
    style_1=style_1.set_properties(subset=['Target'],color='black')


    # In[20]:


    style_1


    # In[21]:


    html3=style_1.render()


    # In[22]:


    query1=("""EXEC USP_HUB_OTP_REPORT_SCH 'W' """)


    # In[23]:


    week_df=pd.read_sql(query1,Utilities.cnxn)


    # In[24]:


    week_df.rename(columns={'RGALPH':'Region','DEPOT_CODE':'Hub','Dkt_Cnt':'Total','PERCEN':'OTP %'},inplace=True)


    # In[25]:


    week_logs_df = pd.merge(week_df, kpi_df3, how='left',
            left_on=['Region','Hub'], right_on=['Region','Hub'])


    # In[26]:


    week_logs_df.rename(columns={'HUB Connection':'Target'},inplace=True)
    week_logs_df['Target']=week_logs_df['Target']*100.0


    # In[27]:


    pivot_week_logs_df=pd.pivot_table(week_logs_df,index=['Region','Hub'],values=['Failure','OTP %','Target','Success','Total'],aggfunc={'Failure':'sum','Target':'sum','OTP %':'sum','Total':'sum','Success':'sum'},margins=True)


    # In[28]:


    pivot_week_logs_df=pivot_week_logs_df[['Target','Failure','Success','Total','OTP %']]


    # In[29]:


    pivot_week_logs_df1=pd.np.round(pivot_week_logs_df,1)
    #pivot_week_logs_df1[['Target','Failure','Success','Total']].astype(int)


    # In[30]:


    query2=("""EXEC USP_HUB_OTP_REPORT_SCH 'D'""")


    # In[31]:


    details_df=pd.read_sql(query2,Utilities.cnxn)


    # In[32]:


    details_df.rename(columns={'RGALPH':'Region','ControlArea':'Depot','DEPOT_CODE':'Area'},inplace=True)


    # In[33]:


    #C:\Users\S2769MAH\Downloads\SQ\sreedhar\Origin_Feeder_Connection_report_'+str(date2)+'.xlsx') as writer:
    from pandas import ExcelWriter
    with ExcelWriter(r'D:\Data\ODA_Loads_Ton_wise\Hub_Connection_report.xlsx') as writer:
        final_logs_df_pivot.to_excel(writer,engine='xlsxwriter',sheet_name='Yesterday HUB Perf Report')
        pivot_week_logs_df1.to_excel(writer,engine='xlsxwriter',sheet_name='WTD HUB Performance Report')
        details_df.to_excel(writer,engine='xlsxwriter',sheet_name='HUB PERFORMANCE DETAIL RPT')
        
        


    # In[34]:


    from datetime import date,timedelta
    d=date.today()
    print (type(d))
    date1=d-timedelta(1)
    date2=datetime.strftime(date1,'%d-%b-%y')

    filepath=r'D:\Data\ODA_Loads_Ton_wise\Hub_Connection_report.xlsx'


    # In[35]:


    import numpy as np
    import pandas as pd
    import itertools
    import json
    from pandas import ExcelWriter
    from pandas import pivot_table
    from datetime import datetime
    import os
    import ftplib
    import traceback

    oppath1=filepath
    #FTP Upload starts
    print ('Logging in...')
    ftp = ftplib.FTP()  
    ftp.connect('10.109.230.50')  
    print (ftp.getwelcome())
    try:  
        try:  
            ftp.login('HOSQTeam', 'Te@mH0$q')
            print ('login done')
            ftp.cwd('Auto_reports')  
            #ftp.cwd('FIFO')
            # move to the desired upload directory  
            print ("Currently in:", ftp.pwd()) 
            print ('Uploading...')  
            fullname = oppath1
            name = os.path.split(fullname)[1]  
            f = open(fullname, "rb")  
            ftp.storbinary('STOR ' + name, f)  
            f.close()  
            print ("OK"  )
            print ("Files:")  
            print (ftp.retrlines('LIST'))
        finally:  
            print ("Quitting...")
            ftp.quit()  
    except:  
        traceback.print_exc()


    # In[37]:




    from_addr = 'mis.ho@spoton.co.in'
    # to_addr = ['rajesh.mp@spoton.co.in','banusanketh.dc@spoton.co.in','mahesh.reddy@spoton.co.in','shivananda.p@spoton.co.in']
    # to_addr = ['sreedhar.m@spoton.co.in','mahesh.reddy@spoton.co.in']
    # cc_addr = ['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
    cc_addr=['sqtf@spoton.co.in','SQ_SPOT@spoton.co.in','anoop.kumar@spoton.co.in','avnish.tripathi@spoton.co.in']
    # bcc_addr = ['rajesh.mp@spoton.co.in']
    bcc_addr=['AOM_SPOT@spoton.co.in','dom_spot@spoton.co.in','rom_spot@spoton.co.in','hubmgr_spot@spoton.co.in','anitha.thyagarajan@spoton.co.in']

    username = 'mis.ho@spoton.co.in'
    password = 'Raj@spot12.mp'

    msg = MIMEMultipart()

    msg['From'] = from_addr
    # msg['To'] = ', '.join(to_addr)
    msg['cc'] = ', '.join(cc_addr)
    msg['bcc'] = ', '.join(bcc_addr)
    msg['Subject'] = 'HUB Connection - On-Time Performance [OTP]'+str(date2)
    html='''<html>
    <h4>Dear ,All</h4>
    <p>Please find HUB Connection On-Time Performance for $date </p>
    <p style="color:red;">Note: - The Performance is measured as per KPI Targets.</p>
    </html>'''
    html4='''
    <h5> Note : For data please click on the below link: </h5>
    <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Hub_Connection_report.xlsx"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Hub_Connection_report.xlsx</p></b>
    '''
    html1='''<h5>Thanks & Regards</h5></b>
    <h5>HO-SQ</h5>'''
        
    #  msg.attach(part10)
    s = Template(html).safe_substitute(date=date2)
    report=""
    report+=s
    report+='<br>'
    # report+='<br>'
    report+=html3
    report+='<br>'
    report+=html4
    report+='<br>'
    report+=html1
    abc=MIMEText(report,'html')
    msg.attach(abc)
    
    part=MIMEBase('application','octet-stream')
    # part1=MIMEBase('application','octet-stream')
    part.set_payload(open(filepath,'rb').read())
    # part1.set_payload(open(filepath1,'rb').read())
    encoders.encode_base64(part)
    # Encoders.encode_base64(part1)
    part.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath))
    # part1.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath1))
    #msg.attach(part)
    # msg.attach(part1)
    

    # server = smtplib.SMTP('smtp.spoton.co.in',587)
    # server.ehlo()
    # server.starttls()
    # server.ehlo()
    # server.login('mis.ho@spoton.co.in','Mis@2019')
    # server.sendmail(from_addr,cc_addr+bcc_addr,msg.as_string())
    # print ('mail sent succesfully')
    # server.quit()

    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(from_addr,cc_addr+bcc_addr, msg.as_string())
    server.quit()


except:

  TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in']  
  CC=['mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "HUB Connection - On-Time Performance [OTP] Error in Execution" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in HUB Connection - On-Time Performance [OTP]'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO+CC, msg.as_string())
  server.quit()

