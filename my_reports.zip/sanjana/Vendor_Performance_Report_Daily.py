
# coding: utf-8

# In[22]:


import pandas as pd
import numpy as np
from datetime import datetime,timedelta
import pyodbc
from fuzzywuzzy import fuzz
import pandas as pd
import pyodbc
from datetime import datetime,timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
import ftplib
# import Utilities
from calendar import monthrange
import smtplib


# In[2]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")


# In[3]:


df=pd.read_sql('exec sp_spoton_linehaul_arrival',cnxn)


# In[4]:


yestdate=datetime.strftime(datetime.now()-timedelta(days=1),"%Y-%m-%d")
yestdate


# In[5]:


df=df[df['sched_Arrvl_date']==yestdate]

df=df[df['Route_code']!='9888']
len(df)
# In[7]:


#f.to_csv(r'vendor_data.csv')
#

# In[8]:


vendor_list=['MAHENDER CARRIER','TRANS CARGO INDIA','Mehta Road Transport','Suvidha Movers Private Limited','DHL ECOMMERCE (INDIA) LLP']


# In[9]:


df=df[df['Vendor_name'].isin(vendor_list)]
len(df)

def getfirst(x,y):
    if (x=='DELAY ARRIVAL') & (y=='DELAY DEPARTURE'):
        return "ONTIME ARRIVAL"
    else:
        return x


df['Grace_Arrival_Remarks']=df.apply(lambda x:getfirst(x['Grace_Arrival_Remarks'],x['Grace_Departure_Remarks']),axis=1)

def getxyz(x,y):
    #print (x,y)
    if (x=='DELAY ARRIVAL') & any(ele in y for ele in ["VECH LATE DEPART BY ORIGEN","veh delay departed by origin",'VEH LATE ARRIVAL DUE TO LATE DEP','veh late arrival due to late dep t from origin','veh late arrival due to late dept from origin','vehicle late departure from origin','veh delay departed by origin so veh delay arrived']):
        return "ONTIME ARRIVAL"
    else:
        return x

df['Grace_Arrival_Remarks']=df.apply(lambda x:getxyz(x['Grace_Arrival_Remarks'],x['DelayArrivalRemarks']),axis=1)
# In[10]:


advance_exception=['Money','Advance Issue','Advance Payment Issue','Advance Payment']
accident_exception=['Accidents','Turn Down On','Out Of Coverage Area','Hold At Same Place']
weather_exception=['Heavy Rain','Rainy','Rain']
breakdown_exception=['Veh Breakdown','Vehicle Breakdown','Breakdown','Break down','Break Down','Repair','Starting','tarting']
rto_exception=['RTO','Rto','rto']
driver_exception=['Late Arrived','Driver Not Pick The Phone','Number Is Not Connecting','Driver Number Is Not Connecting','Not Getting Address','Driver Issue','Driver Not Given Delay Reason','Delay Reason Driver Not Given','Vehicle Delay Due To Breakdown','Its Getting Delay Due To Second Driver Not Felling Well']
driver_delay_exception=['Vehicle Late Arrived','Driver Not Given Delay','Driver Not Given Delay Reason','Driver Not Pick The Phone']
festival_exception=['Festival']
touching_excepton=['EXTRA TOUCHING','touching point','Touching Location','extra touching given','Extra Hold','Due To Extra Hold']
noentry_exception=['No Entry']
roadblock_exception=['Road Block','Road Blocked By Police','Road Blocked']
routedivert_exception=['Route Divert']
singledriver_exception=['Single Driver','Driver No. Continues Busy']
traficjam_exception=['Traffic','traffic','traffic jam','Traffic Jam']
salestax_exception=['Sale Tax Officer','Sale']
ontime_exception=['Ontime','ontime']


# In[11]:


def getArrvExc(x):
    if x=='-':
        return x
    elif any(ele in x for ele in advance_exception):
        return "Advance Money"
    elif any(ele in x for ele in accident_exception):
        return "Accident"
    elif any (ele in x for ele in weather_exception):
        return "Bad Weather"
    elif any (ele in x for ele in breakdown_exception):
        return "Breakdown"
    elif any (ele in x for ele in rto_exception):
        return "Caught By RTO"
    elif any (ele in x for ele in driver_delay_exception):
        return "Driver Not Given Delay Reason"
    elif any (ele in x for ele in festival_exception):
        return "Festival"
    elif any (ele in x for ele in touching_excepton):
        return "Extra Hold At Touching Loc"
    elif any (ele in x for ele in noentry_exception):
        return "No Entry"
    elif any (ele in x for ele in roadblock_exception):
        return "Road Block"
    elif any (ele in x for ele in routedivert_exception):
        return "Route Divert"
    elif any (ele in x for ele in singledriver_exception):
        return "Single Driver"
    elif any (ele in x for ele in traficjam_exception):
        return "Traffic Jam"
    elif any (ele in x for ele in driver_exception):
        return "Driver issue"
    elif any (ele in x for ele in salestax_exception):
        return "Caught By Sale Tax Officer"
#     elif any (ele in x for ele in ontime_exception):
#         return "Ontime"
    else:
        pass


# In[12]:


df['DelayArrivalRemarks']=df['DelayArrivalRemarks'].fillna('-')


# In[ ]:


# df1=df1[df1['Delayreason']!='-']
# len(df1)


# In[13]:


df['Arrival_Exception']=df.apply(lambda x:getArrvExc(x['DelayArrivalRemarks']),axis=1)


# In[14]:


def getRemarks(x,y,z):
    if x=='DELAY ARRIVAL' and y in ['ok','Ok','OK','OKY','Oky']:
        return "Driver Not Given Delay Reason"
    elif x=='DELAY ARRIVAL' and z==None:
        return "Driver Not Given Delay Reason"
    else:
        return z


# In[15]:


df['Arrival_Exception']=df.apply(lambda x:getRemarks(x['Grace_Arrival_Remarks'],x['DelayArrivalRemarks'],x['Arrival_Exception']),axis=1)


# In[ ]:


# df[df['Grace_Arrival_Remarks']=='DELAY ARRIVAL'][['Grace_Arrival_Remarks','DelayArrivalRemarks','Arrival_Exception']]


# In[17]:


area_dict={'MAHENDER CARRIER':{'TO':['mahesh.reddy@spoton.co.in','deepak.sharma@spoton.co.in','raghavendra.rao@spoton.co.in','soham.kakade@spoton.co.in'],'CC':["mahesh.reddy@spoton.co.in"]},
        'TRANS CARGO INDIA':{'TO':['mahesh.reddy@spoton.co.in','deepak.sharma@spoton.co.in','raghavendra.rao@spoton.co.in','soham.kakade@spoton.co.in'],'CC':["mahesh.reddy@spoton.co.in"]},
        'Mehta Road Transport':{'TO':['mahesh.reddy@spoton.co.in','deepak.sharma@spoton.co.in','raghavendra.rao@spoton.co.in','soham.kakade@spoton.co.in'],'CC':["mahesh.reddy@spoton.co.in"]},
        'Suvidha Movers Private Limited':{'TO':['mahesh.reddy@spoton.co.in','deepak.sharma@spoton.co.in','raghavendra.rao@spoton.co.in','soham.kakade@spoton.co.in'],'CC':["mahesh.reddy@spoton.co.in"]},
       'DHL ECOMMERCE (INDIA) LLP':{'TO':['mahesh.reddy@spoton.co.in','deepak.sharma@spoton.co.in','raghavendra.rao@spoton.co.in','soham.kakade@spoton.co.in'],'CC':["mahesh.reddy@spoton.co.in"]}
       }

# area_dict={'MAHENDER CARRIER':{'TO':['mahesh.reddy@spoton.co.in'],'CC':["mahesh.reddy@spoton.co.in"]},
#         'TRANS CARGO INDIA':{'TO':['mahesh.reddy@spoton.co.in'],'CC':["mahesh.reddy@spoton.co.in"]},
#         'Mehta Road Transport':{'TO':['mahesh.reddy@spoton.co.in'],'CC':["mahesh.reddy@spoton.co.in"]},
#         'Suvidha Movers Private Limited':{'TO':['mahesh.reddy@spoton.co.in'],'CC':["mahesh.reddy@spoton.co.in"]},
#        'DHL ECOMMERCE (INDIA) LLP':{'TO':['mahesh.reddy@spoton.co.in'],'CC':["mahesh.reddy@spoton.co.in"]}
#        }

# In[18]:


yestdate


# In[24]:


FROM="reports.ie@spoton.co.in"


# In[26]:


for i in df['Vendor_name'].unique():
    df1=df[df['Vendor_name']==i]
    summary=df1.pivot_table(index=['Vendor_name'],columns=['Grace_Arrival_Remarks'],aggfunc={'thc_No':len})
    try:
        summary['thc_No','DELAY ARRIVAL']
    except:
        summary['thc_No','DELAY ARRIVAL']=0.0
    summary['thc_No','Total']=summary['thc_No','DELAY ARRIVAL']+summary['thc_No','ONTIME ARRIVAL']
    summary['thc_No','Ontime%']=pd.np.round(summary['thc_No','ONTIME ARRIVAL']*100.0/summary['thc_No','Total'])
    df2=df1[df1['Grace_Arrival_Remarks']=='DELAY ARRIVAL'][['Vendor_name','routename','vehicle_No','Grace_Arrival_Hours','Arrival_Exception']]
    summary1=df1.pivot_table(index=['Vendor_name'],columns=['Arrival_Exception'],aggfunc={'thc_No':len})
    df1.to_csv(r'D:\Data\CNM_Arrv_Dep\Vendor_Performance'+i+'.csv')
    filepath=r'D:\Data\CNM_Arrv_Dep\Vendor_Performance'+i+'.csv'
    TO=area_dict[i]["TO"]
    CC=area_dict[i]["CC"]
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "Vendor Daily Arrival Performance on -"+str(yestdate) + '- ' + i

    report=""
    report+='Dear '+i+' Ji'
    report+='<br>'
    report+='<br>'
    report+="Pls Find the Performance On "+str(yestdate)
    report+='<br>'
    report+='<br>'+summary.to_html()+'<br>'
    report+='<br>'
    report+='<br>'
    report+='<br>'+df2.to_html()+'<br>'
    report+='<br>'
    report+='<br>'
    
    abc=MIMEText(report,'html')
    msg.attach(abc)

    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filepath,"rb").read() )
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
    msg.attach(part)



    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO+CC, msg.as_string())
    server.quit()


# In

