
# coding: utf-8

# In[8]:

import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback
import Utilities

# In[ ]:

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()
query=("""EXEC USP_EWAYBILL_MOTIONCONS_MGMT_SQ""")
print (query)
df=pd.read_sql(query,Utilities.cnxn)


# In[2]:

#df=pd.read_csv(r'C:\Users\rajeeshv\Downloads\Ewaybill_mgmt_summary_06-06-2018\Ewaybill_mgmt_summary_06-06-2018.csv')


# In[3]:

len(df)
reportts = datetime.now()
opfilevar=reportts.date()
opfilevar1=reportts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60
opfilevar2=pd.np.round((float(currhrs)/60),0)

# In[21]:

try:
    ewbna=df[(df['IS_EWAYBILL_REQUIRE']=="YES")&(df['IS_EWAYBILL_AVLB']=="NO")]
    len(ewbna)
    ewb_ntavlb_summary=pd.pivot_table(ewbna,index=['TYPE'],columns=['IS_EWAYBILL_AVLB','IS_UPDATED'],values=['DOCKNO'],aggfunc={'DOCKNO':len})
    ewb_ntavlb_summary.columns = [''.join(col).strip() for col in ewb_ntavlb_summary.columns.values]
    ewb_ntavlb_summary.rename(columns={'DOCKNONONO':'Ewb nt Avlb'},inplace=True)
    ewb_ntavlb_summary1=ewb_ntavlb_summary.reset_index()
    partbewbna=df[(df['IS_EWAYBILL_REQUIRE']=="YES")&(df['IS_EWAYBILL_AVLB']=="YES")&(df['IS_UPDATED']=='NO')]
    partb_ntupdt_summary=pd.pivot_table(partbewbna,index=['TYPE'],columns=['IS_EWAYBILL_AVLB','IS_UPDATED'],values=['DOCKNO'],aggfunc={'DOCKNO':len})
    partb_ntupdt_summary.columns = [''.join(col).strip() for col in partb_ntupdt_summary.columns.values]
    partb_ntupdt_summary.rename(columns={'DOCKNOYESNO':'Ewb PartB Not Updt'},inplace=True)
    partb_ntupdt_summary1=partb_ntupdt_summary.reset_index()
    if len(ewb_ntavlb_summary1)==0:
        ewb_ntavlb_summary1=pd.DataFrame({'TYPE':['HUB-HUB','HUB-SC','SC-HUB','SC-SC'],'Ewb nt Avlb':[0,0,0,0]})

    partb_ntupdt_summary1=pd.merge(partb_ntupdt_summary1,ewb_ntavlb_summary1,on='TYPE',how='outer')
    partb_ntupdt_summary1=partb_ntupdt_summary1.fillna(0)
    partb_ntupdt_summary1['Total']=partb_ntupdt_summary1['Ewb PartB Not Updt']+partb_ntupdt_summary1['Ewb nt Avlb']
    partb_ntupdt_summary2=partb_ntupdt_summary1[['TYPE','Ewb nt Avlb','Ewb PartB Not Updt','Total']]
    #partb_ntupdt_summary2=partb_ntupdt_summary2[['Ewb nt Avlb','Ewb PartB Not Updt','Total']].astype(int)
    for i in partb_ntupdt_summary2.columns:
        if i=='TYPE':
            pass
        else:
            partb_ntupdt_summary2[i]=partb_ntupdt_summary2[i].astype(int)
    hubtohub=df[df['TYPE']=='HUB-HUB']
    ewbntavb_hub=hubtohub[(hubtohub['IS_EWAYBILL_REQUIRE']=='YES')&(hubtohub['IS_EWAYBILL_AVLB']=="NO")]
    hubtohubewnnt=ewbntavb_hub.pivot_table(index=['TCBR'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True)
    hubtohubewnnt=hubtohubewnnt.sort_values(by='DOCKNO',ascending=False)
    ewbpartntavb_hub=hubtohub[(hubtohub['IS_EWAYBILL_REQUIRE']=='YES')&(hubtohub['IS_EWAYBILL_AVLB']=='YES')&(hubtohub['IS_UPDATED']=="NO")]
    ewbpartnthubtohub=ewbpartntavb_hub.pivot_table(index=['TCBR'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True)
    ewbpartnthubtohub=ewbpartnthubtohub.sort_values(by='DOCKNO',ascending=False)
    hubtosc=df[df['TYPE']=='HUB-SC']
    ewbntavb_hubtosc=hubtosc[(hubtosc['IS_EWAYBILL_REQUIRE']=='YES')&(hubtosc['IS_EWAYBILL_AVLB']=="NO")]
    pivot_hubtoscewbnt=pd.pivot_table(ewbntavb_hubtosc,index=['TCBR'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True)
    pivot_hubtoscewbnt=pivot_hubtoscewbnt.sort_values(by='DOCKNO',ascending=False)

    ewbpartbntavb_hubtosc=hubtosc[(hubtosc['IS_EWAYBILL_REQUIRE']=='YES')&(hubtosc['IS_EWAYBILL_AVLB']=='YES')&(hubtosc['IS_UPDATED']=="NO")]
    pivot_hubtoscewbpartbnt=pd.pivot_table(ewbpartbntavb_hubtosc,index=['TCBR'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True)
    pivot_hubtoscewbpartbnt=pivot_hubtoscewbpartbnt.sort_values(by='DOCKNO',ascending=False)
    sctohub=df[df['TYPE']=='SC-HUB']
    ewbntavb_sctohub=sctohub[(sctohub['IS_EWAYBILL_REQUIRE']=='YES')&(sctohub['IS_EWAYBILL_AVLB']=="NO")]
    len(ewbntavb_sctohub)
    pivot_sctohubewbnt=pd.pivot_table(ewbntavb_sctohub,index=['TCBR'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True)
    pivot_sctohubewbnt=pivot_sctohubewbnt.sort_values(by='DOCKNO',ascending=False)
    ewbpartbntavb_sctohub=sctohub[(sctohub['IS_EWAYBILL_REQUIRE']=='YES')&(sctohub['IS_EWAYBILL_AVLB']=='YES')&(sctohub['IS_UPDATED']=="NO")]
    pivot_sctohubewbpartbnt=pd.pivot_table(ewbpartbntavb_sctohub,index=['TCBR'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True)
    pivot_sctohubewbpartbnt=pivot_sctohubewbpartbnt.sort_values(by='DOCKNO',ascending=False)
    len(ewbpartbntavb_sctohub)
    sctosc=df[df['TYPE']=='SC-SC']
    ewbntavb_sctosc=sctosc[(sctosc['IS_EWAYBILL_REQUIRE']=='YES')&(sctosc['IS_EWAYBILL_AVLB']=="NO")]
    pivot_sctoscewbnt=pd.pivot_table(ewbntavb_sctosc,index=['TCBR'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True)
    pivot_sctoscewbnt=pivot_sctoscewbnt.sort_values(by='DOCKNO',ascending=False)
    ewbpartbntavb_sctosc=sctosc[(sctosc['IS_EWAYBILL_REQUIRE']=='YES')&(sctosc['IS_EWAYBILL_AVLB']=='YES')&(sctosc['IS_UPDATED']=="NO")]
    pivot_sctoscewbpartbnt=pd.pivot_table(ewbpartbntavb_sctosc,index=['TCBR'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True)
    pivot_sctoscewbpartbnt=pivot_sctoscewbpartbnt.sort_values(by='DOCKNO',ascending=False)
    len(ewbpartbntavb_sctosc)
    
    ewbna.to_csv(r'D:\Data\Ewaybill\Cons Booked\EWB_Cons_Booked_Not_available_Data'+str(opfilevar)+'_'+str(opfilevar2)+'.csv')
    partbewbna.to_csv(r'D:\Data\Ewaybill\Cons Booked\EWB_Cons_Booked_PartB_Not_updated_Data'+str(opfilevar)+'_'+str(opfilevar2)+'.csv')
    ewbna.to_csv(r'D:\Data\Ewaybill\Cons Booked\EWB_Cons_Booked_Not_available_Data.csv')
    partbewbna.to_csv(r'D:\Data\Ewaybill\Cons Booked\EWB_Cons_Booked_PartB_Not_updated_Data.csv')


    oppath1 = r'D:\Data\Ewaybill\Cons Booked\EWB_Cons_Booked_Not_available_Data.csv'
    oppath2 = r'D:\Data\Ewaybill\Cons Booked\EWB_Cons_Booked_PartB_Not_updated_Data.csv'
    for i in [oppath1,oppath2]:
            oppath1=i
            print ('Logging in...')
            ftp = ftplib.FTP()  
            ftp.connect('10.109.230.50')  
            print (ftp.getwelcome())
            try:  
                try:  
                    ftp.login('HOSQTeam', 'Te@mH0$q')
                    print ('login done')
                    ftp.cwd('Auto_reports')  
                    #ftp.cwd('FIFO')
                    # move to the desired upload directory  
                    print ("Currently in:", ftp.pwd()) 
                    print ('Uploading...')  
                    fullname = oppath1
                    name = os.path.split(fullname)[1]  
                    f = open(fullname, "rb")  
                    ftp.storbinary('STOR ' + name, f)  
                    f.close()  
                    print ("OK"  )
                    print ("Files:")  
                    print (ftp.retrlines('LIST'))
                finally:  
                    print ("Quitting...")
                    ftp.quit()  
            except:  
                traceback.print_exc()

    ewbill_req_count=df[df['IS_EWAYBILL_REQUIRE']=='YES']
    ewbill_avlb_count=df[(df['IS_EWAYBILL_REQUIRE']=='YES') & (df['IS_EWAYBILL_AVLB']=='YES')]
    ewbill_notavlb_count=df[(df['IS_EWAYBILL_REQUIRE']=='YES') &(df['IsExempted']=='N')& (df['IS_EWAYBILL_AVLB']=='NO')]
    ewbill_PARTB_updt_count=df[(df['IS_EWAYBILL_REQUIRE']=='YES') & (df['IS_EWAYBILL_AVLB']=='YES')&(df['IS_UPDATED']=='YES')]
    ewbill_PARTB_notupdt_count=df[(df['IS_EWAYBILL_REQUIRE']=='YES') &(df['IsExempted']=='N')& (df['IS_EWAYBILL_AVLB']=='YES')&(df['IS_UPDATED']=='NO')]

    FROM='mis.ho@spoton.co.in'

    TO=["dom_spot@spoton.co.in","rom_spot@spoton.co.in","sq_spot@spoton.co.in","aom_spot@spoton.co.in",'scincharge_spot@spoton.co.in',"hubmgr_spot@spoton.co.in","cnm@spoton.co.in"]
    CC=['sqtf@spoton.co.in','rajesh.kapase@spoton.co.in']
    BCC=['mahesh.reddy@spoton.co.in','shashvat.suhane@spoton.co.in','gireesh.kumar@spoton.co.in','ajesh.c@spoton.co.in','devakumar.d@spoton.co.in','shejeer.b@spoton.co.in']
    #TO=['mahesh.reddy@spoton.co.in']
    #CC=['mahesh.reddy@spoton.co.in']
    #BCC=['mahesh.reddy@spoton.co.in']

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "Ewaybill Compliance Report for Cons In Motion -" + str(opfilevar)+"-"+str(opfilevar2)
    html3='''
    <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EWB_Cons_Booked_Not_available_Data.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EWB_Cons_Booked_Not_available_Data.csv</p></b>
    <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EWB_Cons_Booked_PartB_Not_updated_Data.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EWB_Cons_Booked_PartB_Not_updated_Data.csv</p></b>
    '''
    report=""
    report+='Dear All,'

    report+='<br>'
    report+='Total Cons = '+str(len(df))
    report+='<br>'
    report+= 'Cons in Motion where Ewaybill required = '+str(len(ewbill_req_count))
    report+='<br>'
    report+= 'Cons in Motion where Ewaybill Available = '+str(len(ewbill_avlb_count))
    report+='<br>'
    report+= 'Cons in Motion where Ewaybill Not Available = '+str(len(ewbill_notavlb_count))
    report+='<br>'
    report+= 'Cons in Motion where Ewaybill Part B Updated = '+str(len(ewbill_PARTB_updt_count))
    report+='<br>'
    report+= 'Cons in Motion where Ewaybill Part B Not Updated = '+str(len(ewbill_PARTB_notupdt_count))
    report+='<br>'
    report+='<br>'
    report+='NOTE: Download the Attachment from the Below link'
    report+='<br>'
    report+='<br>'
    report+='Final Summary'
    report+='<br>'
    report+='<br>'+partb_ntupdt_summary2.to_html()+'<br>'
    report+='HUB-HUB'
    report+='<br>'
    report+='EwayBill Not Available'
    report+='<br>'
    report+='<br>'+hubtohubewnnt.to_html()+'<br>'
    report+='<br>'
    report+='EwayBill PartB Not Updated'
    report+='<br>'
    report+='<br>'+ewbpartnthubtohub.to_html()+'<br>'
    report+='<br>'

    report+='HUB-SC'
    report+='<br>'
    report+='EwayBill Not Available'
    report+='<br>'
    report+='<br>'+pivot_hubtoscewbnt.to_html()+'<br>'
    report+='<br>'
    report+='EwayBill PartB Not Updated'
    report+='<br>'
    report+='<br>'+pivot_hubtoscewbpartbnt.to_html()+'<br>'
    report+='<br>'

    report+='SC-HUB'
    report+='<br>'
    report+='EwayBill Not Available'
    report+='<br>'
    report+='<br>'+pivot_sctohubewbnt.to_html()+'<br>'
    report+='<br>'
    report+='EwayBill PartB Not Updated'
    report+='<br>'+pivot_sctohubewbpartbnt.to_html()+'<br>'
    report+='<br>'

    report+='SC-SC'
    report+='<br>'
    report+='EwayBill Not Available'
    report+='<br>'
    report+='<br>'+pivot_sctoscewbnt.to_html()+'<br>'
    report+='<br>'
    report+='EwayBill PartB Not Updated'
    report+='<br>'+pivot_sctoscewbpartbnt.to_html()+'<br>'
    report+='<br>'


    report+=html3
    abc=MIMEText(report,'html')
    msg.attach(abc)

    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(oppath1,"rb").read() )
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
    #msg.attach(part)

    part1 = MIMEBase('application', "octet-stream")
    part1.set_payload( open(oppath2,"rb").read() )
    encoders.encode_base64(part1)
    part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath2))
    #msg.attach(part1)


    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
    server.quit()
except:
    print ('wrong')
    FROM='mis.ho@spoton.co.in'

    #TO=["dom_spot@spoton.co.in","rom_spot@spoton.co.in","sq_spot@spoton.co.in","aom_spot@spoton.co.in",'scincharge_spot@spoton.co.in',"hubmgr_spot@spoton.co.in","cnm@spoton.co.in"]
    #CC=['sqtf@spoton.co.in','rajesh.kapase@spoton.co.in']
    #BCC=['mahesh.reddy@spoton.co.in','shashvat.suhane@spoton.co.in','vishwas.j@spoton.co.in','gireesh.kumar@spoton.co.in','ajesh.c@spoton.co.in','devakumar.d@spoton.co.in','shejeer.b@spoton.co.in']
    TO=['mahesh.reddy@spoton.co.in']

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "Error Report -" + str(opfilevar)+"-"+str(opfilevar2)

    report=""
    report+='Dear All,'

    report+='<br>'
    report+='There Was Error in Ewaybill Compliance Report for Cons In Motion Subjected Report.'
    report+='<br>'

    abc=MIMEText(report,'html')
    msg.attach(abc)

    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO, msg.as_string())
    server.quit()


# In[ ]:



