
# coding: utf-8

# In[ ]:

import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from string import Template
import ftplib

import sys
import Utilities
querydate=date.today()-timedelta(1)


# In[ ]:

# cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")


print (querydate)

query1=("""EXEC dbo.USP_DELV_EFF_SC_WISE_ALL_BA 'S', '{0}' , '{1}'""".format(querydate,querydate))
query2=("""EXEC dbo.USP_DELV_EFF_SC_WISE_ALL_BA 'D', '{0}' , '{1}'""".format(querydate,querydate))
print (query1)


# In[ ]:

data=pd.read_sql(query1,Utilities.cnxn)
#print (data)
data1=pd.read_sql(query2,Utilities.cnxn)

print (len(data))
print (len(data1))


# In[ ]:

# brcd_list=['BNPF','BRDF','CCUB','CCHF','DGPF','KGPF','MLDF','SNPF','SIKM','BGPF','GYAF','MZPF','BKAF','DBDF','HRZF','RGHF',
# 'NEIR','ANGL','BLSF','BHRF','RRKF','KNLF','PNPF','YMNF','ZRKF','NLGF','PWNB','SLNF','UNAN','IXJF','SXRF','ATQF','BUPF','DBSF',
# 'HSPF','JLSF','IXCF','IXPF','PTLF','PHGF','SRHF','AJMB','ALWF','BHLF','BKBF','JDHF','KTUF','NMWF','SGNR','UDRF','ALIF','AZMF',
# 'BERF','BDHF','FRZF','GOPF','HTRF','JNSF','MTHF','MAUF','MRDF','MJNB','RMPF','SRPF','SJPF','UNAF','BDGF','BWNF','HSSF','ROHF',
# 'MRTF','SHBB','DEDF','HLWN','KSPF','DEDC','ROKF','IXGF','DVGF','IXEF','MYQF','AVNS','ERDF','SLMF','APZF','AGMF','CCJB','COKF',
# 'KLMF','KTMF','TSRF','ANTF','KRMF','MHBF','HYDP','SRPT','WRGF','DINF','IXMF','NGLF','RJPF','SVKF','THIF','TRZF','TCRF','MAAM',
# 'VELF','CDPF','GNTF','KRNF','RJAF','QNBF','AKVF','BHUF','CTLF','IXYF','AMDF','HLLF','JGAF','RAJF','SURF','DMVF','MHPF','GUNA',
# 'GWLF','MNDF','REWF','SGRF','UJJN','BLIB','PABF','AKDF','AMVF','ANRF','BARF','DULF','JLGF','JEJF','KLHF','LNIF','OJRF','PNGF',
# 'RNGF','SGLF','STRF','PNQL','SSEF']
# brms_df=pd.DataFrame({'DEST_BRCD':brcd_list})


# In[ ]:

brms_df=pd.read_excel(r'C:\Users\rajeeshv\Downloads\BA_SC_File.xlsx')


# In[ ]:

brms_df.rename(columns={'RGALPH':'REGION','DEPOT_CODE':'DEPOT','ControlArea':'AREA'},inplace=True)


# In[ ]:

data=pd.merge(data,brms_df,on='DEST_BRCD',how='right')


# In[ ]:

data1=pd.merge(data1,brms_df,on='DEST_BRCD',how='right')


# In[ ]:

data.rename(columns={'CCF': 'CCF_without_DRS_block'}, inplace=True)
data.rename(columns={'NON-CCF': 'STF'}, inplace=True)
data = data.reset_index()
data['CCF']=data['DRS_BLOCK'] + data['CCF_without_DRS_block']


# In[ ]:

# data=data.fillna(0)
# data1=data1.fillna(0)


# In[ ]:

pivot=pd.pivot_table(data,index=["AREA",],columns=['DEL_LOCATION_TYPE'],values=["Opening","Incoming","TOTAL","Delivered","NCF","STF","CCF","DEPS"],aggfunc={"Opening":sum,"Incoming":sum,"TOTAL":sum,"Delivered":sum,"NCF":sum,"STF":sum,"CCF":sum,"DEPS":sum},fill_value=0,margins=True)


# In[ ]:

pivot


# In[ ]:

pivot['DE%'] = pd.np.round((pivot['Delivered','All'] / pivot['TOTAL','All'])*100)
pivot['STF%'] = pd.np.round((pivot['STF','All']/ pivot['TOTAL','All'])*100)
pivot['NCF%']= pd.np.round((pivot['NCF','All'] / pivot['TOTAL','All'])*100)
pivot['CCF%']= pd.np.round((pivot['CCF','All'] / pivot['TOTAL','All'])*100)
pivot['DEPS%']= pd.np.round((pivot['DEPS','All'] / pivot['TOTAL','All'])*100)
pivot['STD_DE%']=pd.np.round((pivot['Delivered','STD']*100.0)/(pivot['Opening','STD']+pivot['Incoming','STD']),2)


# In[ ]:

pivot['ODA_DE%']=pd.np.round((pivot['Delivered','ODA']*100.0)/(pivot['Opening','ODA']),2)
pivot1 = pivot[[("CCF","All"),("NCF","All"),("STF","All"),("DEPS","All"),('Opening','STD'),('Opening','ODA'),('Opening','All'),('Incoming','STD'),('Delivered','STD'),('Delivered','ODA'),('Delivered','All'),('TOTAL','ODA'),('TOTAL','STD'),('TOTAL','All')]].astype(int)
pivot2=pivot[['DE%','STD_DE%','ODA_DE%']]
pivot1=pd.merge(pivot1,pivot2,left_index=True,right_index=True)
pivot1=pivot1[['Opening','Incoming','TOTAL','Delivered','DE%','STD_DE%','ODA_DE%','CCF','NCF','STF','DEPS']]
pivot1['DE%']=pd.np.round(pivot1['DE%'],0)
pivot1['STD_DE%']=pd.np.round(pivot1['STD_DE%'],0)
pivot1['ODA_DE%']=pd.np.round(pivot1['ODA_DE%'],0)




# In[ ]:




# In[ ]:

data=data.fillna(0)


# In[ ]:

pivot_area_summary=pd.pivot_table(data,index=['REGION', 'DEPOT','AREA'],columns=['DEL_LOCATION_TYPE'],values=["Opening","Incoming","TOTAL","Delivered","NCF","STF","CCF","DEPS"],aggfunc={"Opening":sum,"Incoming":sum,"TOTAL":sum,"Delivered":sum,"NCF":sum,"STF":sum,"CCF":sum,"DEPS":sum},fill_value=0,margins=True)
pivot_area_summary['DE%'] = pd.np.round((pivot_area_summary['Delivered','All'] / pivot_area_summary['TOTAL','All'])*100)
pivot_area_summary['STF%'] = pd.np.round((pivot_area_summary['STF','All']/ pivot_area_summary['TOTAL','All'])*100)
pivot_area_summary['NCF%']= pd.np.round((pivot_area_summary['NCF','All'] / pivot_area_summary['TOTAL','All'])*100)
pivot_area_summary['CCF%']= pd.np.round((pivot_area_summary['CCF','All'] / pivot_area_summary['TOTAL','All'])*100)
pivot_area_summary['DEPS%']= pd.np.round((pivot_area_summary['DEPS','All'] / pivot_area_summary['TOTAL','All'])*100)
pivot_area_summary['STD_DE%']=pd.np.round((pivot_area_summary['Delivered','STD']*100.0)/(pivot_area_summary['Opening','STD']+pivot_area_summary['Incoming','STD']),2)
pivot_area_summary['ODA_DE%']=pd.np.round((pivot_area_summary['Delivered','ODA']*100.0)/(pivot_area_summary['Opening','ODA']),2)
pivot3_area = pivot_area_summary[[("CCF","All"),("NCF","All"),("STF","All"),("DEPS","All"),('Opening','STD'),('Opening','ODA'),('Opening','All'),('Incoming','STD'),('Delivered','STD'),('Delivered','ODA'),('Delivered','All'),('TOTAL','ODA'),('TOTAL','STD'),('TOTAL','All')]].astype(int)
pivot4_area=pivot_area_summary[['DE%','STD_DE%','ODA_DE%']]


# In[ ]:

pivot3_area=pd.merge(pivot3_area,pivot4_area,left_index=True,right_index=True)
pivot3_area=pivot3_area.fillna(0)
pivot3_area=pivot3_area[['Opening','Incoming','TOTAL','Delivered','DE%','STD_DE%','ODA_DE%','CCF','NCF','STF','DEPS']]
pivot3_area['DE%']=pd.np.round(pivot3_area['DE%'],0)
pivot3_area['STD_DE%']=pd.np.round(pivot3_area['STD_DE%'],0)
pivot3_area['ODA_DE%']=pd.np.round(pivot3_area['ODA_DE%'],0)


# In[ ]:

pivot3_area


# In[ ]:

pivot_a=pd.pivot_table(data,index=['REGION', 'DEPOT','AREA',"DEST_BRCD"],columns=['DEL_LOCATION_TYPE'],values=["Opening","Incoming","TOTAL","Delivered","NCF","STF","CCF","DEPS"],aggfunc={"Opening":sum,"Incoming":sum,"TOTAL":sum,"Delivered":sum,"NCF":sum,"STF":sum,"CCF":sum,"DEPS":sum},fill_value=0,margins=True)
pivot_a['DE%'] = pd.np.round((pivot_a['Delivered','All'] / pivot_a['TOTAL','All'])*100)
pivot_a['STF%'] = pd.np.round((pivot_a['STF','All']/ pivot_a['TOTAL','All'])*100)
pivot_a['NCF%']= pd.np.round((pivot_a['NCF','All'] / pivot_a['TOTAL','All'])*100)
pivot_a['CCF%']= pd.np.round((pivot_a['CCF','All'] / pivot_a['TOTAL','All'])*100)
pivot_a['DEPS%']= pd.np.round((pivot_a['DEPS','All'] / pivot_a['TOTAL','All'])*100)
pivot_a['STD_DE%']=pd.np.round((pivot_a['Delivered','STD']*100.0)/(pivot_a['Opening','STD']+pivot_a['Incoming','STD']),2)
pivot_a['ODA_DE%']=pd.np.round((pivot_a['Delivered','ODA']*100.0)/(pivot_a['Opening','ODA']),2)
pivot3 = pivot_a[[("CCF","All"),("NCF","All"),("STF","All"),("DEPS","All"),('Opening','STD'),('Opening','ODA'),('Opening','All'),('Incoming','STD'),('Delivered','STD'),('Delivered','ODA'),('Delivered','All'),('TOTAL','ODA'),('TOTAL','STD'),('TOTAL','All')]].astype(int)
pivot4=pivot_a[['DE%','STD_DE%','ODA_DE%']]
pivot3=pd.merge(pivot3,pivot4,left_index=True,right_index=True)
pivot3=pivot3.fillna(0)
pivot3=pivot3[['Opening','Incoming','TOTAL','Delivered','DE%','STD_DE%','ODA_DE%','CCF','NCF','STF','DEPS']]
pivot3['DE%']=pd.np.round(pivot3['DE%'],0)
pivot3['STD_DE%']=pd.np.round(pivot3['STD_DE%'],0)
pivot3['ODA_DE%']=pd.np.round(pivot3['ODA_DE%'],0)


# In[ ]:

pivot3=pivot3.replace([np.inf,-np.inf],np.nan).fillna(0)
pivot1=pivot1.replace([np.inf,-np.inf],np.nan).fillna(0)
pivot3_area=pivot3_area.replace([np.inf,-np.inf],np.nan).fillna(0)


# In[ ]:

pivot3


# In[ ]:

opening_cons=data['Opening'].sum()
opening_cons


# In[ ]:

data.columns.tolist()


# In[ ]:

incoming_cons=data['Incoming'].sum()
incoming_cons


# In[ ]:

delivered_cons=data['Delivered'].sum()
delivered_cons


# In[ ]:

closing_cons=data['TOTAL'].sum()
closing_cons


# In[ ]:

ccf_cons=data['CCF'].sum()
ccf_per=pd.np.round((ccf_cons/closing_cons)*100,1)
ccf_cons,ccf_per


# In[ ]:

stf_cons=data['STF'].sum()
stf_per=pd.np.round((stf_cons/closing_cons)*100,1)
stf_cons,stf_per


# In[ ]:

data1.columns


# In[ ]:

overall_per=pd.np.round((data['Delivered'].sum()/data['TOTAL'].sum())*100.0,1)
overall_per


# In[ ]:

query3 = ("""
            EXEC UBESP_PUD_ANALYSIS_OPEN_CLOSE_STOCK_ARRV_DELV_SSRS_CS
            """)


closingstockfull=pd.read_sql(query3, Utilities.cnxn)


# In[ ]:

len(closingstockfull)


# In[ ]:

closingstockfull=closingstockfull[closingstockfull['DEST_BRCD'].isin(brms_df['DEST_BRCD'])]


# In[ ]:

len(closingstockfull)


# In[ ]:

from datetime import datetime


# In[ ]:

closingstockfull['Timestamp']=datetime.now()


# In[ ]:

closingstockfull['Timestamp'].dtype


# In[ ]:

len(closingstockfull[closingstockfull['REPORTDATE_MIN_ARRVDT']>24])


# In[ ]:

#closingstockfull['Hours']=(closingstockfull['Timestamp']-closingstockfull['REPORTDATE_MIN_ARRVDT']).hours


# In[ ]:

# file=r'D:\Data\ODA_Loads_Ton_wise\BA_DE\BA_DE.xlsx'
# writer=pd.ExcelWriter(file,engine='openpyxl')
# pivot3.to_excel(writer, sheet_name='pivot',index=None)
# data.to_excel(writer, sheet_name='Con Call Data')
# data1.to_excel(writer, sheet_name='CCF & NCF data')
# pivot3_area.to_excel(writer, sheet_name='Area Wise Summary',index=None)
# writer.save()


# In[ ]:

to_day=date.today()

from pandas import ExcelWriter

# with ExcelWriter(r'D:\Data\ODA_Loads_Ton_wise\BA_DE\BA_DE_'+str(to_day)+'.xlsx') as writer:
#        pivot3.to_excel(writer, sheet_name='pivot',engine='xlsxwriter')
#        data.to_excel(writer, sheet_name='Con Call Data',engine='xlsxwriter')
#        data1.to_excel(writer, sheet_name='CCF_NCF data',engine='xlsxwriter')

# with ExcelWriter(r'D:\Data\ODA_Loads_Ton_wise\BA_DE\BA_DE.xlsx') as writer:
#     pivot3.to_excel(writer, sheet_name='pivot',engine='xlsxwriter',encoding='utf-8')
#     data.to_excel(writer, sheet_name='Con Call Data',engine='xlsxwriter',encoding='utf-8')
#     data1.to_excel(writer, sheet_name='CCF & NCF data',engine='xlsxwriter',encoding='utf-8')
#     pivot3_area.to_excel(writer, sheet_name='Area Wise Summary',engine='xlsxwriter',encoding='utf-8')

# In[ ]:
pivot3.to_csv(r'D:\Data\ODA_Loads_Ton_wise\BA_DE\Sc_Summary_'+str(to_day)+'.csv')
pivot3_area.to_csv(r'D:\Data\ODA_Loads_Ton_wise\BA_DE\Area_Summary_'+str(to_day)+'.csv')
data.to_csv(r'D:\Data\ODA_Loads_Ton_wise\BA_DE\ConCall_Data'+str(to_day)+'.csv')
data1.to_csv(r'D:\Data\ODA_Loads_Ton_wise\BA_DE\CCF_NCF_DATA'+str(to_day)+'.csv')

pivot3.to_csv(r'D:\Data\ODA_Loads_Ton_wise\BA_DE\Sc_Summary.csv')
pivot3_area.to_csv(r'D:\Data\ODA_Loads_Ton_wise\BA_DE\Area_Summary.csv')
data.to_csv(r'D:\Data\ODA_Loads_Ton_wise\BA_DE\ConCall_Data.csv')
data1.to_csv(r'D:\Data\ODA_Loads_Ton_wise\BA_DE\CCF_NCF_DATA.csv')


filepath=r'D:\Data\ODA_Loads_Ton_wise\BA_DE\Sc_Summary.csv'
filepath1=r'D:\Data\ODA_Loads_Ton_wise\BA_DE\ConCall_Data.csv'
filepath2=r'D:\Data\ODA_Loads_Ton_wise\BA_DE\CCF_NCF_DATA.csv'
filepath3=r'D:\Data\ODA_Loads_Ton_wise\BA_DE\Area_Summary.csv'
#filepath=r'D:\Data\ODA_Loads_Ton_wise\BA_DE.xlsx'


# In[ ]:

import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback
for i in [filepath,filepath1,filepath2,filepath3]:
    oppath1=i
    #FTP Upload starts
    print ('Logging in...')
    ftp = ftplib.FTP()  
    ftp.connect('10.109.230.50')  
    print (ftp.getwelcome())
    try:  
        try:  
            ftp.login('HOSQTeam', 'Te@mH0$q')
            print ('login done')
            ftp.cwd('Auto_reports')  
            #ftp.cwd('FIFO')
            # move to the desired upload directory  
            print ("Currently in:", ftp.pwd()) 
            print ('Uploading...')  
            fullname = oppath1
            name = os.path.split(fullname)[1]  
            f = open(fullname, "rb")  
            ftp.storbinary('STOR ' + name, f)  
            f.close()  
            print ("OK"  )
            print ("Files:")  
            print (ftp.retrlines('LIST'))
        finally:  
            print ("Quitting...")
            ftp.quit()  
    except:  
        traceback.print_exc()


# In[ ]:


# In[ ]:

from_addr = 'mis.ho@spoton.co.in'
#to_addr = ['vishwas.j@spoton.co.in']
to_addr = ['prafulla.masurkar@spoton.co.in','Rom_spot@spoton.co.in','Dom_spot@spoton.co.in','Aom_spot@spoton.co.in','BA-AMDD@spoton.co.in','BA-BLRD@spoton.co.in','BA-BOMD@spoton.co.in','BA-CCUD@spoton.co.in','BA-HYDD@spoton.co.in','BA-IDRD@spoton.co.in','BA-IXCD@spoton.co.in','BA-LKOD@spoton.co.in','BA-MAAD@spoton.co.in','BA-NCRD@spoton.co.in','BA-RTKD@spoton.co.in']
cc_addr = ["abhik.mitra@spoton.co.in", "jothi.menon@spoton.co.in","sharmistha.majumdar@spoton.co.in",'rajesh.kumar@spoton.co.in','shivananda.p@spoton.co.in','pawan.sharma@spoton.co.in']
bcc_addr = ['anitha.thyagarajan@spoton.co.in','mahesh.reddy@spoton.co.in']

#cc_addr = ['mahesh.reddy@spoton.co.in']
#bcc_addr=['vishwas.j@spoton.co.in']
username = 'mis.ho@spoton.co.in'
password = 'Mis@2019'

msg = MIMEMultipart()

msg['From'] = from_addr
msg['To'] = ', '.join(to_addr)
msg['cc'] = ', '.join(cc_addr)
msg['bcc'] = ', '.join(bcc_addr)
msg['Subject'] = 'BA Delivery Efficiency with STF/NCF/CCF'
html='''<html>
<h4>Dear All,</h4>
<p>PFA, BA Delivery efficiency with STF/NCF/CCF</p>
</html>'''
# part11=MIMEText(html,'html')
# #msg.attach(part11)

# # html3='''<h3>1. Location type : ALL</h3>'''
# # part15 = MIMEText(html3,'html')
# # msg.attach(part15)
# part12=MIMEText('''<h4>1. Location type : ALL</h4>'''+pivot.to_html(),'html')
# #msg.attach(part12)
# part13=MIMEText('''<h4>2. Location type : STD</h4>'''+pivotS.to_html(),'html')
# #msg.attach(part13)
# part14=MIMEText('''<h4>3. Location type : ODA</h4>'''+pivotO.to_html(),'html')
#msg.attach(part14)
html3='''
<h5> To download the Delivery Efficiency with STF/NCF/CCF data, Please click the link below </h5>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Sc_Summary.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Sc_Summary.csv</p></b>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Area_Summary.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Area_Summary.csv</p></b>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/ConCall_Data.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/ConCall_Data.csv</p></b>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/CCF_NCF_DATA.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/CCF_NCF_DATA.csv</p></b>

'''
html1='''<h5>Thanks & Regards</h5></b>
<h5>HO-SQ</h5>'''

#  msg.attach(part10)
report=""
report+=html
report+='<br>'
report+="Opening Stock : "+str(int(opening_cons))
report+='<br>'
report+='Incoming Stock : '+str(int(incoming_cons))
report+='<br>'
report+="Total Stock Cons : "+str(int(closing_cons))
report+='<br>'
report+="Delivered Cons : "+str(int(delivered_cons))
report+='<br>'
report+='<br>'
report+='TOTAL DE% : '+str(pd.np.round((delivered_cons*100.0/closing_cons),1))
report+='<br>'
report+='<h4>1. Location type : ALL</h4>'
# report+='<br>'
report+='<br>'+pivot1.to_html()+'<br>'
# report+='<br>'
# report+='<h4>2. Location type : STD</h4>'
# # report+='<br>'
# report+='<br>'+pivotS.to_html()+'<br>'
# # report+='<br>'
# report+='<h4>3. Location type : ODA</h4>'
# # report+='<br>'
# report+='<br>'+pivotO.to_html()+'<br>'
report+=html3
report+='<br>'
report+=html1
abc=MIMEText(report,'html')
msg.attach(abc)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
part=MIMEBase('application','octet-stream')
# part1=MIMEBase('application','octet-stream')
part.set_payload(open(filepath,'rb').read())
# part1.set_payload(open(filepath1,'rb').read())
encoders.encode_base64(part)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
server.sendmail(from_addr,to_addr+cc_addr+bcc_addr,msg.as_string())
print ('mail sent succesfully')
server.quit()



# In[ ]:



