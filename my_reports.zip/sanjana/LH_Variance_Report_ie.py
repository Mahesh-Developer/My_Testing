
# coding: utf-8

# In[1]:

import pandas as pd
from datetime import datetime, timedelta
import numpy as np
pd.set_option('display.max_columns',40)
from sqlalchemy import *
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import Utilities
cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=PYTHON_DB;UID=PythonOnline;PWD=P@ssw0rd123$")


startdate=datetime.strftime(datetime.now()-timedelta(days=31),"%Y-%m-%d")
print (startdate)
df = pd.read_sql("SELECT * FROM LH30days WHERE [THC DATE] >='{0}'".format(startdate),cnxn)
df=df[~(df["Vech Type"].isin(['DATAVECHILE','VIRTUALHUB']))]
dfyest=df[(df["THC DATE"]>=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)-timedelta(days=1)))&(df["THC DATE"]<=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)))]
#dfyest-pd.DataFrame()
if len(dfyest)!=0:
    pass
else:
    df=pd.read_excel(r'http://spoton.co.in/downloads/PMDLH/PMDLH.xls')
    df=df[~(df["Vech Type"].isin(['DATAVECHILE','VIRTUALHUB']))]

    
print (len(df))
#df.to_csv(r'LH30days_Bhargav.csv')
#df["VEHICLE PAYLOAD"]=df["VEHICLE PAYLOAD"].replace(0,13500)
print (len(df))
def va1(x,y):
  try:
    per=pd.np.round((x*100.0)/y,1)
    return per
  except:
    return 0.0

df["Util%"] = df.apply(lambda x: va1(x["TOTAL ACTUAL LOAD"],x["VEHICLE PAYLOAD"]),axis=1)
df["Vol Util%"] = df.apply(lambda x: va1(x["TOTAL VOL WEIGHT"],x["VEHICLE PAYLOAD"]),axis=1)
thcdatarollgrp=df.pivot_table(index=["NEW PATH"],values=["COST","Util%","ROUTE CODE"],aggfunc={"COST":np.sum,"Util%":np.mean,"ROUTE CODE":lambda x: str(x.value_counts().to_dict())})
thcdatarollgrp["Period"] ="31day"
thcdatarollgrp["COST"] = thcdatarollgrp["COST"]*1.0/31
dfmtd=df[(df["THC DATE"]>=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)-timedelta(days=1)).replace(day=1))&(df["THC DATE"]<=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)))]
thcdatamtdgrp=dfmtd.pivot_table(index=["NEW PATH"],values=["COST","Util%","ROUTE CODE"],aggfunc={"COST":np.sum,"Util%":np.mean,"ROUTE CODE":lambda x: str(x.value_counts().to_dict())})
thcdatamtdgrp["Period"] ="MTD"
thcdatamtdgrp["COST"] = thcdatamtdgrp["COST"]*1.0/((datetime.today()-timedelta(days=1)).day)
dfyest=df[(df["THC DATE"]>=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)-timedelta(days=1)))&(df["THC DATE"]<=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)))]

thcdatayestgrp=dfyest.pivot_table(index=["NEW PATH"],values=["COST","Util%","ROUTE CODE"],aggfunc={"COST":np.sum,"Util%":np.mean,"ROUTE CODE":lambda x: str(x.value_counts().to_dict())})
thcdatayestgrp["Period"] ="Yest"
for i in [thcdatarollgrp,thcdatamtdgrp,thcdatayestgrp]:
    i["COST"]=i["COST"].astype(int)
    i.rename_axis({"ROUTE CODE":"Freq"},axis=1,inplace=True)
thcdatafinal=pd.concat([np.round(thcdatarollgrp),np.round(thcdatamtdgrp),np.round(thcdatayestgrp)],axis=0)
df1 = thcdatafinal.reset_index().pivot_table(values=["COST"],index="NEW PATH",columns="Period",aggfunc="sum",fill_value=0)
df2 = thcdatafinal.reset_index().pivot_table(values=["Util%"],index="NEW PATH",columns="Period",aggfunc="mean",fill_value=0)
df3 = thcdatafinal.reset_index().pivot_table(values=["Freq"],index="NEW PATH",columns="Period",aggfunc="sum",fill_value=0)
df4 = pd.concat((df1,df2,df3), axis=1)
df4["Var"]=df4.apply(lambda x: x["COST"]["Yest"]-x["COST"]["31day"],axis=1)
df4.sort_values('Var',ascending=False,inplace=True)
df6 = df4.reset_index()
# cnxn1 = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.87;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
#cnxn1=cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# 
# cursor1 = cnxn1.cursor()
#livetc = pd.read_excel("http://spoton.co.in/downloads/TCR_UND_2HRS/TCR_UND_ISDEPART_YES_2HRS_NEXT_TO_NEXT.xls")
cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# 
stockquery1 = ("""SELECT     *
 
 
  FROM tblTimeConnectionReport_Undelivered_2HRS   
    WHERE ISDEPARTED_FRM_CURRLOC='YES'""")
print (stockquery1)

livetc=pd.read_sql(stockquery1,cnxn)
print (len(livetc),'livetc')
livetc.rename(columns={'CDELDT':'DUE DATE','ORIGIN_BRCODE':'ORIGIN BRCODE','CURR_BRANCHCODE':'CURR BRANCHCODE','ISDEPARTED_FRM_CURRLOC':'IS DEPARTED FRM CURRLOC','DEPARTURE_TIME_FRM_CURLOC':'DEPARTURE TIME FRM CURLOC','DEPARTURE_TO_LOC_FRM_CURLOC':'DEPARTURE TO LOC FRM CURLOC','DEPARTED_FRM_CURRLOC_THCNO':'DEPARTED FRM CURRLOC THCNO','DEPARTED_FRM_CURRLOC_ROUTECD':'DEPARTED FRM CURRLOC ROUTECD','DEPARTED_FRM_CURRLOC_VEHNO':'DEPARTED FRM CURRLOC VEHNO','DOCKDT':'PICKUP DATE','LatestConStatusCode':'Latest Con Status Code','TCNO_FROM_HUB':'TCNO FROM HUB','THC_VENDOR_TYPE':'THC VENDOR TYPE','THC_SOURC':'THC SOURC','THC_DEST':'THC DEST','THC_ETA':'THC ETA','THC_ARRI_ENTRY':'THC ARRI ENTRY','THC_LAST_UPDATE_HR':'THC LAST UPDATE HR','THC_ROUTE_NAME':'THC ROUTE NAME','THC_LAST_TIME':'THC LAST TIME','ApptmntDelDate':'Apptmnt Del Date','TIME_STAMP':'TIMESTAMP'},inplace=True)
# 
def convertdate(x):
    try:
        retval =  datetime.strptime(str(x).split(":")[0],"%Y-%m-%d %H")
    except:
        retval = datetime.strptime("2017-01-01 00","%Y-%m-%d %H")
    return retval
yeststart = datetime.today().replace(hour=9,minute=0,second=0,microsecond=0) - timedelta(days=1)
yestend = datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)
livetcselect = livetc.loc[:,["DOCKNO","DEPARTURE TIME FRM CURLOC","CURR BRANCHCODE","DEPARTURE TO LOC FRM CURLOC","PICKUP DATE","ARRV_AT_CURR_LOCATION"]]
print (len(livetcselect),'livetcselect')
livetcselect["NEW PATH"]=livetcselect.apply(lambda x: x["CURR BRANCHCODE"]+"-"+x["DEPARTURE TO LOC FRM CURLOC"], axis=1)
livetcselect["PICKUP DATE"]=livetcselect.apply(lambda x: convertdate(x["PICKUP DATE"]),axis=1)
livetcselect["DEPARTURE TIME FRM CURLOC"]=livetcselect.apply(lambda x: convertdate(x["DEPARTURE TIME FRM CURLOC"]),axis=1)
livetcselect = livetcselect[livetcselect["DEPARTURE TIME FRM CURLOC"]!=datetime.strptime("2017-01-01 00","%Y-%m-%d %H")]
livetcselect = livetcselect[livetcselect["PICKUP DATE"]!=datetime.strptime("2017-01-01 00","%Y-%m-%d %H")]
print (len(livetcselect))
print (livetcselect.dtypes)
#livetcselect['ARRV_AT_CURR_LOCATION']=livetcselect['ARRV_AT_CURR_LOCATION'].fillna(livetcselect['ARRV_AT_CURR_LOCATION'].isnull(),None)
# livetcselect.to_csv(r'LH_V.csv')
# 
# print (livetcselect[livetcselect['ARRV_AT_CURR_LOCATION'].isnull()])
# exit(0)
livetcselect=livetcselect[~livetcselect['ARRV_AT_CURR_LOCATION'].isnull()]
livetcselect["ARRV_AT_CURR_LOCATION"]=livetcselect.apply(lambda x: datetime.strptime(str(x["ARRV_AT_CURR_LOCATION"]).split(":")[0],"%Y-%m-%d %H"),axis=1)
livetcselect["ageofcon"]=livetcselect.apply(lambda x: (x["DEPARTURE TIME FRM CURLOC"]-x["PICKUP DATE"]).days*24+(x["DEPARTURE TIME FRM CURLOC"]-x["PICKUP DATE"]).seconds/3600,axis=1)
livetcselect["agefromloc"]=livetcselect.apply(lambda x: (x["DEPARTURE TIME FRM CURLOC"]-x["ARRV_AT_CURR_LOCATION"]).days*24+(x["DEPARTURE TIME FRM CURLOC"]-x["ARRV_AT_CURR_LOCATION"]).seconds/3600,axis=1)
livetcselect = livetcselect[(livetcselect["DEPARTURE TIME FRM CURLOC"]>=yeststart) & (livetcselect["DEPARTURE TIME FRM CURLOC"]<=yestend)]
livedf = livetcselect.groupby(['NEW PATH']).agg({'ageofcon':np.mean,'agefromloc':np.mean}).reset_index()
livedf['ageofcon']=livedf.apply(lambda x: round(x['ageofcon'],1),axis=1)
livedf['agefromloc']=livedf.apply(lambda x: round(x['agefromloc'],1),axis=1)
livedf = livedf.set_index("NEW PATH")
df7 = df6.join(livedf,on="NEW PATH",how='left')

from datetime import date,timedelta
todate=date.today()
today_date=datetime.strftime(todate,'%d-%m-%Y')
today_date
df7=df7.loc[:,[('NEW PATH',''),('Var',''),('Util%','31day'),(u'Util%', u'MTD'),(u'Util%', u'Yest'),(u'Freq', u'MTD'),(u'Freq', u'Yest'),'agefromloc','ageofcon']]
df7.to_csv(r'D:\Data\Appointment Reports\LH Variance\LHvar'+str(today_date)+'.csv')
filepath=r'D:\Data\Appointment Reports\LH Variance\LHvar'+str(today_date)+'.csv'



#vishwas.j@spoton.co.in
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

# TO=['mahesh.reddy@spoton.co.in']
TO=['satya.pal@spoton.co.in','krishna.chandrasekar@spoton.co.in','pawan.sharma@spoton.co.in','prasanna.hegde@spoton.co.in','saptarshi.pathak@spoton.co.in',"shashvat.suhane@spoton.co.in","ashwani.gangwar@spoton.co.in"]
FROM="reports.ie@spoton.co.in"
CC=['mahesh.reddy@spoton.co.in','vineet.vikram@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = "LH Variance Report RDB" + " - " + str(today_date)
html='''<html>
<style>
p
{
  margin:0;
  margin-top: 5px;
  padding:0;
  font-size:17px;
    line-height:20px;
}
</style>
</html>'''

# html3='''
# <h5> For the base data, please refer the link </h5>
# <p><a href= "http://spoton.co.in/downloads/OCID/OCID.xls"</a>http://spoton.co.in/downloads/OCID/OCID.xls</p></b>
# '''
s = Template(html).safe_substitute(date=today_date)
report=""
report+=s
report+='<br>'
report+='<br>'+df7.head(20).to_html()+'<br>'
#report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()
