
# coding: utf-8

# In[1]:


import ast
import pandas as pd
from datetime import datetime, timedelta
from itertools import permutations
import numpy as np
import Utilities
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template
# In[2]:
import pyodbc
cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=PYTHON_DB;UID=PythonOnline;PWD=P@ssw0rd123$")
#try:
#df=pd.read_csv(r'http://spoton.co.in/downloads/IEP_CON_THC_DATA_DAILY/IEP_CON_THC_DATA_DAILY.csv')
query = ("""exec USP_CON_THC_DAILY_DATA""")
print (query)
df = pd.read_sql(query, Utilities.cnxn)
print (len(df),'df')

df.rename(columns={'Con No':'Con_No','TC Dest':'TC_Dest','TC Source':'TC_Source','THC Transaction Date':'THC_Transaction_Date','THC Date':'THC_Date','TC Date':'TC_Date'},inplace=True)

for i in ["Pickupdate","DueDate","THC_Transaction_Date","THC_Date","TC_Date"]:
  df[i]=pd.to_datetime(df[i],format="%d/%m/%Y %H:%M")

dfyest=df[(df["TC_Date"]>=((datetime.today()).replace(hour=9,minute=0,second=0,microsecond=0)-timedelta(days=1)))&(df["TC_Date"]<=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)))]


# In[3]:


#2. Adding Residual Path & Ideal Next Location
import pickle
# try:
#     pkl_file = open(r'C:\users\ankitgoel888\downloads\path_dict.pkl', 'rb')
# except:
#     pkl_file = open(r'C:/Users/ankit/Dropbox/Python/LH/Paths_testrest/path_dict.pkl', 'rb')

try:
  pkl_file = open(r'D:\Path Dict\path_dict.pkl', 'rb')
except:
  pkl_file = open(r'D:\Path Dict\path_dict.pkl', 'rb')


path_dict = pickle.load(pkl_file)
pkl_file.close()
dfyest=dfyest.loc[:,["TC_Source","TC_Dest","Destn","Act_Wt","Con_No"]]
dfyest["Resid_Path"]=dfyest.apply(lambda x: path_dict.get((x['TC_Source'],x['Destn'])),axis=1)


# In[4]:


dfyest["Resid_Path"]=dfyest.apply(lambda x: path_dict.get((x['TC_Source'],x['Destn'])),axis=1)
dfyest=dfyest.replace({'MNSB ':'MNSB','GAUH':'GAUB','PNWH':'PWNB'})


# In[5]:


dfyest=dfyest[dfyest["Resid_Path"].notnull()]

def getNextLoc(x):
  try:
    nextloc=x[0][1]
    return nextloc
  except:
    nextloc=x[0][0]
    return nextloc
# dfyest["NextLoc"]=dfyest["Resid_Path"].map(lambda x: x[0][1])
dfyest["NextLoc"]=dfyest.apply(lambda x: getNextLoc(x["Resid_Path"]),axis=1)
dfyest["error"]=dfyest["TC_Dest"]!=dfyest["NextLoc"]
errordf=dfyest[dfyest["error"]==True]


# In[14]:


errordf["Resid_Path2"]=errordf["Resid_Path"].astype(str)
errordf=errordf[errordf["Resid_Path2"].str.len()>18] #More than 2 in resid path
errordf["Resid_Path2"]=errordf["Resid_Path2"].map(lambda x: ast.literal_eval(x)[0])
errordf["inpath"]=errordf.apply(lambda x: x["TC_Dest"] in (x["Resid_Path2"]),axis=1)
errordf=errordf[errordf['inpath']==False]
errordf["chartest"]=errordf.apply(lambda x: x["TC_Dest"][0:3]==x["NextLoc"][0:3],axis=1)
errordf=errordf[errordf['chartest']==False]
opttuples=[("DELH","IDRH","HYDH"),("DEDC","DELH","HDRB"),("BLRT","MAAB","BLRH"),("BBIH","BRGH","IXRB"),("DELH","IDRH","HYDH"),("DELH","AMCH","LUHB"),("DELH","LUHB","AMCH"),("AMDH","PNQH","BOMH"),("DELH","IXCB","AMCH"),("BRGH","PNQH","NAGH"),("DELH","PNQH","BLRH"),("SNRH","BOMH","PNQH"),("COKB","BLRH","CJBH"),("NDAB","DELH","GZBH"),("CCUH","BRGH","KNPH")]
for i in opttuples:
  errordf=errordf[~((errordf["TC_Source"]==i[0])&(errordf["TC_Dest"]==i[1])&(errordf["NextLoc"]==i[2]))]

optrouting=["SPTFBLRH","BLRHSPTF","JAIHALWF","ALWFJAIH"]
errordf["Optkey"]=errordf["TC_Source"]+errordf["Destn"]
errordf=errordf[~errordf["Optkey"].isin(optrouting)]


# In[15]:


errordf["Resid_Path2"]=errordf["Resid_Path2"].astype(str)
errordfpivot=errordf.pivot_table(index=["TC_Source","TC_Dest","Destn","NextLoc","Resid_Path2"],aggfunc={"Act_Wt":np.sum,"Con_No":len}).reset_index().sort_values("Act_Wt",ascending=False)

from sqlalchemy import *

listoflists = pd.read_sql("select * from listoflists",cnxn)
listoflists["SC"] = listoflists["SC"].apply(ast.literal_eval)
areadf=listoflists.loc[:,['default','SC']].set_index('default').apply(lambda x: pd.Series(x['SC']),axis=1).stack().reset_index(level=1, drop=False).reset_index().drop({'level_1'},axis=1).rename_axis({0:'SC'},axis=1)
sctobrlistdict=areadf.set_index('SC')['default'].to_dict()
errordfpivot['destlist']=errordfpivot['Destn'].map(sctobrlistdict)

finaldf=errordfpivot.pivot_table(index=['TC_Source','TC_Dest','NextLoc','destlist'],aggfunc={"Destn":lambda x: tuple(np.unique(x)),"Resid_Path2":lambda x: np.unique(x)[0],"Act_Wt":np.sum,"Con_No":np.sum}).reset_index().sort_values("Act_Wt",ascending=False)


pd.set_option('display.max_columns',40)
from sqlalchemy import *

startdate=datetime.strftime(datetime.now()-timedelta(days=2),"%Y-%m-%d")
#lhdf = pd.read_sql("SELECT * FROM LH30days WHERE [THC DATE] >='{0}'".format(startdate),Utilities.cnxn)
lhdf = pd.read_sql("SELECT * FROM LH30days WHERE [THC DATE] >= '{0}'".format(startdate),cnxn)
print (len(lhdf))

lhdf=lhdf[~(lhdf["Vech Type"].isin(['DATAVECHILE','VIRTUALHUB']))]
# print (lhdf[["TOTAL ACTUAL LOAD","VEHICLE PAYLOAD"]])
def va1(x,y):
  try:
    per=pd.np.round((x*100.0)/y,1)
    return per
  except:
    return 0.0
lhdf["Util%"] = lhdf.apply(lambda x: va1(x["TOTAL ACTUAL LOAD"],x["VEHICLE PAYLOAD"]),axis=1)
lhdf["Vol Util%"] = lhdf.apply(lambda x: va1(x["TOTAL VOL WEIGHT"],x["VEHICLE PAYLOAD"]),axis=1)
dfyest=lhdf[(lhdf["THC DATE"]>=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)-timedelta(days=1)))&(lhdf["THC DATE"]<=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)))]
#dfyest=pd.DataFrame()
if len(dfyest)!=0:
  pass
else:
  lhdf=pd.read_excel(r'http://spoton.co.in/downloads/PMDLH/PMDLH.xls')
  #lhdf=lhdf[(lhdf["THC DATE"]>=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)-timedelta(days=1)))&(lhdf["THC DATE"]<=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)))]
  lhdf=lhdf[~(lhdf["Vech Type"].isin(['DATAVECHILE','VIRTUALHUB']))]
  lhdf["Util%"] = lhdf.apply(lambda x: round(x["TOTAL ACTUAL LOAD"]*100.0/x["VEHICLE PAYLOAD"],1),axis=1)
  lhdf["Vol Util%"] = lhdf.apply(lambda x: round(x["TOTAL VOL WEIGHT"]*100.0/x["VEHICLE PAYLOAD"],1),axis=1)
  dfyest=lhdf[(lhdf["THC DATE"]>=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)-timedelta(days=1)))&(lhdf["THC DATE"]<=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)))]



dfyest["ROUTE NAME"]=dfyest["ROUTE NAME"].str.replace(" ","")
dfyest["Route Details"]=dfyest["ROUTE NAME"].str.split("-")
utildf=dfyest.loc[:,["Route Details","Util%","Vol Util%"]]
finaldf["Util%"]=finaldf.apply(lambda x: round(utildf[utildf["Route Details"].astype(str).str.contains(".*"+x["TC_Source"]+".*"+x["NextLoc"]+".*",regex=True)]["Util%"].mean(),1),axis=1)


# In[18]:
df = pd.read_csv(r'http://www.spoton.co.in/downloads/PMD_TC_LINEHAUL_DATA/PMDTCLH.csv')
df["THC_DATE"]=pd.to_datetime(df["THC_DATE"])
df["TC_DATE"]=pd.to_datetime(df["TC_DATE"])
df=df[df["ROUTE_CODE"]!="9888"]
df=df[(df["THC_DATE"]>=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)-timedelta(days=1)))&(df["THC_DATE"]<=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)))]
print (len(df),'df')

from sqlalchemy import *
dfschedule = pd.read_sql("SELECT * FROM schedule where [Active Date]=(select max([Active Date]) FROM schedule)",cnxn)

getkmdict = {} #2. Stored in Dict
for ele in zip(dfschedule['Origin'],dfschedule['Destination'],dfschedule['Transit Distance']):
 getkmdict.update({(ele[0],ele[1]):ele[2]})

dfschedule=dfschedule[dfschedule["Origin"]==dfschedule["Route Details"].str[0:4]]
dfschedule["Routelist"]=dfschedule.apply(lambda x: x["Route Details"].split("-"),axis=1)
dfschedule["OD Routelist"] = dfschedule.apply(lambda x: [[i[0],i[1]] for i in permutations(x['Routelist'],2) if x['Routelist'].index(i[0])<x['Routelist'].index(i[1])],axis=1)

def getkms(odroutelist,routelist): #3. Adding transit time column - function adds tt for touching OD combos as well (unlike ttdict)
 odpathlist=[]
 kms=0.0
 for i in range(routelist.index(odroutelist[0]),(routelist.index(odroutelist[1]))):
     odpathlist = odpathlist+[(routelist[i],routelist[i+1])]
 for i in odpathlist:
     if getkmdict.get((i[0],i[1]))!=None:
         kms = kms+float(str(getkmdict.get((i[0],i[1]))))
     else:
         kms=kms
 return kms

def getkmslist(odroutelist,routelist):
 kmlist=[]
 for i in odroutelist:
     kmlist=kmlist+[getkms(i,routelist)]
 return kmlist

dfschedule["od kms"]=dfschedule.apply(lambda x: getkmslist(x["OD Routelist"],x["Routelist"]),axis=1)
dfschedule=dfschedule.loc[:,["OD Routelist","od kms"]]
dfschedule['stackcol']=dfschedule.apply(lambda x: tuple([x["OD Routelist"][i],x["od kms"][i]] for i in range(len(x["od kms"]))),axis=1)

tcdfschedule=dfschedule['stackcol'].apply(pd.Series).stack().reset_index(level=1, drop=True).to_frame('stackcol')#.join(dfschedule[['user']], how='left')
tcdfschedule["TC_BR"]=tcdfschedule.apply(lambda x: x["stackcol"][0][0],axis=1)
tcdfschedule["TC_TOBRCODE"]=tcdfschedule.apply(lambda x: x["stackcol"][0][1],axis=1)
tcdfschedule["kms"]=tcdfschedule.apply(lambda x: x["stackcol"][1],axis=1)
tcdfschedule=tcdfschedule.groupby(['TC_BR','TC_TOBRCODE']).mean()['kms'].reset_index()
df2=df.merge(tcdfschedule,on=["TC_BR","TC_TOBRCODE"],how="left")
df2["kmsweight"]=df2["kms"]*df2["TOTAL_ACTUAL_LOAD"]
df3=df2.pivot_table(index=["THC_NUMBER","ROUTE_CODE","ROUTE_NAME","NEW_PATH"],aggfunc={"kmsweight":np.sum,"VEHICLE_PAYLOAD":np.mean}).reset_index()
df4=df3[df3["VEHICLE_PAYLOAD"]>500]
dfkms = pd.read_sql("SELECT * FROM schedule where [Active Date]=(select max([Active Date]) FROM schedule)",cnxn)
dfkms=dfkms.pivot_table(index="Route Code",aggfunc={"Transit Distance":np.sum}).reset_index()
dfkms=dfkms.rename_axis({'Route Code':'ROUTE_CODE',"Transit Distance":"Total Kms"},axis=1)
df5=df4.merge(dfkms,on="ROUTE_CODE",how='left')
df5["WtdWt"]=np.round(df5["kmsweight"]/df5["Total Kms"])
df5["WtdUtil"]=np.round(df5["WtdWt"]*100.0/df5["VEHICLE_PAYLOAD"],1)
df6=df5.pivot_table(index=["ROUTE_CODE","ROUTE_NAME"],aggfunc={'VEHICLE_PAYLOAD':np.mean,'WtdUtil':np.mean}).reset_index().sort_values("WtdUtil",ascending=True)
finaldf["WtdUtil%"]=finaldf.apply(lambda x: round(df6[df6["ROUTE_NAME"].astype(str).str.contains(".*"+x["TC_Source"]+".*"+x["NextLoc"]+".*",regex=True)]["WtdUtil"].mean(),1),axis=1)


# In[26]:


finaldf=finaldf[finaldf["WtdUtil%"]<=90.0]
finaldf=finaldf[finaldf["Util%"]<=90.0]


# In[35]:


# For mail
print (finaldf)

finaldf["Optkey2"]=finaldf["TC_Source"]+finaldf["TC_Dest"]+finaldf["NextLoc"]
df7=finaldf.drop(["Optkey2"],axis=1)[0:50].rename_axis({'Destn':'Con_Dest','Resid_Path2':'Ideal_Path_Eg'},axis=1)
df7=df7.reset_index().drop('index',axis=1)


dfdetail=errordf.drop(['Optkey','inpath','chartest','error','Resid_Path'],axis=1)
dfdetail["Key"]=dfdetail["TC_Source"]+dfdetail["TC_Dest"]+dfdetail["NextLoc"]
dfdetail=dfdetail[dfdetail["Key"].isin(finaldf["Optkey2"].values.tolist())]
dfdetail=dfdetail.drop("Key",axis=1)


from datetime import date,timedelta
todate=date.today()
today_date=datetime.strftime(todate,'%d-%m-%Y')
today_date

filepath=r'D:\Data\Appointment Reports\Misrouting\DetailedReport'+str(todate)+'.csv'
filepath2=r'D:\Data\Appointment Reports\DetailedReport'+str(todate)+'.csv'
try:
  dfdetail.to_csv(filepath,encoding='utf-8')
except:
  dfdetail.to_csv(filepath2,encoding='utf-8')


df8=df7.sort_values(by='Act_Wt',ascending=False).head(1000)
print (df8)

# In[30]:

# print (exit(0))
# filepath='C:/users/ankitgoel888/downloads/DetailedReport.csv'
# filepath2='C:/users/ankit/desktop/DetailedReport.csv'
# try:
#     dfdetail.to_csv(filepath,encoding='utf-8')
# except:
#     dfdetail.to_csv(filepath2,encoding='utf-8')



TO=['HUBMGR_SPOT@spoton.co.in','prasanna.hegde@spoton.co.in','pawan.sharma@spoton.co.in','krishna.chandrasekar@spoton.co.in','abhik.mitra@spoton.co.in','sqtf@spoton.co.in','shashvat.suhane@spoton.co.in','satya.pal@spoton.co.in']
# TO=['mahesh.reddy@spoton.co.in']
# CC=['shashvat.suhane@spoton.co.in']
FROM="reports.ie@spoton.co.in"

CC=['mahesh.reddy@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = "LH - Misrouted Cons Report RDB" + " : " + str(today_date)
html='''<html>
<style>
p
{
margin:0;
margin-top: 5px;
padding:0;
font-size:17px;
  line-height:20px;
}
</style>

</html>'''

# html3='''
# <h5> For the base data, please refer the link </h5>
# <p><a href= "http://spoton.co.in/downloads/OCID/OCID.xls"</a>http://spoton.co.in/downloads/OCID/OCID.xls</p></b>
# '''
s = Template(html).safe_substitute(date=today_date)
report=""
report+=s
report+='<br>'
report+='<br>'+df8.to_html()+'<br>'
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()

# except:
#   TO=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
#   FROM="mahesh.reddy@spoton.co.in"
#   msg = MIMEMultipart()
#   msg["From"] = FROM
#   msg["To"] = ",".join(TO)
#   #msg["CC"] = ",".join(CC)
#   #msg["BCC"] = ",".join(BCC)
#   #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
#   msg["Subject"] = "LH - Misrouted Cons Report Error in Execution" 
#   report=""
#   report+='Hi,'

#   report+='<br>'
#   report+='There was some error in LH - Misrouted Cons Report'
#   report+='<br>'

#   abc=MIMEText(report.encode('utf-8'),'html')
#   msg.attach(abc)
#   server=smtplib.SMTP('smtp.sendgrid.net', 587)
#   server.ehlo()
#   server.starttls()
#   server.ehlo()
#   server.login("spoton.net.in", "Star@123#")
#   failed = server.sendmail(FROM, TO, msg.as_string())
#   server.quit()

