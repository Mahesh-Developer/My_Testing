
# coding: utf-8

# In[1]:

import numpy as np
import pandas as pd
from IPython import display
from datetime import datetime
from datetime import datetime,timedelta
from datetime import datetime, timedelta
import smtplib
import ftplib
import traceback
import calendar
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template
import pyodbc


# In[2]:

cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
yesterday=datetime.strftime(datetime.now()-timedelta(1),'%Y-%m-%d')

revlinkdf=pd.read_csv(r'http://spoton.co.in/downloads/PMD_PL_DL_RV/PMDPLDLRL.csv')
revlinkdf=revlinkdf[revlinkdf['Product_Type']=='AR']
m = {'Jan': '01','Feb': '02','Mar': '03','Apr':'04','May':'05','Jun':'06','Jul':'07','Aug':'08','Sep':'09','Oct':'10','Nov':'11','Dec':'12'}
revlinkdf['PICKUP_DATE']=revlinkdf['PICKUP_DATE'].apply(lambda x: x.split(' ')[2]+'-'+m.get(x.split(' ')[1])+'-'+x.split(' ')[0])
yesterday_revenue=revlinkdf[(revlinkdf['PICKUP_DATE']==yesterday)]['NetRev'].sum()
mtd_revenue=revlinkdf['NetRev'].sum()

revlinkdf_con=revlinkdf[['Con_Number','PICKUP_DATE','Actual_Weight']]
query=("USP_PUD_YEST_MTD_DATA 'M'")
df=pd.read_sql(query,cnxn)
df['con_id']=df['con_id'].astype(int)
air_df1=df[df['PTYPE']=='AR']
len(air_df1)

bkng_df=air_df1[air_df1['TYP']=='BKG']
revlinkdf1=pd.merge(revlinkdf_con,bkng_df,left_on='Con_Number',right_on='con_id',how='outer')
del revlinkdf1['con_id']
revlinkdf1['COST']=revlinkdf1['COST'].fillna(0)
revlinkdf1['TYP']=revlinkdf1['TYP'].fillna('BKG')
revlinkdf1.rename(columns={'Con_Number':'con_id'},inplace=True)
del_df=air_df1[air_df1['TYP']=='DLV']
len(del_df)
air_df=pd.concat([revlinkdf1,del_df],ignore_index=True)
len(air_df)


# In[3]:

yesterday_revenue,mtd_revenue


# In[4]:

air_df=air_df[air_df['con_id']!=700694552]
len(air_df)

air_df['PICKUP_DATE']=air_df['PICKUP_DATE'].fillna('-')
air_df['DATE']=air_df['DATE'].fillna('-')

def getDate(x,y):
    if (x=='-') & (y=='-'):
        return None
    elif x=='-':
        return y
    else:
        return x

air_df['PICKUP_DATE_1']=air_df.apply(lambda x: getDate(x['PICKUP_DATE'],x['DATE']),axis=1)
def dateconv(date):
    try:
        dt = date.split(' ')[2]+'-'+str(m.get(date.split(' ')[1]))+'-'+date.split(' ')[0]
        return dt
    except:
        return None


import math
air_df['Actual_Weight']=air_df.apply(lambda x: x['ACT_WT'] if math.isnan(x['Actual_Weight']) else x['Actual_Weight'],axis=1)


# In[5]:

air_df.columns


# In[6]:

if len(air_df)==0:
    air_df=pd.DataFrame()
    mtd_pud_cost=0.0
    yest_pud_cost=0.0
    summary=pd.DataFrame()
    print (air_df)
else:
    air_df["DateOnly"]=air_df.apply(lambda x: dateconv(x["PICKUP_DATE_1"]),axis=1)
    air_df['Type']='MTD'
    bkng_yesterday_cost=air_df[(air_df['DateOnly']==yesterday) & (air_df['TYP']=='BKG')]['COST'].sum()
    dlvry_yesterday_cost=air_df[(air_df['DateOnly']==yesterday) & (air_df['TYP']=='DLV')]['COST'].sum()
    bkng_mtd_cost=air_df[air_df['TYP']=='BKG']['COST'].sum()
    dlvry_mtd_cost=air_df[air_df['TYP']=='DLV']['COST'].sum()
    yesterday=datetime.strftime(datetime.now()-timedelta(1),'%Y-%m-%d')
    mtd_pud_cost=pd.np.round(air_df['COST'].sum(),1)
    mtd_pud_cost
    yest_df=air_df[air_df['DateOnly']==yesterday]
    len(yest_df)
    yest_pud_cost=pd.np.round(yest_df['COST'].sum(),1)
    del yest_df['Type']
    yest_df['Type']='YST'
    air_df=pd.concat([air_df,yest_df],ignore_index=True)
    air_df.rename(columns={'Actual_Weight':'Wt','COST':'Cost','con_id':'Cons'},inplace=True)
    summary=air_df.pivot_table(index=['TYP'],columns=['Type'],values=['Wt','Cons','Cost'],aggfunc={'Wt':sum,'Cons':len,'Cost':sum}).fillna(0)
    sums=summary.sum(level=0, axis=1)
    sums.columns = pd.MultiIndex.from_product([sums.columns, ['Total']])
    # summary = pd.concat([summary, sums], axis=1)
    summary.loc['Total']=summary.sum(axis=0)
    summary[('CPK','MTD')]=summary[('Cost','MTD')]/summary[('Wt','MTD')]
    try:
        summary[('CPK','YST')]=summary[('Cost','YST')]/summary[('Wt','YST')]
    except:
        summary[('CPK','YST')]=0
    summary=summary.swaplevel(0, 1, 1).sort_index(1)
    try:
        summary=summary[[('YST','Cons'),('YST','Wt'),('YST','Cost'),('YST','CPK'),('MTD','Cons'),('MTD','Wt'),('MTD','Cost'),('MTD','CPK')]]
        summary[('YST','CPK')]=pd.np.round(summary[('YST','CPK')],1)
        summary[('MTD','CPK')]=pd.np.round(summary[('MTD','CPK')],1)
        summary[('MTD','Cost')]=pd.np.round(summary[('MTD','Cost')],1)
        summary[('YST','Cost')]=pd.np.round(summary[('YST','Cost')],1)
        #summary[('Total','Cost')]=pd.np.round(summary[('Total','Cost')],1)
        summary[('MTD','Cons')]=summary[('MTD','Cons')].astype(int)
        summary[('YST','Cons')]=summary[('YST','Cons')].astype(int)
        #summary[('Total','Cons')]=summary[('Total','Cons')].astype(int)
    except:
        summary=summary[[('MTD','Cons'),('MTD','Wt'),('MTD','Cost'),('MTD','CPK')]]
        summary[('MTD','CPK')]=pd.np.round(summary[('MTD','CPK')],1)
        summary[('MTD','Cost')]=pd.np.round(summary[('MTD','Cost')],1)
        # summary[('Total','Cost')]=pd.np.round(summary[('Total','Cost')],1)
        summary[('MTD','Cons')]=summary[('MTD','Cons')].astype(int)


# In[7]:

bkng_yesterday_cost,dlvry_yesterday_cost


# In[8]:

bkng_mtd_cost,dlvry_mtd_cost


# In[9]:

query1=("exec USP_PMD_LINEHAUL_DATA_30DAYS")


# In[14]:


linehal_df=pd.read_sql(query1,cnxn)


# In[15]:


len(linehal_df)
startdate=datetime.strftime((datetime.now()-timedelta(days=1)).replace(day=1),"%Y-%m-%d")+ ' 00:00:00'
enddate=datetime.strftime(datetime.now()-timedelta(days=1),"%Y-%m-%d")+' 23:59:00'
linehal_df=linehal_df[(linehal_df['THC DATE']>=startdate) & (linehal_df['THC DATE']<=enddate)]

# In[16]:


air_linehal_df=linehal_df[linehal_df['THCTYPE']=='AR']
len(air_linehal_df)


# In[17]:


air_linehal_df=air_linehal_df[~air_linehal_df['THC NUMBER'].isin(['SFBLRNX0007255','STBLRNX0007117','SFBLNFX0000076','STBLRNX0007118','WFABOHX0000001','WTPNQOX0000168','SFBLRNX0007262','SFBLRNX0007263','WFABOHX0000002'])]
len(air_linehal_df)
air_sclist=['ABOC','APNC','ACCC','AMAC','AHYC','ADEC','ABLC','AAMC']
air_hublist=['ADEH','AMAH','AHYH','ABOH','AAMH','ABLH','APNH','ACCH']

def getFeeders(org,dest):
    if org in air_hublist and dest in air_sclist:
        return "Destn Feeder"
    elif org in air_sclist and dest in air_hublist:
        return "Origin Feeder"
    elif dest in ['ADEH','AMAH','AHYH','ABOH','AAMH','ABLH','APNH','ACCH','ABOC','APNC','ACCC','AMAC','AHYC','ADEC','ABLC','AAMC']:
        return "Origin Feeder"
    else :
        return "Destn Feeder"

air_linehal_df['Feeder']=air_linehal_df.apply(lambda x:getFeeders(x['ORIGIN'],x['Destination']),axis=1)

if len(air_linehal_df)==0:
    air_linehal_df=pd.DataFrame()
    mtd_feeder_cost=0.0
    yest_feeder_cost=0.0
    lh_summary=pd.DataFrame()
else:
    mtd_feeder_cost=pd.np.round(air_linehal_df['COST'].sum(),1)
    air_linehal_df['Type']='MTD'
    mtd_originfeeder=air_linehal_df[air_linehal_df['Feeder']=='Origin Feeder']['COST'].sum()
    mtd_destnfeeder=air_linehal_df[air_linehal_df['Feeder']=='Destn Feeder']['COST'].sum()

    air_linehal_df['DATE']=air_linehal_df['THC DATE'].dt.date
    air_linehal_df['DATE']=air_linehal_df['DATE'].astype(str)
    yestair_linehal_df=air_linehal_df[air_linehal_df['DATE']==yesterday]
    yesterday_originfeeder=yestair_linehal_df[yestair_linehal_df['Feeder']=='Origin Feeder']['COST'].sum()
    yesterday_destnfeeder=yestair_linehal_df[yestair_linehal_df['Feeder']=='Destn Feeder']['COST'].sum()

    yest_feeder_cost=pd.np.round(yestair_linehal_df['COST'].sum(),1)
    del yestair_linehal_df['Type']
    yestair_linehal_df['Type']='YST'
    air_linehal_df=pd.concat([air_linehal_df,yestair_linehal_df],ignore_index=True)
    air_linehal_df.rename(columns={'THC NUMBER':"THCs",'COST':'Cost','TOTAL ACTUAL LOAD':'Actual_Wt'},inplace=True)
    lh_summary=air_linehal_df.pivot_table(index=['Type'],aggfunc={"THCs":len,'Cost':sum,'Actual_Wt':sum})
    lh_summary['CPK']=pd.np.round(lh_summary['Cost']/lh_summary['Actual_Wt'],1)
    lh_summary=lh_summary[['THCs','Actual_Wt','Cost','CPK']]
    lh_summary['Actual_Wt']=lh_summary['Actual_Wt'].astype(int)
    lh_summary['Cost']=pd.np.round(lh_summary['Cost'],1)
    lh_summary['CPK']=pd.np.round(lh_summary['CPK'],1)
    lh_summary.loc['Total']=lh_summary.sum(axis=0)


# In[10]:

yesterday_originfeeder,yesterday_destnfeeder


# In[11]:

mtd_originfeeder,mtd_destnfeeder


# In[12]:

air_df[air_df['Type']=='MTD'].to_csv(r'D:\Data\Demostic Air Cost Report\AirPMD.csv')
air_linehal_df.to_csv(r'D:\Data\Demostic Air Cost Report\LHAir.csv')

filepath=r'D:\Data\Demostic Air Cost Report\AirPMD.csv'
filepath1=r'D:\Data\Demostic Air Cost Report\LHAir.csv'
todate=datetime.strftime(datetime.now(),"%Y-%m-%d")

startdate="'"+datetime.strftime((datetime.now()-timedelta(days=1)).replace(day=1),"%Y-%m-%d")+"'"
enddate="'"+datetime.strftime(datetime.now(),"%Y-%m-%d")+"'"
cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=PYTHON_DB;UID=PythonOnline;PWD=P@ssw0rd123$")

df = pd.read_sql("SELECT * FROM revenuebkg WHERE PICKUP_DATE >= {0} AND PICKUP_DATE < {1}".format(startdate,enddate),cnxn) 

df=df[df['Product Type']=='AR']
len(df)
df=df[df['Con Number']!=700694552]
len(df)

yeststart = datetime.combine((datetime.now()-timedelta(days=1)).date(), datetime.min.time())
mtdrevenue = round(df["NetRev"].sum(),1)
yestrevenue=round(df[df["PICKUP_DATE"]>=yeststart]["NetRev"].sum(),1)
mtdrevenue,yestrevenue


# In[13]:

cnxn1 = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")

query3=("""SELECT  BA.bacd ,

        BA.banm ,

        CONVERT(VARCHAR(10), TC.CDDate, 103) CDDate ,

        TC.FlightNo ,

        TC.AirMode ,

        TC.TotalWeight ,

        TC.TotalWeightSlabMovement ,

        TC.AwbCharges ,

        TC.DOFees ,

        TC.TotalMiscCharges ,

        TC.TotalInboundCharges ,

        TC.TotalOutboundCharges ,

        TC.AdditionalCharges ,

        TC.TotChrgSlabwise ,

        TC.TotChrgMovementSlabwise ,

        TC.TotalBasedOnHeavyCharges ,

        TC.TotalBasedOnDGCharges ,

        TC.TotalBasedOnOthersCharges ,

        TC.TotalBasedOnDiscountCharges ,

        TC.TotalBasedOnPerKGCharges ,

        TC.GrandTotal ,

        TR.CDNo,CDWeight

FROM    dbo.tblColoaderRateCalculationDetails TC WITH ( NOLOCK )

        INNER JOIN dbo.tblRCBagMapping TR WITH ( NOLOCK ) ON TR.RCID = TC.RateCalcID

        INNER JOIN dbo.BAMS BA WITH ( NOLOCK ) ON BA.bacd = TC.ColoaderId""")


# In[34]:


try:
    coloader_df=pd.read_sql(query3,cnxn1)
    len(coloader_df)
except:
    coloader_df=pd.DataFrame()

data_query=("""SELECT  BA.bacd ,

            BA.banm ,

            CONVERT(VARCHAR(10), TC.CDDate, 103) CDDate ,

            TC.FlightNo ,

            TC.AirMode ,

            TC.TotalWeight ,

            TC.TotalWeightSlabMovement ,

            TC.AwbCharges ,

            TC.DOFees ,

            TC.TotalMiscCharges ,

            TC.TotalInboundCharges ,

            TC.TotalOutboundCharges ,

            TC.AdditionalCharges ,

            TC.TotChrgSlabwise ,

            TC.TotChrgMovementSlabwise ,

            TC.TotalBasedOnHeavyCharges ,

            TC.TotalBasedOnDGCharges ,

            TC.TotalBasedOnOthersCharges ,

            TC.TotalBasedOnDiscountCharges ,

            TC.TotalBasedOnPerKGCharges ,

            TC.GrandTotal,TR.CDNo,DT.DOCKNO,CONVERT(VARCHAR(10),DT.DOCKDT,103) BOOKINGDATE,DT.ACTUWT,DT.CHRGWT,DT.PKGSNO,CS.REVISED_CHRG_AMOUNT

    FROM    dbo.tblColoaderRateCalculationDetails TC WITH ( NOLOCK )

                  INNER JOIN dbo.tblRCBagMapping TR WITH (NOLOCK) ON TR.RCID = TC.RateCalcID

                  INNER JOIN dbo.TblBagHeader TB WITH (NOLOCK) ON TB.BagId = TR.BagId

                  INNER JOIN dbo.TblBagConTrans TS WITH (NOLOCK) ON TS.BagHeaderId = TB.BagId

                  INNER JOIN dbo.DOCKET DT WITH (NOLOCK) ON DT.DOCKNO = TS.DOCKNO

            INNER JOIN dbo.BAMS BA WITH ( NOLOCK ) ON BA.bacd = TC.ColoaderId

                  INNER JOIN dbo.Con_BalanceSheet_Sales CS WITH (NOLOCK) ON CS.[Con Number] = DT.DOCKNO""")

coloader_data=pd.read_sql(data_query,cnxn1)


cdstart=datetime.strftime((datetime.now()-timedelta(days=1)).replace(day=1),"%d/%m/%Y")
cdenddt=datetime.strftime((datetime.now()-timedelta(days=1)),"%d/%m/%Y")
coloader_df=coloader_df[(coloader_df['CDDate']>=cdstart) & (coloader_df['CDDate']<=cdenddt)]
coloader_data=coloader_data[(coloader_data['CDDate']>=cdstart) & (coloader_data['CDDate']<=cdenddt)]



# In[14]:

if len(coloader_df)==0:
    coloader_df=pd.DataFrame()
    mtd_coloader_cost=0.0
    yest_coloader_cost=0.0
    coloader_summary=pd.DataFrame()
else:
    coloader_df['Type']='MTD'
    yester_lh_cost=coloader_df[coloader_df['CDDate']==cdenddt]['GrandTotal'].sum()
    mtd_lh_cost=coloader_df['GrandTotal'].sum()

    mtd_coloader_cost=coloader_df['GrandTotal'].sum()
    yesterday=datetime.strftime(datetime.now()-timedelta(1),'%d/%m/%Y')
    yest_coloader_df=coloader_df[coloader_df['CDDate']==yesterday]
    yest_coloader_cost=yest_coloader_df['GrandTotal'].sum()
    if len(yest_coloader_df)>1:
        del yest_coloader_df['Type']
    else:
        pass
    yest_coloader_df['Type']='YST'
    coloader_df=pd.concat([coloader_df,yest_coloader_df],ignore_index=True)
    coloader_summary=coloader_df.pivot_table(index=['Type'],aggfunc={'CDWeight':sum,'GrandTotal':sum})
    coloader_summary['CPK']=pd.np.round(coloader_summary['GrandTotal']/coloader_summary['CDWeight'],1)
    coloader_summary=coloader_summary[['CDWeight','GrandTotal','CPK']]
    coloader_summary['CDWeight']=coloader_summary['CDWeight'].astype(int)
    coloader_summary['GrandTotal']=pd.np.round(coloader_summary['GrandTotal'],1)


# In[15]:

# yester_lh_cost,mtd_lh_cost


# In[16]:

coloader_data.to_csv(r'D:\Data\Demostic Air Cost Report\coloader_df.csv')
filepath2=r'D:\Data\Demostic Air Cost Report\coloader_df.csv'
percent_df=pd.DataFrame({'Cost':[mtd_pud_cost+mtd_feeder_cost+mtd_coloader_cost,yest_pud_cost+yest_feeder_cost+yest_coloader_cost],'Revenue':[mtdrevenue,yestrevenue]},index=['MTD','YST'])
percent_df['Perc%']=pd.np.round(percent_df['Cost']*100.0/percent_df['Revenue'],1)
percent_df=percent_df.fillna(0)
percent_df['Cost']=pd.np.round(percent_df['Cost'],1)
percent_df['Revenue']=pd.np.round(percent_df['Revenue'],1)


# In[17]:

# pickupdf=pd.DataFrame({'COST':[bkng_yesterday_cost,bkng_mtd_cost],'Revenue':[yesterday_revenue,mtd_revenue],'Type':['YST','MTD'],'Parameter':'1-Pickup'})
# delvdf=pd.DataFrame({'COST':[dlvry_yesterday_cost,dlvry_mtd_cost],'Revenue':[yesterday_revenue,mtd_revenue],'Type':['YST','MTD'],'Parameter':'5-Delivery'})


# # In[18]:

# lhdf=pd.DataFrame({'COST':[yester_lh_cost,mtd_lh_cost],'Revenue':[yesterday_revenue,mtd_revenue],'Type':['YST','MTD'],'Parameter':'3-LH'})
# lhdf


# # In[19]:

# Originfeederdf=pd.DataFrame({'COST':[yesterday_originfeeder,mtd_originfeeder],'Revenue':[yesterday_revenue,mtd_revenue],'Type':['YST','MTD'],
#                              'Parameter':'2-Origin Feeder'})
# Originfeederdf


# # In[20]:

# Destnfeederdf=pd.DataFrame({'COST':[yesterday_destnfeeder,mtd_destnfeeder],'Revenue':[yesterday_revenue,mtd_revenue],'Type':['YST','MTD'],
#                             'Parameter':'4-Destn Feeder'})
# Destnfeederdf


# # In[38]:

# summary2=pd.concat([pickupdf,delvdf,lhdf,Originfeederdf,Destnfeederdf],ignore_index=True)


# # In[39]:

# summary2=summary2.pivot_table(index=['Parameter'],columns=['Type'],values=['COST','Revenue'],aggfunc={'COST':sum,'Revenue':sum})


# # In[40]:

# summary2


# # In[41]:

# summary2=summary2.swaplevel(0, 1, 1).sort_index(1)


# # In[36]:




# In[42]:

# summary2[('YST','%Rev')]=pd.np.round(summary2[('YST','COST')]/summary2[('YST','Revenue')],2)
# summary2


# # In[43]:

# summary2[('MTD','%Rev')]=pd.np.round(summary2[('MTD','COST')]/summary2[('MTD','Revenue')],2)
# summary2


# # In[44]:

# # summary3=summary2[[('YST','COST'),('YST','Revenue'),('YST','%'),('MTD','COST'),('MTD','Revenue'),('MTD','%')]]
# summary3=summary2[[('YST','COST'),('YST','%Rev'),('MTD','COST'),('MTD','%Rev')]]


# # In[29]:




# # In[46]:

# summary3.loc['Total']=summary3.sum(axis=0)


# # In[47]:

# summary3


# In[ ]:

# TO=['mahesh.reddy@spoton.co.in']
TO=["abhik.mitra@spoton.co.in","krishna.chandrasekar@spoton.co.in","satya.pal@spoton.co.in",'anto.paul@spoton.co.in','dillip.padhi@spoton.co.in',"sanjay.johri@spoton.co.in"]
CC= ["mahesh.reddy@spoton.co.in"]
# CC=["mahesh.reddy@spoton.co.in"]
FROM="reports.ie@spoton.co.in"

msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "Domestic Air - Cost Reporting" + " - " + str(todate)
html='''<html>
<h4>Dear All,</h4>
<p>PFA Domestic - Air Cost Report $date</p>
</html>'''
#s = Template(html).safe_substitute(date=yest_date)
report=""
report+="Dear All"
report+='<br>'
report+='<br>'
report+='PFB Pickup & Delivery Costing'
report+='<br>'
report+='<br>'+summary.to_html()+'<br>'
report+='<br>'
report+='PFB  Feeder Costing'
report+='<br>'
report+='<br>'+lh_summary.to_html()+'<br>'
report+='<br>'
report+='PFB  Linehaul Costing'
report+='<br>'
report+='<br>'+coloader_summary.to_html()+'<br>'
report+='<br>'
report+='Revenue & Gross Margin summary'
report+='<br>'
report+='<br>'+percent_df.to_html()+'<br>'
# report+='Parameter Wise Summary'
# report+='<br>'
# report+='<br>'+summary3.to_html()+'<br>'

abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(filepath1,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
msg.attach(part1)

part2 = MIMEBase('application', "octet-stream")
part2.set_payload( open(filepath2,"rb").read() )
encoders.encode_base64(part2)
part2.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath2))
msg.attach(part2)

# server=smtplib.SMTP('smtp.sendgrid.net', 587)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("spoton.net.in", "Star@123#")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()

