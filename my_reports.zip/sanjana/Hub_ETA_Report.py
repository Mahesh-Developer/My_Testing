
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import datetime,timedelta
import smtplib
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os


# In[2]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()
cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
cursor = cnxn.cursor()

# In[3]:


df=pd.read_sql("EXEC dbo.USP_ETA_SLIP_NEW_SQ",cnxn)


# In[4]:


len(df)


# In[8]:


df.columns


# In[5]:


df1=df[df['ISDEPARTED_FRM_CURRLOC']=='NO']
len(df1)


# In[6]:


df1=df1[df1['HUBCENTER']=='Y']
len(df1)


# In[7]:


df1=df1[df1['Delay_Days']>0]


# In[11]:


hub_eta_summary=df1.pivot_table(index=['CURR_BRANCHNAME'],columns=['Delay_Days'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').fillna(0)


# In[12]:


hub_eta_summary['DOCKNO']=hub_eta_summary['DOCKNO'].astype(int)



df2=df1[df1['CurLocConStatusCategory'].isin(['SENDER FAILURE','RECEIVER FAILURE'])]

hub_eta_summary12=df2.pivot_table(index=['CURR_BRANCHNAME'],columns=['Delay_Days'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').fillna(0)


# In[12]:


hub_eta_summary12['DOCKNO']=hub_eta_summary12['DOCKNO'].astype(int)


df1.to_csv(r'D:\Data\New_ETA_Slip_Report\Hub\Hub_ETA_Slip_Data.csv')


# In[15]:


filepath=r'D:\Data\New_ETA_Slip_Report\Hub\Hub_ETA_Slip_Data.csv'


# In[16]:


todate=datetime.strftime(datetime.now(),"%Y-%m-%d :%H")
todate


# In[17]:


# TO=['mahesh.reddy@spoton.co.in']
TO=['hubmgr_spot@spoton.co.in']
# CC=['mahesh.reddy@spoton.co.in']
CC=['sqtf@spoton.co.in','mahesh.reddy@spoton.co.in','anitha.thyagarajan@spoton.co.in','sanjana.narayana@spoton.co.in']
FROM="reports.ie@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
# msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "ETA Slip Cons lying at locations - HUB" + ' - ' +todate

report=""
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='ETA Slip Cons lying at locations HUB : '+todate

report+='<br>'
report+='ETA Slip Cons lying @ locations excluding ccf cons'
report+='<br>'
report+='<br>'+hub_eta_summary12.to_html()+'<br>'
report+='<br>'

report+='<br>'
report+='<br>'+hub_eta_summary.to_html()+'<br>'

abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

# part2 = MIMEBase('application', "octet-stream")
# part2.set_payload( open(filepath2,"rb").read() )
# encoders.encode_base64(part2)
# part2.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath2))
# msg.attach(part2)



server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("spoton.net.in", "Star@123#")
server.login('spoton.net.in', 'Star@123#')
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()


