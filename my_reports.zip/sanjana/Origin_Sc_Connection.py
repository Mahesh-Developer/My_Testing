
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta,datetime
import sys
import Utilities
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

reload(sys).setdefaultencoding("ISO-8859-1")


# In[2]:


# cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")


# # In[3]:


# cursor=cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()
# In[4]:


#a='Y'

try:
    query=("""EXEC USP_ORIGIN_SC_OTP_REPORT_SCH 'Y' """)
    query


    # In[5]:


    df=pd.read_sql(query,Utilities.cnxn)


    # In[6]:


    # df=pd.read_excel(r'C:\Users\S2769MAH\Downloads\SQ\sreedhar\OTP_Data.xlsx')
    df.columns


    # In[7]:


    df.rename(columns={'RGALPH':'Region','DEPOT_CODE':'Depot','ControlArea':'Area','Dkt_Cnt':'Total','':'OTP %'},inplace=True)


    # In[8]:


    df['Success']=df['Success'].astype(float)
    df['Failure']=df['Failure'].astype(float)
    df['Total']=df['Total'].astype(float)
    #df


    # In[9]:


    yestarday_pivot_df=pd.pivot_table(df,index=['Region','Depot','Area'],values=['Failure','Success','Total','OTP %'],aggfunc={'Failure':'sum','Success':'sum','Total':'sum','OTP %':'sum'})
    yestarday_pivot_df=pd.np.round(yestarday_pivot_df,1)
    yestarday_pivot_df
    # yestarday_pivot_df3=pd.pivot_table(df,index=['Region','Depot','Area'],values=['Failure','Success','Total','OTP %'],aggfunc={'Failure':'sum','Success':'sum','Total':'sum','OTP %':'sum'},margins=True)
    # yestarday_pivot_df3


    # In[10]:


    # yestarday_pivot_df1=(pd.concat((yestarday_pivot_df.reset_index(),
    #                  yestarday_pivot_df.reset_index().groupby('Region').aggregate({'Failure':'sum','Success':'sum','OTP %':'mean','Total':'sum'}).reset_index())).\
    #                       sort_values(['Region']).\
    #                       fillna('total').\
    #                       set_index(['Region','Depot','Area']))


    # In[11]:


    # yestarday_pivot_df1=pd.np.round(yestarday_pivot_df,1)
    # #yestarday_pivot_df1


    # In[12]:


    yestarday_pivot_df2=yestarday_pivot_df.reset_index()
    yestarday_pivot_df2=yestarday_pivot_df2[['Region','Depot','Area','Failure','Success','Total','OTP %']]
    yestarday_pivot_df2


    # In[13]:


    # yestarday_pivot_df1=pd.np.round(yestarday_pivot_df1,1)
    # yestarday_pivot_df1
    # yestarday_pivot_df1.groupby(['Region','Depot','Area']).agg({'OTP %':'mean'})


    # In[14]:


    xls = pd.ExcelFile(r'C:\Users\rajeeshv\Downloads\KPI Targets.xlsx')
    kpi_df = pd.read_excel(xls,sheetname='Depot',header=[1,2],index_col=[0])


    # In[15]:


    kpi_df1=pd.DataFrame()
    kpi_df1[['Region','Target','Depot','Area']]=kpi_df[['Region','Org SC Connection','Depot','Area']]


    # In[16]:


    kpi_df1=kpi_df1.reset_index()
    del kpi_df1['index']
    kp1=kpi_df1[['Region','Target']]
    kp1
    #kpi_df1.drop(kpi_df1.index[[3,9]])
    #kpi_df1=kpi_df1[~kpi_df['Region'].isin(['East Total','North Total','South Total','West Total'])==False]
    kpi_df1=kpi_df1[~kpi_df1['Region'].str.contains('Total')]
    kpi_df1


    # In[17]:


    logs_df = pd.merge(yestarday_pivot_df2, kp1, how='left',
            left_index=True, right_index=True)
    del logs_df['Region_y']
    logs_df=logs_df.rename(columns={'Region_x':'Region'})
    #logs_df['Target']=logs_df['Target']*100.0


    # In[18]:


    # logs_df=logs_df.drop_duplicates(subset=['Region','Depot','Area'])
    logs_df['Target']=logs_df['Target']*100.0


    # In[19]:

    ss=pd.pivot_table(logs_df,index=['Region','Depot','Area'],margins=True,values=['Failure','Success','Total','OTP %','Target'],aggfunc={'Failure':sum,'Success':sum,'Total':sum,'OTP %':pd.np.mean,'Target':pd.np.mean})
    #ss=pd.pivot_table(logs_df,index=['Region','Depot','Area'],margins=True,values=['Failure','Success','Total','OTP %','Target'],aggfunc={'Failure':'sum','Success':'sum','Total':'sum','OTP %':'sum','Target':'sum'})
    ss1=pd.pivot_table(logs_df,index=['Region','Depot','Area'],margins=True,values=['Failure','Success','Total','OTP %','Target'],aggfunc={'Failure':'sum','Success':'sum','Total':'sum','OTP %':'sum','Target':'sum'})
    ss=ss.reset_index()
    ss1=ss1[['Target','Failure','Success','Total','OTP %']]


    # In[20]:


    # d = {}
    # d['CCUA'] = '98'
    # d['GUAA'] = '98'
    # d['JSPA'] = '98'
    # d['East Total']='98'
    # d['IXCA']='98'
    # d['LKOA']='90'
    # d['JAIA']='98'
    # d['NCRA']='98'
    # d['UKNA']='90'
    # d['North Total']='95'
    # d['BLRA']='95'
    # d['HYDA']='95'
    # d['VGAA']='95'
    # d['MAAA']='98'
    # d['CBEA']='95'
    # d['COKA']='95'
    # d['IXMA']='95'
    # d['South Total']='96'
    # d['AMDA']='95'
    # d['BOMA']='95'
    # d['GOIA']='95'
    # d['IDRA']='95'
    # d['NAGA']='95'
    # d['PNQA']='95'
    # d['West Total']='95'
    # d['All']='96'
    ss=ss[['Region','Depot','Area','Target','Failure','Success','Total','OTP %']]
    ss=pd.np.round(ss,1)

    # In[21]:


    yestarday_pivot_df=pd.np.round(yestarday_pivot_df,1)


    # In[22]:


    yestarday_pivot_df.columns


    # In[23]:


    def highlight_greater(row):
    #     print (type(row['Target']),row['Target'])
        if row['OTP %'] < row['Target']:
            color = 'red'
        else:
            color='green'

        background = ['color: {}'.format(color) for _ in row]

        return background


    # In[24]:


    ss['Target']=pd.to_numeric(ss['Target'])


    # In[25]:


    style_1= ss.style.apply(highlight_greater,subset=['OTP %','Target'],axis=1)


    # In[26]:


    style_1


    # In[27]:


    style_1=style_1.set_properties(subset=['Target'],color='black')


    # In[28]:


    style_1


    # In[29]:


    #branch wise 
    query1=("""EXEC USP_ORIGIN_SC_OTP_REPORT_SCH 'B' """)
    # xls = pd.ExcelFile(r'C:\Users\S2769MAH\Downloads\SQ\sreedhar\OTP_Data.xlsx')
    # branch_df = pd.read_excel(xls,sheetname='Branch Wise')
    branch_df=pd.read_sql(query1,Utilities.cnxn)


    # In[30]:


    branch_df.rename(columns={'RGALPH':'Region','DEPOT_CODE':'Depot','ControlArea':'Area','Dkt_Cnt':'Total','':'OTP %','ORGNCD':'Branch_Name'},inplace=True)


    # In[31]:


    branch_df


    # In[32]:


    branch_pivot_df=pd.pivot_table(branch_df,index=['Region','Depot','Area','Branch_Name'])
    branch_pivot_df=pd.np.round(branch_pivot_df,1)
    branch_pivot_df1=branch_pivot_df.reset_index()
    branch_pivot_df1


    # In[33]:


    branch_logs_df = pd.merge(branch_pivot_df1, kpi_df1, how='left',
            left_on=['Region','Depot','Area'], right_on=['Region','Depot','Area'])
    # del logs_df['Region_y']
    # logs_df=logs_df.rename(columns={'Region_x':'Region'})
    branch_logs_df['Target']=branch_logs_df['Target']*100.0
    branch_logs_df=branch_logs_df[['Region','Depot','Area','Branch_Name','Target','Failure','Success','Total','OTP %']]
    branch_pivot_df1=pd.pivot_table(branch_logs_df,index=['Region','Depot','Area','Branch_Name'])
    branch_pivot_df1=branch_pivot_df1[['Target','Failure','Total','Success','OTP %']]


    # In[34]:


    branch_pivot_df1=branch_pivot_df1.fillna(0)


    # In[35]:


    #Week to Date
    # week_df=pd.read_excel(xls,sheetname='WTD')
    query2=("""EXEC USP_ORIGIN_SC_OTP_REPORT_SCH 'W'""")
    week_df=pd.read_sql(query2,Utilities.cnxn)
    week_df


    # In[36]:


    week_df.rename(columns={'RGALPH':'Region','DEPOT_CODE':'Depot','ControlArea':'Area','Dkt_Cnt':'Total','':'OTP %'},inplace=True)


    # In[37]:


    week_pivot_df=pd.pivot_table(week_df,index=['Region','Depot','Area'])


    # In[38]:


    week_pivot_df1=week_pivot_df.reset_index()


    # In[39]:


    # week_pivot_df1=(pd.concat((week_pivot_df.reset_index(),
    #                  week_pivot_df.reset_index().groupby('Region').aggregate({'Failure':'sum','Success':'sum','OTP %':'mean','Total':'sum'}).reset_index())).\
    #                       sort_values(['Region']).\
    #                       fillna('Total').\
    #                       set_index(['Region','Depot','Area']))


    # In[40]:


    week_pivot_df1=pd.np.round(week_pivot_df1,1)
    week_pivot_df2=week_pivot_df1.reset_index()
    #week_pivot_df2=week_pivot_df2[['Region','Depot','Area','Failure','Success','Total','OTP %']]


    # In[41]:


    week_logs_df = pd.merge(week_pivot_df2, kp1, how='left',
            left_index=True, right_index=True)
    del week_logs_df['Region_y']
    week_logs_df=week_logs_df.rename(columns={'Region_x':'Region'})
    week_logs_df['Target']=week_logs_df['Target']*100.0
    week_logs_df_pivot=pd.pivot_table(week_logs_df,index=['Region','Depot','Area'],values=['Failure','Success','Total','OTP %','Target'],aggfunc={'Failure':'sum','Success':'sum','Total':'sum','OTP %':'sum','Target':'sum'},margins=True)
    #del week_logs_df_pivot['index']
    week_logs_df_pivot=week_logs_df_pivot[['Target','Failure','Success','Total','OTP %']]
    week_logs_df_pivot


    # In[42]:


    query3=("""EXEC USP_ORIGIN_SC_OTP_REPORT_SCH 'D'""")
    # details_df=pd.read_excel(xls,sheetname='Details')
    details_df=pd.read_sql(query3,Utilities.cnxn)


    # In[43]:


    #Origin SC Connection - On-Time Performance 6th Jan 2018
    from datetime import date
    d1=date.today()
    today_date=datetime.strftime(d1,'%d-%b-%Y')


    # In[44]:


    from pandas import ExcelWriter
    with ExcelWriter(r'D:\Data\ODA_Loads_Ton_wise\Origin SC Connection - On-Time Performance.xlsx') as writer:
        ss1.to_excel(writer,engine='xlsxwriter',sheet_name='Yesterday Origin SC Report')
        week_logs_df_pivot.to_excel(writer,engine='xlsxwriter',sheet_name='WTD Origin SC Connection Report')
        branch_pivot_df1.to_excel(writer,engine='xlsxwriter',sheet_name='Origin SC Connection BranchWise')
        details_df.to_excel(writer,engine='xlsxwriter',sheet_name='Origin SC Conn Detail Rpt')
        


    # In[45]:


    filepath=r'D:\Data\ODA_Loads_Ton_wise\Origin SC Connection - On-Time Performance.xlsx'


    # In[46]:


    style_1=style_1.set_table_styles([{'selector': 'tr:hover','props': [('background-color', 'yellow')]}])
    style_1=style_1.set_table_attributes('class="table table-bordered"')
    # style_1=style_1.set_table_attributes('table-layout="fixed"')
    style_2=style_1.set_caption('Summary')
    style_2


    # In[47]:


    html3=style_2.render()
    type(html3)


    # In[48]:


    from datetime import date,timedelta
    d=date.today()
    print (type(d))
    date1=d-timedelta(1)
    date2=datetime.strftime(date1,'%d-%b-%y')
    # type(date1)
    # time=datetime.strftime(d,'%H:%M')
    # time


    # In[49]:


    import numpy as np
    import pandas as pd
    import itertools
    import json
    from pandas import ExcelWriter
    from pandas import pivot_table
    from datetime import datetime
    import os
    import ftplib
    import traceback

    oppath1=filepath
    #FTP Upload starts
    print ('Logging in...')
    ftp = ftplib.FTP()  
    ftp.connect('10.109.230.50')  
    print (ftp.getwelcome())
    try:  
        try:  
            ftp.login('HOSQTeam', 'Te@mH0$q')
            print ('login done')
            ftp.cwd('Auto_reports')  
            #ftp.cwd('FIFO')
            # move to the desired upload directory  
            print ("Currently in:", ftp.pwd()) 
            print ('Uploading...')  
            fullname = oppath1
            name = os.path.split(fullname)[1]  
            f = open(fullname, "rb")  
            ftp.storbinary('STOR ' + name, f)  
            f.close()  
            print ("OK"  )
            print ("Files:")  
            print (ftp.retrlines('LIST'))
        finally:  
            print ("Quitting...")
            ftp.quit()  
    except:  
        traceback.print_exc()


    # In[50]:




    from_addr = 'mis.ho@spoton.co.in'
    # to_addr = ['rajesh.mp@spoton.co.in','banusanketh.dc@spoton.co.in','mahesh.reddy@spoton.co.in','shivananda.p@spoton.co.in']
    # to_addr = ['sreedhar.m@spoton.co.in','mahesh.reddy@spoton.co.in']
    #cc_addr = ['maheshmahesh11464@gmail.com','mahesh.reddy@spoton.co.in']
    cc_addr=['sqtf@spoton.co.in','ashwani.gangwar@spoton.co.in','SQ_SPOT@spoton.co.in','pramod.pandey@spoton.co.in','md.zaya@spoton.co.in','anoop.kumar@spoton.co.in','avnish.tripathi@spoton.co.in']
    #bcc_addr = ['rajesh.mp@spoton.co.in']
    bcc_addr=['AOM_SPOT@spoton.co.in','dom_spot@spoton.co.in','rom_spot@spoton.co.in','hubmgr_spot@spoton.co.in','anitha.thyagarajan@spoton.co.in']

    username = 'mis.ho@spoton.co.in'
    password = 'Raj@spot12.mp'

    msg = MIMEMultipart()

    msg['From'] = from_addr
    # msg['To'] = ', '.join(to_addr)
    msg['cc'] = ', '.join(cc_addr)
    msg['bcc'] = ', '.join(bcc_addr)
    msg['Subject'] = 'Origin SC Connection - On-Time Performance'+str(date2)
    html='''<html>
    <h4>Dear ,All</h4>
    <p>Please find attached Origin SC On-Time Connection Performance for $date of con's picked till 18:00 Hrs. </p>
    <p style="color:red;">Note:- The Performance is measured as per KPI Targets.</p>
    </html>'''
    html4='''
    <h5> Note : For data please click on the below link: </h5>
    <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Origin SC Connection - On-Time Performance.xlsx"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Origin SC Connection - On-Time Performance.xlsx</p></b>
    '''
    html1='''<h5>Thanks & Regards</h5></b>
    <h5>HO-SQ</h5>'''
        
    #  msg.attach(part10)
    s = Template(html).safe_substitute(date=date2)
    report=""
    report+=s
    report+='<br>'
    # report+='<br>'
    report+=html3
    report+='<br>'
    report+=html4
    report+='<br>'
    report+=html1
    abc=MIMEText(report,'html')
    msg.attach(abc)
    
    part=MIMEBase('application','octet-stream')
    # part1=MIMEBase('application','octet-stream')
    part.set_payload(open(filepath,'rb').read())
    # part1.set_payload(open(filepath1,'rb').read())
    encoders.encode_base64(part)
    # Encoders.encode_base64(part1)
    part.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath))
    # part1.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath1))
    #msg.attach(part)
    # msg.attach(part1)


    # server = smtplib.SMTP('smtp.spoton.co.in',587)
    # server.ehlo()
    # server.starttls()
    # server.ehlo()
    # server.login('mis.ho@spoton.co.in','Mis@2019')
    # server.sendmail(from_addr,cc_addr+bcc_addr,msg.as_string())
    # print ('mail sent succesfully')
    # server.quit()

    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(from_addr,cc_addr+bcc_addr, msg.as_string())
    server.quit()

except:

  TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in']  
  CC=['mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "Origin SC Connection - On-Time Performance Error in Execution" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in Origin SC Connection - On-Time Performance.'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO+CC, msg.as_string())
  server.quit()

