
# coding: utf-8

# In[ ]:


import numpy as np
import pandas as pd
import pyodbc
from IPython import display
from datetime import datetime
from datetime import datetime,timedelta
from datetime import datetime, timedelta
import smtplib
import ftplib
import traceback
import calendar
import os
import Utilities

# In[ ]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


# In[ ]:


query=("EXEC USP_Servicelevel_SQ 'M' ")


# In[ ]:


df=pd.read_sql(query,Utilities.cnxn)

print ('USP_Servicelevel_SQ')
# In[ ]:


print (len(df))


# In[ ]:


df


# In[ ]:

print (df)
df['Reach %']=pd.np.round(df['Reach']*100.0/df['TOTAL CONS'],1)
df['OPP %']=pd.np.round(df['OPP_Cons']*100.0/df['TOTAL CONS'],1)
df['CEM %']=pd.np.round(df['CEM_Cons']*100.0/df['TOTAL CONS'],1)
df['Damage %']=pd.np.round(df['DAMAGE']*100.0/df['TOTAL CONS'],1)
df['Theft %']=pd.np.round(df['THEFT']*100.0/df['TOTAL CONS'],1)


# In[ ]:


df.columns


# In[ ]:


df_summary=df[['CUSTCODE','CUSTNAME','MTH','TOTAL CONS','Reach %', 'OPP %', 'CEM %', 'Damage %', 'Theft %']]
df_summary


# ## Pickup Performance

# In[ ]:


pkp_query=("EXEC USP_CUST_PICKUP_SUMMARY_SQ 'M' ")


# In[ ]:


pkp_df=pd.read_sql(pkp_query,Utilities.cnxn)

print ('USP_CUST_PICKUP_SUMMARY_SQ')

# In[ ]:


print (len(pkp_df))


# In[ ]:


pkp_df['Success %']=pd.np.round(pkp_df['Success']*100.0/pkp_df['Total_Pickups'])


# In[ ]:


pkp_df=pkp_df.replace([np.inf,-np.inf],np.nan).fillna(0)


# In[ ]:


pkp_df


# ## Undel with Ageing

# In[ ]:


undel_query=("USP_STOCK_ALL_SQ")


# In[ ]:


undel_df=pd.read_sql(undel_query,Utilities.cnxn)

print ('USP_STOCK_ALL_SQ')
# In[ ]:


print (len(undel_df))


# In[ ]:


undel_df1=undel_df[undel_df['CustCode']=='000120834']
len(undel_df1)


# In[ ]:


def getRange(x):
    if int(x) in range(0,23):
        return "0-24"
    elif int(x) in range(24,28):
        return "24-48"
    elif int(x) in range(48,72):
        return "48-72"
    else:
        return ">72 Hours"


# In[ ]:


undel_df1['Bucket']=undel_df1['HOURS_LYING_AT_CURR_LOCATION'].apply(lambda x: getRange(x))


# In[ ]:


undel_df1[['Bucket','HOURS_LYING_AT_CURR_LOCATION']]


# In[ ]:


undel_summary=undel_df1.pivot_table(index=['CURR_AREA'],columns=['Bucket'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total')


# In[ ]:


undel_summary


# ## internal damage & Theft 

# In[ ]:


damage_query=("EXEC USP_CUST_DEPS_DATA_SQ")


# In[ ]:


damage_df=pd.read_sql(damage_query,Utilities.cnxn)
print (len(damage_df))
print ('USP_CUST_DEPS_DATA_SQ')

# In[ ]:


damage_summary=damage_df.pivot_table(index=['COMING_FROM'],aggfunc={'DOCKNO':len})
damage_summary

# In[ ]:


todate=datetime.strftime(datetime.now(),"%Y-%m-%d")
todate


# In[ ]:


df.to_csv(r'D:\Data\Campus_Despatch\ServiceLevel_Data_'+str(todate)+'.csv')
df.to_csv(r'D:\Data\Campus_Despatch\ServiceLevel_Data.csv')


# In[ ]:


pkp_df.to_csv(r'D:\Data\Campus_Despatch\PickUp_Performance_'+str(todate)+'.csv')
pkp_df.to_csv(r'D:\Data\Campus_Despatch\PickUp_Performance.csv')


# In[ ]:


undel_df1.to_csv(r'D:\Data\Campus_Despatch\Undel_Management_'+str(todate)+'.csv')
undel_df1.to_csv(r'D:\Data\Campus_Despatch\Undel_Management.csv')


# In[ ]:


damage_df.to_csv(r'D:\Data\Campus_Despatch\Damages_Data_'+str(todate)+'.csv')
damage_df.to_csv(r'D:\Data\Campus_Despatch\Damages_Data.csv')


# In[ ]:


filepath=r'D:\Data\Campus_Despatch\ServiceLevel_Data.csv'
filepath1=r'D:\Data\Campus_Despatch\PickUp_Performance.csv'
filepath2=r'D:\Data\Campus_Despatch\Undel_Management.csv'
filepath3=r'D:\Data\Campus_Despatch\Damages_Data.csv'


# In[ ]:


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

#TO=['mahesh.reddy@spoton.co.in']
TO=['sq_spot@spoton.co.in','sqtf@spoton.co.in','spot_security@spoton.co.in','spot_cstl@spoton.co.in','omwati.rajput@spoton.co.in']
FROM="mis.ho@spoton.co.in"
CC=['mahesh.reddy@spoton.co.in','anitha.thyagarajan@spoton.co.in','shivananda.p@spoton.co.in']
#CC=['mahesh.reddy@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
msg["Subject"] = "CAMPUS Customer Performance " + " : " + todate
html='''<html>
<style>
p
{
  margin:0;
  margin-top: 5px;
  padding:0;
  font-size:17px;
    line-height:20px;
}
</style>
<h3>Dear All,</h3>
<p>Please Find POD's Summary.</p>
</html>'''


s = Template(html).safe_substitute()
report=""
#report+=s
#report+='<br>'+final_dff5.to_html()+'<br>'
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='Please Find attached CAMPUS DESPATCHES STARTING EFFECTIVE TODAY :'
report+='<br>'
#report+='NOTE : The below data is excluding Appointment Cons'
report+='PickUp Summary : '
report+='<br>'
report+='<br>'+pkp_df.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='Internal Damage/ Theft Summary : '
report+='<br>'
report+='<br>'+damage_summary.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='Stock Management Summary : '
report+='<br>'
report+='<br>'+undel_summary.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='Service Levels : '
report+='<br>'
report+='<br>'+df_summary.to_html()+'<br>'
report+='<br>'
report+='<br>'


html5='''
<h5> To download the data , Please click the link below </h5>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Undel_Management.xlsx"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Undel_Management.xlsx</p></b>
    '''
#report+=html5
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)
part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(filepath1,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
msg.attach(part1)

part2 = MIMEBase('application', "octet-stream")
part2.set_payload( open(filepath2,"rb").read() )
encoders.encode_base64(part2)
part2.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath2))
msg.attach(part2)

part3 = MIMEBase('application', "octet-stream")
part3.set_payload( open(filepath3,"rb").read() )
encoders.encode_base64(part3)
part3.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath3))
msg.attach(part3)

server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()

