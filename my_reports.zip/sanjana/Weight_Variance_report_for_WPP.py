
# coding: utf-8

# In[ ]:


import numpy as np
import pandas as pd
import pyodbc
from IPython import display
from datetime import datetime
from datetime import datetime,timedelta
from datetime import datetime, timedelta
import smtplib
import ftplib
import traceback
import calendar
import os
import Utilities

# In[ ]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()
cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")


# In[ ]:


query=("EXEC USP_WEIGHT_VARIANCE_WPP25_SQ")


# In[ ]:


df=pd.read_sql(query,cnxn)
print (len(df))


# In[ ]:


df=df[df['ISDEPARTED_FRM_CURRLOC']=='NO']


# In[ ]:


summary=df.pivot_table(index=['CURR_REGION','CURR_AREA'],aggfunc={'DOCKNO':len})


# In[ ]:


summary.head()


# In[ ]:


depotdftots1 = summary.groupby(level='CURR_REGION').sum()


# In[ ]:


depotdftots1.index = [depotdftots1.index, ['Total'] * len(depotdftots1)]


# In[ ]:


depotpivot1 = np.round(pd.concat([summary,depotdftots1]).sort_index().append(summary.sum().rename(('Grand', 'Total'))),2)


# In[ ]:


depotpivot1


# In[ ]:


# df1=df[df['CON_LOC_TYPE'].isin(['At_Origin_SC','At_Origin_HUB','At_Destn','At_Destn_HUB','At_Intransit_HUB'])]
# len(df1)


# In[ ]:


parent_summary=df.pivot_table(index=['PARENTNAME'],columns=['CON_LOC_TYPE'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').fillna(0)


# In[ ]:


parent_summary['DOCKNO']=parent_summary['DOCKNO'].astype(int)
parent_summary=parent_summary.sort_values(('DOCKNO','Total'),ascending=False)


# In[ ]:


parent_summary


# In[ ]:


todate=datetime.strftime(datetime.now(),"%Y-%m-%d %H")
todate


# In[ ]:

df.to_csv(r'D:\Data\Weight_Report\Weight_Variance_Report_'+str(todate)+'.csv')

df.to_csv(r'D:\Data\Weight_Report\Weight_Variance_Report.csv')


# In[ ]:


filepath=r'D:\Data\Weight_Report\Weight_Variance_Report.csv'


# In[ ]:


import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback

oppath1=filepath
#FTP Upload starts
print ('Logging in...')
ftp = ftplib.FTP()  
ftp.connect('10.109.230.50')  
print (ftp.getwelcome())
try:  
    try:  
        ftp.login('HOSQTeam', 'Te@mH0$q')
        print ('login done')
        ftp.cwd('Auto_reports')  
        #ftp.cwd('FIFO')
        # move to the desired upload directory  
        print ("Currently in:", ftp.pwd()) 
        print ('Uploading...')  
        fullname = oppath1
        name = os.path.split(fullname)[1]  
        f = open(fullname, "rb")  
        ftp.storbinary('STOR ' + name, f)  
        f.close()  
        print ("OK"  )
        print ("Files:")  
        print (ftp.retrlines('LIST'))
    finally:  
        print ("Quitting...")
        ftp.quit()  
except:  
    traceback.print_exc()


# In[ ]:


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

#TO=['mahesh.reddy@spoton.co.in']
TO=['aom_spot@spoton.co.in','dom_spot@spoton.co.in','rom_spot@spoton.co.in','hubmgr_spot@spoton.co.in','scincharge_spot@spoton.co.in','sq_spot@spoton.co.in','spot_cstl@spoton.co.in']
CC=['abhik.mitra@spoton.co.in','jothi.menon@spoton.co.in','rajesh.kumar@spoton.co.in','pawan.sharma@spoton.co.in','anitha.thyagarajan@spoton.co.in','shivananda.p@spoton.co.in','mahesh.reddy@spoton.co.in']

FROM="mis.ho@spoton.co.in"
#CC=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in','anitha.thyagarajan@spoton.co.in','shivananda.p@spoton.co.in']
# CC=['mahesh.reddy@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
msg["Subject"] = "Weight Variance report for WPP > 25 Kgs " + " : " + todate
html='''<html>
<style>
p
{
  margin:0;
  margin-top: 5px;
  padding:0;
  font-size:17px;
    line-height:20px;
}
</style>
<h3>Dear All,</h3>
<p>Please Find POD's Summary.</p>
</html>'''


s = Template(html).safe_substitute()
report=""
#report+=s
#report+='<br>'+final_dff5.to_html()+'<br>'
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='Below is the Weight Variance report for all Apparels where Weight Per Piece ( WPP) is more than 25 Kgs,'
report+='<br>'
report+='Pls weigh the box and check the system weight & physical weight are same.  If found difference then hold the shipment and highlight the same to SQ'
report+='Location Wise Summary : '
report+='<br>'
report+='<br>'+depotpivot1.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='Customer wise Summary : '
report+='<br>'
report+='<br>'+parent_summary.to_html()+'<br>'
report+='<br>'
report+='<br>'

html5='''
<h5> To download the data , Please click the link below </h5>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Weight_Variance_Report.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Weight_Variance_Report.csv</p></b>
    '''
report+=html5
abc=MIMEText(report,'html')
msg.attach(abc)
# part = MIMEBase('application', "octet-stream")
# part.set_payload( open(filepath,"rb").read() )
# encoders.encode_base64(part)
# part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
# msg.attach(part)
# part1 = MIMEBase('application', "octet-stream")
# part1.set_payload( open(filepath1,"rb").read() )
# encoders.encode_base64(part1)
# part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
# msg.attach(part1)

# part2 = MIMEBase('application', "octet-stream")
# part2.set_payload( open(filepath2,"rb").read() )
# encoders.encode_base64(part2)
# part2.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath2))
# msg.attach(part2)

# part3 = MIMEBase('application', "octet-stream")
# part3.set_payload( open(filepath3,"rb").read() )
# encoders.encode_base64(part3)
# part3.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath3))
# msg.attach(part3)

server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()


# In[ ]:


exit(0)


# In[ ]:


import datetime
day_of_month = datetime.datetime.now().day
week_number = (day_of_month - 1) // 7 + 1
day_of_month


# In[ ]:


week_number

