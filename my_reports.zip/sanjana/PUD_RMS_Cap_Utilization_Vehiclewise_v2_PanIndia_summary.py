
# coding: utf-8

# In[1]:

import pandas as pd
import smtplib
import os
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import datetime
from datetime import datetime
from datetime import timedelta
from pandas import ExcelWriter


# In[2]:

branchdf = pd.read_csv('D:\Python\Scripts and Files\Path and Graph Files\Branchlist.csv')
branchdfcols = ['BRANCH CODE','Depot','Region']
branchdf = pd.DataFrame(branchdf,columns=branchdfcols)

pudrmsbasedata = pd.read_csv(r'http://spoton.co.in/downloads/IEProjects/PRCU/PRCU.csv')
pudrmsbasedata['VEHICLE_CAPACITY_NEW'] = pudrmsbasedata.apply(lambda x:abs(x['VEHICLECAPACITY']),axis=1)

branchdfpmdmerge = pd.merge(pudrmsbasedata,branchdf,left_on='Brcd',right_on='BRANCH CODE',how='left')
pudrmsdata = branchdfpmdmerge
pudrmsdata = pudrmsdata.drop('BRANCH CODE',axis=1)


# In[3]:

pudrmsdataforremovingdups = pudrmsdata.drop_duplicates(cols='VehicleNo')
pudrmsdataforremovingdupsgrp = pudrmsdataforremovingdups.groupby(['Region','Depot']).agg({'VEHICLE_CAPACITY_NEW':sum}).reset_index() 
pudrmsdataforremovingdupsgrp['VEHICLE_CAPACITY_NEW'].sum()


# In[4]:

pudrmsdata = pudrmsdata.dropna(subset=['VehicleType'])
print len(pudrmsdata)
pudrmsdata = pudrmsdata.rename(columns={'\xef\xbb\xbfDy':'Date'})


# In[5]:

def utilcalc(vehcap,ofdwt,pkpwt):
    totalwt = ofdwt+pkpwt
    try:
        util = (pd.np.round((totalwt/vehcap),4))*100
        return util
    except:
        return 0

def distancecalc(deldist,pickdist):
    totaldist = deldist+pickdist
    return totaldist


def utilcutoff(utilzn):
    if utilzn >= 300:
        return 'High_utilization'
    elif utilzn <= 50 :
        return 'Low_utilization'
    else:
        return 'NA'

def mispickupperc(totalpickups,mispickups):
    totalassignedpickups = totalpickups+mispickups
    mispickupperc = (pd.np.round((mispickups*1.0/totalassignedpickups),4))*100
    return mispickupperc

def undelperc(ofdcons,undelcons):
    undelperc = pd.np.round(((undelcons/ofdcons)*100.0),2)
    return undelperc


# In[6]:

pudrmsdata['Total_distance'] = pudrmsdata.apply(lambda x:distancecalc(x['DEL_TRAVELDISTANCE'],x['PKP_TRAVELDISTANCE']),axis=1)


# In[7]:

pudrmsdatagrp = pudrmsdata.groupby(['Date','Brcd','VehicleNo','VEHICLE_CAPACITY_NEW','VehicleContractType']).agg({'OFD_CONS':sum,'TOT_DRS':sum,'OFD_ACTWT':sum,'PKP_ACTWT':sum,'DLV_UNIQUEPINCODES':sum,'MISSPICKUPS':sum,'NONDLV_CONS':sum,'Total_distance':sum}).reset_index()


# In[9]:

pudrmsdatagrp['Utilization'] = pudrmsdatagrp.apply(lambda x:utilcalc(x['VEHICLE_CAPACITY_NEW'],x['OFD_ACTWT'],x['PKP_ACTWT']),axis=1)


# In[10]:

pudrmsdatagrp['Utilization_Remarks'] = pudrmsdatagrp.apply(lambda x:utilcutoff(x['Utilization']),axis=1)


# In[11]:

pudrmsdatagrp1forsummary = pudrmsdata.groupby(['Region','Depot','VehicleNo','VEHICLE_CAPACITY_NEW']).agg({'OFD_CONS':sum,'OFD_ACTWT':sum,'PKP_ACTWT':sum,'DLV_UNIQUEPINCODES':sum,'MISSPICKUPS':sum,'NONDLV_CONS':sum,'Total_distance':sum,'TOT_PKPS':sum}).reset_index()


# In[12]:

pudrmsdatagrpsummary = pudrmsdatagrp1forsummary.groupby(['Region','Depot']).agg({'OFD_CONS':sum,'OFD_ACTWT':sum,'PKP_ACTWT':sum,'DLV_UNIQUEPINCODES':sum,'MISSPICKUPS':sum,'NONDLV_CONS':sum,'Total_distance':sum,'TOT_PKPS':sum}).reset_index()
#pudrmsdatagrpsummary['Utilization'] = pudrmsdatagrpsummary.apply(lambda x:utilcalc(x['VEHICLE_CAPACITY_NEW'],x['OFD_ACTWT'],x['PKP_ACTWT']),axis=1)
pudrmssummary = pd.merge(pudrmsdatagrpsummary,pudrmsdataforremovingdupsgrp,on=['Region','Depot'],how='outer')
pudrmssummary['Utilization'] = pudrmssummary.apply(lambda x:utilcalc(x['VEHICLE_CAPACITY_NEW'],x['OFD_ACTWT'],x['PKP_ACTWT']),axis=1)
pudrmssummary['Mispickup%'] = pudrmssummary.apply(lambda x:mispickupperc(x['TOT_PKPS'],x['MISSPICKUPS']),axis=1)
pudrmssummary['Undel%'] = pudrmssummary.apply(lambda x:mispickupperc(x['OFD_CONS'],x['NONDLV_CONS']),axis=1)
pudrmssummary
mailcols = ['Region','Depot','Utilization','Mispickup%','Undel%']
pudrmssummarymail = pd.DataFrame(pudrmssummary,columns=mailcols)
pudrmssummarymail


# In[13]:

now = datetime.now()
yestday = now-timedelta(hours=24)
yestdate = yestday.date()


# In[14]:

#pudrmsdatagrp.to_csv(r'C:\Data\PUD_RMS\PUD_RMS_Report_Vehiclewise_'+str(yestdate)+'.csv')
#oppath1 = r'C:\Data\PUD_RMS\PUD_RMS_Report_Vehiclewise_'+str(yestdate)+'.csv'


# In[15]:

with ExcelWriter(r'D:\Data\PUD_RMS\Vehiclewise\PUD_RMS_Report_Vehiclewise_'+str(yestdate)+'.xlsx') as writer:
     ###orginal_cancel_basedata.to_excel(writer, sheet_name='Sheet1',engine='xlsxwriter')
     pudrmsdatagrp.to_excel(writer, sheet_name='All_vehicles',engine='xlsxwriter')
     pudrmssummary.to_excel(writer, sheet_name='PAN_INDIA_Summary',engine='xlsxwriter')
    
oppath2 = r'D:\Data\PUD_RMS\Vehiclewise\PUD_RMS_Report_Vehiclewise_'+str(yestdate)+'.xlsx'


# In[16]:

pudrmssummarymail = pudrmssummarymail.to_string(index=False)


# In[17]:

filePath = oppath2
def sendEmail(TO = ["goutam.barik@spoton.co.in","sukumar.sakthivel@spoton.co.in"],
              #TO = ["vishwas.j@spoton.co.in"],
              #TO = ["rajeesh.vr@spoton.co.in"],
              CC = ["abhik.mitra@spoton.co.in","rajeesh.vr@spoton.co.in"],
             #CC = ["vishwas.j@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "Vehicle wise PUD RMS Report - "+ str(yestdate)
    body_text = """
    Dear All,
    
    PFB the PUD RMS summay for PAN-INDIA for """+str(yestdate)+"""
    
"""+str(pudrmssummarymail)+"""
    
    
    Note:
    1) 'Utilization_Remarks' column indicates how well the vehicle has been utilized. If the utilization is more than 300%, a remark of High utilization is given. 
    If the utilization is less than 50%, a remark of Low utilization is given.
    
    
    """
    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("vishwas.j@spoton.co.in", "Startrek!123")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends

