# -*- coding: utf-8 -*-
"""
Created on Thu Oct  9 12:31:36 2014

@author: s1602vis
"""

import pandas as pd
import requests as req
import json
from pandas import ExcelWriter
from pprint import pprint
from itertools import repeat
import time

def save_xls(list_dfs, name_dfs, xls_path):
   i = 0
   writer = ExcelWriter(xls_path)   
   for dataframe in list_dfs:
       sheetname = name_dfs[i]
       dataframe.to_excel(writer, sheetname, merge_cells = False)
       i = i+1
   writer.save()




"""xl1 = pd.ExcelFile('C:\Data\PUDAnalysis\250216\Company_branch_addresses_for_distance.xlsx')
df1 = xl1.parse("odpair data")"""
#ippath3 = ('C:\Data\GPS\Pincodes_conversion.xlsx')
#ippath4 = (r'C:\Users\s1602vis\Desktop\ODA_Distances.xlsx')
#xl3 = pd.ExcelFile(ippath4)
#ODPair = xl3.parse('Sheet1')
ODPair =pd.read_csv(r'C:\Users\s1602vis\Documents\IPython Notebooks\Pincode_analysis_SS\frame.csv')

ippath4 = r'C:\Users\s1602vis\Desktop\Apilist.xlsx'
xl4 = pd.ExcelFile(ippath4)
APIlist = xl4.parse('Sheet1')
keylist = APIlist['API list'].tolist()
lenkeylist = len(keylist)
#print (ODPair)
#print (Apilist)
#print (keylist)

j = 0
path = []
divisionbase= lenkeylist

url1 = 'https://maps.googleapis.com/maps/api/distancematrix/json?'
url3 = '&mode=driving&language=En'

 
#http://maps.googleapis.com/maps/api/distancematrix/json?origins=Vancouver+BC|Seattle&destinations=San+Francisco|Victoria+BC&mode=bicycling&language=fr-FR&key=API_KEY

for index,rows in ODPair.iterrows():
    time.sleep(0.3)
    origins = ODPair.iloc[j]['Origin_pincode']
    destinations = ODPair.iloc[j]['Branch_address']
    #start fix to overcome the Google API 2500 elements limit
    rowmode= j%divisionbase
    url4='&key='+ str (keylist[rowmode])
    #end fix to overcome the Google API 2500 elements limit            
    print ('Test url is', url4)    
    url = url1+str('&origins='+str(origins))+str('&destinations='+str(destinations))+url3+url4
    #print (url)
    r = req.get(url)
    text = r.text
    json_data=json.loads(text)
    #print (type (json_data))
    print (json_data)
    a = json_data['rows']
    try:
        addcheck= a[0]['elements'][0]['status']
    except:
        addcheck = 'UNKNOWN_ERROR'
    if addcheck == 'NOT_FOUND' or addcheck == 'ZERO_RESULTS':
        print('Address not found')
        ODPair.loc[j,'Remark1'] = 'Check Address'
    elif addcheck == 'UNKNOWN_ERROR':
        ODPair.loc[j,'Remark1'] = 'Rerun this OD pair'
    else:
        print (a[0]['elements'][0]['distance']['value'])
        print (a[0]['elements'][0]['duration']['text'])
        ODPair.loc[j,'Distance'] = (a[0]['elements'][0]['distance']['value'])/1000
        ODPair.loc[j,'Duration'] = a[0]['elements'][0]['duration']['text']
        distcheck= a[0]['elements'][0]['distance']['value']
        print (distcheck)
        if distcheck > 200000:
            ODPair.loc[j,'Remark2'] = 'Distance greater than 200 kms'
    j = j+1

print (ODPair)

ODPair.to_csv(r'C:\Users\s1602vis\Desktop\frame_op.csv')

#oppath0 = r'C:\Users\s1602vis\Desktop\frame_op.xlsx'
#printlist =  [ODPair]
#namelist = ['Sheet1']
#save_xls (printlist, namelist, oppath0)




