
# coding: utf-8

# In[ ]:

import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
import os
import glob
import Utilities

import sys
reload(sys).setdefaultencoding("ISO-8859-1")
# In[ ]:

datetoday = datetime.now().date()

todayminus1 = datetoday-timedelta(days=1)
todayminus2 = datetoday-timedelta(days=2)
todayminus3 = datetoday-timedelta(days=3)
todayminus4 = datetoday-timedelta(days=4)


# In[ ]:

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()

# In[ ]:

def roundofffuncdiv(a,b):
    perc = pd.np.round((a*1.0/b)*100.0,2)
    return perc


# ### ONETIME MISPICKUPS DATA

# In[ ]:

crmpkpquery = ("""
        EXEC USP_RISK_CUST_CRM_PICKUP_DETAIL 'Y'
        """)
crmpkpdata = pd.read_sql(crmpkpquery, Utilities.cnxn)


# In[ ]:

crmpkpdata_pivot = pd.pivot_table(crmpkpdata,index=['PARENTCODE','PARENTNAME'],columns=['PICKUPSTATUS'],values=['REFNO'],aggfunc=len).reset_index()
crmpkpdata_pivot.columns = [' '.join(col).strip() for col in crmpkpdata_pivot.columns.values]
crmpkpdata_pivot = crmpkpdata_pivot.fillna(0)

crmpkpdata_pivot = pd.DataFrame(crmpkpdata_pivot,columns=['PARENTCODE','PARENTNAME','REFNO SUCCESS','REFNO INTERNAL','REFNO EXTERNAL','REFNO OPEN'])


# In[ ]:

#crmpkpdata_pivot['TOTAL'] = crmpkpdata_pivot.apply(lambda x:(x['REFNO EXTERNAL']+x['REFNO INTERNAL']+x['REFNO SUCCESS']),axis=1)

crmpkpdata_pivot_total = pd.pivot_table(crmpkpdata,index=['PARENTCODE','PARENTNAME'],values=['REFNO'],aggfunc=len).reset_index()
crmpkpdata_pivot_total = crmpkpdata_pivot_total.rename(columns={'REFNO':'TOTAL'})


#crmpkpdata_pivot['TOTAL_MISSED'] = crmpkpdata_pivot.apply(lambda x:(x['REFNO EXTERNAL']+x['REFNO INTERNAL']),axis=1)
crmpkpdata_fail_full = crmpkpdata[crmpkpdata['PICKUPSTATUS']!='SUCCESS']
crmpkpdata_fail_full_pivot = pd.pivot_table(crmpkpdata_fail_full,index=['PARENTCODE','PARENTNAME'],values=['REFNO'],aggfunc=len).reset_index()
crmpkpdata_fail_full_pivot = crmpkpdata_fail_full_pivot.rename(columns={'REFNO':'TOTAL_MISSED'})


crmpkpdata_fail_total = pd.merge(crmpkpdata_pivot_total,crmpkpdata_fail_full_pivot,on=['PARENTCODE','PARENTNAME'],how='outer')


## merge back to main pivot
crmpkpdata_pivot = pd.merge(crmpkpdata_pivot,crmpkpdata_fail_total,on=['PARENTCODE','PARENTNAME'],how='outer')
## merge back to main pivot


crmpkpdata_pivot['Missed%'] = crmpkpdata_pivot.apply(lambda x:roundofffuncdiv(x['TOTAL_MISSED'],x['TOTAL']),axis=1)
crmpkpdata_pivot['INTERNAL_MISSED%'] = crmpkpdata_pivot.apply(lambda x:roundofffuncdiv(x['REFNO INTERNAL'],x['TOTAL']),axis=1)

totalmissedperc = pd.np.round((crmpkpdata_pivot['TOTAL_MISSED'].sum()*1.0/crmpkpdata_pivot['TOTAL'].sum())*100.0,2)
intmissedperc = pd.np.round((crmpkpdata_pivot['REFNO INTERNAL'].sum()*1.0/crmpkpdata_pivot['TOTAL'].sum())*100.0,2)
totalotpkp = crmpkpdata_pivot['TOTAL'].sum()


crmpkpdata_pivot = crmpkpdata_pivot.rename(columns={'Missed%':'Onetime_Missed_PU%','INTERNAL_MISSED%':'Onetime_Internal_Missed_PU%','TOTAL':'TOTAL_Onetime_PU'})
crmpkpdata_pivot = pd.DataFrame(crmpkpdata_pivot,columns=['PARENTCODE','PARENTNAME','Onetime_Missed_PU%','Onetime_Internal_Missed_PU%','TOTAL_Onetime_PU'])

#crmpkpdata_pivot.to_csv(r'crmpkpdata_pivot.csv')


# In[ ]:

totalotpkp,intmissedperc,totalmissedperc


# In[ ]:

sumlistpkp = ['000000000','Total',totalmissedperc,intmissedperc,totalotpkp]
col_listpkp = ['PARENTCODE','PARENTNAME','Onetime_Missed_PU%','Onetime_Internal_Missed_PU%','TOTAL_Onetime_PU']
crmpkpdata_totals = pd.DataFrame(data=[sumlistpkp], columns = col_listpkp)
crmpkpdata_pivot = crmpkpdata_pivot.append(crmpkpdata_totals,ignore_index=True)


# In[ ]:

len(crmpkpdata_pivot)


# ### For Areawise Summary or Mispickups

# In[ ]:

crmpkpdata_pivot_area = pd.pivot_table(crmpkpdata,index=['Region','Area'],columns=['PICKUPSTATUS'],values=['REFNO'],aggfunc=len).reset_index()
crmpkpdata_pivot_area.columns = [' '.join(col).strip() for col in crmpkpdata_pivot_area.columns.values]
crmpkpdata_pivot_area = crmpkpdata_pivot_area.fillna(0)

crmpkpdata_pivot_area = pd.DataFrame(crmpkpdata_pivot_area,columns=['Region','Area','REFNO SUCCESS','REFNO INTERNAL','REFNO EXTERNAL','REFNO OPEN'])


# In[ ]:

crmpkpdata_pivot_area.head()


# In[ ]:

#crmpkpdata_pivot['TOTAL'] = crmpkpdata_pivot.apply(lambda x:(x['REFNO EXTERNAL']+x['REFNO INTERNAL']+x['REFNO SUCCESS']),axis=1)

crmpkpdata_pivot_total_area = pd.pivot_table(crmpkpdata,index=['Region','Area'],values=['REFNO'],aggfunc=len).reset_index()
crmpkpdata_pivot_total_area = crmpkpdata_pivot_total_area.rename(columns={'REFNO':'TOTAL'})


#crmpkpdata_pivot['TOTAL_MISSED'] = crmpkpdata_pivot.apply(lambda x:(x['REFNO EXTERNAL']+x['REFNO INTERNAL']),axis=1)
crmpkpdata_fail_full_area = crmpkpdata[crmpkpdata['PICKUPSTATUS']!='SUCCESS']
crmpkpdata_fail_full_pivot_area = pd.pivot_table(crmpkpdata_fail_full_area,index=['Region','Area'],values=['REFNO'],aggfunc=len).reset_index()
crmpkpdata_fail_full_pivot_area = crmpkpdata_fail_full_pivot_area.rename(columns={'REFNO':'TOTAL_MISSED'})


crmpkpdata_fail_total_area = pd.merge(crmpkpdata_pivot_total_area,crmpkpdata_fail_full_pivot_area,on=['Region','Area'],how='outer')
print crmpkpdata_fail_total_area.head()

## merge back to main pivot
crmpkpdata_pivot_area = pd.merge(crmpkpdata_pivot_area,crmpkpdata_fail_total_area,on=['Region','Area'],how='outer')
## merge back to main pivot

crmpkpdata_pivot_area.head()


# In[ ]:

crmpkpdata_pivot_area['Missed%'] = crmpkpdata_pivot_area.apply(lambda x:roundofffuncdiv(x['TOTAL_MISSED'],x['TOTAL']),axis=1)
crmpkpdata_pivot_area['INTERNAL_MISSED%'] = crmpkpdata_pivot_area.apply(lambda x:roundofffuncdiv(x['REFNO INTERNAL'],x['TOTAL']),axis=1)

totalmissedperc_area = pd.np.round((crmpkpdata_pivot_area['TOTAL_MISSED'].sum()*1.0/crmpkpdata_pivot_area['TOTAL'].sum())*100.0,2)
intmissedperc_area = pd.np.round((crmpkpdata_pivot_area['REFNO INTERNAL'].sum()*1.0/crmpkpdata_pivot_area['TOTAL'].sum())*100.0,2)
totalotpkp_area = crmpkpdata_pivot_area['TOTAL'].sum()


crmpkpdata_pivot_area = crmpkpdata_pivot_area.rename(columns={'Missed%':'Onetime_Missed_PU%','INTERNAL_MISSED%':'Onetime_Internal_Missed_PU%','TOTAL':'TOTAL_Onetime_PU'})
crmpkpdata_pivot_area = pd.DataFrame(crmpkpdata_pivot_area,columns=['Region','Area','Onetime_Missed_PU%','Onetime_Internal_Missed_PU%','TOTAL_Onetime_PU'])

#crmpkpdata_pivot_area.to_csv(r'crmpkpdata_pivot_area.csv')


# In[ ]:

sumlistpkp_area = ['Total','Total',totalmissedperc_area,intmissedperc_area,totalotpkp_area]
col_listpkp_area = ['Region','Area','Onetime_Missed_PU%','Onetime_Internal_Missed_PU%','TOTAL_Onetime_PU']
crmpkpdata_totals_area = pd.DataFrame(data=[sumlistpkp_area], columns = col_listpkp_area)
crmpkpdata_pivot_area = crmpkpdata_pivot_area.append(crmpkpdata_totals_area,ignore_index=True)


# In[ ]:

#crmpkpdata_pivot_area.to_csv(r'crmpkpdata_pivot_area.csv')


# #### UNCONNECTED SHIPMENTS DATA

# In[ ]:

unconctquery = ("""
        EXEC USP_RISK_CUST_UNCONNECT_DETAIL
        """)
unconctdata = pd.read_sql(unconctquery, Utilities.cnxn)


# In[ ]:

#unconctdata_pivot = pd.pivot_table(unconctdata,index=['PTMSPTCD','PTMSPTNM'],columns=['CON_STATUS'],values=['DOCKNO'],aggfunc=len).reset_index()
unconctdata_pivot = pd.pivot_table(unconctdata,index=['PTMSPTCD','PTMSPTNM'],values=['DOCKNO'],aggfunc=len).reset_index()
#unconctdata_pivot.columns = [' '.join(col).strip() for col in unconctdata_pivot.columns.values]
unconctdata_pivot = unconctdata_pivot.fillna(0)

unconctdata_pivot = unconctdata_pivot.rename(columns={'DOCKNO':'TOTAL_UNCONNECTED_CONS'})

#unconctdata_pivot = pd.DataFrame(unconctdata_pivot,columns=['PTMSPTCD','PTMSPTNM','DOCKNO STF','DOCKNO NCF','DOCKNO DEPS','DOCKNO CCF'])

#unconctdata_pivot['TOTAL_UNCONNECTED_CONS'] = unconctdata_pivot.apply(lambda x:(x['DOCKNO CCF']+x['DOCKNO DEPS']+x['DOCKNO NCF']+x['DOCKNO STF']),axis=1)


# In[ ]:

ccfstflist = ['CCF','STF']
unconn_ccf_stf = unconctdata[(unconctdata['LYING >24 HRS']=='YES') & (unconctdata['CON_STATUS'].isin(ccfstflist))]


unconn_ccf_stf_pivot = pd.pivot_table(unconn_ccf_stf,index=['PTMSPTCD','PTMSPTNM'],columns=['CON_STATUS'],values=['DOCKNO'],aggfunc=len).reset_index()
unconn_ccf_stf_pivot.columns = [' '.join(col).strip() for col in unconn_ccf_stf_pivot.columns.values]
unconn_ccf_stf_pivot = unconn_ccf_stf_pivot.fillna(0)


# In[ ]:

unconn_ccf = unconn_ccf_stf_pivot['DOCKNO CCF'].sum()
unconn_stf = unconn_ccf_stf_pivot['DOCKNO STF'].sum()
unconn_total = unconctdata_pivot['TOTAL_UNCONNECTED_CONS'].sum()
print unconn_ccf,unconn_stf,unconn_total


# In[ ]:

unconnected_final = pd.merge(unconctdata_pivot,unconn_ccf_stf_pivot,on=['PTMSPTCD','PTMSPTNM'],how='outer')
print unconnected_final.columns.tolist()
print unconnected_final['DOCKNO CCF'].sum(),unconnected_final['DOCKNO STF'].sum(),unconnected_final['TOTAL_UNCONNECTED_CONS'].sum()
unconnected_final = pd.DataFrame(unconnected_final,columns=['PTMSPTCD','PTMSPTNM','DOCKNO CCF','DOCKNO STF','TOTAL_UNCONNECTED_CONS'])
unconnected_final = unconnected_final.rename(columns={'PTMSPTCD':'PARENTCODE','PTMSPTNM':'PARENTNAME','DOCKNO CCF':'UNCONNECTED_CCF>24Hrs','DOCKNO STF':'UNCONNECTED_STF>24Hrs'})
unconnected_final = unconnected_final.fillna(0)


# In[ ]:

sumlistunconn = ['000000000','Total',unconn_ccf,unconn_stf,unconn_total]
col_listunconn = ['PARENTCODE','PARENTNAME','UNCONNECTED_CCF>24Hrs','UNCONNECTED_STF>24Hrs','TOTAL_UNCONNECTED_CONS']
unconn_totals = pd.DataFrame(data=[sumlistunconn], columns = col_listunconn)
unconnected_final = unconnected_final.append(unconn_totals,ignore_index=True)


# In[ ]:

len(unconnected_final)


# ### For Unconnected Areawise

# In[ ]:

unconctdata_pivot_area = pd.pivot_table(unconctdata,index=['Region','Area'],values=['DOCKNO'],aggfunc=len).reset_index()
#unconctdata_pivot.columns = [' '.join(col).strip() for col in unconctdata_pivot.columns.values]
unconctdata_pivot_area = unconctdata_pivot_area.fillna(0)

unconctdata_pivot_area = unconctdata_pivot_area.rename(columns={'DOCKNO':'TOTAL_UNCONNECTED_CONS'})


# In[ ]:

unconn_ccf_stf_pivot_area = pd.pivot_table(unconn_ccf_stf,index=['Region','Area'],columns=['CON_STATUS'],values=['DOCKNO'],aggfunc=len).reset_index()
unconn_ccf_stf_pivot_area.columns = [' '.join(col).strip() for col in unconn_ccf_stf_pivot_area.columns.values]
unconn_ccf_stf_pivot_area = unconn_ccf_stf_pivot_area.fillna(0)


# In[ ]:

unconn_ccf_area = unconn_ccf_stf_pivot_area['DOCKNO CCF'].sum()
unconn_stf_area = unconn_ccf_stf_pivot_area['DOCKNO STF'].sum()
unconn_total_area = unconctdata_pivot_area['TOTAL_UNCONNECTED_CONS'].sum()
print unconn_ccf_area,unconn_stf_area,unconn_total_area


# In[ ]:

unconnected_final_area = pd.merge(unconctdata_pivot_area,unconn_ccf_stf_pivot_area,on=['Region','Area'],how='outer')
print unconnected_final_area.columns.tolist()
print unconnected_final_area['DOCKNO CCF'].sum(),unconnected_final_area['DOCKNO STF'].sum(),unconnected_final_area['TOTAL_UNCONNECTED_CONS'].sum()
unconnected_final_area = pd.DataFrame(unconnected_final_area,columns=['Region','Area','DOCKNO CCF','DOCKNO STF','TOTAL_UNCONNECTED_CONS'])
unconnected_final_area = unconnected_final_area.rename(columns={'DOCKNO CCF':'UNCONNECTED_CCF>24Hrs','DOCKNO STF':'UNCONNECTED_STF>24Hrs'})
unconnected_final_area = unconnected_final_area.fillna(0)


# In[ ]:

sumlistunconn_area = ['Total','Total',unconn_ccf_area,unconn_stf_area,unconn_total_area]
col_listunconn_area = ['Region','Area','UNCONNECTED_CCF>24Hrs','UNCONNECTED_STF>24Hrs','TOTAL_UNCONNECTED_CONS']
unconn_totals_area = pd.DataFrame(data=[sumlistunconn_area], columns = col_listunconn_area)
unconnected_final_area = unconnected_final_area.append(unconn_totals_area,ignore_index=True)


# In[ ]:

#unconnected_final_area.to_csv(r'unconnected_final_area.csv')


# ### For Undel Aging

# In[ ]:

undelquery = ("""
        EXEC USP_RISK_CUST_UNDELCON_DETAIL
        """)
undeldata = pd.read_sql(undelquery, Utilities.cnxn)
print len(undeldata)
undeldata = undeldata[undeldata['AGEING']!='<=24HRS']

includelist = ['CCF','STF']
undeldata = undeldata[undeldata['CONSTATUS'].isin(includelist)]
len(undeldata)


# In[ ]:

undeldata_pivot = pd.pivot_table(undeldata,index=['PARENTCODE','PARENTNAME'],columns=['CONSTATUS','AGEING'],values=['DOCKNO'],aggfunc=len).reset_index()


# In[ ]:

undeldata_pivot.columns = [' '.join(col).strip() for col in undeldata_pivot.columns.values]
undeldata_pivot = undeldata_pivot.fillna(0)
undeldata_pivot = undeldata_pivot.rename(columns={'DOCKNO CCF >24HRS':'UNDEL_CCF_>24HRS','DOCKNO CCF >48HRS':'UNDEL_CCF_>48HRS','DOCKNO CCF >72HRS':'UNDEL_CCF_>72HRS','DOCKNO STF >24HRS':'UNDEL_STF_>24HRS','DOCKNO STF >48HRS':'UNDEL_STF_>48HRS','DOCKNO STF >72HRS':'UNDEL_STF_>72HRS'})


# In[ ]:

undeldata_pivot.head()


# In[ ]:

undeldata_ccf_24 = undeldata_pivot['UNDEL_CCF_>24HRS'].sum()
undeldata_ccf_48 = undeldata_pivot['UNDEL_CCF_>48HRS'].sum()
undeldata_ccf_72 = undeldata_pivot['UNDEL_CCF_>72HRS'].sum()
undeldata_stf_24 = undeldata_pivot['UNDEL_STF_>24HRS'].sum()
undeldata_stf_48 = undeldata_pivot['UNDEL_STF_>48HRS'].sum()
undeldata_stf_72 = undeldata_pivot['UNDEL_STF_>72HRS'].sum()


sumlistundel = ['000000000','Total',undeldata_ccf_24,undeldata_ccf_48,undeldata_ccf_72,undeldata_stf_24,undeldata_stf_48,undeldata_stf_72]
col_listundel = ['PARENTCODE','PARENTNAME','UNDEL_CCF_>24HRS','UNDEL_CCF_>48HRS','UNDEL_CCF_>72HRS','UNDEL_STF_>24HRS','UNDEL_STF_>48HRS','UNDEL_STF_>72HRS']
undel_totals = pd.DataFrame(data=[sumlistundel], columns = col_listundel)
undeldata_pivot = undeldata_pivot.append(undel_totals,ignore_index=True)

#undeldata_pivot.to_csv(r'undeldata_pivot.csv')


# In[ ]:

len(undeldata_pivot)


# ### For Undel Areawise

# In[ ]:

undeldata_pivot_area = pd.pivot_table(undeldata,index=['DEST_REGION','DEST_AREA'],columns=['CONSTATUS','AGEING'],values=['DOCKNO'],aggfunc=len).reset_index()
undeldata_pivot_area.columns = [' '.join(col).strip() for col in undeldata_pivot_area.columns.values]
undeldata_pivot_area = undeldata_pivot_area.fillna(0)
undeldata_pivot_area = undeldata_pivot_area.rename(columns={'DEST_REGION':'Region','DEST_AREA':'Area','DOCKNO CCF >24HRS':'UNDEL_CCF_>24HRS','DOCKNO CCF >48HRS':'UNDEL_CCF_>48HRS','DOCKNO CCF >72HRS':'UNDEL_CCF_>72HRS','DOCKNO STF >24HRS':'UNDEL_STF_>24HRS','DOCKNO STF >48HRS':'UNDEL_STF_>48HRS','DOCKNO STF >72HRS':'UNDEL_STF_>72HRS'})


# In[ ]:

undeldata_ccf_24_area = undeldata_pivot_area['UNDEL_CCF_>24HRS'].sum()
undeldata_ccf_48_area = undeldata_pivot_area['UNDEL_CCF_>48HRS'].sum()
undeldata_ccf_72_area = undeldata_pivot_area['UNDEL_CCF_>72HRS'].sum()
undeldata_stf_24_area = undeldata_pivot_area['UNDEL_STF_>24HRS'].sum()
undeldata_stf_48_area = undeldata_pivot_area['UNDEL_STF_>48HRS'].sum()
undeldata_stf_72_area = undeldata_pivot_area['UNDEL_STF_>72HRS'].sum()

sumlistundel_area = ['Total','Total',undeldata_ccf_24_area,undeldata_ccf_48_area,undeldata_ccf_72_area,undeldata_stf_24_area,undeldata_stf_48_area,undeldata_stf_72_area]
col_listundel_area = ['Region','Area','UNDEL_CCF_>24HRS','UNDEL_CCF_>48HRS','UNDEL_CCF_>72HRS','UNDEL_STF_>24HRS','UNDEL_STF_>48HRS','UNDEL_STF_>72HRS']
undel_totals_area = pd.DataFrame(data=[sumlistundel_area], columns = col_listundel_area)
undeldata_pivot_area = undeldata_pivot_area.append(undel_totals_area,ignore_index=True)


# In[ ]:

#undeldata_pivot_area.to_csv(r'undeldata_pivot_area.csv')


# ### For Tickets Pending

# In[ ]:

pendingticksquery = ("""
        EXEC USP_RISK_CUST_TICKET_DETAIL
        """)
pendingticksdata = pd.read_sql(pendingticksquery, Utilities.cnxn)
print len(pendingticksdata)
pendingticksdata = pendingticksdata[pendingticksdata['TICKET_AGEING']!='<=24HRS']
len(pendingticksdata)


# In[ ]:

pendingticks_pivot = pd.pivot_table(pendingticksdata,index=['PARENTCODE','PARENTNAME'],columns=['TICKET_AGEING'],values=['TICKET NO'],aggfunc=len).reset_index()


# In[ ]:

pendingticks_pivot.columns = [' '.join(col).strip() for col in pendingticks_pivot.columns.values]
pendingticks_pivot = pendingticks_pivot.fillna(0)
pendingticks_pivot = pendingticks_pivot.rename(columns={'TICKET NO >24HRS':'PENDING_TICKETS_>24HRS','TICKET NO >48HRS':'PENDING_TICKETS_>48HRS','TICKET NO >72HRS':'PENDING_TICKETS_>72HRS'})


# In[ ]:

pendingticks_24 = pendingticks_pivot['PENDING_TICKETS_>24HRS'].sum()
pendingticks_48 = pendingticks_pivot['PENDING_TICKETS_>48HRS'].sum()
pendingticks_72 = pendingticks_pivot['PENDING_TICKETS_>72HRS'].sum()


sumlistpendticks = ['000000000','Total',pendingticks_24,pendingticks_48,pendingticks_72]
col_listpendticks = ['PARENTCODE','PARENTNAME','PENDING_TICKETS_>24HRS','PENDING_TICKETS_>48HRS','PENDING_TICKETS_>72HRS']
pendticks_totals = pd.DataFrame(data=[sumlistpendticks], columns = col_listpendticks)
pendingticks_pivot = pendingticks_pivot.append(pendticks_totals,ignore_index=True)

#pendingticks_pivot.to_csv(r'pendingticks_pivot.csv')


# In[ ]:

len(pendingticks_pivot)


# ### For Pending Complaints

# In[ ]:

pendingcompsquery = ("""
        EXEC USP_RISK_CUST_COMPLAINT_DETAIL
        """)
pendingcompsdata = pd.read_sql(pendingcompsquery, Utilities.cnxn)
print len(pendingcompsdata)

### Edit on 27-03-2017 for adding Total complaints
pendingcomps_cat_total = pd.pivot_table(pendingcompsdata,index=['PARENTCODE','PARENTNAME'],columns=['CategoryName'],values=['COMPLAINT NO'],aggfunc=len,margins=True).reset_index()
pendingcomps_cat_total.columns = [' '.join(col).strip() for col in pendingcomps_cat_total.columns.values]
pendingcomps_cat_total = pendingcomps_cat_total.fillna(0)

## For selecting actua column names and removing Complaint No in the columne name
pendingcomps_cat_total = pendingcomps_cat_total.rename(columns={col: col.split(' NO ')[1] for col in (checkcol for checkcol in pendingcomps_cat_total.columns if ' NO ' in checkcol)})
pendingcomps_cat_total = pendingcomps_cat_total.rename(columns={'All':'TOTAL'})
## For selecting actua column names and removing Complaint No in the columne name


total_compspending = pendingcompsdata.groupby(['PARENTCODE','PARENTNAME']).agg({'COMPLAINT NO':len}).reset_index()
total_compspending = total_compspending.rename(columns={'COMPLAINT NO':'Total_Complaints'})
### Edit on 27-03-2017 for adding Total complaints
pendingcompsdata = pendingcompsdata[pendingcompsdata['TICKET_AGEING']!='<=24HRS']
len(pendingcompsdata)


# In[ ]:

pendingcomps_pivot = pd.pivot_table(pendingcompsdata,index=['PARENTCODE','PARENTNAME'],columns=['TICKET_AGEING'],values=['COMPLAINT NO'],aggfunc=len).reset_index()


# In[ ]:

pendingcomps_pivot.columns = [' '.join(col).strip() for col in pendingcomps_pivot.columns.values]
pendingcomps_pivot = pendingcomps_pivot.fillna(0)


## Edit for adding Total complaints in the DF
pendingcomps_pivot = pd.merge(pendingcomps_pivot,total_compspending,on=['PARENTCODE','PARENTNAME'],how='outer')
## Edit for adding Total complaints in the DF

pendingcomps_pivot = pd.DataFrame(pendingcomps_pivot,columns=['PARENTCODE','PARENTNAME','COMPLAINT NO >24HRS','COMPLAINT NO >48HRS','COMPLAINT NO >72HRS','Total_Complaints'])

pendingcomps_pivot = pendingcomps_pivot.rename(columns={'COMPLAINT NO >24HRS':'PENDING_COMPLAINTS_>24HRS','COMPLAINT NO >48HRS':'PENDING_COMPLAINTS_>48HRS','COMPLAINT NO >72HRS':'PENDING_COMPLAINTS_>72HRS'})
pendingcomps_24 = pendingcomps_pivot['PENDING_COMPLAINTS_>24HRS'].sum()
pendingcomps_48 = pendingcomps_pivot['PENDING_COMPLAINTS_>48HRS'].sum()
pendingcomps_72 = pendingcomps_pivot['PENDING_COMPLAINTS_>72HRS'].sum()
total_complaints = pendingcomps_pivot['Total_Complaints'].sum()

sumlistpendcomps = ['000000000','Total',pendingcomps_24,pendingcomps_48,pendingcomps_72,total_complaints]
col_listpendcomps = ['PARENTCODE','PARENTNAME','PENDING_COMPLAINTS_>24HRS','PENDING_COMPLAINTS_>48HRS','PENDING_COMPLAINTS_>72HRS','Total_Complaints']
pendcomps_totals = pd.DataFrame(data=[sumlistpendcomps], columns = col_listpendcomps)
pendingcomps_pivot = pendingcomps_pivot.append(pendcomps_totals,ignore_index=True)

#pendingcomps_pivot.to_csv(r'pendingcomps_pivot.csv')
# In[ ]:

#pendingcomps_pivot.to_csv(r'pendingcomps_pivot.csv')


# In[ ]:

len(pendingcomps_pivot)


# ### For OPP CEM REACH 

# In[ ]:

oppsumquery = ("""
        EXEC dbo.USP_RISK_CUST_OPP_SUMMARY
        """)
oppsumdata = pd.read_sql(oppsumquery, Utilities.cnxn)
len(oppsumdata)


# In[ ]:

try:
    totalduecons = oppsumdata['TOTAL CONS'].sum()
    reachperc = pd.np.round((oppsumdata['REACH CONS'].sum()*1.0/totalduecons)*100.0,2)
    oppperc = pd.np.round((oppsumdata['ONTIME DELIVERY'].sum()*1.0/totalduecons)*100.0,2)
    cemperc = pd.np.round((oppsumdata['CEM_CONS'].sum()*1.0/totalduecons)*100.0,2)
except:
    totalduecons = 0.0
    reachperc = 0.0
    oppperc = 0.0
    cemperc = 0.0


# In[ ]:

oppsumdata_summary = oppsumdata.groupby(['PARENTCODE','PARENTNAME']).agg({'TOTAL CONS':sum,'REACH CONS':sum,'ONTIME DELIVERY':sum,'CEM_CONS':sum}).reset_index()
oppsumdata_summary['REACH%'] = oppsumdata_summary.apply(lambda x:roundofffuncdiv(x['REACH CONS'],x['TOTAL CONS']),axis=1)
oppsumdata_summary['OPP%'] = oppsumdata_summary.apply(lambda x:roundofffuncdiv(x['ONTIME DELIVERY'],x['TOTAL CONS']),axis=1)
oppsumdata_summary['CEM%'] = oppsumdata_summary.apply(lambda x:roundofffuncdiv(x['CEM_CONS'],x['TOTAL CONS']),axis=1)


# In[ ]:

#oppsumdata_summary.to_csv(r'oppsumdata_summary.csv')


# In[ ]:

oppsumdata_summary = pd.DataFrame(oppsumdata_summary,columns=['PARENTCODE','PARENTNAME','TOTAL CONS','REACH%','OPP%','CEM%'])


# In[ ]:

oppsumdata_summary = oppsumdata_summary.rename(columns={'TOTAL CONS':'TOTAL_DUEDATE_CONS'})


# In[ ]:

sumlistreach = ['000000000','Total',totalduecons,reachperc,oppperc,cemperc]
col_listreach = ['PARENTCODE','PARENTNAME','TOTAL_DUEDATE_CONS','REACH%','OPP%','CEM%']
reach_totals = pd.DataFrame(data=[sumlistreach], columns = col_listreach)
oppsumdata_summary = oppsumdata_summary.append(reach_totals,ignore_index=True)


# In[ ]:

#oppsumdata_summary.to_csv(r'oppsumdata_summary.csv')


# In[ ]:

len(oppsumdata_summary)


# ### For Areawise Reach

# In[ ]:

oppsumdata_summary_area = oppsumdata.groupby(['Region','Area']).agg({'TOTAL CONS':sum,'REACH CONS':sum,'ONTIME DELIVERY':sum,'CEM_CONS':sum}).reset_index()
oppsumdata_summary_area['REACH%'] = oppsumdata_summary_area.apply(lambda x:roundofffuncdiv(x['REACH CONS'],x['TOTAL CONS']),axis=1)
oppsumdata_summary_area['OPP%'] = oppsumdata_summary_area.apply(lambda x:roundofffuncdiv(x['ONTIME DELIVERY'],x['TOTAL CONS']),axis=1)
oppsumdata_summary_area['CEM%'] = oppsumdata_summary_area.apply(lambda x:roundofffuncdiv(x['CEM_CONS'],x['TOTAL CONS']),axis=1)


# In[ ]:

oppsumdata_summary_area = pd.DataFrame(oppsumdata_summary_area,columns=['Region','Area','TOTAL CONS','REACH%','OPP%','CEM%'])


# In[ ]:

oppsumdata_summary_area = oppsumdata_summary_area.rename(columns={'TOTAL CONS':'TOTAL_DUEDATE_CONS'})


# In[ ]:

sumlistreach = ['Total','Total',totalduecons,reachperc,oppperc,cemperc]
col_listreach = ['Region','Area','TOTAL_DUEDATE_CONS','REACH%','OPP%','CEM%']
reach_totals = pd.DataFrame(data=[sumlistreach], columns = col_listreach)
oppsumdata_summary_area = oppsumdata_summary_area.append(reach_totals,ignore_index=True)


# In[ ]:

#oppsumdata_summary_area.to_csv(r'oppsumdata_summary_area.csv')


# ### For Delivery Efficiency

# In[ ]:

deleffquery = ("""
         EXEC dbo.USP_RISK_CUST_DELIVERY_EFFICIENCY
        """)
deleffdata = pd.read_sql(deleffquery, Utilities.cnxn)
len(deleffdata)


# In[ ]:

deleffdata_summary = deleffdata.groupby(['PARENTCODE','PARENTNAME']).agg({'Total':sum,'Delivered':sum}).reset_index()

try:
    deleffdata_summary['Delivery_Efficiency%'] = deleffdata_summary.apply(lambda x:roundofffuncdiv(x['Delivered'],x['Total']),axis=1)
except:
    deleffdata_summary['Delivery_Efficiency%'] = 0.0


# In[ ]:

deleffdata_summary.head()


# In[ ]:

deleffdata_summary = pd.DataFrame(deleffdata_summary,columns=['PARENTCODE','PARENTNAME','Delivery_Efficiency%'])

try:
    total_de = pd.np.round((deleffdata['Delivered'].sum()*1.0/deleffdata['Total'].sum())*100.0,2)
except:
    total_de = 0.0

sumlistde = ['000000000','Total',total_de]
col_listde = ['PARENTCODE','PARENTNAME','Delivery_Efficiency%']
de_totals = pd.DataFrame(data=[sumlistde], columns = col_listde)
deleffdata_summary = deleffdata_summary.append(de_totals,ignore_index=True)


#deleffdata_summary.to_csv(r'deleffdata_summary.csv')


# In[ ]:

deleffdata_summary_area = deleffdata.groupby(['Region','Area']).agg({'Total':sum,'Delivered':sum}).reset_index()

try:
    deleffdata_summary_area['Delivery_Efficiency%'] = deleffdata_summary_area.apply(lambda x:roundofffuncdiv(x['Delivered'],x['Total']),axis=1)
except:
    deleffdata_summary_area['Delivery_Efficiency%'] = 0.0


# In[ ]:

deleffdata_summary_area = pd.DataFrame(deleffdata_summary_area,columns=['Region','Area','Delivery_Efficiency%'])

try:
    total_de = pd.np.round((deleffdata['Delivered'].sum()*1.0/deleffdata['Total'].sum())*100.0,2)
except:
    total_de = 0.0

sumlistde = ['Total','Total',total_de]
col_listde = ['Region','Area','Delivery_Efficiency%']
de_totals = pd.DataFrame(data=[sumlistde], columns = col_listde)
deleffdata_summary_area = deleffdata_summary_area.append(de_totals,ignore_index=True)


#deleffdata_summary_area.to_csv(r'deleffdata_summary_area.csv')


# ### For Shortage report

# In[ ]:

shortquery = ("""
         EXEC USP_RISK_CUST_SHORTAGE_REPORT
        """)
shortdata = pd.read_sql(shortquery, Utilities.cnxn)
len(shortdata)

shortdata = shortdata.rename(columns={'ParentCode':'PARENTCODE','ParentName':'PARENTNAME','RGALPH':'Region','ControlArea':'Area'})


# In[ ]:

shortdata_greater72 = shortdata[shortdata['Ageing']!='<=72Hrs']
len(shortdata_greater72)
shortdata_greater72_pivot = pd.pivot_table(shortdata_greater72,index=['PARENTCODE','PARENTNAME'],columns=['Ageing'],values=['DOCKNO'],aggfunc=len).reset_index()
shortdata_greater72_pivot.columns = [' '.join(col).strip() for col in shortdata_greater72_pivot.columns.values]
shortdata_greater72_pivot = shortdata_greater72_pivot.fillna(0)

shortdata_greater72_summary = pd.DataFrame(shortdata_greater72_pivot,columns=['PARENTCODE','PARENTNAME','DOCKNO >120Hrs','DOCKNO >72Hrs'])

try:
    consgreat120 = shortdata_greater72_summary['DOCKNO >120Hrs'].sum()
    consgreat72 = shortdata_greater72_summary['DOCKNO >72Hrs'].sum()
except:
    consgreat120 = 0.0
    consgreat72 = 0.0
    
    
sumlistshort = ['000000000','Total',consgreat120,consgreat72]
col_listshort = ['PARENTCODE','PARENTNAME','DOCKNO >120Hrs','DOCKNO >72Hrs']
short_totals = pd.DataFrame(data=[sumlistshort], columns = col_listshort)
shortdata_summary = shortdata_greater72_summary.append(short_totals,ignore_index=True)

shortdata_summary = shortdata_summary.rename(columns={'DOCKNO >120Hrs':'SHORT_vs_PENDING_RESOLUTION>120Hrs','DOCKNO >72Hrs':'SHORT_vs_PENDING_RESOLUTION>72Hrs'})
shortdata_summary = shortdata_summary.fillna(0)


# In[ ]:

shortdata_summary.head()


# ### For Shortage Areawise

# In[ ]:

shortdata_greater72_area = pd.pivot_table(shortdata_greater72,index=['Region','Area'],columns=['Ageing'],values=['DOCKNO'],aggfunc=len).reset_index()
shortdata_greater72_area.columns = [' '.join(col).strip() for col in shortdata_greater72_area.columns.values]
shortdata_greater72_area = shortdata_greater72_area.fillna(0)

shortdata_greater72_area_summary = pd.DataFrame(shortdata_greater72_area,columns=['Region','Area','DOCKNO >120Hrs','DOCKNO >72Hrs'])

try:
    consgreat120 = shortdata_greater72_area_summary['DOCKNO >120Hrs'].sum()
    consgreat72 = shortdata_greater72_area_summary['DOCKNO >72Hrs'].sum()
except:
    consgreat120 = 0.0
    consgreat72 = 0.0
    
    
sumlistshort_area = ['Total','Total',consgreat120,consgreat72]
col_listshort_area = ['Region','Area','DOCKNO >120Hrs','DOCKNO >72Hrs']
short_totals_area = pd.DataFrame(data=[sumlistshort_area], columns = col_listshort_area)
shortdata_summary_area = shortdata_greater72_area_summary.append(short_totals_area,ignore_index=True)

shortdata_summary_area = shortdata_summary_area.rename(columns={'DOCKNO >120Hrs':'SHORT_vs_PENDING_RESOLUTION>120Hrs','DOCKNO >72Hrs':'SHORT_vs_PENDING_RESOLUTION>72Hrs'})
shortdata_summary_area = shortdata_summary_area.fillna(0)


# In[ ]:


# In[ ]:

otpu_unconnected = pd.merge(crmpkpdata_pivot,unconnected_final,on=['PARENTCODE','PARENTNAME'],how='outer')
otpu_unconnected = otpu_unconnected.fillna('-')

otpu_uncon_undel = pd.merge(otpu_unconnected,undeldata_pivot,on=['PARENTCODE','PARENTNAME'],how='outer')
otpu_uncon_undel = otpu_uncon_undel.fillna('-')

otpu_uncon_undel_ticks = pd.merge(otpu_uncon_undel,pendingticks_pivot,on=['PARENTCODE','PARENTNAME'],how='outer')
otpu_uncon_undel_ticks = otpu_uncon_undel_ticks.fillna('-')

otpu_uncon_undel_ticks_comps = pd.merge(otpu_uncon_undel_ticks,pendingcomps_pivot,on=['PARENTCODE','PARENTNAME'],how='outer')
otpu_uncon_undel_ticks_comps = otpu_uncon_undel_ticks_comps.fillna('-')

otpu_uncon_undel_ticks_comps_short = pd.merge(otpu_uncon_undel_ticks_comps,shortdata_summary,on=['PARENTCODE','PARENTNAME'],how='outer')
otpu_uncon_undel_ticks_comps_short = otpu_uncon_undel_ticks_comps_short.fillna('-')

print otpu_uncon_undel_ticks_comps_short.columns.tolist()

otpu_uncon_undel_ticks_comps_opp_short = pd.merge(otpu_uncon_undel_ticks_comps_short,oppsumdata_summary,on=['PARENTCODE','PARENTNAME'],how='outer')
otpu_uncon_undel_ticks_comps_opp_short = otpu_uncon_undel_ticks_comps_opp_short.fillna('-')

otpu_uncon_undel_ticks_comps_opp_de_short = pd.merge(otpu_uncon_undel_ticks_comps_opp_short,deleffdata_summary,on=['PARENTCODE','PARENTNAME'],how='outer')
otpu_uncon_undel_ticks_comps_opp_de_short = otpu_uncon_undel_ticks_comps_opp_de_short.fillna('-')

# otpu_uncon_undel_ticks_comps_opp_de = pd.merge(otpu_uncon_undel_ticks_comps_opp,deleffdata_summary,on=['PARENTCODE','PARENTNAME'],how='outer')
# otpu_uncon_undel_ticks_comps_opp_de = otpu_uncon_undel_ticks_comps_opp_de.fillna('-')

# otpu_uncon_undel_ticks_comps_opp_de_short = pd.merge(otpu_uncon_undel_ticks_comps_opp_de,shortdata_summary,on=['PARENTCODE','PARENTNAME'],how='outer')
# otpu_uncon_undel_ticks_comps_opp_de_short = otpu_uncon_undel_ticks_comps_opp_de_short.fillna('-')



# In[ ]:

otpu_unconn_area = pd.merge(crmpkpdata_pivot_area,unconnected_final_area,on=['Region','Area'],how='outer')
otpu_unconn_area = otpu_unconn_area.fillna('-')

otpu_uncon_undel_area = pd.merge(otpu_unconn_area,undeldata_pivot_area,on=['Region','Area'],how='outer')
otpu_uncon_undel_area = otpu_uncon_undel_area.fillna('-')

otpu_uncon_undel_opp_area = pd.merge(otpu_uncon_undel_area,oppsumdata_summary_area,on=['Region','Area'],how='outer')
otpu_uncon_undel_opp_area = otpu_uncon_undel_opp_area.fillna('-')

otpu_uncon_undel_opp_de_area = pd.merge(otpu_uncon_undel_opp_area,deleffdata_summary_area,on=['Region','Area'],how='outer')
otpu_uncon_undel_opp_de_area = otpu_uncon_undel_opp_de_area.fillna('-')

otpu_uncon_undel_opp_de_short_area = pd.merge(otpu_uncon_undel_opp_de_area,shortdata_summary_area,on=['Region','Area'],how='outer')
otpu_uncon_undel_opp_de_short_area = otpu_uncon_undel_opp_de_short_area.fillna('-')


#otpu_uncon_undel_opp_de_short_area.to_csv(r'otpu_uncon_undel_opp_de_short_area.csv')

# In[ ]:

finalsummary_total = otpu_uncon_undel_ticks_comps_opp_de_short[otpu_uncon_undel_ticks_comps_opp_de_short['PARENTNAME']=='Total']

finalsummary_total.loc[finalsummary_total.index,'Date'] = todayminus1

finalsummary_total = pd.DataFrame(finalsummary_total,columns=['PARENTCODE','PARENTNAME','Onetime_Internal_Missed_PU%','Onetime_Missed_PU%','TOTAL_Onetime_PU','UNCONNECTED_CCF>24Hrs','UNCONNECTED_STF>24Hrs','UNDEL_CCF_>24HRS','UNDEL_CCF_>48HRS','UNDEL_CCF_>72HRS','UNDEL_STF_>24HRS','UNDEL_STF_>48HRS','UNDEL_STF_>72HRS','SHORT_vs_PENDING_RESOLUTION>72Hrs','SHORT_vs_PENDING_RESOLUTION>120Hrs','PENDING_TICKETS_>24HRS','PENDING_TICKETS_>48HRS','PENDING_TICKETS_>72HRS','PENDING_COMPLAINTS_>24HRS','PENDING_COMPLAINTS_>48HRS','PENDING_COMPLAINTS_>72HRS','Total_Complaints','REACH%','OPP%','CEM%','TOTAL_DUEDATE_CONS','Delivery_Efficiency%','Date'])


# In[ ]:

finalsummary_total_area = otpu_uncon_undel_opp_de_short_area[otpu_uncon_undel_opp_de_short_area['Area']=='Total']
#finalsummary_total_area.loc[finalsummary_total_area.index,'Date'] = todayminus1

#otpu_uncon_undel_opp_de_short_area.to_csv(r'otpu_uncon_undel_opp_de_short_area_1.csv')
# In[ ]:

finalsummary_total_t = finalsummary_total.T.reset_index()
#finalsummary_total_t.to_csv(r'finalsummary_total_t.csv')
finalsummary_total_t = finalsummary_total_t.rename(columns={'index':'Parameters',finalsummary_total_t.columns[1]:todayminus1})
excludelist = ['000000000','Total',todayminus1]
finalsummary_total_t = finalsummary_total_t[~(finalsummary_total_t[todayminus1].isin(excludelist))]

finalsummary_total_t = finalsummary_total_t[(finalsummary_total_t['Parameters']!='TOTAL_UNCONNECTED_CONS')]


# In[ ]:

otpu_uncon_undel_ticks_comps_opp_de_short = otpu_uncon_undel_ticks_comps_opp_de_short[otpu_uncon_undel_ticks_comps_opp_de_short['PARENTNAME']!='Total']


# In[ ]:

otpu_uncon_undel_opp_de_short_area = otpu_uncon_undel_opp_de_short_area[otpu_uncon_undel_opp_de_short_area['Area']!='Total']
#otpu_uncon_undel_opp_de_short_area.to_csv(r'otpu_uncon_undel_opp_de_short_area_2.csv')

# In[ ]:

#finalsummary = finalsummary_total.append(otpu_uncon_undel_ticks_comps_opp_de_short,ignore_index=True)
finalsummary = finalsummary_total.append(otpu_uncon_undel_ticks_comps_opp_de_short)


# In[ ]:

finalsummary_area = finalsummary_total_area.append(otpu_uncon_undel_opp_de_short_area)

#finalsummary_area.to_csv(r'finalsummary_area.csv')

# In[ ]:

finalsummary.loc[finalsummary.index,'Date'] = todayminus1


# In[ ]:

#finalsummary_area.loc[finalsummary_area.index,'Date'] = todayminus1

#finalsummary_area.to_csv(r'finalsummary_area_1.csv')


# In[ ]:

finalsummary = pd.DataFrame(finalsummary,columns=['PARENTCODE','PARENTNAME','Onetime_Internal_Missed_PU%','Onetime_Missed_PU%','TOTAL_Onetime_PU','UNCONNECTED_CCF>24Hrs','UNCONNECTED_STF>24Hrs','UNDEL_CCF_>24HRS','UNDEL_CCF_>48HRS','UNDEL_CCF_>72HRS','UNDEL_STF_>24HRS','UNDEL_STF_>48HRS','UNDEL_STF_>72HRS','SHORT_vs_PENDING_RESOLUTION>72Hrs','SHORT_vs_PENDING_RESOLUTION>120Hrs','PENDING_TICKETS_>24HRS','PENDING_TICKETS_>48HRS','PENDING_TICKETS_>72HRS','PENDING_COMPLAINTS_>24HRS','PENDING_COMPLAINTS_>48HRS','PENDING_COMPLAINTS_>72HRS','Total_Complaints','REACH%','OPP%','CEM%','TOTAL_DUEDATE_CONS','Delivery_Efficiency%','Date'])


# In[ ]:

#finalsummary_area = pd.DataFrame(finalsummary_area,columns=['Region','Area','Onetime_Internal_Missed_PU%','Onetime_Missed_PU%','TOTAL_Onetime_PU','UNCONNECTED_CCF>24Hrs','UNCONNECTED_STF>24Hrs','UNDEL_CCF_>24HRS','UNDEL_CCF_>48HRS','UNDEL_CCF_>72HRS','UNDEL_CCF_>24HRS','UNDEL_STF_>48HRS','UNDEL_STF_>72HRS','SHORT_vs_PENDING_RESOLUTION>72Hrs','SHORT_vs_PENDING_RESOLUTION>120Hrs','REACH%','OPP%','CEM%','TOTAL_DUEDATE_CONS','Delivery_Efficiency%','Date'])
finalsummary_area = pd.DataFrame(finalsummary_area,columns=['Region','Area','Onetime_Internal_Missed_PU%','Onetime_Missed_PU%','TOTAL_Onetime_PU','UNCONNECTED_CCF>24Hrs','UNCONNECTED_STF>24Hrs','UNDEL_CCF_>24HRS','UNDEL_CCF_>48HRS','UNDEL_CCF_>72HRS','UNDEL_STF_>24HRS','UNDEL_STF_>48HRS','UNDEL_STF_>72HRS','SHORT_vs_PENDING_RESOLUTION>72Hrs','SHORT_vs_PENDING_RESOLUTION>120Hrs','REACH%','OPP%','CEM%','TOTAL_DUEDATE_CONS','Delivery_Efficiency%'])


# In[ ]:

finalsummary_total_t.to_csv(r'D:\Data\Risk_Customer_Report\Management_summary\Management_Summary_'+str(todayminus1)+'.csv',index=False)

#summary1day = pd.read_csv(r'finalsummary_total_t_'+str(todayminus1)+'.csv')

#summary1dayminus = pd.read_excel(r'D:\Data\Risk_Customer_Report\Complete_summary\Risk_Customer_Report_'+str(todayminus1)+'.xlsx','Management_Summary')
#summary2dayminus = pd.read_csv(r'D:\Data\Risk_Customer_Report\Management_summary\Management_Summary_'+str(todayminus2)+'.csv')
#summary3dayminus = pd.read_csv(r'D:\Data\Risk_Customer_Report\Management_summary\Management_Summary_'+str(todayminus3)+'.csv')
#summary4dayminus = pd.read_csv(r'D:\Data\Risk_Customer_Report\Management_summary\Management_Summary_'+str(todayminus4)+'.csv')

mgmtlist = [pd.read_csv(filename) for filename in glob.glob("D:\Data\Risk_Customer_Report\Management_summary\*.csv")]
mgmt_summary = reduce(lambda left,right: pd.merge(left,right,on='Parameters',how='outer'), mgmtlist)

#last2days_summary = pd.merge(finalsummary_total_t,summary2dayminus,on=['Parameters'],how='outer')
#last3days_summary = pd.merge(last2days_summary,summary3dayminus,on=['Parameters'],how='outer')
#last4days_summary = pd.merge(last3days_summary,summary4dayminus,on=['Parameters'],how='outer')

#cols = [c for c in last3days_summary.columns if c()[:7] != 'Unnamed']
#last3days_summary = last3days_summary[cols]

#last3days_summary.drop('reports', axis=1)


with ExcelWriter(r'D:\Data\Risk_Customer_Report\Complete_summary\Risk_Customer_Report_'+str(todayminus1)+'.xlsx') as writer:
    #pendingcomps_cat_total.to_excel(writer, sheet_name='Category_Complaints',engine='xlsxwriter')
    mgmt_summary.to_excel(writer, sheet_name='Management_Summary',engine='xlsxwriter')
    finalsummary.to_excel(writer, sheet_name='Customerwise_Summary',engine='xlsxwriter')
    finalsummary_area.to_excel(writer, sheet_name='Area_Summary',engine='xlsxwriter')
    crmpkpdata.to_excel(writer, sheet_name='Pickups',engine='xlsxwriter')
    unconctdata.to_excel(writer, sheet_name='Unconnected',engine='xlsxwriter')
    undeldata.to_excel(writer, sheet_name='Undel',engine='xlsxwriter')
    pendingticksdata.to_excel(writer, sheet_name='Tickets',engine='xlsxwriter')
    pendingcompsdata.to_excel(writer, sheet_name='Complaints',engine='xlsxwriter')
    pendingcomps_cat_total.to_excel(writer, sheet_name='Complaints_category',engine='xlsxwriter')
    oppsumdata.to_excel(writer, sheet_name='Reach',engine='xlsxwriter')
    deleffdata.to_excel(writer, sheet_name='Delivery efficiency',engine='xlsxwriter')
    shortdata_greater72.to_excel(writer, sheet_name='Short_data',engine='xlsxwriter')


oppath_riskcust = r'D:\Data\Risk_Customer_Report\Complete_summary\Risk_Customer_Report_'+str(todayminus1)+'.xlsx'
# In[ ]:
filePath = oppath_riskcust
def sendEmail(TO = ["spot_cstl@spoton.co.in","sq_spot@spoton.co.in","rsm_spot@spoton.co.in","dsm_spot@spoton.co.in","aom_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in","hubmgr_spot@spoton.co.in"],
             #TO = ["vishwas.j@spoton.co.in"],
             #CC = ["vishwas.j@spoton.co.in"],
             BCC = ["mahesh.reddy@spoton.co.in"],
             CC = ["abhik.mitra@spoton.co.in","rajesh.kumar@spoton.co.in","sharmistha.majumdar@spoton.co.in","uday.sharma@spoton.co.in"],
    FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "Risk Customer Report" + " - " + str(todayminus1)
    body_text = """
    Hi All,
    
    PFA the Risk customer report for """+str(todayminus1)+"""
    
    This is the report designed to get a daily view of Risk Customers cons that has not met the expected service and leads to an escalation if not acted immediately. 
    OPS and CS is expected to look at their respective part of the jobs and resolve the same on the same day itself. 
    
    Below are the legends for the different sheets in the attachment
    
    Management_Summary : This will contain the trend of all the parameters daywise
    Customerwise_Summary : This is the customerwise summary for yesterday
    Area_Summary : This sheet contains areawise summary for yesterday
    Pickups : Data for Onetime standard pickups
    Unconnected : Conwise data of unconnected cons
    Undel : Conwise data of undelivered cons
    Tickets : Pending tickets data
    Complaints : Pending complaints data
    Reach : Reach, OPP and CEM data for each branch for each customer
    Delivery efficiency : Delivery efficiency data for each branch for each customer
    Short_data : Short updated and resultion pending cases conwise details
    

    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')


