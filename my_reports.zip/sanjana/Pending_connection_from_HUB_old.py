
# coding: utf-8

# In[ ]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta
import sys

reload(sys).setdefaultencoding("ISO-8859-1")


# In[ ]:


cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")


# In[ ]:


cursor=cnxn.cursor()


# In[ ]:


query=(""" SELECT --TOP 20
                    A.DOCKNO ,
                    A.CDELDT ,
                    A.DC ,
                    DACCC ,
                    A.VTC ,
                    A.FTC ,
                    BOOKING_REGION ,
                    ACTUAL_WEIGHT ,
                    PKGSNO ,
                    A.VOLUME ,
                    ORIGIN_BRCODE ,
                    ORIGIN_BRNAME ,
                    orgareaname ,
                    A.DEFAULTHUB ORIGINHUB ,
                    ORGLOCTYPE ,
                    DESTCD ,
                    destareaname ,
                    DESTHUB ,
                    DESTLOCTYPE ,
                    PINCODE ,
                    DOCKDT ,
                    CURR_AREA ,
                    CURR_BRANCHCODE ,
                    CURR_BRANCHNAME ,
                    C.RGALPH CURR_REGION ,
                    ARRV_AT_CURR_LOCATION ,
                    HOURS_LYING_AT_CURR_LOCATION ,
                    ISDEPARTED_FRM_CURRLOC ,
                    A.CurLocConStatusCategory, 
                    A.CurLocConStatusCode, 
                    A.CurLocConStatusDesc, 
                    A.CurLocConStatusReason, 
                    A.CurLocConStatusDate ,
                    A.LatestConStatusCategory ,
                    A.LatestConStatusCode ,
                    A.LatestConStatusDesc ,
                    A.LatestConStatusReason ,
                    A.LatestConStatusDate ,
                    A.CSGNCD ,
                    REPLACE(A.CSGNNM,'"','') CSGNNM,
                    A.CSGECD ,
                    REPLACE(A.CSGENM,'"','') CSGENM ,
                    TIME_STAMP ,
                    CSAgentEmpCode ,
                    D.EMPNM ,
                    DATEDIFF(DAY, A.ARRV_AT_CURR_LOCATION, A.TIME_STAMP) CON_LYING_CURRR_LOCATION ,
                    CASE WHEN A.ISDEPARTED_FRM_CURRLOC = 'NO'
                         THEN CAST(DATEDIFF(HOUR, A.ARRV_AT_CURR_LOCATION,
                                            GETDATE()) AS VARCHAR)
                         ELSE '-'
                    END [COOLING HOURS] ,
                    CASE WHEN A.ISDEPARTED_FRM_CURRLOC = 'NO'
                              AND DATEDIFF(HOUR, A.ARRV_AT_CURR_LOCATION,
                                           GETDATE()) <= 24 THEN '1 DAY'
                         WHEN A.ISDEPARTED_FRM_CURRLOC = 'NO'
                              AND DATEDIFF(HOUR, A.ARRV_AT_CURR_LOCATION,
                                           GETDATE()) > 24
                              AND DATEDIFF(HOUR, A.ARRV_AT_CURR_LOCATION,
                                           GETDATE()) <= 48
                         THEN '2 DAY'
                         WHEN A.ISDEPARTED_FRM_CURRLOC = 'NO'
                              AND DATEDIFF(HOUR, A.ARRV_AT_CURR_LOCATION,
                                           GETDATE()) > 48
                              AND DATEDIFF(HOUR, A.ARRV_AT_CURR_LOCATION,
                                           GETDATE()) <= 72
                         THEN '3 DAY'
                         WHEN A.ISDEPARTED_FRM_CURRLOC = 'NO'
                              AND DATEDIFF(HOUR, A.ARRV_AT_CURR_LOCATION,
                                           GETDATE()) > 72
                              AND DATEDIFF(HOUR, A.ARRV_AT_CURR_LOCATION,
                                           GETDATE()) <= 96
                         THEN '4 DAY'
                         WHEN A.ISDEPARTED_FRM_CURRLOC = 'NO'
                              AND DATEDIFF(HOUR, A.ARRV_AT_CURR_LOCATION,
                                           GETDATE()) > 96 THEN '> 4 DAY'
                         ELSE '-'
                    END [COOLING BUCKET] ,
                    CASE WHEN ( A.CURR_BRANCHCODE = A.DESTCD ) THEN 'DESTN'
                         WHEN ( A.CURR_BRANCHCODE = A.ORIGIN_BRCODE )
                         THEN 'ORIGIN'
                         WHEN ( C.HUBCENTER = 'Y' ) THEN 'HUB'
                         ELSE 'IN-TRANSIT'
                    END LOCATION  
          FROM      dbo.tblTimeConnectionReport_Undelivered_2Hrs A
          INNER JOIN dbo.brms C WITH ( NOLOCK ) ON A.CURR_BRANCHCODE = C.BRCD
          INNER JOIN dbo.EMPMST D WITH ( NOLOCK ) ON A.CSAgentEmpCode = D.EMPCD
          WHERE     A.ISDEPARTED_FRM_CURRLOC = 'NO'
            AND A.CURR_BRANCHCODE != A.DESTCD  """ )


# In[ ]:


data=pd.read_sql(query,cnxn)


# In[ ]:


data = data[data['LOCATION']=='HUB']


# In[ ]:


data = data[~data['CurLocConStatusCategory'].isin(['SENDER FAILURE','RECEIVER FAILURE'])]


# In[ ]:


data = data[data['CurLocConStatusCode'].isin(['DIR','EIR','SIR','PIR'])]


# In[ ]:


final_list=['Paper Works Received Without Shipment',
'Held in Hub Due to Paperwork Missing',
'Shipment Label or boxes Criss - Crossed',
'Held in Checkpost due to missing or incorrect paperwork',
'Shipment Received without Paper Works']


# In[ ]:


data=data[~data['CurLocConStatusDesc'].isin(final_list)]


# In[ ]:


top11 = data[data['CURR_BRANCHCODE'].isin(['BLRH','CCUH','AMDH','DELH','AMCH','BOMH','PNQH','HYDH','MAAH','NAGH','BRGH'])]


# In[ ]:


pivot11=pd.pivot_table(top11,index=["CURR_BRANCHCODE"],columns=["COOLING BUCKET"],values=["DOCKNO"],aggfunc={"DOCKNO":len},fill_value='0',margins=True)


# In[ ]:


pivot11=pivot11.sort_values([('DOCKNO', 'All')], ascending=False).astype(int)


# In[ ]:


top_remains = data[~data['CURR_BRANCHCODE'].isin(['BLRH','CCUH','AMDH','DELH','AMCH','BOMH','PNQH','HYDH','MAAH','NAGH','BRGH'])]


# In[ ]:


pivot_remains=pd.pivot_table(top_remains,index=["CURR_BRANCHCODE"],columns=["COOLING BUCKET"],values=["DOCKNO"],aggfunc={"DOCKNO":len},fill_value='',margins=True)


# In[ ]:


from pandas import ExcelWriter


# In[ ]:


with ExcelWriter(r'D:\Data\ODA_Loads_Ton_wise\Pen_HUB_cnctn.xlsx') as writer:
    pivot11.to_excel(writer, sheet_name='top11hubs',engine='xlsxwriter')
    pivot_remains.to_excel(writer, sheet_name='pivot',engine='xlsxwriter')
    data.to_excel(writer,sheet_name='data',engine='xlsxwriter')
    


# In[ ]:


filepath= r'D:\Data\ODA_Loads_Ton_wise\Pen_HUB_cnctn.xlsx'


# In[ ]:


import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback

oppath1=filepath
#FTP Upload starts
print ('Logging in...')
ftp = ftplib.FTP()  
ftp.connect('10.109.230.50')  
print (ftp.getwelcome())
try:  
    try:  
        ftp.login('HOSQTeam', 'Te@mH0$q')
        print ('login done')
        ftp.cwd('Auto_reports')  
        #ftp.cwd('FIFO')
        # move to the desired upload directory  
        print ("Currently in:", ftp.pwd()) 
        print ('Uploading...')  
        fullname = oppath1
        name = os.path.split(fullname)[1]  
        print ('os path ok')
        f = open(fullname, "rb")  
        ftp.storbinary('STOR ' + name, f)  
        f.close()  
        print ("OK"  )
        print ("Files:")  
        print (ftp.retrlines('LIST'))
    finally:  
        print ("Quitting...")
        ftp.quit()  
except:  
    traceback.print_exc()


# In[ ]:


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.MIMEBase import MIMEBase
from email import Encoders
import os

from_addr = 'mis.ho@spoton.co.in'
# to_addr = ['rajesh.mp@spoton.co.in']
# to_addr = ['sreedhar.m@spoton.co.in','sharanagouda.biradar@spoton.co.in']
# cc_addr = ['imrajeshm@gmail.com']
cc_addr = ['shivananda.p@spoton.co.in','abhik.mitra@spoton.co.in','jothi.menon@spoton.co.in','pawan.sharma@spoton.co.in','rajesh.kumar@spoton.co.in','prasanna.hegde@spoton.co.in','vijay.adhale@spoton.co.in','rajesh.ebnath@spoton.co.in','sharanagouda.biradar@spoton.co.in']
bcc_addr = ['rajesh.mp@spoton.co.in','HUBMGR_SPOT@spoton.co.in','Omkar.Chorge@spoton.co.in','ramachandran.p@spoton.co.in','sureshbabu.y@spoton.co.in','surendra.pandey@spoton.co.in','sopanrao.bhoite@spoton.co.in','samarajeet.dubey@spoton.co.in','satyaprakash.vishwakarma@spoton.co.in','lingaraj.chidambaram@spoton.co.in','Sukesh.Mishra@spoton.co.in','narendra.londhe@spoton.co.in','ramniwas.sharma@spoton.co.in','jaisingh.chauhan@spoton.co.in','AOM_SPOT@spoton.co.in','rom_spot@spoton.co.in','dom_spot@spoton.co.in','venkata.satyanand@spoton.co.in','m.rama.krishna@spoton.co.in','Rajnish.pathak@spoton.co.in','vijay.dubey@spoton.co.in','scincharge_spot@spoton.co.in']
# bcc_addr=['mahesh.reddy@spoton.co.in']
username = 'mis.ho@spoton.co.in'
password = 'Mis@2019'

msg = MIMEMultipart()

msg['From'] = from_addr
# msg['To'] = ', '.join(to_addr)
msg['bcc'] = ', '.join(bcc_addr)
msg['cc'] = ', '.join(cc_addr)
msg['Subject'] = 'Pending connection from Hub'
html='''<html>
<h4>Dear All Hub Coll's, </h4>
<p> Pls find the below Hub wise pending connection summary details as on today </p>
<p> Please do not hold any shipments for internal issue. Please make sure to connect all pending shipments today itself & clear the backlog.</p>
</html>'''

html1='''<h5>Pl Note : Below these numbers are excluding Receiver Failure, Sender Failure & DEPS.</h5></b>
<h5>HO-SQ</h5>'''

# part10=MIMEText(html1,'html')
#  <h5>Rajesh M P </h5></b>
# msg.attach(part10)
html3='''
<h5> To download the Details of "Pending connection from HUB", Please click the link below </h5>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Pen_HUB_cnctn.xlsx"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Pen_HUB_cnctn.xlsx</p></b>
'''

html5='''
<h4> Top11 Hub-pending connection shipments</h4>
'''
html6='''
<h4> Other Hub-pending connection shipments</h4>
'''


html4='''<h5>Thanks & Regards</h5></b>
<h5>HO-SQ</h5>'''

report=""
report+=html
report+=html1
report+=html3
report+=html5
# report+='<br>'
report+='<br>'+pivot11.to_html()+'<br>'
# report+='<br>'
report+=html6
# report+='<br>'
report+='<br>'+pivot_remains.to_html()+'<br>'
report+=html4
report+='<br>'
abc=MIMEText(report,'html')
msg.attach(abc)

server = smtplib.SMTP('smtp.spoton.co.in',587)
part=MIMEBase('application','octet-stream')
# for attachment insted of link
# part.set_payload(open(filepath,'rb').read())
# Encoders.encode_base64(part)
# part.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath))
# msg.attach(part)

server.ehlo()
server.starttls()
server.ehlo()
# server.login('mis.ho@spoton.co.in','Mis@2019')
# server.sendmail(from_addr,cc_addr+bcc_addr,msg.as_string())
print ('mail sent succesfully')
server.quit()

