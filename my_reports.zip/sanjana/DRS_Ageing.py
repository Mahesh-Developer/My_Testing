
# coding: utf-8

# In[1]:


import pandas as pd
from datetime import datetime, timedelta
import numpy as np
from sqlalchemy import *
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import sys

reload(sys).setdefaultencoding("ISO-8859-1")


# In[2]:


query=("""EXEC USP_CLOSINGSTOCK_REPORT_1HR_IE""")
cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
cursor = cnxn.cursor()


# In[3]:


#df=pd.read_excel(r'http://spoton.co.in/downloads/OCID_CLOSINGSTOCK_1HR/OCID_CLOSINGSTOCK_1HR.xls')
df=pd.read_sql(query,cnxn)


# In[4]:


len(df)


# In[5]:


df.columns


# In[6]:


def getDates(drsdate):
    return drsdate.date()


# In[7]:


df['Date']=df.apply(lambda x: getDates(x['LASTDRS_PREPAREDDATE']),axis=1)


# In[8]:


len(df)


# In[9]:


datetime.today().date()


# In[10]:


fil_df=df[df['Date']!=datetime.today().date()]


# In[11]:


len(fil_df)


# In[12]:


fil_df['Diff_Hrs']=pd.np.round((fil_df['TimestateDate']-fil_df['LASTDRS_PREPAREDDATE'])/np.timedelta64(1,'h'),1)


# In[13]:


std_fil_df=fil_df[fil_df['DEL_LOCATION_TYPE']=='STD']
oda_fil_df=fil_df[fil_df['DEL_LOCATION_TYPE']=='ODA']


# In[14]:


print (len(std_fil_df),len(oda_fil_df))


# In[15]:


std_pivot_df=pd.pivot_table(std_fil_df,index=['DEST_DEPOT'],aggfunc={'Diff_Hrs':np.sum,'DOCKNO':len})


# In[16]:


std_pivot_df['Avg']=pd.np.round(std_pivot_df['Diff_Hrs']/std_pivot_df['DOCKNO'],1)


# In[17]:


std_pivot_df


# In[18]:


oda_pivot_df=pd.pivot_table(oda_fil_df,index=['DEST_DEPOT'],aggfunc={'Diff_Hrs':np.sum,'DOCKNO':len})


# In[19]:


oda_pivot_df['Avg']=pd.np.round(oda_pivot_df['Diff_Hrs']/oda_pivot_df['DOCKNO'],1)


# In[20]:


oda_pivot_df


# In[21]:

from datetime import date,timedelta
yes=datetime.strftime(date.today(),'%Y-%m-%d')

from pandas import ExcelWriter
with ExcelWriter(r'D:\Data\DRS Reports\DRS_Ageing_'+str(yes)+'.xlsx') as writer:
    df.to_excel(writer,engine='xlsxwriter',sheet_name='Data')
    std_pivot_df.to_excel(writer,engine='xlsxwriter',sheet_name='STD Summary')
    oda_pivot_df.to_excel(writer,engine='xlsxwriter',sheet_name='ODA Summary')


# In[22]:


filePath1=r'D:\Data\DRS Reports\DRS_Ageing_'+str(yes)+'.xlsx'


# In[24]:




# In[25]:


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

TO=['shivananda.p@spoton.co.in']

FROM='mis.ho@spoton.co.in'
CC=['mahesh.reddy@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "DRS Ageing Summary as of " + " - " + str(yes)
html='''<html>
<h4>Dear All,</h4>
<h3>DRS Ageing Summary for STD</h3>
</html>'''
html3='''
<h3>DRS Ageing Summary for ODA</h3>
'''
s = Template(html).safe_substitute(date=yes)
report=""
report+=s
report+='<br>'+std_pivot_df.to_html()+'<br>'
report+='<br>'
report+=html3
report+='<br>'+oda_pivot_df.to_html()+'<br>'
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filePath1,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath1))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()

