# -*- coding: utf-8 -*-
"""
Created on Wed Mar 23 16:24:04 2016

@author: rajeeshv
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
import calendar
import datetime
from pandas import ExcelWriter

yestdaypickups = pd.read_csv(r'http://10.109.230.50/downloads/IEProjects/YDCD/YDCD.csv')

datenow = date.today()
dateyest = datenow-timedelta(hours=24)

yestdaypickups.to_csv(r'D:\Data\Pickups_yesterday\Pickup_cons_'+str(dateyest)+'.csv',encoding='utf-8')
print 'Yesterday pickups saving done'