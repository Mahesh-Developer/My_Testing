
# coding: utf-8

# In[1]:

import pandas as pd
import numpy as np
import datetime
#from datetime import datetime
from datetime import timedelta
from pandas import ExcelWriter
import sys
from email import encoders
#reload(sys)
#sys.setdefaultencoding("UTF8")
import traceback
import ftplib
import os

import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText


# In[2]:

##leadbasedata = pd.read_csv(r'C:\Data\Customer_lead_management\PIPELINE_LEAD_REPORT.csv')
leadbasedata = pd.read_csv(r'https://spoton.co.in/downloads/PIPELINE_LEAD_REPORT/PIPELINE_LEAD_REPORT.csv')


# In[3]:

leadbasedata = leadbasedata.rename(columns={'\xef\xbb\xbfLeadid':'Leadid'})


# In[4]:

leaddata = leadbasedata.drop_duplicates(cols = 'Leadid')


# In[5]:

leaddataactive = leaddata[leaddata['LeadStatus']=='Active']
leaddatainactive = leaddata[leaddata['LeadStatus']=='Inactive']


# ### 6 MONTH SUMMARY

# In[6]:

##$$leaddataactivesummary = leaddataactive.groupby(['SaleRegion','LastStatusCode','LastStatusDesc']).agg({'Leadid':len,'PotentialRevenueInLakhs':sum}).reset_index()
leaddataactivesummary_pivot = pd.pivot_table(leaddataactive,index=['SaleRegion','LastStatusCode','LastStatusDesc'],values=['Leadid','PotentialRevenueInLakhs'],aggfunc={'Leadid':len,'PotentialRevenueInLakhs':sum}).reset_index()
leaddataactivesummary_pivot_all = pd.pivot_table(leaddataactive,index=['LastStatusCode','LastStatusDesc'],values=['Leadid','PotentialRevenueInLakhs'],aggfunc={'Leadid':len,'PotentialRevenueInLakhs':sum}).reset_index()
leaddataactivesummary = leaddataactivesummary_pivot.append(leaddataactivesummary_pivot_all,ignore_index=True)
leaddataactivesummary.SaleRegion.fillna('PAN_INDIA',inplace=True)

columns6msum = ['SaleRegion','LastStatusCode','LastStatusDesc','Leadid','PotentialRevenueInLakhs']
leaddataactivesummary = pd.DataFrame(leaddataactivesummary,columns=columns6msum)


# ### 6 MONTH AGEING REPORT

# In[7]:

leaddataactivetills4 = leaddataactive[leaddataactive['LastStatusCode']!='S5']
#leaddataactiveageing = pd.pivot_table(leaddataactivetills4,index=['SaleRegion','SalesPersonName'],columns=['LastStatusCode'],values=['DaysSinceLastStatusDate'],aggfunc=np.mean).reset_index()
#leaddataactiveageing = leaddataactiveageing.fillna(0)
leaddataactiveageing = leaddataactivetills4.groupby(['SaleRegion','SalesPersonName','LastStatusCode','LastStatusDesc']).agg({'DaysSinceLastStatusDate':np.mean}).reset_index()
leaddataactiveageing['DaysSinceLastStatusDate_Avg'] = np.round(leaddataactiveageing.apply(lambda x:x['DaysSinceLastStatusDate'],axis=1),0)
leaddataactiveageing = leaddataactiveageing.drop(['DaysSinceLastStatusDate'],axis=1)


# ### GETTING MONTH NUMBER

# In[8]:

now = datetime.datetime.now()
yestday = now-timedelta(hours=24)
yestdate = yestday.date()
yestdaymonth = yestday.month


# ### CURRENT MONTH SUMMARY (ACTIVE LEADS)

# In[9]:

leaddatacurmonth = leaddataactive[leaddataactive['LeadCreationMonth']==yestdaymonth]
##$$leaddataactivecurmonthsum = leaddatacurmonth.groupby(['LastStatusCode']).agg({'Leadid':len,'PotentialRevenueInLakhs':sum}).reset_index()
leaddataactivecurmonthsum_pivot = pd.pivot_table(leaddatacurmonth,index=['SaleRegion','LastStatusCode','LastStatusDesc'],values=['Leadid','PotentialRevenueInLakhs'],aggfunc={'Leadid':len,'PotentialRevenueInLakhs':np.sum}).reset_index()
leaddataactivecurmonthsum_pivot_all = pd.pivot_table(leaddatacurmonth,index=['LastStatusCode','LastStatusDesc'],values=['Leadid','PotentialRevenueInLakhs'],aggfunc={'Leadid':len,'PotentialRevenueInLakhs':np.sum}).reset_index()
leaddataactivecurmonthsum = leaddataactivecurmonthsum_pivot.append(leaddataactivecurmonthsum_pivot_all,ignore_index=True)
leaddataactivecurmonthsum.SaleRegion.fillna('PAN_INDIA',inplace=True)

columnsmtdsum = ['SaleRegion','LastStatusCode','LastStatusDesc','Leadid','PotentialRevenueInLakhs']
leaddataactivecurmonthsum = pd.DataFrame(leaddataactivecurmonthsum,columns=columnsmtdsum)

leaddataactivecurmonthsum = leaddataactivecurmonthsum.rename(columns={'PotentialRevenueInLakhs':'Revenue(L)',})

leaddataactivecurmonthsumeast = leaddataactivecurmonthsum[leaddataactivecurmonthsum['SaleRegion']=='East']
eastleads = leaddataactivecurmonthsumeast['Leadid'].sum()
eastrev = leaddataactivecurmonthsumeast['Revenue(L)'].sum()
eastsumlist = ['East_Total','-','-',eastleads,eastrev]
eastcol_list = ['SaleRegion','LastStatusCode','LastStatusDesc','Leadid','Revenue(L)']
easttotals = pd.DataFrame(data=[eastsumlist], columns = eastcol_list)
leaddataactivecurmonthsumeast = leaddataactivecurmonthsumeast.append(easttotals,ignore_index=True)

leaddataactivecurmonthsumnorth = leaddataactivecurmonthsum[leaddataactivecurmonthsum['SaleRegion']=='North']
northleads = leaddataactivecurmonthsumnorth['Leadid'].sum()
northrev = leaddataactivecurmonthsumnorth['Revenue(L)'].sum()
northsumlist = ['North_Total','-','-',northleads,northrev]
northcol_list = ['SaleRegion','LastStatusCode','LastStatusDesc','Leadid','Revenue(L)']
northtotals = pd.DataFrame(data=[northsumlist], columns = northcol_list)
leaddataactivecurmonthsumnorth = leaddataactivecurmonthsumnorth.append(northtotals,ignore_index=True)

leaddataactivecurmonthsumsouth = leaddataactivecurmonthsum[leaddataactivecurmonthsum['SaleRegion']=='South']
southleads = leaddataactivecurmonthsumsouth['Leadid'].sum()
southrev = leaddataactivecurmonthsumsouth['Revenue(L)'].sum()
southsumlist = ['South_Total','-','-',southleads,southrev]
southcol_list = ['SaleRegion','LastStatusCode','LastStatusDesc','Leadid','Revenue(L)']
southtotals = pd.DataFrame(data=[southsumlist], columns = southcol_list)
leaddataactivecurmonthsumsouth = leaddataactivecurmonthsumsouth.append(southtotals,ignore_index=True)

leaddataactivecurmonthsumwest = leaddataactivecurmonthsum[leaddataactivecurmonthsum['SaleRegion']=='West']
westleads = leaddataactivecurmonthsumwest['Leadid'].sum()
westrev = leaddataactivecurmonthsumwest['Revenue(L)'].sum()
westsumlist = ['West_Total','-','-',westleads,westrev]
westcol_list = ['SaleRegion','LastStatusCode','LastStatusDesc','Leadid','Revenue(L)']
westtotals = pd.DataFrame(data=[westsumlist], columns = westcol_list)
leaddataactivecurmonthsumwest = leaddataactivecurmonthsumwest.append(westtotals,ignore_index=True)

leaddataactivecurmonthsumpanindia = leaddataactivecurmonthsum[leaddataactivecurmonthsum['SaleRegion']=='PAN_INDIA']
panindialeads = leaddataactivecurmonthsumpanindia['Leadid'].sum()
panindiarev = leaddataactivecurmonthsumpanindia['Revenue(L)'].sum()
panindiasumlist = ['PAN_INDIA_Total','-','-',panindialeads,panindiarev]
panindiacol_list = ['SaleRegion','LastStatusCode','LastStatusDesc','Leadid','Revenue(L)']
panindiatotals = pd.DataFrame(data=[panindiasumlist], columns = panindiacol_list)
leaddataactivecurmonthsumpanindia = leaddataactivecurmonthsumpanindia.append(panindiatotals,ignore_index=True)

leaddataactivecurmonthsumen = leaddataactivecurmonthsumeast.append(leaddataactivecurmonthsumnorth,ignore_index=True)
leaddataactivecurmonthsumens = leaddataactivecurmonthsumen.append(leaddataactivecurmonthsumsouth,ignore_index=True)
leaddataactivecurmonthsumensw = leaddataactivecurmonthsumens.append(leaddataactivecurmonthsumwest,ignore_index=True)
leaddataactivecurmonthsumenswtotal = leaddataactivecurmonthsumensw.append(leaddataactivecurmonthsumpanindia,ignore_index=True)
# ### INACTIVE LEADS

# In[10]:

leaddatacurmonthinactive = leaddatainactive[leaddatainactive['LeadCreationMonth']==yestdaymonth]
##$$leaddataactivecurmonthsum = leaddatacurmonth.groupby(['LastStatusCode']).agg({'Leadid':len,'PotentialRevenueInLakhs':sum}).reset_index()
leaddatainactivecurmonthsum_pivot = pd.pivot_table(leaddatacurmonthinactive,index=['SaleRegion','LastStatusCode','LastStatusDesc'],values=['Leadid','PotentialRevenueInLakhs'],aggfunc={'Leadid':len,'PotentialRevenueInLakhs':np.sum}).reset_index()
leaddatainactivecurmonthsum_pivot_all = pd.pivot_table(leaddatacurmonthinactive,index=['LastStatusCode','LastStatusDesc'],values=['Leadid','PotentialRevenueInLakhs'],aggfunc={'Leadid':len,'PotentialRevenueInLakhs':np.sum}).reset_index()
leaddatainactivecurmonthsum = leaddatainactivecurmonthsum_pivot.append(leaddatainactivecurmonthsum_pivot_all,ignore_index=True)
leaddatainactivecurmonthsum.SaleRegion.fillna('PAN_INDIA',inplace=True)

columnsmtdsum = ['SaleRegion','LastStatusCode','LastStatusDesc','Leadid','PotentialRevenueInLakhs']
leaddatainactivecurmonthsum = pd.DataFrame(leaddatainactivecurmonthsum,columns=columnsmtdsum)


# ### CURRENT MONTH NORTH & EAST SUMMARY

# In[11]:

# Current month North & East Account wise
regionlist = ['North','East']
leaddatacurmonth_NE = leaddatacurmonth[leaddatacurmonth['SaleRegion'].isin(regionlist)]
##$$leaddatacurmonth_NE_grp = leaddatacurmonth_NE.groupby(['Channel','SalesPersonName']).agg({'Leadid':len,'PotentialRevenueInLakhs':sum}).reset_index()
leaddatacurmonth_NE_pivot = pd.pivot_table(leaddatacurmonth_NE,index=['Channel','SalesPersonName'],values=['Leadid','PotentialRevenueInLakhs'],aggfunc={'Leadid':len,'PotentialRevenueInLakhs':sum}).reset_index()

leaddatacurmonth_NE_pivot_all = pd.pivot_table(leaddatacurmonth_NE,index=['Channel'],values=['Leadid','PotentialRevenueInLakhs'],aggfunc={'Leadid':len,'PotentialRevenueInLakhs':sum}).reset_index()
leaddatacurmonth_NE = leaddatacurmonth_NE_pivot.append(leaddatacurmonth_NE_pivot_all,ignore_index=True)
leaddatacurmonth_NE.SalesPersonName.fillna('PAN_INDIA',inplace=True)

columnsmtdne = ['SalesPersonName','Channel','Leadid','PotentialRevenueInLakhs']
leaddatacurmonth_NE = pd.DataFrame(leaddatacurmonth_NE,columns=columnsmtdne)


# ### CURRENT MONTH SOUTH SUMMARY

# In[12]:

leaddatacurmonth_South = leaddatacurmonth[leaddatacurmonth['SaleRegion']=='South']
##$$leaddatacurmonth_South_grp = leaddatacurmonth_South.groupby(['Channel','SalesPersonName']).agg({'Leadid':len,'PotentialRevenueInLakhs':sum}).reset_index()
leaddatacurmonth_South_pivot = pd.pivot_table(leaddatacurmonth_South,index=['Channel','SalesPersonName'],values=['Leadid','PotentialRevenueInLakhs'],aggfunc={'Leadid':len,'PotentialRevenueInLakhs':sum}).reset_index()

leaddatacurmonth_South_pivot_all = pd.pivot_table(leaddatacurmonth_South,index=['Channel'],values=['Leadid','PotentialRevenueInLakhs'],aggfunc={'Leadid':len,'PotentialRevenueInLakhs':sum}).reset_index()
leaddatacurmonth_South = leaddatacurmonth_South_pivot.append(leaddatacurmonth_South_pivot_all,ignore_index=True)
leaddatacurmonth_South.SalesPersonName.fillna('PAN_INDIA',inplace=True)

columnsmtdsouth = ['SalesPersonName','Channel','Leadid','PotentialRevenueInLakhs']
leaddatacurmonth_South = pd.DataFrame(leaddatacurmonth_South,columns=columnsmtdsouth)


# ### CURRENT MONTH WEST SUMMARY

# In[13]:

leaddatacurmonth_West = leaddatacurmonth[leaddatacurmonth['SaleRegion']=='West']
##$$leaddatacurmonth_West_grp = leaddatacurmonth_West.groupby(['Channel','SalesPersonName']).agg({'Leadid':len,'PotentialRevenueInLakhs':sum}).reset_index()
leaddatacurmonth_West_pivot = pd.pivot_table(leaddatacurmonth_West,index=['Channel','SalesPersonName'],values=['Leadid','PotentialRevenueInLakhs'],aggfunc={'Leadid':len,'PotentialRevenueInLakhs':sum}).reset_index()

leaddatacurmonth_West_pivot_all = pd.pivot_table(leaddatacurmonth_West,index=['Channel'],values=['Leadid','PotentialRevenueInLakhs'],aggfunc={'Leadid':len,'PotentialRevenueInLakhs':sum}).reset_index()
leaddatacurmonth_West = leaddatacurmonth_West_pivot.append(leaddatacurmonth_West_pivot_all,ignore_index=True)
leaddatacurmonth_West.SalesPersonName.fillna('PAN_INDIA',inplace=True)

columnsmtdwest = ['SalesPersonName','Channel','Leadid','PotentialRevenueInLakhs']
leaddatacurmonth_West = pd.DataFrame(leaddatacurmonth_West,columns=columnsmtdwest)


# ### 6 MONTHS CHANNELWISE SUMMARY

# In[14]:

channelwisesummarygrp = leaddataactive.groupby(['SaleRegion','Channel','LastStatusCode','LastStatusDesc']).agg({'Leadid':len,'PotentialRevenueInLakhs':sum}).reset_index()

channelwisesummary_all = pd.pivot_table(leaddataactive,index=['Channel'],values=['Leadid','PotentialRevenueInLakhs'],aggfunc={'Leadid':len,'PotentialRevenueInLakhs':sum}).reset_index()
channelwisesummary = channelwisesummarygrp.append(channelwisesummary_all,ignore_index=True)
channelwisesummary.SaleRegion.fillna('PAN_INDIA',inplace=True)

columns6mchannel = ['SaleRegion','Channel','LastStatusCode','LastStatusDesc','Leadid','PotentialRevenueInLakhs']
channelwisesummary = pd.DataFrame(channelwisesummary,columns=columns6mchannel)


# ### 6 MONTHS SALESPERSONWISE SUMMARY

# In[15]:

salespersonwisesummary = leaddataactive.groupby(['SaleRegion','SalesPersonName','LastStatusCode','LastStatusDesc']).agg({'Leadid':len,'PotentialRevenueInLakhs':sum}).reset_index()

columns6msalespersonwise = ['SaleRegion','SalesPersonName','LastStatusCode','LastStatusDesc','Leadid','PotentialRevenueInLakhs']
salespersonwisesummary = pd.DataFrame(salespersonwisesummary,columns=columns6msalespersonwise)


# ### WRITING TO EXCEL FILE

# In[16]:

with ExcelWriter(r'D:\Data\Sales_lead_management\Summary\Sales_NBD_Pipeline_report_'+str(yestdate)+'.xlsx') as writer:
    leaddataactivecurmonthsumenswtotal.to_excel(writer, sheet_name='MTD_Summary',engine='xlsxwriter')
    leaddatacurmonth_NE.to_excel(writer, sheet_name='MTD_N+E',engine='xlsxwriter')
    leaddatacurmonth_South.to_excel(writer, sheet_name='MTD_South',engine='xlsxwriter')
    leaddatacurmonth_West.to_excel(writer, sheet_name='MTD_West',engine='xlsxwriter')
    leaddatainactivecurmonthsum.to_excel(writer, sheet_name='MTD_SUMMARY_Inactive',engine='xlsxwriter')
    leaddataactivesummary.to_excel(writer, sheet_name='6M_Summary',engine='xlsxwriter')
    leaddataactiveageing.to_excel(writer, sheet_name='6M_Ageing',engine='xlsxwriter')
    channelwisesummary.to_excel(writer, sheet_name='6M_Channelwise',engine='xlsxwriter')
    salespersonwisesummary.to_excel(writer, sheet_name='6M_SalePersonWise',engine='xlsxwriter')

oppath2 = r'D:\Data\Sales_lead_management\Summary\Sales_NBD_Pipeline_report_'+str(yestdate)+'.xlsx'  


leadbasedata.to_csv(r'D:\Data\Sales_lead_management\Customer_lead_basedata.csv')
oppath1 = r'D:\Data\Sales_lead_management\Customer_lead_basedata.csv'



# ### FTP

# In[17]:

ftp = ftplib.FTP()
ftp.connect('10.109.250.50')
#print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        #print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppath1
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        #print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()
    

#######$$$$$$$$$ http://spoton.co.in/downloads/IEProjects/ETA/Customer_lead_basedata.csv 


# In[18]:

columnsmtdsummail = ['SaleRegion','LastStatusCode','Leadid','Revenue(L)']
leaddataactivecurmonthsumpanindiamail = pd.DataFrame(leaddataactivecurmonthsumpanindia,columns=columnsmtdsummail)
leaddataactivecurmonthsumpanindiamail = leaddataactivecurmonthsumpanindiamail.to_string(index=False)


# In[19]:

filePath = oppath2
def sendEmail(TO = ["rsm_spot@spoton.co.in","reena.singhania@spoton.co.in"],
            #TO = ["Ankit@iepfunds.com","rajeesh.vr@spoton.co.in"],
            #TO = ["vishwas.j@spoton.co.in"],
            #TO = ["rajeesh.vr@spoton.co.in"],
            CC = ["uday.sharma@spoton.co.in","abhik.mitra@spoton.co.in","narasimha.murthy@spoton.co.in","Yogesh@iepfunds.com","rajeesh.vr@spoton.co.in"],
            #CC = ["vishwas.j@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "Sales NBD - Pipeline Report - "+ str(yestdate)
    body_text = """
    Dear All,
    
    PFA the Sales NBD Pipeline report as of """+str(yestdate)+""" (For Active Leads)
    
    PFB the Pipeline report summary for current month as of """ +str(yestdate)+"""

    
    """+str(leaddataactivecurmonthsumpanindiamail)+"""
    
    
    LEGENDS:
    S0	Lead Identified
    S1	Prospecting Done
    S2	Proposal Submitted to Customer
    S3	Counter Proposal accepted by Customer
    S4	Proposal Signed
    S5	Trading Initiated

    The base data for the report can be downloaded from the below link
    
    http://spoton.co.in/downloads/IEProjects/ETA/Customer_lead_basedata.csv
    
    """
    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends


leadbasedata.to_csv(r'D:\Data\Sales_lead_management\Pipeline_basedata\Customer_lead_basedata_'+str(yestdate)+'.csv')
# In[ ]:

