
# coding: utf-8

# In[1]:

import pandas as pd
import pyodbc
from datetime import datetime,timedelta
import numpy as np
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
import smtplib
import Utilities


# In[2]:

startdate='2019-07-15 00:00:00'
enddate=datetime.strftime(datetime.now(),'%Y-%m-%d %H:%M:%S')
startdate,enddate


# In[3]:

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()


# In[4]:

query=("""SELECT  CONVERT(VARCHAR(10), DT.DOCKDT, 103) [VTC con pickup date] ,
        CONVERT(VARCHAR(10), DD.DELY_DT, 103) [VTC con delivery date] ,
        CASE WHEN DT.DOC_CURLOC = DT.REASSIGN_DESTCD
             THEN CONVERT(VARCHAR(10), DS.DOD_Recvdt_Dbr, 103)
        END [VTC receive date at Delivery SC] ,
        DS.COURIER_ENTRYDT [VTC forwarding date from Delivery SC] ,
        DS.COURIER_NO [VTC forwarding date from Delivery SC CourierNo] ,
        DS.COURIER_NAME [VTC forwarding date from Delivery SC CourierName] ,
        CONVERT(VARCHAR(10), DE.ReceiveDate, 103) [VTC received date at HO] ,
        CASE WHEN DEE.CourierNumber IS NOT NULL
                  AND DEE.ReceiveStatus IS NULL
             THEN CONVERT(VARCHAR(10), DEE.CourierDate, 103)
        END [VTC forwarding date from HO TO Customer] ,
        CASE WHEN DEE.CourierNumber IS NOT NULL
                  AND DEE.ReceiveStatus IS NULL THEN DEE.CourierNumber
        END [VTC forwarding date from HO TO Customer CourierNo] ,
        CASE WHEN DEE.CourierNumber IS NOT NULL
                  AND DEE.ReceiveStatus IS NULL THEN DEE.CourierName
        END [VTC forwarding date from HO TO Customer CourierName] ,
        DT.CSGNCD ,
        DT.CSGNNM ,
        DS.DOD_AMT ,
        DS.DOD_NO ,
        DT.DOCKNO ,
        BD.BRCD ,
        BD.BRNM ,
        BD.DEPOT_CODE ,
        ISNULL(CONVERT(VARCHAR(10), DEE.CourierPickupDate, 103), '-') [Courier Pickup Date] ,
        ISNULL(CONVERT(VARCHAR(10), DEE.CourierDeliveryDate, 103), '-') [Courier Delivery Date] ,
        ISNULL(DEE.CourierDlvStatus, '-') [Courier Delivery Status] ,
        ISNULL(DEE.CourierDlvRemarks, '-') [Courier Delivery Remarks]
FROM    dbo.DOCKET DT WITH ( NOLOCK )
        INNER JOIN brms BD WITH ( NOLOCK ) ON BD.BRCD = DT.DESTCD
        LEFT OUTER JOIN dbo.DKT_DELY DD WITH ( NOLOCK ) ON DD.DOCKNO = DT.DOCKNO
        LEFT OUTER JOIN dbo.DKT_DOD DS WITH ( NOLOCK ) ON DS.DOCKNO = DT.DOCKNO
        LEFT OUTER JOIN brms O WITH ( NOLOCK ) ON O.BRCD = DT.ORGNCD
        LEFT OUTER JOIN brms D WITH ( NOLOCK ) ON D.BRCD = DT.REASSIGN_DESTCD
        LEFT OUTER JOIN dbo.EMPMST EP WITH ( NOLOCK ) ON EP.EMPCD = DS.COURIER_ENTRYBY
        LEFT OUTER JOIN DKT_DOD_STATUS DE WITH ( NOLOCK ) ON DS.AUTOID = DE.AutoId
                                                             AND DE.ReceiveStatus = 'Y'
        LEFT OUTER JOIN DKT_DOD_STATUS DEE WITH ( NOLOCK ) ON DS.AUTOID = DEE.AutoId
                                                              AND DEE.ReceiveStatus IS NULL
WHERE   DT.ApplyVTC = 1
        AND DD.DELY_DT BETWEEN '{0}' AND '{1}'""").format(startdate,enddate)
df=pd.read_sql(query,Utilities.cnxn)
print (len(df))
df.drop_duplicates('DOCKNO',inplace=True)




# In[5]:




# In[7]:

df['VTC receive at Delivery SC']=df['VTC receive date at Delivery SC'].apply(lambda x: 1 if x!=None else 0)
df['VTC forwarding from Delivery SC']=df['VTC forwarding date from Delivery SC'].apply(lambda x: 0 if pd.isnull(x) else 1)
df['VTC received at HO']=df['VTC received date at HO'].apply(lambda x: 1 if x!=None else 0)
df['VTC forwarding from HO']=df['VTC forwarding date from HO TO Customer'].apply(lambda x: 1 if x!=None else 0)
df['VTC_Received_By_Customer']=df['Courier Delivery Status'].apply(lambda x: 0 if x=='-' else 1)


# In[8]:

mtdsummary=df.pivot_table(index=['DEPOT_CODE'],
    aggfunc={'VTC_Received_By_Customer':sum,'VTC con delivery date':len,'VTC receive at Delivery SC':sum,
             'VTC forwarding from Delivery SC':sum,'VTC received at HO':sum,'VTC forwarding from HO':sum}).reset_index()


# In[9]:

mtdsummary


# In[10]:

mtdsummary1=mtdsummary[['DEPOT_CODE','VTC con delivery date','VTC receive at Delivery SC','VTC forwarding from Delivery SC','VTC received at HO',
           'VTC forwarding from HO','VTC_Received_By_Customer']]


# In[11]:

mtdsummary1.loc['Total']=mtdsummary1[['VTC con delivery date','VTC receive at Delivery SC','VTC forwarding from Delivery SC','VTC received at HO',
           'VTC forwarding from HO','VTC_Received_By_Customer']].sum(axis=0)


# In[12]:

mtdsummary1


# In[13]:

df['Delivery Date']=df['VTC con delivery date']
datewisesummary=df.pivot_table(index=['Delivery Date'],
                                aggfunc={'VTC_Received_By_Customer':sum,'VTC con delivery date':len,'VTC receive at Delivery SC':sum,
                                         'VTC forwarding from Delivery SC':sum,'VTC received at HO':sum,
                                         'VTC forwarding from HO':sum}).reset_index()


# In[14]:

datewisesummary


# In[15]:

datewisesummary=datewisesummary[['Delivery Date','VTC con delivery date','VTC receive at Delivery SC','VTC forwarding from Delivery SC','VTC received at HO',
           'VTC forwarding from HO','VTC_Received_By_Customer']]


# In[16]:

datewisesummary.loc['Total']=datewisesummary[['VTC con delivery date','VTC receive at Delivery SC','VTC forwarding from Delivery SC','VTC received at HO',
           'VTC forwarding from HO','VTC_Received_By_Customer']].sum(axis=0)


# In[17]:
datewisesummary['Delivery Date']=pd.to_datetime(datewisesummary['Delivery Date'],format="%d/%m/%Y")
datewisesummary.sort_values('Delivery Date',ascending=False,inplace=True)


# In[18]:

mtdsummary


# In[19]:

mtdsummary['Delivered Not Rcvd@Sc']=mtdsummary['VTC con delivery date']-mtdsummary['VTC receive at Delivery SC']
mtdsummary['Rcvd @Sc not Forwarded to HO']=mtdsummary['VTC receive at Delivery SC']-mtdsummary['VTC forwarding from Delivery SC']
mtdsummary['Forwarded to HO but not Recvd @ HO']=mtdsummary['VTC forwarding from Delivery SC']-mtdsummary['VTC received at HO']
mtdsummary['Received @ HO not forwarded to Customer']=mtdsummary['VTC received at HO']-mtdsummary['VTC forwarding from HO']
mtdsummary['Not Received @ Customer']=mtdsummary['VTC forwarding from HO']-mtdsummary['VTC_Received_By_Customer']


# In[20]:

exception_summary=mtdsummary[['DEPOT_CODE','Delivered Not Rcvd@Sc','Rcvd @Sc not Forwarded to HO','Forwarded to HO but not Recvd @ HO',
            'Received @ HO not forwarded to Customer','Not Received @ Customer']]


# In[22]:

exception_summary.loc['Total']=exception_summary[['Delivered Not Rcvd@Sc','Rcvd @Sc not Forwarded to HO','Forwarded to HO but not Recvd @ HO',
            'Received @ HO not forwarded to Customer','Not Received @ Customer']].sum(axis=0)


# In[24]:

mtdsummary1


# In[23]:

exception_summary


# In[ ]:

df.to_csv(r'D:\Data\VTC Data\VTC_Data_All_Depots.csv')


# In[28]:

filepath=r'D:\Data\VTC Data\VTC_Data_All_Depots.csv'


# In[26]:

date=datetime.strftime(datetime.now(),'%Y-%m-%d')



# In[30]:

TO=['spot_is@spoton.co.in','scincharge_spot@spoton.co.in','spot_cstl@spoton.co.in','rom_spot@spoton.co.in','aom_spot@spoton.co.in','dom_spot@spoton.co.in','dinesh.kumar.sharma@spoton.co.in','balakrishnan.r@spoton.co.in','dominic.sathish@spoton.co.in','shiva.prasad@spoton.co.in','baskar.t@spoton.co.in','manzil.bhattacharya@spoton.co.in','aom_spot@spoton.co.in','scincharge_spot@spoton.co.in']
# TO=['mahesh.reddy@spoton.co.in']

CC=["satya.pal@spoton.co.in","abhik.mitra@spoton.co.in",'shivananda.p@spoton.co.in','rajesh.kapase@spoton.co.in','pawan.sharma@spoton.co.in','rajesh.kumar@spoton.co.in','krishna.chandrasekar@spoton.co.in','saptarshi.pathak@spoton.co.in','mahesh.reddy@spoton.co.in']
# CC=['mahesh.reddy@spoton.co.in']

FROM="reports.ie@spoton.co.in"
# FROM="mahesh.reddy@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
# msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "VTC Report & Exceptions" + " - " + str(date)
report=""
report+="Dear All"
report+='<br>'
report+='<br>'
report+='Please find VTC Report '
report+='<br>'
report+='<br>'
report+='<br>'
report+="Exceptions Summary "
report+='<br>'+exception_summary.to_html()+'<br>'
report+='<br>'
report+="Depot Wise Summary "
report+='<br>'+mtdsummary1.to_html()+'<br>'
report+='<br>'

report+='<br>'
report+="Date Wise Summary "
report+='<br>'+datewisesummary.to_html()+'<br>'
report+='<br>'



abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)


# server=smtplib.SMTP('smtp.sendgrid.net', 587)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("mahesh.reddy@spoton.co.in", "Nov@2018")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()


# In[ ]:



