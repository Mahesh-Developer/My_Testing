
# coding: utf-8

# In[1]:

import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
#import datetime
import os
import Utilities
#dsn = 'vishwas'
#user = 'sa'
#password = 'password@123'
#database = 'ESTL_CRP2'
#
#con_string = 'DSN=%s;UID=%s;PWD=%s;DATABASE=%s;' % (dsn, user, password, database)
#conn = pyodbc.connect(con_string)
#conn.autocommit = True
#cursor = conn.cursor()


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()

#cursor.execute("select TOP 10 DOCKNO from docket")
#rows = cursor.fetchall()
#for row in rows:
#    print row.DOCKNO
query=("""
  SELECT  TC.thcno AS ThcNo ,
        CASE WHEN ISNULL(vs.SourceCode, '') = '' THEN TC.sourcehb
             ELSE vs.SourceCode
        END sourcehb ,
        CASE WHEN ISNULL(vs.DestinationCode, '') = '' THEN TC.tobh_code
             ELSE vs.DestinationCode
        END tobh_code ,
        TC.sourcehb [FromHUB] ,
        TC.tobh_code [CurHUB] ,
        hd2.tobh_code [NextHUB] ,
        TC.routety ,
        CASE WHEN TC.routety = 'D' THEN GETDATE()
             ELSE dbo.UFN_GET_THC_ARRCTIME_ASPER_GPS_CNM_NEW(TC.thcno, NULL)
        END AS ArrivalTime_ASPER_GPS_CNM ,
        CAST(CONVERT(VARCHAR, hd2.actarrv_dt, 112) + ' ' + hd2.actarrv_tm AS SMALLDATETIME) Arrivaltime ,
        TR.TCHDRFLAG ,
        CASE WHEN hd2.tobh_code IS NULL THEN 'Y'
             WHEN hd2.tobh_code = 'Null' THEN 'Y'
             ELSE 'N'
        END AlreadyArrived ,
        SUM(d.ACTUWT) AS ld_actuwt
FROM    THCHDR TC WITH ( NOLOCK )
        LEFT OUTER JOIN tbl_VehicleRunningStatus_New vs WITH ( NOLOCK ) ON vs.ThcNo = TC.thcno
        LEFT OUTER JOIN THCHDR hd2 WITH ( NOLOCK ) ON TC.thcno = hd2.thcno
                                                      AND TC.tobh_code = hd2.sourcehb
        LEFT OUTER JOIN dbo.TCHDR TR WITH ( NOLOCK ) ON TR.THCNO = TC.thcno
                                                        AND TR.ToBH_CODE = TC.tobh_code
        LEFT OUTER  JOIN dbo.TCTRN d WITH ( NOLOCK ) ON d.TCNO = TR.TCNO
WHERE   TC.actarrv_dt >= CONVERT(DATE, GETDATE() - 15)
          --  AND TC.tobh_code = 'BLRH'
        AND TC.tobh_code <> 'Null'
        AND ( hd2.thcno IS  NULL
              OR TR.TCHDRFLAG = 'Y'
            )--INCLUDE THE CONS WHICH ARE NOT INSCANNED YET  
        AND hd2.sourcehb IS NOT NULL -- TO GET ONLY ARRIVED THC's
        --    AND tc.thcno = 'NTDELHX0073861'
        
GROUP BY TC.thcno ,
        TC.sourcehb ,
        TC.tobh_code ,
        TC.routety ,
        hd2.actarrv_dt ,
        hd2.actarrv_tm ,
        TR.TCHDRFLAG ,
        hd2.tobh_code ,
        vs.SourceCode ,
        vs.DestinationCode
        """)
#rows = cursor.fetchall()
#df = pd.DataFrame(query.fetchall())



veh_pileup_df = pd.read_sql(query, Utilities.cnxn)

veh_pileup_df.to_csv(r'D:\Data\Vehicle_pileup_report\veh_pileup_df.csv')

veh_pileup_df = veh_pileup_df.drop_duplicates(subset='ThcNo')
veh_pileup_df = veh_pileup_df.drop(['TCHDRFLAG'],axis=1)

veh_pileup_df = veh_pileup_df[veh_pileup_df['routety']!='D']

corehublist = ['AMCH','AMDH','BLRH','BOMH','BRGH','CCUH','DELH','HYDH','MAAH','NAGH','PNQH','VPIH','VZAH','SXVF','IDRH','CJBH','GAUB','GAUH','COKB','JAIH','BGMH','PATF','PATH','BBIH','IXRB']

# veh_pileup_df = veh_pileup_df[veh_pileup_df['tobh_code'].isin(corehublist)]

## Edit on 16-10-2016 for filtering out not reached THCs
# veh_pileup_df = veh_pileup_df[veh_pileup_df['AlreadyArrived']=='Y']
## Edit on 16-10-2016 for filtering out not reached THCs

ts= datetime.now()
opfilevar=ts.date()
opfilevar1=ts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=pd.np.round(float(currhrs)/60)


veh_pileup_df.loc[veh_pileup_df.index,'CurrentTime'] = ts


def diffhr(currtime,arrivetime):
    diff = (currtime - arrivetime)
    return pd.np.round(diff.total_seconds()/3600,1)
    #return diffhrs
def get3hrscount(timediff):
    if timediff>3:
        return 1
    else:
        return 0

veh_pileup_df['Time_diff'] = veh_pileup_df.apply(lambda x:diffhr (x['CurrentTime'],x['Arrivaltime']),axis=1)
veh_pileup_df['>3Hrs'] = veh_pileup_df.apply(lambda x:get3hrscount (x['Time_diff']),axis=1)



veh_pileup_df_grp = veh_pileup_df.groupby(['sourcehb','CurHUB']).agg({'ThcNo':len,'ld_actuwt':sum,'Time_diff':sum,'>3Hrs':sum}).reset_index()
veh_pileup_df_grp['WtTimeDiff'] = veh_pileup_df_grp.apply(lambda x:pd.np.round((x['Time_diff']/x['ThcNo']),1),axis=1)
veh_pileup_df_grp = pd.DataFrame(veh_pileup_df_grp,columns=['sourcehb','CurHUB','ThcNo','ld_actuwt','WtTimeDiff','>3Hrs'])
veh_pileup_df_grp = veh_pileup_df_grp.rename(columns={'CurHUB':'LOC','ld_actuwt':'Wt(T)','sourcehb':'SourceHub'})


def loadroundoff(wt):
    wt_in_ton = pd.np.round(wt/1000.0,1)
    return wt_in_ton

veh_pileup_df_grp['Wt(T)'] = veh_pileup_df_grp.apply(lambda x:loadroundoff(x['Wt(T)']),axis=1)
veh_pileup_df_grp = veh_pileup_df_grp.sort_values('Wt(T)',ascending=False)
# veh_pileup_df_grp = veh_pileup_df_grp.to_string(index=False)


## For converting datetime in readable format. Edit on 27-10-2016
veh_pileup_df['ArrivalTime_ASPER_GPS_CNM'] = veh_pileup_df.apply(lambda x:datetime.strftime(x['ArrivalTime_ASPER_GPS_CNM'],"%Y-%m-%d %H:%M:%S"),axis=1)
veh_pileup_df['Arrivaltime'] = veh_pileup_df.apply(lambda x:datetime.strftime(x['Arrivaltime'],"%Y-%m-%d %H:%M:%S"),axis=1)
veh_pileup_df['CurrentTime'] = veh_pileup_df.apply(lambda x:datetime.strftime(x['CurrentTime'],"%Y-%m-%d %H:%M:%S"),axis=1)


# In[2]:


import geopy
import pandas as pd
from geopy.distance import vincenty, great_circle
g = geopy.geocoders.GoogleV3(api_key='AIzaSyBHh5UbW1CYILQssgheYvaHcu9gOiAMOW4')
def getdist(pin,scpin):
    try:
        pinresult=g.geocode('INDIA,'+str(pin))

        pinlat=pinresult.latitude

        pinlon=pinresult.longitude

        scpinresult=g.geocode('INDIA,'+str(scpin))

        scpinlat=scpinresult.latitude

        scpinlon=scpinresult.longitude

        distance=vincenty((scpinlat, scpinlon),(pinlat,pinlon)).kilometers

        return distance

    except:

        return '-'


# In[5]:

import pyodbc
cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=PYTHON_DB;UID=PythonOnline;PWD=P@ssw0rd123$")



# In[6]:

scdetails = pd.read_sql("SELECT SC,[Name of SC],Type,Pincode FROM branchmaster",cnxn)
hubdetails = pd.read_sql("SELECT HUB,[Hub Name],[Location Status],[Pincode] FROM hubmaster",cnxn)
hubdetails.columns=scdetails.columns
scdetails=scdetails.append(hubdetails)


# In[7]:

scpindict={}
for i in zip(scdetails["SC"],scdetails["Pincode"]):
    scpindict.update({i[0]:i[1]})


# In[8]:

veh_pileup_df_grp['distance']=veh_pileup_df_grp.apply(lambda x:getdist(scpindict.get(x['SourceHub']),scpindict.get(x['LOC'])),axis=1)


# In[9]:

# senddf['Act Wt In Tonnes']=pd.np.round(senddf['Act Wt In Tonnes'],1)
# senddf = senddf.rename(columns={'Act Wt In Tonnes':'ACTWT','Con Number':'Cons'})

# In[11]:

senddf1=veh_pileup_df_grp[veh_pileup_df_grp['distance']>500]
senddf2=veh_pileup_df_grp[veh_pileup_df_grp['distance']<500]
del senddf1['distance']
del senddf2['distance']

scdetails = pd.read_sql("SELECT SC,[Name of SC],Type,[Pincode] FROM branchmaster",cnxn)
hubdetails = pd.read_sql("SELECT HUB,[Hub Name],[Location Status],Pincode FROM hubmaster",cnxn)
sc=scdetails['SC'].unique().tolist()
hubs=hubdetails['HUB'].unique().tolist()

# In[5]:

maildf=veh_pileup_df_grp.pivot_table(index='LOC',aggfunc={'ThcNo':sum,'Wt(T)':sum,'WtTimeDiff':pd.np.mean,'>3Hrs':sum}).reset_index().sort_values('ThcNo',ascending=False)
maildf['WtTimeDiff']=pd.np.round(maildf['WtTimeDiff'],1)
maildf=maildf[['LOC','ThcNo','Wt(T)','WtTimeDiff','>3Hrs']]
maildfhubs=maildf[maildf['LOC'].isin(hubs)]
maildfhubs=maildfhubs[maildfhubs['WtTimeDiff']>2]
maildfsc=maildf[maildf['LOC'].isin(sc)]
maildfsc=maildfsc[maildfsc['WtTimeDiff']>1]
# In[9]:

maildfhubs=maildfhubs.to_html()
maildfsc=maildfsc.to_html()	

# In[10]:

ts= datetime.now()
opfilevar=ts.date()
opfilevar1=ts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60
opfilevar2=pd.np.round(float(currhrs)/60)


# In[11]:

veh_pileup_df.to_csv(r'D:\Data\Vehicle Pile Up All Location\VehicleTHCwise-'+str(opfilevar)+str('-')+str(opfilevar2)+'.csv')
veh_pileup_df.to_csv(r'D:\Data\Vehicle Pile Up All Location\VehicleTHCwise.csv')
filepath=r'D:\Data\Vehicle Pile Up All Location\VehicleTHCwise.csv'
# TO=["hubmgr_spot@spoton.co.in","Cnm@Spoton.Co.In","Raghavendra.Rao@Spoton.Co.In","dom_spot@spoton.co.in","rom_spot@spoton.co.in"]
# TO=['supratim@iepfunds.com','ankit@iepfunds.com','pawan.sharma@spoton.co.in','satya.pal@spoton.co.in']
TO=['shashvat.suhane@spoton.co.in']
FROM='reports.ie@spoton.co.in'
# CC=["supratim@iepfunds.com","rajeesh.vr@spoton.co.in","sqtf@spoton.co.in","pawan.sharma@spoton.co.in","prasanna.hegde@spoton.co.in","rajesh.kapase@spoton.co.in","shashvat.suhane@spoton.co.in"]
# BCC = ['yogesh.singh@spoton.co.in','prabhakar.mahajan@spoton.co.in','nitin.tatyarao@spoton.co.in','vinodkumar.mishra@spoton.co.in','jai.prakash@spoton.co.in','vishwas.j@spoton.co.in','nomesh.ganvir@spoton.co.in','sanjay.panse@spoton.co.in','sunil.khare@spoton.co.in','OPS.HUB.IDRH.1@SPOTON.CO.IN','Rajesh.Mishra@Spoton.Co.In']
CC=['shashvat.suhane@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "Vehicle Pileup Report All Location -"+ str(opfilevar)+"-"+str(opfilevar2)
html='''<html>
<h4>Dear All,</h4>
PFB Summary of Vehicle Pile up report for hubs<br></br>'''+str(maildfhubs)+'''
<br>PFB Summary of Vehicle Pile up report for SC's</br><br>'''+str(maildfsc)+'''</br>
<br>PFB Summary of Vehicle Pile up report where Distance b/w is greater than 500</br><br>'''+str(senddf1.to_html())+'''</br>
<br>PFB Summary of Vehicle Pile up report where Distance b/w is less than 500</br><br>'''+senddf2.to_html()+'''</br></html>'''
# report=""
# # report+='<br>'
# report+='PFB the weight which are available in stock where distance between two location less than 500'
# # report+='<br>'
# report+=''
# report+='<br>'+senddf2.to_html()+'<br>'
klm=MIMEText(html,'html')
msg.attach(klm)
# bcd=MIMEText(senddf1.to_html(),'html')
# msg.attach(bcd)
# abc=MIMEText(report,'html')
# msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()


# In[ ]:



