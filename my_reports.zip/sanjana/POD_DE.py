
# coding: utf-8

# In[34]:


import pandas as pd
import pyodbc
from datetime import datetime,timedelta
import smtplib
import os
import numpy as np
import Utilities

# In[7]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()


# In[5]:


yestdate=datetime.strftime(datetime.now()-timedelta(days=1),'%Y-%m-%d')
yestdate


# In[6]:


query=("EXEC dbo.USP_DELV_EFF_SC_WISE_ALL_POD  'S', '{0}', '{1}'").format(yestdate,yestdate)
query


# In[12]:


df=pd.read_sql(query,Utilities.cnxn)


# In[13]:


len(df)


# In[14]:


df.columns


# In[16]:


area_summary=df.pivot_table(index=['ControlArea'],aggfunc={'TOTAL':sum,'SCAN_CON':sum}).reset_index()


# In[18]:


area_summary['SCAN_DE%']=pd.np.round(area_summary['SCAN_CON']*100.0/area_summary['TOTAL'],0)


# In[37]:


area_summary=area_summary.replace([np.inf,-np.inf],np.nan).fillna(0)
area_summary['SCAN_DE%']=area_summary['SCAN_DE%'].astype(int)


# In[38]:


area_summary


# In[20]:


branch_summary=df.pivot_table(index=['ControlArea','DEST_BRCD'],aggfunc={'TOTAL':sum,'SCAN_CON':sum}).reset_index()


# In[22]:


branch_summary['SCAN_DE%']=pd.np.round(branch_summary['SCAN_CON']*100.0/branch_summary['TOTAL'],0)


# In[35]:


branch_summary=branch_summary.replace([np.inf,-np.inf],np.nan).fillna(0)
branch_summary['SCAN_DE%']=branch_summary['SCAN_DE%'].astype(int)


# In[24]:


from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template
import pyodbc


# In[25]:


todate=datetime.strftime(datetime.now(),'%Y-%m-%d')
# todate='2019-05-20'


# In[26]:


writer = pd.ExcelWriter(r'D:\Data\POD_Scan_DE\SCAN_DE_'+str(todate)+'.xlsx', engine='xlsxwriter')
area_summary.to_excel(writer,sheet_name='Area Summary')
branch_summary.to_excel(writer,sheet_name='Branch Summary')
df.to_excel(writer,sheet_name='Data')
writer.save()

writer = pd.ExcelWriter(r'D:\Data\POD_Scan_DE\SCAN_DE.xlsx', engine='xlsxwriter')
area_summary.to_excel(writer,sheet_name='Area Summary')
branch_summary.to_excel(writer,sheet_name='Branch Summary')
df.to_excel(writer,sheet_name='Data')
writer.save()

# In[27]:


filepath=r'D:\Data\POD_Scan_DE\SCAN_DE.xlsx'


# In[29]:


# TO=['mahesh.reddy@spoton.co.in']
TO=["aom_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in","scincharge_spot@spoton.co.in","jothi.menon@spoton.co.in","shivananda.p@spoton.co.in"]
CC=["mahesh.reddy@spoton.co.in","anitha.thyagarajan@spoton.co.in"]
FROM="mis.ho@spoton.co.in"
# FROM="mahesh.reddy@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "POD Scan DE" + " - " + str(todate)

report=""
report+="Dear All"
report+='<br>'
report+='<br>'
report+='Please find POD Scan Delivery Performance'
report+='<br>'
report+='<br>'
report+='PFB Area Wise Summary'
report+='<br>'+area_summary.to_html()+'<br>'


abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

# part1 = MIMEBase('application', "octet-stream")
# part1.set_payload( open(filepath1,"rb").read() )
# encoders.encode_base64(part1)
# part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
# msg.attach(part1)


# server=smtplib.SMTP('smtp.sendgrid.net', 587)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("mahesh.reddy@spoton.co.in", "Nov@2018")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()

