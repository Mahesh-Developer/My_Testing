
# coding: utf-8

# In[1]:
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from sqlalchemy import *
import smtplib
import os
import traceback
import ftplib
import Utilities
import simplejson
import urllib
import sys;
#cnxn1 = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.87;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
#cursor1 = cnxn1.cursor()
# cnxn1 = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor1 = cnxn1.cursor()

# cnxn1 = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor1 = cnxn1.cursor()



#try:
pd.set_option("display.max_columns",120)
pd.set_option("display.max_colwidth",1000)

reload(sys);
sys.setdefaultencoding("utf8")
#intransitdf=pd.read_excel(r'http://spoton.co.in/downloads/TCR_UND_2HRS/TCR_UND_ISDEPART_YES_2HRS.xls')

stockquery1 = ("""SELECT     *
 
 
  FROM tblTimeConnectionReport_Undelivered_2HRS   
    WHERE ISDEPARTED_FRM_CURRLOC='YES'""")
print (stockquery1)

# intransitdf=pd.read_sql(stockquery1,Utilities.cnxn)
intransitdf=pd.read_sql(stockquery1,Utilities.cnxn)
print ('intransitdf',len(intransitdf))
intransitdf.rename(columns={'CDELDT':'DUE DATE','ORIGIN_BRCODE':'ORIGIN BRCODE','CURR_BRANCHCODE':'CURR BRANCHCODE','ISDEPARTED_FRM_CURRLOC':'IS DEPARTED FRM CURRLOC','DEPARTURE_TIME_FRM_CURLOC':'DEPARTURE TIME FRM CURLOC','DEPARTURE_TO_LOC_FRM_CURLOC':'DEPARTURE TO LOC FRM CURLOC','DEPARTED_FRM_CURRLOC_THCNO':'DEPARTED FRM CURRLOC THCNO','DEPARTED_FRM_CURRLOC_ROUTECD':'DEPARTED FRM CURRLOC ROUTECD','DEPARTED_FRM_CURRLOC_VEHNO':'DEPARTED FRM CURRLOC VEHNO','DOCKDT':'PICKUP DATE','LatestConStatusCode':'Latest Con Status Code','TCNO_FROM_HUB':'TCNO FROM HUB','THC_VENDOR_TYPE':'THC VENDOR TYPE','THC_SOURC':'THC SOURC','THC_DEST':'THC DEST','THC_ETA':'THC ETA','THC_ARRI_ENTRY':'THC ARRI ENTRY','THC_LAST_UPDATE_HR':'THC LAST UPDATE HR','THC_ROUTE_NAME':'THC ROUTE NAME','THC_LAST_TIME':'THC LAST TIME','ApptmntDelDate':'Apptmnt Del Date','TIME_STAMP':'TIMESTAMP'},inplace=True)
# 
htrquery = ("""EXEC USP_HUB_THROUGHPUT_DETAILS_SALES_ONEHOUR""")
print (htrquery)
# invdf = pd.read_sql(htrquery, Utilities.cnxn)
invdf = pd.read_sql(htrquery,Utilities.cnxn)

print (len(invdf))
print (invdf[invdf['Hub/SC Location']=='AMCH']['Act.WtInTonnes'].sum())

intransitdf.DOCKNO=intransitdf.DOCKNO.astype(int)
print ('invdf',len(invdf))
invdf.rename(columns={'Hub/SC Location':"Hub SC Location",'Arrival Date @ Hub':"Arrival Date Hub",'DestnBranch':"Destn Branch",'Act.WtInTonnes':"Act Wt In Tonnes",'LatestStatusCode':"Latest Status Code",'OriginArea':"Origin Area",'DestnArea':'Destn Area'},inplace=True)
invdf['Con Number']=invdf['Con Number'].astype(int)
#invdf=pd.read_excel(r'http://spoton.co.in/downloads/HTR_1HR/HTR_1HR.xls')
invdf['OD']=zip(invdf['Hub SC Location'],invdf['Destn Branch'])
import pickle
try:
    pkl_file = open(r'D:\Path Dict\path_dict.pkl', 'rb')
except:
    pkl_file = open(r'C:\Users\ankit\Dropbox\Python\testrest\Async2\Async2\path_dict.pkl', 'rb')
path_dict = pickle.load(pkl_file)
print (path_dict.get(('DBLR','BLRH')))
pkl_file.close()
invdf["Resid_Path"]=invdf['OD'].map(lambda x: path_dict.get((x[0],x[1]))[0] if path_dict.get((x[0],x[1]))!=None else [0,0])


def getNextLoc(pth,con):
    try:
        nxtloc=pth[1]
        return nxtloc
    except:
        return '-'
invdf['NextLoc']=invdf.apply(lambda x: getNextLoc(x['Resid_Path'],x['Con Number']),axis=1)
mergedf = pd.merge(invdf,intransitdf,left_on=['Con Number'], right_on=['DOCKNO'], how='inner')
invdf_correct=invdf[~invdf['Con Number'].isin(mergedf['Con Number'])]

#print (invdf_correct[invdf_correct['Hub SC Location']=='BRGH'])


hublist_df=pd.read_excel(r'D:\Python\Scripts and Files\Python Scripts\Timegraph\Hublist.xlsx')
hublist=hublist_df['BRANCH CODE'].tolist()

print (invdf_correct[(invdf_correct['Hub SC Location']=='NDAH')&(invdf_correct['NextLoc']=='AGRB')])

def getType(nextloc):
    if nextloc in hublist:
        return "HUB"
    else:
        return "SC"


invdf_correct['LOC_TYPE']=invdf_correct.apply(lambda x: getType(x['NextLoc']),axis=1)


def getWtType(wttype):
    if wttype>1.0:
        return ">1 Tonnes"
    else:
        return "<1 Tonnes"

invdf_correct['WT_TYPE']=invdf_correct.apply(lambda x: getWtType(x['Act Wt In Tonnes']),axis=1)
loadavailabledf=invdf_correct.pivot_table(index=['Hub SC Location','NextLoc'],aggfunc={'Act Wt In Tonnes':np.sum,'Con Number':len}).reset_index().sort_values('Act Wt In Tonnes',ascending=False)
loadavailabledf

loadavailabledf=loadavailabledf[(loadavailabledf['Hub SC Location']!='CCUC') & (loadavailabledf['NextLoc']!='DCCU')]
# In[2]:

commoncons=len(mergedf)
invcons=len(invdf_correct)


# In[3]:

senddf=loadavailabledf[loadavailabledf['Act Wt In Tonnes']>10]


# In[4]:

import geopy
import pandas as pd
from geopy.distance import vincenty, great_circle
g = geopy.geocoders.GoogleV3(api_key='AIzaSyA0m2hyGsBWWG4zH0EvY5CWIkMzbNthnuU')
def getdist(pin,scpin):
    try:
        pinresult=g.geocode('INDIA,'+str(pin))

        pinlat=pinresult.latitude

        pinlon=pinresult.longitude

        scpinresult=g.geocode('INDIA,'+str(scpin))

        scpinlat=scpinresult.latitude

        scpinlon=scpinresult.longitude

        distance=vincenty((scpinlat, scpinlon),(pinlat,pinlon)).kilometers

        return distance

    except:

        return '-'


# In[5]:



import pyodbc
cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=PYTHON_DB;UID=PythonOnline;PWD=P@ssw0rd123$")

# In[6]:

scdetails = pd.read_sql("SELECT SC,[Name of SC],Type,Pincode FROM branchmaster",cnxn)
hubdetails = pd.read_sql("SELECT HUB,[Hub Name],[Location Status],Pincode FROM hubmaster",cnxn)
hubdetails.columns=scdetails.columns
scdetails=scdetails.append(hubdetails)


# In[7]:

scpindict={}
for i in zip(scdetails["SC"],scdetails["Pincode"]):
    scpindict.update({i[0]:i[1]})


# In[8]:

senddf['distance']=senddf.apply(lambda x:getdist(scpindict.get(x['Hub SC Location']),scpindict.get(x['NextLoc'])),axis=1)


# In[9]:

senddf['Act Wt In Tonnes']=pd.np.round(senddf['Act Wt In Tonnes'],1)
senddf = senddf.rename(columns={'Act Wt In Tonnes':'ACTWT','Con Number':'Cons'})

# In[11]:

senddf1=senddf[senddf['distance']>500]
senddf2=senddf[senddf['distance']<500]
del senddf1['distance']
del senddf2['distance']


# In[12]:

reportts = datetime.now()
opfilevar=reportts.date()
opfilevar1=reportts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=np.round((float(currhrs)/60),0)


# In[13]:

intransitdf.to_csv(r'D:\Data\Load Available\data\intransit'+ str(opfilevar)+"-"+str(opfilevar2)+'.csv')
invdf.to_csv(r'D:\Data\Load Available\data\inventory'+ str(opfilevar)+"-"+str(opfilevar2)+'.csv')
invdf_correct.to_csv(r'D:\Data\Load Available\Load_available\Load_available_'+ str(opfilevar)+"-"+str(opfilevar2)+'.csv')
invdf_correct.to_csv(r'D:\Data\Load Available\Load_available\Load_available.csv')
mergedf.to_csv(r'D:\Data\Load Available\Load_available\mergedf'+ str(opfilevar)+"-"+str(opfilevar2)+'.csv')
filepath = r'D:\Data\Load Available\Load_available\Load_available.csv'


print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = filepath
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()

# In[14]:
loadavailabledf['Timestamp']=datetime.now()
mergedf.to_csv(r'D:\Data\Load Available\Mergedf\incorrect_'+ str(opfilevar)+"-"+str(opfilevar2)+'.csv')
#filepath='D:\Data\Load Available\incorrect'+ str(opfilevar)+"-"+str(opfilevar2)+'.csv'
loadavailabledf.to_csv(r'D:\Data\Load Available\Mergedf\loadavailable_'+ str(opfilevar)+"-"+str(opfilevar2)+'.csv')
filepath=r'D:\Data\Load Available\Mergedf\loadavailable_'+ str(opfilevar)+"-"+str(opfilevar2)+'.csv'
# In[15]:

TO=["hubmgr_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in","cnm@spoton.co.in"]
# TO=['sqtf@spoton.co.in','supratim@iepfunds.com','ankit@iepfunds.com','vishwas.j@spoton.co.in','pawan.sharma@spoton.co.in','krishna.chandrasekar@spoton.co.in','prasanna.hegde@spoton.co.in']
# TO=['mahesh.reddy@spoton.co.in']
FROM='reports.ie@spoton.co.in'
CC=['sqtf@spoton.co.in','rajesh.kapase@spoton.co.in','mahesh.reddy@spoton.co.in','shashvat.suhane@spoton.co.in','syed.hussain@spoton.co.in','abhik.mitra@spoton.co.in']
BCC = ['yogesh.singh@spoton.co.in',"sq_spot@spoton.co.in",'prabhakar.mahajan@spoton.co.in','nitin.tatyarao@spoton.co.in','vinodkumar.mishra@spoton.co.in','jai.prakash@spoton.co.in','nomesh.ganvir@spoton.co.in','sanjay.panse@spoton.co.in','sunil.khare@spoton.co.in','OPS.HUB.AMDH.1@spoton.co.in','aditya.shekhar@spoton.co.in','chidananda.biswal@spoton.co.in','virendra.singh@spoton.co.in','dhruvnarayan.tiwari@spoton.co.in','anilkumar.mishra@spoton.co.in','anoop.kumar@spoton.co.in','avnish.tripathi@spoton.co.in']
# CC=['vishwas.j@spoton.co.in']
# BCC=['shashvat.suhane@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "Load Available Report -"+ str(opfilevar)+"-"+str(opfilevar2)
html='''<html>
<h4>Dear All,</h4>
<br>Number of cons in inventory='''+str(invcons)+'''</br>
<br>Number of cons in stock as well as intransit='''+str(commoncons)+'''</br>
<p>For the conlevel data, please use the link http://spoton.co.in/downloads/IEProjects/ETA/Load_available.csv </p>
<p>PFB the weight which are available in stock where distance between two location greater than 500  </p>
<br>'''+senddf1.to_html()+'''<br><p>PFB the weight which are available in stock where distance between two location less than 500</p></br>'''+senddf2.to_html()+'''</html>'''
# report=""
# # report+='<br>'
# report+='PFB the weight which are available in stock where distance between two location less than 500'
# # report+='<br>'
# report+=''
# report+='<br>'+senddf2.to_html()+'<br>'
klm=MIMEText(html,'html')
msg.attach(klm)
# bcd=MIMEText(senddf1.to_html(),'html')
# msg.attach(bcd)
# abc=MIMEText(report,'html')
# msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()


# except:
#   TO=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
#   FROM="mahesh.reddy@spoton.co.in"
#   msg = MIMEMultipart()
#   msg["From"] = FROM
#   msg["To"] = ",".join(TO)
#   #msg["CC"] = ",".join(CC)
#   #msg["BCC"] = ",".join(BCC)
#   #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
#   msg["Subject"] = "Load Available Report Error in Execution" 
#   report=""
#   report+='Hi,'

#   report+='<br>'
#   report+='There was some error in Load Available Report.'
#   report+='<br>'

#   abc=MIMEText(report.encode('utf-8'),'html')
#   msg.attach(abc)
#   server=smtplib.SMTP('smtp.sendgrid.net', 587)
#   server.ehlo()
#   server.starttls()
#   server.ehlo()
#   server.login("spoton.net.in", "Star@123#")
#   failed = server.sendmail(FROM, TO, msg.as_string())
#   server.quit()
