
# coding: utf-8

# In[ ]:


import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
from datetime import datetime, timedelta
#import datetime
import os
# import Utilities


# In[ ]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()


# In[ ]:

try:
  query = ("""
      ( SELECT    TC.thcno AS ThcNo ,
         CASE WHEN ISNULL(vs.SourceCode,'') = ''
     THEN TC.sourcehb 
     ELSE
         vs.SourceCode
     END sourcehb, 

      CASE WHEN ISNULL(vs.DestinationCode,'') = ''
     THEN TC.tobh_code 
     ELSE
         vs.DestinationCode
     END tobh_code, 

          TC.routety ,
          CASE WHEN TC.routety = 'D' THEN GETDATE()
               ELSE dbo.UFN_GET_THC_ARRCTIME_ASPER_GPS_CNM_NEW(TC.thcno,
                                                            NULL)
          END AS ArrivalTime_ASPER_GPS_CNM ,
          CAST(CONVERT(VARCHAR, hd2.actarrv_dt, 112) + ' ' + hd2.actarrv_tm AS SMALLDATETIME) Arrivaltime ,
          TR.TCHDRFLAG ,
          CASE WHEN hd2.tobh_code IS NULL THEN 'Y'
               WHEN hd2.tobh_code = 'Null' THEN 'Y'
               ELSE 'N'
          END AlreadyArrived ,
          SUM(d.ACTUWT) AS ld_actuwt
  FROM       THCHDR TC WITH ( NOLOCK )

          LEFT OUTER JOIN tbl_VehicleRunningStatus_New vs WITH ( NOLOCK ) ON vs.ThcNo = TC.thcno

          LEFT OUTER JOIN THCHDR hd2 WITH ( NOLOCK ) ON TC.thcno = hd2.thcno
                                                        AND TC.tobh_code = hd2.sourcehb
          LEFT OUTER JOIN dbo.TCHDR TR WITH ( NOLOCK ) ON TR.THCNO = TC.thcno
                                                          AND TR.ToBH_CODE = TC.tobh_code
          LEFT OUTER  JOIN dbo.TCTRN d WITH ( NOLOCK ) ON d.TCNO = TR.TCNO
  WHERE     TC.actarrv_dt >= CONVERT(DATE, GETDATE() - 15)
        --  AND TC.tobh_code = 'BLRH'
          AND TC.tobh_code <> 'Null'
          AND ( hd2.thcno IS  NULL
                OR TR.TCHDRFLAG = 'Y'
              )--INCLUDE THE CONS WHICH ARE NOT INSCANNED YET   
          AND hd2.sourcehb IS NOT NULL -- TO GET ONLY ARRIVED THC's
  --	AND tc.thcno = 'NTDELHX0073861'
  GROUP BY  TC.thcno ,

          TC.sourcehb ,
          TC.tobh_code ,
          TC.routety ,
          hd2.actarrv_dt ,
          hd2.actarrv_tm ,
          TR.TCHDRFLAG ,
          hd2.tobh_code,vs.SourceCode, vs.DestinationCode
  )
      """)


  # In[ ]:


  veh_pileup_df = pd.read_sql(query, cnxn)


  # In[ ]:


  len(veh_pileup_df)


  # In[ ]:


  veh_pileup_df = veh_pileup_df.drop_duplicates(subset='ThcNo')
  veh_pileup_df = veh_pileup_df.drop(['TCHDRFLAG'],axis=1)
  veh_pileup_df = veh_pileup_df[veh_pileup_df['routety']!='D']
  corehublist = ['AMCH','AMDH','BLRH','BOMH','BRGH','CCUH','DELH','HYDH','MAAH','NAGH','PNQH','VPIH','VZAH','SXVF','IDRH','CJBH','GAUB','GAUH','COKB','JAIH','BGMH','PATF','PATH','BBIH','IXRB']
  veh_pileup_df = veh_pileup_df[veh_pileup_df['AlreadyArrived']=='Y']


  # In[ ]:


  ts= datetime.now()
  opfilevar=ts.date()
  opfilevar1=ts.time()
  ct2= str (opfilevar1)
  currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60
  opfilevar2=pd.np.round(float(currhrs)/60)
  veh_pileup_df.loc[veh_pileup_df.index,'CurrentTime'] = ts


  # In[ ]:


  def diffhr(currtime,arrivetime):
      diff = (currtime - arrivetime)
      return pd.np.round(diff.total_seconds()/3600,1)
  #return diffhrs
  def get3hrscount(timediff):
      if timediff>3:
          return 1
      else:
          return 0


  # In[ ]:


  veh_pileup_df['Time_diff'] = veh_pileup_df.apply(lambda x:diffhr (x['CurrentTime'],x['Arrivaltime']),axis=1)
  veh_pileup_df['>3Hrs'] = veh_pileup_df.apply(lambda x:get3hrscount (x['Time_diff']),axis=1)
  veh_pileup_df_grp = veh_pileup_df.groupby(['sourcehb','tobh_code']).agg({'ThcNo':len,'ld_actuwt':sum,'Time_diff':sum,'>3Hrs':sum}).reset_index()
  veh_pileup_df_grp['WtTimeDiff'] = veh_pileup_df_grp.apply(lambda x:pd.np.round((x['Time_diff']/x['ThcNo']),1),axis=1)
  veh_pileup_df_grp = pd.DataFrame(veh_pileup_df_grp,columns=['sourcehb','tobh_code','ThcNo','ld_actuwt','WtTimeDiff','>3Hrs'])
  veh_pileup_df_grp = veh_pileup_df_grp.rename(columns={'tobh_code':'LOC','ld_actuwt':'Wt(T)'})


  # In[ ]:


  def loadroundoff(wt):
      wt_in_ton = pd.np.round(wt/1000.0,1)
      return wt_in_ton

  veh_pileup_df_grp['Wt(T)'] = veh_pileup_df_grp.apply(lambda x:loadroundoff(x['Wt(T)']),axis=1)
  veh_pileup_df_grp = veh_pileup_df_grp.sort_values('Wt(T)',ascending=False)
  try:
      veh_pileup_df['ArrivalTime_ASPER_GPS_CNM'] = veh_pileup_df.apply(lambda x:datetime.strftime(x['ArrivalTime_ASPER_GPS_CNM'],"%Y-%m-%d %H:%M:%S"),axis=1)
  except:
      pass
  veh_pileup_df['Arrivaltime'] = veh_pileup_df.apply(lambda x:datetime.strftime(x['Arrivaltime'],"%Y-%m-%d %H:%M:%S"),axis=1)
  veh_pileup_df['CurrentTime'] = veh_pileup_df.apply(lambda x:datetime.strftime(x['CurrentTime'],"%Y-%m-%d %H:%M:%S"),axis=1)


  # In[ ]:


  len(veh_pileup_df)


  # In[ ]:


  cnxn1 = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=PYTHON_DB;UID=PythonOnline;PWD=P@ssw0rd123$")


  # In[ ]:


  cursor1=cnxn1.cursor()


  # In[ ]:


  veh_pileup_df.rename(columns={'>3Hrs':'greater3Hrs'},inplace=True)


  # In[ ]:


  print (len(veh_pileup_df))

  # In[ ]:

  cnxn1.autocommit = True

  for u in range (0,len(veh_pileup_df)):
      thcno = veh_pileup_df.iloc[u]['ThcNo']
      sourcehb = veh_pileup_df.iloc[u]['sourcehb']
      tobh_code = veh_pileup_df.iloc[u]['tobh_code']
      routety= veh_pileup_df.iloc[u]['routety']
      gpsarrivaltime = veh_pileup_df.iloc[u]['ArrivalTime_ASPER_GPS_CNM']
      arrivaltime = veh_pileup_df.iloc[u]['Arrivaltime']
      alreadyarrived = veh_pileup_df.iloc[u]['AlreadyArrived']
      actwt = veh_pileup_df.iloc[u]['ld_actuwt']
      currentime= veh_pileup_df.iloc[u]['CurrentTime']
      timediff = veh_pileup_df.iloc[u]['Time_diff']
      grhours = veh_pileup_df.iloc[u]['greater3Hrs']
      grhours=str(grhours)
      #print (thcno, sourcehb, tobh_code, routety, gpsarrivaltime, arrivaltime, alreadyarrived, actwt, currentime, timediff, grhours)
      
      #print (cursor.execute("""INSERT INTO  instructions (Origin, Destination, Path, ORG REG, DEST REG) values (?, ?, ?, ?, ?)""",(origin, dest, path, orgreg, destreg)))
      cursor1.execute("""INSERT INTO  vehiclepileup (ThcNo, sourcehb, tobh_code, routety, ArrivalTime_ASPER_GPS_CNM, Arrivaltime, AlreadyArrived, ld_actuwt, CurrentTime, Time_diff, greater3Hrs) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                     (thcno, sourcehb, tobh_code, routety, gpsarrivaltime, arrivaltime, alreadyarrived, actwt, currentime, timediff, grhours))
  cursor1.commit()


  # In[ ]:

except:
  TO=['mahesh.reddy@spoton.co.in']  
  #CC=[]
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  #msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "ERROR Report" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in vehiclepileup data uploading.'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO, msg.as_string())
  server.quit()


