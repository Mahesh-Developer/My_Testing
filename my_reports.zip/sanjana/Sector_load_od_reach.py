# -*- coding: utf-8 -*-
"""
Created on Mon Aug 08 10:17:29 2016

@author: rajeeshv
"""

import pandas as pd

sectorloaddata = pd.read_csv(r'D:\Data\Sector_load_july16.csv')

print len(sectorloaddata)

sectorloaddata_pivot = pd.pivot_table(sectorloaddata,index=['Hub SC Location','Nextloc'],columns=['reached'],values=['Con Number'],aggfunc=len).reset_index()
sectorloaddata_pivot.to_csv(r'D:\Data\Sector_load_july16_summary.csv')