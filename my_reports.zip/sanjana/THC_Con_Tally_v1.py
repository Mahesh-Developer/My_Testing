
# coding: utf-8

# In[1]:

import pandas as pd
from datetime import datetime, timedelta
from pandas import ExcelWriter

import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import os
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import Utilities

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.87;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()

outgoingquery = ("""EXEC USP_THC_OUTGOING_SCAN_REPORT  """)
print (outgoingquery)
outscandata = pd.read_sql(outgoingquery, Utilities.cnxn)

incomingquery = ("""EXEC USP_THC_INCOMING_SCAN_REPORT  """)
print (incomingquery)
inscandata = pd.read_sql(incomingquery, Utilities.cnxn)
inscandata.rename(columns={'IS HUB Y/N':'IS HUB Y N','Coming_From_Loc':'Coming From Loc','THC Rec Time':'THC Rec Time','Incoming_THC':'Incoming THC','INSCAN_Y_N':'INSCAN Y N','Scanning_Location':'Scanning Location','PickupDate':'Pickup Date','Org_Brcd':'Org Brcd','Org_Name':'Org Name','Reassign_Brcd':'Reassign Brcd','Reassign_BrName':'Reassign Br Name'},inplace=True)
outscandata.rename(columns={'PickupDate':'Pickup Date','Org_Brcd':'Org Brcd','Org_Name':'Org Name','Reassign_Brcd':'Reassign Brcd','Reassign_BrName':'Reassign Br Name','Scanning_Location':'Scanning Location','OUTSCAN_Y_N':'OUTSCAN Y N','Outgoing_THC_NO':'Outgoing THC NO','THC Preparation Time':'THC Preparation Time','OutGoing_From_Loc':'Out Going From Loc','IS HUB Y/N':'IS HUB Y N'},inplace=True)
# In[2]:

# inscandata = pd.io.excel.read_excel(r'http://spoton.co.in/downloads/IEP_THC_INCOMING_OUTGOING_SCAN/IEP_THC_INCOMING_OUTGOING_SCAN.xls','THC Incoming Scan Report')
# outscandata = pd.io.excel.read_excel(r'http://spoton.co.in/downloads/IEP_THC_INCOMING_OUTGOING_SCAN/IEP_THC_INCOMING_OUTGOING_SCAN.xls','THC Outgoing Scan Report')


# In[3]:

datetoday = datetime.today()
datefilter = datetoday-timedelta(hours=24)
datefilter=datefilter.date()
datefilter

with ExcelWriter(r'D:\Data\THC_Inscan_Outscan_Tally\Basedata\THC_Inscan_Outscan_Tally_'+str(datefilter)+'.xlsx') as writer:
    inscandata.to_excel(writer, sheet_name='THC Incoming Scan Report',engine='xlsxwriter')
    outscandata.to_excel(writer, sheet_name='THC Outgoing Scan Report',engine='xlsxwriter')


# In[4]:

inscanpivot = pd.pivot_table(inscandata,index='Scanning Location',columns=['INSCAN Y N'],values=['DOCKNO'],aggfunc=len,fill_value=0.0).reset_index()


# In[5]:

inscanpivot.columns = [' '.join(col).strip() for col in inscanpivot.columns.values]
inscanpivot = inscanpivot.rename(columns={'DOCKNO N':'Not_Scanned_In','DOCKNO Y':'Scanned_In'})


# In[6]:

def scanperc(scan,total):
    scanperge = pd.np.round((scan*1.0/total)*100.0,0)
    return scanperge


# In[7]:

inscanpivot['Total_Inscan'] = inscanpivot.apply(lambda x:(x['Not_Scanned_In']+x['Scanned_In']),axis=1)
inscanpivot['Inscan%'] = inscanpivot.apply(lambda x:scanperc(x['Scanned_In'],x['Total_Inscan']),axis=1)


# In[8]:

outscanpivot = pd.pivot_table(outscandata,index='Scanning Location',columns=['OUTSCAN Y N'],values=['DOCKNO'],aggfunc=len,fill_value=0.0).reset_index()
outscanpivot.columns = [' '.join(col).strip() for col in outscanpivot.columns.values]
outscanpivot = outscanpivot.rename(columns={'DOCKNO N':'Not_Scanned_Out','DOCKNO Y':'Scanned_Out'})


# In[9]:

outscanpivot['Total_Outscan'] = outscanpivot.apply(lambda x:(x['Not_Scanned_Out']+x['Scanned_Out']),axis=1)
outscanpivot['Outscan%'] = outscanpivot.apply(lambda x:scanperc(x['Scanned_Out'],x['Total_Outscan']),axis=1)


# In[10]:

scanreport = pd.merge(inscanpivot,outscanpivot,on=['Scanning Location'],how='outer')
scanreport = scanreport.fillna(0)


# In[11]:

scanreport['Total_Cons'] = scanreport.apply(lambda x:(x['Total_Inscan']+x['Total_Outscan']),axis=1)
scanreport['Total_Scanned_Cons'] = scanreport.apply(lambda x:(x['Scanned_In']+x['Scanned_Out']),axis=1)
scanreport['Total_Scan%'] = scanreport.apply(lambda x:scanperc(x['Total_Scanned_Cons'],x['Total_Cons']),axis=1)
scanreport = scanreport.sort_values('Total_Cons',ascending=False)

scanreport.loc[scanreport.index,'TIMESTAMP'] = datefilter

scanreport = scanreport.rename(columns={'Scanning Location':'Locn'})

# In[12]:
scanreport = scanreport[['Locn','Total_Inscan','Not_Scanned_In','Scanned_In','Inscan%','Total_Outscan','Not_Scanned_Out','Scanned_Out','Outscan%','Total_Cons','Total_Scanned_Cons','Total_Scan%','TIMESTAMP']]
scanreport.to_csv(r'D:\Data\THC_Inscan_Outscan_Tally\Summary\THC_Inscan_Outscan_Report_'+str(datefilter)+'.csv',index=False)


# In[13]:

scanreport_summary = scanreport[['Locn','Inscan%','Outscan%','Total_Scan%','TIMESTAMP']]
scanreport_summary.to_csv(r'D:\Data\THC_Inscan_Outscan_Tally\Email_summary\THC_Inscan_Outscan_Summary_'+str(datefilter)+'.csv',index=False)

scanreport_email = scanreport_summary[['Locn','Inscan%','Outscan%','Total_Scan%']].head(15)
scanreport_email = scanreport_email.to_string(index=False)


# In[14]:

with ExcelWriter(r'D:\Data\THC_Inscan_Outscan_Tally\Total_Summary\THC_Inscan_Outscan_Summary_'+str(datefilter)+'.xlsx') as writer:
    scanreport.to_excel(writer, sheet_name='Inscan_Outscan_Report',engine='xlsxwriter')
    scanreport_summary.to_excel(writer, sheet_name='Summary',engine='xlsxwriter')
    
with ExcelWriter(r'D:\Data\THC_Inscan_Outscan_Tally\THC_Inscan_Outscan_Summary.xlsx') as writer:
    scanreport.to_excel(writer, sheet_name='Inscan_Outscan_Report',engine='xlsxwriter')
    scanreport_summary.to_excel(writer, sheet_name='Summary',engine='xlsxwriter')
    
oppath2 = r'D:\Data\THC_Inscan_Outscan_Tally\THC_Inscan_Outscan_Summary.xlsx'


# In[16]:

filePath = oppath2
def sendEmail(TO = ["aom_spot@spoton.co.in","dom_spot@spoton.co.in","HUBMGR_SPOT@spoton.co.in"],
            #TO = ["mahesh.reddy@spoton.co.in"],
            #TO = ["vishwas.j@spoton.co.in"],
            #CC = ["mahesh.reddy@spoton.co.in"],
            CC = ["rom_spot@spoton.co.in","abhik.mitra@spoton.co.in","Pawan.Sharma@Spoton.Co.In","Jothi.Menon@Spoton.Co.In","Rajesh.Kumar@Spoton.Co.In","Shivananda.P@Spoton.Co.In","rajeesh.vr@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "SERVER ETA FTP" + " - " + str(reportts)
    msg["Subject"] = "Con Inscan Outscan Tally Report" + " - " + str(datefilter)
    body_text = """
    Dear All,

    PFA the Con Inscan Outscan Tally Report for """ + str(datefilter) +"""
    
    PFB the summary. The below summary is the TOP 15 locations based on the total cons handled. The complete summary is attached in the email"""+str()+"""

"""+str(scanreport_email)+"""
    
    The cons considered for the report are, for Incoming, all the THCs whose actual arrival was yesterday and for outgoing, all the THCs whose actual departures was yesterday
    
    For the conwise details, please download the file from the below link
    
    http://spoton.co.in/downloads/IEP_THC_INCOMING_OUTGOING_SCAN/IEP_THC_INCOMING_OUTGOING_SCAN.xls
    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    #server=smtplib.SMTP('124.7.138.249', 587)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
mailend = datetime.now().time()
print 'mailend is', mailend


# In[ ]:
