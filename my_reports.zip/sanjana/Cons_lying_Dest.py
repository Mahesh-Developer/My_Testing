
# coding: utf-8

# In[ ]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta
import sys

reload(sys).setdefaultencoding("ISO-8859-1")

# In[ ]:


# cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")


# # In[ ]:


# cursor=cnxn.cursor()


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()

# In[ ]:


query=("""SELECT  --TOP 10
        A.DOCKNO ,
        B.DOCKDT BOOKINGDATE ,
        A.ACTUWT ,
        PIECES ,
        DEST_BRCD ,
        DEST_BRNM ,
        DEST_AREA ,
        DEST_DEPOT ,
        DEST_REGION ,
        DEL_LOCATION_TYPE ,
        VTC ,
        FTC ,
        DACC ,
        DC ,
        A.CSGECD ,
        A.CSGENM ,
        ARRV_AT_DEST_SC ,
        REPORTDATE_MIN_ARRVDT ,
        A.CSGNCD ,
        A.CSGNNM ,
        ORG_BRCD ,
        ORG_BRNM ,
        ORG_AREA ,
        ORG_DEPOT ,
        ORG_REGION ,
        A.DECLVAL ,
        DEST_PINCODE ,
        ConStatusCategory ,
        ConStatusCode ,
        ConStatusDesc ,
        ConStatusReason ,
        ConStatusDate ,
        LogDate ,
        FreeStorageDays ,
        CON_BLOCKED_FOR_PAY_ISSUES ,
        PARENTCODE ,
        PARENTNAME ,
        CON_BLOCKED_FOR_ODA_PIN_ISSUES ,
        CON_BLOCKED_FOR_DEMURRAGE ,
        TTS_AuditStatus ,
        TTS_AuditRemarks ,
        ReportGenConStatusDate ,
        IsTTSTicketRaised ,
        IsApptmntDel ,
        ApptmntDelDate ,
        A.CDELDT DUEDATE ,
        LatestTicketStatus ,
        LatestTicketStatusCode ,
        DEMURRAGE_RESPONSIBILITY ,
        ( SELECT    dbo.UFN_GET_CSAGENTCODE(A.DOCKNO)
        ) AGENTCODE ,
        C.EMPNM AGENTNAME
FROM    dbo.tblOCIDClosingStock A
        INNER JOIN dbo.DOCKET B WITH ( NOLOCK ) ON B.DOCKNO = A.DOCKNO
        LEFT OUTER JOIN dbo.EMPMST C ON C.EMPCD = ( SELECT  dbo.UFN_GET_CSAGENTCODE(A.DOCKNO)
                                                  )
WHERE   LogDate = CONVERT(DATE, GETDATE())
        AND ConStatusCategory IN ( 'RECEIVER FAILURE', 'SENDER FAILURE' )
        AND ConStatusCode NOT IN ( 'UCG', 'UG1', 'UG2', 'UG3', 'SSC' )
        AND B.DOCKDT >= 0     """)


# In[ ]:


data=pd.read_sql(query,Utilities.cnxn)


# In[ ]:


# data = pd.read_excel(r'E:\RAJESH M P\RAJESH M P\a Rajesh M P\Reports\Closing stock\cons of lying @ destn SC\CCF_cons_lying@Destn_SC.xlsx','Data')


# In[ ]:


pivot = pd.pivot_table(data,index=["PARENTNAME"],values=["DOCKNO"],aggfunc={"DOCKNO":len},fill_value=0,margins=False).reset_index()


# In[ ]:


pivot.head(8)


# In[ ]:


pivot=pivot.sort_values(by='DOCKNO',ascending=False)


# In[ ]:


pivot.head(8)


# In[ ]:


pivot = pivot.reset_index(drop=True)


# In[ ]:


pivot.head(9)


# In[ ]:


from pandas import ExcelWriter


# In[ ]:


with ExcelWriter(r'D:\Data\ODA_Loads_Ton_wise\CCF_lying_at_Dest.xlsx') as writer:
       pivot.to_excel(writer, sheet_name='pivot',engine='xlsxwriter')
       data.to_excel(writer, sheet_name='Data',engine='xlsxwriter')


# In[ ]:


writer = pd.ExcelWriter(r'D:\Data\ODA_Loads_Ton_wise\CCF_lying_at_Dest.xlsx', engine='xlsxwriter')
pivot.to_excel(writer, sheet_name='pivot',index=False)
data.to_excel(writer, sheet_name='Data',index=False )
# workbook = writer.book
worksheet = writer.sheets['pivot']
worksheet.set_column('A:A', 40)

worksheet1= writer.sheets['Data']
worksheet1.set_column('A:AZ',20)
# total_fmt = workbook.add_format({'align': 'right', 'num_format': '$#,##0',
#                                  'bold': True, 'bottom':6})

writer.save()


# In[ ]:


filepath=r'D:\Data\ODA_Loads_Ton_wise\CCF_lying_at_Dest.xlsx'


# In[ ]:


import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback

oppath1=filepath
#FTP Upload starts
print ('Logging in...')
ftp = ftplib.FTP()  
ftp.connect('10.109.230.50')  
print (ftp.getwelcome())
try:  
    try:  
        ftp.login('HOSQTeam', 'Te@mH0$q')
        print ('login done')
        ftp.cwd('Auto_reports')  
        #ftp.cwd('FIFO')
        # move to the desired upload directory  
        print ("Currently in:", ftp.pwd()) 
        print ('Uploading...')  
        fullname = oppath1
        name = os.path.split(fullname)[1]  
        f = open(fullname, "rb")  
        ftp.storbinary('STOR ' + name, f)  
        f.close()  
        print ("OK"  )
        print ("Files:")  
        print (ftp.retrlines('LIST'))
    finally:  
        print ("Quitting...")
        ftp.quit()  
except:  
    traceback.print_exc()


# In[ ]:


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.MIMEBase import MIMEBase
from email import Encoders
import os

from_addr = 'mis.ho@spoton.co.in'
to_addr = ['spot_cstl@spoton.co.in','sharmistha.majumdar@spoton.co.in']
#to_addr = ['rajesh.mp@spoton.co.in','mahesh.reddy@spoton.co.in']
#cc_addr = ['imrajeshmp@gmail.com']
cc_addr = ['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in']
bcc_addr = ['rajesh.mp@spoton.co.in']

username = 'mis.ho@spoton.co.in'
password = 'Mis@2019'

msg = MIMEMultipart()

msg['From'] = from_addr
msg['To'] = ', '.join(to_addr)
msg['bcc'] = ', '.join(bcc_addr)
msg['cc'] = ', '.join(cc_addr)
msg['Subject'] = 'CCF cons lying @ Destn SC.'
html='''<html>
<h4>Dear ,CS Team</h4>
</html>'''

html1='''<h5>Thanks & Regards</h5></b>
<h5>HO-SQ</h5>'''

# part10=MIMEText(html1,'html')
#  <h5>Rajesh M P </h5></b>
# msg.attach(part10)
html3='''
<h5> To download the CCF cons which is lying at Destn SC, Please click the link below </h5>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/CCF_lying_at_Dest.xlsx"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/CCF_lying_at_Dest.xlsx</p></b>
'''

report=""
report+=html
report+='<br>'
report+=html3
report+='<br>'
report+=html1
abc=MIMEText(report,'html')
msg.attach(abc)

server = smtplib.SMTP('smtp.sendgrid.net',587)
part=MIMEBase('application','octet-stream')

#part.set_payload(open(filepath,'rb').read())
#Encoders.encode_base64(part)
#part.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath))
#msg.attach(part)

server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
server.sendmail(from_addr,to_addr+cc_addr+bcc_addr,msg.as_string())
print ('mail sent succesfully')
server.quit()

