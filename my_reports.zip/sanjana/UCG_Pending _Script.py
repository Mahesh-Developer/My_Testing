
# coding: utf-8

# In[18]:


import numpy as np
import pandas as pd
# import matplotlib.pyplot as plt
# import seaborn
from glob import glob
from IPython import display
from datetime import datetime,timedelta
import pyodbc
# import geopy
import pandas as pd
import Utilities

# In[19]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


# In[7]:
yest=datetime.now()-timedelta(0)
enddate=yest.date()
enddate=str(enddate)+' 23:59:00'

startdate=datetime.strftime((datetime.today().replace(day=1,month=1,year=2019)),'%Y-%m-%d')

query= '''    
EXEC USP_UCG_GET_LETTERS_REPORT 'ALL','ALL','ALL','{0}','{1}','ALL','ALL'    
'''.format(startdate,enddate)

# query= '''    
# EXEC USP_UCG_GET_LETTERS_REPORT 'ALL','ALL','ALL','2018-01-01','2019-02-24','ALL','ALL'    
# '''


# In[8]:


table=pd.read_sql(query,Utilities.cnxn)


# In[9]:


table.columns


# In[10]:


# T=table[table.UCGApprovalStatus == 'Pending']
# ta=table[[table.UCGNotice != 'Final Notice'],[table.UCGApprovalStatus== 'Pending']]

Ta=table[table.UCGNotice != 'Final Notice']
tab=Ta[Ta.UCGApprovalStatus == 'Pending']
# piv=piv[piv[('FinalStatusDate')]== 'Nan']
ta=tab[tab.FinalStatusDesc != 'DELIVERED']
T=ta[ta.CurrentLocationDepot == 'HYDD']
# ta.groupby(['CurrentLocationDepot'])
T


# In[11]:


# ta[['CurrentLocationDepot','UCGNotice']]


# In[12]:


# piv=pd.pivot_table(ta,index=["UCGApprovalStatus", "CurrentLocationDepot","FinalStatusDesc"],
# piv=piv[piv[('UCGApprovalStatus')]== 'Pending']
# # piv=piv[piv[('FinalStatusDate')]== 'Nan']
# piv=piv[piv[('UCGApprovalStatus')]!= 'DELIVERED']

#"CurrentLocationDepot",


# In[13]:


piv=pd.pivot_table(ta,index=["CurrentLocationDepot"],
                   columns=['UCGNotice'], 
                   values=['ConNumber'], 
                   aggfunc={'ConNumber':len}, 
                  margins=True, margins_name= 'Grand Total' ).fillna(0)
piv


# In[14]:


# from pandas import ExcelWriter
# with ExcelWriter(r"E:\UCG_NoticePendingSYST.xlsx") as writer:
#     piv.to_excel(writer, sheet_name='Data',engine='xlsxwriter')
# print('file created')

piv.to_csv(r'D:\Data\UCG\UCG_NoticePendingSYST.csv')
# In[15]:


import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback
from glob import glob
from IPython import display
from datetime import datetime,timedelta
import pyodbc

date=datetime.strftime(datetime.now(),'%Y-%m-%d-%H')


# In[16]:


filepath=r'D:\Data\UCG\UCG_NoticePendingSYST.csv'


# In[17]:


oppath1=filepath
#FTP Upload starts
print ('Logging in...')
ftp = ftplib.FTP()  
ftp.connect('10.109.230.50')  
print (ftp.getwelcome())

try:
 try:
     ftp.login('HOSQTeam', 'Te@mH0$q')
     print ('login done')
     ftp.cwd('Auto_reports')
     #ftp.cwd('FIFO')
     # move to the desired upload directory
     print ("Currently in:", ftp.pwd())
     print ('Uploading...')
     fullname = oppath1
     name = os.path.split(fullname)[1]
     f = open(fullname, "rb")
     ftp.storbinary('STOR ' + name, f)
     f.close()
     print ("OK"  )
     print ("Files:")
     print (ftp.retrlines('LIST'))
 finally:
     print ("Quitting...")
     ftp.quit()
except:
    traceback.print_exc()
    
#date=datetime.strftime(datetime.now(),'%Y-%m-%d %H:%M:%S')


# ----------- E M A I L --------------------------    
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template                    


TO=['AOM_SPOT@spoton.co.in','DOM_SPOT@spoton.co.in','ROM_SPOT@spoton.co.in','SC_incharge@spoton.co.in']
# TO = ['sanjana.narayana@spoton.co.in']

FROM="mis.ho@spoton.co.in"
CC = ['SQ_SPOT <SQ_SPOT@spoton.co.in','rajesh.kumar@spoton.co.in','pawan.sharma@spoton.co.in','prafulla.masurkar@spoton.co.in','jothi.menon@spoton.co.in','shivananda.p@spoton.co.in']


# CC = ['sanjana.narayana@spoton.co.in']

BCC = ['sanjana.narayana@spoton.co.in']


msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = " UCG 1st/ 2nd/ Reminder notices pending in the system.  " + " - " + str(date)
html='''<html>
<style>        
p
 {
   margin:0;
   margin-top: 5px;
   padding:0;
   font-size:15px;
   line-height:20px;
 }
</style>                


'''
html3='''
<h5> To download UCG_NoticePendingSYST.xlsx, Please click the link below </h5>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/UCG_NoticePendingSYST.xlsx"</a>
"http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/UCG_NoticePendingSYST.xlsx</p>
'''
report=""
report+='<br>'
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='Please find summary of UCG 1st/ 2nd/ Reminder notices pending in the system.'
report+='<br>'
report+='<br>'+piv.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(oppath1,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
#msg.attach(part1)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
print ('mail sent')
server.quit()

