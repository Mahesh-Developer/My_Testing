
# coding: utf-8

# In[1]:


import pandas as pd
import pyodbc
from datetime import datetime,timedelta
from datetime import datetime,timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
import ftplib
from calendar import monthrange
import smtplib


# In[2]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()


# In[3]:


startdate=datetime.strftime((datetime.now()-timedelta(days=1)).replace(day=1),"%Y-%m-%d")
startdate


# In[4]:


enddate=datetime.strftime(datetime.now()-timedelta(days=1),"%Y-%m-%d")
enddate


# In[5]:


query=("""SELECT  A.Dockno COnNumber,
C.BrCode BranchCode,
C.HandMFNO ManifestNumber,
D.AckId AcknowledgementNumber,
D.CreatedBy ACK_PIS_by,
A.PISNO PISNumber,
F.DOCKDT PickupDate,
G.DELY_DT DeliveryDate,
A.ShipmentType,
A.CollectedAmt,
E.DocketWiseInvoiceAmount,
A.BankName,
B.ReceivedOn SCReceiveddate,
C.HandOverEmpcd Manifest_HandOverEmpcd,
B.ReceivedBy,
D.AckDate,
C.CreatedOn ManifestDate,
A.ANDROIDUSERID vendordetails,
A.PISGenerated
FROM    dbo.tblCashFTCCollectionDtls A WITH ( NOLOCK )
        INNER JOIN dbo.TblCashFTCHandOverDTLS B WITH ( NOLOCK ) ON B.Dockno = A.Dockno
        INNER JOIN dbo.TBLCashFTCHandOverHDR C WITH ( NOLOCK ) ON C.HandOverid = B.HandOverid
        LEFT JOIN dbo.TblCashFTCHandOver_Ack D WITH ( NOLOCK ) ON D.AckId = B.AckId
        LEFT JOIN dbo.tblInvoiceConMap E WITH (NOLOCK) ON A.Dockno = E.DocketNumber
        LEFT JOIN DOCKET F WITH (NOLOCK) ON A.Dockno = F.DOCKNO
        LEFT JOIN dbo.DKT_DELY G WITH (NOLOCK) ON A.Dockno = G.DOCKNO
WHERE   G.DELY_DT BETWEEN '{0}'
                  AND    '{1}'
 

""").format (startdate, enddate) 


# In[6]:


df2=pd.read_sql(query,cnxn)


# In[7]:


df1=df2[df2['ShipmentType']=='D']


# In[8]:


df1=df1[~df1['DeliveryDate'].isnull()]
df1['DocketWiseInvoiceAmount']=df1['DocketWiseInvoiceAmount'].apply(lambda x: pd.np.round(x*118)/100,0)


# In[9]:


df1['Del_Date']=df1['DeliveryDate'].apply(lambda x:str(x).split(' ')[0])


# In[ ]:

df1['Del_cons']=df1['DeliveryDate'].apply(lambda x: 0 if pd.isnull(x) else 1)


# In[ ]:

df1['Manifest']=df1['ManifestDate'].apply(lambda x:0 if x==None else 1)


# In[ ]:

df1['SCReceived']=df1['SCReceiveddate'].apply(lambda x: 0 if pd.isnull(x) else 1)


# In[ ]:

df1['PISGenerate']=df1['PISGenerated'].apply(lambda x:0 if x=='N' else 1)


# In[ ]:

df1['Ackndge']=df1['AckDate'].apply(lambda x: 0 if pd.isnull(x) else 1)


# In[ ]:

deldf=df1[df1['ShipmentType']=='D']
len(deldf)


# In[ ]:

deldf=deldf[deldf['Del_Date']>=startdate]
len(deldf)


# In[10]:


def a(Manifest,SCReceived,Ackndge,PISGenerate):
    if Manifest==0:
        return 'Delivered but manifest not done'
    else:
        if SCReceived==0:
            return 'Manifest done but not received by SC'
        else:
            if Ackndge==0:
                return 'Received by SC but Acknwledgement not done'
            else:
                if PISGenerate==0:
                    return 'Acknowlegdement done but PIS not done'
                else:
                    return 'PIS Done'
        


# In[11]:


df1['Status']=df1.apply(lambda x:a (x['Manifest'],x['SCReceived'],x['Ackndge'],x['PISGenerate']),axis=1)


# In[12]:





# In[13]:


dd1=df1[df1['Status']=='Delivered but manifest not done']
dd2=df1[df1['Status']=='Manifest done but not received by SC']
dd3=df1[df1['Status']=='Received by SC but Acknwledgement not done']
dd4=df1[df1['Status']=='Acknowlegdement done but PIS not done']


# In[14]:


dd11=dd1.pivot_table(index=['BranchCode','vendordetails'],values=['COnNumber'],aggfunc={'COnNumber':len}).reset_index()
dd21=dd2.pivot_table(index=['BranchCode','Manifest_HandOverEmpcd'],values=['COnNumber'],aggfunc={'COnNumber':len}).reset_index()
dd31=dd3.pivot_table(index=['BranchCode','ReceivedBy'],values=['COnNumber'],aggfunc={'COnNumber':len}).reset_index()
dd41=dd4.pivot_table(index=['BranchCode','ACK_PIS_by'],values=['COnNumber'],aggfunc={'COnNumber':len}).reset_index()


# # Delivered but manifest not done

# In[15]:


dd11


# # Manifest done but not received by SC(Delivery)

# In[16]:


dd21


# # Received by SC but Acknwledgement not done(Delivery)

# In[17]:


dd31


# # Acknowlegdement done but PIS not done(Delivery)

# In[18]:


dd41


# In[19]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()


# In[20]:


startdate=datetime.strftime((datetime.now()-timedelta(days=1)).replace(day=1),"%Y-%m-%d")
startdate


# In[21]:


enddate=datetime.strftime(datetime.now()-timedelta(days=1),"%Y-%m-%d")
enddate


# In[22]:


query=("""SELECT  A.Dockno COnNumber,
C.BrCode BranchCode,
C.HandMFNO ManifestNumber,
D.AckId AcknowledgementNumber,
D.CreatedBy ACK_PIS_by,
A.PISNO PISNumber,
F.DOCKDT PickupDate,
G.DELY_DT DeliveryDate,
A.ShipmentType,
A.CollectedAmt,
E.DocketWiseInvoiceAmount,
A.BankName,
B.ReceivedOn SCReceiveddate,
C.HandOverEmpcd Manifest_HandOverEmpcd,
B.ReceivedBy,
D.AckDate,
C.CreatedOn ManifestDate,
A.ANDROIDUSERID vendordetails,
A.PISGenerated
FROM    dbo.tblCashFTCCollectionDtls A WITH ( NOLOCK )
        INNER JOIN dbo.TblCashFTCHandOverDTLS B WITH ( NOLOCK ) ON B.Dockno = A.Dockno
        INNER JOIN dbo.TBLCashFTCHandOverHDR C WITH ( NOLOCK ) ON C.HandOverid = B.HandOverid
        LEFT JOIN dbo.TblCashFTCHandOver_Ack D WITH ( NOLOCK ) ON D.AckId = B.AckId
        LEFT JOIN dbo.tblInvoiceConMap E WITH (NOLOCK) ON A.Dockno = E.DocketNumber
        LEFT JOIN DOCKET F WITH (NOLOCK) ON A.Dockno = F.DOCKNO
        LEFT JOIN dbo.DKT_DELY G WITH (NOLOCK) ON A.Dockno = G.DOCKNO
WHERE   F.DOCKDT BETWEEN '{0}'
                  AND    '{1}'
 

""").format (startdate, enddate) 


# In[23]:


df3=pd.read_sql(query,cnxn)


# In[24]:


df4=df3[df3['ShipmentType']=='P']


# In[25]:


df4=df4[~df4['DeliveryDate'].isnull()]
df4['DocketWiseInvoiceAmount']=df4['DocketWiseInvoiceAmount'].apply(lambda x: pd.np.round(x*118)/100,0)


# In[26]:


df4['pick_Date']=df4['PickupDate'].apply(lambda x:str(x).split(' ')[0])


# In[ ]:

df4['pick_cons']=df4['PickupDate'].apply(lambda x: 0 if pd.isnull(x) else 1)


# In[ ]:

df4['Manifest']=df4['ManifestDate'].apply(lambda x:0 if x==None else 1)


# In[ ]:

df4['SCReceived']=df4['SCReceiveddate'].apply(lambda x: 0 if pd.isnull(x) else 1)


# In[ ]:

df4['PISGenerate']=df4['PISGenerated'].apply(lambda x:0 if x=='N' else 1)


# In[ ]:

df4['Ackndge']=df4['AckDate'].apply(lambda x: 0 if pd.isnull(x) else 1)





# In[27]:


def b(Manifest,SCReceived,Ackndge,PISGenerate):
    if Manifest==0:
        return 'Pickedup but manifest not done'
    else:
        if SCReceived==0:
            return 'Manifest done but not received by SC'
        else:
            if Ackndge==0:
                return 'Received by SC but Acknwledgement not done'
            else:
                if PISGenerate==0:
                    return 'Acknowlegdement done but PIS not done'
                else:
                    return 'PIS Done'


# In[28]:


df4['Status']=df4.apply(lambda x:b (x['Manifest'],x['SCReceived'],x['Ackndge'],x['PISGenerate']),axis=1)


# In[29]:


dp1=df4[df4['Status']=='Pickedup but manifest not done']
dp2=df4[df4['Status']=='Manifest done but not received by SC']
dp3=df4[df4['Status']=='Received by SC but Acknwledgement not done']
dp4=df4[df4['Status']=='Acknowlegdement done but PIS not done']


# In[30]:


dp11=dp1.pivot_table(index=['BranchCode','vendordetails'],values=['COnNumber'],aggfunc={'COnNumber':len}).reset_index()
dp21=dp2.pivot_table(index=['BranchCode','Manifest_HandOverEmpcd'],values=['COnNumber'],aggfunc={'COnNumber':len}).reset_index()
dp31=dp3.pivot_table(index=['BranchCode','ReceivedBy'],values=['COnNumber'],aggfunc={'COnNumber':len}).reset_index()
dp41=dp4.pivot_table(index=['BranchCode','ACK_PIS_by'],values=['COnNumber'],aggfunc={'COnNumber':len}).reset_index()


# # Picked up but manifest not done

# In[31]:


dp11


# # Manifest done but not received by SC(Pickup)

# In[32]:


dp21


# # Received by SC but Acknwledgement not done(Pickup)

# In[33]:


dp31


# # Acknowlegdement done but PIS not done(Pickup)

# In[34]:


dp41


# In[35]:


df1.to_csv(r'D:\Data\FTC\Report2\Delivery_data.csv')
df4.to_csv(r'D:\Data\FTC\Report2\Pickup_data.csv')


# In[36]:


filepath=r'D:\Data\FTC\Report2\Delivery_data.csv'
filepath1=r'D:\Data\FTC\Report2\Pickup_data.csv'


# In[37]:


TO=['badan.singh@spoton.co.in','saptarshi.pathak@spoton.co.in','dillip.padhi@spoton.co.in','banusanketh.dc@spoton.co.in','abhik.mitra@spoton.co.in','krishna.chandrasekar@spoton.co.in','scincharge_spot@spoton.co.in','AOM_SPOT@spoton.co.in','DOM_SPOT@spoton.co.in','pawan.sharma@spoton.co.in','rajesh.kumar@spoton.co.in','suman.kumar@spoton.co.in','manjunath.swamy@spoton.co.in','mahesh.reddy@spoton.co.in']
# TO=['banusanketh.dc@spoton.co.in']
CC=['mahesh.reddy@spoton.co.in']
FROM="reports.ie@spoton.co.in"
# FROM="mahesh.reddy@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "Cash HOTO Report 2" + " - " + str(enddate)

report=""
report+="Dear All,"
report+='<br>'
report+='Please find the Cash HOTO Report 2'
report+='<br>'
report+='Delivered but manifest not done. '
report+='<br>'
report+='<br>'+dd11.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='Manifest done but not received by SC(Delivery). '
report+='<br>'
report+='<br>'+dd21.to_html()+'<br>'
report+='<br>'
report+='Received by SC but Acknwledgement not done(Delivery) '
report+='<br>'
report+='<br>'+dd31.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='Acknowlegdement done but PIS not done(Delivery) '
report+='<br>'
report+='<br>'+dd41.to_html()+'<br>'
report+='<br>'

report+='Picked up but manifest not done '
report+='<br>'
report+='<br>'+dp11.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='Manifest done but not received by SC(Pickup) '
report+='<br>'
report+='<br>'+dp21.to_html()+'<br>'
report+='<br>'
report+='Received by SC but Acknwledgement not done(Pickup) '
report+='<br>'
report+='<br>'+dp31.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='Acknowlegdement done but PIS not done(Pickup) '
report+='<br>'
report+='<br>'+dp41.to_html()+'<br>'
report+='<br>'

abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(filepath1,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
msg.attach(part1)


# server=smtplib.SMTP('smtp.sendgrid.net', 587)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("mahesh.reddy@spoton.co.in", "Nov@2018")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()


