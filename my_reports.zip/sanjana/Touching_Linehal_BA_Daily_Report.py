
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
from datetime import datetime,timedelta
import pyodbc
from fuzzywuzzy import fuzz
import pandas as pd
import pyodbc
from datetime import datetime,timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
import ftplib
# import Utilities
from calendar import monthrange
import smtplib


# In[2]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")


# In[3]:


df=pd.read_sql('EXEC USP_CNM_TOUCHING_LOCATION_THC',cnxn)


# In[4]:


print (len(df))


df['Grace_Minutes']=df['DELAY_MINS'].apply(lambda x: 'DELAY' if x>30 else 'ONTIME')
# In[5]:


touch=['KNPH','SNRH','IDRH','VPIH','HYDH','JAIH','BGMH','BLRT','VZAH','PATH','BBIH']


# In[6]:


touchdf=df[df['TOUCHING_LOC'].isin(touch)]


# In[7]:


touchdf_summary=touchdf.pivot_table(index=['TOUCHING_LOC'],columns=['Grace_Minutes'],values=['thcno'],aggfunc={'thcno':len},margins=True,margins_name='TOTAL').fillna(0)


# In[8]:


touchdf_summary[('thcno','Ontime%')]=pd.np.round(touchdf_summary[('thcno','ONTIME')]*100.0/touchdf_summary[('thcno','TOTAL')],0)


# In[ ]:


f=touchdf_summary[('thcno','Ontime%')]


# In[9]:


touchdf_summary


# In[10]:


touchdf_lane=touchdf.pivot_table(index=['TOUCHING_LOC','ROUTE_NAME','SCH_Halting_Mins','DELAY_MINS'],columns=['Grace_Minutes'],values=['thcno'],aggfunc={'thcno':len},margins=True,margins_name='TOTAL').fillna(0)


# In[11]:


touchdf_lane


# In[ ]:


## Touching


# In[12]:


baloc=['BNPF','BLSF','MLDF','GWLF','IXPF','DEDF','UDRF','FRZF','IXEF','ANTF','CDPF','SRPT','DINF','IXMF','AKVF','STRF','AKDF','AMVF','BLIB']


# In[13]:


batouchdf=df[df['TOUCHING_LOC'].isin(baloc)]


# In[14]:


batouchdf_summary=batouchdf.pivot_table(index=['TOUCHING_LOC'],columns=['Grace_Minutes'],values=['thcno'],aggfunc={'thcno':len},margins=True,margins_name='TOTAL').fillna(0)


# In[15]:


batouchdf_summary


# In[16]:


batouchdf_summary[('thcno','Ontime%')]=pd.np.round(batouchdf_summary[('thcno','ONTIME')]*100.0/batouchdf_summary[('thcno','TOTAL')],0)


# In[17]:


batouchdf_lane=batouchdf.pivot_table(index=['TOUCHING_LOC','ROUTE_NAME','SCH_Halting_Mins','DELAY_MINS'],columns=['Grace_Minutes'],values=['thcno'],aggfunc={'thcno':len},margins=True,margins_name='TOTAL').fillna(0)


# In[18]:
todate=datetime.strftime(datetime.now()-timedelta(days=1),"%Y-%m-%d")
todate

batouchdf.to_csv(r'D:\Data\CNM_Arrv_Dep\Touching\BA\BA_Touching_Data'+str(todate)+'.csv')
batouchdf.to_csv(r'D:\Data\CNM_Arrv_Dep\Touching\BA\BA_Touching_Data.csv')

touchdf.to_csv(r'D:\Data\CNM_Arrv_Dep\Touching\Linehal\Linehal_Touching_Data'+str(todate)+'.csv')
touchdf.to_csv(r'D:\Data\CNM_Arrv_Dep\Touching\Linehal\Linehal_Touching_Data.csv')

# In[19]:

filepath=r'D:\Data\CNM_Arrv_Dep\Touching\Linehal\Linehal_Touching_Data.csv'
filepath1=r'D:\Data\CNM_Arrv_Dep\Touching\BA\BA_Touching_Data.csv'


# In[22]:





# In[24]:


# TO=['mahesh.reddy@spoton.co.in']
# CC=['mahesh.reddy@spoton.co.in']
TO=['HUBMGR_SPOT@spoton.co.in','ashok.dwivedi@spoton.co.in','kamlesh.sharma@spoton.co.in']
# TO=["krishna.kumar.bhardwaj@spoton.co.in","ramachandran.p@spoton.co.in","Rajnish.pathak@spoton.co.in","jaivir.singh@spoton.co.in","sopanrao.bhoite@spoton.co.in","pawan.sharma@spoton.co.in","ashwani.gangwar@spoton.co.in","prasanna.hegde@spoton.co.in","onkar.sharma@spoton.co.in","manoj.pareek@spoton.co.in","narendra.londhe@spoton.co.in","rajesh.ks@spoton.co.in","pramod.pandey@spoton.co.in","rajesh.mishra@spoton.co.in","sukesh.mishra@spoton.co.in","ashok.dwivedi@spoton.co.in","lingaraj.chidambaram@spoton.co.in"]
# CC= ["abhik.mitra@spoton.co.in","rom_spot@spoton.co.in","Avinash.Singh@spoton.co.in","dinesh.kumar.sharma@spoton.co.in","sasikumar.kannan@spoton.co.in","rajesh.debnath@spoton.co.in","jothi.menon@spoton.co.in","ananth.m@spoton.co.in","rajesh.kumar@spoton.co.in","bushra.jamadar@spoton.co.in","anushree.gadre@spoton.co.in","vimal.s@spoton.co.in","satya.pal@spoton.co.in","vishwas.j@spoton.co.in","shivananda.p@spoton.co.in","mahesh.reddy@spoton.co.in","abhishek.cv@spoton.co.in","shruthi.sk@spoton.co.in"]
CC=['sqtf@spoton.co.in','aom_spot@spoton.co.in','dom_spot@spoton.co.in','rom_spot@spoton.co.in','raghavendra.rao@spoton.co.in','dandappa.buskutti@spoton.co.in','sharanagouda.biradar@spoton.co.in','cnm@spoton.co.in',"mahesh.reddy@spoton.co.in"]
FROM="reports.ie@spoton.co.in"
# FROM="mahesh.reddy@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "Touching Location Performance On " + " - " + str(todate)
html='''<html>
<h4>Dear All,</h4>
<p>PFA the Air Monitoring Report for $date</p>
</html>'''
#s = Template(html).safe_substitute(date=yest_date)
report=""
report+="Dear Hub Manager's,"
report+='<br>'
report+='Pls Find the TOUCHING LOCATION PERFORMANCE on '+str(todate)+' '
report+='<br>'
report+='Hub Wise Touching Location Performance :'
report+='<br>'+touchdf_summary.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='Lane Wise Touching Location Performance :'
report+='<br>'+touchdf_lane.to_html()+'<br>'
report+='<br>'

abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)


# server=smtplib.SMTP('smtp.sendgrid.net', 587)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("mahesh.reddy@spoton.co.in", "Nov@2018")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()


# In[25]:


TO=['aom_spot@spoton.co.in','dom_spot@spoton.co.in','scincharge_spot@spoton.co.in','HUBMGR_SPOT@spoton.co.in','Virendra.Singh@spoton.co.in']
# TO=["krishna.kumar.bhardwaj@spoton.co.in","ramachandran.p@spoton.co.in","Rajnish.pathak@spoton.co.in","jaivir.singh@spoton.co.in","sopanrao.bhoite@spoton.co.in","pawan.sharma@spoton.co.in","ashwani.gangwar@spoton.co.in","prasanna.hegde@spoton.co.in","onkar.sharma@spoton.co.in","manoj.pareek@spoton.co.in","narendra.londhe@spoton.co.in","rajesh.ks@spoton.co.in","pramod.pandey@spoton.co.in","rajesh.mishra@spoton.co.in","sukesh.mishra@spoton.co.in","ashok.dwivedi@spoton.co.in","lingaraj.chidambaram@spoton.co.in"]
# CC= ["abhik.mitra@spoton.co.in","rom_spot@spoton.co.in","Avinash.Singh@spoton.co.in","dinesh.kumar.sharma@spoton.co.in","sasikumar.kannan@spoton.co.in","rajesh.debnath@spoton.co.in","jothi.menon@spoton.co.in","ananth.m@spoton.co.in","rajesh.kumar@spoton.co.in","bushra.jamadar@spoton.co.in","anushree.gadre@spoton.co.in","vimal.s@spoton.co.in","satya.pal@spoton.co.in","vishwas.j@spoton.co.in","shivananda.p@spoton.co.in","mahesh.reddy@spoton.co.in","abhishek.cv@spoton.co.in","shruthi.sk@spoton.co.in"]
CC=['rom_spot@spoton.co.in','sqtf@spoton.co.in','SQ_SPOT@spoton.co.in','raghavendra.rao@spoton.co.in','cnm@spoton.co.in',"mahesh.reddy@spoton.co.in"]
FROM="reports.ie@spoton.co.in"
# FROM="mahesh.reddy@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "Touching Performance : BA Location " + " - " + str(todate)
html='''<html>
<h4>Dear All,</h4>
<p>PFA the Air Monitoring Report for $date</p>
</html>'''
#s = Template(html).safe_substitute(date=yest_date)
report=""
report+="Dear DOM/AOM,"
report+='<br>'
report+='Please find the Touching Performance of BA locations as at '+str(todate)
report+='<br>'
report+='Ensure to take corrective actions on the delayed TAT'
report+='<br>'
report+='BA Touching Location Performance :'
report+='<br>'+batouchdf_summary.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='Lane Wise Touching Location Performance :'
report+='<br>'+batouchdf_lane.to_html()+'<br>'
report+='<br>'

abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath1,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
msg.attach(part)


# server=smtplib.SMTP('smtp.sendgrid.net', 587)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("mahesh.reddy@spoton.co.in", "Nov@2018")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()

