
# coding: utf-8

# In[1]:

import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta,datetime
import sys
import Utilities
import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
from string import Template
import sys
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
reload(sys).setdefaultencoding("ISO-8859-1")

# In[2]:

try:
    querydate=datetime.strftime(datetime.now(),'%Y-%m-%d %H:%M:%S')
    querydate


    # In[3]:

    querydate1=datetime.strftime(datetime.now()-timedelta(hours=1),'%Y-%m-%d %H:%M:%S')
    querydate1


    # In[4]:

    #querydate='2018-06-04 00:00:00'
    #querydate1='2018-06-04 13:00:00'


    # In[5]:

    cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
    #query=("""EXEC USP_CON_DATA_SQ_PLT_SHORTAGE""")

    # cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
    # cursor = cnxn.cursor()


    query=(""" EXEC USP_CON_DATA_SQ_PLT_SHORTAGE '{0}' , '{1}'""".format(querydate1,querydate))


    # In[6]:

    query


    # In[7]:

    df=pd.read_sql(query,Utilities.cnxn)
    # df=pd.read_sql(query,cnxn)
    

    # In[8]:

    print (len(df))
    

    # In[9]:

    hubtohubdf=df[df['BRTYPE']=='HUB - HUB']


    # In[10]:

    len(hubtohubdf)


    # In[11]:

    try:
        hubtohubpivot=pd.pivot_table(hubtohubdf,index=['ComingFrom','PCS SHORT LOCATION','DOCKNO'],values=['PCS SHORT','TOTPTPCS'],aggfunc={'TOTPTPCS':pd.np.mean,'PCS SHORT':lambda x: x.nunique()}).reset_index()
        hubtohubpivot1=pd.pivot_table(hubtohubpivot,index=['ComingFrom','PCS SHORT LOCATION'],values=['PCS SHORT','TOTPTPCS','DOCKNO'],aggfunc={'DOCKNO':len,'TOTPTPCS':sum,'PCS SHORT':sum}).reset_index()
        hubtohubpivot1=hubtohubpivot1.sort_values('PCS SHORT',ascending=False)
    except:
        hubtohubpivot1=pd.DataFrame()
        
        #hubtohubpivot=pd.pivot_table(hubtohubdf,index=['ComingFrom','PCS SHORT LOCATION'],values=['DOCKNO','PCS SHORT','TOTPTPCS'],aggfunc={'TOTPTPCS':sum,'DOCKNO':len,'PCS SHORT':lambda x: x.nunique()})


    # In[12]:

    sctohubdf=df[df['BRTYPE']=='SC - HUB']


    # In[13]:

    len(sctohubdf)


    # In[14]:

    try:
        sctohubpivot=pd.pivot_table(sctohubdf,index=['ComingFrom','PCS SHORT LOCATION','DOCKNO'],values=['PCS SHORT','TOTPTPCS'],aggfunc={'TOTPTPCS':pd.np.mean,'PCS SHORT':lambda x: x.nunique()}).reset_index()
        sctohubpivot1=pd.pivot_table(sctohubpivot,index=['ComingFrom','PCS SHORT LOCATION'],values=['PCS SHORT','TOTPTPCS','DOCKNO'],aggfunc={'DOCKNO':len,'TOTPTPCS':sum,'PCS SHORT':sum}).reset_index()
        sctohubpivot1=sctohubpivot1.sort_values('PCS SHORT',ascending=False)
    except:
        sctohubpivot1=pd.DataFrame()
        #sctohubpivot=pd.pivot_table(sctohubdf,index=['ComingFrom','PCS SHORT LOCATION'],values=['DOCKNO','PCS SHORT','TOTPTPCS'],aggfunc={'TOTPTPCS':len,'DOCKNO':lambda x: x.nunique(),'PCS SHORT':lambda x: x.nunique()})


    # In[15]:

    hubtoscdf=df[df['BRTYPE']=='HUB - SC']


    # In[16]:

    len(hubtoscdf)


    # In[17]:

    try:
        hubtoscpivot=pd.pivot_table(hubtoscdf,index=['ComingFrom','PCS SHORT LOCATION','DOCKNO'],values=['PCS SHORT','TOTPTPCS'],aggfunc={'TOTPTPCS':pd.np.mean,'PCS SHORT':lambda x: x.nunique()}).reset_index()
        hubtoscpivot1=pd.pivot_table(hubtoscpivot,index=['ComingFrom','PCS SHORT LOCATION'],values=['PCS SHORT','TOTPTPCS','DOCKNO'],aggfunc={'DOCKNO':len,'TOTPTPCS':sum,'PCS SHORT':sum}).reset_index()
        hubtoscpivot1=hubtoscpivot1.sort_values('PCS SHORT',ascending=False)
    except:
        hubtoscpivot1=pd.DataFrame()


    # In[18]:

    sctoscdf=df[df['BRTYPE']=='SC - SC']


    # In[19]:

    len(sctoscdf)


    # In[20]:

    try:
        sctoscdfpivot=pd.pivot_table(sctoscdf,index=['ComingFrom','PCS SHORT LOCATION','DOCKNO'],values=['PCS SHORT','TOTPTPCS'],aggfunc={'TOTPTPCS':pd.np.mean,'PCS SHORT':lambda x: x.nunique()}).reset_index()
        sctoscdfpivot1=pd.pivot_table(sctoscdfpivot,index=['ComingFrom','PCS SHORT LOCATION'],values=['PCS SHORT','TOTPTPCS','DOCKNO'],aggfunc={'DOCKNO':len,'TOTPTPCS':sum,'PCS SHORT':sum}).reset_index()
        sctoscdfpivot1=sctoscdfpivot1.sort_values('PCS SHORT',ascending=False)
    except:
        sctoscdfpivot1=pd.DataFrame()


    # In[21]:

    try:
        dfpivot=pd.pivot_table(df,index=['BRTYPE','DOCKNO'],values=['PCS SHORT','TOTPTPCS'],aggfunc={'TOTPTPCS':pd.np.mean,'PCS SHORT':lambda x: x.nunique()}).reset_index()
        dfpivot1=pd.pivot_table(dfpivot,index=['BRTYPE'],values=['DOCKNO','PCS SHORT','TOTPTPCS'],aggfunc={'DOCKNO':len,'PCS SHORT':sum,'TOTPTPCS':sum}).reset_index()
        dfpivot1['Per%']=pd.np.round((dfpivot1['PCS SHORT'])*100.0/dfpivot1['TOTPTPCS'],1)

    except:
        dfpivot1=pd.DataFrame()


    # In[22]:

    try:
        docksummary=pd.pivot_table(df,index=['DOCKNO','ComingFrom','PCS SHORT LOCATION'],values=['PCS SHORT','TOTPTPCS'],aggfunc={'TOTPTPCS':pd.np.mean,'PCS SHORT':lambda x: x.nunique()}).reset_index()
        docksummary1=pd.pivot_table(docksummary,index=['DOCKNO','ComingFrom','PCS SHORT LOCATION'],values=['PCS SHORT','TOTPTPCS'],aggfunc={'PCS SHORT':sum,'TOTPTPCS':sum}).reset_index()
        docksummary1['Scanned PCS']=docksummary1['TOTPTPCS']-docksummary1['PCS SHORT']
        docksummary1=docksummary1[['DOCKNO','ComingFrom','TOTPTPCS','PCS SHORT LOCATION','Scanned PCS','PCS SHORT']]
    except:
        docksummary1=pd.DataFrame()


    # In[23]:




    # In[24]:

    reportts = datetime.now()
    opfilevar=reportts.date()
    opfilevar1=reportts.time()
    ct2= str (opfilevar1)
    currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

    opfilevar2=pd.np.round((float(currhrs)/60),0)


    # In[25]:

    df.to_csv(r'D:\Data\PLT Shortage\Shortagedata'+ str(opfilevar)+"-"+str(int(opfilevar2))+'.csv')
    docksummary1.to_csv(r'D:\Data\PLT Shortage\Docksummary'+ str(opfilevar)+"-"+str(int(opfilevar2))+'.csv')


    # In[26]:

    filepath=r'D:\Data\PLT Shortage\Shortagedata'+ str(opfilevar)+"-"+str(int(opfilevar2))+'.csv'
    filepath1=r'D:\Data\PLT Shortage\Docksummary'+ str(opfilevar)+"-"+str(int(opfilevar2))+'.csv'


    # In[27]:

    #TO=['mahesh.reddy@spoton.co.in']
    #CC=['mahesh.reddy@spoton.co.in']
    #BCC=['mahesh.reddy@spoton.co.in']
    TO=['avnish.tripathi@spoton.co.in','jai.prakash@spoton.co.in','anoop.kumar@spoton.co.in','virendra.singh@spoton.co.in','plt.vigilance_sw@spoton.co.in','plt.vigilance_ne@spoton.co.in','vinay.soam@spoton.co.in','HUBMGR_SPOT@spoton.co.in','AOM_SPOT@spoton.co.in','DOM_SPOT@spoton.co.in','ROM_SPOT@spoton.co.in','scincharge_spot@spoton.co.in','RIM_Spot@spoton.co.in','mangesh.gaikwad@spoton.co.in','Maruti.nandan@spoton.co.in','nitin.gaikwad@spoton.co.in','sb.pawar@spoton.co.in','amit.sharma@spoton.co.ins','purna.panda@spoton.co.in','Atul.Khare@spoton.co.in','ugresh.kanth@spoton.co.in','ashok.sahu@spoton.co.in','rakesh.sonawane@spoton.co.in','naresh.yemujala@spoton.co.in','sanjeet.kumar@spoton.co.in','ramakrishna.v@spoton.co.in','rajkumar@spoton.co.in','sb.pawar@spoton.co.in','chethan.h@spoton.co.in','yogesh.singh@spoton.co.in','samarjeet.dubey@spoton.co.in','dinesh.s@spoton.co.in','rajesh.mishra@spoton.co.in','chidananda.biswal@spoton.co.in']
    CC=['abhik.mitra@spoton.co.in','rajesh.kapase@spoton.co.in','shivananda.p@spoton.co.in','pawan.sharma@spoton.co.in','jothi.menon@spoton.co.in','rajesh.kumar@spoton.co.in','alok.b@spoton.co.in','sharanagouda.biradar@spoton.co.in','satya.pal@spoton.co.in','shivananda.p@spoton.co.in','mahesh.reddy@spoton.co.in','saptarshi.pathak@spoton.co.in']
    #BCC=['mahesh.reddy@spoton.co.in']
    # BCC=['plt.vigilance_sw@spoton.co.in','plt.vigilance_ne@spoton.co.in','HUBMGR_SPOT@spoton.co.in','AOM_SPOT@spoton.co.in','DOM_SPOT@spoton.co.in','ROM_SPOT@spoton.co.in','scincharge_spot@spoton.co.in','RIM_Spot@spoton.co.in','mangesh.gaikwad@spoton.co.in','Maruti.nandan@spoton.co.in','nitin.gaikwad@spoton.co.in','sb.pawar@spoton.co.in','amit.sharma@spoton.co.ins','purna.panda@spoton.co.in','Atul.Khare@spoton.co.in','ugresh.kanth@spoton.co.in','ashok.sahu@spoton.co.in','rakesh.sonawane@spoton.co.in','naresh.yemujala@spoton.co.in','sanjeet.kumar@spoton.co.in','ramakrishna.v@spoton.co.in','rajkumar@spoton.co.in','sb.pawar@spoton.co.in','chethan.h@spoton.co.in','yogesh.singh@spoton.co.in','samarjeet.dubey@spoton.co.in','dinesh.s@spoton.co.in','rajesh.mishra@spoton.co.in','chidananda.biswal@spoton.co.in']



    FROM='reports.ie@spoton.co.in'
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["TO"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "PLT Shortage Exception Report " + str(opfilevar)+"-"+str(opfilevar2)
    html3='''
    <h5> To download the cons data , Please click the link below </h5>
    <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EwayBill_NotAvl_Hub.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EwayBill_NotAvl_Hub.csv</p></b>
    '''
    report=""
    report+='Dear All,'

    report+='<br>'
    report+='PFA Exception on PLT Shortage'
    report+='<br>'
    report+='<br>'
    report+='NOTE: Date Range between '+str(querydate)+'-'+str(querydate1)
    report+='<br>'
    report+='<br>'
    report+='Total Movement wise PLT Shortage'
    report+='<br>'
    report+='<br>'
    report+='<br>'+dfpivot1.to_html()+'<br>'

    report+='HUB-HUB PLT Shortage'
    report+='<br>'
    report+='<br>'
    report+='<br>'+hubtohubpivot1.to_html()+'<br>'
    report+='HUB-SC PLT Shortage'
    report+='<br>'
    report+='<br>'
    report+='<br>'+hubtoscpivot1.to_html()+'<br>'
    report+='SC-HUB PLT Shortage'
    report+='<br>'
    report+='<br>'
    report+='<br>'+sctohubpivot1.to_html()+'<br>'
    report+='SC-SC PLT Shortage'
    report+='<br>'
    report+='<br>'
    report+='<br>'+sctoscdfpivot1.to_html()+'<br>'

    abc=MIMEText(report,'html')
    msg.attach(abc)
    part1 = MIMEBase('application', "octet-stream")
    part1.set_payload( open(filepath,"rb").read() )
    Encoders.encode_base64(part1)
    part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
    msg.attach(part1)

    part2 = MIMEBase('application', "octet-stream")
    part2.set_payload( open(filepath1,"rb").read() )
    Encoders.encode_base64(part2)
    part2.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
    msg.attach(part2)

    #msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, CC+TO, msg.as_string())
    server.quit()

except:
  TO=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  #msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "PLT Shortage Exception Report Error in Execution" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in PLT Shortage Exception Report'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO, msg.as_string())
  server.quit()



# In[ ]:



