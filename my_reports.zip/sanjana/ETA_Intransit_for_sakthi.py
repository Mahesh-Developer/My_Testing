
# coding: utf-8

# <b> Importing Lib </b>

# In[17]:

import pandas as pd
import networkx as nx
import numpy as np
from pandas import ExcelWriter
from collections import OrderedDict
from datetime import datetime, timedelta, time
import datetime
from py2neo import authenticate, Graph
authenticate("localhost:7474", "neo4j", "server")
import traceback
import ftplib

import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import os



# <b> Printing Function </b>

# In[18]:
"""
def save_xls(list_dfs, name_dfs, xls_path):
   i = 0
   writer = ExcelWriter(xls_path)
   for dataframe in list_dfs:
       sheetname = name_dfs[i]
       dataframe.to_excel(writer, sheetname, merge_cells = False)
       i = i+1
   writer.save()
"""

prgmstart = datetime.datetime.now().time()
print 'Program start time is ', prgmstart 


# <b> Importing files </b>

# In[19]:

ippath1 = r'D:/Python/Scripts and Files/Path and Graph Files/Path_Final_July15.xlsx'
#ippath2 = 'C:/Data/TGC/TCR/Today/TCR_test.xls'
###ippath2 = r'C:/Users/s1738raj/Documents/IPython Notebooks/intansit_upload/TCR_UND_test.xls'
#ippath2 = r'C:/Data/IE/ETA_Sakthi/TCR_UND_ISDEPART_YES_2HRS.xls'
#oppath2 = r'C:/Users/s1738raj/Documents/IPython Notebooks/intansit_upload/TCR_UND_test_OP.xlsx'
oppath2 = 'D:/Python/Scripts and Files/Path and Graph Files/ETA_Intransit_Data.csv'


hubprocessingtime = 1
scprocessingtime = 1


x1 = pd.ExcelFile(ippath1)
paths = x1.parse("Sheet1")
#xl2 = pd.ExcelFile(ippath2)
tcrdata = pd.io.excel.read_excel('http://10.109.230.50/downloads/TCR_UND_2HRS/TCR_UND_ISDEPART_YES_2HRS.xls','TCR_UND_ISDEPART_YES_2HRS ')
#tcrdata = xl2.parse('TCR_UND_ISDEPART_YES_2HRS ')


# <b> Setting up the graph </b>

# In[22]:

graph= Graph()
C_graph= Graph()


# <b> Split the dataframe to Inventory and Intransit</b>

# In[23]:


# <b>Using Neo4j Calculating Total Transit for Intransit Cons</b>



def findeta_intransit (connumber, destinationtcr, currloc, nextlocintcr, departtimetcr, timestamp):
    
    #df3= paths[(paths['Origin']== origintcr ) & (paths['Destination']== destinationtcr)]
    df3= paths[(paths['Destination']== destinationtcr) & (paths['Path1'].str.contains(currloc)) & (paths['Path1'].str.contains(nextlocintcr))]
    if df3.empty:
        eta = 'NA'
        nextloc = 'NA'
        return eta, nextloc
        
    else:
        #print('dataframe is df3',df3)
        pathlist1 = df3['Path1'].tolist()
        #print('Pathlist is ',pathlist1 )
    
    path_in= pathlist1[0]
    
    #print ('path_in1 is a',path_in)
    path_in= str(path_in)
    path_in_list= path_in.split('-')
    #print ('path_in1 is',path_in_list)
    
    if currloc in path_in_list:
        match_loc = [j for j, x in enumerate(path_in_list) if x == currloc] 
        #print ('matching', match_loc)
        position= match_loc[0]
        #print ('post is', position)
        nextloc = path_in_list[position+1]
        
    else:
        eta = 'NA'
        nextloc = 'NA'
        return eta, nextloc
        
    path_in1=path_in_list[(position+1):]
    #print ('path_in1', path_in1)
    
    q_current=("""MATCH (n:Location{name:{PLO}})-[r]->(m:Location{name:{PLD}})
                RETURN r.legtt, r.coolingtime""")
    
    #current_edges=graph.cypher.execute(q_current, {"PLO":currloc, "PLD":nextloc})
    intransit_leg_transittimelist=[]
    intransit_leg_coolingtimelist=[]
    intransit_legtransit=0
    intransit_legcooling=0
    #print ('curr and nxt loc',currloc, nextloc)
    #print ('q_current', graph.cypher.execute(q_current, {"PLO":currloc, "PLD":nextloc}))
    for record in graph.cypher.execute(q_current, {"PLO":currloc, "PLD":nextloc}):
        #print(record.name)
        intransit_leg_transittimelist.append(record[0])
        intransit_leg_coolingtimelist.append(record[1])
    
    remarklist=[]
    if intransit_leg_transittimelist:
        #print ('yoyo')
        if intransit_leg_transittimelist[0]==0:
            #print ('check vir')
            intransit_legtransit=0
            intransit_legcooling=hubprocessingtime 
        else:
            #print ('yoyoyoyo')
            intransit_legtransit=min(intransit_leg_transittimelist)
            intransit_legcooling=min(intransit_leg_coolingtimelist)
            
    else:
        remarklist.append('No Schedule in THC file')
        #print ('Outside No Schedule in THC file')
        eta = 'NA'
        nextloc = 'NA'
        return eta, nextloc

        
    #print ('firstlegcoolingtimelist', firstlegcoolingtimelist)
    intransit_totaltt=0
    #print intransit_legtransit, intransit_legcooling
    intransit_totaltt=intransit_legtransit+intransit_legcooling
    
    depart_date = departtimetcr
    depart_time= depart_date.time()
    dt1= str(depart_time)
    depart_time1= (sum(float(x) * 60 ** i for i,x in enumerate(reversed(dt1.split(":")))))/60
    depart_time1=float(depart_time1)/60  #to convert the int only result of a division of python2.7
    #print('depart_time1 is', depart_time1)
    arrival_date1 = depart_date + timedelta(hours=intransit_totaltt)
    #print ('arrival_date1',arrival_date1)
    #depart_date2 = depart_date.to_pydatetime()  #only use is to calculate final eta
    #depart_date2 = depart_date2.date()  #only use is to calculate final eta
    ##
    curr_date2 = timestamp
    #curr_date3= "2015-03-26 00:00"
    #curr_date3 = datetime.strptime(curr_date3, "%Y-%m-%d %H:%M")
    #curr_time2 = 15.75
    #curr_date2 = curr_date3 + timedelta(hours=curr_time2)  #this complication was kept to sort the issue of getting eta curr date
    grace_time= 1
    #curr_time1=curr_time2+grace_time
    curr_date1 = curr_date2 + timedelta(hours=grace_time)
    max_currtdate= max (arrival_date1, curr_date1)
    curr_date=max_currtdate.date()
    ct1= max_currtdate.time()
    #print ('ct1', ct1)
    ct2= str (ct1)
    #print ('ct2', ct2)
    currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60
    
    currhrs=float(currhrs)/60  #to convert the int only result of a division of python2.7
    #print('currhrs is', currhrs)
    
    #curr date only for final eta
    ## guess this is not needed- 13-July-15 now; had used to convert to days in the end
    
    if arrival_date1 >= curr_date2:
        #min_currtdate= min (arrival_date1, curr_date1)
        eta_datetime = curr_date2
        curr_date_eta = curr_date2.date()
        eta_currhrs= curr_date2.time()
        eta_currhrs = str (eta_currhrs)
        eta_currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(eta_currhrs.split(":")))))/60
        eta_currhrs=float(eta_currhrs)/60
    else:
        eta_datetime = curr_date1
        curr_date_eta = curr_date1.date()
        eta_currhrs= curr_date1.time()
        eta_currhrs = str (eta_currhrs)
        eta_currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(eta_currhrs.split(":")))))/60
        eta_currhrs=float(eta_currhrs)/60
    ## guess this is not needed- 13-July-15 now; had used to convert to days in the end
    #curr date only for final eta ends
    
    overlap_transit=0
    #print 'arrival_date1,curr_date2',arrival_date1,curr_date2
    if arrival_date1>=curr_date2:
        delta =  (arrival_date1 - curr_date2)
        #overlap_transit=((delta.days)*24)+(float(delta.seconds)/3600)
        overlap_transit=(float(delta.total_seconds())/3600)
        #print 'inside',overlap_transit
        #print'delta',delta
        #print'delta seconds is',delta.total_seconds()
        ############################################ DELTA TO BE CHECKED
    else:
        overlap_transit=0
    #print 'overlap_transit',overlap_transit
    transittimes=0
    transittimes=overlap_transit  #cooling already included in arrival_date1
    #print 'transittimes',transittimes
    forced_cooling=0
    #print ('outside transit',transittimes)
    
    ##
    #print 'currhrs',currhrs
    ignitionstart= currhrs
    ignitiontime=0
    deptimelist=[]
    deptimelist.append(eta_currhrs)
    arrivallist=[]
    arrivallist.append(currhrs)
    r=0
    #print 'begin second loop'
    for r in range (0, len(path_in1)-1):
        origin = path_in1[r]
        destination = path_in1[r+1]
        #print ('origin is', origin)
        #print ('dest is',destination)
    
        q_after=("""MATCH (n:Location{name:{PLO}})-[r]->(m:Location{name:{PLD}})
                WHERE (r.lhtype="LH" or r.lhtype="Market")and r.departtime>={CH} 
                RETURN r.departtime, r.code, r.legtt, r.coolingtime, r.arrivaltime""")
        q_before=("""MATCH (n:Location{name:{PLO}})-[s]->(m:Location{name:{PLD}})
                WHERE (s.lhtype="LH" or s.lhtype="Market") and s.departtime<{CH}
                RETURN s.departtime, s.code, s.legtt, s.coolingtime, s.arrivaltime""")
        q_virtual=("""MATCH (n:Location{name:{PLO}})-[r]->(m:Location{name:{PLD}})
                WHERE r.lhtype="Virtual"
                RETURN r.departtime, r.code, r.legtt, r.coolingtime, r.arrivaltime""")
        #print ('check', transittimes)
        after_edges=graph.cypher.execute(q_after, {"PLO":origin, "PLD":destination, "CH":float(currhrs)})
        before_edges=graph.cypher.execute(q_before, {"PLO":origin, "PLD":destination, "CH":float(currhrs)})
        virtual_edges=graph.cypher.execute(q_virtual, {"PLO":origin, "PLD":destination})
        #print ('after/before',after_edges, before_edges,  virtual_edges)
        if after_edges:
            departure=min(after_edges, key=lambda x:x[0])
        #elif before_edges:    #print ('checkkk')
        elif before_edges:
            departure=min(before_edges, key=lambda x:x[0])
                #print 'before edges'
        else:
            departure = 'no path'
        #print ('departure is',departure)
        if after_edges or before_edges:  #boolean to seperate queries which give null set(result of nodes not present in graph)
            #print ('lock1')
            departure_time = departure[0]
            transittimes=transittimes+ departure[2]+ departure[3]
            #print ('inside nextloc', nextloc, afternextloc)
            deptimelist.append(departure[0])
            if (departure[4]+departure[3]) > 24:
                currhrs= (departure[4]+departure[3] - 24)
                arrivallist.append(departure[4]+departure[3]-24)
            else:
                currhrs= (departure[4]+departure[3])
                arrivallist.append(departure[4]+departure[3])
                #print ('arrivallist inside',arrivallist, departure[4], departure[3])
                
        #forced_cooling= 0
        elif virtual_edges:
            #elif virtual_edges[0][1]:
            #print ('lock2')
            departure_time = currhrs
            arrival_time = currhrs
            #print ('virtual is', virtual_edges)
            transittimes=transittimes+ virtual_edges[0][3]
            #print 'transittimes',transittimes,virtual_edges[0][3]
            deptimelist.append(departure_time)
            if (arrival_time+virtual_edges[0][3]) > 24:
                currhrs= (arrival_time+virtual_edges[0][3] - 24)
                arrivallist.append(arrival_time+virtual_edges[0][3]-24)
            else:
                currhrs= (arrival_time+virtual_edges[0][3])
                arrivallist.append(arrival_time+virtual_edges[0][3])
        
        else:
            
            remarklist.append('No Schedule in THC file')
            eta = 'NA'
            nextloc = 'NA'
            return eta, nextloc
            #print ('Ot No Schedule in THC file')

        #print ('inside transit', transittimes)
        if (len(deptimelist)==len(path_in1)) and (len(arrivallist)==len(path_in1)):
            for u in range (1, len(path_in1)-2):
                if deptimelist[u+1] >= arrivallist[u]:
                    forced_cooling = forced_cooling+deptimelist[u+1]-arrivallist[u]
                    #print('inside1',forced_cooling)
                else:
                    forced_cooling = forced_cooling+deptimelist[u+1]+(24-arrivallist[u])
                    #print('inside2',forced_cooling)
        #print ('deptimelist is',deptimelist)
        #print ('virtual_edges', virtual_edges)
        if (not virtual_edges) & (deptimelist[1]>=ignitionstart):
            ignitiontime= (deptimelist[1]-ignitionstart)
            #print ('ignition if is',ignitiontime)
        elif (not virtual_edges) & (deptimelist[1]<ignitionstart):
            ignitiontime= (24-ignitionstart+deptimelist[1])
            
    finaltt=transittimes+forced_cooling+ignitiontime
    ##totaldays=finaltt//24
    ##remainhrs=finaltt%24
    #print ('totaldays', totaldays, remainhrs)
    if remarklist:    #if-else statement only to exit loop when there is a remark of no schedule
        eta = 'NA'
        nextloc = 'NA'
        return eta, nextloc
        
    else:
        ##if ((remainhrs+deptimelist[0])>24):
            ##totaldays= totaldays+1
        ##elif (arrivallist[-1]>14):
            ##totaldays= totaldays+1
        ##else:
            ##totaldays= totaldays
        #print finaltt, transittimes, forced_cooling, ignitiontime
        finalscarrival = eta_datetime+timedelta(hours=finaltt)
        at1 = finalscarrival.time()
        at2= str (at1)
    
        finalhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(at2.split(":")))))/60
        finalhrs=float(finalhrs)/60  #to convert the int only result of a division of python2.7
    
        if finalhrs <= 16:
            eta = finalscarrival.date()
        else:
            eta = (finalscarrival+timedelta(days=1)).date()
        
    return eta, nextloc




columnsop= ['Con No_int','ETA_int','Timestamp_int']
dfop_int_sakthi= pd.DataFrame(columns=columnsop)




tcrconlist_int= tcrdata['DOCKNO'].tolist()
print 'the intransit list has', len(tcrconlist_int)
n = 0
for n in range (0, len(tcrconlist_int)):
    connumber = tcrdata.iloc[n]['DOCKNO']
    #print ('connumber', connumber)
    origintcr = tcrdata.iloc[n]['ORIGIN BRCODE']
    destinationtcr = tcrdata.iloc[n]['DESTCD']
    currloc = tcrdata.iloc[n]['CURR BRANCHCODE']
    nextlocintcr =  tcrdata.iloc[n]['DEPARTURE TO LOC FRM CURLOC']
    #currloc = tcrdata.iloc[n]['Route Code'] #to_be_added in TCR
    #print 'arrivaltimetcr in tcr is', arrivaltimetcr
    departtimetcr = tcrdata.iloc[n]['DEPARTURE TIME FRM CURLOC']
    #print 'departtimetcr in tcr is', departtimetcr
    reportts = tcrdata.iloc[n]['TIME STAMP']
    timestamp= reportts.to_pydatetime()
    
    if destinationtcr == currloc :
        dfop_int_sakthi.loc[n,'Con No_int'] = connumber
        dfop_int_sakthi.loc[n,'ETA_int'] = 'NA'
        dfop_int_sakthi.loc[n,'Timestamp_int'] = timestamp
        continue
        
    
    print connumber, destinationtcr, currloc, nextlocintcr, departtimetcr, timestamp
    
    eta, nextloc = findeta_intransit (connumber, destinationtcr, currloc, nextlocintcr, departtimetcr, timestamp)
    #print  eta, nextloc  
    dfop_int_sakthi.loc[n,'Con No_int'] = connumber
    dfop_int_sakthi.loc[n,'ETA_int'] = eta
    dfop_int_sakthi.loc[n,'Timestamp_int'] = timestamp
    
"""    
printlist =  [tcrdata]
namelist = ['Data']
save_xls (printlist, namelist, oppath2)
"""

dfop_int_sakthi.to_csv('D:/Python/Scripts and Files/Path and Graph Files/ETA_Intransit_Data.csv')
print 'saving done'
prgmend = datetime.datetime.now().time()
print 'prgmend', prgmend

###### FOR FTP..TEMPORARY

# In[ ]:



prgmend = datetime.datetime.now().time()
#print 'Program end time is ', prgmend 

#print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
#print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        #print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppath2
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        #print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        #print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()

ftpend = datetime.datetime.now().time()
print 'ftpend is', ftpend


filePath = oppath2
def sendEmail(#TO = ["ashwani.gangwar@spoton.co.in","krishna.kumar.bhardwaj@spoton.co.in","jaisingh.chauhan@spoton.co.in","joseph.arul.seelan@spoton.co.in","dhiraj.patil@spoton.co.in","krishan.kaushik@spoton.co.in","ramniwas.sharma@spoton.co.in","sopanrao.bhoite@spoton.co.in","ramachandran.p@spoton.co.in","manoj.pareek@spoton.co.in","pramod.pandey@spoton.co.in","surendra.pandey@spoton.co.in","onkar.sharma@spoton.co.in","ajay.kumar.singh@spoton.co.in","satyaprakash.vishwakarma@spoton.co.in","sandesh.patade@Spoton.co.in","cnm@spoton.co.in","cstl_spot@spoton.co.in"],
            TO = ["rajeesh.vr@spoton.co.in"],
            #TO = ["vishwas.j@spoton.co.in"],
            CC = ["vishwas.j@spoton.co.in"],
            #CC = ["sqtf@spoton.co.in","sq_spot@spoton.co.in","supratim@iepfund.com","rajesh.kumar@spoton.co.in","pawan.sharma@spoton.co.in","vishwas.j@spoton.co.in","prasanna.hegde@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "SERVER Intransit ETA FTP" + " - " + str(reportts)
    msg["Subject"] = "SERVER Intransit ETA FTP" + " - " + str(reportts)
    body_text = """
    Dear All,

    PFA the Intransit ETA FTP as on """ + str(reportts) +"""

    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
mailend = datetime.datetime.now().time()
print 'mailend is', mailend
#Sending output file via mail ends




# In[24]:




# 
