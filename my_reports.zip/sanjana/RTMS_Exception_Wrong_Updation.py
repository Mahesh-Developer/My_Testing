
# coding: utf-8

# In[83]:


import pandas as pd
import pyodbc
from datetime import datetime,timedelta
import smtplib
import ftplib
import traceback
import calendar
import os
import pyodbc
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import Utilities

# In[2]:


#  cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")


# In[3]:

try:
    yestdate=datetime.strftime(datetime.now()-timedelta(days=1),"%Y-%m-%d")
    yestdate

    f1=yestdate+' 00:00:00'
    f2=yestdate+' 23:59:00'
    f1,f2

    # In[4]:


    df=pd.read_sql("""select rt.AWBNo,rt.FieldEmployeeName,
    rt.longvalue,rt.latvalue,
    rt.TransactionDate,
    rt.DeliveredTo,
    rt.ReceiverMobNumber,
    rt.GoogleAddress,
    rt.DistanceinKM,
    rt.GoogDistanceFrmBranch,
    rt.GPSPincode,
    d.CSGENM,
    d.CSGEPIN,
    d.DESTCD,
    b.LATITUDE,
    b.LONGITUDE from tblAndroidConStatusDetails rt
     INNER JOIN dbo.DOCKET d ON rt.AWBNo=d.DOCKNO
     INNER JOIN brms b ON d.DESTCD=b.BRCD WHERE rt.TransactionDate BETWEEN '{0}' AND '{1}'
    """.format(f1,f2),cnxn)


    # In[5]:


    len(df)


    # In[6]:


    df['concat']=df['latvalue'].astype(str)+'_'+df['longvalue'].astype(str)


    # In[7]:


    df1=df.drop_duplicates('concat')




    # In[55]:


    from geopy.geocoders import Nominatim
    import geopy
    import pandas as pd
    from geopy.distance import vincenty, great_circle
    from geopy.geocoders import GoogleV3

    # geolocator = GoogleV3()
    def getdist12(x,y):
        geolocator = GoogleV3(api_key='AIzaSyB2P7aCxU2yeGJXBQ1hpAawU7TLCxEssjQ ')
        location=geolocator.reverse((x,y))
    #     print (location)
        if location:
            postcode=location[0]
            
            return (str(postcode))
        else:
            return None


    # In[56]:


    df1['Address']=df1.apply(lambda x:getdist12(x['latvalue'],x['longvalue']),axis=1)


    # In[ ]:





    df2=df1[['concat','Address']]


    # In[62]:


    finaldf=pd.merge(df,df2,on='concat',how='left')


    # In[65]:





    # In[72]:


    def getException(pin,add):
        if add==None:
            return None
        elif pin in add:
            return "Correctly Updated"
        else:
            return "Wrongly Updated"


    # In[73]:


    finaldf['Exception']=finaldf.apply(lambda x: getException(x['CSGEPIN'],x['Address']),axis=1)


    # In[75]:


    summary=finaldf.pivot_table(index=['DESTCD'],columns=['Exception'],values=['AWBNo'],aggfunc={'AWBNo':len},margins=True,margins_name="Total").fillna(0)


    # In[76]:





    summary.sort_values(('AWBNo','Wrongly Updated'),ascending=False,inplace=True)


    # In[78]:




    finaldf.to_csv(r'D:\Data\RTMS\wrong_updation\ConWise_Data'+str(yestdate)+'.csv')


    # In[81]:


    filepath=r'D:\Data\RTMS\wrong_updation\ConWise_Data'+str(yestdate)+'.csv'


    # In[85]:

    # TO=['mahesh.reddy@spoton.co.in']
    TO=['abhik.mitra@spoton.co.in','alok.b@spoton.co.in','satya.pal@spoton.co.in','banusanketh.dc@spoton.co.in']
    CC=['mahesh.reddy@spoton.co.in']

    FROM='reports.ie@spoton.co.in'
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["TO"] = ",".join(TO)
    msg["CC"] = ",".join(CC)

    msg["Subject"] = "RTMS Exception Report(Pincode Updation) " + str(yestdate)

    report=""
    report+='Dear All,'

    report+='<br>'
    report+='<br>'
    report+='PFA RTMS Exception Report(Pincode Updation)'
    report+='<br>'
    report+='<br>'
    report+='NOTE: Date Range between '+str(yestdate)+' 00:00:00'+' - '+str(yestdate)+' 23:59:00'
    report+='<br>'
    report+='<br>'
    report+='Summary Sorted based on Wrongly Updated count'
    report+='<br>'
    report+='<br>'
    report+='<br>'+summary.to_html()+'<br>'



    abc=MIMEText(report,'html')
    msg.attach(abc)
    part1 = MIMEBase('application', "octet-stream")
    part1.set_payload( open(filepath,"rb").read() )
    encoders.encode_base64(part1)
    part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
    msg.attach(part1)



    #msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, CC+TO, msg.as_string())
    server.quit()

except:

  TO=["mahesh.reddy@spoton.co.in"] 
  CC=['mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "Performance Metrics Monitoring-CCUA" + " - " + str(opfilevar)
  msg["Subject"] = "RTMS Exception ERROR Report" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in RTMS Exception Report(Pincode Updation)'
  report+='<br>'

  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  #server.login("spoton.co.in", "#Xat694#")
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO+CC, msg.as_string())
  server.quit()


