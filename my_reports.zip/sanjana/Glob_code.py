# -*- coding: utf-8 -*-
"""
Created on Thu Apr 07 11:04:17 2016

@author: rajeeshv
"""

import pandas as pd
import glob
print ('hello')
path =r'D:\Data\Hub Performance\2019Aug\without mondays' # use your path


allFiles = glob.glob(path + "/*.csv")
frame = pd.DataFrame()
list_ = []
# print ('hello')
for file_ in allFiles:
	print (file_)
	df = pd.read_csv(file_)
	# dt=file_.split('Stock_Data')[1].split('.')[0][:-4]
	# df=df[df['CurrentBranch'].isin(['DELH','DELO'])]
	# df['Timestamp']=dt
	list_.append(df)
frame = pd.concat(list_)


frame.to_csv(r'D:\Data\Hub Performance\2019Aug\without mondays\Aug2019_Withoutmondays_Data.csv')

print (len(frame))
