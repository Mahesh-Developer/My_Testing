
# coding: utf-8

# <b> Importing Lib </b>

# In[181]:

import pandas as pd
#import networkx as nx
import numpy as np
from pandas import ExcelWriter
from datetime import datetime, timedelta, time
from py2neo import authenticate, Graph
authenticate("localhost:7474", "neo4j", "server")
import datetime
import time
import traceback
import ftplib

from pandas import pivot_table
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import os
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import Utilities
# <b> Printing Function </b>

# In[182]:
"""
def save_xls(list_dfs, name_dfs, xls_path):
   i = 0
   writer = ExcelWriter(xls_path)
   for dataframe in list_dfs:
       sheetname = name_dfs[i]
       dataframe.to_excel(writer, sheetname, merge_cells = True)
       i = i+1
   writer.save()
"""

# <b> Importing files </b>

# In[183]:
#print datetime.now() #only to get the start time in log reports
ippath1 = r'D:/Python/Scripts and Files/Path and Graph Files/Path_Final_July15.xlsx'
#ippath2 = 'C:/Data/TGC/TCR/Today/TCR_test.xls'
#ippath2 = '/home/sbaner03/ETA/HTR_1HRfinal.xls'
oppath2 = 'D:/Python/Scripts and Files/Path and Graph Files/ETA_Data_with_Actionhrs.csv'
#oppath3 = '/home/sbaner03/ETA/OP_ETA_Intr.xlsx'


# <b> Loading Dataframes to create linehaul time master and schedule graph</b>

# In[184]:

hubprocessingtime = 3
scprocessingtime = 2


# In[185]:

x1 = pd.ExcelFile(ippath1)
paths = x1.parse("Sheet1")
#xl2 = pd.ExcelFile(ippath2)
#tcrdata = xl2.parse('HUB_THROUGHPUT_ONEHOUR')
#tcrdata = xl2.parse('TIMECONNECTIONREPORT')
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

query = ("""EXEC USP_HUB_THROUGHPUT_DETAILS_SALES_ONEHOUR """)
print (query)

# tcrdata = pd.read_sql(query, cnxn)
# tcrdata.rename(columns={'Hub/SC Location':'Hub SC Location','Arrival Date @ Hub':'Arrival Date Hub','BookingDate':'Booking Date','OriginDepot':'Origin Depot','OriginArea':'Origin Area','DestnDepot':'Destn Depot','DestnArea':'Destn Area','DestnBranch':'Destn Branch','NoOfPackages':'No Of Packages','Act.WtInTonnes':'Act Wt In Tonnes','Del. Location Type':'Del Location Type','LatestStatusCode':'Latest Status Code','LatestStatus':'Latest Status','LatestStatusDate':'Latest Status Date','LatestStatusReason':'Latest Status Reason','LatestStatusBranch':'Latest Status Branch','LatestStatusCategory':'Latest Status Category','AccountCode':'Account Code','AccountName':'Account Name','ServiceCenter Pincode':'Service Center Pincode','ApptmntDelDate':'APPOINTMENT DEL DATE'},inplace=True)
tcrdata = pd.io.excel.read_excel('http://10.109.230.50/downloads/HTR_1HR/HTR_1HR.xls','HUB_THROUGHPUT_ONEHOUR')

# <b> Setting up the graph </b>

# In[186]:

graph= Graph()
C_graph= Graph()


# <b> Inventory </b>

# In[ ]:

def findeta (connumber, origintcr, destinationtcr, currloc, arrivaltimetcr, timestamp):
    #duedate1=duedate.to_pydatetime()
    df3= paths[(paths['Destination']== destinationtcr) & (paths['Path1'].str.contains(currloc))]
    if df3.empty:
        eta = 'NA'
        nextloc = 'NA'
        #print eta
        return eta, nextloc

    else:
        pathlist1 = df3['Path1'].tolist()
    path_in= pathlist1[0]
    #print ('path_in1 is a',path_in)
    path_in= str(path_in)
    path_in_list= path_in.split('-')
    #print ('path_in_list is',path_in_list)

    if currloc in path_in_list:
        match_loc = [j for j, x in enumerate(path_in_list) if x == currloc]
        #print ('matching', match_loc)
        position= match_loc[0]
        #print ('post is', position)
        nextloc = path_in_list[position+1]
    else:
        eta = 'NA'
        nextloc = 'NA'
        return eta, nextloc

    path_in1=path_in_list[(position):]
    #print ('path_in1 is',path_in1)

    transittimes=0
    forced_cooling=0
    ##
    arrival_date1 = arrivaltimetcr #+ timedelta(hours=hubprocessingtime)
    curr_date1 = timestamp
    #curr_date1= "2015-03-27 00:00"
    #curr_date1 = datetime.strptime(curr_date1, "%Y-%m-%d %H:%M")
    #curr_time1 = 15.75
    #curr_date1 = curr_date1 + timedelta(hours=curr_time1)
    ###max_currtdate= max (arrival_date1, curr_date1)
    max_currtdate= curr_date1
    curr_date=max_currtdate.date()
    ct1= max_currtdate.time()
    ct2= str (ct1)
    #print ('curr_date1', curr_date1)
    #print ('ct1, ct2', ct1, ct2)
    #print ('curr_date', curr_date)
    currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60
    currhrs=float(currhrs)/60  #to convert the int only result of a division of python2.7
    #print('currhrs is', currhrs)

    ##
    ignitionstart= currhrs
    ignitiontime=0
    deptimelist=[]
    arrivallist=[]
    remarklist=[]
    for r in range (0, len(path_in1)-1):
        checklist2=[]
        origin = path_in1[r]
        destination = path_in1[r+1]
        #print origin
        #print destination

        q_after=("""MATCH (n:Location{name:{PLO}})-[r]->(m:Location{name:{PLD}})
                WHERE (r.lhtype="LH" or r.lhtype="Market") and r.departtime>={CH}
                RETURN r.departtime, r.code, r.legtt, r.coolingtime, r.arrivaltime""")
        q_before=("""MATCH (n:Location{name:{PLO}})-[s]->(m:Location{name:{PLD}})
                WHERE (s.lhtype="LH" or s.lhtype="Market") and s.departtime<{CH}
                RETURN s.departtime, s.code, s.legtt, s.coolingtime, s.arrivaltime""")
        q_virtual=("""MATCH (n:Location{name:{PLO}})-[r]->(m:Location{name:{PLD}})
                WHERE r.lhtype="Virtual"
                RETURN r.departtime, r.code, r.legtt, r.coolingtime, r.arrivaltime""")

        #print ('check', transittimes)
        after_edges=graph.cypher.execute(q_after, {"PLO":origin, "PLD":destination, "CH":float(currhrs)})
        before_edges=graph.cypher.execute(q_before, {"PLO":origin, "PLD":destination, "CH":float(currhrs)})
        virtual_edges=graph.cypher.execute(q_virtual, {"PLO":origin, "PLD":destination})

        if after_edges:
            #print 'after edges'
            departure=min(after_edges, key=lambda x:x[0])
        elif before_edges:    #print ('checkkk')
            departure=min(before_edges, key=lambda x:x[0])
            #print 'before edges'
        else:
            #print 'in else'
            departure = 'no path'
        #print ('departure is',departure)
        #if after_edges:  #boolean to seperate queries which give null set(result of nodes not present in graph)
        if (after_edges or before_edges):
            #print ('lock')
            departure_time = departure[0]
            lh = departure[1]
            #print('lh is', lh)
            #print (departure[2])
            #print (departure[3])
            transittimes=transittimes+ departure[2]+ departure[3]
            deptimelist.append(departure[0])
            if (departure[4]+departure[3]) > 24:
                currhrs= (departure[4]+departure[3] - 24)
                arrivallist.append(departure[4]+departure[3]-24)
            else:
                currhrs= (departure[4]+departure[3])
                arrivallist.append(departure[4]+departure[3])
                #print ('arrivallist',arrivallist)

        #forced_cooling= 0
            #elif virtual_edges:
        elif virtual_edges:
            departure_time = currhrs
            arrival_time = currhrs
            #print ('virtual is', virtual_edges)
            transittimes=transittimes+ virtual_edges[0][3]
            deptimelist.append(departure_time)
            if (arrival_time+virtual_edges[0][3]) > 24:
                currhrs= (arrival_time+virtual_edges[0][3] - 24)
                arrivallist.append(arrival_time+virtual_edges[0][3]-24)
            else:
                currhrs= (arrival_time+virtual_edges[0][3])
                arrivallist.append(arrival_time+virtual_edges[0][3])

        else:
            eta = 'NA'
            checklist2.append(origin+'-'+destination)
            remarklist.append('No Schedule in THC file')
            nextloc = 'NA'
            #print ('No Schedule in THC file')
            return eta, nextloc


        if (len(deptimelist)==len(path_in1)-1) and (len(arrivallist)==len(path_in1)-1):
            for u in range (0, len(path_in1)-2):
                if deptimelist[u+1] >= arrivallist[u]:
                    forced_cooling = forced_cooling+deptimelist[u+1]-arrivallist[u]
                    #print('inside1',forced_cooling)
                else:
                    forced_cooling = forced_cooling+deptimelist[u+1]+(24-arrivallist[u])
                    #print('inside2',forced_cooling)
        #print ('deptimelist is',deptimelist)
        #print ('virtual_edges', virtual_edges)
        if (not virtual_edges) & (deptimelist[0]>=ignitionstart):
            ignitiontime= (deptimelist[0]-ignitionstart)
            #print ('ignition if is',ignitiontime)
        elif (not virtual_edges) & (deptimelist[0]<ignitionstart):
            ignitiontime= (24-ignitionstart+deptimelist[0])
            #print ('ignition elif is',ignitiontime)
            #print ('ignition',ignitiontime)
    finaltt=transittimes+forced_cooling+ignitiontime
    ##totaldays=finaltt//24
    ##remainhrs=finaltt%24
    if remarklist:    #if-else statement only to exit loop when there is a remark of no schedule
        #break
        eta = 'NA'
        nextloc = 'NA'
        return eta, nextloc


    else:
        finalscarrival = max_currtdate+timedelta(hours=finaltt)
        at1 = finalscarrival.time()
        at2= str (at1)

        finalhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(at2.split(":")))))/60
        finalhrs=float(finalhrs)/60  #to convert the int only result of a division of python2.7

        if finalhrs <= 16:
            eta = finalscarrival.date()
        else:
            eta = (finalscarrival+timedelta(days=1)).date()
        ###eta = finalscarrival.date()
    #duedate2=duedate1.date()
    #delaydays = (eta-duedate2).days
    return eta, nextloc


# <b> Main ETA Finding </b>

# In[ ]:
#prgmstart = time.clock()
prgmstart = datetime.datetime.now().time()
print 'prgmstart', prgmstart
columnsop= ['Con No','ETA','Timestamp']
dfop_sakthi= pd.DataFrame(columns=columnsop)

#*depspaperworkcodelist = ['SRE','DIR','EIR','SIR','SRD','SRS','SRP','DLP','SWP','PWS','HCM','HPM','MOP','SRH','HOC','ONR','SPH','SPO','DBO','DIP','SHS','SSC','HIP']
#corehublist = ['AMCH','AMDH','BLRH','BOMH','BRGH','CCUH','DELH','HYDH','MAAH','NAGH','PNQH','VPIH','VZAH','SXVF']
#*corehublist = ['AMDH','BLRH','BOMH','DELH','HYDH','MAAH','NAGH','PNQH']
#corehublist = ['BOMH','DELH','MAAH','NAGH','BRGH','CCUH','AMCH']
tcrconlist_inv= tcrdata['Con Number'].tolist()
print 'the inventory list has', len(tcrconlist_inv)
#*n = 0
#*for n in range (0, len(tcrconlist_inv)):
    #*currloc = tcrdata.iloc[n]['Hub SC Location']
    #*if currloc in corehublist:
        #*tcrdata.loc[n,'Hub'] = 'Main Hub'
    #*else:
        #*tcrdata.loc[n,'Hub'] = 'Sec Hub'
#*hubcheck = tcrdata[(tcrdata['Hub'] == 'Main Hub')]
#*hubcheckconlist = hubcheck['Con Number'].tolist()
m=0
for m in range (0, len(tcrconlist_inv)):
    connumber = tcrdata.iloc[m]['Con Number']
    print connumber

    #*if connumber in hubcheckconlist:
        #*pass
    #*else:
        #*tcrdata.loc[m,'Remark'] = 'No Prediction'
        #*continue

    origintcr = tcrdata.iloc[m]['Origin Branch']
    destinationtcr = tcrdata.iloc[m]['Destn Branch']
    currloc = tcrdata.iloc[m]['Hub SC Location']
    arrivaltimetcr = tcrdata.iloc[m]['Arrival Date Hub']
    #weights = tcrdata.iloc[m]['Act Wt In Tonnes']
    statuscodes = tcrdata.iloc[m]['Latest Status Code']
    reportts = tcrdata.iloc[m]['TIMESTAMP']
    #print 'timestamp is', reportts 
    timestamp= reportts.to_pydatetime()
    #print timestamp
    duedate = tcrdata.iloc[m]['Due Date']
    duedate1 = duedate.to_pydatetime()
    duedate2=duedate1.date()


    #tcrdata.loc[m,'CurrLoc - Dest'] = "-".join((currloc, destinationtcr))
    #tcrdata.loc[m,'CurrLoc - Dest'] = "-".join(currloc, destinationtcr)
    #*print connumber
    #*if arrivaltimetcr.to_pydatetime() < (timestamp - timedelta(days=30)):
        #*print connumber, 'Old Con'
        #*tcrdata.loc[m,'Observation'] = 'Old Con'
    #*elif statuscodes in depspaperworkcodelist:
        #*tcrdata.loc[m,'Observation'] = 'DEPS/Paperworks'
        #*print connumber, 'DEPS/Paperworks'
    #*else:
        #*tcrdata.loc[m,'Observation'] = 'Correct'
        #*print connumber, 'Correct'

    #*if currloc in corehublist:
        #*tcrdata.loc[m,'Hub'] = 'Main Hub'
    #*else:
        #*tcrdata.loc[m,'Hub'] = 'Sec Hub'

    eta, nextloc = findeta (connumber, origintcr, destinationtcr, currloc, arrivaltimetcr, timestamp)
    dfop_sakthi.loc[m,'Con No'] = connumber
    dfop_sakthi.loc[m,'ETA'] = eta
    dfop_sakthi.loc[m,'Timestamp'] = timestamp
    #cprint 'timestamp is', reportts 
    #print type(eta), eta
    #*tcrdata.loc[m,'CurrLoc - Next Loc'] = "-".join((currloc, nextloc))

    #type(eta) is datetime.date and
    #*if type(eta) is datetime.date and tcrdata.loc[m,'Observation'] == 'Correct':
    if type(eta) is datetime.date:
        #print 'inside'
        delaydays = (eta-duedate2).days
        tcrdata.loc[m,'Delay Days'] = delaydays
        etafuture = eta
        timestampnew = timestamp
        delaydaysnew = delaydays
        
        #including 12 hrs check first to increase speed 19-June-15
        timestampnewtwelve = (timestamp + timedelta(hours= 4))
        etafuturetwelve, nextlocfuturetwelve = findeta (connumber, origintcr, destinationtcr, currloc, arrivaltimetcr, timestampnewtwelve)
        delaydaysnewtwelve = (etafuturetwelve-duedate2).days
        if delaydaysnewtwelve <= delaydays:
            dfop_sakthi.loc[m,'Action Hours'] = '4+'
            continue
        #including 12 hrs check first to increase speed 19-June-15
            
        while delaydaysnew <= delaydays and timestampnew <= (timestamp + timedelta(hours=4)):
            #*print 'check'
            addtime = 1
            timestampnew = timestampnew + timedelta(hours=addtime)
            etafuture, nextlocfuture = findeta (connumber, origintcr, destinationtcr, currloc, arrivaltimetcr, timestampnew)
            delaydaysnew = (etafuture-duedate2).days
            #*tcrdata.loc[m,'Remark'] = 'Prediction Done'
            if delaydaysnew > delaydays:
                #tcrdata.loc[m,'Ideal next depart time'] = timestampnew
                diff = timestampnew - timestamp
                #*print (diff)
                #diff_time = diff.time()
                diff_str = str(diff)
                hoursforaction = (sum(float(x) * 60 ** i for i,x in enumerate(reversed(diff_str.split(":")))))/60
                hoursforaction = float(hoursforaction)/60
                if hoursforaction - 1 == 0:
                    dfop_sakthi.loc[m,'Action Hours'] = hoursforaction #incoporated -1 and hours=5 for more accuracy# '4 hours' wont be shown, only 0,1,2,3,4+. due to processing time constraint
                else:
                    dfop_sakthi.loc[m,'Action Hours'] = hoursforaction - 1 #incoporated -1 and hours=5 for more accuracy
                break
                #*if hoursforaction <= 2:
                    #*tcrdata.loc[m,'Bucket-Action Hours'] = '0 to 2'
                #*elif 2 < hoursforaction <= 4:
                    #*tcrdata.loc[m,'Bucket-Action Hours'] = '2 to 4'
                #*elif 4 < hoursforaction <= 8:
                    #*tcrdata.loc[m,'Bucket-Action Hours'] = '4 to 8'
                #*elif 8 < hoursforaction <= 12:
                    #*tcrdata.loc[m,'Bucket-Action Hours'] = '8 to 12'
                #*else:
                    #*tcrdata.loc[m,'Bucket-Action Hours'] = 'Twelve (12) plus hours'
                #*break

        else:
            #*print connumber, 'outside'
            #tcrdata.loc[m,'Ideal next depart time'] = 'Twelve (12) plus hours'
            dfop_sakthi.loc[m,'Action Hours'] = '4+'
            #*tcrdata.loc[m,'Bucket-Action Hours'] = 'Twelve (12) plus hours'
            #*tcrdata.loc[m,'Remark'] = 'No Change in ETA in next 12 hrs'
            #tcrdata.loc[m,'Remark'] = 'Check for fault'
        ####
    else:
        #print 'outside'
        #*dfop_sakthi.loc[m,'Remark'] = 'No Prediction'
        dfop_sakthi.loc[m,'Action Hours'] = 'NA'

#*coredata=tcrdata[(tcrdata['Observation'] == 'Correct') & (tcrdata['Remark'] != 'No Prediction') & (tcrdata['Hub'] == 'Main Hub')]
#*PT1=pivot_table(coredata,rows=['Hub SC Location','CurrLoc - Next Loc'],columns=['Bucket-Action Hours'],values=['Con Number'],aggfunc='count',fill_value=0,margins=True)
#*PT2=np.round(pivot_table(coredata,rows=['Hub SC Location','CurrLoc - Next Loc'],columns=['Bucket-Action Hours'],values=['Act Wt In Tonnes'],aggfunc=sum,fill_value=0,margins=True), 0)

############## deleted schedule wise weight/con part which was below this. present in original eta slip in pythonanywhere

#############

"""
printlist =  [dfop_sakthi]
namelist = ['Data']
save_xls (printlist, namelist, oppath2)
"""

dfop_sakthi.to_csv('D:/Python/Scripts and Files/Path and Graph Files/ETA_Data_with_Actionhrs.csv')
print 'saving done'
prgmend = datetime.datetime.now().time()
print 'prgmend', prgmend

###### FOR FTP..TEMPORARY

# In[ ]:
print ('Logging in...')
ftp = ftplib.FTP()
#ftp.connect('119.226.230.94')
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppath2
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()

#FTP Upload ends
ftpend = datetime.datetime.now().time()
print 'ftpend is', ftpend


filePath = oppath2
def sendEmail(#TO = ["ashwani.gangwar@spoton.co.in","krishna.kumar.bhardwaj@spoton.co.in","jaisingh.chauhan@spoton.co.in","joseph.arul.seelan@spoton.co.in","dhiraj.patil@spoton.co.in","krishan.kaushik@spoton.co.in","ramniwas.sharma@spoton.co.in","sopanrao.bhoite@spoton.co.in","ramachandran.p@spoton.co.in","manoj.pareek@spoton.co.in","pramod.pandey@spoton.co.in","surendra.pandey@spoton.co.in","onkar.sharma@spoton.co.in","ajay.kumar.singh@spoton.co.in","satyaprakash.vishwakarma@spoton.co.in","sandesh.patade@Spoton.co.in","cnm@spoton.co.in","cstl_spot@spoton.co.in"],
            TO = ["rajeesh.vr@spoton.co.in"],
            #TO = ["vishwas.j@spoton.co.in"],
            CC = ["vishwas.j@spoton.co.in"],
            #CC = ["sqtf@spoton.co.in","sq_spot@spoton.co.in","supratim@iepfund.com","rajesh.kumar@spoton.co.in","pawan.sharma@spoton.co.in","vishwas.j@spoton.co.in","prasanna.hegde@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "SERVER Action Hours ETA FTP" + " - " + str(reportts)
    msg["Subject"] = "SERVER Action Hours ETA FTP" + " - " + str(reportts)
    body_text = """
    Dear All,

    PFA the Action Hours ETA FTP as on """ + str(reportts) +"""

    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
mailend = datetime.datetime.now().time()
print 'mailend is', mailend
#Sending output file via mail ends





# In[ ]:



