
# coding: utf-8

# In[1]:

import pandas as pd
import sframe as gl
import sframe.aggregate as agg
# import graphlab as gl
# import graphlab.aggregate as agg
from datetime import datetime, timedelta
from itertools import permutations
import numpy as np

import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import os
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import Utilities
# In[2]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.87;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()
query = ("""EXEC USP_HUB_THROUGHPUT_DETAILS_SALES_ONEHOUR """)
print (query)
inventory_pd=pd.read_sql(query,Utilities.cnxn)
inventory_pd=inventory_pd[['Hub/SC Location','Arrival Date @ Hub',"Next Frwd Loc","Con Number",'DestnBranch','Act.WtInTonnes','LatestStatusCode',"Volume","TIMESTAMP",'OriginArea','DestnArea']]
inventory_pd.rename(columns={'Hub/SC Location':"Hub SC Location",'Arrival Date @ Hub':"Arrival Date Hub",'DestnBranch':"Destn Branch",'Act.WtInTonnes':"Act Wt In Tonnes",'LatestStatusCode':"Latest Status Code",'OriginArea':"Origin Area",'DestnArea':'Destn Area'},inplace=True)
#converters = {col: str for col in range(8)}
#inventory_pd = pd.read_excel('http://spoton.co.in/downloads/HTR_1HR/HTR_1HR.xls',usecols=["Hub SC Location","Arrival Date Hub","Next Frwd Loc","Con Number","Destn Branch","Act Wt In Tonnes","Latest Status Code","Volume","TIMESTAMP","Origin Area",'Destn Area'])


# In[3]:

inventory_pd.head(2)


# In[4]:

inventory_pd['Latest Status Code'].fillna('OTR',inplace=True)


# In[6]:

inventory_pd = inventory_pd[pd.notnull(inventory_pd['Arrival Date Hub'])]
inventory_pd = inventory_pd[pd.notnull(inventory_pd["Next Frwd Loc"])]


# In[8]:

columnlist = inventory_pd.columns.tolist()
for i in columnlist:
    try:
        if inventory_pd[i][0].dtype=="int64":
            inventory_pd[i].fillna(0,inplace=True)
        else:
            if inventory_pd[i][0].dtype=="float64":
                inventory_pd[i].fillna(0.0,inplace=True)
    except:
        pass


# In[9]:

inventory_pd.to_csv(r'D:\Python\Scripts and Files\Path and Graph Files\inventory.csv') #writing and accessing agan to solve issue with Sframe


# In[10]:

inventory = gl.SFrame.read_csv(r"D:\Python\Scripts and Files\Path and Graph Files\inventory.csv")


# In[12]:
print inventory["Arrival Date Hub"][0]
inventory["Arrival Date Hub"]=inventory.apply(lambda x: datetime.strptime((str(x["Arrival Date Hub"])
                                                                .split(".")[0]),"%Y-%m-%d %H:%M:%S"))
inventory["TIMESTAMP"]=inventory.apply(lambda x: datetime.strptime
                                       ((str(x["TIMESTAMP"]).split(".")[0]),"%Y-%m-%d %H:%M:%S"))
inventory["Ageing_Hours"]=inventory.apply(lambda x: round
                                          ((x["TIMESTAMP"]-x["Arrival Date Hub"]).seconds*1.0/3600,2))
inventory = inventory[inventory["Ageing_Hours"]>2.0]


# In[13]:

inventory["OD"]=inventory.apply(lambda x: x['Origin Area']+"-"+x['Destn Area'])


# In[14]:

depspaperworkcodelist = ['SRE','SRD','SRS','SRP','DLP','SWP','PWS','HCM','HPM','MOP','SRH','HOC','ONR','SPH','SPO','DBO','DIP','SHS','SSC','HIP','RNX','APT','APN','SHD','SMT','SPL','MSH','UCG','RRA','HPE','WIA','UG1','UG2','UG3','HMP','HWC','NPE','HIM']
inventory2 = inventory.filter_by(depspaperworkcodelist,'Latest Status Code', exclude=True)


# In[15]:

inventory_grp0=inventory2.groupby(key_columns=['Hub SC Location','Next Frwd Loc','OD'],operations={'Sum': agg.SUM('Act Wt In Tonnes')})


# In[16]:

inventory_grp0["Sum"] = inventory_grp0.apply(lambda x: round(x["Sum"],3))


# In[18]:

inventory_grp = inventory_grp0.groupby(key_columns=['Hub SC Location','Next Frwd Loc'],
                                  operations={'Sum': agg.SUM('Sum'),'OD':agg.CONCAT('OD','Sum')})
#inventory_grp.rename({"Hub SC Location":"Origin","Next Frwd Loc":"Destination"})


# In[19]:

###NEED TO UPDATE THE SCH DEPARTURE FILE###


# In[20]:

inventory_grp["NEW PATH"] = inventory_grp.apply(lambda x: x["Hub SC Location"]+"-"+x["Next Frwd Loc"])


# In[21]:

inventory_grp2 = inventory_grp.select_columns(["NEW PATH","Sum","OD"])


# In[23]:

relev_time = inventory["TIMESTAMP"].unique()[0]
relev_date = datetime.strptime(str(relev_time).split(" ")[0],"%Y-%m-%d")
relev_date


# In[24]:

schedule1 = gl.SFrame.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\schedule_file.csv')


# In[25]:

schedule1["Route Origin"] = schedule1.apply(lambda x: x["Route Details"].split("-")[0])
schedule1["Route Destn"] = schedule1.apply(lambda x: x["Route Details"].split("-")[-1])


# In[26]:

schedule=schedule1[schedule1["Origin"]==schedule1["Route Origin"]]


# In[27]:

schedule['depart_t1'] = schedule.apply(lambda x: relev_date+timedelta(hours=
        (int(str(x["Departure time"]).split(":")[0])+int(str(x["Departure time"]).split(":")[1])/60)))
schedule['depart_t2'] = schedule.apply(lambda x: relev_date+timedelta(days=1,hours=
        (int(str(x["Departure time"]).split(":")[0])+int(str(x["Departure time"]).split(":")[1])/60)))
schedule['chosen_t1']=schedule.apply(lambda x:x['depart_t2'] if x['depart_t1'].hour<relev_time.hour+1 
                                     else x['depart_t1'])


# In[28]:

schedule["NEW PATH"]=schedule.apply(lambda x: x["Route Origin"]+"-"+x["Route Destn"])


# In[29]:

nextdepartlimit = relev_time+timedelta(hours=10)


# In[30]:

schedule2 = schedule[schedule['chosen_t1']<nextdepartlimit]


# In[31]:

schedule2["nextschdetails"]=schedule2.apply(lambda x: x["Route Code"]+":"+x["Route Details"]+":"+str(x["chosen_t1"]))


# In[32]:

schedule3 = schedule2.select_columns(["NEW PATH",'nextschdetails'])


# In[33]:

shortlistlanes = ["BOMH-DELH","DELH-BOMH","BOMH-AMCH","AMCH-BOMH","BLRH-AMCH","AMCH-BLRH","PNQH-DELH","DELH-PNQH","DELH-BLRH","BLRH-DELH"]


# In[34]:

schedule4 = schedule3.filter_by(shortlistlanes,"NEW PATH")


# In[36]:

shortlistlanessf = gl.SFrame(shortlistlanes)


# In[37]:

shortlistlanessf2 = shortlistlanessf.rename({'X1':"NEW PATH"})


# In[38]:

lhprebuildup = shortlistlanessf2.join(schedule4,on="NEW PATH",how='outer')


# In[39]:

lhbuildup = lhprebuildup.join(inventory_grp2,on="NEW PATH",how='left')


# In[40]:

lhbuildupdf = lhbuildup.to_dataframe()


# In[43]:

lhbuildupdf = lhbuildupdf[pd.notnull(lhbuildupdf['Sum'])]
lhbuildupdf = lhbuildupdf.sort_values("Sum", ascending= False)


# In[45]:

schd = lhbuildupdf[pd.notnull(lhbuildupdf['nextschdetails'])]
noschd = lhbuildupdf[pd.isnull(lhbuildupdf['nextschdetails'])]


# In[46]:

schd.loc[schd.index, 'Remark'] = 'Sch'
noschd.loc[noschd.index, 'Remark'] = 'Market'


# In[47]:

df = schd.append(noschd)


# In[48]:

grpcon = pd.read_csv("D:\Python\Scripts and Files\Path and Graph Files\sector_buildup_routing\File_for_LH_monthend_buildup.csv") #the output report of sector load


# In[49]:

diffdict = {}
for hub, toloc, diff in zip(grpcon["Hub SC Location"], grpcon["Nextloc"], grpcon["diff%"]):
    diffdict[(hub, toloc)] = diff


# In[50]:

def getdiff(od):
    org = od.split('-')[0]
    dest = od.split('-')[1]
    try:
        return diffdict.get((org,dest))
    except:
        return 79
    
def getaction(wt, remark, diff):
    if remark == 'Sch':
        if wt >= 13.5:
            return 'Depart'
    else:
        if (wt >= 13.5) and (diff >0):
            return 'Depart'


# In[51]:

df['Diff%'] = df.apply(lambda x: getdiff(x['NEW PATH']), axis=1)


# In[52]:

df['Action'] = df.apply(lambda x: getaction(x['Sum'],x['Remark'], x['Diff%']), axis=1)


# In[53]:

df = df.rename(columns={'Sum':'Wt(T)'})


# In[54]:
datetimenow = datetime.now()

opfilevar=datetimenow.date()
opfilevar1=datetimenow.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=np.round((float(currhrs)/60),0)

df.to_csv(r'D:\Data\LH_buildup_monthend\Summary\LH_Monthend_Buildup_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv') #attachment
df.to_csv(r'D:\Data\LH_buildup_monthend\Summary\LH_Monthend_Buildup.csv') #attachment
oppath5 = r'D:\Data\LH_buildup_monthend\Summary\LH_Monthend_Buildup.csv'
# In[55]:

dfdepart = df[df['Action']=='Depart']


# In[56]:
dfdepart = dfdepart[['NEW PATH','Wt(T)','Remark','Diff%','Action']]

#dfdepart #mailbody add if else to handle enpty dataframe

if len(dfdepart) != 0:
    dfdepart = dfdepart
    dfdepart = dfdepart.to_string(index=False)
else:
    #grp_finaltable2_maildf = pd.DataFrame()
    dfdepart = 'There is no 13.5T to be departed due to load buildup'


# In[ ]:
filePath = oppath5
def sendEmail(#TO = ["ashwani.gangwar@spoton.co.in","krishna.kumar.bhardwaj@spoton.co.in","jaisingh.chauhan@spoton.co.in","joseph.arul.seelan@spoton.co.in","dhiraj.patil@spoton.co.in","krishan.kaushik@spoton.co.in","ramniwas.sharma@spoton.co.in","sopanrao.bhoite@spoton.co.in","ramachandran.p@spoton.co.in","manoj.pareek@spoton.co.in","pramod.pandey@spoton.co.in","surendra.pandey@spoton.co.in","onkar.sharma@spoton.co.in","ajay.kumar.singh@spoton.co.in","satyaprakash.vishwakarma@spoton.co.in","sandesh.patade@Spoton.co.in","cnm@spoton.co.in","cstl_spot@spoton.co.in"],
            #TO = ["rajeesh.vr@spoton.co.in","Ankit@iepfunds.com","prasanna.hegde@spoton.co.in"],
            TO = ["rajeesh.vr@spoton.co.in"],
            CC = ["vishwas.j@spoton.co.in"],
            #CC = ["sqtf@spoton.co.in","sq_spot@spoton.co.in","supratim@iepfund.com","rajesh.kumar@spoton.co.in","pawan.sharma@spoton.co.in","vishwas.j@spoton.co.in","prasanna.hegde@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "SERVER ETA FTP" + " - " + str(reportts)
    msg["Subject"] = "LH Buildup Report " + "- "+ str(opfilevar)+"-"+str(opfilevar2)
    body_text = """
    Dear All,

    PFA the LH Buildup Report for """ + str(opfilevar)+"-"+str(opfilevar2) +"""
    
    PFB the summary."""+str()+"""

"""+str(dfdepart)+"""

    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    #server=smtplib.SMTP('124.7.138.249', 587)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()



