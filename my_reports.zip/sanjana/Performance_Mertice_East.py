
# coding: utf-8

# In[1]:


import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
import pandas as pd
from datetime import datetime,timedelta
import sys
import pandas.io.sql
import pandas as pd
import numpy as np
import sys
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template


reload(sys).setdefaultencoding("ISO-8859-1")
import Utilities
# In[2]:

try:
    datetoday = datetime.now().date()
    todayminus1 = datetoday-timedelta(days=1)
    todayminus1=datetime.strftime(todayminus1,'%Y-%m-%d')
    #todayminus1='2018-03-11'
    print (todayminus1)

    # In[3]:


    # cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
    # cursor = cnxn.cursor()

    # cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
    # cursor = cnxn.cursor()
    # In[4]:


    #Delivery Efficiency query
    del_eff_query = ("""
            EXEC dbo.USP_DELV_EFF_SC_WISE_ALL 'S', '{0}','{1}'
           """.format(todayminus1,todayminus1))


    # In[5]:


    del_eff_df = pd.read_sql_query(del_eff_query,Utilities.cnxn)


    # In[6]:


    len(del_eff_df)


    # In[7]:


    east_del_eff_df=del_eff_df[del_eff_df['RGALPH']=='E']
    len(east_del_eff_df)


    # In[8]:


    east_del_eff_df


    # In[9]:


    dedf = east_del_eff_df.groupby('ControlArea').agg({'TOTAL':sum,'Delivered':sum}).reset_index()


    # In[10]:


    branch_dedf = east_del_eff_df.groupby('BRNM').agg({'TOTAL':sum,'Delivered':sum}).reset_index()


    # In[11]:


    branch_dedf
    branch_dedf['DE%']=(branch_dedf['Delivered'].divide(branch_dedf['TOTAL'])*100)
    branch_dedf=branch_dedf.replace([np.inf, -np.inf], np.nan)
    # branch_dedf['DE%']=branch_dedf['DE%'].astype(int)
    branch_dedf


    # In[12]:


    dedf['DE%']=dedf['Delivered'].divide(dedf['TOTAL'])*100
    dedf=dedf.replace([np.inf, -np.inf], np.nan)
    # dedf['DE%']=dedf['DE%'].astype(int)


    # In[13]:


    #pickup query
    pickpquery = ("""EXEC dbo.CRM_WEEKLY_PERFORMANCE_SCWISE_DATA_SHIVA_KPI  '{0}','{1}'""".format(todayminus1,todayminus1))
    print ('pickpquery',pickpquery)


    # In[14]:


    pickp_df=pd.read_sql_query(pickpquery,Utilities.cnxn)
    len(pickp_df)


    # In[15]:


    pickp_df.head()


    # In[16]:


    east_pickup_df=pickp_df[pickp_df['RGALPH']=='E']
    print ('east_pickup_df',len(east_pickup_df))

    # In[17]:


    pkdf = east_pickup_df.groupby(['ControlArea']).agg({'Total_Pickups':sum,'Total_Success':sum}).reset_index()


    # In[18]:


    branch_pkdf = east_pickup_df.groupby(['BRNM']).agg({'Total_Pickups':sum,'Total_Success':sum}).reset_index()


    # In[19]:
    print (branch_pkdf)

    try:
        branch_pkdf['Pkp_Per%']=branch_pkdf.apply(lambda x:pd.np.round((x['Total_Success']*1.0/x['Total_Pickups'])*100.0,2),axis=1)
    except:
        branch_pkdf['Pkp_Per%']=0

    # In[20]:


    try:
        pkdf['Pkp_Per%']=pkdf.apply(lambda x:pd.np.round((x['Total_Success']*1.0/x['Total_Pickups'])*100.0,2),axis=1)
    except:
        pkdf['Pkp_Per%']=0

    # In[21]:


    #Fake pickups query
    fake_query=("""EXEC dbo.USP_Pickup_Audit_Report_SHIVA  '{0}','{1}'""".format(todayminus1,todayminus1))
    fake_query


    # In[22]:


    fake_df=pd.read_sql(fake_query,Utilities.cnxn)
    len(fake_df)


    # In[23]:


    east_fake_df=fake_df[fake_df['Region']=='East']
    len(east_fake_df)


    # In[24]:


    grp_fake_df = east_fake_df.groupby(['AREA']).agg({'NotOk':sum}).reset_index()


    # In[25]:


    grp_fake_df.rename(columns={'AREA':'ControlArea'},inplace=True)


    # In[26]:


    branch_fake_df = east_fake_df.groupby(['Branch']).agg({'NotOk':sum}).reset_index()


    # In[27]:


    branch_fake_df.rename(columns={'Branch':'BRNM'},inplace=True)


    # In[28]:


    #undelivered query
    undel_query=("""USP_UNDELIVERED_CONS_GRT_1DAY""")
    undel_query


    # In[29]:


    undel_df=pd.read_sql(undel_query,Utilities.cnxn)
    len(undel_df)


    # In[30]:


    undel_df.head()


    # In[31]:


    east_undel_df=undel_df[undel_df['DESTN_REGION']=='E']
    len(east_undel_df)


    # In[32]:


    grp_undel_df = east_undel_df.groupby(['DESTN_AREA']).agg({'DOCKNO':len}).reset_index()


    # In[33]:


    branch_grp_undel_df = east_undel_df.groupby(['DESTN_BRNM']).agg({'DOCKNO':len}).reset_index()


    # In[34]:


    branch_grp_undel_df.rename(columns={'DESTN_BRNM':'BRNM','DOCKNO':'Undel_Cons'},inplace=True)


    # In[35]:


    grp_undel_df.rename(columns={'DESTN_AREA':'ControlArea','DOCKNO':'Undel_Cons'},inplace=True)


    # In[36]:


    #ccf query
    ccf_query=("""SELECT  --TOP 10
            A.DOCKNO ,
            B.DOCKDT BOOKINGDATE ,
            A.ACTUWT ,
            PIECES ,
            DEST_BRCD ,
            DEST_BRNM ,
            DEST_AREA ,
            DEST_DEPOT ,
            DEST_REGION ,
            DEL_LOCATION_TYPE ,
            VTC ,
            FTC ,
            DACC ,
            DC ,
            A.CSGECD ,
            A.CSGENM ,
            ARRV_AT_DEST_SC ,
            REPORTDATE_MIN_ARRVDT ,
            A.CSGNCD ,
            A.CSGNNM ,
            ORG_BRCD ,
            ORG_BRNM ,
            ORG_AREA ,
            ORG_DEPOT ,
            ORG_REGION ,
            A.DECLVAL ,
            DEST_PINCODE ,
            ConStatusCategory ,
            ConStatusCode ,
            ConStatusDesc ,
            ConStatusReason ,
            ConStatusDate ,
            LogDate ,
            FreeStorageDays ,
            CON_BLOCKED_FOR_PAY_ISSUES ,
            PARENTCODE ,
            PARENTNAME ,
            CON_BLOCKED_FOR_ODA_PIN_ISSUES ,
            CON_BLOCKED_FOR_DEMURRAGE ,
            TTS_AuditStatus ,
            TTS_AuditRemarks ,
            ReportGenConStatusDate ,
            IsTTSTicketRaised ,
            IsApptmntDel ,
            ApptmntDelDate ,
            A.CDELDT DUEDATE ,
            LatestTicketStatus ,
            LatestTicketStatusCode ,
            DEMURRAGE_RESPONSIBILITY ,
            ( SELECT    dbo.UFN_GET_CSAGENTCODE(A.DOCKNO)
            ) AGENTCODE ,
            C.EMPNM AGENTNAME
    FROM    dbo.tblOCIDClosingStock A
            INNER JOIN dbo.DOCKET B WITH ( NOLOCK ) ON B.DOCKNO = A.DOCKNO
            LEFT OUTER JOIN dbo.EMPMST C ON C.EMPCD = ( SELECT  dbo.UFN_GET_CSAGENTCODE(A.DOCKNO)
                                                      )
    WHERE   LogDate = CONVERT(DATE, GETDATE())
            AND ConStatusCategory IN ( 'RECEIVER FAILURE', 'SENDER FAILURE' )
            AND ConStatusCode NOT IN ( 'UCG', 'UG1', 'UG2', 'UG3', 'SSC' )
            AND B.DOCKDT >= 0     """)


    # In[37]:


    ccf_df=pd.read_sql(ccf_query,Utilities.cnxn)
    len(ccf_df)


    # In[38]:


    east_ccf_df=ccf_df[ccf_df['DEST_REGION']=='E']
    len(east_ccf_df)


    # In[39]:


    grp_cc_df = east_ccf_df.groupby(['DEST_AREA']).agg({'DOCKNO':len,'ACTUWT':sum}).reset_index()


    # In[40]:


    branch_grp_cc_df = east_ccf_df.groupby(['DEST_BRNM']).agg({'DOCKNO':len,'ACTUWT':sum}).reset_index()


    # In[41]:


    branch_grp_cc_df.head()
    branch_grp_cc_df.rename(columns={'DEST_BRNM':'BRNM','DOCKNO':'CCF_Cons','ACTUWT':'CCF_Wt'},inplace=True)


    # In[42]:


    grp_cc_df.rename(columns={'DEST_AREA':'ControlArea','DOCKNO':'CCF_Cons','ACTUWT':'CCF_Wt'},inplace=True)


    # In[43]:


    final_df1=pd.merge(dedf,pkdf, on=['ControlArea'],how='outer')
    final_df1


    # In[44]:


    final_df1=pd.merge(final_df1,grp_cc_df,on='ControlArea',how='outer')


    # In[45]:


    final_df1=pd.merge(final_df1,grp_undel_df,on='ControlArea',how='outer' )
    final_df1


    # In[46]:


    grp_fake_df.columns


    # In[47]:


    final_df1=pd.merge(final_df1,grp_fake_df,on='ControlArea',how='outer' )


    # In[48]:


    final_df2=final_df1[['ControlArea','DE%','Pkp_Per%','CCF_Cons','CCF_Wt','Undel_Cons','NotOk']]


    # In[49]:


    final_df2=final_df2.fillna(0)


    # In[50]:


    branch_final_df=pd.merge(branch_dedf,branch_pkdf,on='BRNM',how='outer')


    # In[51]:


    branch_final_df=pd.merge(branch_final_df,branch_grp_cc_df,on='BRNM',how='outer')


    # In[52]:


    branch_final_df=pd.merge(branch_final_df,branch_grp_undel_df,on='BRNM',how='outer')


    # In[53]:


    branch_final_df=pd.merge(branch_final_df,branch_fake_df,on='BRNM',how='outer')


    # In[54]:


    branch_final_df.rename(columns={'NotOk':'Fake-Pickups'},inplace=True)
    branch_final_df['CCF_Wt(T)']=pd.np.round((branch_final_df['CCF_Wt']/1000.0),1)
    branch_final_df1=branch_final_df[['BRNM','DE%','Pkp_Per%','CCF_Cons','CCF_Wt(T)','Fake-Pickups','Undel_Cons']]


    # In[55]:


    branch_final_df2=branch_final_df1.fillna(0)


    # In[57]:


    final_df2['CCF_Wt(T)']=pd.np.round((final_df2['CCF_Wt']/1000.0),1)
    del final_df2['CCF_Wt']


    # In[58]:


    final_df2['DE%']=final_df2['DE%'].astype(int)
    final_df2['Pkp_Per%']=final_df2['Pkp_Per%'].astype(int)
    final_df2['CCF_Cons']=final_df2['CCF_Cons'].astype(int)
    final_df2['CCF_Wt(T)']=final_df2['CCF_Wt(T)'].astype(int)
    final_df2['NotOk']=final_df2['NotOk'].astype(int)


    # In[59]:


    branch_final_df2['DE%']=branch_final_df2['DE%'].astype(int)
    branch_final_df2['Pkp_Per%']=branch_final_df2['Pkp_Per%'].astype(int)
    branch_final_df2['CCF_Cons']=branch_final_df2['CCF_Cons'].astype(int)
    branch_final_df2['CCF_Wt(T)']=branch_final_df2['CCF_Wt(T)'].astype(int)
    branch_final_df2['Fake-Pickups']=branch_final_df2['Fake-Pickups'].astype(int)


    # In[60]:


    final_df2.rename(columns={'ControlArea':'Area','NotOk':'Fake-Pickups'},inplace=True)


    # In[61]:


    #pivot_ccf_df = pd.pivot_table(east_ccf_df,index=["PARENTNAME"],values=["DOCKNO"],aggfunc={"DOCKNO":len},fill_value=0,margins=False)
    pivot_ccf_df = pd.pivot_table(east_ccf_df,index=["PARENTNAME"],values=["DOCKNO","PIECES","ACTUWT"],aggfunc={"DOCKNO":len,"ACTUWT":sum,"PIECES":sum},fill_value=0,margins=False)


    # In[62]:


    pivot_ccf_df1=pivot_ccf_df.sort_values(by='DOCKNO',ascending=False)


    # In[63]:


    final_df3=final_df2[['Area','DE%','Pkp_Per%','CCF_Cons','CCF_Wt(T)','Fake-Pickups','Undel_Cons']]


    # In[68]:


    from pandas import ExcelWriter
    with ExcelWriter(r'D:\Data\East Performance Reports\EAST_Performance_Metrics_Monitoring_'+str(todayminus1)+'.xlsx') as writer:
        final_df3.to_excel(writer,engine='xlsxwriter',sheet_name='Area Summary')
        branch_final_df2.to_excel(writer,engine='xlsxwriter',sheet_name='Branch Summary')
        east_del_eff_df.to_excel(writer,engine='xlsxwriter',sheet_name='Delivery Data')
        east_pickup_df.to_excel(writer,engine='xlsxwriter',sheet_name='Pickup Data')
        east_ccf_df.to_excel(writer,engine='xlsxwriter',sheet_name='CCF Data')
        east_undel_df.to_excel(writer,engine='xlsxwriter',sheet_name='Undelivered Data')
        east_fake_df.to_excel(writer,engine='xlsxwriter',sheet_name='FakePickup Data')
        pivot_ccf_df1.to_excel(writer,engine='xlsxwriter',sheet_name='CCF Customer Wise Data')
        


    # In[69]:


    #filePath=r'C:\Users\S2769MAH\Downloads\SQ\sreedhar\Performance_East.xlsx'
    filePath=r'D:\Data\East Performance Reports\EAST_Performance_Metrics_Monitoring_'+str(todayminus1)+'.xlsx'


    # In[70]:


    from datetime import date,timedelta,datetime
    yes=datetime.strftime(date.today()-timedelta(1),'%Y-%m-%d')


    # In[71]:



    #'shivananda.p@spoton.co.in',
    TO=['badri.pandey@spoton.co.in','md.zaya@spoton.co.in','pramod.kumar@spoton.co.in','susmit.mitra@spoton.co.in','abani.behera@spoton.co.in']
    CC=['abhik.mitra@spoton.co.in','shivananda.p@spoton.co.in','rajesh.kumar@spoton.co.in','jothi.menon@spoton.co.in','pawan.sharma@spoton.co.in','satya.pal@spoton.co.in','mahesh.reddy@spoton.co.in','shashvat.suhane@spoton.co.in','anitha.thyagarajan@spoton.co.in']
    FROM="reports.ie@spoton.co.in"
    #TO=['mahesh.reddy@spoton.co.in']
    #CC=['maheshmahesh11464@gmail.com']
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "Performance Metrics-East" + " - " + str(yes)
    html='''<html>
    <h4>Dear All,</h4>
    <p>PFA the Performance Metrics Monitoring-EAST : $date</p>
    <p><b>Area Wise:</b></p>
    </html>'''
    # html3='''
    # <h3>PFA ADC Summary Cons Reached Destination </h3>

    # '''
    s = Template(html).safe_substitute(date=yes)
    report=""
    report+=s
    report+='<br>'+final_df3.to_html()+'<br>'
    abc=MIMEText(report,'html')
    msg.attach(abc)
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO+CC, msg.as_string())
    server.quit()

except:
  TO=['mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  #msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "Performance Metrics-East Error in Execution" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in Performance Metrics-East'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO, msg.as_string())
  server.quit()


