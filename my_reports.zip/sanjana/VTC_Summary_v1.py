
# coding: utf-8

# In[1]:


import pandas as pd
import pyodbc
from datetime import datetime,timedelta
import numpy as np
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
import smtplib
import Utilities

# In[2]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()


# In[3]:


startdate='2019-05-28 00:00:00'
enddate='2019-07-07 23:59:00'
#enddate=datetime.strftime(datetime.now(),'%Y-%m-%d %H:%M:%S')
startdate,enddate


# In[4]:


query=("""SELECT  CONVERT(VARCHAR(10), DT.DOCKDT, 103) [VTC con pickup date] ,
        CONVERT(VARCHAR(10), DD.DELY_DT, 103) [VTC con delivery date] ,
        CASE WHEN DT.DOC_CURLOC = DT.REASSIGN_DESTCD
             THEN CONVERT(VARCHAR(10), DS.DOD_Recvdt_Dbr, 103)
        END [VTC receive date at Delivery SC] ,
        CASE WHEN EP.CURRBRCD <> 'BLHO'
             THEN CONVERT(VARCHAR(10), DS.COURIER_ENTRYDT, 103)
        END [VTC forwarding date from Delivery SC] ,
        CASE WHEN EP.CURRBRCD <> 'BLHO' THEN DE.CourierNumber
        END [VTC forwarding date from Delivery SC CourierNo] ,
        CASE WHEN EP.CURRBRCD <> 'BLHO' THEN DE.CourierName
        END [VTC forwarding date from Delivery SC CourierName] ,
        CASE WHEN EP.CURRBRCD <> 'BLHO'
             THEN CONVERT(VARCHAR(10), DE.ReceiveDate, 103)
        END [VTC received date at HO] ,
        CASE WHEN DEE.CourierNumber IS NOT NULL
                  AND DEE.ReceiveStatus IS NULL
             THEN CONVERT(VARCHAR(10), DEE.CourierDate, 103)
        END [VTC forwarding date from HO TO Customer] ,
        CASE WHEN DEE.CourierNumber IS NOT NULL
                  AND DEE.ReceiveStatus IS NULL THEN DEE.CourierNumber
        END [VTC forwarding date from HO TO Customer CourierNo] ,
        CASE WHEN DEE.CourierNumber IS NOT NULL
                  AND DEE.ReceiveStatus IS NULL THEN DEE.CourierName
        END [VTC forwarding date from HO TO Customer CourierName] ,
        DT.CSGNCD ,
        DT.CSGNNM ,
        DS.DOD_AMT ,
        DS.DOD_NO ,
        DT.DOCKNO ,
        BD.BRCD ,
        BD.BRNM ,
        BD.DEPOT_CODE ,
        DEE.CourierPickupDate ,
        DEE.CourierDeliveryDate ,
        DEE.CourierDlvStatus ,
        DEE.CourierDlvRemarks
FROM    dbo.DOCKET DT WITH ( NOLOCK )
        INNER JOIN brms BD WITH ( NOLOCK ) ON BD.BRCD = DT.DESTCD
        LEFT OUTER JOIN dbo.DKT_DELY DD WITH ( NOLOCK ) ON DD.DOCKNO =
DT.DOCKNO
        LEFT OUTER JOIN dbo.DKT_DOD DS WITH ( NOLOCK ) ON DS.DOCKNO =
DT.DOCKNO
        LEFT OUTER JOIN dbo.EMPMST EP WITH ( NOLOCK ) ON EP.EMPCD =
DS.COURIER_ENTRYBY
        LEFT OUTER JOIN DKT_DOD_STATUS DE WITH ( NOLOCK ) ON DS.AUTOID =
DE.AutoId
                                                             AND
DE.ReceiveStatus = 'Y'
        LEFT OUTER JOIN DKT_DOD_STATUS DEE WITH ( NOLOCK ) ON DS.AUTOID =
DEE.AutoId
                                                              AND
DEE.ReceiveStatus IS NULL
WHERE   DT.ApplyVTC = 1
        AND DD.DELY_DT BETWEEN '{0}' AND '{1}'""").format(startdate,enddate)

df=pd.read_sql(query,Utilities.cnxn)


# In[6]:


df1=df[df['DEPOT_CODE']=='NCRD']

df1.drop_duplicates('DOCKNO',inplace=True)
# In[7]:


df.to_csv(r'D:\Data\VTC Data\VTC_Data.csv')


# In[8]:


len(df1)


# In[9]:


df1['VTC receive at Delivery SC']=df1['VTC receive date at Delivery SC'].apply(lambda x: 1 if x!=None else 0)


# In[10]:


df1['VTC forwarding from Delivery SC']=df1['VTC forwarding date from Delivery SC'].apply(lambda x: 1 if x!=None else 0)


# In[11]:


df1['VTC received at HO']=df1['VTC received date at HO'].apply(lambda x: 1 if x!=None else 0)


# In[12]:


df1['VTC forwarding from HO']=df1['VTC forwarding date from HO TO Customer'].apply(lambda x: 1 if x!=None else 0)
df1['VTC_Received_By_Customer']=df1['CourierDlvStatus'].apply(lambda x: 1 if x!=None else 0)

# In[13]:


mtdsummary=df1.pivot_table(index=['BRCD','BRNM'],aggfunc={'VTC_Received_By_Customer':sum,'VTC con delivery date':len,'VTC receive at Delivery SC':sum,'VTC forwarding from Delivery SC':sum,'VTC received at HO':sum,'VTC forwarding from HO':sum})
df1['Delivery Date']=df1['VTC con delivery date']
mtdsummary123=df1.pivot_table(index=['Delivery Date'],aggfunc={'VTC_Received_By_Customer':sum,'VTC con delivery date':len,'VTC receive at Delivery SC':sum,'VTC forwarding from Delivery SC':sum,'VTC received at HO':sum,'VTC forwarding from HO':sum}).reset_index()
mtdsummary123['Delivery Date']=pd.to_datetime(mtdsummary123['Delivery Date'],format='%d/%m/%Y')
mtdsummary123.sort_values('Delivery Date',ascending=True,inplace=True)
mtdsummary123=mtdsummary123[['Delivery Date','VTC con delivery date','VTC receive at Delivery SC','VTC forwarding from Delivery SC','VTC received at HO','VTC forwarding from HO','VTC_Received_By_Customer']]
mtdsummary123.loc['Total']=mtdsummary123.sum(axis=0)
mtdsummary123=mtdsummary123.fillna(0)
mtdsummary=mtdsummary.reset_index()


# In[15]:


mtdsummary['Delivered Not Rcvd@Sc']=mtdsummary['VTC con delivery date']-mtdsummary['VTC receive at Delivery SC']
mtdsummary['Rcvd @Sc not Forwarded to HO']=mtdsummary['VTC receive at Delivery SC']-mtdsummary['VTC forwarding from Delivery SC']
mtdsummary['Forwarded to HO but not Recvd @ HO']=mtdsummary['VTC forwarding from Delivery SC']-mtdsummary['VTC received at HO']
mtdsummary['Received @ HO not forwarded to Customer']=mtdsummary['VTC received at HO']-mtdsummary['VTC forwarding from HO']


# In[ ]:


# mtdsummary.rename(columns={'VTC forwarding date from Delivery SC_val':'VTC forwarding date from Delivery SC','VTC forwarding date from HO_val':'VTC forwarding date from HO','VTC receive date at Delivery SC_val':'VTC receive date at Delivery SC','VTC received date at HO_val':'VTC received date at HO'},inplace=True)


# In[ ]:


# mtdsummary.loc['Total']=mtdsummary.sum(axis=0)


# In[16]:


mtdsummary1=mtdsummary[['BRCD','BRNM','VTC con delivery date','VTC receive at Delivery SC','VTC forwarding from Delivery SC','VTC received at HO','VTC forwarding from HO','VTC_Received_By_Customer','Delivered Not Rcvd@Sc','Rcvd @Sc not Forwarded to HO','Forwarded to HO but not Recvd @ HO','Received @ HO not forwarded to Customer']]


# In[17]:


mtdsummary1.loc['Total']=mtdsummary1[['VTC con delivery date','VTC receive at Delivery SC','VTC forwarding from Delivery SC','VTC received at HO','VTC forwarding from HO','VTC_Received_By_Customer','Delivered Not Rcvd@Sc','Rcvd @Sc not Forwarded to HO','Forwarded to HO but not Recvd @ HO','Received @ HO not forwarded to Customer']].sum(axis=0)


# In[18]:


mtdsummary1=mtdsummary1.fillna(0)


# In[19]:


for i in ['VTC con delivery date','VTC receive at Delivery SC','VTC forwarding from Delivery SC','VTC received at HO','VTC forwarding from HO','Delivered Not Rcvd@Sc','Rcvd @Sc not Forwarded to HO','Forwarded to HO but not Recvd @ HO','Received @ HO not forwarded to Customer','VTC_Received_By_Customer']:
    if i in ['BRCD','BRNM']:
        pass
    else:
        mtdsummary1[i]=mtdsummary1[i].astype(int)


# In[20]:


mtdsummary1


# In[ ]:


##MTD Summary


# In[21]:


yestdate=datetime.strftime(datetime.now()-timedelta(days=1),'%d/%m/%Y')
# yestdate='01/06/2019'


# In[22]:


yestdf=df1[df1['VTC con delivery date']==yestdate]


# In[ ]:


len(yestdf)


# In[23]:


yestsummary=yestdf.pivot_table(index=['BRCD'],aggfunc={'VTC_Received_By_Customer':sum,'VTC con delivery date':len,'VTC receive at Delivery SC':sum,'VTC forwarding from Delivery SC':sum}).reset_index()


# In[24]:


yestsummary


# In[ ]:


# yestsummary.rename(columns={'VTC forwarding date from Delivery SC_val':'VTC forwarding date from Delivery SC','VTC receive date at Delivery SC_val':'VTC receive date at Delivery SC'},inplace=True)


# In[ ]:


yestsummary


# In[27]:


try:
    yestsummary1=yestsummary[['BRCD','VTC con delivery date','VTC receive at Delivery SC','VTC forwarding from Delivery SC']]
    yestsummary1.loc['Total']=yestsummary1[['VTC con delivery date','VTC receive at Delivery SC','VTC forwarding from Delivery SC']].sum(axis=0)
    yestsummary1=yestsummary1.fillna(0)
    for i in ['VTC con delivery date','VTC receive at Delivery SC','VTC forwarding from Delivery SC']:
        if i == 'BRCD':
            pass
        else:
            yestsummary1[i]=yestsummary1[i].astype(int) 
except:
    yestsummary1=pd.DataFrame()


# In[28]:


yestsummary1


# In[ ]:


## Customerwise summary


# In[29]:


customer_summary=yestdf.pivot_table(index=['CSGNCD', 'CSGNNM'],aggfunc={'VTC received at HO':sum,'VTC forwarding from HO':sum}).reset_index()


# In[ ]:


# customer_summary.rename(columns={'VTC received date at HO_val':'VTC received date at HO','VTC forwarding date from HO_val':'VTC forwarding date from HO'},inplace=True)


# In[30]:


try:
    customer_summary=customer_summary[['CSGNCD','CSGNNM','VTC received at HO','VTC forwarding from HO']]
    customer_summary.loc['Total']=customer_summary[['VTC received at HO','VTC forwarding from HO']].sum(axis=0)
    customer_summary=customer_summary.fillna(0)
    for i in ['VTC received at HO','VTC forwarding from HO']:
        customer_summary[i]=customer_summary[i].astype(int)
except:
    customer_summary=pd.DataFrame()


# In[31]:


customer_summary


# In[32]:
## BLRD and AMDD added

startdate1='2019-06-18 00:00:00'
enddate1='2019-07-07 23:59:00'
# enddate1=datetime.strftime(datetime.now(),'%Y-%m-%d %H:%M:%S')
startdate1,enddate1


# In[4]:


query=("""SELECT  CONVERT(VARCHAR(10), DT.DOCKDT, 103) [VTC con pickup date] ,
        CONVERT(VARCHAR(10), DD.DELY_DT, 103) [VTC con delivery date] ,
        CASE WHEN DT.DOC_CURLOC = DT.REASSIGN_DESTCD
             THEN CONVERT(VARCHAR(10), DS.DOD_Recvdt_Dbr, 103)
        END [VTC receive date at Delivery SC] ,
        CASE WHEN EP.CURRBRCD <> 'BLHO'
             THEN CONVERT(VARCHAR(10), DS.COURIER_ENTRYDT, 103)
        END [VTC forwarding date from Delivery SC] ,
        CASE WHEN EP.CURRBRCD <> 'BLHO' THEN DE.CourierNumber
        END [VTC forwarding date from Delivery SC CourierNo] ,
        CASE WHEN EP.CURRBRCD <> 'BLHO' THEN DE.CourierName
        END [VTC forwarding date from Delivery SC CourierName] ,
        CASE WHEN EP.CURRBRCD <> 'BLHO'
             THEN CONVERT(VARCHAR(10), DE.ReceiveDate, 103)
        END [VTC received date at HO] ,
        CASE WHEN DEE.CourierNumber IS NOT NULL
                  AND DEE.ReceiveStatus IS NULL
             THEN CONVERT(VARCHAR(10), DEE.CourierDate, 103)
        END [VTC forwarding date from HO TO Customer] ,
        CASE WHEN DEE.CourierNumber IS NOT NULL
                  AND DEE.ReceiveStatus IS NULL THEN DEE.CourierNumber
        END [VTC forwarding date from HO TO Customer CourierNo] ,
        CASE WHEN DEE.CourierNumber IS NOT NULL
                  AND DEE.ReceiveStatus IS NULL THEN DEE.CourierName
        END [VTC forwarding date from HO TO Customer CourierName] ,
        DT.CSGNCD ,
        DT.CSGNNM ,
        DS.DOD_AMT ,
        DS.DOD_NO ,
        DT.DOCKNO ,
        BD.BRCD ,
        BD.BRNM ,
        BD.DEPOT_CODE ,
        DEE.CourierPickupDate ,
        DEE.CourierDeliveryDate ,
        DEE.CourierDlvStatus ,
        DEE.CourierDlvRemarks
FROM    dbo.DOCKET DT WITH ( NOLOCK )
        INNER JOIN brms BD WITH ( NOLOCK ) ON BD.BRCD = DT.DESTCD
        LEFT OUTER JOIN dbo.DKT_DELY DD WITH ( NOLOCK ) ON DD.DOCKNO =
DT.DOCKNO
        LEFT OUTER JOIN dbo.DKT_DOD DS WITH ( NOLOCK ) ON DS.DOCKNO =
DT.DOCKNO
        LEFT OUTER JOIN dbo.EMPMST EP WITH ( NOLOCK ) ON EP.EMPCD =
DS.COURIER_ENTRYBY
        LEFT OUTER JOIN DKT_DOD_STATUS DE WITH ( NOLOCK ) ON DS.AUTOID =
DE.AutoId
                                                             AND
DE.ReceiveStatus = 'Y'
        LEFT OUTER JOIN DKT_DOD_STATUS DEE WITH ( NOLOCK ) ON DS.AUTOID =
DEE.AutoId
                                                              AND
DEE.ReceiveStatus IS NULL
WHERE   DT.ApplyVTC = 1
        AND DD.DELY_DT BETWEEN '{0}' AND '{1}'""").format(startdate1,enddate1)

dff=pd.read_sql(query,Utilities.cnxn)
dff=dff[dff['DEPOT_CODE'].isin(['BLRD','AMDD'])]

dff['VTC receive at Delivery SC']=dff['VTC receive date at Delivery SC'].apply(lambda x: 1 if x!=None else 0)

dff['VTC forwarding from Delivery SC']=dff['VTC forwarding date from Delivery SC'].apply(lambda x: 1 if x!=None else 0)

dff['VTC received at HO']=dff['VTC received date at HO'].apply(lambda x: 1 if x!=None else 0)

dff['VTC forwarding from HO']=dff['VTC forwarding date from HO TO Customer'].apply(lambda x: 1 if x!=None else 0)
dff['VTC_Received_By_Customer']=dff['CourierDlvStatus'].apply(lambda x: 1 if x!=None else 0)

dff['Delivery Date']=dff['VTC con delivery date']
remmtdsummary123=dff.pivot_table(index=['DEPOT_CODE','Delivery Date'],
                                 values=['VTC_Received_By_Customer','VTC con delivery date','VTC receive at Delivery SC','VTC forwarding from Delivery SC'
                                         ,'VTC received at HO','VTC forwarding from HO'],
                                aggfunc={'VTC_Received_By_Customer':sum,'VTC con delivery date':len,'VTC receive at Delivery SC':sum,
                                         'VTC forwarding from Delivery SC':sum,'VTC received at HO':sum,'VTC forwarding from HO':sum}
                                 ,margins=True).reset_index()

remmtdsummary123=remmtdsummary123[['DEPOT_CODE','Delivery Date','VTC con delivery date','VTC receive at Delivery SC',
                                   'VTC forwarding from Delivery SC','VTC received at HO','VTC forwarding from HO','VTC_Received_By_Customer']]
remmtdsummary123=remmtdsummary123.fillna(0)

remmtdsummary=dff.pivot_table(index=['BRCD','BRNM'],
                              values=['VTC_Received_By_Customer','VTC con delivery date','VTC receive at Delivery SC','VTC forwarding from Delivery SC','VTC received at HO','VTC forwarding from HO'],
                              aggfunc={'VTC_Received_By_Customer':sum,'VTC con delivery date':len,'VTC receive at Delivery SC':sum,
                                                             'VTC forwarding from Delivery SC':sum,
                                                             'VTC received at HO':sum,'VTC forwarding from HO':sum},margins=True).reset_index()


remmtdsummary['Delivered Not Rcvd@Sc']=remmtdsummary['VTC con delivery date']-remmtdsummary['VTC receive at Delivery SC']
remmtdsummary['Rcvd @Sc not Forwarded to HO']=remmtdsummary['VTC receive at Delivery SC']-remmtdsummary['VTC forwarding from Delivery SC']
remmtdsummary['Forwarded to HO but not Recvd @ HO']=remmtdsummary['VTC forwarding from Delivery SC']-remmtdsummary['VTC received at HO']
remmtdsummary['Received @ HO not forwarded to Customer']=remmtdsummary['VTC received at HO']-remmtdsummary['VTC forwarding from HO']

remmtdsummary=remmtdsummary[['BRCD','BRNM','VTC con delivery date','VTC receive at Delivery SC','VTC forwarding from Delivery SC','VTC received at HO','VTC forwarding from HO','VTC_Received_By_Customer','Delivered Not Rcvd@Sc','Rcvd @Sc not Forwarded to HO','Forwarded to HO but not Recvd @ HO','Received @ HO not forwarded to Customer']]

date=datetime.strftime(datetime.now(),'%Y-%m-%d')


# In[33]:


filepath=r'D:\Data\VTC Data\VTC_Data.csv'


# In[35]:


TO=['dinesh.kumar.sharma@spoton.co.in','balakrishnan.r@spoton.co.in','dominic.sathish@spoton.co.in','shiva.prasad@spoton.co.in','manzil.bhattacharya@spoton.co.in','aom_spot@spoton.co.in','scincharge_spot@spoton.co.in']
# TO=['saptarshi.pathak@spoton.co.in']
#TO=['aom_spot@spoton.co.in','dom_spot@spoton.co.in','rom_spot@spoton.co.in','scincharge_spot@spoton.co.in','banusanketh.dc@spoton.co.in']
CC=["satya.pal@spoton.co.in","abhik.mitra@spoton.co.in",'krishna.chandrasekar@spoton.co.in','saptarshi.pathak@spoton.co.in','mahesh.reddy@spoton.co.in']
# CC=['mahesh.reddy@spoton.co.in']
# BCC=['mahesh.reddy@spoton.co.in']
FROM="reports.ie@spoton.co.in"
# FROM="mahesh.reddy@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
# msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "VTC Pilot Report (28 May - 07 July 2019)" + " - " + str(date)
report=""
report+="Dear All"
report+='<br>'
report+='<br>'
report+='Please find VTC Report '
report+='<br>'
report+='<br>'
report+="NCRD Date Wise MTD Summary"
report+='<br>'+mtdsummary123.to_html()+'<br>'
report+='<br>'

report+='<br>'
report+="BLRD&AMDD Date Wise MTD Summary"
report+='<br>'+remmtdsummary123.to_html()+'<br>'
report+='<br>'

report+='<br>'
report+="NCRD Branch Wise MTD Summary"
report+='<br>'+mtdsummary1.to_html()+'<br>'
report+='<br>'

report+='<br>'
report+="BLRD&AMDD Branch Wise MTD Summary"
report+='<br>'+remmtdsummary.to_html()+'<br>'
report+='<br>'

report+="Yesterday Sc level Summary"
report+='<br>'
report+='<br>'+yestsummary1.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+="Yesterday Customerwise Summary"
report+='<br>'
report+='<br>'+customer_summary.to_html()+'<br>'


abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)


# server=smtplib.SMTP('smtp.sendgrid.net', 587)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("mahesh.reddy@spoton.co.in", "Nov@2018")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()


