
# coding: utf-8

# In[1]:

import pandas as pd
from datetime import datetime, timedelta

import os
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from pandas import ExcelWriter
from email import encoders
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import Utilities
# In[2]:
#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
#cursor = cnxn.cursor()

query = ("""EXEC USP_THC_TRANSIT_IEP_REPORT """)
print (query)
#intransitdata = pd.read_csv(r'http://spoton.co.in/downloads/IEP_THC_INTRANSIT_REPORT/IEP_THC_INTRANSIT_REPORT.csv')
#intransitdata = pd.read_csv(r'C:\Users\s1602vis\Documents\IPython Notebooks\Intransit_CNM\IEP_THC_INTRANSIT_REPORT.csv')
intransitdata = pd.read_sql(query, Utilities.cnxn)

# In[3]:

print len(intransitdata)
## For excluding Data THCs
intransitdata = intransitdata[intransitdata['THC_ROUTE_TYPE']!='D']
## For excluding Data THCs

print len(intransitdata)
## For excluding Data THCs




# In[6]:
## For slicing dataframe where origin and destination are in main hublist
corehublist = ['AMCH','AMDH','BLRH','BOMH','BRGH','CCUH','DELH','HYDH','MAAH','NAGH','PNQH','VPIH','VZAH','SXVF']
def org_dest_hublist(thcorigin,thcdest):
    if (thcorigin in corehublist) and (thcdest in corehublist):
        return 'YES'
    else:
        return 'NO'
## For slicing dataframe where origin and destination are in main hublist

# In[7]:

def tc_thc_dest_same(tcdest,thcdest):
    if tcdest==thcdest:
        return 'Yes'
    else:
        return 'No'


# In[8]:

def datestring(x):
    try:
        fulldate = datetime.strptime(x,'%d-%m-%Y %H:%M:%S')
        return fulldate
    except:
        fulldate = datetime.strptime(x,'%d-%m-%Y %H:%M')
        return fulldate


# In[9]:

def timediff(ts,deptime):
    diff = (ts - deptime).total_seconds()
    diff = pd.np.round(diff/3600.0,2)
    return diff


# In[10]:

intransitdata['THC_TC_DEST_SAME'] = intransitdata.apply(lambda x:tc_thc_dest_same(x['TCDESTN'],x['THCDESTN']),axis=1)
intransitdata['TimeStampDate'] = intransitdata.apply(lambda x:datestring(x['TimeStampDate']),axis=1)
intransitdata['THC_DEPARTURE_DATE'] = intransitdata.apply(lambda x:datestring(x['THC_DEPARTURE_DATE']),axis=1)


# In[11]:

intransitdata['Dep_Time_Diff'] = intransitdata.apply(lambda x:timediff(x['TimeStampDate'],x['THC_DEPARTURE_DATE']),axis=1)

# In[14]:
## For slicing dataframe where origin and destination are in main hublist
intransitdata['THC_ORG_DEST_IN_CORE_LIST']  = intransitdata.apply(lambda x:org_dest_hublist(x['THCORIGIN'],x['THCDESTN']),axis=1)
## For slicing dataframe where origin and destination are in main hublist


# In[15]:
## For slicing dataframe where update time is greater than 6 hours
intransit_not_updated = intransitdata[intransitdata['Dep_Time_Diff']>=8.0]
## For slicing dataframe where update time is greater than 6 hours

## For slicing dataframe where TC Dest and THC Dest is same. To avoid touching vehicles
intransit_not_updated = intransit_not_updated[intransit_not_updated['THC_TC_DEST_SAME']=='Yes']
## For slicing dataframe where TC Dest and THC Dest is same. To avoid touching vehicles

## For slicing dataframe where Org and Dest are in main hublist
intransit_not_updated = intransit_not_updated[intransit_not_updated['THC_ORG_DEST_IN_CORE_LIST']=='YES']
## For slicing dataframe where Org and Dest are in main hublist


## For excluding Updated THCs by CNM or GPS
updatebylist = ['CNM','GPS']
intransit_not_updated = intransit_not_updated[~intransit_not_updated['THC_UPDATED_BY'].isin(updatebylist)]
intransit_not_updated = intransit_not_updated.drop_duplicates(['THCNO'])
## For excluding Updated THCs by CNM or GPS
print len(intransitdata)

try:
    intransit_not_updated.loc[intransit_not_updated.index,'Status'] = 'Not_updated'
except:
    print 'No not updated THCs'


## For getting THCs whose last update hr is more than 8. May it be GPS or CNM
intransit_no_rcnt_update = intransitdata[intransitdata['THC_UPDATED_BY'].isin(updatebylist)]
## For excluding Updated THCs by CNM or GPS
print len(intransit_no_rcnt_update)
print intransit_no_rcnt_update['THC_LAST_UPDATE_HR'].values[0],type(intransit_no_rcnt_update['THC_LAST_UPDATE_HR'].values[0])
intransit_no_rcnt_update = intransit_no_rcnt_update[intransit_no_rcnt_update['THC_LAST_UPDATE_HR']>8.0]
print len(intransit_no_rcnt_update)
intransit_no_rcnt_update = intransit_no_rcnt_update[intransit_no_rcnt_update['THC_TC_DEST_SAME']=='Yes']
intransit_no_rcnt_update = intransit_no_rcnt_update[intransit_no_rcnt_update['THC_ORG_DEST_IN_CORE_LIST']=='YES']
intransit_no_rcnt_update = intransit_no_rcnt_update.drop_duplicates(['THCNO'])

try:
    intransit_no_rcnt_update.loc[intransit_no_rcnt_update.index,'Status'] = 'Update_before_8hrs'
except:
    print 'No not updated THCs'

print len(intransit_no_rcnt_update)
## For getting THCs whose last update hr is more than 8. May it be GPS or CNM


# In[16]:


## Appending THCs not updated recently and no updates
intransit_not_updated=intransit_not_updated.append(intransit_no_rcnt_update,ignore_index=True)
## Appending THCs not updated recently and no updates
intransit_not_updated = intransit_not_updated.rename(columns={'\xef\xbb\xbfTC_NO':'TC_NO'})

intransit_not_updated = pd.DataFrame(intransit_not_updated,columns=['TC_NO','TC_DT','TCORIGIN','TCDESTN','TOTAL_TC_CONS','TOTAL_TC_WT','THCNO','THCORIGIN','THCDESTN','THC_ROUTE_CODE','THC_ROUTE_NAME','THC_ROUTE_TYPE','THC_DEPARTURE_DATE','THC_DEPARTURE_TIME','THC_SCHDEULED_DEPARTURE_TIME','THC_Reached_Not_Inscanned','THC_ETA','TOTAL_THC_CONS','TOTAL_THC_WT','THC_LAST_UPDATE_HR','THC_UPDATED_BY','TimeStampDate','THC_TC_DEST_SAME','Dep_Time_Diff','THC_ORG_DEST_IN_CORE_LIST','Status'])



ts= datetime.now()
opfilevar=ts.date()
opfilevar1=ts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=pd.np.round(float(currhrs)/60)
# In[17]:

intransit_not_updated.to_csv(r'D:\Python\Scripts and Files\Path and Graph Files\secto_buildup_routing_INTRANSIT\storage\CNM_not_updated_new_intransit_23122016\CNM_'+ str(opfilevar)+str('-')+ str(opfilevar2)+'.csv') 

oppath_cnm_no_update = r'D:\Python\Scripts and Files\Path and Graph Files\secto_buildup_routing_INTRANSIT\storage\CNM_not_updated_new_intransit_23122016\CNM_'+ str(opfilevar)+str('-')+ str(opfilevar2)+'.csv'


# In[ ]:
## CNM NOT UPDATED FILE EMAIL
thc_noupdates =len(intransit_not_updated)
print 'thc_noupdates',thc_noupdates
emailhourslist = [7.0,14.0,21.0]
#emailhourslist = [90.0]

print opfilevar2
if opfilevar2 in emailhourslist:
    print 'CNM EMAIL'
    filePath = oppath_cnm_no_update
    def sendEmail(TO = ["Cnm@Spoton.Co.In","Raghavendra.Rao@Spoton.Co.In"],
                #TO = ["mahesh.re@spoton.co.in"],
                #TO = ["vishwas.j@spoton.co.in"],
                CC = ["Rajesh.Kumar@Spoton.Co.In","mahesh.reddy@spoton.co.in"],
                #CC = ["rajeesh.vr@spoton.co.in","vishwas.j@spoton.co.in"],
                #CC = ["vishwas.j@spoton.co.in"],
                FROM="reports.ie@spoton.co.in"):
        HOST = "smtp.spoton.co.in"
    #smtplib.SMTP('smtp.spoton.co.in', 25)
    
        msg = MIMEMultipart()
        msg["From"] = FROM
        msg["To"] = ",".join(TO)
        msg["CC"] = ",".join(CC)
        msg["Subject"] = "GPS/CNM Not updated THCs " + '- ' + str(opfilevar)+str('-')+ str(opfilevar2)
        body_text = """
        Dear All,
        
        PFA the THCs for which there are no GPS/CNM updates or where the update is greater than 8 hours
        
        The number of THCs not updated or where the update is greater than 8 hours = """+str(thc_noupdates)+"""
    
        """
    
        if body_text:
            msg.attach( MIMEText(body_text) )
        part = MIMEBase('application', "octet-stream")
        part.set_payload( open(filePath,"rb").read() )
        Encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
        msg.attach(part)
        server=smtplib.SMTP('smtp.sendgrid.net', 587)
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login("spoton.net.in", "Star@123#")
    
        try:
            failed = server.sendmail(FROM, TO+CC, msg.as_string())
            server.close()
        except Exception, e:
            errorMsg = "Unable to send email. Error: %s" % str(e)
    
    if __name__ == "__main__":
        sendEmail()
    #print('Email sent')
    
else:
    print 'No email for CNM'
    
## CNM NOT UPDATED FILE EMAIL


