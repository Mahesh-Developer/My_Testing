
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta,datetime
from string import Template
import sys
import Utilities
reload(sys).setdefaultencoding("ISO-8859-1")


# In[2]:


# cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")


# # In[3]:


# cursor=cnxn.cursor()

#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
#cursor = cnxn.cursor()


# In[4]:


query=("""EXEC USP_CON_IMAGE_KPI""")


# In[5]:


df=pd.read_sql(query,Utilities.cnxn)


# In[6]:


def getDtMt(val):
    date1=datetime.strftime(val,'%d-%b')
    return date1


# In[7]:


df['Date']=df.apply(lambda x: getDtMt(x['DOCKDT']),axis=1)


# In[8]:


def getMtYr(val1):
    mtyr=datetime.strftime(val1,'%b-%y')
    return mtyr


# In[9]:


df['Month']=df.apply(lambda x: getMtYr(x['DOCKDT']),axis=1)
df=df.rename(columns={'BOOKING_REGION':'Region','ControlArea':'Area','BOOKING_BRCODE':'Org Brn'})


# In[16]:


from datetime import date, timedelta
today_date=date.today()
previous_month=today_date-timedelta(30)
last_month=today_date-timedelta(90)
last_month
p_month=datetime.strftime(previous_month,'%b')
p_month
l_month=datetime.strftime(last_month,'%b')
c_month=datetime.strftime(today_date,'%b')

print (c_month)
# In[17]:


#fil_df=df[~(df['Date'].str.contains(p_month)) & ~(df['Date'].str.contains(l_month))]
fil_df=df[~df['Date'].str.contains(l_month)]
fil_df['Date'].unique()
cur_df=fil_df[fil_df['Date'].str.contains(c_month)]
print (fil_df['Month'].unique())
print (len(cur_df))
# In[57]:


#Region & Area current month region wise
fil_pivot_df=pd.pivot_table(cur_df,index=['Region','Area'],columns=['Month','Date'],values=['DOCKNO'],aggfunc={'DOCKNO':len},fill_value=0,margins=True)
fil_pivot_df=fil_pivot_df.astype(int)
# fil_pivot_df


# In[44]:


#Region & Area All months
region_area_pivot_df=pd.pivot_table(fil_df,index=['Region','Area'],columns=['Month','Date'],values=['DOCKNO'],aggfunc={'DOCKNO':len},fill_value=0,margins=True)
region_area_pivot_df=region_area_pivot_df.astype(int)


# In[58]:


#Full data month wise
full_mnth_wise_pivot_df=pd.pivot_table(fil_df,index=['Region','Area'],columns=['Month'],values=['DOCKNO'],aggfunc={'DOCKNO':len},fill_value=0,margins=True)
full_mnth_wise_pivot_df=full_mnth_wise_pivot_df.astype(int)
# full_mnth_wise_pivot_df


# In[22]:


# tab_tots = full_mnth_wise_pivot_df.groupby(level='Region').sum()
# tab_tots.index = [tab_tots.index, ['Total'] * len(tab_tots)]
# print(tab_tots)


# In[28]:


# full_df2=pd.concat(
#     [full_mnth_wise_pivot_df, tab_tots]
# ).sort_index(ascending=False).append(
#     full_mnth_wise_pivot_df.sum().rename(('Grand', 'Total'))
# )
# full_df2


# In[29]:


full_date_wise_pivot_df=pd.pivot_table(df,index=['Region','Area'],columns=['Month','Date'],values=['DOCKNO'],aggfunc={'DOCKNO':len},fill_value=0,margins=True)
# full_date_wise_pivot_df


# In[30]:


tab_tots = full_date_wise_pivot_df.groupby(level='Region').sum()
tab_tots.index = [tab_tots.index, ['Total'] * len(tab_tots)]
# print(tab_tots)


# In[31]:


full_date_df2=pd.concat(
    [full_date_wise_pivot_df, tab_tots]
).sort_index(ascending=False).append(
    full_date_wise_pivot_df.sum().rename(('Grand', 'Total'))
)
# full_date_df2


# In[34]:


#full date wise Region data
full_date_df2.drop('All',inplace=True)
full_date_df2=full_date_df2.astype(int)
# full_date_df2


# In[45]:


#sc wise current month data
region_pivot_df=pd.pivot_table(cur_df,index=['Org Brn'],columns=['Month','Date'],values=['DOCKNO'],aggfunc={'DOCKNO':len},fill_value=0,margins=True)
region_pivot_df.drop('All',inplace=True)


# In[46]:


region_pivot_df=region_pivot_df.sort_values([('DOCKNO', 'All')],ascending=False).astype(int)
# region_pivot_df


# In[47]:


#top ten Sc wise
topten_region_pivot_df=region_pivot_df.head(10)
# topten_region_pivot_df


# In[48]:


#sc wise Full data
sc_full_pivot_df=pd.pivot_table(fil_df,index=['Org Brn'],columns=['Month','Date'],values=['DOCKNO'],aggfunc={'DOCKNO':len},fill_value=0,margins=True)
sc_full_pivot_df=sc_full_pivot_df.astype(int)


# In[49]:


# tab_tots = sc_full_pivot_df.groupby(level='Org Brn').sum()
# tab_tots.index = [tab_tots.index, ['Total'] * len(tab_tots)]
# print(tab_tots)


# In[52]:


# sc_full_date_df2=pd.concat(
#     [sc_full_pivot_df, tab_tots]
# ).sort_index(ascending=False).append(
#     sc_full_pivot_df.sum().rename(('Grand', 'Total'))
# )
# sc_full_date_df2


# In[53]:
d=datetime.now()
date=datetime.strftime(d,'%d-%b-%Y')
date
time=datetime.strftime(d,'%H:%M')
time


from pandas import ExcelWriter
with ExcelWriter(r'D:\Data\ODA_Loads_Ton_wise\Con_Image_Not_Uploaded'+str(date)+'.xlsx') as writer:
    sc_full_pivot_df.to_excel(writer,engine='xlsxwriter',sheet_name='SC wise Full data')
    region_area_pivot_df.to_excel(writer,engine='xlsxwriter',sheet_name='Region wise Full data')
    region_pivot_df.to_excel(writer,engine='xlsxwriter',sheet_name='SC wise Current mnth data')
    fil_pivot_df.to_excel(writer,engine='xlsxwriter',sheet_name='Region wise Current mnth data')
    df.to_excel(writer,engine='xlsxwriter',sheet_name='Con Details')



# In[54]:


filepath=r'D:\Data\ODA_Loads_Ton_wise\Con_Image_Not_Uploaded'+str(date)+'.xlsx'


# In[55]:





# In[59]:


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os

from_addr = 'mis.ho@spoton.co.in'


#cc_addr = ['maheshmahesh11464@gmail.com','mahesh.reddy@spoton.co.in']
cc_addr=['sqtf@spoton.co.in','SQ_spot@spoton.co.in']
#bcc_addr = ['mahesh.reddy@spoton.co.in']
bcc_addr=['rom_spot@spoton.co.in','aom_spot@spoton.co.in','dom_spot@spoton.co.in','scincharge_spot@spoton.co.in','anitha.thyagarajan@spoton.co.in']

username = 'mis.ho@spoton.co.in'
password = 'Spot@123'

msg = MIMEMultipart()

msg['From'] = from_addr
msg['cc'] = ', '.join(cc_addr)
msg['bcc'] = ', '.join(bcc_addr)
msg['Subject'] = 'Con Image Not Uploaded Report 1st May 2018 to '+str(date)+' executed today at'+str(time)
html='''<html>
<h4>Dear All,</h4>
<p>Please find below Con Image Not Uploaded Report for your reference and necessary action. Report executed at $time Hrs</p>
<p>Top Defaulter SC</p>
</html>'''
html3='''
<p>Area Wise Summary</p>
'''
html1='''<h5>Thanks & Regards</h5></b>
<h5>HO-SQ</h5>'''
    
#  msg.attach(part10)
s = Template(html).safe_substitute(time=time)
report=""
report+=s
report+='<br>'
report+='<br>'+topten_region_pivot_df.to_html()+'<br>'
report+='<br>'
report+=html3
report+='<br>'
report+='<br>'+fil_pivot_df.to_html()+'<br>'
report+='<br>'+full_mnth_wise_pivot_df.to_html()+'<br>'

report+=html1
abc=MIMEText(report,'html')
msg.attach(abc)
server = smtplib.SMTP('smtp.sendgrid.net',587)
part=MIMEBase('application','octet-stream')
# part1=MIMEBase('application','octet-stream')
part.set_payload(open(filepath,'rb').read())
# part1.set_payload(open(filepath1,'rb').read())
encoders.encode_base64(part)
# Encoders.encode_base64(part1)
part.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath))
# part1.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath1))
msg.attach(part)
# msg.attach(part1)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
server.sendmail(from_addr,cc_addr+bcc_addr,msg.as_string())
print ('mail sent succesfully')
server.quit()

