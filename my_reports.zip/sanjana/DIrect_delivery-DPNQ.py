
# coding: utf-8

# In[1]:

import pandas as pd
import pandas.io.sql
import pandas as pd
import sys
import numpy as np
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from sqlalchemy import *
import datetime
# from datetime import datetime,timedelta
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import smtplib
import requests as req
import json
import os
import Utilities

date=datetime.datetime.now().date()
month=date.strftime('%Y-%m')
# ### for cpkg cost existing route

# In[2]:

# df=pd.read_csv(r'pmd-june-nov.csv')


# In[3]:

# main=df[['PINCODE2','ACT_WT2','COST2','SENDERCODE2']]


# In[4]:

# main=df[['PINCODE2','RouteName','ACT_WT2','COST2']]


# In[5]:

# maingrp=main.groupby(['PINCODE2','SENDERCODE2']).agg({'ACT_WT2':sum,'COST2':sum}).reset_index()


# In[6]:

# maingrp=main.groupby(['PINCODE2','RouteName']).agg({'ACT_WT2':sum,'COST2':sum}).reset_index()


# In[7]:

# maingrp['CPKG']=maingrp.apply(lambda x: round(x['COST2']/x['ACT_WT2'],2),axis=1)


# In[8]:

maingrp=pd.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\DirectDeliveryFiles\cpkg.csv')


# In[9]:

# maingrp=[['PINCODE2','SENDERCODE2','CPKG']]


# In[10]:

# pincode=df[['PINCODE2','BRANCH_CODE2']]


# In[11]:

pincode=pd.read_excel(r'D:\Python\Scripts and Files\Path and Graph Files\DirectDeliveryFiles\Book1.xlsx')


# In[12]:

pincode=pincode.drop_duplicates(['PinCode']).reset_index()


# In[13]:

pincode=pincode.rename_axis({'PinCode':'PINCODE2'},axis=1)


# ### For feeder cost

# In[14]:

pmddata = pd.read_excel(r'http://spoton.co.in/downloads/PMDLH/PMDLH.xls')


# In[15]:

# pmddata=pd.read_excel(r'/home/stl/Desktop/shashvat/PMDLH_2017-12-31.xlsx')


# In[16]:

pmddata = pmddata[(pmddata['ORIGIN']=='PNQH') & ((pmddata['ROUTE NAME'].str.contains('PNQC'))|(pmddata['ROUTE NAME'].str.contains('PHRB'))) & (pmddata['VEHICLE NUMBER']!='DATA-VEH')]


# In[17]:

len(pmddata)


# In[18]:

def datetimeconv(thcdttm):
    thcdt = thcdttm.date()
    return thcdt


# In[19]:

today = datetime.datetime.now().date()


# In[20]:

pmddata['THC DATE'] = pmddata.apply(lambda x:datetimeconv(x['THC DATE']),axis=1)


# In[21]:

pmddata = pmddata[pmddata['THC DATE']!=today]


# In[22]:

pmddata1=pmddata[~(pmddata['DESTINATION']=='PNQC')]


# In[23]:

pmddata=pmddata[pmddata['DESTINATION']=='PNQC']


# In[24]:

pmddata1['DESTINATION']='PHRB'


# In[25]:

pmddata=pd.concat([pmddata,pmddata1])


# In[26]:

#pmddata.to_csv('PMdlh.csv')


# In[27]:

pmddatagrp = pd.pivot_table(pmddata,index=['THC DATE','DESTINATION'],values=['THC NUMBER','VEHICLE PAYLOAD','TOTAL ACTUAL LOAD','COST'], aggfunc={'THC NUMBER':len,'VEHICLE PAYLOAD':sum,'TOTAL ACTUAL LOAD':sum,'COST':sum}).reset_index()


# In[28]:

pmddatagrp=pmddatagrp.rename_axis({'THC DATE':'DATE2'},axis=1)


# In[29]:

# feeder cost was taken from satish file consulted by ramniwas which is pnqc=0.48 phrb=0.56


# In[30]:

def feedercost(branch):
    if branch=='PNQC':
        return 0.48
    else:
        return 0.56


# In[31]:

pmddatagrp['feeder cost']=pmddatagrp.apply(lambda x: feedercost(x['DESTINATION']),axis=1)


# ### for main data

# In[32]:

# data=pd.read_csv(r'PMD_2017-12-30.csv')


# In[33]:

# data=pd.read_csv(r'http://spoton.co.in/downloads/PMD/PMD.csv')

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()
query=("""SELECT CASE WHEN PUDTYPE = 'ADHOC'   

                          AND (( A.MKT_SBA_APPLICABLE = 'Y'   

                                OR A.MKT_HIRE_REASON = 'DEDICATED FOR SINGLE CUSTOMER'   

                                OR A.MKT_HIRE_REASON = 'NSL SHIPMENT'   

                                OR A.MKT_HIRE_REASON = 'LATE NIGHT/EARLY MORNING'   

                              )   

                          OR ( A.SENDERCODE = '000119837'    

                               OR A.SENDERCODE = '000118040'   

                               OR A.SENDERCODE = '000118041'   

                               OR A.SENDERCODE = '000119721'   

                               OR A.SENDERCODE = '000120083'   

                             )) THEN 'ADHOC-Special'   

                     ELSE PUDTYPE   

                END PUDTYPE_STATUS ,a.* FROM dbo.tblPUDYestMtdData  a  WITH (NOLOCK)""")
data=pd.read_sql(query,Utilities.cnxn)
# data=pd.read_csv(r'http://spoton.co.in/downloads/PMD/PMD.csv')

# df=df.rename(columns={})
# In[36]:

# data.to_csv('PMD.csv')

data=data.rename(columns={'BRANCH_CODE':'BRANCH_CODE2','PINCODE':'PINCODE2','DATE':'DATE2','PUDTYPE':'PUDTYPE2','COST':'COST2','ACT_WT':'ACT_WT2','SENDERCODE':'SENDERCODE2'})
# In[37]:


# In[34]:

dff=data[data['BRANCH_CODE2']=='DPNQ']


# In[35]:

dff['DATE2']=dff.apply(lambda x:x['DATE2'].date(),axis=1)


# In[36]:

# dff.to_csv(r'PMD.csv')


# In[37]:

dff.COST2.sum()


# In[38]:

dff=dff[~(dff['PUDTYPE2']=='COUNTER')]


# In[39]:

dff=pd.merge(pincode,dff,on='PINCODE2',how='right')


# In[40]:

dff=dff.rename_axis({'ControllingBRCD':'DESTINATION'},axis=1).reset_index()


# In[41]:
try:
	dffa=dff[~(dff['DESTINATION'].isin(['PNQC','PHRB']))]


	# In[42]:

	dffb=dff[dff['DESTINATION'].isin(['PNQC','PHRB'])]


	# In[43]:

	# dffa['DESTINATION']='PHRB'


	# In[44]:

	url1 = 'https://maps.googleapis.com/maps/api/distancematrix/json?'
	url3 = '&mode=driving&language=En'
	url4='&key=AIzaSyB1vQavw0Wao_3rr08EI0b-rstREE5HaT0'
	def getdist(pincode):
	    url = url1+str('&origins=INDIA, 411012')+str('&destinations=INDIA, '+str(pincode))+url3+url4
	    r = req.get(url)
	    text = r.text
	    json_data=json.loads(text)
	    a = json_data['rows']
	    try:
	        addcheck= a[0]['elements'][0]['status']
	    except:
	        addcheck = 'UNKNOWN_ERROR'
	    if addcheck == 'NOT_FOUND' or addcheck == 'ZERO_RESULTS':
	        return 'Address not found'
	    elif addcheck == 'UNKNOWN_ERROR':
	        return 'UNKNOWN_ERROR'
	    else:
	        distance1=(a[0]['elements'][0]['distance']['value'])/1000
	    url = url1+str('&origins=INDIA, 412308')+str('&destinations=INDIA, '+str(pincode))+url3+url4
	    r = req.get(url)
	    text = r.text
	    json_data=json.loads(text)
	    a = json_data['rows']
	    try:
	        addcheck= a[0]['elements'][0]['status']
	    except:
	        addcheck = 'UNKNOWN_ERROR'
	    if addcheck == 'NOT_FOUND' or addcheck == 'ZERO_RESULTS':
	        return 'Address not found'
	    elif addcheck == 'UNKNOWN_ERROR':
	        return 'UNKNOWN_ERROR'
	    else:
	        distance2=(a[0]['elements'][0]['distance']['value'])/1000
	    if distance1>150 and distance2>150:
	        return 'PNQC'
	    if distance1>distance2:
	        return 'PHRB'
	    else:
	        return'PNQC'


	# In[45]:

	dffa['DESTINATION']=dffa.apply(lambda x:getdist(x['PINCODE2']),axis=1)


	# In[46]:

	dffa


	# In[47]:

	# dffa=dffa[~(dffa['DESTINATION']=='UNKNOWN')]


	# In[48]:

	dff=pd.concat([dffa,dffb])
except:
	pass


# In[49]:

dff.head()


# In[50]:

# dffa=dff[dff['BAVEHNO']=='MH16AE8549']


# In[51]:

# dffb=dff[~(dff['BAVEHNO']=='MH16AE8549')]


# In[52]:

# stdgrp=dffa.groupby('DATE2').agg({'COST2':sum}).reset_index()


# In[53]:

# stdlen=len(stdgrp['COST2'])


# In[54]:

# price=max(1.2*1760*stdlen,1.2*dffa.ACT_WT2.sum())


# In[55]:

# stdgrp['COST2']=price/stdlen


# In[56]:

# dff=pd.concat([dffa,dffb])


# In[57]:

pincode2=dff.pivot_table(index=['DATE2', 'DESTINATION','PINCODE2','SENDERCODE2'],values='ACT_WT2',aggfunc=sum,fill_value=0).reset_index()


# In[58]:

pincode2=pd.merge(pincode2,maingrp,on=['PINCODE2','SENDERCODE2'],how='left')


# In[59]:

pincode2


# In[60]:

pincode2['CPKG']=pincode2['CPKG'].fillna(1)


# In[61]:

pincode2['ProbableDeliveryCost']=pincode2.apply(lambda x:round(x['ACT_WT2_x']*x['CPKG'],2),axis=1)


# In[62]:


# In[63]:

finalpudcost=pincode2.groupby('DATE2').agg({'ProbableDeliveryCost':sum}).reset_index()



# In[65]:

pivot=dff.pivot_table(index=['DATE2', 'DESTINATION'],values='ACT_WT2',aggfunc=sum,margins=True,fill_value=0).reset_index()


# In[66]:


# In[67]:

feedercost=pd.merge(pmddatagrp,pivot,on=['DATE2','DESTINATION'],how='outer')


# In[68]:

# In[69]:

feedercost=feedercost.fillna(0)


# In[70]:

feedercost=feedercost.rename_axis({'ACT_WT2':'DD_Loads','TOTAL ACTUAL LOAD':'Feeder Load'},axis=1)


# In[71]:

def excess(ddload,feederload,vehcapacity):
    if ddload==0:
    	return 0
    load=ddload+feederload-vehcapacity
    if load>0:
        return load
    else:
        return 0


# In[72]:

feedercost['Excess_Load']=feedercost.apply(lambda x :excess(x['DD_Loads'],x['Feeder Load'],x['VEHICLE PAYLOAD']),axis=1)


# In[73]:

def cost(excess,feedercost):
    if excess>0:
        return round(excess*feedercost,2)
    else:
        return 0


# In[74]:

feedercost['MKT_Feeder_Cost']=feedercost.apply(lambda x :cost(x['Excess_Load'],x['feeder cost']),axis=1)


# In[75]:

feedercost


# In[76]:

finalfeedercost=feedercost.groupby('DATE2').agg({'MKT_Feeder_Cost':sum}).reset_index()


# In[77]:

finalweight=dff.pivot_table(index='DATE2',columns='PUDTYPE2',values='ACT_WT2',aggfunc=sum,margins=True,fill_value=0).reset_index()


# In[78]:

finalcost=dff.pivot_table(index='DATE2',columns='PUDTYPE2',values='COST2',aggfunc=sum,fill_value=0).reset_index()
DATE2=[datetime.datetime.today().replace(day=i).date() for i in range(1,datetime.datetime.today().day) if datetime.datetime.today().replace(day=i).weekday()!=6]
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

holidayquery = ("""
        select * from tblYearlyHolidayMst with (nolock) where HDAY_DATE>'2016-01-01'
        """)

holidaymaster = pd.read_sql(holidayquery, Utilities.cnxn)
PNQAholiday=holidaymaster[holidaymaster['ControlArea']=='PNQA']
x=[i.date() for i in PNQAholiday.HDAY_DATE.tolist()]
# In[79]:
ab=pd.DataFrame(columns=['DATE2'])
ab.DATE2=list(set(DATE2)-set(x))
finalcost=pd.merge(finalcost,ab,on='DATE2',how='outer').fillna(0).sort_values('DATE2')


# In[80]:

# finalcost=pd.merge(finalcost,stdgrp,on='DATE2',how='outer')


# In[81]:

# finalcost['COST2']=finalcost['COST2'].fillna(0)


# In[82]:

# finalcost['STD']=finalcost.apply(lambda x:x['STD']+x['COST2'],axis=1)


# In[83]:

# del finalcost['COST2']


# In[84]:

finalcost['ManpowerCost']=round(195000/(12*26))


# In[85]:

# finalcost['FIXED']=0


# In[86]:

finalcost


# In[87]:

# ic = finalcost[finalcost['DATE2']<=datetime.datetime.strptime('2018-02-08','%Y-%m-%d').date()].index
# finalcost.loc[ic,'FIXED'] = 2115

ic = finalcost[finalcost['DATE2']<=datetime.datetime.strptime('2018-02-08','%Y-%m-%d').date()].index
finalcost.loc[ic,'ManpowerCost'] = 2960

# In[88]:

try:
    finalcost['All_COST']=finalcost.apply(lambda x:x['ADHOC']+x['FIXED']+x['STD']+x['ManpowerCost'],axis=1)
except:
    try:
        finalcost['All_COST']=finalcost.apply(lambda x:x['FIXED']+x['STD']+x['ManpowerCost'],axis=1)
    except:
    	try:
        	finalcost['All_COST']=finalcost.apply(lambda x:x['ADHOC']+x['STD']+x['ManpowerCost'],axis=1)
        except:
        	try:
        		finalcost['All_COST']=finalcost.apply(lambda x:x['ADHOC']+x['FIXED']+x['ManpowerCost'],axis=1)
        	except:
        		try:
        			finalcost['All_COST']=finalcost.apply(lambda x:x['ADHOC']+x['ManpowerCost'],axis=1)
        		except:
        			try:
        				finalcost['All_COST']=finalcost.apply(lambda x:x['FIXED']+x['ManpowerCost'],axis=1)
        			except:
        				finalcost['All_COST']=finalcost.apply(lambda x:x['STD']+x['ManpowerCost'],axis=1)

# In[89]:

finalweight=finalweight.rename_axis({'ADHOC':'ADHOC_WT','FIXED':'FIXED_WT','STD':'STD_WT','All':'All_WT'},axis=1)


# In[90]:

finalcost=finalcost.rename_axis({'ADHOC':'ADHOC_COST','FIXED':'FIXED_COST','STD':'STD_COST','All':'All_COST'},axis=1)


# In[91]:

finaldf=pd.merge(finalweight,finalcost,on='DATE2',how='right')
finaldf=finaldf.merge(finalpudcost,on='DATE2',how='left').merge(finalfeedercost,on='DATE2',how='left').fillna(0).sort_values('DATE2')


# In[92]:

finaldf['HandlingCostForSC']=finaldf.apply(lambda x:x['All_WT']*0.2,axis=1)


# In[93]:

finaldf['TotalDeliveredFromSC_Cost']=finaldf.apply(lambda x: x['ProbableDeliveryCost']+x['MKT_Feeder_Cost']+x['HandlingCostForSC'],axis=1)


# In[94]:


# In[100]:

finaldf['Savings']=finaldf.apply(lambda x:x['TotalDeliveredFromSC_Cost']-x['All_COST'],axis=1)


# In[95]:

finaldf.Savings.sum()


# In[96]:

finaldf
col=['DATE2','ADHOC_WT','FIXED_WT','STD_WT','All_WT','ADHOC_COST','FIXED_COST','STD_COST','ManpowerCost','All_COST','ProbableDeliveryCost','MKT_Feeder_Cost','HandlingCostForSC','TotalDeliveredFromSC_Cost','Savings']
col1=['DATE2','FIXED_WT','STD_WT','All_WT','FIXED_COST','STD_COST','ManpowerCost','All_COST','ProbableDeliveryCost','MKT_Feeder_Cost','HandlingCostForSC','TotalDeliveredFromSC_Cost','Savings']
col2=['DATE2','ADHOC_WT','STD_WT','All_WT','ADHOC_COST','STD_COST','ManpowerCost','All_COST','ProbableDeliveryCost','MKT_Feeder_Cost','HandlingCostForSC','TotalDeliveredFromSC_Cost','Savings']
col3=['DATE2','ADHOC_WT','FIXED_WT','All_WT','ADHOC_COST','FIXED_COST','ManpowerCost','All_COST','ProbableDeliveryCost','MKT_Feeder_Cost','HandlingCostForSC','TotalDeliveredFromSC_Cost','Savings']
col4=['DATE2','STD_WT','All_WT','STD_COST','ManpowerCost','All_COST','ProbableDeliveryCost','MKT_Feeder_Cost','HandlingCostForSC','TotalDeliveredFromSC_Cost','Savings']
col5=['DATE2','ADHOC_WT','All_WT','ADHOC_COST','ManpowerCost','All_COST','ProbableDeliveryCost','MKT_Feeder_Cost','HandlingCostForSC','TotalDeliveredFromSC_Cost','Savings']
col6=['DATE2','FIXED_WT','All_WT','FIXED_COST','ManpowerCost','All_COST','ProbableDeliveryCost','MKT_Feeder_Cost','HandlingCostForSC','TotalDeliveredFromSC_Cost','Savings']
# In[109]:
sav=round(finaldf['Savings'].sum())
# try:
# 	values=['Total',finaldf['ADHOC_WT'].sum(),finaldf['ADHOC-Special_WT'].sum(),finaldf['FIXED_WT'].sum(),finaldf['STD_WT'].sum(),finaldf['All_WT'].sum(),finaldf['ADHOC_COST'].sum(),finaldf['ADHOC-Special_COST'].sum(),finaldf['FIXED_COST'].sum(),finaldf['STD_COST'].sum(),finaldf['ManpowerCost'].sum(),finaldf['All_COST'].sum(),finaldf['ProbableDeliveryCost'].sum(),finaldf['MKT_Feeder_Cost'].sum(),finaldf['HandlingCostForSC'].sum(),finaldf['TotalDeliveredFromSC_Cost'].sum(),sav]
# except:
#     try:
#         values=['Total',finaldf['ADHOC-Special_WT'].sum(),finaldf['FIXED_WT'].sum(),finaldf['STD_WT'].sum(),finaldf['All_WT'].sum(),finaldf['ADHOC-Special_COST'].sum(),finaldf['FIXED_COST'].sum(),finaldf['STD_COST'].sum(),finaldf['ManpowerCost'].sum(),finaldf['All_COST'].sum(),finaldf['ProbableDeliveryCost'].sum(),finaldf['MKT_Feeder_Cost'].sum(),finaldf['HandlingCostForSC'].sum(),finaldf['TotalDeliveredFromSC_Cost'].sum(),sav]
#     except:
#         try:
try:
	values=['Total',finaldf['ADHOC_WT'].sum(),finaldf['FIXED_WT'].sum(),finaldf['STD_WT'].sum(),finaldf['All_WT'].sum(),finaldf['ADHOC_COST'].sum(),finaldf['FIXED_COST'].sum(),finaldf['STD_COST'].sum(),finaldf['ManpowerCost'].sum(),finaldf['All_COST'].sum(),finaldf['ProbableDeliveryCost'].sum(),finaldf['MKT_Feeder_Cost'].sum(),finaldf['HandlingCostForSC'].sum(),finaldf['TotalDeliveredFromSC_Cost'].sum(),sav]
	i=1
except:
	try:
		values=['Total',finaldf['FIXED_WT'].sum(),finaldf['STD_WT'].sum(),finaldf['All_WT'].sum(),finaldf['FIXED_COST'].sum(),finaldf['STD_COST'].sum(),finaldf['ManpowerCost'].sum(),finaldf['All_COST'].sum(),finaldf['ProbableDeliveryCost'].sum(),finaldf['MKT_Feeder_Cost'].sum(),finaldf['HandlingCostForSC'].sum(),finaldf['TotalDeliveredFromSC_Cost'].sum(),sav]
		i=2
	except:
		try:
			values=['Total',finaldf['ADHOC_WT'].sum(),finaldf['FIXED_WT'].sum(),finaldf['All_WT'].sum(),finaldf['ADHOC_COST'].sum(),finaldf['FIXED_COST'].sum(),finaldf['ManpowerCost'].sum(),finaldf['All_COST'].sum(),finaldf['ProbableDeliveryCost'].sum(),finaldf['MKT_Feeder_Cost'].sum(),finaldf['HandlingCostForSC'].sum(),finaldf['TotalDeliveredFromSC_Cost'].sum(),sav]
			i=3
		except:
			try:
				values=['Total',finaldf['ADHOC_WT'].sum(),finaldf['STD_WT'].sum(),finaldf['All_WT'].sum(),finaldf['ADHOC_COST'].sum(),finaldf['STD_COST'].sum(),finaldf['ManpowerCost'].sum(),finaldf['All_COST'].sum(),finaldf['ProbableDeliveryCost'].sum(),finaldf['MKT_Feeder_Cost'].sum(),finaldf['HandlingCostForSC'].sum(),finaldf['TotalDeliveredFromSC_Cost'].sum(),sav]
				i=4
			except:
				try:
					values=['Total',finaldf['STD_WT'].sum(),finaldf['All_WT'].sum(),finaldf['STD_COST'].sum(),finaldf['ManpowerCost'].sum(),finaldf['All_COST'].sum(),finaldf['ProbableDeliveryCost'].sum(),finaldf['MKT_Feeder_Cost'].sum(),finaldf['HandlingCostForSC'].sum(),finaldf['TotalDeliveredFromSC_Cost'].sum(),sav]
					i=5
				except:
					try:
						values=['Total',finaldf['ADHOC_WT'].sum(),finaldf['All_WT'].sum(),finaldf['ADHOC_COST'].sum(),finaldf['ManpowerCost'].sum(),finaldf['All_COST'].sum(),finaldf['ProbableDeliveryCost'].sum(),finaldf['MKT_Feeder_Cost'].sum(),finaldf['HandlingCostForSC'].sum(),finaldf['TotalDeliveredFromSC_Cost'].sum(),sav]
						i=6
					except:
						values=['Total',finaldf['FIXED_WT'].sum(),finaldf['All_WT'].sum(),finaldf['FIXED_COST'].sum(),finaldf['ManpowerCost'].sum(),finaldf['All_COST'].sum(),finaldf['ProbableDeliveryCost'].sum(),finaldf['MKT_Feeder_Cost'].sum(),finaldf['HandlingCostForSC'].sum(),finaldf['TotalDeliveredFromSC_Cost'].sum(),sav]
						i=7



# In[110]:
try:
	totaldf=pd.DataFrame(data=[values],columns=col)
except:
	if i==2:
		totaldf=pd.DataFrame(data=[values],columns=col1)
	elif i==3:
		totaldf=pd.DataFrame(data=[values],columns=col3)
	elif i==4:
		totaldf=pd.DataFrame(data=[values],columns=col2)
	elif i==5:
		totaldf=pd.DataFrame(data=[values],columns=col4)
	elif i==6:
		totaldf=pd.DataFrame(data=[values],columns=col5)
	else:
		totaldf=pd.DataFrame(data=[values],columns=col6)

finaldf=finaldf.append(totaldf,ignore_index=True)

def cpk(cost,wt):
	try:
		return round((cost*1.0)/wt,2)
	except:
		return 0
try:
	finaldf['ADHOC-CPK']=finaldf.apply(lambda x:cpk(x['ADHOC_COST'],x['ADHOC_WT']),axis=1)
except:
	pass
try:
	finaldf['STD-CPK']=finaldf.apply(lambda x:cpk(x['STD_COST'],x['STD_WT']),axis=1)
except:
	pass
try:
	finaldf['FIXED-CPK']=finaldf.apply(lambda x:cpk(x['FIXED_COST'],x['FIXED_WT']),axis=1)
except:
	pass
finaldf['All-CPK']=finaldf.apply(lambda x:cpk(x['All_COST']-x['ManpowerCost'],x['All_WT']),axis=1)
# In[101]:

finaldf
try:
	finaldf=finaldf[['DATE2','ADHOC_WT','FIXED_WT','STD_WT','All_WT','ADHOC_COST','FIXED_COST','STD_COST','ManpowerCost','All_COST','ADHOC-CPK','FIXED-CPK','STD-CPK','All-CPK','ProbableDeliveryCost','MKT_Feeder_Cost','HandlingCostForSC','TotalDeliveredFromSC_Cost','Savings']]
except:
	try:
		finaldf=finaldf[['DATE2','FIXED_WT','STD_WT','All_WT','FIXED_COST','STD_COST','ManpowerCost','All_COST','FIXED-CPK','STD-CPK','All-CPK','ProbableDeliveryCost','MKT_Feeder_Cost','HandlingCostForSC','TotalDeliveredFromSC_Cost','Savings']]
	except:
		try:
			finaldf=finaldf[['DATE2','ADHOC_WT','STD_WT','All_WT','ADHOC_COST''STD_COST','ManpowerCost','All_COST','ADHOC-CPK','STD-CPK','All-CPK','ProbableDeliveryCost','MKT_Feeder_Cost','HandlingCostForSC','TotalDeliveredFromSC_Cost','Savings']]
		except:
			try:
				finaldf=finaldf[['DATE2','ADHOC_WT','FIXED_WT','All_WT','ADHOC_COST','FIXED_COST','ManpowerCost','All_COST','ADHOC-CPK','FIXED-CPK','All-CPK','ProbableDeliveryCost','MKT_Feeder_Cost','HandlingCostForSC','TotalDeliveredFromSC_Cost','Savings']]
			except:
				try:
					finaldf=finaldf[['DATE2','STD_WT','All_WT','STD_COST','ManpowerCost','All_COST','STD-CPK','All-CPK','ProbableDeliveryCost','MKT_Feeder_Cost','HandlingCostForSC','TotalDeliveredFromSC_Cost','Savings']]
				except:
					try:
						finaldf=finaldf[['DATE2','FIXED_WT','All_WT','FIXED_COST','ManpowerCost','All_COST','FIXED-CPK','All-CPK','ProbableDeliveryCost','MKT_Feeder_Cost','HandlingCostForSC','TotalDeliveredFromSC_Cost','Savings']]
					except:
						finaldf=finaldf[['DATE2','ADHOC_WT','All_WT','ADHOC_COST','ManpowerCost','All_COST','ADHOC-CPK','All-CPK','ProbableDeliveryCost','MKT_Feeder_Cost','HandlingCostForSC','TotalDeliveredFromSC_Cost','Savings']]



k=['DATE2','ADHOC_WT','FIXED_WT','STD_WT','All_WT','ADHOC_COST','FIXED_COST','STD_COST','ManpowerCost','All_COST','ProbableDeliveryCost','MKT_Feeder_Cost','HandlingCostForSC','TotalDeliveredFromSC_Cost','Savings']
# for i in k:
#     try:
#         finaldf[i]=pd.np.round(finaldf[i])
#     except:
#         pass

for i in k:
    try:
        finaldf[i]=finaldf[i].astype('int')
    except:
        pass
try:
	finaldf['ADHOC_WT']=finaldf['ADHOC_WT'].fillna(0).astype('int')
except:
	pass
try:
	maildf=finaldf[['DATE2','ADHOC_WT','FIXED_WT','STD_WT','All_WT','ADHOC_COST','FIXED_COST','STD_COST','ManpowerCost','All_COST','ADHOC-CPK','FIXED-CPK','STD-CPK','All-CPK','Savings']]
except:
	try:
		maildf=finaldf[['DATE2','FIXED_WT','STD_WT','All_WT','FIXED_COST','STD_COST','ManpowerCost','All_COST','FIXED-CPK','STD-CPK','All-CPK','Savings']]
	except:
		try:
			maildf=finaldf[['DATE2','ADHOC_WT','STD_WT','All_WT','ADHOC_COST''STD_COST','ManpowerCost','All_COST','ADHOC-CPK','STD-CPK','All-CPK','Savings']]
		except:
			try:
				maildf=finaldf[['DATE2','ADHOC_WT','FIXED_WT','All_WT','ADHOC_COST','FIXED_COST','ManpowerCost','All_COST','ADHOC-CPK','FIXED-CPK','All-CPK','Savings']]
			except:
				try:
					maildf=finaldf[['DATE2','STD_WT','All_WT','STD_COST','ManpowerCost','All_COST','STD-CPK','All-CPK','Savings']]
				except:
					try:
						maildf=finaldf[['DATE2','FIXED_WT','All_WT','FIXED_COST','ManpowerCost','All_COST','FIXED-CPK','All-CPK','Savings']]
					except:
						mailldf=finaldf[['DATE2','ADHOC_WT','All_WT','ADHOC_COST','ManpowerCost','All_COST','ADHOC-CPK','All-CPK','Savings']]# maildf=finaldf[['DATE2','ADHOC_WT','FIXED_WT','STD_WT','All_WT','ADHOC_COST','FIXED_COST','STD_COST','ManpowerCost','All_COST','ADHOC-CPK','FIXED-CPK','STD-CPK','All-CPK','Savings']]
df=maildf.to_html()
finaldf.to_csv(r'D:\Data\DirectDelivery-DPNQ\Savingscal_'+str(month)+str('_')+'.csv')

# In[116]:

# finaldf.to_excel('DD-BLR.xlsx')

filePath=r'D:\Data\DirectDelivery-DPNQ\Savingscal_'+str(month)+str('_')+'.csv'
# In[102]:

df=maildf.to_html()


# In[103]:

def sendEmail(TO = ["Ramniwas.Sharma@Spoton.Co.In","rajesh.debnath@spoton.co.in"],
            # TO = ["shashvat.suhane@spoton.co.in"],
            # TO = ["vishwas.j@spoton.co.in"],
            # CC = ["shashvat.suhane@spoton.co.in"],
            CC = ["Krishna.Chandrasekar@Spoton.Co.In","pawan.sharma@spoton.co.in","shashvat.suhane@spoton.co.in","abhik.mitra@spoton.co.in"],
            #BCC = ["vinayak.kumbhar@spoton.co.in","vinodkumar.mishra@spoton.co.in","nitin.tatyarao@spoton.co.in","kiran.pawar@spoton.co.in","jai.prakash@spoton.co.in","rajesh.mishra@spoton.co.in","ops.hub.idrh.1@spoton.co.in"] ,
            #BCC = ["vishwas.j@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["BCC"] = ",".join(BCC)
    msg["Subject"] = "DD-Cost-Comparison Report-DPNQ"
    body_text = df
    msgtext="""Dear All ,
    The Total savings for DPNQ in MTD is """+str(sav)+"""   """
    msg.attach( MIMEText(msgtext) )
    msg.attach( MIMEText(body_text,'html') )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()


# In[ ]:



