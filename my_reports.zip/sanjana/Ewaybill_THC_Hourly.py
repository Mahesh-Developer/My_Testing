
# coding: utf-8

# In[1]:


import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
import os
import Utilities

# In[2]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()


# In[3]:


ewbnpquery = ("""
        EXEC dbo.USP_EWAYBILL_MIS_THC_SQ 'NP'
        """)
ewbfull = pd.read_sql(ewbnpquery, Utilities.cnxn)


# In[17]:


ewb_na = ewbfull[(ewbfull['IS_EWAYBILL_REQUIRE']=='YES') & (ewbfull['IS_EWAYBILL_AVLB']=='NO')]


# In[18]:


ewb_na_sum = ewb_na.groupby(['CURR_BRANCHCODE']).agg({'DOCKNO':len}).reset_index().sort_values('DOCKNO',ascending=False)
ewb_notavailable = ewb_na_sum['DOCKNO'].sum()


# In[21]:


ewb_ntup = ewbfull[(ewbfull['IS_EWAYBILL_REQUIRE']=='YES') & (ewbfull['IS_EWAYBILL_AVLB']=='YES') & (ewbfull['IS_UPDATED']=='NO') ]


# In[22]:


ewb_ntup_sum = ewb_ntup.groupby(['CURR_BRANCHCODE']).agg({'DOCKNO':len}).reset_index().sort_values('DOCKNO',ascending=False)
ewb_pb_not_updated = ewb_ntup_sum['DOCKNO'].sum()

# In[14]:


ewb_npdatedquery = ("""
        EXEC dbo.USP_EWAYBILL_MIS_THC_SQ 'NU'
        """)
ewb_npdated = pd.read_sql(ewb_npdatedquery, Utilities.cnxn)


# In[ ]:

reportts = datetime.now()
opfilevar=reportts.date()
opfilevar1=reportts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=pd.np.round((float(currhrs)/60),0)




ewb_na.to_csv(r'D:\Data\Ewaybill\THC_Hourly\No_EWB\EWB_Not_available_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv')
ewb_npdated.to_csv(r'D:\Data\Ewaybill\THC_Hourly\Not_Updated\EWB_PartB_Not_updated_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv')

ewb_na.to_csv(r'D:\Data\Ewaybill\THC_Hourly\EWB_Not_available.csv')
ewb_npdated.to_csv(r'D:\Data\Ewaybill\THC_Hourly\EWB_PartB_Not_updated.csv')

oppath1 = r'D:\Data\Ewaybill\THC_Hourly\EWB_Not_available.csv'
oppath2 = r'D:\Data\Ewaybill\THC_Hourly\EWB_PartB_Not_updated.csv'


TO=["hubmgr_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in","cnm@spoton.co.in","sq_spot@spoton.co.in","aom_spot@spoton.co.in",'scincharge_spot@spoton.co.in','HUBEWBcontroller@spoton.co.in']
CC=['sqtf@spoton.co.in','rajesh.kapase@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in','shashvat.suhane@spoton.co.in']

# TO=['vishwas.j@spoton.co.in']
# CC=['vishwas.j@spoton.co.in']
# BCC=['vishwas.j@spoton.co.in']
FROM='mis.ho@spoton.co.in'

msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "Ewaybill Exception Report for Departed Cons -" + str(opfilevar)+"-"+str(opfilevar2)
html='''<html>
<h4>Dear All,</h4>
</html>'''
report=""
report+='Dear All,'

report+='<br>'
report+='Below is the location wise summary for the cons for which has been departed from Current location'
report+='<br>'
report+='<br>'
report+= 'Cons for which there is no Ewaybill = '+str(ewb_notavailable)
report+='<br>'
report+= 'Cons for which Ewaybill is available but Part B is not updated = '+str(ewb_pb_not_updated)
report+='<br>'
report+='<br>'
report+='Location wise summary for the cons for which there is no Ewaybill'
report+='<br>'
report+=''
report+='<br>'+ewb_na_sum.to_html()+'<br>'
report+='Below is the summary of the cons for which Part B of Ewaybill is not updated'
report+='<br>'
report+='<br>'+ewb_ntup_sum.to_html()+'<br>'
abc=MIMEText(report,'html')
msg.attach(abc)

part = MIMEBase('application', "octet-stream")
part.set_payload( open(oppath1,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
msg.attach(part)

part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(oppath2,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath2))
msg.attach(part1)


server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()