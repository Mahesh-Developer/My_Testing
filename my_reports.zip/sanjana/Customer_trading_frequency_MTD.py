
# coding: utf-8

# In[1]:

import pandas as pd
import numpy as np
import datetime
from datetime import timedelta, date
import glob
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import os
import ftplib
import traceback

path =r'D:\Data\Customer_trading_frequency_trigger\Trigger_basefiles' # use your path
allFiles = glob.glob(path + "/*.csv")
frame = pd.DataFrame()
list_ = []
for file_ in allFiles:
    df = pd.read_csv(file_,index_col=None, header=0)
    list_.append(df)
frame = pd.concat(list_)
frame.to_csv(r'D:\Data\Trigger_glob.csv')

# In[2]:

pickupbase  = pd.read_csv(r'D:\Data\Pickups_CTP.csv')


# In[3]:

trigger  = pd.read_csv(r'D:\Data\Trigger_glob.csv')


# In[4]:

pickupbase.columns.tolist()
trigger.columns.tolist()


# In[5]:

trigger_req_cols = pd.DataFrame(trigger,columns=['CUSTOMERCODE','AccountType','CustSignBranchCode','CustSignBranchName','SaleArea','SaleDepot','SaleRegion','TerritoryManagerName'])
trigger_req_cols = trigger_req_cols.drop_duplicates(subset = 'CUSTOMERCODE')


# In[6]:

pd.unique(pickupbase['Pickup_date'].values)

pd.unique(pickupbase.head(-5000)['Pickup_date'])


# In[7]:

k = pickupbase['Pickup_date'].values[0]
print k
try:
    y = datetime.datetime.strptime(k,'%Y-%m-%d %H:%M:%S')
except:
    y = datetime.datetime.strptime(k,'%d/%m/%Y %H:%M:%S')
y.date()


# In[8]:


#def finddate(x):
#    try:
#        y = datetime.datetime.strptime(x,'%Y-%m-%d %H:%M:%S')  
#    except:
#        y = datetime.datetime.strptime(x,'%d/%m/%Y %H:%M:%S')
#    return y.date()
                              
## TO handle different datetime format, modified the above function again   

def finddate(x):
    try:
        y = datetime.datetime.strptime(x,'%Y-%m-%d %H:%M:%S')  
    except:
        try:
            y = datetime.datetime.strptime(x,'%d/%m/%Y %H:%M:%S')
        except:
            y = datetime.datetime.strptime(x,'%d-%m-%Y %H:%M')
    return y.date()
# In[9]:

pickupbase['PickupDate_Only'] = pickupbase.apply(lambda x: finddate(x['Pickup_date']), axis=1)


# In[12]:

todaydate = datetime.date.today()
todayday = todaydate.strftime("%a")
print todaydate, type(todaydate), todayday
yesterdate = todaydate-timedelta(days = 1)
start_date = datetime.date(todaydate.year, todaydate.month, 1)
totaldays = (todaydate-start_date).days   ### Condered Today though TOTAL Days is the difference between start date and yesterday ~ to (a-b)+1  
print totaldays,start_date,todaydate

sundays = np.busday_count(start_date,todaydate, weekmask='Sun')
workingdays = totaldays-sundays
workingdays

# In[14]:

pickup = pickupbase[pickupbase['PickupDate_Only']>=start_date] ## > or >= To be finalized
len(pickup)
#pickup.to_csv('pickup.csv')


# In[15]:

def daysoftrade(x):
    dys = len(list(set(x)))
    return dys


# In[16]:

def roundoff(kgslost):
    kgslostroundoff = pd.np.round(kgslost,0)
    return kgslostroundoff


# In[17]:

def dateonly(timestamp):
    try:
        y = datetime.datetime.strptime(timestamp,'%Y-%m-%d') 
    except:
        y = datetime.datetime.strptime(timestamp,'%d-%m-%Y') 
    return y.date()


# In[18]:

trigger['Date'] = trigger.apply(lambda x:dateonly(x['Timestamp']),axis=1)


# In[19]:

trigger = trigger[trigger['Date']>=start_date]
len(trigger)


# In[20]:

pickupgroupby = pickup.groupby(['CUSTOMERCODE']).agg({'PickupDate_Only': lambda x: daysoftrade(x)}).reset_index()
trigger = trigger.rename(columns={'Kgs_Lost':'Kgs_Lost1'})
triggergroupby = trigger.groupby(['CUSTOMERCODE','CUSTOMERNAME','Avg_Diff']).agg({'Kgs_Lost1': pd.np.mean}).reset_index()
triggergroupby['Avg_Kgs'] = triggergroupby.apply(lambda x:roundoff(x['Kgs_Lost1']),axis=1)
triggergroupby = triggergroupby.drop('Kgs_Lost1',axis=1)
#analysisdfgrpby = analysisdf.groupby(['CUSTOMERCODE', 'Qtr_Weekno']).agg({'Actual Weight_y': lambda x: percentilecalc(x), 'Con Number_y': lambda x: percentilecalc(x)}).reset_index()


# In[21]:

#pickupgroupby.to_csv('C:\Data\Customer_trading_pattern_pickup_yesterday\picupgroupby.csv')
mergefile = pd.merge(triggergroupby, pickupgroupby, on=['CUSTOMERCODE'], how='left')
mergefile.PickupDate_Only.fillna(0,inplace=True)
#mergefile.to_csv('C:\Data\Customer_trading_pattern_pickup_yesterday\mergefile_2305.csv')


# In[22]:

def expectedtradingdayscalc(totaldays,avgdiff):
    try:
        expectedtrad_days = pd.np.ceil(totaldays/(avgdiff+1))
    except:
        expectedtrad_days = 'Check'
    return expectedtrad_days


# In[23]:

mergefile.loc[mergefile.index,'Total days'] = workingdays
mergefile['Expected_trading_days'] = mergefile.apply(lambda x:expectedtradingdayscalc(x['Total days'],x['Avg_Diff']),axis=1)
mergefile['Days Missed Trading'] = mergefile.apply(lambda x:(x['Expected_trading_days']-x['PickupDate_Only']),axis=1)
mergefile['Kgs_lost'] = mergefile.apply(lambda x:(x['Days Missed Trading']*x['Avg_Kgs']),axis=1)
mergefile = mergefile[mergefile['Kgs_lost']>0]    ## For removing customers who have traded more frequently than their average differene days


# In[24]:

triggermtd = pd.merge(mergefile,trigger_req_cols,on='CUSTOMERCODE',how='left')

# Rename at the end and not here
#triggermtd = triggermtd.rename(columns={'Total days':'Working_days','Avg_Diff':'Trading_frequency','Expected_trading_days':'Expected_trading_cycles','Kgs_lost':'Total_Kgs_lost','PickupDate_Only':'Days_Actually_Traded'})
# Rename at the end and not here

triggermtd = triggermtd.drop('Avg_Kgs',axis=1)
mtd_cust_list = triggermtd['CUSTOMERCODE'].tolist()


# In[25]:

triggermtd.to_csv(r'D:\Data\Customer_trading_frequency_trigger\MTD_Yesterday_OP\Sales_trigger_MTD.csv')
triggermtd.to_csv(r'D:\Data\Customer_trading_frequency_trigger\MTD_Yesterday_OP\MTD\Sales_trigger_MTD'+str(yesterdate)+'.csv')

print triggermtd.columns.tolist()
# In[26]:

triggeryest = trigger[(trigger['Date']==yesterdate) & (trigger['CUSTOMERCODE'].isin(mtd_cust_list))]
triggeryest = triggeryest.drop(['Unnamed: 0','Unnamed: 0.1','Timestamp'],axis=1)
print triggeryest.columns.tolist()
triggeryest = triggeryest.rename(columns={'Kgs_Lost1':'Kgs_lost'}) ## Renaming again back due to renaming column just before triggergroupby inorder to round off the average kgs

# In[27]:

triggeryest.to_csv(r'D:\Data\Customer_trading_frequency_trigger\MTD_Yesterday_OP\Sales_trigger_yesterday.csv')
triggeryest.to_csv(r'D:\Data\Customer_trading_frequency_trigger\MTD_Yesterday_OP\Yesterday\Sales_trigger_yesterday'+str(yesterdate)+'.csv')


#### Groupbys for MTD and Yesterday
finalgrp_region_yest = triggeryest.groupby(['SaleRegion']).agg({'CUSTOMERCODE': len, 'Kgs_lost': sum}).reset_index()
finalgrp_depot_yest = triggeryest.groupby(['SaleDepot']).agg({'CUSTOMERCODE': len, 'Kgs_lost': sum}).reset_index()
finalgrp_branch_yest = triggeryest.groupby(['SaleDepot','CustSignBranchName']).agg({'CUSTOMERCODE': len, 'Kgs_lost': sum}).reset_index()
finalgrp_tsm_yest = triggeryest.groupby(['SaleDepot','TerritoryManagerName']).agg({'CUSTOMERCODE': len, 'Kgs_lost': sum}).reset_index()
finalgrp_acctype_yest = triggeryest.groupby(['AccountType', 'SaleDepot']).agg({'CUSTOMERCODE': len, 'Kgs_lost': sum}).reset_index()
print finalgrp_region_yest.columns.tolist()

finalgrp_region_mtd = triggermtd.groupby(['SaleRegion']).agg({'CUSTOMERCODE': len, 'Kgs_lost': sum}).reset_index()
finalgrp_depot_mtd = triggermtd.groupby(['SaleDepot']).agg({'CUSTOMERCODE': len, 'Kgs_lost': sum}).reset_index()
finalgrp_branch_mtd = triggermtd.groupby(['SaleDepot','CustSignBranchName']).agg({'CUSTOMERCODE': len, 'Kgs_lost': sum}).reset_index()
finalgrp_tsm_mtd = triggermtd.groupby(['SaleDepot','TerritoryManagerName']).agg({'CUSTOMERCODE': len, 'Kgs_lost': sum}).reset_index()
finalgrp_acctype_mtd = triggermtd.groupby(['AccountType', 'SaleDepot']).agg({'CUSTOMERCODE': len, 'Kgs_lost': sum}).reset_index()
print finalgrp_region_mtd.columns.tolist()
###finalgrp_region_mtd = finalgrp_region_mtd.rename(columns={'index':'SaleRegion'}) ## SaleRegion Column name automatically getting renamed to index. Hence renaming again

finalgrp_region = pd.merge(finalgrp_region_yest,finalgrp_region_mtd,on=['SaleRegion'],suffixes=['_Yest','_MTD'],how='outer')
finalgrp_depot = pd.merge(finalgrp_depot_yest,finalgrp_depot_mtd,on=['SaleDepot'],suffixes=['_Yest','_MTD'],how='outer')
finalgrp_branch = pd.merge(finalgrp_branch_yest,finalgrp_branch_mtd,on=['SaleDepot','CustSignBranchName'],suffixes=['_Yest','_MTD'],how='outer')
finalgrp_tsm = pd.merge(finalgrp_tsm_yest,finalgrp_tsm_mtd,on=['SaleDepot','TerritoryManagerName'],suffixes=['_Yest','_MTD'],how='outer')
finalgrp_acctype = pd.merge(finalgrp_acctype_yest,finalgrp_acctype_mtd,on=['AccountType', 'SaleDepot'],suffixes=['_Yest','_MTD'],how='outer')


#renaming this particular column for having a neat name in basedata file and presentation also
finalgrp_region = finalgrp_region.rename(columns={'CUSTOMERCODE_Yest':'Low_Trading_Cust_Yest','CUSTOMERCODE_MTD':'Low_Trading_Cust_MTD'})
finalgrp_depot = finalgrp_depot.rename(columns={'CUSTOMERCODE_Yest':'Low_Trading_Cust_Yest','CUSTOMERCODE_MTD':'Low_Trading_Cust_MTD'})
finalgrp_branch = finalgrp_branch.rename(columns={'CUSTOMERCODE_Yest':'Low_Trading_Cust_Yest','CUSTOMERCODE_MTD':'Low_Trading_Cust_MTD'})
finalgrp_tsm = finalgrp_tsm.rename(columns={'CUSTOMERCODE_Yest':'Low_Trading_Cust_Yest','CUSTOMERCODE_MTD':'Low_Trading_Cust_MTD'})
finalgrp_acctype = finalgrp_acctype.rename(columns={'CUSTOMERCODE_Yest':'Low_Trading_Cust_Yest','CUSTOMERCODE_MTD':'Low_Trading_Cust_MTD'})


#for giving 'total' variables in mail body
kgslost_yest = triggeryest['Kgs_lost'].sum()
lowtradingcust_yest = len(triggeryest['CUSTOMERCODE'])

kgslost_mtd = triggermtd['Kgs_lost'].sum()
lowtradingcust_mtd = len(triggermtd['CUSTOMERCODE'])

# For Addidng totals in each dataframe
sumlistregion = ['TOTAL',kgslost_yest,lowtradingcust_yest,kgslost_mtd,lowtradingcust_mtd]
col_listregion = ['SaleRegion','Kgs_lost_Yest','Low_Trading_Cust_Yest','Kgs_lost_MTD','Low_Trading_Cust_MTD']
regiontotal = pd.DataFrame(data=[sumlistregion], columns = col_listregion)
finalgrp_region = finalgrp_region.append(regiontotal,ignore_index=True)

sumlistdepot= ['TOTAL',kgslost_yest,lowtradingcust_yest,kgslost_mtd,lowtradingcust_mtd]
col_listdepot= ['SaleDepot','Kgs_lost_Yest','Low_Trading_Cust_Yest','Kgs_lost_MTD','Low_Trading_Cust_MTD']
depottotal = pd.DataFrame(data=[sumlistdepot], columns = col_listdepot)
finalgrp_depot = finalgrp_depot.append(depottotal,ignore_index=True)

sumlistbrcd= ['TOTAL','-',kgslost_yest,lowtradingcust_yest,kgslost_mtd,lowtradingcust_mtd]
col_listbrcd= ['SaleDepot','CustSignBranchName','Kgs_lost_Yest','Low_Trading_Cust_Yest','Kgs_lost_MTD','Low_Trading_Cust_MTD']
brcdtotal = pd.DataFrame(data=[sumlistbrcd], columns = col_listbrcd)
finalgrp_branch = finalgrp_branch.append(brcdtotal,ignore_index=True)

sumlisttsm= ['TOTAL','-',kgslost_yest,lowtradingcust_yest,kgslost_mtd,lowtradingcust_mtd]
col_listtsm= ['SaleDepot','TerritoryManagerName','Kgs_lost_Yest','Low_Trading_Cust_Yest','Kgs_lost_MTD','Low_Trading_Cust_MTD']
tsmtotal = pd.DataFrame(data=[sumlisttsm], columns = col_listtsm)
finalgrp_tsm= finalgrp_tsm.append(tsmtotal,ignore_index=True)

sumlistchannel= ['TOTAL','-',kgslost_yest,lowtradingcust_yest,kgslost_mtd,lowtradingcust_mtd]
col_listchannel= ['SaleDepot','AccountType','Kgs_lost_Yest','Low_Trading_Cust_Yest','Kgs_lost_MTD','Low_Trading_Cust_MTD']
channeltotal = pd.DataFrame(data=[sumlistchannel], columns = col_listchannel)
finalgrp_acctype= finalgrp_acctype.append(channeltotal,ignore_index=True)

#To get columns in order
columnsopregion = ['SaleRegion','Kgs_lost_Yest','Low_Trading_Cust_Yest','Kgs_lost_MTD','Low_Trading_Cust_MTD']
finalgrp_region = pd.DataFrame(finalgrp_region,columns=columnsopregion)

columnsopdepot= ['SaleDepot','Kgs_lost_Yest','Low_Trading_Cust_Yest','Kgs_lost_MTD','Low_Trading_Cust_MTD']
finalgrp_depot = pd.DataFrame(finalgrp_depot,columns=columnsopdepot)

columnsopbrcd= ['SaleDepot','CustSignBranchName','Kgs_lost_Yest','Low_Trading_Cust_Yest','Kgs_lost_MTD','Low_Trading_Cust_MTD']
finalgrp_branch = pd.DataFrame(finalgrp_branch,columns=columnsopbrcd)

columnsoptsm= ['SaleDepot','TerritoryManagerName','Kgs_lost_Yest','Low_Trading_Cust_Yest','Kgs_lost_MTD','Low_Trading_Cust_MTD']
finalgrp_tsm = pd.DataFrame(finalgrp_tsm,columns=columnsoptsm)

columnsopacttype= ['SaleDepot','AccountType','Kgs_lost_Yest','Low_Trading_Cust_Yest','Kgs_lost_MTD','Low_Trading_Cust_MTD']
finalgrp_acctype = pd.DataFrame(finalgrp_acctype,columns=columnsopacttype)
# For Addidng totals in each dataframe


#### Groupbys for MTD and Yesterday

triggermtd = triggermtd.rename(columns={'Avg_Diff':'Trading_Frequency','Total days':'Working_days','PickupDate_Only':'Days_Actually_Traded','Expected_trading_days':'Expected_trading_cycles','Kgs_lost':'Total_Kgs_lost','Days Missed Trading':'Days_Missed_Trading'})
triggermtd = pd.DataFrame(triggermtd,columns=['CUSTOMERCODE','CUSTOMERNAME','Trading_Frequency','Working_days','Expected_trading_cycles','Days_Actually_Traded','Days_Missed_Trading','Total_Kgs_lost','AccountType','CustSignBranchCode','CustSignBranchName','SaleArea','SaleDepot','SaleRegion','TerritoryManagerName'])
triggermtd.to_csv(r'D:\Data\Customer_trading_frequency_trigger\MTD_Yesterday_OP\Sales_trigger_MTD.csv')
triggermtd.to_csv(r'D:\Data\Customer_trading_frequency_trigger\MTD_Yesterday_OP\MTD\Sales_trigger_MTD'+str(yesterdate)+'.csv')

# In[27]:
triggeryest = triggeryest.rename(columns={'Avg_Diff':'Trading_Frequency'})
triggeryest.to_csv(r'D:\Data\Customer_trading_frequency_trigger\MTD_Yesterday_OP\Sales_trigger_yesterday.csv')
triggeryest.to_csv(r'D:\Data\Customer_trading_frequency_trigger\MTD_Yesterday_OP\Yesterday\Sales_trigger_yesterday'+str(yesterdate)+'.csv')


## Fro FTP-ing MTD basedata
oppath2 = r'D:\Data\Customer_trading_frequency_trigger\MTD_Yesterday_OP\Sales_trigger_MTD.csv'
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
#print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        #print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppath2
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        #print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()
    
## Fro FTP-ing MTD basedata    

## Fro FTP-ing yesterday basedata
oppath3 = r'D:\Data\Customer_trading_frequency_trigger\MTD_Yesterday_OP\Sales_trigger_yesterday.csv'
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
#print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        #print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppath3
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        #print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()
## Fro FTP-ing yesterday basedata

with ExcelWriter(r'D:\Data\Customer_trading_frequency_trigger\MTD_Yesterday_OP\Summary_files\Trading_pattern_trigger_'+str(yesterdate)+'.xlsx') as writer:
    ##$$finaldf.to_excel(writer, sheet_name='FINAL',engine='xlsxwriter')
    finalgrp_region.to_excel(writer, sheet_name='REGION_WISE',engine='xlsxwriter')
    finalgrp_depot.to_excel(writer, sheet_name='DEPOT_WISE',engine='xlsxwriter')
    finalgrp_branch.to_excel(writer, sheet_name='BRANCH_WISE',engine='xlsxwriter')
    finalgrp_tsm.to_excel(writer, sheet_name='TSM_WISE',engine='xlsxwriter')
    finalgrp_acctype.to_excel(writer, sheet_name='CHANNEL_WISE',engine='xlsxwriter')

oppath1 =  r'D:\Data\Customer_trading_frequency_trigger\MTD_Yesterday_OP\Summary_files\Trading_pattern_trigger_'+str(yesterdate)+'.xlsx'
filePath = oppath1

if todayday == 'Sun':
    def sendEmail(TO = ["Reena.Singhania@Spoton.Co.In"],
                  #TO = ["vishwas.j@spoton.co.in"], 
                  CC = ["mahesh.reddy@spoton.co.in"],
                FROM="mahesh.reddy@spoton.co.in"):
        HOST = "smtp.spoton.co.in"
    #smtplib.SMTP('smtp.spoton.co.in', 25)
    
        msg = MIMEMultipart()
        msg["From"] = FROM
        msg["To"] = ",".join(TO)
        msg["CC"] = ",".join(CC)
        #msg["Subject"] = "Sales Trigger Report MTD" + '_' + str(yesterdate)
        msg["Subject"] = "Sales Trigger Report MTD" + '_' + str(yesterdate)
        body_text = """
        Dear All,
        
        PFA the Sales Trigger Report summary as of """+str(yesterdate)+""" 
    
        No of customers trading below their respective level of trade frequency for yesterday = """+str(lowtradingcust_yest)+"""
        Lost opportunity estimated in kgs yesterday  = """+str(kgslost_yest)+"""    
        
        No of customers trading below their respective level of trade frequency MTD = """+str(lowtradingcust_mtd)+"""
        Lost opportunity estimated in kgs MTD  = """+str(kgslost_mtd)+"""    
        
        
        Please copy paste the below link to your browser for downloading the base files.
        
        For MTD basefile : http://10.109.230.50/downloads/IEProjects/ETA/Sales_trigger_MTD.csv
        For Yesterday basefile : http://10.109.230.50/downloads/IEProjects/ETA/Sales_trigger_yesterday.csv
        
        
        """
        
    
        if body_text:
            msg.attach( MIMEText(body_text) )
        part = MIMEBase('application', "octet-stream")
        part.set_payload( open(filePath,"rb").read() )
        Encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
        msg.attach(part)
        server=smtplib.SMTP('smtp.sendgrid.net', 587)
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login("spoton.net.in", "Star@123#")
    
        try:
            failed = server.sendmail(FROM, TO+CC, msg.as_string())
            server.close()
        except Exception, e:
            errorMsg = "Unable to send email. Error: %s" % str(e)
    
    if __name__ == "__main__":
        sendEmail()
    print('Email sent')

else:
    def sendEmail(TO = ["vishwas.j@spoton.co.in"],
                  #TO = ["vishwas.j@spoton.co.in"], 
                  CC = ["vishwas.j@spoton.co.in"],
                FROM="mahesh.reddy@spoton.co.in"):
        HOST = "smtp.spoton.co.in"
    #smtplib.SMTP('smtp.spoton.co.in', 25)
    
        msg = MIMEMultipart()
        msg["From"] = FROM
        msg["To"] = ",".join(TO)
        msg["CC"] = ",".join(CC)
        #msg["Subject"] = "Sales Trigger Report MTD" + '_' + str(yesterdate)
        msg["Subject"] = "Sales Trigger Report MTD" + '_' + str(yesterdate)
        body_text = """
        Dear All,
        
        PFA the Sales Trigger Report summary as of """+str(yesterdate)+""" 
    
        No of customers trading below their respective level of trade frequency for yesterday = """+str(lowtradingcust_yest)+"""
        Lost opportunity estimated in kgs yesterday  = """+str(kgslost_yest)+"""    
        
        No of customers trading below their respective level of trade frequency MTD = """+str(lowtradingcust_mtd)+"""
        Lost opportunity estimated in kgs MTD  = """+str(kgslost_mtd)+"""    
        
        
        Please copy paste the below link to your browser for downloading the base files.
        
        For MTD basefile : http://10.109.230.50/downloads/IEProjects/ETA/Sales_trigger_MTD.csv
        For Yesterday basefile : http://10.109.230.50/downloads/IEProjects/ETA/Sales_trigger_yesterday.csv
        
        
        """
        
    
        if body_text:
            msg.attach( MIMEText(body_text) )
        part = MIMEBase('application', "octet-stream")
        part.set_payload( open(filePath,"rb").read() )
        Encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
        msg.attach(part)
        server=smtplib.SMTP('smtp.sendgrid.net', 587)
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login("spoton.net.in", "Star@123#")
    
        try:
            failed = server.sendmail(FROM, TO+CC, msg.as_string())
            server.close()
        except Exception, e:
            errorMsg = "Unable to send email. Error: %s" % str(e)
    
    if __name__ == "__main__":
        sendEmail()
    print('Email sent') 