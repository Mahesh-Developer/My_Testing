
# coding: utf-8

# In[ ]:


import pandas as pd
import pyodbc
from datetime import datetime,timedelta
import os


# In[ ]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()


# In[ ]:


startdate=datetime.strftime((datetime.now()-timedelta(days=1)).replace(day=1),"%Y-%m-%d")
startdate


# In[ ]:


enddate=datetime.strftime(datetime.now()-timedelta(days=2),'%Y-%m-%d')
enddate


# In[ ]:


query=("EXEC USP_Servicelevel_Retail_SQ '{0}', '{1}'").format(startdate,enddate)
query


# In[ ]:


df=pd.read_sql(query,cnxn)


# In[ ]:


len(df)


# In[ ]:


df['% Reach']=pd.np.round(df['Reach']*100.0/df['TOTAL CONS'],1)
df['% OPP_Cons']=pd.np.round(df['OPP_Cons']*100.0/df['TOTAL CONS'],1)
df['% CEM_Cons']=pd.np.round(df['CEM_Cons']*100.0/df['TOTAL CONS'],1)
df['% DAMAGE']=pd.np.round(df['DAMAGE']*100.0/df['TOTAL CONS'],1)
df['% THEFT']=pd.np.round(df['THEFT']*100.0/df['TOTAL CONS'],1)


# In[ ]:


df['Due_dt']=pd.to_datetime(df['Due_dt'])


# In[ ]:


df['week']=df['Due_dt'].dt.strftime("%U")


# In[ ]:


summary=df.pivot_table(index=['week'],
               values=['TOTAL CONS','Reach','OPP_Cons','CEM_Cons','DAMAGE','THEFT'],
               aggfunc={'TOTAL CONS':sum,'Reach':sum,'OPP_Cons':sum,'CEM_Cons':sum,'DAMAGE':sum,'THEFT':sum})


# In[ ]:


summary=summary.reset_index()


# In[ ]:





# In[ ]:


summary['% Reach']=pd.np.round(summary['Reach']*100.0/summary['TOTAL CONS'],1)
summary['% OPP_Cons']=pd.np.round(summary['OPP_Cons']*100.0/summary['TOTAL CONS'],1)
summary['% CEM_Cons']=pd.np.round(summary['CEM_Cons']*100.0/summary['TOTAL CONS'],1)
summary['% DAMAGE']=pd.np.round(summary['DAMAGE']*100.0/summary['TOTAL CONS'],1)
summary['% THEFT']=pd.np.round(summary['THEFT']*100.0/summary['TOTAL CONS'],1)


# In[ ]:


df.to_csv(r'D:\Data\Retail_Consiments\weekly\D:\Data\Retail_Consiments\weekly\Data.csv')


# In[ ]:


summary=summary[['week','% Reach','% OPP_Cons','% CEM_Cons','% DAMAGE','% THEFT']]


# In[ ]:


summary


# In[ ]:


filepath=r'D:\Data\Retail_Consiments\weekly\Data.csv'


# In[ ]:


todate=datetime.strftime(datetime.now(),format='%Y-%m-%d')
todate


# In[ ]:


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

TO=['aom_spot@spoton.co.in','rom_spot@spoton.co.in','dom_spot@spoton.co.in','rsm_spot@spoton.co.in','dsm_spot@spoton.co.in','asm_spot@spoton.co.in','sqtf@spoton.co.in','arokia.doss@spoton.co.in','narasimha.murthy@spoton.co.in','sanjay.johri@spoton.co.in','vishal.gp@spoton.co.in']

#TO=['sq_spot@spoton.co.in','sqtf@spoton.co.in','spot_security@spoton.co.in','spot_cstl@spoton.co.in','omwati.rajput@spoton.co.in']
FROM="mis.ho@spoton.co.in"
CC=['mahesh.reddy@spoton.co.in','anitha.thyagarajan@spoton.co.in','shivananda.p@spoton.co.in']
# CC=['mahesh.reddy@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
msg["Subject"] = "Weekly Service level report for Retail consignments " + " : " + todate
html='''<html>
<style>
p
{
  margin:0;
  margin-top: 5px;
  padding:0;
  font-size:17px;
    line-height:20px;
}
</style>
<h3>Dear All,</h3>
<p>Please Find POD's Summary.</p>
</html>'''


s = Template(html).safe_substitute()
report=""
#report+=s
#report+='<br>'+final_dff5.to_html()+'<br>'
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='Please Find attached Weekly Service level report for Retail consignments :'
report+='<br>'
#report+='NOTE : The below data is excluding Appointment Cons'
report+='Summary : '
report+='<br>'
report+='<br>'+summary.to_html()+'<br>'
report+='<br>'

html5='''
<h5> To download the data , Please click the link below </h5>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Undel_Management.xlsx"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Undel_Management.xlsx</p></b>
    '''
#report+=html5
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()


