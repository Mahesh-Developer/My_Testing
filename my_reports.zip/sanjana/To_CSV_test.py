# -*- coding: utf-8 -*-
"""
Created on Tue Sep 29 15:58:57 2015

@author: rajeeshv
"""

import pandas as pd
import numpy as np

htr = pd.io.excel.read_excel('http://spoton.co.in/downloads/HTR_1HR/HTR_1HR.xls','HUB_THROUGHPUT_ONEHOUR')

ts = htr.iloc[0]['TIMESTAMP'].to_pydatetime()
opfilevar=ts.date()
opfilevar1=ts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=np.ceil(float(currhrs)/60)


newhtr = pd.read_csv('D:\Data\eta_rank\DA2.csv')
newhtr.to_csv("D:\Data\eta_rank\DA2OP"+"-"+str(opfilevar)+"-"+str(opfilevar2)+".csv")