# In[181]:

import pandas as pd
import networkx as nx
import numpy as np
from pandas import ExcelWriter
from datetime import datetime, timedelta, time
from py2neo import Graph
import datetime

from pandas import pivot_table
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import os
import traceback
import ftplib

#import socket
#socket.getaddrinfo('localhost', 8080)


# In[2]:

def save_xls(list_dfs, name_dfs, xls_path):
   i = 0
   writer = ExcelWriter(xls_path)
   for dataframe in list_dfs:
       sheetname = name_dfs[i]
       dataframe.to_excel(writer, sheetname, merge_cells = True)
       i = i+1
   writer.save()


# In[3]:

ippath1 = r'D:/Python/Scripts and Files/Path and Graph Files/Path_Final_July15.xlsx'


oppath2 = r'D:/Python/Scripts and Files/Path and Graph Files/Load_available_report.xlsx'

# In[184]:

hubprocessingtime = 3
scprocessingtime = 2


# In[185]:

x1 = pd.ExcelFile(ippath1)
paths = x1.parse("Sheet1")

#ippath2 = r'C:\Data\ETA\10032016_ETA_modification\HTR_1HR.xls'
#xl2 = pd.ExcelFile(ippath2)
#tcrdata = xl2.parse('HUB_THROUGHPUT_ONEHOUR')

sccategoryfile = pd.read_csv(r'D:/Python/Scripts and Files/Path and Graph Files/SC_category.csv')
sccategoryfile = sccategoryfile.drop(['Name','Cat','Area'],axis=1)

tcrdata = pd.io.excel.read_excel('http://10.109.230.50/downloads/HTR_1HR/HTR_1HR.xls','HUB_THROUGHPUT_ONEHOUR')

# Merge for SC Category in HTR file
tcrdatasccat = pd.merge(tcrdata,sccategoryfile,left_on=['Destn Branch'],right_on=['SC'],how='left')
tcrdata = tcrdatasccat
# Merge for SC Category in HTR file

criticallanes = pd.read_csv(r'D:/Python/Scripts and Files/Path and Graph Files/Critical_lanes_loadavaliable.csv')


# In[4]:

criticallaneslist = criticallanes['Lanes'].tolist()


# In[5]:

def findeta (connumber, origintcr, destinationtcr, currloc, arrivaltimetcr, timestamp):
    #duedate1=duedate.to_pydatetime()
    df3= paths[(paths['Destination']== destinationtcr) & (paths['Path1'].str.contains(currloc))]
    if df3.empty:
        nextloc = 'NA'
        #print eta
        return nextloc

    else:
        pathlist1 = df3['Path1'].tolist()
    path_in= pathlist1[0]
    #print ('path_in1 is a',path_in)
    path_in= str(path_in)
    path_in_list= path_in.split('-')
    #print ('path_in_list is',path_in_list)

    if currloc in path_in_list:
        match_loc = [j for j, x in enumerate(path_in_list) if x == currloc]
        #print ('matching', match_loc)
        position= match_loc[0]
        #print ('post is', position)
        nextloc = path_in_list[position+1]
    else:
        nextloc = 'NA'
        return nextloc

    path_in1=path_in_list[(position):]
    #print ('path_in1 is',path_in1)

    return nextloc


# In[6]:

# <b> Main ETA Finding </b>

# In[ ]:

#depspaperworkcodelist = ['SRE','SRD','SRS','SRP','DLP','SWP','PWS','HCM','HPM','MOP','SRH','HOC','ONR','SPH','SPO','DBO','DIP','SHS','SSC','HIP']
depspaperworkcodelist = ['SRE','SRD','SRS','SRP','DLP','SWP','PWS','HCM','HPM','MOP','SRH','HOC','ONR','SPH','SPO','DBO','DIP','SHS','SSC','HIP','RNX','APT','APN','SHD','SMT','SPL','MSH','UCG','RRA','HPE','WIA','UG1','UG2','UG3','HMP','HWC','NPE','HIM']
#corehublist = ['AMCH','AMDH','BLRH','BOMH','BRGH','CCUH','DELH','HYDH','MAAH','NAGH','PNQH','VPIH','VZAH','SXVF']
corehublist = ['AMDH','BLRH','BOMH','DELH','HYDH','MAAH','NAGH','PNQH','CCUH','BRGH']
#corehublist = ['BOMH','DELH','MAAH','NAGH','BRGH','CCUH','AMCH']
tcrconlist_inv= tcrdata['Con Number'].tolist()
print 'the inventory list has', len(tcrconlist_inv)

for m in range (0, len(tcrconlist_inv)):
    connumber = tcrdata.iloc[m]['Con Number']
    origintcr = tcrdata.iloc[m]['Origin Branch']
    destinationtcr = tcrdata.iloc[m]['Destn Branch']
    currloc = tcrdata.iloc[m]['Hub SC Location']
    arrivaltimetcr = tcrdata.iloc[m]['Arrival Date Hub']
    #weights = tcrdata.iloc[m]['Act Wt In Tonnes']
    statuscodes = tcrdata.iloc[m]['Latest Status Code']
    reportts = tcrdata.iloc[m]['TIMESTAMP']
    timestamp= reportts.to_pydatetime()
    duedate = tcrdata.iloc[m]['Due Date']
    duedate1 = duedate.to_pydatetime()
    duedate2=duedate1.date()

    #print connumber
    if arrivaltimetcr.to_pydatetime() < (timestamp - timedelta(days=30)):
        #print connumber, 'Old Con'
        tcrdata.loc[m,'Observation'] = 'Old Con'
    elif statuscodes in depspaperworkcodelist:
        tcrdata.loc[m,'Observation'] = 'DEPS/Paperworks'
        #print connumber, 'DEPS/Paperworks'
    else:
        tcrdata.loc[m,'Observation'] = 'Correct'
        #print connumber, 'Correct'

    if currloc in corehublist:
        tcrdata.loc[m,'Hub'] = 'Main Hub'
    else:
        tcrdata.loc[m,'Hub'] = 'Sec Hub'

    nextloc = findeta (connumber, origintcr, destinationtcr, currloc, arrivaltimetcr, timestamp)
    tcrdata.loc[m,'Next Loc'] = nextloc
    #print type(eta), eta
    tcrdata.loc[m,'CurrLoc - Next Loc'] = "-".join((currloc, nextloc))


# In[7]:

tcrdataclean = tcrdata[tcrdata['Observation']=='Correct']

tcrdataclean = tcrdataclean[tcrdataclean['Next Loc']!='NA']       #For Excluding cons with no paths


# In[8]:

tcrdatacleangrp = tcrdataclean.groupby(['CurrLoc - Next Loc']).agg({'Con Number':len,'Act Wt In Tonnes':sum}).reset_index()
tcrdatacleangrp = tcrdatacleangrp.sort_values('Act Wt In Tonnes',ascending=False)

##$$tcrdatacleangrp = tcrdatacleangrp[tcrdatacleangrp['CurrLoc - Next Loc'].isin(criticallaneslist)]
tcrdatacleangrpmerge = pd.merge(tcrdatacleangrp,criticallanes,left_on=['CurrLoc - Next Loc'],right_on=['Lanes'],how='inner')
tcrdatacleangrpmerge = tcrdatacleangrpmerge.drop(['Lanes'], axis=1)


tcrdatacleangrpmainloc = tcrdataclean[tcrdataclean['Category']=='A']
#to fix overlap of main loc of AMCH over DELH main loc 27-June-2016
tcr_AMCH1 = tcrdataclean[tcrdataclean['Next Loc']=='AMCH']
tcr_AMCH = tcr_AMCH1[tcr_AMCH1['AMCH Category']=='A']
tcrdatacleangrpmainloc = tcrdatacleangrpmainloc.append(tcr_AMCH)
#to fix overlap of main loc of AMCH over DELH main loc 27-June-2016
tcrdatacleangrpmainloc = tcrdatacleangrpmainloc.groupby(['CurrLoc - Next Loc']).agg({'Con Number':len,'Act Wt In Tonnes':sum}).reset_index()
tcrdatacleangrpmainlocmerge = pd.merge(tcrdatacleangrpmerge,tcrdatacleangrpmainloc,left_on=['CurrLoc - Next Loc'],right_on=['CurrLoc - Next Loc'],suffixes =['_Total','_Mainloc'] ,how='left')

tcrdatacleangrpmainlocmerge =tcrdatacleangrpmainlocmerge.rename(columns={'CurrLoc - Next Loc':'Lanes','Con Number_Total':'Cons_total','Act Wt In Tonnes_Total':'WT_total(T)','Con Number_Mainloc':'Cons_MainLoc','Act Wt In Tonnes_Mainloc':'WT_MainLoc(T)'})
tcrdatacleangrpmainlocmerge = tcrdatacleangrpmainlocmerge.fillna(0)

tcrdatacleangrpmainlocmerge['WT_total']= np.round(tcrdatacleangrpmainlocmerge.apply(lambda x: (x['WT_total(T)']*1000), axis=1),0)
tcrdatacleangrpmainlocmerge['WT_MainLoc']= np.round(tcrdatacleangrpmainlocmerge.apply(lambda x: (x['WT_MainLoc(T)']*1000), axis=1),0)


columnsop=['Lanes','Cons_total','WT_total','Cons_MainLoc','WT_MainLoc','Veh_dep_time']
tcrdatacleangrpmainlocmerge = pd.DataFrame(tcrdatacleangrpmainlocmerge,columns=columnsop)

# In[9]:

printlist =  [tcrdatacleangrpmainlocmerge]
namelist = ['Summary']
save_xls (printlist, namelist, oppath2)
print 'saving done'



tcrdatacleangrpmainlocmerge = tcrdatacleangrpmainlocmerge.to_string(index=False)
# In[10]:

opfilevar=reportts.date()
opfilevar1=reportts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=np.round((float(currhrs)/60),0)

# In[11]:

filePath = oppath2
def sendEmail(#TO = ["supratim@iepfunds.com","rajeesh.vr@spoton.co.in"],
            TO = ["cnm@spoton.co.in","raghavendra.rao@spoton.co.in","HUBMGR_SPOT@spoton.co.in"],
            #TO = ["vishwas.j@spoton.co.in"],
            #CC = ["vishwas.j@spoton.co.in"],
            CC = ["pawan.sharma@spoton.co.in","sqtf@spoton.co.in","shivananda.p@spoton.co.in","prasanna.hegde@spoton.co.in","rajeesh.vr@spoton.co.in", "rajesh.debnath@spoton.co.in"],
            BCC = ["vinayak.kumbhar@spoton.co.in","vinodkumar.mishra@spoton.co.in","nitin.tatyarao@spoton.co.in","kiran.pawar@spoton.co.in","jai.prakash@spoton.co.in","yogesh.singh@spoton.co.in"] ,
            #BCC = ["vishwas.j@spoton.co.in"] ,
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "Load Available for movement @ "+ str(opfilevar)+"-"+str(opfilevar2)
    msg["Subject"] = "Load Available for movement @ "+ str(opfilevar)+"-"+str(opfilevar2)
    body_text = """
    Dear All,
    
    PFB the load available for the critical lanes @ """ +str(opfilevar)+"-"+str(opfilevar2)+"""

    
    """+str(tcrdatacleangrpmainlocmerge)+"""
    
    For Conlevel basedata, please use the link below
    
    http://spoton.co.in/downloads/IEProjects/ETA/Load_available_report.xlsx
    """
    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends


# In[ ]:
oppath3 = r'D:\Data\Load_available_archives\All\Load_available_report_'+str(opfilevar)+'_'+str(opfilevar2)+'.xlsx'
printlist =  [tcrdata]
namelist = ['Data']
save_xls (printlist, namelist, oppath3)

oppath5 = r'D:\Data\Load_available_archives\Load_available_report.xlsx'
printlist =  [tcrdata]
namelist = ['Data']
save_xls (printlist, namelist, oppath5)

# For link in the email 

print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppath5
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()

# For link in the email 

## For VPIH load available fro BOMH

destareas_north = ['NCRA','LKOA','JAIA','IXCA','UKNA']
tcrdata_vpih = tcrdata[(tcrdata['Hub SC Location']=='VPIH') & (tcrdata['Destn Area'].isin(destareas_north))]
print len(tcrdata[(tcrdata['Hub SC Location']=='VPIH')])
print len(tcrdata_vpih)

laod_inc_depspwpkk = pd.np.round(tcrdata_vpih['Act Wt In Tonnes'].sum(),2)
cft_inc_depspwpkk = pd.np.round(tcrdata_vpih['Volume'].sum(),2)

tcrdata_vpih_clean = tcrdata_vpih[tcrdata_vpih['Observation']=='Correct']
laod_exc_depspwpkk = pd.np.round(tcrdata_vpih_clean['Act Wt In Tonnes'].sum(),2)
cft_exc_depspwpkk = pd.np.round(tcrdata_vpih_clean['Volume'].sum(),2)

oppath4 = r'D:\Data\Load_available_archives\VPIH_load\Load_available_VPIH_'+str(opfilevar)+'_'+str(opfilevar2)+'.xlsx'
printlist =  [tcrdata_vpih]
namelist = ['VPIH_Load']
save_xls (printlist, namelist, oppath4)

#emailhourslist = [0.0,24.0]
emailhourslist = [90.0]

print opfilevar2
if opfilevar2 in emailhourslist:
    print 'VPIH EMAIL'
    filePath1 = oppath4
    def sendEmail(TO = ["ramachandran.p@spoton.co.in","rajesh.debnath@spoton.co.in","sandesh.patade@spoton.co.in","ops.HUb.bomh.1@spoton.co.in","Omprakash.Singh@Spoton.Co.In"],
                #TO = ["rajeesh.vr@spoton.co.in"],
                #TO = ["vishwas.j@spoton.co.in"],
                CC = ["Pawan.Sharma@Spoton.Co.In","rajeesh.vr@spoton.co.in","prasanna.hegde@spoton.co.in"],
                #CC = ["rajeesh.vr@spoton.co.in","vishwas.j@spoton.co.in"],
                #CC = ["vishwas.j@spoton.co.in"],
                FROM="reports.ie@spoton.co.in"):
        HOST = "smtp.spoton.co.in"
    #smtplib.SMTP('smtp.spoton.co.in', 25)
    
        msg = MIMEMultipart()
        msg["From"] = FROM
        msg["To"] = ",".join(TO)
        msg["CC"] = ",".join(CC)
        msg["Subject"] = "VPIH Load Available for BOMH-DELH vehicle " + '- ' + str(opfilevar)+str('-')+ str(opfilevar2)
        body_text = """
        Dear All,
        
        This report gives the load available at VPIH for north areas
        
        Load available  = """+str(laod_inc_depspwpkk)+""" T
        Load available (excluding DEPS/Ppwk) = """+str(laod_exc_depspwpkk)+""" T
        
        CFT available  = """+str(cft_inc_depspwpkk)+""" cft
        CFT available (excluding DEPS/Ppwk) = """+str(cft_exc_depspwpkk)+""" cft
    
        Note :
        Conwise details has been attached in the email. We have identified the DEPS/paperwork cons in the 'Observation' column.
        To get the eligible cons, please select 'Correct' in the 'Observations' column. 
        """
    
        if body_text:
            msg.attach( MIMEText(body_text) )
        part = MIMEBase('application', "octet-stream")
        part.set_payload( open(filePath1,"rb").read() )
        Encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath1))
        msg.attach(part)
        server=smtplib.SMTP('smtp.sendgrid.net', 587)
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login("spoton.net.in", "Star@123#")
    
        try:
            failed = server.sendmail(FROM, TO+CC, msg.as_string())
            server.close()
        except Exception, e:
            errorMsg = "Unable to send email. Error: %s" % str(e)
    
    if __name__ == "__main__":
        sendEmail()
    #print('Email sent')
    
else:
    print 'No email for now'


## For VPIH load available fro BOMH





## For South loads available from JAIH. Added on 28-12-2016 12:00 PM

destareas_south = ['BLRA','MAAA','CBEA','COKA','IXMA']
tcrdata_jaih = tcrdata[(tcrdata['Hub SC Location']=='JAIH') & (tcrdata['Destn Area'].isin(destareas_south))]


laod_inc_depspwpkk_jaih = pd.np.round(tcrdata_jaih['Act Wt In Tonnes'].sum(),2)
cft_inc_depspwpkk_jaih = pd.np.round(tcrdata_jaih['Volume'].sum(),2)

tcrdata_jaih_clean = tcrdata_jaih[tcrdata_jaih['Observation']=='Correct']
laod_exc_depspwpkk_jaih = pd.np.round(tcrdata_jaih_clean['Act Wt In Tonnes'].sum(),2)
cft_exc_depspwpkk_jaih = pd.np.round(tcrdata_jaih_clean['Volume'].sum(),2)

oppath_jaih = r'D:\Data\Load_available_archives\JAIH_load\Load_available_JAIH_'+str(opfilevar)+'_'+str(opfilevar2)+'.xlsx'
printlist =  [tcrdata_jaih]
namelist = ['JAIH_Load']
save_xls (printlist, namelist, oppath_jaih)

emailhourslist_jaih = [2.0]
#emailhourslist = [90.0]

print opfilevar2
if opfilevar2 in emailhourslist_jaih:
    print 'JAIH EMAIL'
    filePath2 = oppath_jaih
    def sendEmail(TO = ["Krishna.Kumar.Bhardwaj@Spoton.Co.In","ops.hub.delh.1@spoton.co.in"],
                #TO = ["vishwas.j@spoton.co.in"],
                CC = ["Pawan.Sharma@Spoton.Co.In","rajeesh.vr@spoton.co.in","prasanna.hegde@spoton.co.in"],
                #CC = ["vishwas.j@spoton.co.in"],
                FROM="reports.ie@spoton.co.in"):
        HOST = "smtp.spoton.co.in"
    #smtplib.SMTP('smtp.spoton.co.in', 25)
    
        msg = MIMEMultipart()
        msg["From"] = FROM
        msg["To"] = ",".join(TO)
        msg["CC"] = ",".join(CC)
        msg["Subject"] = "JAIH Load Available for South " + '- ' + str(opfilevar)+str('-')+ str(opfilevar2)
        body_text = """
        Dear All,
        
        This report gives the load available at JAIH for South areas
        
        Load available  = """+str(laod_inc_depspwpkk_jaih)+""" T
        Load available (excluding DEPS/Ppwk) = """+str(laod_exc_depspwpkk_jaih)+""" T
        
        CFT available  = """+str(cft_inc_depspwpkk_jaih)+""" cft
        CFT available (excluding DEPS/Ppwk) = """+str(cft_exc_depspwpkk_jaih)+""" cft
    
        Note :
        Conwise details has been attached in the email. We have identified the DEPS/paperwork cons in the 'Observation' column.
        To get the eligible cons, please select 'Correct' in the 'Observations' column. 
        """
    
        if body_text:
            msg.attach( MIMEText(body_text) )
        part = MIMEBase('application', "octet-stream")
        part.set_payload( open(filePath2,"rb").read() )
        Encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath2))
        msg.attach(part)
        server=smtplib.SMTP('smtp.sendgrid.net', 587)
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login("spoton.net.in", "Star@123#")
    
        try:
            failed = server.sendmail(FROM, TO+CC, msg.as_string())
            server.close()
        except Exception, e:
            errorMsg = "Unable to send email. Error: %s" % str(e)
    
    if __name__ == "__main__":
        sendEmail()
    #print('Email sent')
    
else:
    print 'No email for now'


## For South loads available from JAIH. Added on 28-12-2016 12:00 PM




