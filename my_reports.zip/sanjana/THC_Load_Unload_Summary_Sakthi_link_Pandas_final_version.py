
# coding: utf-8

# In[1]:

# import ctypes, inspect, os, sframe
# from ctypes import wintypes
# kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
# kernel32.SetDllDirectoryW.argtypes = (wintypes.LPCWSTR,)
# src_dir = os.path.split(inspect.getfile(sframe))[0]
# kernel32.SetDllDirectoryW(src_dir)


# In[2]:

import pandas as pd
from datetime import datetime, timedelta
from pandas import ExcelWriter
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
import os
import smtplib

datetoday=datetime.today()
datefilter = datetoday-timedelta(hours=24)
datefilter=datefilter.date()
datefilter
# In[3]:

link = 'http://spoton.co.in/downloads/IEProjects/THCLOADUNLOAD/THCLOADUNLOAD.csv'


# In[4]:

def datetimeformatconvert(dep_load_unload_times):
    try:
        fulldate = datetime.strptime(dep_load_unload_times,'%d-%m-%Y %H:%M')
    except:
        fulldate = datetime.strptime(dep_load_unload_times,'%Y-%m-%d %H:%M:%S')
    return fulldate


# In[5]:

#thcload_unloadtime = gl.SFrame.read_csv(r'C:\Data\THC_load_unload\THC_LOAD_UNLOAD_COMBINED_PERFORMANCE_23Jul2016_New_sample_1.csv')
##thcload_unloadtime = gl.SFrame.read_csv(link,quote_char='"')
thcload_unloadtime = pd.read_csv(link)
thcload_unloadtime.to_csv(r'D:\Data\THC_Load_Unload_Efficiency\Basefile\THC_Load_Unload_Basefile_'+str(datefilter)+'.csv')

# In[6]:

thcload_unloadtime = thcload_unloadtime.rename(columns={'\xef\xbb\xbfHub_Location':'Hub_Location'})
#stockdata=stockdata.rename(columns={'\xef\xbb\xbfPARENTCODE1':'PARENTCODE1'})
thcload_unloadtime.columns.tolist()


# In[ ]:




# In[7]:

thcload_unloadtime = thcload_unloadtime.fillna(0)


# In[8]:

thcload_unloadtime['DEP_ARRIVAL_DATE'] = thcload_unloadtime.apply(lambda x: datetimeformatconvert(x['Departure_Or_Arrival_Date']),axis=1)
thcload_unloadtime['LOAD_UNLOAD_START'] = thcload_unloadtime.apply(lambda x: datetimeformatconvert(x['Load_unload_starttime']),axis=1)
thcload_unloadtime['LOAD_UNLOAD_END'] = thcload_unloadtime.apply(lambda x: datetimeformatconvert(x['Load_unload_endtime']),axis=1)

thcload_unloadtime['Starthr'] = thcload_unloadtime.apply(lambda x: (x['LOAD_UNLOAD_START'].hour),axis=1)
thcload_unloadtime['Endhr'] = thcload_unloadtime.apply(lambda x: (x['LOAD_UNLOAD_END'].hour),axis=1)


# In[9]:

##thcload_unloadtime.save('thcload_unloadtime.csv')


# In[10]:

print thcload_unloadtime['LOAD_UNLOAD_END'][0],type(thcload_unloadtime['LOAD_UNLOAD_END'][0])
print thcload_unloadtime['LOAD_UNLOAD_START'][0],type(thcload_unloadtime['LOAD_UNLOAD_START'][0])
print thcload_unloadtime['DEP_ARRIVAL_DATE'][0],type(thcload_unloadtime['DEP_ARRIVAL_DATE'][0])


# In[11]:

def turnarndtimecalc(loadunloadtype,deparrvltime,loadunloadstart,loadunloadend):
    if loadunloadtype == 'U':
        tat = (loadunloadend-deparrvltime)
        #tat = pd.np.round(tat,2)
    elif loadunloadtype == 'L':
        tat = (deparrvltime-loadunloadstart)
        #tat = pd.np.round(tat,2)
    else:
        tat = 'check'
    #return tat
    tathrs = round((tat.total_seconds()*1.0)/3600,2)
    if tathrs == 0:
        tathrs = 0.1
    return tathrs
    

    


# In[12]:

##thcload_unloadtime['TAT'] = thcload_unloadtime.apply(lambda x: turnarndtimecalc(x['Load_unload'],x['DEP_ARRIVAL_DATE'],x['LOAD_UNLOAD_START'],x['LOAD_UNLOAD_END']))
thcload_unloadtime['Turn_around_time'] = thcload_unloadtime.apply(lambda x: (turnarndtimecalc(x['Load_or_unload'],x['DEP_ARRIVAL_DATE'],x['LOAD_UNLOAD_START'],x['LOAD_UNLOAD_END'])),axis=1)


# In[13]:

#thcload_unloadtime.to_csv('thcload_unloadtime_tatcheck.csv')


# In[14]:

def efficiencycal(tatperhr):
    idealtat = 3.0
    efficiency = pd.np.round((abs(tatperhr*idealtat)/13500.0)*100,2)
    return efficiency

def efficiencycal_thc(tatperhr_thc):
    idealtat_thc = 3.0
    thcefficiency = pd.np.round((abs(tatperhr_thc*idealtat_thc)/13500.0)*100,2)
    return thcefficiency

def efficiencycal_thc_buckets(thceffy):
    if thceffy<=50:
        return 'LOW'
    elif thceffy>50 and thceffy<=70:
        return 'MEDIUM'
    elif thceffy>70:
        return 'HIGH'
    else:
        return 'CHECK'


# In[15]:

thcload_unloadtime['Load_unload_TAT_per_hr'] = thcload_unloadtime.apply(lambda x: round((x['Actual_load_unload_wt'])/(x['Turn_around_time']),2),axis=1)
thcload_unloadtime['THC_Efficiency'] = thcload_unloadtime.apply(lambda x: efficiencycal_thc(x['Load_unload_TAT_per_hr']),axis=1)

thcload_unloadtime['THC_Efficiency_Bucket'] = thcload_unloadtime.apply(lambda x: efficiencycal_thc_buckets(x['THC_Efficiency']),axis=1)


# Finding THC Exceptions start
def exceptioncheck(loadunloadtype,deparrvltime,loadunloadstart,loadunloadend,tatloadunloadperhr):
    if loadunloadtype == 'U' and (deparrvltime>=loadunloadend):
        return 'Data_entry'
    elif loadunloadtype == 'L' and (loadunloadstart>=deparrvltime):
        return 'Data_entry'
    elif tatloadunloadperhr>=10000:
        return 'Check'
    else:
        return 'OK'
        
thcload_unloadtime['Exception'] = thcload_unloadtime.apply(lambda x: exceptioncheck(x['Load_or_unload'],x['Departure_Or_Arrival_Date'],x['Load_unload_starttime'],x['Load_unload_endtime'],x['Load_unload_TAT_per_hr']),axis=1)

thc_exceptionsdf = thcload_unloadtime[thcload_unloadtime['Exception']!='OK']
exceptionthcs = len(thc_exceptionsdf)
# Finding THC Exceptions end

##thcload_unloadtime['Turn_around_time'] = thcload_unloadtime.apply(lambda x: round(x['TAT'],2))


# In[17]:

thcload_unloadtime_load = thcload_unloadtime[thcload_unloadtime['Load_or_unload']=='L']
thcload_unloadtime_unload = thcload_unloadtime[thcload_unloadtime['Load_or_unload']=='U']
len(thcload_unloadtime_load),len(thcload_unloadtime_unload)


# In[18]:

#thc_load_grpby = thcload_unloadtime_load.groupby(['Hub_Location'],{'TAT':agg.SUM('Turn_around_time'),'Actual_Load_or_Unload_Wt': agg.SUM('Actual_load_unload_wt'),'THC_L_Count': agg.COUNT('THC_Number')})
#thc_unload_grpby = thcload_unloadtime_unload.groupby(['Hub_Location'],{'TAT':agg.SUM('Turn_around_time'),'Actual_Load_or_Unload_Wt': agg.SUM('Actual_load_unload_wt'),'THC_U_Count': agg.COUNT('THC_Number')})


thc_load_grpby = thcload_unloadtime_load.groupby(['Hub_Location']).agg({'Turn_around_time':sum,'Actual_load_unload_wt': sum,'THC_Number': len}).reset_index()
thc_unload_grpby = thcload_unloadtime_unload.groupby(['Hub_Location']).agg({'Turn_around_time':sum,'Actual_load_unload_wt': sum,'THC_Number': len}).reset_index()


# In[19]:

thc_load_grpby = thc_load_grpby.rename(columns={'Turn_around_time':'TAT','THC_Number':'THC_L_Count','Actual_load_unload_wt':'Actual_Load_or_Unload_Wt'})
thc_unload_grpby = thc_unload_grpby.rename(columns={'Turn_around_time':'TAT','THC_Number':'THC_U_Count','Actual_load_unload_wt':'Actual_Load_or_Unload_Wt'})


# In[20]:

thc_load_grpby['Load_wt_TAT_perhr'] = thc_load_grpby.apply(lambda x: round((x['Actual_Load_or_Unload_Wt'])/(x['TAT']),2),axis=1)
thc_unload_grpby['Unload_wt_TAT_perhr'] = thc_unload_grpby.apply(lambda x:round((x['Actual_Load_or_Unload_Wt'])/(x['TAT']),2),axis=1)


# In[21]:

thc_load_grpby['Loading_Efficiency'] = thc_load_grpby.apply(lambda x: efficiencycal(x['Load_wt_TAT_perhr']),axis=1)
thc_unload_grpby['Unloading_Efficiency'] = thc_unload_grpby.apply(lambda x: efficiencycal(x['Unload_wt_TAT_perhr']),axis=1)


# In[22]:

thc_load_grpby


# In[23]:

thc_unload_grpby


# In[24]:

#thcsummary = thc_load_grpby.join(thc_unload_grpby,on='Hub_Location',how = 'outer')
thcsummary = pd.merge(thc_load_grpby,thc_unload_grpby,on='Hub_Location',how = 'outer')


# In[25]:

thcsummary


# In[26]:

thcsummary = thcsummary.rename(columns={'TAT_x':'TAT_Load','TAT_y':'TAT_Unload','Actual_Load_or_Unload_Wt_x':'Actual_Load_or_Unload_Wt_Load','Actual_Load_or_Unload_Wt_y':'Actual_Load_or_Unload_Wt_Unload'})


# In[27]:

thcsummary = thcsummary.fillna(0)


# In[28]:

thcsummary['TOTAL_THCs'] = thcsummary.apply(lambda x:x['THC_L_Count']+x['THC_U_Count'],axis=1)
thcsummary['TOTAL_ACT_WT'] = thcsummary.apply(lambda x:x['Actual_Load_or_Unload_Wt_Load']+x['Actual_Load_or_Unload_Wt_Unload'],axis=1)
thcsummary['TOTAL_TAT'] = thcsummary.apply(lambda x:x['TAT_Load']+x['TAT_Unload'],axis=1)


# In[29]:

thcsummary.head()


# In[30]:

thcsummary['TOTAL_TAT_PER_HR'] = thcsummary.apply(lambda x: round((x['TOTAL_ACT_WT'])/(x['TOTAL_TAT']),2),axis=1)
thcsummary['TOTAL_EFFICIENCY'] = thcsummary.apply(lambda x: efficiencycal(x['TOTAL_TAT_PER_HR']),axis=1)


# In[31]:

#thc_final_summary = thcsummary


# In[32]:



# In[33]:

thc_final_summary = pd.DataFrame(thcsummary,columns=['Hub_Location','TOTAL_THCs','TOTAL_ACT_WT','THC_L_Count','Loading_Efficiency','THC_U_Count','Unloading_Efficiency','TOTAL_EFFICIENCY'])


# In[34]:

thc_final_summary


# In[35]:

#thc_final_summary.remove_columns(['TAT_Load','TAT_Unload','Actual_Load_or_Unload_Wt_Unload','Actual_Load_or_Unload_Wt_Load','Load_wt_TAT_perhr','Unload_wt_TAT_perhr'])


# In[36]:

hublist = thc_final_summary['Hub_Location'].unique()
itemlist = []
for hubs in hublist:
    for i in range(0,24):
        thchub = thcload_unloadtime[thcload_unloadtime['Hub_Location']==hubs]
        thcrel = thchub[(thchub['Starthr']<=i) &(thchub['Endhr']>i)]
        count = len(thcrel)
        lcount = len(thcrel[thcrel['Load_or_unload']=='L'])
        ucount = count-lcount
        item = [hubs,i,count,lcount,ucount]
        itemlist.append(item)
itemdf = pd.DataFrame(itemlist)
itemdf.columns = ['Hub_Location','TimeofDay','THCCount','LCount','UCount']
#itemsf = gl.SFrame(itemdf)
#itemsf = pd.DataFrame(itemdf,columns=)
itemdf.to_csv(r'D:\Data\THC_Load_Unload_Efficiency\itemdf.csv')

# In[38]:

hubgrp = itemdf.groupby(['Hub_Location']).agg({'THCCount':max}).reset_index()
hubgrp = hubgrp.rename(columns={'THCCount':'Max_simultaneous_load_unload'})


# In[39]:

hubgrp


# In[40]:

thc_final_summary = pd.merge(thc_final_summary,hubgrp,on='Hub_Location',how = 'outer')


# In[41]:

#thc_final_summary_df = thc_final_summary.to_dataframe()
thc_final_summary = pd.DataFrame(thc_final_summary,columns=['Hub_Location','TOTAL_THCs','TOTAL_ACT_WT','Max_simultaneous_load_unload','THC_L_Count','Loading_Efficiency','THC_U_Count','Unloading_Efficiency','TOTAL_EFFICIENCY'])
thc_final_summary = thc_final_summary.sort_values('TOTAL_ACT_WT',ascending=False)
#thcload_unloadtime_df = thcload_unloadtime.to_dataframe()


# In[42]:

thc_final_summary


# In[43]:
tatsum = thcload_unloadtime['Turn_around_time'].sum()
loadsum = thcload_unloadtime['Actual_load_unload_wt'].sum()
idealtat = 3.0

tatloadperhr = (loadsum*1.0/tatsum)
total_overall_efficiency = pd.np.round(((tatloadperhr*idealtat)/13500.0)*100,2)


# In[44]:

thc_final_summary_mailbody = thc_final_summary
thc_final_summary_mailbody = thc_final_summary_mailbody.rename(columns={'Hub_Location':'HUB','TOTAL_THCs':'THCs','TOTAL_ACT_WT':'ACT_WT','Max_simultaneous_load_unload':'L_U_Smlt','THC_L_Count':'L_THC','THC_U_Count':'U_THC','Loading_Efficiency':'L_EFF','Unloading_Efficiency':'U_EFF','TOTAL_EFFICIENCY':'TOTAL_EFF'})

# In[45]:

thc_final_summary_mailbody = thc_final_summary_mailbody.to_string(index=False)


# In[46]:

thcload_unloadtime.loc[thcload_unloadtime.index,'Date'] = datefilter

thc_final_summary.to_csv(r'D:\Data\THC_Load_Unload_Efficiency\THC_Summary_Data\THC_LU_Efficiency_Summary_'+str(datefilter)+'.csv')
thcload_unloadtime.to_csv(r'D:\Data\THC_Load_Unload_Efficiency\THC_Data\THC_LU_Data_'+str(datefilter)+'.csv')

# In[ ]:

## To remove target time in the file which is sent to everyone
thcload_unloadtime = thcload_unloadtime.drop(['Target_time_in_mins'],axis=1)
thc_exceptionsdf = thc_exceptionsdf.drop(['Target_time_in_mins'],axis=1)
## To remove target time in the file which is sent to everyone



#### For explaining the efficiency calculation
delh_totalwt = thcload_unloadtime[thcload_unloadtime['Hub_Location']=='DELH']['Actual_load_unload_wt'].sum()
delh_totaltat = thcload_unloadtime[thcload_unloadtime['Hub_Location']=='DELH']['Turn_around_time'].sum()
print delh_totalwt,delh_totaltat

idealtime_delh = pd.np.round((delh_totalwt/4500.0),2)

delh_effy = pd.np.round((idealtime_delh/delh_totaltat)*100.0,2)
print delh_effy
#### For explaining the efficiency calculation


oppath1 = r'D:\Data\THC_Load_Unload_Efficiency\THC_LU_Consolidated\THC_LU_Efficiency_'+str(datefilter)+'.xlsx'
with ExcelWriter(r'D:\Data\THC_Load_Unload_Efficiency\THC_LU_Consolidated\THC_LU_Efficiency_'+str(datefilter)+'.xlsx') as writer:
    thc_final_summary.to_excel(writer, sheet_name='SUMMARY',engine='xlsxwriter')
    thcload_unloadtime.to_excel(writer, sheet_name='THC_DATA',engine='xlsxwriter')
    thc_exceptionsdf.to_excel(writer, sheet_name='THC_EXCEPTIONS',engine='xlsxwriter')

# In[ ]:
filePath = oppath1
def sendEmail(#TO = ["hubmgr_spot@spoton.co.in"],
            #TO = ["rajeesh.vr@spoton.co.in"],
            TO = ["vishwas.j@spoton.co.in"],
            CC = ["vishwas.j@spoton.co.in"],
            #CC = ["supratim@iepfunds.com","pawan.sharma@spoton.co.in","krishna.chandrasekar@spoton.co.in","Ankit@iepfunds.com","abhik.mitra@spoton.co.in","prasanna.hegde@spoton.co.in","vishwas.j@spoton.co.in","rajeesh.vr@spoton.co.in","shivananda.p@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "Linehaul_Vehicle_Load_Unload_Efficiency" + '- ' + str(datefilter)
    body_text = """
    Dear All,
    
    PFA the Linehaul_Vehicle_Load_Unload_Efficiency for """+str(datefilter)+ """

    The overall Loading unloading efficiency is """+str(total_overall_efficiency)+"""    
    THCs where there might be data entry issues = """+str(exceptionthcs)+"""   
    
    The calculation of efficiency is shown below
    
    PFB the summary
"""+str(thc_final_summary_mailbody)+"""    
    
    
    Example on how total efficiency of DELH is calculated:
    
    Total weight loaded/unloaded by DELH (Sum of Actual_load_unload_wt column)= """+str(delh_totalwt)+""" KG
    Total time taken to load/unload the above weight by DELH (Sum of Turn_around_time column) = """+str(delh_totaltat)+""" Hours
    
    NOTE : Our assumption is that for loading/unloading 13500 KG, 3 hours is required. Hence per hour, 4500 KG is the ideal weight to be loaded/unloaded
    
    If the weight loaded/unloaded by DELH is divided by 4500, we will get the ideal time for loading/unloading that weight. 
    So ideal time for DELH is """+str(delh_totalwt)+""" / """+str(4500)+""" which is """+str(idealtime_delh)+""" Hours
    Now, efficiency is calculated as (Ideal time/ total time taken by DELH)*100 which is shown below
    """+str(idealtime_delh)+"""/"""+str(delh_totaltat)+"""*100 = """+str(delh_effy)+"""%
    If loading efficiency needs to be calculated, select 'L' in Load_or_unload column and repeat the same procedure mentioned above
    If unloading efficiency needs to be calculated, select 'U' in Load_or_unload column and repeat the same procedure mentioned above
    
    
    Turn around time(TAT) :
    TAT for loading = (Departure time of vehicle - Loading start time)
    TAT for unloading = (Arrival time of vehicle - Unloading end time)
    Efficiency:
    Loading efficiency - Actual Weight loaded in total time / Ideal Weight to be loaded in total time
    Unloading efficiency - Actual Weight unloaded in total time / Ideal weight to be unloaded in total time
    
    Note: For a 13.5T vehicle, Ideal TAT is 3 hours ie.., in 3 hours a 13.5T vehicle to be unloaded/loaded completely    
    
    The report has 3 sheets
    1) Summary : This sheet has the hubwise summary of efficiency in loading/unloading
    2) THC_Data : This sheet has all the THCs received/prepared yesterday for which load/unload start and end time has been updated
    3) THC_EXCEPTIONS : This sheet contains THC numbers which have exceptions which needs a check. Currently, THCs which have data entry anamaly and high load/unload wt per hr will be given under exceptions and these needs to be checked
    
    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends





# In[ ]:



