
# coding: utf-8

# In[1]:


import pandas as pd
import pyodbc
from datetime import datetime,timedelta
from datetime import datetime,timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
import ftplib
from calendar import monthrange
import smtplib


# In[42]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()


# In[15]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()


# In[2]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
cursor = cnxn.cursor()


# In[3]:


# startdate=datetime.strftime((datetime.now()-timedelta(days=1)).replace(day=1),"%Y-%m-%d")
startdate='2019-08-01'


# In[4]:


enddate=datetime.strftime(datetime.now()-timedelta(days=1),"%Y-%m-%d")
enddate


# In[5]:


query1=("""SELECT  A.Dockno DOCKNO,
A.PISGenerated TabPISgenerated
FROM    dbo.tblCashFTCCollectionDtls A WITH ( NOLOCK )
        INNER JOIN dbo.TblCashFTCHandOverDTLS B WITH ( NOLOCK ) ON B.Dockno = A.Dockno
        INNER JOIN dbo.TBLCashFTCHandOverHDR C WITH ( NOLOCK ) ON C.HandOverid = B.HandOverid
        LEFT JOIN dbo.TblCashFTCHandOver_Ack D WITH ( NOLOCK ) ON D.AckId = B.AckId
        LEFT JOIN dbo.tblInvoiceConMap E WITH (NOLOCK) ON A.Dockno = E.DocketNumber
        LEFT JOIN DOCKET F WITH (NOLOCK) ON A.Dockno = F.DOCKNO
        LEFT JOIN dbo.DKT_DELY G WITH (NOLOCK) ON A.Dockno = G.DOCKNO
WHERE   G.DELY_DT BETWEEN '{0}'
                  AND    '{1}'
 

""").format (startdate, enddate) 


# In[6]:


query2=("""SELECT  A.DOCKNO ,

        A.DOCKDT Pickupdate ,

        A.CDELDT Deliverydate ,

        A.PAYBAS ,

        A.ORGNCD ,

        A.DESTCD ,

        TV.TotalInvoiceAmount ,

        B.InvoiceId ,

        D.PISNO ,

        C.CollectedAmnt ,

        B.InvoiceId

FROM    dbo.DOCKET A WITH ( NOLOCK )

        LEFT OUTER JOIN dbo.DKT_DELY DD WITH ( NOLOCK ) ON DD.DOCKNO = A.DOCKNO

        LEFT OUTER JOIN dbo.tblInvoiceConMap B WITH ( NOLOCK ) ON B.DocketNumber = A.DOCKNO

              LEFT OUTER JOIN dbo.tblInvoice TV WITH (NOLOCK) ON TV.InvoiceId = B.InvoiceId AND TV.SupplementaryInvoiceType IS NULL AND TV.Reinvoice = 0

        LEFT OUTER JOIN espeedage.dbo.Collectiondtls_iep C WITH ( NOLOCK ) ON SUBSTRING(C.conNo,

                                                              1, 10) = CONVERT(VARCHAR(10), B.InvoiceId)

                                                              AND C.CollectionTyp NOT IN (

                                                              'DEM', 'OCT',

                                                              'ETX' )

        LEFT OUTER JOIN espeedage.dbo.CollectionMain_iep D WITH ( NOLOCK ) ON D.InternalNo = C.InternalNo

        LEFT OUTER JOIN dbo.tblCashFTCCollectionDtls E WITH ( NOLOCK ) ON E.Dockno = A.DOCKNO

WHERE   A.PAYBAS IN ( 4 )

        AND A.CDELDT BETWEEN '{0}'
                     AND     '{1}'

""").format (startdate, enddate)


# In[7]:


df1=pd.read_sql(query1,cnxn)


# In[8]:


df2=pd.read_sql(query2,cnxn)


# In[9]:


df1['Entry Type']='TAB'


# In[10]:


df1['DOCKNO']=df1['DOCKNO'].astype(int)


# In[11]:


df2['DOCKNO']=df2['DOCKNO'].astype(int)


# In[12]:


df3=pd.merge(df2,df1,how='left',on='DOCKNO')


# In[13]:


df3['Entry Type']=df3['Entry Type'].fillna('Manual/IBS')


# In[14]:


df4=df3[df3['DESTCD'].isin(['BLRB','BLRT','BLRF','BLRR','BLRN'])]


# In[15]:


df4['PISNO']=df4['PISNO'].fillna(0)


# In[18]:


def a(PISNO):
   
    if PISNO!=0:
        return 'PIS Done'
    else:
        return 'PIS Not Done'
                 


# In[19]:


df4['Status']=df4.apply(lambda x:a (x['PISNO']),axis=1)


# In[20]:


df4


# In[21]:


df5=df4.pivot_table(index=['Deliverydate'],columns=['Entry Type','Status'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True).fillna(0)


# 
# # CASH Delivery

# In[38]:


df5


# In[23]:


query11=("""SELECT  A.Dockno DOCKNO,
A.PISGenerated TabPISgenerated
FROM    dbo.tblCashFTCCollectionDtls A WITH ( NOLOCK )
        INNER JOIN dbo.TblCashFTCHandOverDTLS B WITH ( NOLOCK ) ON B.Dockno = A.Dockno
        INNER JOIN dbo.TBLCashFTCHandOverHDR C WITH ( NOLOCK ) ON C.HandOverid = B.HandOverid
        LEFT JOIN dbo.TblCashFTCHandOver_Ack D WITH ( NOLOCK ) ON D.AckId = B.AckId
        LEFT JOIN dbo.tblInvoiceConMap E WITH (NOLOCK) ON A.Dockno = E.DocketNumber
        LEFT JOIN DOCKET F WITH (NOLOCK) ON A.Dockno = F.DOCKNO
        LEFT JOIN dbo.DKT_DELY G WITH (NOLOCK) ON A.Dockno = G.DOCKNO
WHERE   F.DOCKDT BETWEEN '{0}'
                  AND    '{1}'
 

""").format (startdate, enddate) 


# In[24]:


query21=("""SELECT  A.DOCKNO ,

        A.DOCKDT Pickupdate ,

        A.CDELDT Deliverydate ,

        A.PAYBAS ,

        A.ORGNCD ,

        A.DESTCD ,

        TV.TotalInvoiceAmount ,

        B.InvoiceId ,

        D.PISNO ,

        C.CollectedAmnt ,

        B.InvoiceId

FROM    dbo.DOCKET A WITH ( NOLOCK )

        LEFT OUTER JOIN dbo.DKT_DELY DD WITH ( NOLOCK ) ON DD.DOCKNO = A.DOCKNO

        LEFT OUTER JOIN dbo.tblInvoiceConMap B WITH ( NOLOCK ) ON B.DocketNumber = A.DOCKNO

              LEFT OUTER JOIN dbo.tblInvoice TV WITH (NOLOCK) ON TV.InvoiceId = B.InvoiceId AND TV.SupplementaryInvoiceType IS NULL AND TV.Reinvoice = 0

        LEFT OUTER JOIN espeedage.dbo.Collectiondtls_iep C WITH ( NOLOCK ) ON SUBSTRING(C.conNo,

                                                              1, 10) = CONVERT(VARCHAR(10), B.InvoiceId)

                                                              AND C.CollectionTyp NOT IN (

                                                              'DEM', 'OCT',

                                                              'ETX' )

        LEFT OUTER JOIN espeedage.dbo.CollectionMain_iep D WITH ( NOLOCK ) ON D.InternalNo = C.InternalNo

        LEFT OUTER JOIN dbo.tblCashFTCCollectionDtls E WITH ( NOLOCK ) ON E.Dockno = A.DOCKNO

WHERE   A.PAYBAS IN ( 1 )

        AND A.DOCKDT BETWEEN '{0}'
                     AND     '{1}'

""").format (startdate, enddate)


# In[25]:


df11=pd.read_sql(query11,cnxn)


# In[26]:


df21=pd.read_sql(query21,cnxn)


# In[27]:


df11['Entry Type']='TAB'


# In[28]:


df11['DOCKNO']=df11['DOCKNO'].astype(int)


# In[29]:


df21['DOCKNO']=df21['DOCKNO'].astype(int)


# In[30]:


df31=pd.merge(df21,df11,how='left',on='DOCKNO')


# In[31]:


df31['Entry Type']=df31['Entry Type'].fillna('Manual/IBS')


# In[32]:


df41=df31[df31['ORGNCD'].isin(['BLRB','BLRT','BLRF','BLRR','BLRN'])]


# In[33]:


df41['PISNO']=df41['PISNO'].fillna(0)


# In[34]:


def b(PISNO):
    
    if PISNO!=0:
        return 'PIS Done'
    else:
        return 'PIS Not Done'


# In[35]:


df41['Status']=df41.apply(lambda x:b (x['PISNO']),axis=1)


# In[36]:


df51=df41.pivot_table(index=['Deliverydate'],columns=['Entry Type','Status'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True).fillna(0)


# # CASH Pick-up

# In[45]:


df51


# In[233]:


df4
df41

