
# coding: utf-8

# In[26]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta
import sys
import Utilities

# cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor=cnxn.cursor()

query=("""SELECT  --TOP 10
        A.DOCKNO ,
        B.DOCKDT BOOKINGDATE ,
        A.ACTUWT ,
        PIECES ,
        DEST_BRCD ,
        DEST_BRNM ,
        DEST_AREA ,
        DEST_DEPOT ,
        DEST_REGION ,
        DEL_LOCATION_TYPE ,
        VTC ,
        FTC ,
        DACC ,
        DC ,
        A.CSGECD ,
        A.CSGENM ,
        ARRV_AT_DEST_SC ,
        REPORTDATE_MIN_ARRVDT ,
        A.CSGNCD ,
        A.CSGNNM ,
        ORG_BRCD ,
        ORG_BRNM ,
        ORG_AREA ,
        ORG_DEPOT ,
        ORG_REGION ,
        A.DECLVAL ,
        DEST_PINCODE ,
        ConStatusCategory ,
        ConStatusCode ,
        ConStatusDesc ,
        ConStatusReason ,
        ConStatusDate ,
        LogDate ,
        FreeStorageDays ,
        CON_BLOCKED_FOR_PAY_ISSUES ,
        PARENTCODE ,
        PARENTNAME ,
        CON_BLOCKED_FOR_ODA_PIN_ISSUES ,
        CON_BLOCKED_FOR_DEMURRAGE ,
        TTS_AuditStatus ,
        TTS_AuditRemarks ,
        ReportGenConStatusDate ,
        IsTTSTicketRaised ,
        IsApptmntDel ,
        ApptmntDelDate ,
        A.CDELDT DUEDATE ,
        LatestTicketStatus ,
        LatestTicketStatusCode ,
        DEMURRAGE_RESPONSIBILITY ,
        ( SELECT    dbo.UFN_GET_CSAGENTCODE(A.DOCKNO)
        ) AGENTCODE ,
        C.EMPNM AGENTNAME
FROM    dbo.tblOCIDClosingStock A
        INNER JOIN dbo.DOCKET B WITH ( NOLOCK ) ON B.DOCKNO = A.DOCKNO
        LEFT OUTER JOIN dbo.EMPMST C ON C.EMPCD = ( SELECT  dbo.UFN_GET_CSAGENTCODE(A.DOCKNO)
                                                  )
WHERE   LogDate = CONVERT(DATE, GETDATE())
        AND ConStatusCategory IN ( 'RECEIVER FAILURE', 'SENDER FAILURE' )
        AND ConStatusCode NOT IN ( 'UCG', 'UG1', 'UG2', 'UG3', 'SSC' )
        AND B.DOCKDT >= 0     """)

data=pd.read_sql(query,Utilities.cnxn)
df= pd.DataFrame(data=data)


# In[27]:


pivot=pd.pivot_table(df, index=["PARENTNAME","DEST_BRCD"],
                     values=["DOCKNO","PIECES","ACTUWT"],
                     aggfunc={"DOCKNO":len,"ACTUWT":sum,"PIECES":sum},
                     fill_value=0,
                     margins=True)

pivot.groupby(by="PARENTNAME")
pivot["ACTUWT>5"]=(pivot['ACTUWT']/1000)
pivot["ACTUWT>5"]=pd.np.round(pivot["ACTUWT>5"],0)
pivot.sort_values('ACTUWT>5',ascending=False,inplace=True)
pivot=pivot[pivot['ACTUWT>5']>=5.0]
# ----------------- F I L T E R ------------------------- #
pivot1=pivot[["ACTUWT>5","DOCKNO","PIECES"]]
pivot2 = pivot1.reset_index()


# In[28]:


df2=pd.merge(df,pivot2, on=['PARENTNAME','DEST_BRCD'], how='right')


# In[29]:


df2.rename(columns={"DOCKNO_x":"DOCKNO",
                    "PIECES_x":"PIECES",
                
                    "ACTUWT>5":"ACTUWT_NAs",
                    "ACTUWT_y":"Actual_NA",
                    "DOCKNO_y":"DOCKNO_na",
                    "PIECES_y":"pieces_na"},
           inplace=True)


# In[30]:


table=df2[['PARENTNAME', 'PARENTCODE','DOCKNO', 'BOOKINGDATE', 'ACTUWT', 'PIECES', 'DEST_BRCD', 'DEST_BRNM',
       'DEST_AREA', 'DEST_DEPOT', 'DEST_REGION', 'DEL_LOCATION_TYPE', 'VTC',
       'FTC', 'DACC', 'DC', 'CSGECD', 'CSGENM', 'ARRV_AT_DEST_SC',
       'REPORTDATE_MIN_ARRVDT', 'CSGNCD', 'CSGNNM', 'ORG_BRCD', 'ORG_BRNM',
       'ORG_AREA', 'ORG_DEPOT', 'ORG_REGION', 'DECLVAL', 'DEST_PINCODE',
       'ConStatusCategory', 'ConStatusCode', 'ConStatusDesc',
       'ConStatusReason', 'ConStatusDate', 'LogDate', 'FreeStorageDays',
       'CON_BLOCKED_FOR_PAY_ISSUES', 
       'CON_BLOCKED_FOR_ODA_PIN_ISSUES', 'CON_BLOCKED_FOR_DEMURRAGE',
       'TTS_AuditStatus', 'TTS_AuditRemarks', 'ReportGenConStatusDate',
       'IsTTSTicketRaised', 'IsApptmntDel', 'ApptmntDelDate', 'DUEDATE',
       'LatestTicketStatus', 'LatestTicketStatusCode',
       'DEMURRAGE_RESPONSIBILITY', 'AGENTCODE', 'AGENTNAME']]


# In[31]:


import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback
from glob import glob
from IPython import display
from datetime import datetime,timedelta
import pyodbc



date=datetime.strftime(datetime.now(),'%Y-%m-%d-%H')


# In[32]:


from pandas import ExcelWriter
with ExcelWriter(r"D:\Data\CCF5Tons\CCF_cons_Greater_than_5T.xlsx") as writer:
  pivot2.to_excel(writer, sheet_name='ACTUWT>5T',engine='xlsxwriter')
  # table.to_excel(writer, sheet_name='DATA',engine='xlsxwriter')

print("ExcelSheet Created!")


# In[33]:


filepath=r'D:\Data\CCF5Tons\CCF_cons_Greater_than_5T.xlsx'
oppath1=filepath


#### Separate CSV for Data. Vishwas edit

table.to_csv(r'D:\Data\CCF5Tons\CCF_cons_Greater_than_5T_Data.csv')
filepath1 = r'D:\Data\CCF5Tons\CCF_cons_Greater_than_5T_Data.csv'


oppath2=filepath1
#FTP Upload starts
print ('Logging in...')
ftp = ftplib.FTP()  
ftp.connect('10.109.230.50')  
print (ftp.getwelcome())

try:
 try:
     ftp.login('HOSQTeam', 'Te@mH0$q')
     print ('login done')
     ftp.cwd('Auto_reports')
     #ftp.cwd('FIFO')
     # move to the desired upload directory
     print ("Currently in:", ftp.pwd())
     print ('Uploading...')
     fullname = oppath2
     name = os.path.split(fullname)[1]
     f = open(fullname, "rb")
     ftp.storbinary('STOR ' + name, f)
     f.close()
     print ("OK"  )
     print ("Files:")
     print (ftp.retrlines('LIST'))
 finally:
     print ("Quitting...")
     ftp.quit()
except:
    traceback.print_exc()

#### Separate CSV for Data. Vishwas edit

# In[37]:


### Not required as attached in the email


# #FTP Upload starts
# print ('Logging in...')
# ftp = ftplib.FTP()  
# ftp.connect('10.109.230.50')  
# print (ftp.getwelcome())

# try:
#  try:
#      ftp.login('HOSQTeam', 'Te@mH0$q')
#      print ('login done')
#      ftp.cwd('Auto_reports')
#      #ftp.cwd('FIFO')
#      # move to the desired upload directory
#      print ("Currently in:", ftp.pwd())
#      print ('Uploading...')
#      fullname = oppath1
#      name = os.path.split(fullname)[1]
#      f = open(fullname, "rb")
#      ftp.storbinary('STOR ' + name, f)
#      f.close()
#      print ("OK"  )
#      print ("Files:")
#      print (ftp.retrlines('LIST'))
#  finally:
#      print ("Quitting...")
#      ftp.quit()
# except:
#     traceback.print_exc()

### Not required as attached in the email
    
#date=datetime.strftime(datetime.now(),'%Y-%m-%d %H:%M:%S')


# ----------- E M A I L --------------------------    
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template                    


TO=['uday.sharma@spoton.co.in','sanjay.nalawade@spoton.co.in','mayank.dwivedi@spoton.co.in','spot_cstl@spoton.co.in','dsm_spot@spoton.co.in']
# TO=['sanjana.narayana@spoton.co.in']
# CC =['vishwas.j@spoton.co.in']
FROM="mis.ho@spoton.co.in"
CC = ['sharmistha.majumdar@spoton.co.in','jothi.menon@spoton.co.in','pawan.sharma@spoton.co.in','rajesh.kumar@spoton.co.in','shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in']
BCC = ['sanjana.narayana@spoton.co.in','mahesh.reddy@spoton.co.in']


msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = " CCF cons lying @ Destn SC Wt>5T " + " - " + str(date)
html='''<html>
<style>        
p
 {
   margin:0;
   margin-top: 5px;
   padding:0;
   font-size:15px;
   line-height:20px;
 }
</style>                


'''
html3='''

Link below for the conwise data

<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/CCF_cons_Greater_than_5T_Data.csv"</a>
"http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/CCF_cons_Greater_than_5T_Data.csv</p>
'''
report=""
report+='<br>'
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='Please find summary where Actual weight is greater than 5Tons.'
report+='<br>'
report+='<br>'+pivot2.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(oppath1,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("spoton.net.in", "Star@123#")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
print ('mail sent')
server.quit()

