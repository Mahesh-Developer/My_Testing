
# coding: utf-8

# In[15]:

import pandas as pd
import numpy as np
from py2neo import authenticate, Graph
authenticate("localhost:7474", "neo4j", "server")
import urllib2
import time
from datetime import datetime, timedelta, time
import os
import smtplib
import urllib
import ftplib
import traceback


# In[16]:

#for_csv#htr = pd.read_csv('D:/Data/eta_rank/HTR_1HR_11092015145500.csv')
htr = pd.read_csv('http://10.109.230.50/downloads/IEProjects/STOCKOrigin/StockOrigin.csv')
#paths = pd.read_csv('C:/Data/eta_rank/Path_Final_July15.csv')
#for_csv#paths = pd.read_csv('D:/Python/Scripts and Files/Path and Graph Files/Path.csv')
#graph= Graph("https://Spoton_DB3:dYumk9ZAbxNUIhk9H1Dl@db-3k8xwesdvxtketstpbln.graphenedb.com:24780/db/data/")

ippath1 = r'D:/Python/Scripts and Files/Path and Graph Files/Path_Final_July15.xlsx'
x1 = pd.ExcelFile(ippath1)
paths = x1.parse("Sheet1")

graph= Graph()


# In[17]:

ts = datetime.strptime(htr['TimeStamp'].values[0],'%m/%d/%Y %I:%M:%S %p')
##for_excel#ts = htr.iloc[0]['TimeStamp'].to_pydatetime()
#htr['TimeStamp'].values[0]
htr['DUEDATE'].values[0]

# In[18]:

def sameOrgDest(org1,dest1):
    try:
        if org1==dest1:
            return 'Yes'
        else:
            return 'No'
    except:
        return 'No'
        

#for_csv#htr['HrsAfterArr'] = htr.apply(lambda x: np.ceil((datetime.strptime(x['TIMESTAMP'],'%m/%d/%Y %I:%M:%S %p')-datetime.strptime(x['Arrival Date Hub'],'%m/%d/%Y %I:%M:%S %p')).total_seconds()/3600), axis = 1)
#for_csv#htr['DD'] = htr.apply(lambda x: datetime.strptime(x['Due Date'],'%m/%d/%Y %I:%M:%S %p'), axis = 1)
htr['Same_Org_and_Dest'] = htr.apply(lambda x : sameOrgDest(x['ORGBRCD'], x['DLVBRCD']), axis=1)
htr = htr[htr['Same_Org_and_Dest']=='No']
#htr['HrsAfterArr'] = htr.apply(lambda x: np.ceil((x['TimeStamp'].to_pydatetime()-x['Arrival Date Hub'].to_pydatetime()).total_seconds()/3600), axis = 1)
#htr['DD'] = htr.apply(lambda x: (x['DUEDATE'].to_pydatetime().date()), axis = 1)
htr['DD'] = htr.apply(lambda x: datetime.strptime(x['DUEDATE'],'%d/%m/%Y'), axis = 1)
#htr = htr[(htr['HrsAfterArr']>=1) & (htr['HrsAfterArr']<720)]


# In[19]:

consPivot = htr.pivot_table(index = ['ORGBRCD','DLVBRCD','DD'], values = '\xef\xbb\xbfDOCKNO', aggfunc = 'count').reset_index()
consPivot.sort_values('\xef\xbb\xbfDOCKNO', ascending = False)


# In[20]:

def findeta (currloc,destinationtcr,timestamp):
    
    df3 = paths[(paths['Destination']== destinationtcr) & (paths['Path1'].str.contains(currloc))]
    if df3.empty:
        #print 'no path'
        return 'NA'
    else:
        path_in = df3['Path1'].values[0]
    path_in= str(path_in)
    path_in_list= path_in.split('-')
    #match_loc = [j for j, x in enumerate(path_in_list) if x == currloc]
    #position= match_loc[0]
    #path_in1=path_in_list[(position):]
    path_in1 = path_in_list[path_in_list.index(filter(lambda x: x==currloc,path_in_list)[0]):]

    transittimes=0
    forced_cooling=0
    ##
    curr_date1 = timestamp
    #curr_date1= "2015-03-27 00:00"
    #curr_date1 = datetime.strptime(curr_date1, "%Y-%m-%d %H:%M")
    #curr_time1 = 15.75
    #curr_date1 = curr_date1 + timedelta(hours=curr_time1)
    max_currtdate= curr_date1
    curr_date=max_currtdate.date()
    ct1= max_currtdate.time()
    ct2= str (ct1)
    #print ('curr_date1', curr_date1)
    #print ('ct1, ct2', ct1, ct2)
    #print ('curr_date', curr_date)
    currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60
    currhrs=float(currhrs)/60  #to convert the int only result of a division of python2.7
    #print('currhrs is', currhrs)

    ##
    ignitionstart= currhrs
    ignitiontime=0
    deptimelist=[]
    arrivallist=[]
    remarklist=[]
    for r in range (0, len(path_in1)-1):
        checklist2=[]
        origin = path_in1[r]
        destination = path_in1[r+1]
        #print origin
        #print destination

        q_after=("""MATCH (n:Location{name:{PLO}})-[r]->(m:Location{name:{PLD}})
                WHERE (r.lhtype="LH" or r.lhtype="Market") and r.departtime>={CH}
                RETURN r.departtime, r.code, r.legtt, r.coolingtime, r.arrivaltime""")
        q_before=("""MATCH (n:Location{name:{PLO}})-[s]->(m:Location{name:{PLD}})
                WHERE (s.lhtype="LH" or s.lhtype="Market") and s.departtime<{CH}
                RETURN s.departtime, s.code, s.legtt, s.coolingtime, s.arrivaltime""")
        q_virtual=("""MATCH (n:Location{name:{PLO}})-[r]->(m:Location{name:{PLD}})
                WHERE r.lhtype="Virtual"
                RETURN r.departtime, r.code, r.legtt, r.coolingtime, r.arrivaltime""")

        #print ('check', transittimes)
        after_edges=graph.cypher.execute(q_after, {"PLO":origin, "PLD":destination, "CH":float(currhrs)})
        before_edges=graph.cypher.execute(q_before, {"PLO":origin, "PLD":destination, "CH":float(currhrs)})
        virtual_edges=graph.cypher.execute(q_virtual, {"PLO":origin, "PLD":destination})

        if after_edges:
            #print 'after edges'
            departure=min(after_edges, key=lambda x:x[0])
        elif before_edges:    #print ('checkkk')
            departure=min(before_edges, key=lambda x:x[0])
            #print 'before edges'
        else:
            #print 'in else'
            departure = 'no path'
        #print ('departure is',departure)
        #if after_edges:  #boolean to seperate queries which give null set(result of nodes not present in graph)
        if (after_edges or before_edges):
            #print ('lock')
            departure_time = departure[0]
            lh = departure[1]
            #print('lh is', lh)
            #print (departure[2])
            #print (departure[3])
            transittimes=transittimes+ departure[2]+ departure[3]
            deptimelist.append(departure[0])
            if (departure[4]+departure[3]) > 24:
                currhrs= (departure[4]+departure[3] - 24)
                arrivallist.append(departure[4]+departure[3]-24)
            else:
                currhrs= (departure[4]+departure[3])
                arrivallist.append(departure[4]+departure[3])
                #print ('arrivallist',arrivallist)

        #forced_cooling= 0
            #elif virtual_edges:
        elif virtual_edges:
            departure_time = currhrs
            arrival_time = currhrs
            #print ('virtual is', virtual_edges)
            transittimes=transittimes+ virtual_edges[0][3]
            deptimelist.append(departure_time)
            if (arrival_time+virtual_edges[0][3]) > 24:
                currhrs= (arrival_time+virtual_edges[0][3] - 24)
                arrivallist.append(arrival_time+virtual_edges[0][3]-24)
            else:
                currhrs= (arrival_time+virtual_edges[0][3])
                arrivallist.append(arrival_time+virtual_edges[0][3])

        else:
            eta = 'NA'
            checklist2.append(origin+'-'+destination)
            remarklist.append('No Schedule in THC file')
            #print ('No Schedule in THC file')
            return eta


        if (len(deptimelist)==len(path_in1)-1) and (len(arrivallist)==len(path_in1)-1):
            for u in range (0, len(path_in1)-2):
                if deptimelist[u+1] >= arrivallist[u]:
                    forced_cooling = forced_cooling+deptimelist[u+1]-arrivallist[u]
                    #print('inside1',forced_cooling)
                else:
                    forced_cooling = forced_cooling+deptimelist[u+1]+(24-arrivallist[u])
                    #print('inside2',forced_cooling)
        #print ('deptimelist is',deptimelist)
        #print ('virtual_edges', virtual_edges)
        if (not virtual_edges) & (deptimelist[0]>=ignitionstart):
            ignitiontime= (deptimelist[0]-ignitionstart)
            #print ('ignition if is',ignitiontime)
        elif (not virtual_edges) & (deptimelist[0]<ignitionstart):
            ignitiontime= (24-ignitionstart+deptimelist[0])
            #print ('ignition elif is',ignitiontime)
            #print ('ignition',ignitiontime)
    finaltt=transittimes+forced_cooling+ignitiontime
    ##totaldays=finaltt//24
    ##remainhrs=finaltt%24
    if remarklist:    #if-else statement only to exit loop when there is a remark of no schedule
        #break
        eta = 'NA'
        return eta


    else:
        finalscarrival = max_currtdate+timedelta(hours=finaltt)
        at1 = finalscarrival.time()
        at2= str (at1)

        finalhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(at2.split(":")))))/60
        finalhrs=float(finalhrs)/60  #to convert the int only result of a division of python2.7

        if finalhrs <= 16:
            eta = finalscarrival.date()
        else:
            eta = (finalscarrival+timedelta(days=1)).date()
    print eta
    return eta


# In[ ]:

def actionhours(currloc, destinationtcr, timestamp):
    eta1 = findeta(currloc, destinationtcr, timestamp)
    print eta1, type(eta1)
    if eta1 != 'NA':
        etafuture = eta1
        timestampnew = timestamp
        timestampnewtwelve = (timestamp + timedelta(hours= 4))
        etafuturetwelve = findeta (currloc, destinationtcr, timestampnewtwelve)
        if etafuturetwelve <= eta1:
            hoursforaction = 4
            return hoursforaction
            
        #including 4 hrs check first to increase speed 19-June-15
        
        while etafuture <= eta1 and timestampnew <= (timestamp + timedelta(hours=4)):
            addtime = 1
            timestampnew = timestampnew + timedelta(hours=addtime)
            etafuture = findeta (currloc, destinationtcr, timestampnew)
            if etafuture > eta1:
                diff = timestampnew - timestamp
                diff_str = str(diff)
                hoursforaction = (sum(float(x) * 60 ** i for i,x in enumerate(reversed(diff_str.split(":")))))/60
                hoursforaction = float(hoursforaction)/60
                if hoursforaction - 1 == 0:
                    return hoursforaction
                else:
                    hoursforaction = hoursforaction - 1
                    return hoursforaction
                break


        else:
            hoursforaction = 4
            return hoursforaction
            
            
        
    else:
        print 'not inside'
        hoursforaction = 'NA'
        return hoursforaction
    


# In[ ]:

consPivot['ETA'] = consPivot.apply(lambda x: findeta(x['ORGBRCD'],x['DLVBRCD'],ts), axis = 1)
#consPivot = consPivot.head() 
consPivot['ActionHrs'] = consPivot.apply(lambda x: actionhours(x['ORGBRCD'],x['DLVBRCD'],ts), axis = 1)
#consPivot = consPivot[['Hub SC Location','Destn Branch','DD']]


# In[ ]:

joinlist = ['ORGBRCD','DLVBRCD','DD']
newhtr = pd.merge(htr, consPivot, left_on = joinlist, right_on = joinlist, how = 'inner')


newhtr = newhtr[(newhtr['ETA']!='NA')]
newhtr['DD_py'] = newhtr.apply(lambda x: (x['DD']).to_pydatetime().date(), axis = 1)
newhtr['Delaydays'] = newhtr.apply(lambda x: (x['ETA']-x['DD_py']).days, axis = 1)
newhtr = newhtr[(newhtr['Delaydays']>=0) & (newhtr['Delaydays']<100)]
newhtr['Score'] = newhtr.apply(lambda x: (((5-x['ActionHrs'])*1000000)+(x['Delaydays']*100)), axis = 1)

newhtr['Rank'] = newhtr['Score'].rank(ascending=0, method='min')
#finalhtr = newhtr[['Con Number_x', 'Hub SC Location', 'DD_py', 'ETA', 'ActionHrs', 'Delaydays', 'Score', 'Rank', 'TIMESTAMP']]
print 'program ran'
opfilevar=ts.date()
opfilevar1=ts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=np.ceil(float(currhrs)/60)

print 'opfilevar,opfilevar2',opfilevar,opfilevar2
newhtr.to_csv('D:/Data/eta_rank/origin_eta_folder_rankfiles/Orign_ETA_OP'+'-'+str(opfilevar)+'-'+str(opfilevar2)+'.csv', encoding="utf-8")
print 'Done!!!!!'

# In[ ]:
to = 'rajeesh.vr@spoton.co.in'
gmail_user = 'spoton.net.in'
gmail_pwd = 'Star@123#'
smtpserver = smtplib.SMTP('smtp.sendgrid.net', 587)
smtpserver.ehlo()
smtpserver.starttls()
smtpserver.ehlo
smtpserver.login(gmail_user, gmail_pwd)
header = 'To:' + to + '\n' + 'From: ' + gmail_user + '\n' + 'Subject:ETA Rank File generated'+'-'+str(opfilevar)+'-'+str(opfilevar2)+ '\n'
print header
msg = header + '\n ETA Rank file generated \n\n'
smtpserver.sendmail(gmail_user, to, msg)
print 'Email has been sent!!'
smtpserver.close()



# In[ ]:




# In[ ]:



