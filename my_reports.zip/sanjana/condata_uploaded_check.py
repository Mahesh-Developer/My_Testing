
# coding: utf-8

# In[ ]:

import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from datetime import datetime, timedelta, date
import os
import ftplib
import traceback
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template


# In[ ]:

startdate=datetime.strftime(datetime.now()-timedelta(1),'%Y-%m-%d')+' 00:00:00'
startdate


# In[ ]:

startdate="'"+startdate+"'"
startdate


# In[ ]:

enddate=datetime.strftime(datetime.now()-timedelta(1),'%Y-%m-%d')+' 23:59:59'
enddate="'"+enddate+"'"
enddate


# In[ ]:

cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=PYTHON_DB;UID=PythonOnline;PWD=P@ssw0rd123$")


# In[ ]:

condata = pd.read_sql("SELECT * FROM condata WHERE Pickupdate >= {0} AND Pickupdate < {1}".format(startdate,enddate),cnxn)


# In[ ]:

len(condata)


# In[ ]:

if len(condata)>=2000:
    pass
else:
    #vishwas.j@spoton.co.in
    FROM='vishwas.j@spoton.co.in'
    TO=['mahesh.reddy@spoton.co.in']
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["Subject"] = "Condata Data Not Uploaded"
    html='''<html>
    <h4>Hi,</h4>
    <p></p>
    </html>'''
    report=""
    report+='<br>'
    report+='The Condata Data Uploaded Count is ='+str(len(condata))
    report+='<br>'
    report+='<br>'
    report+='There was error in Uploading Condata Data Betwen :'+str(startdate)+' - '+str(enddate)
    report+='<br>'
    abc=MIMEText(report,'html')
    msg.attach(abc)

    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO, msg.as_string())
    server.quit()


# In[ ]:



