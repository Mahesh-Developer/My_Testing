
# coding: utf-8

# <b> Importing Libraries </b>

# In[37]:

import pandas as pd
import networkx as nx
from pandas import ExcelWriter
from datetime import datetime, timedelta, time
from py2neo import authenticate, Graph
authenticate("localhost:7474", "neo4j", "server")
#authenticate("localhost:7474", "neo4j", "IE")


# <b> Printing Function </b>

# In[38]:

def save_xls(list_dfs, name_dfs, xls_path):
   i = 0
   writer = ExcelWriter(xls_path)
   for dataframe in list_dfs:
       sheetname = name_dfs[i]
       dataframe.to_excel(writer, sheetname, merge_cells = False)
       i = i+1
   writer.save()


# <b> Input and Output File path definition </b>

# In[39]:


#ippath2 = 'D:/Python/Scripts and Files/Path and Graph Files/THCLocationv2.xlsx'
#ippath3 = 'D:/Python/Scripts and Files/Path and Graph Files/TransitFile_New.xlsx'
#ippath4 = 'D:/Python/Scripts and Files/Path and Graph Files/Hublist.xlsx'
#oppath1 = 'D:/Python/Scripts and Files/Path and Graph Files/OP25.xlsx'

ippath2 = 'D:\Python\Scripts and Files\Path and Graph Files\New_timegraph_files\THCLocationv2_June17.xlsx'
ippath3 = 'D:\Python\Scripts and Files\Path and Graph Files\New_timegraph_files\Latest routes_June17.xlsx'
ippath4 = 'D:\Python\Scripts and Files\Path and Graph Files\New_timegraph_files\Hublist.xlsx'
oppath1 = 'D:\Python\Scripts and Files\Path and Graph Files\New_timegraph_files\OP25.xlsx'

#ippath1 = 'C:/Users/Ruchira Banerjee/Dropbox/Scripts/ETA/Input/Path.xlsx'
#ippath2 = 'C:/Users/Ruchira Banerjee/Dropbox/Scripts/ETA/Input/THCSchedule1.xlsx'
#ippath3 = 'C:/Users/Ruchira Banerjee/Dropbox/Scripts/ETA/Input/TransitFile.xlsx'
#ippath4 = 'C:/Users/Ruchira Banerjee/Dropbox/Scripts/ETA/Input/Hublist.xlsx'
#oppath1 = 'C:/Users/Ruchira Banerjee/Dropbox/Scripts/ETA/Input/OP.xlsx'
#oppath2 = 'C:/Users/Ruchira Banerjee/Dropbox/Scripts/ETA/Input/OP2.xlsx'


# <b> Global Variable Definition </b>

# In[40]:

###variable definitions
#hubprocessingtime = 3
#scprocessingtime = 2

hubprocessingtime = 1
scprocessingtime = 1


# <b> Loading Dataframes to create linehaul time master and schedule graph</b>

# In[41]:

###main program
x2 = pd.ExcelFile(ippath2)
thcschedule = x2.parse("Base Data")
#thcschedule =thcschedule[thcschedule['Route Code']=='D1272']
x3 = pd.ExcelFile(ippath3)
transit = x3.parse("Schedule")
market= x3.parse("Market")
#transit = transit[transit['Route Code']=='D1272']
x4 = pd.ExcelFile(ippath4)
hubdf = x4.parse("Sheet1")
#print (hubdf)


# <b> Setting up the graph </b>

# In[42]:

### graph setup
G= nx.MultiDiGraph()
H = nx.MultiDiGraph()
I = nx.MultiDiGraph()
#H_graph= Graph("http://Spoton_data:iodV6JBholNR0Z3hbAAu@spotondata.sb02.stations.graphenedb.com:24789/db/data/")
#graph= Graph("http://Spoton_data:iodV6JBholNR0Z3hbAAu@spotondata.sb02.stations.graphenedb.com:24789/db/data/")

H_graph= Graph()
graph= Graph()


# <b> Setting up graph from THCSchedule (G graph) </b>

# In[43]:

### THCSchedule edge set up
for i in range (0,len(thcschedule)):
    origin = thcschedule.iloc[i]['Origin']
    destination = thcschedule.iloc[i]['Destination']
    routecode = thcschedule.iloc[i]['Route Code']
    lhorigin= thcschedule.iloc[i]['LHO']
    lhdest= thcschedule.iloc[i]['LHD']
    G.add_edge(origin,destination,weight=1, g_routecd = routecode, departTime= 0, departDay= 1, arrivalTime= 4, arrivalDay= 1, g_lhorigin=lhorigin, g_lhdest=lhdest)
g_edge= [(u,v,d) for (u,v,d) in G.edges(data=True)]
print (len(g_edge))


# <b> Setting up hublists and lhcodelists </b>

# In[44]:

hublist= hubdf['BRANCH CODE'].tolist()
lhcodelist= transit['Route Code'].unique().tolist()
#print(lhcodelist)


# <b> Setting up graph from TransitFile (H Graph)</b>

# In[45]:

### TransitFile edge set up

for i in range (0,len(transit)):
    origin = transit.iloc[i]['Origin']
    destination = transit.iloc[i]['Destination']
    routecode = transit.iloc[i]['Route Code']
    departT = transit.iloc[i]['Dep time']
    departD = transit.iloc[i]['Departure Day']
    arrivalT= transit.iloc[i]['Arr time']
    arrivalD= transit.iloc[i]['Arrival day']
    lhorigin= transit.iloc[i]['LHO']
    lhdest= transit.iloc[i]['LHD']
    coolTime= 1
    if (destination == lhdest)&(destination in hublist):
        coolTime = hubprocessingtime
    elif (destination == lhdest)&(destination not in hublist):
        coolTime = scprocessingtime
    H.add_edge(origin,destination,lhtype = 'LH', weight=((arrivalD-departD)*24-departT+arrivalT), coolingTime=coolTime, h_routecd = routecode, departTime= departT, departDay= departD, arrivalTime= arrivalT, arrivalDay= arrivalD, h_lhorigin=lhorigin, h_lhdest=lhdest)

# <b> Inserting/Adding virtual branches as edges of H graph </b>

# In[46]:

### virtual movement setup
print (len(hubdf))
for i in range (0,len(hubdf)):
    origin = hubdf.iloc[i]['VB']
    destination = hubdf.iloc[i]['BRANCH CODE']
    H.add_edge(origin,destination,lhtype = 'Virtual', weight=0, coolingTime=0, h_routecd = 'V100'+str(i), departTime= 20, departDay= 1, arrivalTime= 23, arrivalDay= 1, h_lhorigin=origin, h_lhdest=destination)
    H.add_edge(destination,origin,lhtype = 'Virtual', weight=0, coolingTime=0, h_routecd = 'V200'+str(i), departTime= 20, departDay= 1, arrivalTime= 23, arrivalDay= 1, h_lhorigin=origin, h_lhdest=destination)
#k_edge= [(u,v,d) for (u,v,d) in K.edges(data=True)]
#print (k_edge)
#print (len(k_edge))


# <b> Inserting Market movements </b>

# In[47]:

print (len(market))
for i in range (0,len(market)):
    origin = market.iloc[i]['Origin']
    destination = market.iloc[i]['Destination']
    #routecode = transit.iloc[i]['Route Code']
    departT = market.iloc[i]['Dep time']
    departD = market.iloc[i]['Departure Day']
    arrivalT= market.iloc[i]['Arr time']
    arrivalD= market.iloc[i]['Arrival day']
    lhorigin= market.iloc[i]['LHO']
    lhdest= market.iloc[i]['LHD']
    coolTime= 1
    if (destination == lhdest)&(destination in hublist):
        coolTime = hubprocessingtime
    elif (destination == lhdest)&(destination not in hublist):
        coolTime = scprocessingtime
    H.add_edge(origin,destination,lhtype = 'Market', weight=((arrivalD-departD)*24-departT+arrivalT), coolingTime=coolTime, h_routecd = 'M100'+str(i), departTime= departT, departDay= departD, arrivalTime= arrivalT, arrivalDay= arrivalD, h_lhorigin=lhorigin, h_lhdest=lhdest)

#k_edge= [(u,v,d) for (u,v,d) in K.edges(data=True)]
#print (k_edge)
#print (len(k_edge))


# <b>Adding days/time to THCSchedule graph from TransitFile graph </b>

# In[48]:

### scheduled vehcile setup
for n_edges in g_edge:
    org=n_edges[0]
    dest=n_edges[1]
    print org, dest
    lhcode=n_edges[2]['g_routecd']
    h_edge= [(u,v,d) for (u,v,d) in H.edges(data=True) if ((u==org) & (v==dest) & (d['h_routecd']==lhcode))]

    if h_edge:
        a=0
    else:
        dep_data= [(u,v,d) for (u,v,d) in H.edges(data=True) if ((u==org)&(d['h_routecd']==lhcode))]
        arr_data= [(u,v,d) for (u,v,d) in H.edges(data=True) if ((v==dest)&(d['h_routecd']==lhcode))]
        if dep_data:
            dep_day= dep_data[0][2]['departDay']
            dep_time= dep_data[0][2]['departTime']
            lhorigin1= dep_data[0][2]['h_lhorigin']
            lhdest1= dep_data[0][2]['h_lhdest']
        else:
            dep_day='check'
            dep_time='check'
            lhorigin1= 'check'
            lhdest1= 'check'
        if arr_data:
            arr_day= arr_data[0][2]['arrivalDay']
            arr_time= arr_data[0][2]['arrivalTime']
            lhorigin1= dep_data[0][2]['h_lhorigin']
            lhdest1= dep_data[0][2]['h_lhdest']
        else:
            arr_time='check'
            arr_day='check'
            lhorigin1= 'check'
            lhdest1= 'check'
        print org,dep_time,'->',dest,arr_time
        H.add_edge(org, dest, lhtype = 'LH',weight=((arr_day-dep_day)*24-dep_time+arr_time), coolingTime=coolTime, h_routecd = lhcode, departTime= dep_time, departDay= dep_day, arrivalTime= arr_time, arrivalDay= arr_day, h_lhorigin=lhorigin1, h_lhdest=lhdest1)
print (len(G.edges()))
print (len(H.edges()))
#nx.draw_networkx(H)


# <b> Adding Cooling Time to H graph </b>

# In[49]:

for p in range (0, len(lhcodelist)):
    c_edge= [(u,v,d) for (u,v,d) in H.edges(data=True) if (d['h_routecd']==lhcodelist[p])]
    #print ('length is',len(c_edge))
    for q in range (0,len(c_edge)):
        c_origin= c_edge[q]
        c_dest= c_edge[q][1]
        #print ('c_dest is', c_dest)
        d_edge= [(u,v,d) for (u,v,d) in H.edges(data=True) if ((u==c_dest)&(d['h_routecd']==lhcodelist[p]))]
        #print ('d_edge is', d_edge)
        if (d_edge):
            c_edge[q][2]['coolingTime']= (d_edge[0][2]['departDay']-c_edge[q][2]['arrivalDay'])*24+d_edge[0][2]['departTime']-c_edge[q][2]['arrivalTime']

        #print ('c_edge is', c_edge)


# <b> Origin error printing </b>

# In[50]:

origin_error = [(u,v,d) for (u,v,d) in H.edges(data=True) if (d['departTime']=='check')]
print (origin_error)


# <b> Destination error printing </b>

# In[51]:

dest_error = [(u,v,d) for (u,v,d) in H.edges(data=True) if (d['arrivalTime']=='check')]
print (dest_error)


# <b> Checking node count and degrees of both graphs </b>

# In[52]:

gnodes =(G.nodes())
hnodes =(H.nodes())
print (len(gnodes))
print (len(hnodes))
g_edges = G.degree(gnodes)
#print (g_edges)
h_edges = H.degree(hnodes)
#print (h_edges)


# <b> Genrating output dataframe from edge and saving to Neo4j </b>

# In[53]:

h_edge= [(u,v,d) for (u,v,d) in H.edges(data=True)]

#add cyphr code to delete the entire graph
querydelete=('MATCH (n)OPTIONAL MATCH (n)-[r]-()DELETE n, r')
graph.cypher.execute(querydelete)
tx_H= H_graph.cypher.begin()
print (len(H.edges()))
for k in range(0,len(H.edges())):
    #for (u,v,d) in h_edge:
    org = h_edge[k][0]
    dest = h_edge[k][1]
    routecode = h_edge[k][2]['h_routecd']
    lhtype= h_edge[k][2]['lhtype']
    legTT = h_edge[k][2]['weight']
    coolingtime = h_edge[k][2]['coolingTime']
    departtime = h_edge[k][2]['departTime']
    departday = h_edge[k][2]['departDay']
    arrivaltime = h_edge[k][2]['arrivalTime']
    arrivalday = h_edge[k][2]['arrivalDay']
    lhorigin = h_edge[k][2]['h_lhorigin']
    lhdest = h_edge[k][2]['h_lhdest']

    #totallegTT = h_edge[k][2]['weight']+h_edge[k][2]['coolingTime']
    query1= ("""MERGE (a:Location{name:{N}, Type:'Spoton Location'})
            ON CREATE SET a.Location={N}, a.Type='Spoton Location'
            RETURN a""")
    tx_H.append(query1, {"N":str(org)})
    tx_H.append(query1, {"N":str(dest)})
    query2= ("""MATCH (a:Location{name:{O}, Type:'Spoton Location'}),
            (b:Location{name:{D}, Type:'Spoton Location'})
            WHERE a:Location and b:Location
            CREATE (a) -[rn:connects]-> (b)
            SET rn.code={CODE}, rn.lhtype={LHT}, rn.legtt={TT}, rn.coolingtime={CT},
            rn.departtime={DT}, rn.departday={DD}, rn.arrivaltime={AT}, rn.arrivalday={AD},
            rn.lhorigin={LHO}, rn.lhdest={LHD}
            RETURN a,b,rn""")
    tx_H.append(query2, {"O":org, "D":dest, "CODE":routecode, "LHT":lhtype, "TT":float(legTT), "CT":float(coolingtime), "DT":float(departtime), "DD":float(departday), "AT":float(arrivaltime), "AD":float(arrivalday), "LHO":lhorigin, "LHD":lhdest})

    query_vehicle= ("""MERGE (a:Location{name:{CODE}, origin:{O}, destination:{D}})
            ON CREATE SET a.Location={CODE}, a.origin={O}, a.destination={D},
            a.lhtype={LHT}, a.legtt={TT}, a.coolingtime={CT},
            a.departtime={DT}, a.departday={DD}, a.arrivaltime={AT}, a.arrivalday={AD},
            a.lhorigin={LHO}, a.lhdest={LHD}, a.Type='Linehaul'
            RETURN a""")

    tx_H.append(query_vehicle, {"O":org, "D":dest, "CODE":routecode, "LHT":lhtype, "TT":float(legTT), "CT":float(coolingtime), "DT":float(departtime), "DD":float(departday), "AT":float(arrivaltime), "AD":float(arrivalday), "LHO":lhorigin, "LHD":lhdest})

    tx_H.process()

statuslist = ['DEPS', 'DESTINATION FAILURE', 'HUB FAILURE', 'LINEHAUL FAILURE', 'NON CONTROLLABLE FAILURE', 'ORIGIN FAILURE', 'RECEIVER FAILURE', 'SENDER FAILURE']
for j in range (0, len(statuslist)):
    query_status= ("""MERGE (a:Status{name:{S}})
            ON CREATE SET a.Status={S}
            RETURN a""")
    tx_H.append(query_status, {"S":statuslist[j]})
    tx_H.process()

tx_H.commit()


# In[54]:

#for line in nx.generate_edgelist(H):
    #print(line)
columnsop= ['Route Code', 'Origin', 'Destination', 'Departure Time', 'Departure Date', 'Arrival Time', 'Arrival Day', 'TT']
#print ('columnsop is', columnsop)
dfop= pd.DataFrame(columns=columnsop)
h_edge= [(u,v,d) for (u,v,d) in H.edges(data=True)]
for k in range(0,len(H.edges())):
    #for (u,v,d) in h_edge:
    dfop.loc[k,'Origin'] = h_edge[k][0]
    dfop.loc[k, 'Destination'] = h_edge[k][1]
    dfop.loc[k,'Route Code'] = h_edge[k][2]['h_routecd']
    dfop.loc[k,'Departure Time'] = h_edge[k][2]['departTime']
    dfop.loc[k,'Departure Date'] = h_edge[k][2]['departDay']
    dfop.loc[k,'Arrival Time'] = h_edge[k][2]['arrivalTime']
    dfop.loc[k,'Arrival Day'] = h_edge[k][2]['arrivalDay']
    dfop.loc[k,'Leg TT'] = h_edge[k][2]['weight']
    dfop.loc[k,'LH Origin'] = h_edge[k][2]['h_lhorigin']
    dfop.loc[k,'LH Dest'] = h_edge[k][2]['h_lhdest']
    dfop.loc[k,'Cooling Time'] = h_edge[k][2]['coolingTime']
    dfop.loc[k,'Total leg TT'] = h_edge[k][2]['weight']+h_edge[k][2]['coolingTime']
#print (dfop)
printlist =  [dfop]
namelist = ['Sheet1']
save_xls (printlist, namelist, oppath1)
print 'done success'

# In[54]:




# In[54]:



