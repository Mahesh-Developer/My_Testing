# -*- coding: utf-8 -*-
"""
Created on Fri Oct 21 14:39:03 2016

@author: rajeeshv
"""

import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
import datetime
import os
import Utilities

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


query = ("""
        EXEC dbo.USP_DUEDATE_DATA_SQ_IE
        """)

dudedateconsdf = pd.read_sql(query, Utilities.cnxn)
print len(dudedateconsdf)