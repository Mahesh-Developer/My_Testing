
# coding: utf-8

# In[ ]:

# In[181]:

import pandas as pd
import networkx as nx
import numpy as np
from pandas import ExcelWriter
from datetime import datetime, timedelta, time
from py2neo import Graph
import datetime
from pandas import pivot_table

from pandas import pivot_table
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import os


# In[2]:

def save_xls(list_dfs, name_dfs, xls_path):
   i = 0
   writer = ExcelWriter(xls_path)
   for dataframe in list_dfs:
       sheetname = name_dfs[i]
       dataframe.to_excel(writer, sheetname, merge_cells = True)
       i = i+1
   writer.save()


# In[3]:

ippath1 = r'D:/Python/Scripts and Files/Path and Graph Files/Path_Final_July15.xlsx'
#ippath1 = r'C:/Users/s1738raj/Desktop/LoadAvailableGlob/Path_Final_July15.xlsx'


oppath2 = r'D:/Python/Scripts and Files/Path and Graph Files/Load_available_report.xlsx'
#oppath2 = r'C:/Users/s1738raj/Desktop/LoadAvailableGlob/Load_available_report.xlsx'


# In[184]:

hubprocessingtime = 3
scprocessingtime = 2


# In[185]:

x1 = pd.ExcelFile(ippath1)
paths = x1.parse("Sheet1")

#ippath2 = r'C:\Data\ETA\10032016_ETA_modification\HTR_1HR.xls'
#xl2 = pd.ExcelFile(ippath2)
#tcrdata = xl2.parse('HUB_THROUGHPUT_ONEHOUR')

sccategoryfile = pd.read_csv(r'D:/Python/Scripts and Files/Path and Graph Files/SC_category.csv')
#sccategoryfile = pd.read_csv(r'C:/Users/s1738raj/Desktop/LoadAvailableGlob/SC_category.csv')
sccategoryfile = sccategoryfile.drop(['Name','Cat','Area'],axis=1)

tcrdata = pd.io.excel.read_excel('http://10.109.230.50/downloads/HTR_1HR/HTR_1HR.xls','HUB_THROUGHPUT_ONEHOUR')

# Merge for SC Category in HTR file
tcrdatasccat = pd.merge(tcrdata,sccategoryfile,left_on=['Destn Branch'],right_on=['SC'],how='left')
tcrdata = tcrdatasccat
# Merge for SC Category in HTR file

#criticallanes = pd.read_csv(r'C:/Users/s1738raj/Desktop/LoadAvailableGlob/Critical_lanes_loadavaliable.csv')
criticallanes = pd.read_csv(r'D:/Python/Scripts and Files/Path and Graph Files/Critical_lanes_loadavaliable.csv')


# In[4]:

criticallaneslist = criticallanes['Lanes'].tolist()


# In[5]:

def findeta (connumber, origintcr, destinationtcr, currloc, arrivaltimetcr, timestamp):
    #duedate1=duedate.to_pydatetime()
    df3= paths[(paths['Destination']== destinationtcr) & (paths['Path1'].str.contains(currloc))]
    if df3.empty:
        nextloc = 'NA'
        #print eta
        return nextloc

    else:
        pathlist1 = df3['Path1'].tolist()
    path_in= pathlist1[0]
    #print ('path_in1 is a',path_in)
    path_in= str(path_in)
    path_in_list= path_in.split('-')
    #print ('path_in_list is',path_in_list)

    if currloc in path_in_list:
        match_loc = [j for j, x in enumerate(path_in_list) if x == currloc]
        #print ('matching', match_loc)
        position= match_loc[0]
        #print ('post is', position)
        nextloc = path_in_list[position+1]
    else:
        nextloc = 'NA'
        return nextloc

    path_in1=path_in_list[(position):]
    #print ('path_in1 is',path_in1)

    return nextloc


# In[6]:

# <b> Main ETA Finding </b>

# In[ ]:

#depspaperworkcodelist = ['SRE','SRD','SRS','SRP','DLP','SWP','PWS','HCM','HPM','MOP','SRH','HOC','ONR','SPH','SPO','DBO','DIP','SHS','SSC','HIP']
depspaperworkcodelist = ['SRE','SRD','SRS','SRP','DLP','SWP','PWS','HCM','HPM','MOP','SRH','HOC','ONR','SPH','SPO','DBO','DIP','SHS','SSC','HIP','RNX','APT','APN','SHD','SMT','SPL','MSH','UCG','RRA','HPE','WIA','UG1','UG2','UG3','HMP','HWC','NPE','HIM']
#corehublist = ['AMCH','AMDH','BLRH','BOMH','BRGH','CCUH','DELH','HYDH','MAAH','NAGH','PNQH','VPIH','VZAH','SXVF']
corehublist = ['AMDH','BLRH','BOMH','DELH','HYDH','MAAH','NAGH','PNQH','CCUH','BRGH']
#corehublist = ['BOMH','DELH','MAAH','NAGH','BRGH','CCUH','AMCH']
tcrconlist_inv= tcrdata['Con Number'].tolist()
print 'the inventory list has', len(tcrconlist_inv)

for m in range (0, len(tcrconlist_inv)):
    connumber = tcrdata.iloc[m]['Con Number']
    origintcr = tcrdata.iloc[m]['Origin Branch']
    destinationtcr = tcrdata.iloc[m]['Destn Branch']
    currloc = tcrdata.iloc[m]['Hub SC Location']
    arrivaltimetcr = tcrdata.iloc[m]['Arrival Date Hub']
    #weights = tcrdata.iloc[m]['Act Wt In Tonnes']
    statuscodes = tcrdata.iloc[m]['Latest Status Code']
    reportts = tcrdata.iloc[m]['TIMESTAMP']
    timestamp= reportts.to_pydatetime()
    duedate = tcrdata.iloc[m]['Due Date']
    duedate1 = duedate.to_pydatetime()
    duedate2=duedate1.date()

    #print connumber
    if arrivaltimetcr.to_pydatetime() < (timestamp - timedelta(days=30)):
        #print connumber, 'Old Con'
        tcrdata.loc[m,'Observation'] = 'Old Con'
    elif statuscodes in depspaperworkcodelist:
        tcrdata.loc[m,'Observation'] = 'DEPS/Paperworks'
        #print connumber, 'DEPS/Paperworks'
    else:
        tcrdata.loc[m,'Observation'] = 'Correct'
        #print connumber, 'Correct'

    if currloc in corehublist:
        tcrdata.loc[m,'Hub'] = 'Main Hub'
    else:
        tcrdata.loc[m,'Hub'] = 'Sec Hub'

    nextloc = findeta (connumber, origintcr, destinationtcr, currloc, arrivaltimetcr, timestamp)
    tcrdata.loc[m,'Next Loc'] = nextloc
    #print type(eta), eta
    tcrdata.loc[m,'CurrLoc - Next Loc'] = "-".join((currloc, nextloc))


# In[7]:

tcrdataclean = tcrdata[tcrdata['Observation']=='Correct']

tcrdataclean = tcrdataclean[tcrdataclean['Next Loc']!='NA']       #For Excluding cons with no paths


# In[8]:

tcrdatacleangrp = tcrdataclean.groupby(['CurrLoc - Next Loc']).agg({'Con Number':len,'Act Wt In Tonnes':sum}).reset_index()
tcrdatacleangrp = tcrdatacleangrp.sort_values('Act Wt In Tonnes',ascending=False)

##$$tcrdatacleangrp = tcrdatacleangrp[tcrdatacleangrp['CurrLoc - Next Loc'].isin(criticallaneslist)]
tcrdatacleangrpmerge = pd.merge(tcrdatacleangrp,criticallanes,left_on=['CurrLoc - Next Loc'],right_on=['Lanes'],how='inner')
tcrdatacleangrpmerge = tcrdatacleangrpmerge.drop(['Lanes'], axis=1)


tcrdatacleangrpmainloc = tcrdataclean[tcrdataclean['Category']=='A']
#to fix overlap of main loc of AMCH over DELH main loc 27-June-2016
tcr_AMCH1 = tcrdataclean[tcrdataclean['Next Loc']=='AMCH']
tcr_AMCH = tcr_AMCH1[tcr_AMCH1['AMCH Category']=='A']
tcrdatacleangrpmainloc = tcrdatacleangrpmainloc.append(tcr_AMCH)
#to fix overlap of main loc of AMCH over DELH main loc 27-June-2016
tcrdatacleangrpmainloc = tcrdatacleangrpmainloc.groupby(['CurrLoc - Next Loc']).agg({'Con Number':len,'Act Wt In Tonnes':sum}).reset_index()
tcrdatacleangrpmainlocmerge = pd.merge(tcrdatacleangrpmerge,tcrdatacleangrpmainloc,left_on=['CurrLoc - Next Loc'],right_on=['CurrLoc - Next Loc'],suffixes =['_Total','_Mainloc'] ,how='left')

tcrdatacleangrpmainlocmerge =tcrdatacleangrpmainlocmerge.rename(columns={'CurrLoc - Next Loc':'Lanes','Con Number_Total':'Cons_total','Act Wt In Tonnes_Total':'WT_total(T)','Con Number_Mainloc':'Cons_MainLoc','Act Wt In Tonnes_Mainloc':'WT_MainLoc(T)'})
tcrdatacleangrpmainlocmerge = tcrdatacleangrpmainlocmerge.fillna(0)

tcrdatacleangrpmainlocmerge['WT_total']= np.round(tcrdatacleangrpmainlocmerge.apply(lambda x: (x['WT_total(T)']*1000), axis=1),0)
tcrdatacleangrpmainlocmerge['WT_MainLoc']= np.round(tcrdatacleangrpmainlocmerge.apply(lambda x: (x['WT_MainLoc(T)']*1000), axis=1),0)


columnsop=['Lanes','Cons_total','WT_total','Cons_MainLoc','WT_MainLoc','Veh_dep_time']
tcrdatacleangrpmainlocmerge = pd.DataFrame(tcrdatacleangrpmainlocmerge,columns=columnsop)


# In[1]:

# In[10]:

opfilevar=reportts.date()
opfilevar1=reportts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=np.round((float(currhrs)/60),0)

# In[9]:


# In[2]:

#creating a seperate df for storing to be used for glob
summarydf = tcrdatacleangrpmainlocmerge.copy(deep=True)
summarydf.loc[summarydf.index,'TIMESTAMP'] = reportts
summarydf.to_csv(r'D:/Data/LoadAvailableGlob/LoadAvailable_Storage/LoadAvail_ForGlob'+str(opfilevar)+'-'+str(opfilevar2)+'.csv', encoding="utf-8")


# In[3]:

#sume = summarydf.copy(deep=True)
#sume.head(5)


# In[19]:

print reportts


# In[4]:

import glob
globpath =r'D:/Data/LoadAvailableGlob/LoadAvailable_Storage' # use your path
allFiles = glob.glob(globpath + "/*.csv")
frame = pd.DataFrame()
list_ = []
for file_ in allFiles:
    df = pd.read_csv(file_,index_col=None, header=0)
    list_.append(df)
frame = pd.concat(list_)
frame.to_csv(r'D:/Data/LoadAvailableGlob/LA_Globfile.csv')
print 'glob done'

# In[5]:

# In[2]:

globfile = pd.read_csv(r'D:/Data/LoadAvailableGlob/LA_Globfile.csv')


# In[23]:

#for filtering and keeping only last 12 hrs files (6 files)
endtime = datetime.datetime.now() - timedelta(hours=13)


globfile['Timestamp'] = globfile['TIMESTAMP'].apply(lambda x: datetime.datetime.strptime(x.split('.')[0],'%Y-%m-%d %H:%M:%S'))

globfile = globfile[globfile['Timestamp']>endtime]


# In[30]:

#trend_df = globfile.groupby(['Lanes','Veh_dep_time','Timestamp']).agg({'WT_total':sum}).reset_index()


# In[27]:


trend_df=pivot_table(globfile,index=['Lanes', 'Veh_dep_time'],columns=['Timestamp'],values=['WT_total'],aggfunc='sum').reset_index()


# In[9]:

##help##printlist =  [tcrdatacleangrpmainlocmerge,trend_df,tcrdata]
##help##namelist = ['Summary','Trend','Data']
##help##save_xls (printlist, namelist, oppath2)
trend_df.to_csv(r'D:/Python/Scripts and Files/Path and Graph Files/Load_available_trend.csv')
oppath3_forcsv = r'D:/Python/Scripts and Files/Path and Graph Files/Load_available_trend.csv'
print 'saving done'

tcrdatacleangrpmainlocmerge = tcrdatacleangrpmainlocmerge.to_string(index=False)


# In[11]:

filePath = oppath3_forcsv
def sendEmail(#TO = ["cnm@spoton.co.in","raghavendra.rao@spoton.co.in","HUBMGR_SPOT@spoton.co.in"],
            TO = ["sqtf@spoton.co.in"],
            #TO = ["vishwas.j@spoton.co.in"],
            #CC = ["vishwas.j@spoton.co.in"],
            #CC = ["pawan.sharma@spoton.co.in", "nikhil.saxena@spoton.co.in","jothi.menon@spoton.co.in"],
            #CC = ["supratim@iepfunds.com","pawan.sharma@spoton.co.in","Ankit@iepfunds.com","sqtf@spoton.co.in","shivananda.p@spoton.co.in","prasanna.hegde@spoton.co.in","rajeesh.vr@spoton.co.in","vishwas.j@spoton.co.in"],
            BCC = ["mahesh.reddy@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "Load Available for movement @ "+ str(opfilevar)+"-"+str(opfilevar2)
    msg["Subject"] = "Load Available-Trend @ "+ str(opfilevar)+"-"+str(opfilevar2)
    body_text = """
    Dear All,
    
    PFA the trend of load available for the critical lanes @ """ +str(opfilevar)+"-"+str(opfilevar2)+"""

    
    
    """
    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+BCC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends


# In[ ]:

##tcrdata.to_csv(r'D:\Data\Load_available_archives\Load_available_report_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv')


# In[ ]:



