
# coding: utf-8

# In[ ]:


import pandas as pd
import pyodbc
from datetime import datetime,timedelta
import os


# In[ ]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()


# In[ ]:


startdate=datetime.strftime(datetime.now(),'%Y-%m-%d')
startdate


# In[ ]:


query=("EXEC USP_Retail_Undel_SQ")
query


# In[ ]:


df=pd.read_sql(query,cnxn)


# In[ ]:


df.columns


# In[ ]:


def bucket(hrs):
    if hrs in range(0,24):
        return "0-24"
    elif hrs in range(24,48):
        return "24-48"
    elif hrs in range(48,72):
        return "48-72"
    elif hrs in range(72,96):
        return "72-96"
    else:
        return ">96"


# In[ ]:


df['Ageing']=df.apply(lambda x:bucket(x['HOURS_LYING_AT_CURR_LOCATION']),axis=1)


# In[ ]:


summary=df.pivot_table(index=['CURR_AREA'],columns=['Ageing'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True).fillna(0)


# In[ ]:


summary['DOCKNO']=summary['DOCKNO'].astype(int)


# In[ ]:


summary


# In[ ]:


df.to_csv(r'D:\Data\Retail_Consiments\Daily\Data.csv')


# In[ ]:


filepath=r'D:\Data\Retail_Consiments\Daily\Data.csv'


# In[ ]:


todate=datetime.strftime(datetime.now(),format='%Y-%m-%d')
todate


# In[ ]:


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

#TO=['mahesh.reddy@spoton.co.in']
TO=['aom_spot@spoton.co.in','rom_spot@spoton.co.in','dom_spot@spoton.co.in','rsm_spot@spoton.co.in','dsm_spot@spoton.co.in','asm_spot@spoton.co.in','sqtf@spoton.co.in','arokia.doss@spoton.co.in','narasimha.murthy@spoton.co.in','sanjay.johri@spoton.co.in','vishal.gp@spoton.co.in']
FROM="mis.ho@spoton.co.in"
CC=['mahesh.reddy@spoton.co.in','anitha.thyagarajan@spoton.co.in','shivananda.p@spoton.co.in']
#CC=['mahesh.reddy@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
msg["Subject"] = "Daily report on Retail consignments Undelivered " + " : " + todate



report=""

report+='Dear All,'
report+='<br>'
report+='<br>'
report+='Please Find attached Daily report on Retail consignments :'
report+='<br>'

report+='Area Wise Summary : '
report+='<br>'
report+='<br>'+summary.to_html()+'<br>'
report+='<br>'


abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()


