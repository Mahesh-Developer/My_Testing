
# coding: utf-8

# In[1]:


"""
Created on Tue Aug 11 15:09:14 2015

@author: s1602vis
"""
import pandas as pd
import numpy as np
from pandas import ExcelWriter
import urllib
import csv
from datetime import datetime, timedelta, time, date
import os
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import urllib
import ftplib
import traceback


# In[2]:

def datestring(x):
    fulldate = datetime.strptime(x,'%d %b %Y %H:%M')
    return fulldate

def dockno(x):
    return x


# In[3]:

yesterdate=date.today()-timedelta(hours=24)


# In[4]:

pmddata = pd.read_csv(r'http://spoton.co.in/downloads/PMD/PMD.csv')
#openingstock = pd.io.excel.read_excel(r'C:\Data\OCID_PMD\OCID2D.xls','OPENING STOCK')
#incomingstock = pd.io.excel.read_excel(r'C:\Data\OCID_PMD\OCID2D.xls','INCOMING')

openingstock = pd.io.excel.read_excel(r'http://spoton.co.in/downloads/OCID/OCID.xls','OPENING STOCK')
incomingstock = pd.io.excel.read_excel(r'http://spoton.co.in/downloads/OCID/OCID.xls','INCOMING')


# In[5]:

pmddata['Condate'] = pmddata.apply(lambda x:datestring(x['DATE2']),axis=1)


# In[6]:

pmddatacon = pmddata.ix[:,0]
pmddatareqcols = pmddatacon.to_frame(name='DOCKNO')
pmddatareqcols['Date'] = pmddata.apply (lambda x: x['Condate'], axis = 1)
pmddatareqcols['PUDTYPE'] = pmddata.apply (lambda x: x['PUDTYPE2'], axis = 1)
pmddatareqcols['TYPE'] = pmddata.apply (lambda x: x['TYP2'], axis = 1)
#pmddatacon1.to_csv(r'C:\Data\OCID_PMD\pmddatacon.csv')
type(pmddatareqcols['Date'].values[0])


# In[7]:

pmddatareqcols.columns


# In[8]:

#pmddata['DOCKNO'] = pmddata.apply(lambda x:x(pmddata.ix[:,0]),axis=1)
#pmddata.to_csv(r'C:\Data\OCID_PMD\pmddata.csv')


# In[9]:

vehlist = ['STD-ADHOC']
yesterdaydf = pmddatareqcols[(pmddatareqcols['Date'] >= yesterdate) & (pmddatareqcols['PUDTYPE'].isin(vehlist))& (pmddatareqcols['TYPE']=='DLV')]
#yesterdaydf=yesterdaydf.rename(columns={'∩╗┐CON_ID2':'DOCKNO'})
#yesterdaydf.to_csv(r'D:\Data\Market_vehicle_ageing\yesterdaydf.csv')
yesterdaydf.columns
#yesterdaydf.to_csv(r'C:\Data\OCID_PMD\yesterdaydf11111.csv')


# In[10]:

openingyest = pd.merge(yesterdaydf,openingstock,left_on=['DOCKNO'],right_on=['DOCKNO'],how='inner')
#openingyest.to_csv(r'D:\Data\Market_vehicle_ageing\yesterdaydfope.csv')
incomingyest = pd.merge(yesterdaydf,incomingstock,left_on=['DOCKNO'],right_on=['DOCKNO'],how='inner')
len(incomingyest), len(openingyest)
#incomingyest.to_csv(r'D:\Data\Market_vehicle_ageing\yesterdaydfinc.csv')


# In[11]:

columnsopen = ['DOCKNO','DUE DATE','ARRV AT DEST SC','REPORTDATE MIN ARRVDT','DEST BRCD','DEST AREA','DEL LOCATION TYPE'] 
openingyest = pd.DataFrame(openingyest,columns=columnsopen)
openingyest=openingyest.rename(columns={'REPORTDATE MIN ARRVDT':'REPORT TIME MIN ARRV DATE'})


# In[12]:

columnsinc = ['DOCKNO','DUE DATE','ARRV AT DEST SC','REPORT TIME MIN ARRV DATE','DEST BRCD','DEST AREA','DEL LOCATION TYPE'] 
incomingyest = pd.DataFrame(incomingyest,columns=columnsinc)
#incomingyest


# In[13]:

totaldel = openingyest.append(incomingyest,ignore_index=True)
totaldel


# In[25]:

columnstotal = ['DOCKNO','DUE DATE','ARRV AT DEST SC','REPORT TIME MIN ARRV DATE','DEST BRCD','DEST AREA','DEL LOCATION TYPE'] 
totaldel = pd.DataFrame(totaldel,columns=columnstotal)
coolinghrs = (totaldel['REPORT TIME MIN ARRV DATE'].sum())*1.0

#totaldel.to_csv(r'C:\Data\OCID_PMD\Total_Market_Dlys.csv')

totaldelgroupby = totaldel.groupby(['DEST BRCD']).agg({'DOCKNO': 'count','REPORT TIME MIN ARRV DATE': np.mean}).reset_index()
totalcons = (totaldelgroupby['DOCKNO'].sum())*1.0
avgcooling = np.round((coolinghrs/totalcons),2)
totalcons, coolinghrs, avgcooling

totaldelgroupby=totaldelgroupby.rename(columns={'REPORT TIME MIN ARRV DATE':'AVG COOLING HRS'})
# In[15]:

opfilevar =date.today() - timedelta(hours=24)
opfilevar


# In[16]:

totaldelduecons = totaldel[totaldel['DUE DATE']>= opfilevar] 
dueconsno = len(totaldelduecons)


# In[18]:

with ExcelWriter(r'D:\Data\Market_vehicle_ageing\Market_Delivered_'+str(opfilevar)+'.xlsx') as writer:
    totaldel.to_excel(writer, sheet_name='DATA',engine='xlsxwriter')
    totaldelgroupby.to_excel(writer, sheet_name='SUMMARY',engine='xlsxwriter')
    
oppath1 = r'D:\Data\Market_vehicle_ageing\Market_Delivered_'+str(opfilevar)+'.xlsx'


# In[21]:

filePath = oppath1
def sendEmail(#TO = ["supratim@iepfunds.com","Ankit@iepfunds.com"],
            #TO = ["rajeesh.vr@spoton.co.in"],
            TO = ["vishwas.j@spoton.co.in"],
            CC = ["vishwas.j@spoton.co.in"],
            #CC = ["vishwas.j@spoton.co.in","rajeesh.vr@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "Cons Delivered By Market" + " - " + str(opfilevar)
    body_text = """
    Dear All,
    
    PFA the Cons delivered by Market vehicle on """ + str(opfilevar) +"""
    
    Total cons delivered = """+str(totalcons)+"""
    Average cooling hrs = """+str(avgcooling)+"""
    Cons having Duedate>= """+str(opfilevar)+""" = """ +str(dueconsno)+"""
    
    PFB the Summary Branch wise of cons delivered and their ageing"""+"""
    
    """+str(totaldelgroupby)+"""

    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("vishwas.j@spoton.co.in", "Startrek#123")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
#Sending output file via mail ends


# In[ ]:



