# -*- coding: utf-8 -*-
"""
Created on Mon Feb 01 09:12:30 2016

@author: rajeeshv
"""


# coding: utf-8

# In[1]:

import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
import calendar
import datetime
from pandas import ExcelWriter
import glob
import smtplib
import os
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import Utilities
# In[7]:
originstock = pd.read_csv('http://10.109.230.50/downloads/IEProjects/STOCKOrigin/StockOrigin.csv')
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

# query = ("""EXEC USP_ORIGINSC_STOCK """)
# print (query)

# originstock = pd.read_sql(query, cnxn)
# print ('ss')
datetimenow = datetime.datetime.now()

opfilevar=datetimenow.date()
opfilevar1=datetimenow.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=np.round((float(currhrs)/60),0)


originstock.to_csv(r'D:\Data\Stock_at_origin_for_KC\Origin_Hourly_Stock_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv', encoding="utf-8")


# In[ ]:
path =r'D:\Data\Stock_at_origin_for_KC' # use your path
allFiles = glob.glob(path + "/*.csv")
frame = pd.DataFrame()
list_ = []
for file_ in allFiles:
    df = pd.read_csv(file_,index_col=None, header=0)
    list_.append(df)
frame = pd.concat(list_)
frame.to_csv(r'D:\Data\Stock_at_origin_for_KC.csv')

# In[2]:

hourlystockdata = pd.read_csv(r'D:\Data\Stock_at_origin_for_KC.csv')

hourlystockdata.columns.tolist()
hourlystockdata=hourlystockdata.rename(columns={'\xef\xbb\xbfDOCKNO':'DOCKNO'})
hourlystockdata.columns.tolist()
# hourlystockdata['TimeStamp']=pd.to_datetime(hourlystockdata['TimeStamp'])
# hourlystockdata['Date']=hourlystockdata['TimeStamp'].dt.date
print ('done')
hourlystockdatagrp = hourlystockdata.groupby(['TimeStamp']).agg({'DOCKNO':len,'ACTUWT':sum,'VOLUME':sum}).reset_index()
# hourlystockdatagrp = hourlystockdata.groupby(['TimeStamp']).agg({'DOCKNO':len,'ACTUWT':sum,'VOLUME':sum}).reset_index()


def datecalc(x):
    y = datetime.datetime.strptime(x,'%m/%d/%Y %H:%M:%S %p').date()
    return y
    
#hourlystockdatagrp['Date'] = hourlystockdatagrp.apply(lambda x:datecalc(x['TimeStamp']),axis=1)

columnsop = ['Date','DOCKNO','ACTUWT','VOLUME']
hourlystockdatagrp = pd.DataFrame(hourlystockdatagrp,columns=columnsop)

hourlystockdatagrp = hourlystockdatagrp.sort_values('Date',ascending=False)
hourlystockdatagrp.to_csv(r'D:\Python\Scripts and Files\Path and Graph Files\Hourly_stock_origin.csv')



hourlystockdatagrpmail = hourlystockdatagrp.head(10)


hourlystockdatagrpmail = hourlystockdatagrpmail.to_string(index=False)

oppath2 = r'D:\Python\Scripts and Files\Path and Graph Files\Hourly_stock_origin.csv'

filePath = oppath2

def sendEmail(TO = ["krishna.chandrasekar@spoton.co.in"],
            #TO = ["vishwas.j@spoton.co.in"],
            #CC = ["vishwas.j@spoton.co.in"],
            CC = ["mahesh.reddy@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "Stock at Origin" + " - " + str(opfilevar)
    body_text = """
    Dear All,

    PFB the Stock at origin. The below mentioned stock is taken at 10:00 AM everyday. 
    
   """+str(hourlystockdatagrpmail)+"""    

    """
    if body_text:
        msg.attach( MIMEText(body_text) )
        
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    #server=smtplib.SMTP('124.7.138.249', 587)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
mailend = datetime.datetime.now().time()
print 'mailend is', mailend
#Sending output file via mail ends
