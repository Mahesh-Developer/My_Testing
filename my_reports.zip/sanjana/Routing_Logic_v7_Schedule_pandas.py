# -*- coding: utf-8 -*-
"""
Created on Wed Sep 07 10:57:50 2016

@author: rajeeshv
"""

# In[1]:

import pandas as pd
import datetime
from datetime import datetime, timedelta
import calendar
import copy
#import graphlab as gl
#import graphlab.aggregate as agg
#import sframe as gl
#import sframe.aggregate as agg
from itertools import izip
import ftplib
import traceback

import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import os


# In[2]:

timeformatstring = '%m/%d/%Y %H:%M:%S %p'
timeformatstring2 = '%Y-%m-%d %H:%M:%S'
timeformatstring3 = '%m/%d/%Y %I:%M:%S %p'
conprocessing = 1.0
slackhours = 3.0
dayzero = datetime.strptime('2015-1-1 00:00:00', timeformatstring2)
dayminu = datetime.strptime('2014-1-1 00:00:00', timeformatstring2)
link = 'http://spoton.co.in/downloads/HTR_1HR/HTR_1HR.xls'
csvfilename = 'dfbase.csv'


# In[3]:

dfbase = pd.read_excel(link)


#print len(dfbase)

# In[4]:

dfdroplist = ['Latest Status Date','Latest Status Reason','Latest Status Branch','Latest Status Category','Account Name']
dfkeeplist = [i for i in dfbase.columns.tolist() if i not in dfdroplist]
dfbase = dfbase[dfkeeplist]
dfbase.to_csv(r'D:\Python\Scripts and Files\Path and Graph Files\sector_buildup_routing\dfbase.csv')
#dfbase.to_csv(csvfilename)
#print len(dfbase)


# In[5]:

#csvfilename = 'debug_ip.csv'
#invsf = gl.SFrame.read_csv(csvfilename)
#print len(invsf)
invsf = pd.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\sector_buildup_routing\dfbase.csv')
loclist = ['Destn Branch','Hub SC Location','Origin Branch']
maplist = dict({'MAAG': 'MAAC','NEIR': 'GAUB','RJPR': 'PTLF','SIKM': 'SILB','KLMF':'COKB','AMDE':'AMDO'})

## To remove VGAF and GNTF as Sri Krishna Pushkaralu till 24th August

excludebranchlist = ['VGAF','GNTF']
#invsf = invsf.filter_by(excludebranchlist, 'Destn Branch', exclude=True)
invsf = invsf[~(invsf['Destn Branch'].isin(excludebranchlist))]

## To remove VGAF and GNTF as Sri Krishna Pushkaralu till 24th August

## Check done 
def convloc(location):
    get_dict = maplist.get(location)
    #print 'get_dict',get_dict
    if get_dict is None:
        #print 'location',location
        return location
    else:
        return get_dict
 
dfbase.to_csv(r'D:\Data\Routing_logic_sector_buildup\debug123.csv')
  
for locnames in loclist:
    invsf[locnames] = invsf.apply(lambda x: convloc(x[locnames]),axis=1)
#print len(invsf)
dfbase.to_csv(r'D:\Data\Routing_logic_sector_buildup\debug.csv')

# In[6]:

#print len(invsf)
invsf = invsf[invsf['Destn Depot']!='UCGD']
#print len(invsf)
invsf = invsf[invsf['Hub SC Location']!=invsf['Destn Branch']]
#print len(invsf)

dfbase.to_csv(r'D:\Data\Routing_logic_sector_buildup\debug_dest_branch.csv')
# In[7]:

#paperwork-deps-exclusion
depspaperworkcodelist = ['SRE','SRD','SRS','SRP','DLP','SWP','PWS','HCM','HPM','MOP','SRH','HOC','ONR','SPH','SPO','DBO','DIP','SHS','SSC','HIP','RNX','APT','APN','SHD','SMT','SPL','MSH','UCG','RRA','HPE','WIA','UG1','UG2','UG3','HMP','HWC','NPE','HIM']
#invsf = invsf.filter_by(depspaperworkcodelist, 'Latest Status Code', exclude=True)
invsf = invsf[~(invsf['Latest Status Code'].isin(depspaperworkcodelist))]

#paperwork-deps-exclusion


# In[8]:
pathsf = pd.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\sector_buildup_routing\final_pathv3.csv')
lhscheduledf = pd.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\sector_buildup_routing\Timegraph.csv')
#thcbasedata = gl.SFrame.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\sector_buildup_routing\THC_DATA_1.csv')
thcbasedata = pd.read_csv('http://spoton.co.in/downloads/IEProjects/THCDEPTDTLS/THCDEPTDTLS.csv')


# In[9]:

vbdf = pd.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\sector_buildup_routing\Hublist.csv')


# In[10]:

vblist = vbdf['VB'].tolist()


# In[11]:

# to clean the data movements and only keep data movements of virtual branches
vehicletype = ['D']
thcvehicle = thcbasedata.filter_by(vehicletype, 'routety', exclude = True)
thc_data_movemnts = thcbasedata.filter_by(vehicletype, 'routety')
thcdata_virtual1 = thc_data_movemnts.filter_by(vblist, 'TCBR')
thcdata_virtual2 = thc_data_movemnts.filter_by(vblist, 'tobh_code')

thcdata = thcvehicle.append(thcdata_virtual1)
thcdata = thcdata.append(thcdata_virtual2)


# In[12]:

####move to the earlier part of the code

thcdata['dept_time']= thcdata.apply(lambda x: datetime.strptime(x['dept_time'],timeformatstring3))
thcdata['time_elapsed']= thcdata.apply(lambda x: (datetime.now()-x['dept_time']).total_seconds()*1.0/3600)
thcdata['time_elapsed']= pd.np.round(thcdata['time_elapsed'], 0)
thcdata = thcdata[['TCBR','tobh_code','mkt_veh','time_elapsed']]
thcdata.rename({'TCBR': 'Hub SC Location', 'tobh_code': 'Nextloc'})
#thcgrp = thcdata.groupby(['Hub SC Location','Nextloc'], {'time_elapsed': agg.MIN('time_elapsed')})
thcgrp = thcdata.groupby(['Hub SC Location','Nextloc']).agg({'time_elapsed': min}).reset_index()
#stage1tatyesgrp = stage1tatyes.groupby(['Category']).agg({'Invoice_No':len,'Invoice_Amt':sum,'DSO_value':sum,'Stage1_diffdays':pd.np.mean}).reset_index()


# In[13]:

lhscheduledfgrp = lhscheduledf.groupby(['Origin','Destination','Type'],{'Departure Time':agg.CONCAT('Departure Time'),'Total leg TT': agg.CONCAT('Total leg TT')})
print lhscheduledfgrp.head()
lhscheduledf_dict = {}
for org, dest, deptime, transithrs,vbtype in izip(lhscheduledfgrp['Origin'], lhscheduledfgrp['Destination'],
                                     lhscheduledfgrp['Departure Time'], lhscheduledfgrp['Total leg TT'], lhscheduledfgrp['Type']):
    lhscheduledf_dict[(org, dest)] = [deptime,transithrs,vbtype]


# In[14]:

path_dict = {}
for org, dest, paths in izip(pathsf['Origin'], pathsf['Destination'],pathsf['pathlist']):
    path_dict[(org, dest)] = paths


# In[15]:

def getconpath(origin,location,destination):
    #print origin, location, destination
    try:
        conpathall1 = path_dict.get((origin,destination))
        if conpathall1 is None:
            conpathall = None
        else:
            conpathall = [i for i in conpathall1 if location in i]
        auxpathall = path_dict.get((location,destination))
        if conpathall is None:
            conpathall = []
        if auxpathall is None:
            auxpathall = []
        if (len(conpathall)==0) and (len(auxpathall)==0):
            return ['error']
        elif (len(conpathall)==0):
            lenlist = [len(i) for i in auxpathall]
            return auxpathall[lenlist.index(min(lenlist))]
        else:
            lenlist = [len(i) for i in conpathall]
            minconpath = conpathall[lenlist.index(min(lenlist))]
            return minconpath[minconpath.index(location):]
    except:
        ['checkerror']


# In[16]:

def getdeparturetime(org, dest, currtime):
    try:
        currtimedt = str(currtime).split(' ')[0]+' 00:00:00'
        currtimedt = datetime.strptime(currtimedt,'%Y-%m-%d %H:%M:%S')
        deptime_total = lhscheduledf_dict.get((org, dest))
        if deptime_total is None:
            return dayzero, dayzero
        deptime, transithrs, vbtype = deptime_total
        if vbtype == 'Normal':
            timerellist = []
            for i in range(0,len(deptime)):
                deptime1 = timedelta(hours=deptime[i])+(currtimedt)
                deptime2 = timedelta(hours=(deptime[i]+24.0))+(currtimedt)
                arrtime1 = deptime1 + timedelta(hours=transithrs[i])
                arrtime2 = deptime2 + timedelta(hours=transithrs[i])
                if deptime1<=currtime:
                    timerellist.append((deptime2,arrtime2))
                else:
                    timerellist.append((deptime1,arrtime1))
            
            sorted_by_first = sorted(timerellist, key=lambda tup: tup[0], reverse=False)
            return sorted_by_first[0][0],sorted_by_first[0][1]
        elif vbtype == 'VB':
            deptime = timedelta(hours=3.0)+(currtime)
            return deptime,deptime
    except:
        return dayzero,dayzero


# In[17]:

def getidealtimes(con,conpath,pickuptime,arratcurrloc):
    ### pickuptime is current time
    try:
        idealtimelist = []
        hrsatcurrloc = (pickuptime-arratcurrloc).total_seconds()*1.0/3600
        if hrsatcurrloc<=conprocessing:
            adjtimeatloc = conprocessing-hrsatcurrloc
        else:
            adjtimeatloc = 0
        currtime = pickuptime+timedelta(hours=adjtimeatloc)
        idealtimelist.append(pickuptime)
        for i in range (1,len(conpath)):
            org = conpath[i-1]
            dest = conpath[i]
            departuretime,arrivaltime = getdeparturetime(org,dest,currtime)
            if (departuretime==dayzero)or(arrivaltime==dayzero):
                idealtimelist=[dayzero]
                break    
            else:
                if (dest == conpath[-1]) and (departuretime.weekday()==arrivaltime.weekday()==6) and (arrivaltime.hour<=12):
                    departuretime = departuretime+timedelta(hours=24)
                    arrivaltime = arrivaltime+timedelta(hours=24)
                idealtimelist.append(departuretime)
                idealtimelist.append(arrivaltime)
                currtime = arrivaltime

        return idealtimelist
    except:
        return [dayzero]


# In[18]:

def getdeparturetime2(org, dest, currtime):
    try:
        currtimedt = str(currtime).split(' ')[0]+' 00:00:00'
        currtimedt = datetime.strptime(currtimedt,'%Y-%m-%d %H:%M:%S')
        deptime_total = lhscheduledf_dict.get((org, dest))
        if deptime_total is None:
            return dayzero, dayzero
        deptime, transithrs, vbtype = deptime_total
        transittime = max(transithrs)
        if vbtype == 'Normal':
            deptime = timedelta(hours=slackhours)+(currtime)
            arrtime  = deptime+timedelta(hours=transittime)
            return deptime,arrtime
        elif vbtype == 'VB':
            deptime = timedelta(hours=3.0)+(currtime)
            return deptime,deptime
    except:
        return dayzero,dayzero


# In[19]:

def getidealtimes2(con,conpath,pickuptime,arratcurrloc):
    ### pickuptime is current time
    try:
        idealtimelist = []
        hrsatcurrloc = (pickuptime-arratcurrloc).total_seconds()*1.0/3600
        if hrsatcurrloc<=conprocessing:
            adjtimeatloc = conprocessing-hrsatcurrloc
        else:
            adjtimeatloc = 0
        currtime = pickuptime+timedelta(hours=adjtimeatloc)
        idealtimelist.append(pickuptime)
        for i in range (1,len(conpath)):
            org = conpath[i-1]
            dest = conpath[i]
            if i!=1:
                departuretime,arrivaltime = getdeparturetime(org,dest,currtime)
            elif i==1:
                departuretime,arrivaltime = getdeparturetime2(org,dest,currtime)
                
            if (departuretime==dayzero)or(arrivaltime==dayzero):
                idealtimelist=[dayzero]
                break    
            else:
                if (dest == conpath[-1]) and (departuretime.weekday()==arrivaltime.weekday()==6) and (arrivaltime.hour<=12):
                    departuretime = departuretime+timedelta(hours=24)
                    arrivaltime = arrivaltime+timedelta(hours=24)
                idealtimelist.append(departuretime)
                idealtimelist.append(arrivaltime)
                currtime = arrivaltime

        return idealtimelist
    except:
        return [dayzero]


# In[20]:

def geteta(x):
    try:
        return x[-1]
    except:
        return dayminu


# In[21]:

invsf['conpath'] = invsf.apply(lambda x: getconpath(x['Origin Branch'],x['Hub SC Location'],x['Destn Branch']))
invsf['Origin Branch'] = invsf.apply(lambda x: x['Origin Branch'].upper())
invsf['Destn Branch'] = invsf.apply(lambda x: x['Destn Branch'].upper())
invsf['Hub SC Location'] = invsf.apply(lambda x: x['Hub SC Location'].upper())
invsf['arratcurrloc'] = invsf.apply(lambda x: datetime.strptime(x['Arrival Date Hub'].split('.')[0],timeformatstring2))
invsf['currtime'] = invsf.apply(lambda x: datetime.strptime(x['TIMESTAMP'].split('.')[0],timeformatstring2))
invsf['Duedt'] = invsf.apply(lambda x: datetime.strptime(x['Due Date'].split('.')[0],timeformatstring2))
 
invsf['idealtimelist'] = invsf.apply(lambda x: getidealtimes(x['Con Number'],x['conpath'],x['currtime'],x['arratcurrloc']))
invsf['idealtimelist2'] = invsf.apply(lambda x: getidealtimes2(x['Con Number'],x['conpath'],x['currtime'],x['arratcurrloc']))

#print len(invsf)

invsf = invsf[invsf['idealtimelist']!=[dayzero]]
#print len(invsf)
invsf['eta'] = invsf.apply(lambda x: geteta(x['idealtimelist']))
invsf['eta2'] = invsf.apply(lambda x: geteta(x['idealtimelist2']))
invsf = invsf[invsf['eta']!=dayminu]
#print len(invsf)
#errordate = invsf[(invsf['eta']==dayzero)]


# In[22]:

check1 = (invsf[invsf['conpath']==['error']])
#print len(check1)
#print 'error: '+str((check1['Act Wt In Tonnes'].sum()))+ ' : '+str(len(check1))
invsfinal = invsf[(invsf['eta']!=dayminu)]
#print 'correct: '+ str((invsfinal['Act Wt In Tonnes'].sum()))+ ' : '+str(len(invsfinal))


# In[23]:

def getreach(eta,duedt):
    duedtadj = duedt+timedelta(hours=14)
    if eta>duedtadj:
        return 0
    else:
        return 1
def correct_reach2(reach, reach2):
    if reach>reach2:
        return 1
    else:
        return reach2


# In[24]:

invsf['reached'] = invsf.apply(lambda x: getreach(x['eta'],x['Duedt']))
invsf['reached2'] = invsf.apply(lambda x: getreach(x['eta2'],x['Duedt']))
invsf['reached2'] = invsf.apply(lambda x: correct_reach2(x['reached'],x['reached2']))
expected_reach= pd.np.ceil(invsf[invsf['reached']==1]['reached'].sum()*100.0/len(invsf['reached']))
max_expected_reach=pd.np.ceil(invsf[invsf['reached2']==1]['reached2'].sum()*100.0/len(invsf['reached2']))


# In[25]:

def getdelayhrs(duedt,eta,pred):
    if pred==0:
        return -1.0*pd.np.ceil(((duedt+timedelta(hours=14))-eta).total_seconds()*1.0/3600)
    else:
        return 0
invsf['delayhours'] = invsf.apply(lambda x:getdelayhrs(x['Duedt'],x['eta'],x['reached']))
invsf['delayhours2'] = invsf.apply(lambda x:getdelayhrs(x['Duedt'],x['eta2'],x['reached2']))


# In[26]:

def getnextloc(conpath,currloc):
    try:
        ix = conpath.index(currloc)
        return conpath[ix+1]
            
    except:
        return 'error'

quant = 0.4  
invsf['Nextloc'] = invsf.apply(lambda x: getnextloc(x['conpath'],x['Hub SC Location']))    
grpcon = invsf.groupby(['Hub SC Location','Nextloc'],{'wt': agg.SUM('Act Wt In Tonnes'),'reached2':agg.SUM('reached2'),'reached':agg.SUM('reached'),'concount':agg.COUNT_DISTINCT('Con Number'),'delayhrs': agg.QUANTILE('delayhours',quant)})
grpcon['delayhrs'] = grpcon.apply(lambda x: x['delayhrs'][0])

grpcon['wt'] = pd.np.round(grpcon['wt'],1)
grpcon['reachedperc'] = pd.np.ceil(grpcon['reached']*100.0/grpcon['concount'])
grpcon['reachedperc2'] = pd.np.ceil(grpcon['reached2']*100.0/grpcon['concount'])
grpcon['diff%'] = pd.np.ceil(grpcon['reachedperc2']-grpcon['reachedperc'])


# In[27]:

itemlist = []
for items in grpcon:
    org=items['Hub SC Location']
    dest = items['Nextloc']
    deptime_total = lhscheduledf_dict.get((org, dest))
    try: 
        item = [org,dest,deptime_total[0]]
    except:
        item= [org,dest,[0.0]]
    itemlist.append(item)
itemdf = pd.DataFrame(itemlist, columns = ['Hub SC Location','Nextloc','Sch_Dept']) 
itemsf = gl.SFrame(itemdf)
joinlist = ['Hub SC Location','Nextloc']
grpcon = grpcon.join(itemsf, on = joinlist, how = 'left')


# In[28]:

lhscheduledfgrp1 = lhscheduledf.groupby(['Origin','Destination','Type'],{'Payload':agg.QUANTILE('Payload',0.75)})
lhscheduledfgrp1['Payload'] = lhscheduledfgrp1.apply(lambda x: x['Payload'][0]) 
lhscheduledf_dict1 = {}
for org, dest, vbtype,payload in izip(lhscheduledfgrp1['Origin'], lhscheduledfgrp1['Destination'],
                                     lhscheduledfgrp1['Type'],lhscheduledfgrp1['Payload']):
    lhscheduledf_dict1[(org, dest)] = [vbtype,payload]

def get_threshold(org,dest):
    try:
        ret_total = lhscheduledf_dict1.get((org,dest))
        vbtype, pl = ret_total
        if vbtype=='Normal':
            return pl*0.9/1000
        else:
            return 0.0
    except:
        return 9.0


# In[29]:

def getaction(org,dest,wt, reached, reached2):
    threshold = get_threshold(org,dest)
    if threshold < 5:
        threshold = 5
    if ((reached2-reached)>=10 or (reached2<85)) and (wt>=threshold):
        return 'urgent'
    else:
        return 'skip'


# In[30]:

grpcon = grpcon.join(thcgrp, on = ['Hub SC Location','Nextloc'], how = 'left')


# In[31]:


grpcon['critical_action'] = grpcon.apply(lambda x: getaction(x['Hub SC Location'],x['Nextloc'],x['wt'],x['reachedperc'], x['reachedperc2']))


# In[32]:

grpcon_join = grpcon['Hub SC Location','Nextloc', 'critical_action']
invsf = invsf.join(grpcon_join, on = ['Hub SC Location','Nextloc'], how = 'left')


# In[33]:

#save for reports
ts= datetime.now()
opfilevar=ts.date()
opfilevar1=ts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=pd.np.round(float(currhrs)/60)

invsf.save(r'D:\Python\Scripts and Files\Path and Graph Files\sector_buildup_routing\storage\data_storage\Data_Sector_buildup_'+str(opfilevar)+str('_')+str(opfilevar2)+'.csv')
grpcon['Timestamp'] = invsf['currtime'][0]
grpcon.save(r'D:\Python\Scripts and Files\Path and Graph Files\sector_buildup_routing\storage\allgroupby_storage\Allgrpby_Sector_buildup_'+str(opfilevar)+str('_')+str(opfilevar2)+'.csv')
#grpcon.save('allgroupby.csv')


## FTP the conwise basedata
invsf.save(r'D:\Python\Scripts and Files\Path and Graph Files\sector_buildup_routing\Data_Sector_buildup.csv')
oppath2 = r'D:\Python\Scripts and Files\Path and Graph Files\sector_buildup_routing\Data_Sector_buildup.csv'

## For getting the variables for the email body

inventorycons = len(invsf)
urgentcondf = invsf[invsf['critical_action']=='urgent']
urgentreachcons = urgentcondf['reached'].sum()
urgentcons = len(urgentcondf)
urgentreachperc = pd.np.round((urgentreachcons*100.0)/urgentcons,2)

skipcondf = invsf[invsf['critical_action']=='skip']
skipreachcons = skipcondf['reached'].sum()
skipcons = len(skipcondf)
skipreachperc = pd.np.round((skipreachcons*100.0)/skipcons,2)

## For getting the variables for the email body

ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
#print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        #print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppath2
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        #print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()
    
## FTP the conwise basedata 

# In[34]:

grpcon[grpcon['critical_action']=='urgent'].sort_values('wt', ascending = False)
ignorelist=['error']
grpcon = grpcon.filter_by(ignorelist, 'Nextloc', exclude=True)


# In[35]:

grpcon = grpcon[grpcon['critical_action']=='urgent'].sort_values('wt', ascending = False)


# In[36]:

columnlistmail = ['Hub SC Location', 'Nextloc', 'wt','concount', 'reachedperc','reachedperc2', 'diff%','time_elapsed']
columnlist = ['Hub SC Location', 'Nextloc', 'wt','concount', 'reached', 'reached2', 'reachedperc','reachedperc2','diff%','time_elapsed','Sch_Dept','critical_action']
grpcritical_final_mailbody = grpcon[columnlistmail]
grpcritical_final = grpcon[columnlist]
#grpcritical_final = grpcritical_final.rename({'Hub SC Location':'CurrLoc','Nextloc':'NextLoc','concount':'con', 'reached':'Reach','reached2':'MaxReach','reachedperc':'Reach%','reachedperc2':'MaxReach%', 'critical_action':'Action'})
grpcritical_final = grpcritical_final.rename({'Hub SC Location':'CurrLoc','Nextloc':'NextLoc','wt': 'wt(T)','concount':'con','reached':'Reach_Cons','reached2':'MaxReach_Cons' ,'reachedperc':'Reach%','reachedperc2':'MaxReach%'})
grpcritical_final_mailbody = grpcritical_final_mailbody.rename({'Hub SC Location':'CurrLoc','Nextloc':'NextLoc','wt': 'wt(T)','concount':'con', 'reachedperc':'Reach%','reachedperc2':'MaxReach%'})

grpcritical_finaldf = grpcritical_final.to_dataframe()
grpcritical_final_mailbodydf = grpcritical_final_mailbody.to_dataframe()



# In[37]:

grpcritical_finaldf


# In[41]:


grpcritical_finaldf.to_csv(r'D:\Python\Scripts and Files\Path and Graph Files\sector_buildup_routing\Sector_buildup.csv')

##grpcritical_final.save(r'D:\Python\Scripts and Files\Path and Graph Files\Sector_buildup.csv')
#invsf.save('data.csv')


## For saving explicitly

#print 'opfilevar,opfilevar2',opfilevar,opfilevar2
grpcritical_finaldf['Timestamp'] = invsf['currtime'][0]
grpcritical_finaldf.to_csv(r'D:\Python\Scripts and Files\Path and Graph Files\sector_buildup_routing\storage\Sector_buildup_'+str(opfilevar)+str('_')+str(opfilevar2)+'.csv')
## For saving explicitly

# In[ ]:
#@oppath = r'D:\Python\Scripts and Files\Path and Graph Files\Sector_buildup.csv'
oppath = r'D:\Python\Scripts and Files\Path and Graph Files\sector_buildup_routing\Sector_buildup.csv'
# In[ ]:
filePath = oppath
def sendEmail(#TO = ["hubmgr_spot@spoton.co.in","raghavendra.rao@spoton.co.in"],
            #TO = ["rajeesh.vr@spoton.co.in"],
            TO = ["vishwas.j@spoton.co.in"],
            CC = ["vishwas.j@spoton.co.in"],
            #CC = ["supratim@iepfunds.com","pawan.sharma@spoton.co.in","sqtf@spoton.co.in"],
            #BCC = ["vinayak.kumbhar@spoton.co.in","vinodkumar.mishra@spoton.co.in","nitin.tatyarao@spoton.co.in","kiran.pawar@spoton.co.in","jai.prakash@spoton.co.in"] ,
            BCC = ["vishwas.j@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    msg["Subject"] = "Sector Load Buildup " + '- ' + str(opfilevar)+str('-')+ str(opfilevar2)
    body_text = """
    Dear All,
    
    PFA the Sector Load Buildup at """+str(opfilevar)+str('-')+str(opfilevar2)+ """
    Total expected Reach% of the current inventory = """+str(expected_reach)+"""
    Total expected Max Reach% of the current inventory = """+str(max_expected_reach)+"""
    Total cons in inventory = """+str(inventorycons)+"""
    Total cons in urgent status = """+str(urgentcons)+"""
    Total expected Reach % of urgent status cons = """+str(urgentreachperc)+"""
    Total cons in other status = """+str(skipcons)+"""
    Total expected Reach % of other status cons = """+str(skipreachperc)+"""
    
    
    PFB the link for the basedata:
    http://10.109.230.50/downloads/IEProjects/ETA/Data_Sector_buildup.csv    
    
    Legends:
    Reach% :- is the %age of cons in inventory that will reach destSC before its duedate, if the next schedule is used for its departure
    MaxReach% :- is the %age of cons in inventory that will reach destSC before its duedate, if the con is departed in next three hours
    diff% :- is the difference between MaxReach% and Reach%
    Wt :- is weight in tonnes
    con :- is the concount
    time_elapsed :- is the hours since last THC was prepared in last 24hrs
    
    
    PS: The stock excludes cons with DEPS, paperwork and customer related status codes
    
"""+str(grpcritical_final_mailbodydf)+"""
    
    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
#print('Email sent')
#Sending output file via mail ends


######## For FTP of Con reach to IT

invdf = invsf.to_dataframe()
invdf = invdf.rename(columns={'reached':'Reach'})
invdf = pd.DataFrame(invdf,columns=['Con Number','Reach'])

htrbase = pd.read_excel('http://spoton.co.in/downloads/HTR_1HR/HTR_1HR.xls')
htrbase = pd.DataFrame(htrbase,columns=['Con Number'])
conreachdf = pd.merge(htrbase,invdf,on=['Con Number'],how='left')
conreachdf = conreachdf.fillna(0)
conreachdf.to_csv(r'D:\Python\Scripts and Files\Path and Graph Files\sector_buildup_routing\Sector_load_con_reach.csv')
conreachdf.to_csv(r'D:\Python\Scripts and Files\Path and Graph Files\sector_buildup_routing\storage\Reach_FTP\Sector_load_con_reach_'+str(opfilevar)+str('_')+str(opfilevar2)+'.csv')
oppathreach = r'D:\Python\Scripts and Files\Path and Graph Files\sector_buildup_routing\Sector_load_con_reach.csv'


print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppathreach
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()


recipients = ["vishwas.j@spoton.co.in"]
#recipients = ["vishwas.j@spoton.co.in"]
sender = "reports.ie@spoton.co.in"
subject = "Server Reach FTP done - "+ str(opfilevar)+str('-')+ str(opfilevar2)
body = """
Reach FTP done

"""

# make up message
msg = MIMEText(body)
msg['Subject'] = subject
msg['From'] = sender
msg['To'] = ", ".join(recipients)

# sending
session = smtplib.SMTP('smtp.spoton.co.in', 587)
session.starttls()
session.login(sender, 'Reports@2019')
send_it = session.sendmail(sender, recipients, msg.as_string())
session.quit()
######## For FTP of Con reach to IT



