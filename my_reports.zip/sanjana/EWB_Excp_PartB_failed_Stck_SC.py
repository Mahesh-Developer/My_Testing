
# coding: utf-8

# In[6]:


import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
from string import Template
import Utilities

# In[7]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()


# In[8]:


query2=("""EXEC dbo.USP_EWAYBILL_STOCK_CONS_SQ 'NU' """)


# In[9]:


notupdf=pd.read_sql(query2,Utilities.cnxn)


# In[10]:


len(notupdf)


# In[ ]:
try:
    sc_notdf=notupdf[notupdf['CURR_LOC_TYPE']=='SC']


    # In[ ]:


    sc_notup_pivot=pd.pivot_table(sc_notdf,index=['CURR_AREA'],values=['DOCKNO'],aggfunc={'DOCKNO':len})


    # In[ ]:


    sc_notup_pivot


    # In[ ]:


    sc_notup_pivot=sc_notup_pivot.sort_values([('DOCKNO')],ascending=False)


    # In[ ]:


    sc_notup_pivot=sc_notup_pivot.fillna(0)


    # In[ ]:


    nu_sc_max=sc_notup_pivot['DOCKNO'][0]
    nu_sc_loc=sc_notup_pivot.index[0]


    # In[ ]:


    reportts = datetime.now()
    opfilevar=reportts.date()
    opfilevar1=reportts.time()
    ct2= str (opfilevar1)
    currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

    opfilevar2=pd.np.round((float(currhrs)/60),0)


    # In[ ]:


    sc_notdf.to_csv(r'D:\Data\Ewaybill\Stock\PartB Nt Updated\Sc\EwayBill_PartB NotUpdated SC.csv')
    sc_notdf.to_csv(r'D:\Data\Ewaybill\Stock\PartB Nt Updated\Sc\EwayBill_PartB NotUpdated SC_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv')
    filepath4=r'D:\Data\Ewaybill\Stock\PartB Nt Updated\Sc\EwayBill_PartB NotUpdated SC.csv'


    # In[ ]:


    import numpy as np
    import pandas as pd
    import itertools
    import json
    from pandas import ExcelWriter
    from pandas import pivot_table
    from datetime import datetime
    import os
    import ftplib
    import traceback

    oppath1=filepath4
    #FTP Upload starts
    print ('Logging in...')
    ftp = ftplib.FTP()  
    ftp.connect('10.109.230.50')  
    print (ftp.getwelcome())
    try:  
        try:  
            ftp.login('HOSQTeam', 'Te@mH0$q')
            print ('login done')
            ftp.cwd('Auto_reports')  
            #ftp.cwd('FIFO')
            # move to the desired upload directory  
            print ("Currently in:", ftp.pwd()) 
            print ('Uploading...')  
            fullname = oppath1
            name = os.path.split(fullname)[1]  
            f = open(fullname, "rb")  
            ftp.storbinary('STOR ' + name, f)  
            f.close()  
            print ("OK"  )
            print ("Files:")  
            print (ftp.retrlines('LIST'))
        finally:  
            print ("Quitting...")
            ftp.quit()  
    except:  
        traceback.print_exc()


    # In[ ]:

    #TO=['mahesh.reddy@spoton.co.in']
    #CC=['mahesh.reddy@spoton.co.in']
    #BCC=['mahesh.reddy@spoton.co.in']
    TO=["dom_spot@spoton.co.in","rom_spot@spoton.co.in","sq_spot@spoton.co.in","aom_spot@spoton.co.in",'scincharge_spot@spoton.co.in']
    CC=['sqtf@spoton.co.in','rajesh.kapase@spoton.co.in']
    BCC=['mahesh.reddy@spoton.co.in','shashvat.suhane@spoton.co.in','gireesh.kumar@spoton.co.in','ajesh.c@spoton.co.in','devakumar.d@spoton.co.in','shejeer.b@spoton.co.in']
    FROM='mis.ho@spoton.co.in'
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "Ewaybill Exception Report for Stock cons @ SC - PartB updation is failed " + str(opfilevar)+"-"+str(opfilevar2)

    html3='''
    <h5> To download the cons data , Please click the link below </h5>
    <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EwayBill_PartB NotUpdated SC.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EwayBill_PartB NotUpdated SC.csv</p></b>
    '''
    report=""
    report+='Dear All,'

    report+='<br>'
    report+='Below is the exception report on stock cons, where Ewaybill is available but when the con is booked/arrived from previous location Part B is not updated, Pls go through the error message in the attachment why the Part B updation is not happened & correct it accordingly before departing the con from your location.'
    report+='<br>'
    report+='<br>'
    report+='NOTE: Download the Attachment from the Below link'
    report+='<br>'
    report+='<br>'
    report+='Eg:- '+str(nu_sc_loc)+' is have '+str(nu_sc_max)+' cons where Ewaybill is available but Part B is not updated.'
    report+='<br>'+sc_notup_pivot.to_html()+'<br>'
    report+=html3
    abc=MIMEText(report,'html')
    msg.attach(abc)

    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filepath4,"rb").read() )
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath4))
    #msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
    server.quit()

except:
    TO=['mahesh.reddy@spoton.co.in','shivananda.p@spoton.co.in']
    FROM='mis.ho@spoton.co.in'
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    #msg["CC"] = ",".join(CC)
    #msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "ERROR Report" 
    report=""
    report+='Hi,'

    report+='<br>'
    report+='There was some error in Ewaybill Exception Report for Stock cons @ SC - PartB updation is failed'
    report+='<br>'
    
    abc=MIMEText(report.encode('utf-8'),'html')
    msg.attach(abc)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO, msg.as_string())
    server.quit()
