
# coding: utf-8

# In[1]:


import graphlab as gl
import pandas as pd
import datetime
from datetime import datetime, timedelta
import calendar
import copy
#import graphlab as gl
import graphlab.aggregate as agg
from itertools import izip

import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import os
import ctypes, inspect


# In[2]:

timeformatstring = '%m/%d/%Y %H:%M:%S %p'
timeformatstring2 = '%Y-%m-%d %H:%M:%S'
timeformatstring3 = '%d-%m-%Y %H:%M'
conprocessing = 1.0
slackhours = 3.0
timeallowance = 1.0
dayzero = datetime.strptime('2015-1-1 00:00:00', timeformatstring2)
dayminu = datetime.strptime('2014-1-1 00:00:00', timeformatstring2)
link = 'http://spoton.co.in/downloads/TCR_UND_2HRS/TCR_UND_ISDEPART_YES_2HRS.xls'
csvfilename = 'dfbaseTransit.csv'


# In[3]:

dfbase = pd.read_excel(link)
#print len(dfbase)


# In[4]:

dfdroplist = ['Latest Status','Latest Status Date','Latest Status Reason','Latest Status Branch','Latest Status Category','Account Name']
dfkeeplist = [i for i in dfbase.columns.tolist() if i not in dfdroplist]
dfbase = dfbase[dfkeeplist]
dfbase.to_csv(r'D:\Python\Scripts and Files\Path and Graph Files\sector_buildup_routing\dfbase.csv')
#print len(dfbase)


# In[5]:

#csvfilename = 'debug_ip.csv'
invsf = gl.SFrame.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\sector_buildup_routing\dfbase.csv')
#print len(invsf)
statuscodes = gl.load_sframe(r'D:\Python\Scripts and Files\Path and Graph Files\secto_buildup_routing_INTRANSIT\StatusCodes.csv')
loclist = ['DESTCD','CURR BRANCHCODE','ORIGIN BRCODE']
maplist = dict({'MAAG': 'MAAC','NEIR': 'GAUB','RJPR': 'PTLF','SIKM': 'SILB','KLMF':'COKB','AMDE':'AMDO'})

## To remove VGAF and GNTF as Sri Krishna Pushkaralu till 24th August

#excludebranchlist = ['VGAF','GNTF']
#invsf = invsf.filter_by(excludebranchlist, 'DESTCD', exclude=True)

## To remove VGAF and GNTF as Sri Krishna Pushkaralu till 24th August


dfbase.to_csv(r'D:\Python\Scripts and Files\Path and Graph Files\sector_buildup_routing\debug_intransit.csv')
def convloc(location):
    get_dict = maplist.get(location)
    if get_dict is None:
        return location
    else:
        return get_dict
    
for locnames in loclist:
    invsf[locnames] = invsf.apply(lambda x: convloc(x[locnames]))
#print len(invsf)
dfbase.to_csv(r'D:\Python\Scripts and Files\Path and Graph Files\sector_buildup_routing\debug_intransit123.csv')

# In[6]:

invsf.rename({'DOCKNO': 'Con Number','DESTCD':'Destn Branch','CURR BRANCHCODE':'Hub SC Location','ORIGIN BRCODE':'Origin Branch','DUE DATE':'Due Date','DEPARTURE TO LOC FRM CURLOC':'thcdest','TIME STAMP': 'TIMESTAMP', 'DEPARTED FRM CURRLOC ROUTECD':'routecd'})


# In[7]:

#print len(invsf)
invsf = invsf[invsf['Hub SC Location']!=invsf['Destn Branch']]
#print len(invsf)
#for ignoring the data THCs
dataignorelist=['DATA-VEH']
invsf = invsf.filter_by(dataignorelist, 'DEPARTED FRM CURRLOC VEHNO', exclude=True)
#print len(invsf)


# In[8]:

pathsf = gl.SFrame.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\secto_buildup_routing_INTRANSIT\final_pathv3.csv')
lhscheduledf = gl.SFrame.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\secto_buildup_routing_INTRANSIT\Timegraph.csv')


# In[9]:

lhscheduledfgrp = lhscheduledf.groupby(['Origin','Destination','Type'],{'Departure Time':agg.CONCAT('Departure Time'),'Total leg TT': agg.CONCAT('Total leg TT')})
lhscheduledf_dict = {}
for org, dest, deptime, transithrs,vbtype in izip(lhscheduledfgrp['Origin'], lhscheduledfgrp['Destination'],
                                     lhscheduledfgrp['Departure Time'], lhscheduledfgrp['Total leg TT'], lhscheduledfgrp['Type']):
    lhscheduledf_dict[(org, dest)] = [deptime,transithrs,vbtype]


# In[10]:

path_dict = {}
for org, dest, paths in izip(pathsf['Origin'], pathsf['Destination'],pathsf['pathlist']):
    path_dict[(org, dest)] = paths


# In[11]:

def getconpath(origin,location,destination):
    #print origin, location, destination
    try:
        conpathall1 = path_dict.get((origin,destination))
        if conpathall1 is None:
            conpathall = None
        else:
            conpathall = [i for i in conpathall1 if location in i]
        auxpathall = path_dict.get((location,destination))
        if conpathall is None:
            conpathall = []
        if auxpathall is None:
            auxpathall = []
        if (len(conpathall)==0) and (len(auxpathall)==0):
            return ['error']
        elif (len(conpathall)==0):
            lenlist = [len(i) for i in auxpathall]
            return auxpathall[lenlist.index(min(lenlist))]
        else:
            lenlist = [len(i) for i in conpathall]
            minconpath = conpathall[lenlist.index(min(lenlist))]
            return minconpath[minconpath.index(location):]
    except:
        ['checkerror']


# In[12]:

def geteta(x):
    try:
        return x[-1]
    except:
        return dayminu


# In[13]:

invsf['conpath'] = invsf.apply(lambda x: getconpath(x['Origin Branch'],x['thcdest'],x['Destn Branch']))


# In[14]:

invsf['Origin Branch'] = invsf.apply(lambda x: x['Origin Branch'].upper())
invsf['Destn Branch'] = invsf.apply(lambda x: x['Destn Branch'].upper())
invsf['Hub SC Location'] = invsf.apply(lambda x: x['Hub SC Location'].upper())
invsf['departtimefromcurrloc'] = invsf.apply(lambda x: datetime.strptime(x['DEPARTURE TIME FRM CURLOC'].split('.')[0],timeformatstring2))
invsf['sch_dep'] = invsf.apply(lambda x: datetime.strptime(x['THC SCH DEPT FROM SOURCE'].split('.')[0],timeformatstring2))
invsf['currtime'] = invsf.apply(lambda x: datetime.strptime(x['TIMESTAMP'].split('.')[0],timeformatstring2))
invsf['Duedt'] = invsf.apply(lambda x: datetime.strptime(x['Due Date'].split('.')[0],timeformatstring2))

#incorporated on 30-Aug-2016 to include updates from GPS/CNM
#@@#
def thcetadate(thceta):
    try:
        x = thceta.split('.')[0]
        return datetime.strptime(x,timeformatstring2)
    except:
        return dayminu


invsf['thcETA'] = invsf.apply(lambda x: thcetadate(x['THC ETA']))

#to remove the thcs with data issue (removing thcs departed six days [144 hours] before the timestamp)
len(invsf)
cuttofftime = (invsf['currtime'][0])-timedelta(hours = 144)
invsf = invsf[invsf['departtimefromcurrloc']>cuttofftime]
len(invsf)


#creating flag to two a.Updated by CNM/GPS to take the first leg eta directly from the input file and b.The ones not 
#updated by GPS/CNM, where there is a touching location and where the thceta is lesser than the timestamp-will take the schedule tt
flagexcludelist = ['NAL', 'SCH', 'SYS']
def flagmark(updatedby, nxtloc_TC, actualTHCdest, thceta, ts1):
    if updatedby in flagexcludelist:
        return 'Red'
    elif nxtloc_TC != actualTHCdest:
        return 'Red'
    elif thceta <= ts1:
        return 'Red'
    else:
        return 'Green'

invsf['Flag_Mark']= invsf.apply(lambda x: flagmark(x['THC ARRI ENTRY'],x['thcdest'], x['THC DEST'], x['thcETA'],x['currtime']))
#@@#


#incorporated on 30-Aug-2016 to include updates from GPS/CNM


# In[15]:

def getdeparturetime(org, dest, currtime):
    try:
        currtimedt = str(currtime).split(' ')[0]+' 00:00:00'
        currtimedt = datetime.strptime(currtimedt,'%Y-%m-%d %H:%M:%S')
        deptime_total = lhscheduledf_dict.get((org, dest))
        if deptime_total is None:
            return dayzero, dayzero
        deptime, transithrs, vbtype = deptime_total
        if vbtype == 'Normal':
            timerellist = []
            for i in range(0,len(deptime)):
                deptime1 = timedelta(hours=deptime[i])+(currtimedt)
                deptime2 = timedelta(hours=(deptime[i]+24.0))+(currtimedt)
                arrtime1 = deptime1 + timedelta(hours=transithrs[i])
                arrtime2 = deptime2 + timedelta(hours=transithrs[i])
                if deptime1<=currtime:
                    timerellist.append((deptime2,arrtime2))
                else:
                    timerellist.append((deptime1,arrtime1))
            
            sorted_by_first = sorted(timerellist, key=lambda tup: tup[0], reverse=False)
            return sorted_by_first[0][0],sorted_by_first[0][1]
        elif vbtype == 'VB':
            deptime = timedelta(hours=3.0)+(currtime)
            return deptime,deptime
    except:
        return dayzero,dayzero

def getidealtimes(con,conpath,thcorigin,thcdest,deptime,currtimets,flag,thceta):
    ### pickuptime is current time
    try:
        idealtimelist = []
        idealtimelist.append(deptime)
        #@@
        if flag == 'Green':
            currtime = thceta
        else:
            currtime = getdeparturetime(thcorigin, thcdest,deptime)[1]
        #@@
        
        if currtimets>currtime:
            currtime = currtimets+timedelta(hours=timeallowance)
        idealtimelist.append(currtime)
        for i in range (1,len(conpath)):
            org = conpath[i-1]
            dest = conpath[i]
            departuretime,arrivaltime = getdeparturetime(org,dest,currtime)
            if (departuretime==dayzero)or(arrivaltime==dayzero):
                idealtimelist=[dayzero]
                break    
            else:
                if (dest == conpath[-1]) and (departuretime.weekday()==arrivaltime.weekday()==6) and (arrivaltime.hour<=12):
                    departuretime = departuretime+timedelta(hours=24)
                    arrivaltime = arrivaltime+timedelta(hours=24)
                idealtimelist.append(departuretime)
                idealtimelist.append(arrivaltime)
                currtime = arrivaltime

        return idealtimelist
    except:
        return [dayzero]


# In[16]:

#deptime = datetime.strptime('2016-07-03 13:25:00',timeformatstring2)
#deptime = datetime.strptime('2016-07-03 05:00:00',timeformatstring2)
#now = datetime.strptime(str(datetime.now()).split('.')[0],timeformatstring2)
#getidealtimes(510990491,['BOMH','PNQH', 'SNRH', 'DULF'],'DELH','BOMH',deptime,now)
#getidealtimes(511000059,['CCUH','CCUC'],'DELH','CCUH',deptime,now)


# In[17]:

invsf['idealtimelist'] = invsf.apply(lambda x: getidealtimes(x['Con Number'],x['conpath'],x['Hub SC Location'],x['thcdest'],x['departtimefromcurrloc'],x['currtime'],x['Flag_Mark'],x['thcETA']))


# In[18]:

def geteta(x):
    try:
        return x[-1]
    except:
        return dayminu


# In[19]:

invsf['eta'] = invsf.apply(lambda x: geteta(x['idealtimelist']))
invsf = invsf[invsf['eta']!=dayminu]
#print len(invsf)


# In[20]:

#invsf


# In[21]:

check1 = (invsf[invsf['conpath']==['error']])
#print len(check1)
invsfinal = invsf[(invsf['eta']!=dayminu)]
print 'correct: '+' : '+str(len(invsfinal))


# In[22]:

def getreach(eta,duedt):
    duedtadj = duedt+timedelta(hours=14)
    if eta>duedtadj:
        return 0
    else:
        return 1
    
def correct_reach2(reach, reach2):
    if reach>reach2:
        return 1
    else:
        return reach2


ts= datetime.now()
opfilevar=ts.date()
opfilevar1=ts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=pd.np.round(float(currhrs)/60)

# In[23]:

invsf['reached'] = invsf.apply(lambda x: getreach(x['eta'],x['Duedt']))
reachpercent=  pd.np.ceil(invsf[invsf['reached']==1]['reached'].sum()*100.0/len(invsf['reached']))
intransitreachperc = pd.np.round(invsf[invsf['reached']==1]['reached'].sum()*100.0/len(invsf['reached']))
print intransitreachperc

def departurelate(deptimea, schtime, routecd, currloc, nxtloc):
    if routecd != '9888':
        return round((deptimea-schtime).total_seconds()*1.0/3600,1)
        
    else:
        if currloc=='BOMH' and nxtloc == 'DELH': #removing express vehicle
            deptime_BOMHDELH_total = lhscheduledf_dict.get(('BOMH', 'DELH'))
            deptime_BOMHDELH = deptime_BOMHDELH_total[0]
            deptime_BOMHDELH = [x for x in deptime_BOMHDELH if x != 7]
            return deptimea.hour - sorted(deptime_BOMHDELH)[-1]
        elif currloc=='DELH' and nxtloc == 'BLRH': #removing express vehicle
            deptime_DELHBLRH_total = lhscheduledf_dict.get(('DELH', 'BLRH'))
            deptime_DELHBLRH = deptime_DELHBLRH_total[0]
            deptime_DELHBLRH = [x for x in deptime_DELHBLRH if x != 12]
            return deptimea.hour - sorted(deptime_DELHBLRH)[-1]
        else: #last sch departure of a day for market benchmarking
            deptotal_forlatecalc = lhscheduledf_dict.get((currloc, nxtloc))
            if deptotal_forlatecalc is None:
                return 0.0
            else:
                deptime_forlatecalc = deptotal_forlatecalc[0]
                return deptimea.hour - sorted(deptime_forlatecalc)[-1]
                
invsf['dep_gap']= invsf.apply(lambda x: departurelate(x['departtimefromcurrloc'],x['sch_dep'], x['routecd'], x['Hub SC Location'], x['thcdest']))

def transitdelay(currloc1, nxtloc1, deptime1, currtimets1):
    try:
        check_arrvtime = getdeparturetime(currloc1, nxtloc1,deptime1)[1]
        if currtimets1>check_arrvtime:
            return 'Delay'
        else:
            return 'No'
    except:
        return 'No'
        
        
invsf['Transit']= invsf.apply(lambda x: transitdelay(x['Hub SC Location'],x['thcdest'], x['departtimefromcurrloc'], x['currtime']))


print 'length of invsf is', len(invsf)
invsf.save(r'D:\Python\Scripts and Files\Path and Graph Files\secto_buildup_routing_INTRANSIT\storage\data_storage\Data_intransit_reach_'+str(opfilevar)+str('_')+str(opfilevar2)+'.csv')
#invsf save as a file in server


# In[24]:

#grpinvsf = invsf.groupby(['Hub SC Location','thcdest'],{'concount': agg.COUNT_DISTINCT('Con Number'),'reached': agg.SUM('reached')})
#grpinvsf['reachedperc'] = pd.np.round(grpinvsf['reached']*100.0/grpinvsf['concount'], 1)
#grpinvsf[grpinvsf['concount']>100].sort_values('reachedperc',ascending=True)


# In[25]:

grpinvsf = invsf.groupby(['DEPARTED FRM CURRLOC THCNO','routecd','Hub SC Location','thcdest','departtimefromcurrloc','dep_gap','Transit'],{'concount': agg.COUNT_DISTINCT('Con Number'),'reached': agg.SUM('reached')})
grpinvsf['reachedperc'] = pd.np.round(grpinvsf['reached']*100.0/grpinvsf['concount'], 1)

grpinvsf = grpinvsf.sort_values('concount',ascending=False)


# In[26]:

columnlist = ['Hub SC Location', 'thcdest','routecd','departtimefromcurrloc','concount', 'reached','reachedperc','dep_gap', 'Transit']
grpinvsf_final = grpinvsf[columnlist]
grpinvsf_final = grpinvsf_final.rename({'Hub SC Location':'DepartLoc','departtimefromcurrloc':'DepartTime','concount':'con', 'reached':'Reach','reachedperc':'Reach%'})
#grpinvsf_final save as a file in server and attachment in mail

grpinvsf_final.save(r'D:\Python\Scripts and Files\Path and Graph Files\secto_buildup_routing_INTRANSIT\storage\Allgrpby.csv')
oppath0 = r'D:\Python\Scripts and Files\Path and Graph Files\secto_buildup_routing_INTRANSIT\storage\Allgrpby.csv'

grpinvsf_final['Timestamp'] = invsf['currtime'][0]
grpinvsf_final.save(r'D:\Python\Scripts and Files\Path and Graph Files\secto_buildup_routing_INTRANSIT\storage\allgroupby_storage\Allgrpby_'+str(opfilevar)+str('_')+str(opfilevar2)+'.csv')
#finalsf = grpinvsf_final[grpinvsf_final['con']>=100].sort_values('Reach%',ascending=True)
drop_ts = ['DepartLoc', 'thcdest','routecd','DepartTime','con', 'Reach','Reach%','dep_gap', 'Transit']
grpinvsf_final = grpinvsf_final[drop_ts]
finalsf = grpinvsf_final[grpinvsf_final['con']>=60]
finalsf = finalsf[finalsf['Reach%']<75]

finaldf = finalsf.to_dataframe()
#finaldf = pd.DataFrame(finaldf,columns=['DepartLoc','thcdest','routecd','con','Reach','Reach%','dep_gap','Transit','DepartTime'])
finaldf = finaldf.to_string(index=False)
#finaldf in mail body


# In[ ]:
filePath = oppath0
def sendEmail(TO = ["rajeesh.vr@spoton.co.in"],
            #TO = ["rajeesh.vr@spoton.co.in"],
            #TO = ["vishwas.j@spoton.co.in"],
            CC = ["vishwas.j@spoton.co.in"],
            #CC = ["sqtf@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "Intransit reach percentage " + '- ' + str(opfilevar)+str('-')+ str(opfilevar2)+" is " +str(intransitreachperc)+'%'
    body_text = """
    Dear All,
    
    Total expected Intransit Reach% is  """+str(intransitreachperc)+"""
    
    The data is for the vehicles which have >=60 cons and reach% less than 75%
    dep_gap: is the difference in hrs between the departure between and the schedule time
    For market vehicle (to be identified by 9888 routecd) the schedule time is taken as the last schedule time of a day.
    Negative no and zero in 'dep_gap' is a good news.
    Transit: is the remark column indicating whether there is an enroute delay for the vehicle
    
    PFB 
    
"""+str(finaldf)+"""

    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
#print('Email sent')
#Sending output file via mail ends



