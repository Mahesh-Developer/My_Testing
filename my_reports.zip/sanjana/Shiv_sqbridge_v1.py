# -*- coding: utf-8 -*-
"""
Created on Tue Jul 05 15:23:53 2016

@author: rajeeshv
"""

import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
import datetime
import os
import Utilities
#dsn = 'vishwas'
#user = 'sa'
#password = 'password@123'
#database = 'ESTL_CRP2'
#
#con_string = 'DSN=%s;UID=%s;PWD=%s;DATABASE=%s;' % (dsn, user, password, database)
#conn = pyodbc.connect(con_string)
#conn.autocommit = True
#cursor = conn.cursor()


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()

#cursor.execute("select TOP 10 DOCKNO from docket")
#rows = cursor.fetchall()
#for row in rows:
#    print row.DOCKNO
try:
    query = ("""
            EXEC USP_SQ_OPP_Failure_Analysis
            """)
    #rows = cursor.fetchall()
    #df = pd.DataFrame(query.fetchall())



    bridgeanalysisdf = pd.read_sql(query, Utilities.cnxn)
    #bridgeanalysisdf.to_csv(r'bridgeanalysisdf.csv')



    failpercgrby = bridgeanalysisdf.groupby(['SubCategoryOPP1']).agg({'DOCKNO':len}).reset_index()
    failperctotal = failpercgrby['DOCKNO'].sum()


    def failurepercalc(failureper):
        failperc = pd.np.round((failureper*1.0)/failperctotal,3)
        failperc_percentage = failperc*100
        return failperc_percentage

    failpercgrby['Percentage'] = failpercgrby.apply(lambda x:failurepercalc(x['DOCKNO']),axis=1)

    ## For appending TOTAL REACH at the end of OPP categories. Edit on 25-10-2016

    reachedconsdf = bridgeanalysisdf[bridgeanalysisdf['ARRVD_AT_DEST_BEF_CUTOFF']=='Y']
    reachedcons = len(reachedconsdf)

    totalduecons = len(bridgeanalysisdf)

    reachperc = pd.np.round((reachedcons*100.0)/totalduecons,2)

    sumlist_opp = ['Reach%',reachedcons,reachperc]
    col_list_opp = ['SubCategoryOPP1','DOCKNO','Percentage']
    totalsdf_opp = pd.DataFrame(data=[sumlist_opp], columns = col_list_opp)
    failpercgrby = failpercgrby.append(totalsdf_opp,ignore_index=True)

    ## For appending TOTAL REACH at the end of OPP categories. Edit on 25-10-2016


    originfail = bridgeanalysisdf[bridgeanalysisdf['SubCategoryOPP']=='Origin Failure']
    originfailgrby = originfail.groupby(['Orgn_Area']).agg({'DOCKNO':len}).reset_index()
    originfailgrby = originfailgrby.sort_values('DOCKNO',ascending=False)

    originhubfail = bridgeanalysisdf[bridgeanalysisdf['SubCategoryOPP']=='Origin Hub Failure']
    originhubfailgrby = originhubfail.groupby(['ORGN_HUB']).agg({'DOCKNO':len}).reset_index()
    originhubfailgrby = originhubfailgrby.sort_values('DOCKNO',ascending=False)

    lhfailure = bridgeanalysisdf[bridgeanalysisdf['SubCategoryOPP']=='Linehaul Failure']
    lhfailuregrby = lhfailure.groupby(['Lane']).agg({'DOCKNO':len}).reset_index()
    lhfailuregrby = lhfailuregrby.sort_values('DOCKNO',ascending=False)
    lhfailuregrbytop15 = lhfailuregrby.head(15)

    desthubfailure = bridgeanalysisdf[bridgeanalysisdf['SubCategoryOPP']=='Destination Hub Failure']
    desthubfailuregrpby = desthubfailure.groupby(['DESTN_HUB']).agg({'DOCKNO':len}).reset_index()
    desthubfailuregrpby = desthubfailuregrpby.sort_values('DOCKNO',ascending=False)

    destfeederfailure = bridgeanalysisdf[bridgeanalysisdf['SubCategoryOPP']=='Destination Feeder Failure']
    destfeederfailuregrpby = destfeederfailure.groupby(['DESTN_HUB']).agg({'DOCKNO':len}).reset_index()
    destfeederfailuregrpby = destfeederfailuregrpby.sort_values('DOCKNO',ascending=False)

    destfailure = bridgeanalysisdf[bridgeanalysisdf['SubCategoryOPP']=='Destination Failure']
    destfailuregrpby = destfailure.groupby(['Dest_Area']).agg({'DOCKNO':len}).reset_index()
    destfailuregrpby = destfailuregrpby.sort_values('DOCKNO',ascending=False)


    ### Hub Reach Add
    hubreachedconsdf = bridgeanalysisdf[bridgeanalysisdf['ARRV_AT_DESTHUB_BEF_CUTOFF']=='Y']
    hubreachedcons = len(hubreachedconsdf)

    hubreachperc = pd.np.round((hubreachedcons*100.0)/totalduecons,2)

    sumlist_hub = ['Hub_Reach%',hubreachedcons,hubreachperc]
    col_list_hub = ['SubCategoryOPP1','DOCKNO','Percentage']
    totalsdf_hub = pd.DataFrame(data=[sumlist_hub], columns = col_list_hub)
    failpercgrby = failpercgrby.append(totalsdf_hub,ignore_index=True)
    ### Hub Reach Add

    datetoday=datetime.datetime.today()
    datefilter = datetoday-timedelta(hours=24)
    datefilter=datefilter.date()
    datefilter

    oppath1 = r'D:\Data\OPP_failure_analysis\OPP_Failure_analysis_'+str(datefilter)+'.xlsx'
    with ExcelWriter(r'D:\Data\OPP_failure_analysis\OPP_Failure_analysis_'+str(datefilter)+'.xlsx') as writer:
        failpercgrby.to_excel(writer, sheet_name='Failure_Percentage',engine='xlsxwriter')
        originfailgrby.to_excel(writer, sheet_name='Origin_Failure',engine='xlsxwriter')
        originhubfailgrby.to_excel(writer, sheet_name='Origin_Hub_Failure',engine='xlsxwriter')
        lhfailuregrbytop15.to_excel(writer, sheet_name='Linehaul_Failure',engine='xlsxwriter')
        desthubfailuregrpby.to_excel(writer, sheet_name='Destination_Hub_Failure',engine='xlsxwriter')
        destfeederfailuregrpby.to_excel(writer, sheet_name='Destination_feeder_Failure',engine='xlsxwriter')
        destfailuregrpby.to_excel(writer, sheet_name='Destination_Failure',engine='xlsxwriter')

    filePath = oppath1
    def sendEmail(TO = ["rajesh.kumar@spoton.co.in","Jothi.Menon@Spoton.Co.In"],
                 #TO = ["vishwas.j@spoton.co.in"],
                 BCC =  ["shivananda.p@spoton.co.in"],
                 #BCC =  ["vishwas.j@spoton.co.in"],
                FROM="mis.ho@spoton.co.in"):
                # FROM="shivananda.p@spoton.co.in"):
        # HOST = "10.109.230.14"
        HOST = "smpt.spoton.co.in"
    #smtplib.SMTP('smtp.spoton.co.in', 25)

        msg = MIMEMultipart()
        msg["From"] = FROM
        msg["To"] = ",".join(TO)
        msg["BCC"] = ",".join(BCC)
        #msg["Subject"] = "DEPOTWISE OPS Bucket Stock  - "+ str(datefilter)
        msg["Subject"] = "OPP Failure Analysis - "+ str(datefilter)
        body_text = """
        Dear All,
        
        PFA yesterday's OPP Failure Analysis 
            
        
        Regards,
        Shivanand
        """
        if body_text:
            msg.attach( MIMEText(body_text) )
        part = MIMEBase('application', "octet-stream")
        part.set_payload( open(filePath,"rb").read() )
        Encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
        msg.attach(part)
        server=smtplib.SMTP('smtp.sendgrid.net', 587)
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login("spoton.net.in", "Star@123#")
        # server.login("shivananda.p@spoton.co.in", "Apri@2018")

        try:
            failed = server.sendmail(FROM, TO+BCC, msg.as_string())
            server.close()
        except Exception, e:
            errorMsg = "Unable to send email. Error: %s" % str(e)

    if __name__ == "__main__":
        sendEmail()
    print('Email sent')

except:

  TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in'] 
  CC=['mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "OPP Failure Analysis Error in Execution" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in OPP Failure Analysis'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO+CC, msg.as_string())
  server.quit()

#Sending output file via mail ends
##print df_verses.to_csv(r'C:\Data\pyodbc_test.csv')