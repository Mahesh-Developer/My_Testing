
# coding: utf-8

# In[ ]:


import numpy as np
import pandas as pd

from IPython import display
from datetime import datetime
from datetime import datetime,timedelta,date
from datetime import datetime, timedelta
import smtplib
import ftplib
import traceback
import calendar
import os
import pyodbc
#from pymongo import MongoClient
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from string import Template
import Utilities

# In[ ]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")


# In[ ]:
querydate=date.today()-timedelta(1)


query=("EXEC dbo.USP_DELV_EFF_SC_WISE_AIR 'S', '{0}', '{1}'").format(querydate,querydate)


# In[ ]:


df=pd.read_sql(query,cnxn)


# In[ ]:


len(df)


# In[ ]:


del_summary=df.pivot_table(index=['ControlArea','DEST_BRCD'],values=['Delivered','TOTAL'],aggfunc={'Delivered':sum,'TOTAL':sum},margins=True)


# In[ ]:


del_summary['DE%']=pd.np.round(del_summary['Delivered']*100.0/del_summary['TOTAL'],0)


# In[ ]:


del_summary=del_summary.replace([np.inf,-np.inf],np.nan).fillna(0)


# In[ ]:


del_summary['DE%']=del_summary['DE%'].astype(int)


# In[ ]:


##Pickup Summary


# In[ ]:


pkpquery=("EXEC dbo.CRM_WEEKLY_PERFORMANCE_SCWISE_DATA_SHIVA_AIR '{0}','{1}'").format(querydate,querydate)


# In[ ]:


pkp_df=pd.read_sql(pkpquery,cnxn)
len(pkp_df)


# In[ ]:


pkp_summary=pkp_df.pivot_table(index=['ControlArea', 'BRCD'],columns=['PICKUPSTATUS'],values=['REFNO'],aggfunc={'REFNO':len},margins=True,margins_name='Total')


# In[ ]:


pkp_summary['Pkp%']=pd.np.round(pkp_summary[('REFNO','SUCCESS')]*100.0/pkp_summary[('REFNO','Total')],0)


# In[ ]:


pkp_summary=pkp_summary.replace([np.inf,-np.inf],np.nan).fillna(0)


# In[ ]:


pkp_summary['Pkp%']=pkp_summary['Pkp%'].astype(int)


# In[ ]:


todate=datetime.strftime(datetime.now(),'%Y-%m-%d')
todate


# In[ ]:


df.to_csv(r'D:\Data\undel_mgt_air\Air_DE\Air_Delivered_Data'+str(todate)+'.csv')
df.to_csv(r'D:\Data\undel_mgt_air\Air_DE\Air_Delivered_Data.csv')


# In[ ]:


pkp_df.to_csv(r'D:\Data\undel_mgt_air\Air_Pickup\Air_Pickup_Data'+str(todate)+'.csv')
pkp_df.to_csv(r'D:\Data\undel_mgt_air\Air_Pickup\Air_Pickup_Data.csv')


# In[ ]:


filepath=r'D:\Data\undel_mgt_air\Air_DE\Air_Delivered_Data.csv'
filepath1=r'D:\Data\undel_mgt_air\Air_Pickup\Air_Pickup_Data.csv'


# In[ ]:


BCC=["rom_spot@spoton.co.in","aom_spot@spoton.co.in","dom_spot@spoton.co.in","sq_spot@spoton.co.in","sqtf@spoton.co.in","Air_Operation@spoton.co.in","mahesh.reddy@spoton.co.in"]
# BCC=['mahesh.reddy@spoton.co.in']
FROM="mis.ho@spoton.co.in"

msg = MIMEMultipart()
msg["From"] = FROM

msg["BCC"] = ",".join(BCC)

msg["Subject"] = "Delivery & Pickup Peformance - Air" + " - " + str(todate)

report=""
report+="Dear All"
report+='<br>'
report+='Please find the Delivery & Pickup Peformance for Air'
report+='<br>'
report+='Delivery Performance - Air'
report+='<br>'
report+='<br>'+del_summary.to_html()+'<br>'
report+='<br>'
report+='Pickup Performance - Air'
report+='<br>'
report+='<br>'+pkp_summary.to_html()+'<br>'
report+='<br>'


abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(filepath1,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
msg.attach(part1)


# server=smtplib.SMTP('smtp.sendgrid.net', 587)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("mahesh.reddy@spoton.co.in", "Nov@2018")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, BCC, msg.as_string())
server.quit()

