
# coding: utf-8

# In[1]:

import pandas as pd
from datetime import datetime, timedelta
from pandas import ExcelWriter
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
import os
import smtplib

import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import sys
import Utilities
reload(sys).setdefaultencoding("ISO-8859-1")

# In[2]:

datetoday=datetime.today()
datefilter = datetoday-timedelta(hours=24)
datefilter=datefilter.date()
datefilter
# In[3]:


# In[3]:

# In[4]:
def datetimeformatconvert(dep_load_unload_times):
    try:
        fulldate = datetime.strptime(dep_load_unload_times,'%d-%m-%Y %H:%M')
    except:
        fulldate = datetime.strptime(dep_load_unload_times,'%Y-%m-%d %H:%M:%S')
    return fulldate


# In[4]:

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()

query = ("""
        EXEC USP_THC_LOAD_UNLOAD_TARGET_VS_ACTUAL_PERFORMANCE_DATA 'M'
        """)
thcload_unloadtime = pd.read_sql(query, Utilities.cnxn)
thcload_unloadtime.to_csv(r'D:\Data\THC_Load_Unload_Efficiency\Revamped_18052017\Raw_data\THC_Load_Unload_Data_'+str(datefilter)+'.csv')
thcload_unloadtime.head()


# In[5]:

#thcload_unloadtime.to_csv(r'D:\Data\THC_Load_Unload_Efficiency\Basefile\THC_Load_Unload_Basefile_'+str(datefilter)+'.csv')

# In[6]:

#thcload_unloadtime = thcload_unloadtime.rename(columns={'\xef\xbb\xbfHub_Location':'Hub_Location'})
#stockdata=stockdata.rename(columns={'\xef\xbb\xbfPARENTCODE1':'PARENTCODE1'})
thcload_unloadtime.columns.tolist()


thcload_unloadtime = thcload_unloadtime.fillna(0)

keephublist = ['DELH','BLRH','BOMH','CCUH','BRGH','MAAH','AMDH','AMCH','HYDH','PNQH','NAGH','VPIH','JAIH','SNRH','IDRH','AGRB','KNPH','NDAH']

thcload_unloadtime = thcload_unloadtime[thcload_unloadtime['Hub_Location'].isin(keephublist)]


# In[6]:

# In[8]:

thcload_unloadtime['DEP_ARRIVAL_DATE'] = thcload_unloadtime.apply(lambda x: datetimeformatconvert(x['Departure_Or_Arrival_Date']),axis=1)
thcload_unloadtime['LOAD_UNLOAD_START'] = thcload_unloadtime.apply(lambda x: datetimeformatconvert(x['Load_unload_starttime']),axis=1)
thcload_unloadtime['LOAD_UNLOAD_END'] = thcload_unloadtime.apply(lambda x: datetimeformatconvert(x['Load_unload_endtime']),axis=1)

thcload_unloadtime['Starthr'] = thcload_unloadtime.apply(lambda x: (x['LOAD_UNLOAD_START'].hour),axis=1)
thcload_unloadtime['Endhr'] = thcload_unloadtime.apply(lambda x: (x['LOAD_UNLOAD_END'].hour),axis=1)


# In[7]:

# In[11]:

def turnarndtimecalc(loadunloadtype,deparrvltime,loadunloadstart,loadunloadend):
    if loadunloadtype == 'U':
        tat = (loadunloadend-deparrvltime)
        #tat = pd.np.round(tat,2)
    elif loadunloadtype == 'L':
        tat = (deparrvltime-loadunloadstart)
        #tat = pd.np.round(tat,2)
    else:
        tat = 'check'
    #return tat
    tathrs = round((tat.total_seconds()*1.0)/3600,2)
    if tathrs == 0:
        tathrs = 0.1
    return tathrs
    


# In[8]:

##thcload_unloadtime['TAT'] = thcload_unloadtime.apply(lambda x: turnarndtimecalc(x['Load_unload'],x['DEP_ARRIVAL_DATE'],x['LOAD_UNLOAD_START'],x['LOAD_UNLOAD_END']))
thcload_unloadtime['Turn_around_time'] = thcload_unloadtime.apply(lambda x: (turnarndtimecalc(x['Load_or_unload'],x['DEP_ARRIVAL_DATE'],x['LOAD_UNLOAD_START'],x['LOAD_UNLOAD_END'])),axis=1)

thcload_unloadtime = thcload_unloadtime[thcload_unloadtime['Turn_around_time']>=(-24.0)]
thcload_unloadtime = thcload_unloadtime[thcload_unloadtime['Turn_around_time']<=(24.0)]


#thcload_unloadtime.to_csv(r'thcload_unloadtime_excluding_data_error.csv')

# In[13]:

#thcload_unloadtime.to_csv('thcload_unloadtime_tatcheck.csv')


# In[14]:

def efficiencycal(tatperhr):
    idealtat = 3.0
    efficiency = pd.np.round((abs(tatperhr*idealtat)/13500.0)*100,0)
    return efficiency

def efficiencycal_thc(tatperhr_thc):
    idealtat_thc = 3.0
    thcefficiency = pd.np.round((abs(tatperhr_thc*idealtat_thc)/13500.0)*100,0)
    return thcefficiency

def efficiencycal_thc_buckets(thceffy):
    if thceffy<=50:
        return 'LOW'
    elif thceffy>50 and thceffy<=70:
        return 'MEDIUM'
    elif thceffy>70:
        return 'HIGH'
    else:
        return 'CHECK'


# In[9]:

# In[15]:

thcload_unloadtime['Load_unload_TAT_per_hr'] = thcload_unloadtime.apply(lambda x: round((x['Actual_load_unload_wt'])/(x['Turn_around_time']),0),axis=1)
thcload_unloadtime['THC_Efficiency'] = thcload_unloadtime.apply(lambda x: efficiencycal_thc(x['Load_unload_TAT_per_hr']),axis=1)

thcload_unloadtime['THC_Efficiency_Bucket'] = thcload_unloadtime.apply(lambda x: efficiencycal_thc_buckets(x['THC_Efficiency']),axis=1)


print 'total', len(thcload_unloadtime)
thcload_unloadtime_load_yday = thcload_unloadtime[thcload_unloadtime['DEP_ARRIVAL_DATE']>datefilter]
print 'yest', len(thcload_unloadtime_load_yday)
# In[10]:

# Finding THC Exceptions start
def exceptioncheck(loadunloadtype,deparrvltime,loadunloadstart,loadunloadend,tatloadunloadperhr):
    if loadunloadtype == 'U' and (deparrvltime>=loadunloadend):
        return 'Data_entry'
    elif loadunloadtype == 'L' and (loadunloadstart>=deparrvltime):
        return 'Data_entry'
    elif tatloadunloadperhr>=10000:
        return 'Check'
    else:
        return 'OK'
        
thcload_unloadtime['Exception'] = thcload_unloadtime.apply(lambda x: exceptioncheck(x['Load_or_unload'],x['Departure_Or_Arrival_Date'],x['Load_unload_starttime'],x['Load_unload_endtime'],x['Load_unload_TAT_per_hr']),axis=1)

thc_exceptionsdf = thcload_unloadtime[thcload_unloadtime['Exception']!='OK']
exceptionthcs = len(thc_exceptionsdf)
# Finding THC Exceptions end


# In[11]:

##thcload_unloadtime['Turn_around_time'] = thcload_unloadtime.apply(lambda x: round(x['TAT'],2))


# In[17]:

thcload_unloadtime_load = thcload_unloadtime[thcload_unloadtime['Load_or_unload']=='L']
thcload_unloadtime_unload = thcload_unloadtime[thcload_unloadtime['Load_or_unload']=='U']
print len(thcload_unloadtime_load),len(thcload_unloadtime_unload)


# In[12]:

# In[18]:

#thc_load_grpby = thcload_unloadtime_load.groupby(['Hub_Location'],{'TAT':agg.SUM('Turn_around_time'),'Actual_Load_or_Unload_Wt': agg.SUM('Actual_load_unload_wt'),'THC_L_Count': agg.COUNT('THC_Number')})
#thc_unload_grpby = thcload_unloadtime_unload.groupby(['Hub_Location'],{'TAT':agg.SUM('Turn_around_time'),'Actual_Load_or_Unload_Wt': agg.SUM('Actual_load_unload_wt'),'THC_U_Count': agg.COUNT('THC_Number')})


thc_load_grpby = thcload_unloadtime_load.groupby(['Hub_Location']).agg({'Turn_around_time':sum,'Actual_load_unload_wt': sum,'THC_Number': len}).reset_index()
thc_unload_grpby = thcload_unloadtime_unload.groupby(['Hub_Location']).agg({'Turn_around_time':sum,'Actual_load_unload_wt': sum,'THC_Number': len}).reset_index()


# In[19]:

thc_load_grpby = thc_load_grpby.rename(columns={'Turn_around_time':'TAT','THC_Number':'THC_L_Count','Actual_load_unload_wt':'Actual_Load_or_Unload_Wt'})
thc_unload_grpby = thc_unload_grpby.rename(columns={'Turn_around_time':'TAT','THC_Number':'THC_U_Count','Actual_load_unload_wt':'Actual_Load_or_Unload_Wt'})


# In[20]:

thc_load_grpby['Load_wt_TAT_perhr'] = thc_load_grpby.apply(lambda x: round((x['Actual_Load_or_Unload_Wt'])/(x['TAT']),0),axis=1)
thc_unload_grpby['Unload_wt_TAT_perhr'] = thc_unload_grpby.apply(lambda x:round((x['Actual_Load_or_Unload_Wt'])/(x['TAT']),0),axis=1)


# In[21]:

thc_load_grpby['Loading_Efficiency'] = thc_load_grpby.apply(lambda x: efficiencycal(x['Load_wt_TAT_perhr']),axis=1)
thc_unload_grpby['Unloading_Efficiency'] = thc_unload_grpby.apply(lambda x: efficiencycal(x['Unload_wt_TAT_perhr']),axis=1)


# In[13]:

thcsummary = pd.merge(thc_load_grpby,thc_unload_grpby,on='Hub_Location',how = 'outer')

thcsummary = thcsummary.rename(columns={'TAT_x':'TAT_Load','TAT_y':'TAT_Unload','Actual_Load_or_Unload_Wt_x':'Actual_Load_or_Unload_Wt_Load','Actual_Load_or_Unload_Wt_y':'Actual_Load_or_Unload_Wt_Unload'})

thcsummary = thcsummary.fillna(0)

thcsummary['TOTAL_THCs'] = thcsummary.apply(lambda x:x['THC_L_Count']+x['THC_U_Count'],axis=1)
thcsummary['TOTAL_ACT_WT'] = thcsummary.apply(lambda x:x['Actual_Load_or_Unload_Wt_Load']+x['Actual_Load_or_Unload_Wt_Unload'],axis=1)
thcsummary['TOTAL_TAT'] = thcsummary.apply(lambda x:x['TAT_Load']+x['TAT_Unload'],axis=1)


thcsummary['TOTAL_TAT_PER_HR'] = thcsummary.apply(lambda x: round((x['TOTAL_ACT_WT'])/(x['TOTAL_TAT']),0),axis=1)
thcsummary['TOTAL_EFFICIENCY'] = thcsummary.apply(lambda x: efficiencycal(x['TOTAL_TAT_PER_HR']),axis=1)
thcsummary['AVG_TAT_HRS'] = thcsummary.apply(lambda x: pd.np.round((13500.0/x['TOTAL_TAT_PER_HR']),0),axis=1)
thcsummary['Load_AVG_TAT_HRS'] = thcsummary.apply(lambda x: pd.np.round((13500.0/x['Load_wt_TAT_perhr']),0),axis=1)
thcsummary['Unload_AVG_TAT_HRS'] = thcsummary.apply(lambda x: pd.np.round((13500.0/x['Unload_wt_TAT_perhr']),0),axis=1)



thc_final_summary = pd.DataFrame(thcsummary,columns=['Hub_Location','TOTAL_THCs','TOTAL_ACT_WT','THC_L_Count','Loading_Efficiency','THC_U_Count','Unloading_Efficiency','TOTAL_EFFICIENCY','AVG_TAT_HRS','Load_AVG_TAT_HRS','Unload_AVG_TAT_HRS'])

totaldf = pd.DataFrame(thcsummary,columns=['Hub_Location','TOTAL_THCs','TOTAL_EFFICIENCY','AVG_TAT_HRS'])
loadingdf = pd.DataFrame(thcsummary,columns=['Hub_Location','THC_L_Count','Loading_Efficiency','Load_AVG_TAT_HRS'])
unloaddf = pd.DataFrame(thcsummary,columns=['Hub_Location','THC_U_Count','Unloading_Efficiency','Unload_AVG_TAT_HRS'])
# In[34]:

#thc_final_summary
thcsummary
totaldf_req = pd.DataFrame(thcsummary,columns=['Hub_Location','TOTAL_EFFICIENCY','AVG_TAT_HRS'])
loadingdf_req = pd.DataFrame(thcsummary,columns=['Hub_Location','Loading_Efficiency','Load_AVG_TAT_HRS'])
unloaddf_req = pd.DataFrame(thcsummary,columns=['Hub_Location','Unloading_Efficiency','Unload_AVG_TAT_HRS'])

totaldf_req = totaldf_req.rename(columns={'TOTAL_EFFICIENCY':'MTD_EFFY'})
loadingdf_req = loadingdf_req.rename(columns={'Loading_Efficiency':'MTD_Load_EFFY'})
unloaddf_req = unloaddf_req.rename(columns={'Unloading_Efficiency':'MTD_Unload_EFFY'})


# In[14]:

# In[18]:

#thc_load_grpby = thcload_unloadtime_load.groupby(['Hub_Location'],{'TAT':agg.SUM('Turn_around_time'),'Actual_Load_or_Unload_Wt': agg.SUM('Actual_load_unload_wt'),'THC_L_Count': agg.COUNT('THC_Number')})
#thc_unload_grpby = thcload_unloadtime_unload.groupby(['Hub_Location'],{'TAT':agg.SUM('Turn_around_time'),'Actual_Load_or_Unload_Wt': agg.SUM('Actual_load_unload_wt'),'THC_U_Count': agg.COUNT('THC_Number')})
thcload_unloadtime_load_yday = thcload_unloadtime_load[thcload_unloadtime_load['DEP_ARRIVAL_DATE']>=datefilter]
thcload_unloadtime_unload_yday = thcload_unloadtime_unload[thcload_unloadtime_unload['DEP_ARRIVAL_DATE']>=datefilter]
print len(thcload_unloadtime_load_yday)

thc_load_grpby_yday = thcload_unloadtime_load_yday.groupby(['Hub_Location']).agg({'Turn_around_time':sum,'Actual_load_unload_wt': sum,'THC_Number': len}).reset_index()
thc_unload_grpby_yday = thcload_unloadtime_unload_yday.groupby(['Hub_Location']).agg({'Turn_around_time':sum,'Actual_load_unload_wt': sum,'THC_Number': len}).reset_index()


# In[19]:

thc_load_grpby_yday = thc_load_grpby_yday.rename(columns={'Turn_around_time':'TAT','THC_Number':'THC_L_Count','Actual_load_unload_wt':'Actual_Load_or_Unload_Wt'})
thc_unload_grpby_yday = thc_unload_grpby_yday.rename(columns={'Turn_around_time':'TAT','THC_Number':'THC_U_Count','Actual_load_unload_wt':'Actual_Load_or_Unload_Wt'})


# In[20]:

thc_load_grpby_yday['Load_wt_TAT_perhr'] = thc_load_grpby_yday.apply(lambda x: round((x['Actual_Load_or_Unload_Wt'])/(x['TAT']),0),axis=1)
thc_unload_grpby_yday['Unload_wt_TAT_perhr'] = thc_unload_grpby_yday.apply(lambda x:round((x['Actual_Load_or_Unload_Wt'])/(x['TAT']),0),axis=1)


# In[21]:

thc_load_grpby_yday['Loading_Efficiency'] = thc_load_grpby_yday.apply(lambda x: efficiencycal(x['Load_wt_TAT_perhr']),axis=1)
thc_unload_grpby_yday['Unloading_Efficiency'] = thc_unload_grpby_yday.apply(lambda x: efficiencycal(x['Unload_wt_TAT_perhr']),axis=1)


# In[20]:

thcsummary_yday = pd.merge(thc_load_grpby_yday,thc_unload_grpby_yday,on='Hub_Location',how = 'outer')

thcsummary_yday = thcsummary_yday.rename(columns={'TAT_x':'TAT_Load','TAT_y':'TAT_Unload','Actual_Load_or_Unload_Wt_x':'Actual_Load_or_Unload_Wt_Load','Actual_Load_or_Unload_Wt_y':'Actual_Load_or_Unload_Wt_Unload'})

thcsummary_yday = thcsummary_yday.fillna(0)

thcsummary_yday['TOTAL_THCs'] = thcsummary_yday.apply(lambda x:x['THC_L_Count']+x['THC_U_Count'],axis=1)
thcsummary_yday['TOTAL_ACT_WT'] = thcsummary_yday.apply(lambda x:x['Actual_Load_or_Unload_Wt_Load']+x['Actual_Load_or_Unload_Wt_Unload'],axis=1)
thcsummary_yday['TOTAL_TAT'] = thcsummary_yday.apply(lambda x:x['TAT_Load']+x['TAT_Unload'],axis=1)


thcsummary_yday['TOTAL_TAT_PER_HR'] = thcsummary_yday.apply(lambda x: round((x['TOTAL_ACT_WT'])/(x['TOTAL_TAT']),0),axis=1)
thcsummary_yday['TOTAL_EFFICIENCY'] = thcsummary_yday.apply(lambda x: efficiencycal(x['TOTAL_TAT_PER_HR']),axis=1)
thcsummary_yday['AVG_TAT_HRS'] = thcsummary_yday.apply(lambda x: pd.np.round((13500.0/x['TOTAL_TAT_PER_HR']),0),axis=1)

#thcsummary_yday.to_csv(r'thcsummary_yday.csv')
thcsummary_yday['Load_AVG_TAT_HRS'] = thcsummary_yday.apply(lambda x: pd.np.round((13500.0/x['Load_wt_TAT_perhr']),0),axis=1)

def tohandlezeroulthcs(noofthcs,ultatperhr):
    if noofthcs != 0:
        unlavgtat = pd.np.round((13500.0/ultatperhr),0)    
    else:
        unlavgtat = 'No_THCs'
    return unlavgtat

thcsummary_yday['Unload_AVG_TAT_HRS'] = thcsummary_yday.apply(lambda x: tohandlezeroulthcs(x['THC_U_Count'],x['Unload_wt_TAT_perhr']),axis=1)

thc_final_summary_yday = pd.DataFrame(thcsummary_yday,columns=['Hub_Location','TOTAL_THCs','TOTAL_ACT_WT','THC_L_Count','Loading_Efficiency','THC_U_Count','Unloading_Efficiency','TOTAL_EFFICIENCY','AVG_TAT_HRS','Load_AVG_TAT_HRS','Unload_AVG_TAT_HRS'])

totaldf_yday = pd.DataFrame(thcsummary_yday,columns=['Hub_Location','TOTAL_THCs','TOTAL_EFFICIENCY','AVG_TAT_HRS'])
loadingdf_yday = pd.DataFrame(thcsummary_yday,columns=['Hub_Location','THC_L_Count','Loading_Efficiency','Load_AVG_TAT_HRS'])
unloaddf_yday = pd.DataFrame(thcsummary_yday,columns=['Hub_Location','THC_U_Count','Unloading_Efficiency','Unload_AVG_TAT_HRS'])
# In[34]:


totaldf_yday = totaldf_yday.rename(columns={'TOTAL_EFFICIENCY':'YDAY_EFFY','TOTAL_THCs':'THCs','AVG_TAT_HRS':'AVGHRS'})
loadingdf_yday = loadingdf_yday.rename(columns={'Loading_Efficiency':'YDAY_Load_EFFY','THC_L_Count':'THC_L','Load_AVG_TAT_HRS':'L_AVGHRS'})
unloaddf_yday = unloaddf_yday.rename(columns={'Unloading_Efficiency':'YDAY_Unload_EFFY','THC_U_Count':'THC_U','Unload_AVG_TAT_HRS':'U_AVGHRS'})


# In[21]:

final_totaldf = pd.merge(totaldf_yday,totaldf_req,on=['Hub_Location'],how='outer')
final_loaddf = pd.merge(loadingdf_yday,loadingdf_req,on=['Hub_Location'],how='outer')
final_unloaddf = pd.merge(unloaddf_yday,unloaddf_req,on=['Hub_Location'],how='outer')


# In[27]:
## Efficiency calculation for email body
tatsum = thcload_unloadtime['Turn_around_time'].sum()
loadsum = thcload_unloadtime['Actual_load_unload_wt'].sum()
idealtat = 3.0

tatloadperhr = (loadsum*1.0/tatsum)
total_overall_efficiency = pd.np.round(((tatloadperhr*idealtat)/13500.0)*100,0)
avghrs = pd.np.round((13500.0/tatloadperhr),0)


tatsum_yday = thcload_unloadtime_load_yday['Turn_around_time'].sum()
loadsum_yday = thcload_unloadtime_load_yday['Actual_load_unload_wt'].sum()
idealtat = 3.0

tatloadperhr_yday = (loadsum_yday*1.0/tatsum_yday)
total_overall_efficiency_yday = pd.np.round(((tatloadperhr_yday*idealtat)/13500.0)*100,0)
avghrs_yday = pd.np.round((13500.0/tatloadperhr_yday),0)


## Efficiency calculation for email body


final_totaldf = final_totaldf.rename(columns={'Hub_Location':'LOCN','AVG_TAT_HRS':'MTD_AVGHRS'})
final_loaddf = final_loaddf.rename(columns={'Hub_Location':'LOCN','YDAY_Load_EFFY':'YDAY_EFFY','MTD_Load_EFFY':'MTD_EFFY','Load_AVG_TAT_HRS':'L_MTD_AVGHRS'})
final_unloaddf = final_unloaddf.rename(columns={'Hub_Location':'LOCN','YDAY_Unload_EFFY':'YDAY_EFFY','MTD_Unload_EFFY':'MTD_EFFY','Unload_AVG_TAT_HRS':'U_MTD_AVGHRS'})

final_totaldf = final_totaldf.sort_values('YDAY_EFFY',ascending=True)
final_loaddf = final_loaddf.sort_values('YDAY_EFFY',ascending=True)
final_unloaddf = final_unloaddf.sort_values('YDAY_EFFY',ascending=True)
# In[28]:

thcload_unloadtime = thcload_unloadtime.drop(['Target_time_in_mins'],axis=1)

oppath1 = r'D:\Data\THC_Load_Unload_Efficiency\Revamped_18052017\Report\THC_LU_Efficiency_'+str(datefilter)+'.xlsx'
with ExcelWriter(r'D:\Data\THC_Load_Unload_Efficiency\Revamped_18052017\Report\THC_LU_Efficiency_'+str(datefilter)+'.xlsx') as writer:
    final_totaldf.to_excel(writer, sheet_name='TOTAL_SUMMARY',engine='xlsxwriter')
    final_loaddf.to_excel(writer, sheet_name='Load_SUMMARY',engine='xlsxwriter')
    final_unloaddf.to_excel(writer, sheet_name='Unload_SUMMARY',engine='xlsxwriter')
    thcload_unloadtime.to_excel(writer, sheet_name='THC_DATA',engine='xlsxwriter')

# final_totaldf = final_totaldf.to_string(index=False)
# final_loaddf = final_loaddf.to_string(index=False)
# final_unloaddf = final_unloaddf.to_string(index=False)
# In[ ]:
filePath = oppath1
# def sendEmail(TO = ["hubmgr_spot@spoton.co.in","ROM_SPOT@spoton.co.in","dinesh.kumar.sharma@spoton.co.in","avinash.singh@spoton.co.in","ashwani.gangwar@spoton.co.in","sreedhar.m@spoton.co.in"],
#             #TO = ["supratim@iepfunds.com","Ankit@iepfunds.com"],
#             #TO = ["vishwas.j@spoton.co.in"],
#             #CC = ["vishwas.j@spoton.co.in"],
#             #CC = ["vishwas.j@spoton.co.in","rajeesh.vr@spoton.co.in"],
#             CC = ["supratim@iepfunds.com","pawan.sharma@spoton.co.in","krishna.chandrasekar@spoton.co.in","Ankit@iepfunds.com","abhik.mitra@spoton.co.in","prasanna.hegde@spoton.co.in","vishwas.j@spoton.co.in","rajeesh.vr@spoton.co.in","Rajesh.Kumar@Spoton.Co.In","shivananda.p@spoton.co.in","anitha.thyagarajan@spoton.co.in","sharanagouda.biradar@spoton.co.in"],
#             FROM="mahesh.reddy@spoton.co.in"):
#     HOST = "smtp.spoton.co.in"
# #smtplib.SMTP('smtp.spoton.co.in', 25)

#     msg = MIMEMultipart()
#     msg["From"] = FROM
#     msg["To"] = ",".join(TO)
#     msg["CC"] = ",".join(CC)
#     msg["Subject"] = "Linehaul Load Unload Efficiency MTD & YDAY " + '- ' + str(datefilter)
#     body_text = """
#     Dear All,
    
#     PFA the Linehaul_Vehicle_Load_Unload_Efficiency for """+str(datefilter)+ """
    
#     Total efficiency for  """+str(datefilter)+ """ is """+str(total_overall_efficiency_yday)+"""%
#     Average hours for Loading/Unloading """+str(datefilter)+ """ is """+str(avghrs_yday)+""" HRS
#     MTD Total efficiency is """+str(total_overall_efficiency)+"""%
    
#     PFB the Overall Summary
    
# """+str(final_totaldf)+"""    

#     PFB the Loading efficiency summary
    
# """+str(final_loaddf)+"""  

#     PFB the Unloading Efficiency summary
    
# """+str(final_unloaddf)+"""  

#     Details :
    
#     This report has details on the Loading/Unloading efficiency of the THCs whose actual arrivals and actual departures wereduring this month
#     In addition to yesterday's loading/unloading efficiency, the report also has MTD efficency. The average hours to load/unload vehicles both MTD & Yesterday is also mentioned. 
    
#     Turn around time(TAT) :
#     TAT for loading = (Departure time of vehicle - Loading start time)
#     TAT for unloading = (Arrival time of vehicle - Unloading end time)
#     Efficiency:
#     Loading efficiency - Actual Weight loaded in total time / Ideal Weight to be loaded in total time
#     Unloading efficiency - Actual Weight unloaded in total time / Ideal weight to be unloaded in total time
    
#     Note: For a 13.5T vehicle, Ideal TAT is 3 hours ie.., in 3 hours a 13.5T vehicle to be unloaded/loaded completely    
# """

#     if body_text:
#         msg.attach( MIMEText(body_text) )
#     part = MIMEBase('application', "octet-stream")
#     part.set_payload( open(filePath,"rb").read() )
#     Encoders.encode_base64(part)
#     part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
#     msg.attach(part)
#     server=smtplib.SMTP('smtp.sendgrid.net', 587)
#     server.ehlo()
#     server.starttls()
#     server.ehlo()
#     server.login("spoton.net.in", "Star@123#")

#     try:
#         failed = server.sendmail(FROM, TO+CC, msg.as_string())
#         server.close()
#     except Exception, e:
#         errorMsg = "Unable to send email. Error: %s" % str(e)

# if __name__ == "__main__":
#     sendEmail()
# print('Email sent')
#Sending output file via mail ends
print (type(final_totaldf))
# cols=['THCs','YDAY_EFFY','AVGHRS','MTD_EFFY','MTD_AVGHRS']
final_totaldf['THCs']=final_totaldf['THCs'].astype(int)
final_totaldf['YDAY_EFFY']=final_totaldf['YDAY_EFFY'].astype(int)
final_totaldf['AVGHRS']=final_totaldf['AVGHRS'].astype(int)
final_totaldf['MTD_EFFY']=final_totaldf['MTD_EFFY'].astype(int)
final_totaldf['MTD_AVGHRS']=final_totaldf['MTD_AVGHRS'].astype(int)
# final_totaldf[cols] = final_totaldf[cols].apply(pd.to_numeric, errors='coerce')
print (final_totaldf)
#THC_L  YDAY_EFFY  L_AVGHRS  MTD_EFFY  L_MTD_AVGHRS
final_loaddf['THC_L']=final_loaddf['THC_L'].astype(int)
final_loaddf['YDAY_EFFY']=final_loaddf['YDAY_EFFY'].astype(int)
final_loaddf['L_AVGHRS']=final_loaddf['L_AVGHRS'].astype(int)
final_loaddf['MTD_EFFY']=final_loaddf['MTD_EFFY'].astype(int)
final_loaddf['L_MTD_AVGHRS']=final_loaddf['L_MTD_AVGHRS'].astype(int)

#THC_U  YDAY_EFFY  U_AVGHRS  MTD_EFFY  U_MTD_AVGHRS
final_unloaddf['THC_U']=final_unloaddf['THC_U'].astype(int)
final_unloaddf['YDAY_EFFY']=final_unloaddf['YDAY_EFFY'].astype(int)
print (final_unloaddf)
final_unloaddf['U_AVGHRS']=final_unloaddf['U_AVGHRS'].astype(int)
final_unloaddf['MTD_EFFY']=final_unloaddf['MTD_EFFY'].astype(int)
final_unloaddf['U_MTD_AVGHRS']=final_unloaddf['U_MTD_AVGHRS'].astype(int)

from datetime import date,timedelta
todate=date.today()-timedelta(1)
today_date=datetime.strftime(todate,'%d-%m-%Y')
today_date
#vishwas.j@spoton.co.in
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

#TO=['mahesh.reddy@spoton.co.in']
TO = ["hubmgr_spot@spoton.co.in","baskar.t@spoton.co.in","ROM_SPOT@spoton.co.in","dinesh.kumar.sharma@spoton.co.in","avinash.singh@spoton.co.in","ashwani.gangwar@spoton.co.in","sreedhar.m@spoton.co.in"]
# TO=['vishwas.j@spoton.co.in,
# CC=['vishwas.j@spoton.co.in']
FROM="reports.ie@spoton.co.in"
BCC=['abhishek.cv@spoton.co.in','mahesh.reddy@spoton.co.in']
CC = ["pawan.sharma@spoton.co.in","krishna.chandrasekar@spoton.co.in","abhik.mitra@spoton.co.in","prasanna.hegde@spoton.co.in","Rajesh.Kumar@Spoton.Co.In","shivananda.p@spoton.co.in","anitha.thyagarajan@spoton.co.in","sharanagouda.biradar@spoton.co.in","satya.pal@spoton.co.in"]
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = "Linehaul Load Unload Efficiency MTD & YDAY " + '- ' + str(datefilter)
html='''<html>
<style>
p
{
  margin:0;
  margin-top: 5px;
  padding:0;
  font-size:17px;
    line-height:20px;
}
</style>
<h4>Dear All,</h4>
<p>PFA the Linehaul_Vehicle_Load_Unload_Efficiency for $datefilter.</p>
<p>Total efficiency for $datefilter is $total_overall_efficiency_yday%</p>
<p>Average hours for Loading/Unloading $datefilter is $avghrs_yday HRS</p>
<p>MTD Total efficiency is $total_overall_efficiency</p>
<p>PFB the Overall Summary</p>
</html>'''

html3='''
<h4>PFB the Loading efficiency summary</h4>
'''
html4='''
<h4>PFB the Unloading Efficiency summary</h4>
'''
html5='''
<p>Details :
<p>This report has details on the Loading/Unloading efficiency of the THCs whose actual arrivals and actual departures wereduring this month</p>
<p>In addition to yesterday's loading/unloading efficiency, the report also has MTD efficency. The average hours to load/unload vehicles both MTD & Yesterday is also mentioned. </p>    
<p>Turn around time(TAT) :</p>
<p>TAT for loading = (Departure time of vehicle - Loading start time)</p>
<p>TAT for unloading = (Arrival time of vehicle - Unloading end time)</p>
<p>Efficiency:</p>
<p>Loading efficiency - Actual Weight loaded in total time / Ideal Weight to be loaded in total time</p>
<p>Unloading efficiency - Actual Weight unloaded in total time / Ideal weight to be unloaded in total time</p>
<p>Note: For a 13.5T vehicle, Ideal TAT is 3 hours ie.., in 3 hours a 13.5T vehicle to be unloaded/loaded completely</p>
'''
s = Template(html).safe_substitute(total_overall_efficiency=total_overall_efficiency,avghrs_yday=avghrs_yday,datefilter=datefilter,total_overall_efficiency_yday=total_overall_efficiency_yday)
report=""
report+=s
report+='<br>'
report+='<br>'+final_totaldf.to_html()+'<br>'
report+='<br>'
report+=html3
report+='<br>'+final_loaddf.to_html()+'<br>'
report+='<br>'
report+=html4
report+='<br>'+final_unloaddf.to_html()+'<br>'
report+=html5
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filePath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()


