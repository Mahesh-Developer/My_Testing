
# coding: utf-8

# In[1]:

import graphlab as gl
import graphlab.aggregate as agg
import pandas as pd
from datetime import datetime, timedelta
import time
from itertools import chain, islice, repeat, imap,izip,starmap,product
import random
import timeit as t


# In[2]:
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
import os
import ftplib
import traceback

# In[4]:

#conthc = gl.SFrame('conthcdf.csv')
#conthc = gl.SFrame(r'http://spoton.co.in/downloads/IEP_DUEDATE_DATA_REPORT/IEP_DUEDATE_DATA_REPORT.csv')
conthc = gl.SFrame(r'D:\Python\Scripts and Files\Path and Graph Files\Due_date_diagnostic_inputs\Duedate_02052017.csv')
pathsf = gl.SFrame.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\Due_date_diagnostic_inputs\final_pathv3.csv')
lhscheduledf = gl.SFrame.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\Due_date_diagnostic_inputs\Timegraph.csv')
vbdf = pd.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\Due_date_diagnostic_inputs\Hublist.csv')


# In[5]:

conthc = conthc.rename({'\xef\xbb\xbfDOCKNO': 'DOCKNO'})


# In[6]:

#conthc.column_names()


# In[7]:

print len(conthc)


# In[8]:

#conthc = conthc.filter_by(['NULL'],'arrv_dt', exclude=True).filter_by(['NULL'],'dept_dt', exclude=True)
conthc = conthc.filter_by([''],'arrv_dt', exclude=True).filter_by([''],'dept_dt', exclude=True)


# In[9]:

print len(conthc)


# In[10]:

timeformatstring = '%d/%m/%Y %H:%M'
timeformatstring1 = '%d-%m-%Y %H:%M'
timeformatstring2 = '%Y-%m-%d %H:%M:%S'
#dayzero = datetime.strptime('1/1/2015 00:00', timeformatstring)
#dayminu = datetime.strptime('1/1/2014 00:00', timeformatstring)
dayzero = datetime.strptime('2015-1-1 00:00:00', timeformatstring2)
dayminu = datetime.strptime('2014-1-1 00:00:00', timeformatstring2)
dayzero, dayminu


# In[11]:

#conthc['dept_dt'][0], conthc['arrv_dt'][0], conthc['DUE_DATE'][0]


# In[12]:

conthc['dept_dt']= conthc.apply(lambda x: datetime.strptime(x['dept_dt'],timeformatstring2))
conthc['arrv_dt']= conthc.apply(lambda x: datetime.strptime(x['arrv_dt'],timeformatstring2))
conthc['DUE_DATE']= conthc.apply(lambda x: datetime.strptime(x['DUE_DATE'],timeformatstring2))


## Edited to exclude ODA extra days from DUEDATE
conthc = conthc.fillna('ODAExtraTransitDay', 0)
conthc['DUE_DATE'] = conthc.apply(lambda x: x['DUE_DATE']-timedelta (days=int(x['ODAExtraTransitDay'])))
## Edited to exclude ODA extra days from DUEDATE

# In[13]:

def getatdestn(currloc, destination):
    if currloc == destination:
        return 'Yes'
    else:
        return 'No'


# In[14]:

conthc['at_destn'] = conthc.apply(lambda x: getatdestn(x['DOC_CURLOC'],x['DESTN']))


# In[15]:

lhscheduledfgrp = lhscheduledf.groupby(['Origin','Destination','Type'],{'Departure Time':agg.CONCAT('Departure Time'),'Total leg TT': agg.CONCAT('Total leg TT')})
lhscheduledf_dict = {}
for org, dest, deptime, transithrs,vbtype in izip(lhscheduledfgrp['Origin'], lhscheduledfgrp['Destination'],
                                     lhscheduledfgrp['Departure Time'], lhscheduledfgrp['Total leg TT'], lhscheduledfgrp['Type']):
    lhscheduledf_dict[(org, dest)] = [deptime,transithrs,vbtype]


# In[16]:

path_dict = {}
for org, dest, paths in izip(pathsf['Origin'], pathsf['Destination'],pathsf['pathlist']):
    path_dict[(org, dest)] = paths


# In[17]:

def getconpath(origin,location,destination):
    #print origin, location, destination
    try:
        conpathall1 = path_dict.get((origin,destination))
        if conpathall1 is None:
            conpathall = None
        else:
            conpathall = [i for i in conpathall1 if location in i]
        auxpathall = path_dict.get((location,destination))
        if conpathall is None:
            conpathall = []
        if auxpathall is None:
            auxpathall = []
        if (len(conpathall)==0) and (len(auxpathall)==0):
            return ['error']
        elif (len(conpathall)==0):
            lenlist = [len(i) for i in auxpathall]
            return auxpathall[lenlist.index(min(lenlist))]
        else:
            lenlist = [len(i) for i in conpathall]
            minconpath = conpathall[lenlist.index(min(lenlist))]
            return minconpath[minconpath.index(location):]
    except:
        ['checkerror']


# In[18]:

def getdeparturetime(org, dest, currtime):
    try:
        currtimedt = str(currtime).split(' ')[0]+' 00:00:00'
        currtimedt = datetime.strptime(currtimedt,'%Y-%m-%d %H:%M:%S')
        deptime_total = lhscheduledf_dict.get((org, dest))
        if deptime_total is None:
            return dayzero, dayzero
        deptime, transithrs, vbtype = deptime_total
        if vbtype == 'Normal':
            timerellist = []
            for i in range(0,len(deptime)):
                deptime1 = timedelta(hours=deptime[i])+(currtimedt)
                deptime2 = timedelta(hours=(deptime[i]+24.0))+(currtimedt)
                arrtime1 = deptime1 + timedelta(hours=transithrs[i])
                arrtime2 = deptime2 + timedelta(hours=transithrs[i])
                if deptime1<=currtime:
                    timerellist.append((deptime2,arrtime2))
                else:
                    timerellist.append((deptime1,arrtime1))
            
            sorted_by_first = sorted(timerellist, key=lambda tup: tup[0], reverse=False)
            return sorted_by_first[0][0],sorted_by_first[0][1]
        elif vbtype == 'VB':
            deptime = timedelta(hours=3.0)+(currtime)
            return deptime,deptime
    except:
        return dayzero,dayzero


# In[19]:

def getidealtimes(con,conpath,pickuptime):
    ### pickuptime is current time
    try:
        idealtimelist = []
        currtime = pickuptime
        idealtimelist.append(pickuptime)
        for i in range (1,len(conpath)):
            org = conpath[i-1]
            dest = conpath[i]
            departuretime,arrivaltime = getdeparturetime(org,dest,currtime)
            if (departuretime==dayzero)or(arrivaltime==dayzero):
                idealtimelist=[dayzero]
                break    
            else:
                if (dest == conpath[-1]) and (departuretime.weekday()==arrivaltime.weekday()==6) and (arrivaltime.hour<=12):
                    departuretime = departuretime+timedelta(hours=24)
                    arrivaltime = arrivaltime+timedelta(hours=24)
                idealtimelist.append(departuretime)
                idealtimelist.append(arrivaltime)
                currtime = arrivaltime

        return idealtimelist
    except:
        return [dayzero]


# In[20]:

def getdepartedvehicletime(thcorigin, thcdest,actualdeptime):
    try:
        deptime_total = lhscheduledf_dict.get((thcorigin, thcdest))
        if deptime_total is None:
            return dayzero, dayzero
        deptime, transithrs, vbtype = deptime_total
        if vbtype == 'Normal':
            timerellist = []
            for i in range(0,len(deptime)):
                deptime1 = actualdeptime
                arrtime1 = actualdeptime + timedelta(hours=transithrs[i])
                timerellist.append((deptime1,arrtime1))
            
            sorted_by_first = sorted(timerellist, key=lambda tup: tup[0], reverse=False)
            return sorted_by_first[0][0],sorted_by_first[0][1]
        elif vbtype == 'VB':
            arrtime = timedelta(hours=1.0)+(actualdeptime)
            return arrtime,arrtime
    except:
        return dayzero,dayzero
        


# In[21]:

def getidealtimes_source(con,conpath,thcorigin,thcdest,deptime):
    ### pickuptime is current time
    try:
        idealtimelist = []
        idealtimelist.append(deptime)
        currtime = getdepartedvehicletime(thcorigin, thcdest,deptime)[1]
        idealtimelist.append(currtime)
        for i in range (2,len(conpath)):
            org = conpath[i-1]
            dest = conpath[i]
            departuretime,arrivaltime = getdeparturetime(org,dest,currtime)
            if (departuretime==dayzero)or(arrivaltime==dayzero):
                idealtimelist=[dayzero]
                break    
            else:
                if (dest == conpath[-1]) and (departuretime.weekday()==arrivaltime.weekday()==6) and (arrivaltime.hour<=12):
                    departuretime = departuretime+timedelta(hours=24)
                    arrivaltime = arrivaltime+timedelta(hours=24)
                idealtimelist.append(departuretime)
                idealtimelist.append(arrivaltime)
                currtime = arrivaltime

        return idealtimelist
    except:
        return [dayzero]



# In[22]:

conthc['conpath_source'] = conthc.apply(lambda x: getconpath(x['ORGIN'],x['sourcehub'],x['DESTN']))
conthc['conpath_toloc'] = conthc.apply(lambda x: getconpath(x['ORGIN'],x['TOHUB_BR'],x['DESTN']))


# In[23]:

conthc['idealtimelist_source'] = conthc.apply(lambda x: getidealtimes_source(x['DOCKNO'],x['conpath_source'],x['sourcehub'],x['TOHUB_BR'],x['dept_dt']))
conthc['idealtimelist_toloc'] = conthc.apply(lambda x: getidealtimes(x['DOCKNO'],x['conpath_toloc'],x['arrv_dt']))

conthc.save('conthc_check.csv')
# In[24]:

dayzero_conlist_s = list(conthc[conthc['idealtimelist_source']==[dayzero]]['DOCKNO'])
dayzero_conlist_t = list(conthc[conthc['idealtimelist_toloc']==[dayzero]]['DOCKNO'])
print dayzero_conlist_s, type(dayzero_conlist_s)


# In[25]:

conthc = conthc.filter_by(dayzero_conlist_s, 'DOCKNO', exclude=True)
conthc = conthc.filter_by(dayzero_conlist_t, 'DOCKNO', exclude=True)


# In[26]:

conthc = conthc[conthc['idealtimelist_source']!=[dayzero]]
conthc = conthc[conthc['idealtimelist_toloc']!=[dayzero]]


# In[27]:

def geteta(x):
    try:
        return x[-1]
    except:
        return dayminu

def getreach(dockno, eta,duedt):
    ##print dockno, eta, duedt
    duedtadj = duedt+timedelta(hours=14)
    ##print duedtadj
    
    if eta<=duedtadj:
        ##print 'inside if', 0, dockno, eta, duedt
        return 0
    else:
        if eta.hour <= 13:
            eta_delivery = eta.date()
        else:
            eta_delivery = (eta+timedelta(days=1)).date()
        td = (eta_delivery - duedt.date()).days
        ##print 'inside else', td, dockno, eta, duedt
        return td
        


# In[28]:

conthc['eta_source'] = conthc.apply(lambda x: geteta(x['idealtimelist_source']))
conthc['eta_toloc'] = conthc.apply(lambda x: geteta(x['idealtimelist_toloc']))


# In[29]:

conthc = conthc[conthc['eta_source']!=dayminu]
conthc = conthc[conthc['eta_toloc']!=dayminu]


# In[30]:

#help needed: some cons like 511201627 is not appearing in the below print statements. The arrival at dest SC for this con is
#at 1416 hrs of its due date. But its 'reach_source' is 0. Not able to debug because of it's absence
conthc['reach_source'] = conthc.apply(lambda x: getreach(x['DOCKNO'],x['eta_source'],x['DUE_DATE']))
conthc['reach_toloc'] = conthc.apply(lambda x: getreach(x['DOCKNO'],x['eta_toloc'],x['DUE_DATE']))


# In[31]:

len(conthc)


# In[32]:

conthcfailed = conthc[conthc['REACH']=='NO']


# In[33]:

conthcfailedts = conthcfailed.groupby(['DOCKNO','at_destn'],{'org': agg.CONCAT('sourcehub'),'dest': agg.CONCAT('TOHUB_BR'),'reach_source': agg.CONCAT('reach_source'),'reach_toloc': agg.CONCAT('reach_toloc'), 'conpath_source': agg.CONCAT('conpath_source'), 'conpath_toloc': agg.CONCAT('conpath_toloc')})


# In[34]:

conthcfailed_dict = {}
for con,org,reach_source,dest,reach_toloc,atdest,conpath_toloc in izip(conthcfailedts['DOCKNO'],conthcfailedts['org'],conthcfailedts['reach_source'],conthcfailedts['dest'],conthcfailedts['reach_toloc'], conthcfailedts['at_destn'],conthcfailedts['conpath_toloc']):
    conthcfailed_dict.update({con: (org,reach_source,dest,reach_toloc, atdest,conpath_toloc)})


# In[35]:

reason_dict = {}
for con in conthcfailed_dict:
    
    vals = conthcfailed_dict.get(con)
    sourcelist = vals[0]
    toloclist = vals[2]
    source_delays = vals[1]
    toloc_delays = vals[3]
    atdest = vals[4]
    conpath_toloc = vals[5]
    source_hike_node = -1
    toloc_hike_node = -1
    if len(sourcelist) == 1:
        if source_delays[0] > 0:
            source_hike_node = 0
    else: 
        for i in range (0, len(sourcelist)-1):
            if source_delays[0] > 0:
                source_hike_node = 0
                break
            #print con, len(sourcelist), source_delays, 'i is', i
            if source_delays[i+1]>source_delays[i]:
                source_hike_node = i+1
                break 
                
    if len(toloclist) == 1:
        if toloc_delays[0] > 0:
            toloc_hike_node = 0
    else:  
        for i in range (0, len(toloclist)-1):
            if toloc_delays[0] > 0:
                toloc_hike_node = 0
                break
            if toloc_delays[i+1] > toloc_delays[i]:
                toloc_hike_node = i+1
                break
    #print con, source_hike_node, toloc_hike_node  
    #print source, toloc
    
    if toloc_delays[len(toloclist)-1]== 0: #to exclude which has reached the dest SC on time
        if atdest == 'Yes':
            reason_dict.update({con: ('Reached','Lastvalue0',source_hike_node,toloc_hike_node)})
        else:
            try:
                nxtloctn = conpath_toloc[len(toloclist)-1][1]
            except:
                nxtloctn = 'error'
            reason_dict.update({con: ('Location',str(toloclist[len(toloclist)-1])+str('-')+str(nxtloctn),source_hike_node,toloc_hike_node)})
            #Loc-ND
    elif source_hike_node == -1:
        toloc_hike_node = len(toloclist)
        source_hike_node = len(sourcelist)
        reason_dict.update({con: ('LH',str(sourcelist[-1])+str('-')+str(toloclist[-1]),source_hike_node,toloc_hike_node)})
        #LastLeg
        #print 'nothing'
    else:
        if source_hike_node == toloc_hike_node:
            #print 'location', source[source_hike_node]
            reason_dict.update({con: ('Location',str(sourcelist[source_hike_node])+str('-')+str(toloclist[toloc_hike_node]),source_hike_node,toloc_hike_node)})
        else:
            #print 'LH>', source[toloc_hike_node-1],toloc[toloc_hike_node]
            reason_dict.update({con: ('LH',str(sourcelist[toloc_hike_node])+str('-')+str(toloclist[toloc_hike_node]),source_hike_node,toloc_hike_node)})
    
    
    


# In[36]:

reasonsf = gl.SFrame()
conlist = []
categorylist = []
specificlist = []
sourcehnlist = []
tolochnlist = []
xy = ['DOCKNO', 'Reason', 'Specific_Pt', 'S_hikenode', 'T_hikenode']
for con1 in reason_dict:
    vals1 = reason_dict.get(con1)
    category = vals1[0]
    specific_pt = vals1[1]
    s_hn = vals1[2]
    tl_hn = vals1[3]
    conlist.append(con1)
    categorylist.append(category)
    specificlist.append(specific_pt)
    sourcehnlist.append(s_hn)
    tolochnlist.append(tl_hn)


# In[37]:

conarray = gl.SArray(conlist)
categoryarray = gl.SArray(categorylist)
specificarray = gl.SArray(specificlist)
source_hnarray = gl.SArray(sourcehnlist)
toloc_hnarray = gl.SArray(tolochnlist)

reasonsf.add_column(conarray, name='DOCKNO')
reasonsf.add_column(categoryarray, name='Reason')
reasonsf.add_column(specificarray, name='specific_pt')
reasonsf.add_column(source_hnarray, name='S_hikenode')
reasonsf.add_column(toloc_hnarray, name='T_hikenode')
#reasonsf


# In[38]:

finalsf = conthcfailedts.join(reasonsf, on='DOCKNO', how='left')


# In[39]:

def finderror(sourcepath, tolocpath):
    if 'error' in [j for i in sourcepath for j in i]:
        return 'found error'
    elif 'error' in [j for i in tolocpath for j in i]:
        return 'found error'
    else: 
        return 'clean'
    


# In[40]:

finalsf['check_error'] = finalsf.apply(lambda x: finderror(x['conpath_source'],x['conpath_toloc']))
#finaldf = finaldf[finaldf['conpath_source'].str.contains('error')]
#df3= paths[(paths['Destination']== destinationtcr) & (paths['Path1'].str.contains(currloc))]


# In[41]:

finalsf = finalsf[finalsf['check_error']=='clean']   


# In[42]:

finalsf = finalsf[finalsf['Reason']!='Reached'] #eliminate where getting as reached  To remove comment


# In[43]:

datetoday = datetime.today()
datefilter = datetoday-timedelta(hours=24)
datefilter=datefilter.date()
datefilter


basedata = conthcfailed.join(finalsf, on='DOCKNO',how='inner')
#basedata.save('basedata.csv')
basedatadf = basedata.to_dataframe()

#basedatadf.to_csv(r'D:\Data\Duedate_diagnostic\Basedata\Duedate_diagnostic_data_'+str(datefilter)+'.csv')
basedatadf.to_csv(r'D:\Data\Duedate_diagnostic\Basedata\Duedate_diagnostic_data_02052017.csv')

basedatadf.to_csv(r'D:\Data\Duedate_diagnostic\Duedate_diagnostic_data.csv')  
#basedatadf.to_csv(r'D:\Data\Duedate_diagnostic\Duedate_diagnostic_data_test.csv')  # To remove line
oppath_data = r'D:\Data\Duedate_diagnostic\Duedate_diagnostic_data.csv'

#fosdhfsodhfodsh  ##To remove comment
## Edit for Oneline LH THC data for JM
basedatadf['Concate'] = basedatadf.apply(lambda x:(x['sourcehub']+str('-')+x['TOHUB_BR']),axis=1)
uniquedf_lh = basedatadf[basedatadf['Reason']=='LH'][['DOCKNO','specific_pt']]
uniquedf_lh = uniquedf_lh.drop_duplicates(subset='DOCKNO')

lh_fail_1liner = pd.merge(uniquedf_lh,basedatadf,left_on=['DOCKNO','specific_pt'],right_on=['DOCKNO','Concate'],how='inner')
lh_fail_1liner = lh_fail_1liner.drop_duplicates(subset='DOCKNO')

lh_fail_1liner.to_csv(r'D:\Data\Duedate_diagnostic\Basedata_LH\Duedate_diagnostic_LH_oneliner_'+str(datefilter)+'.csv')

lh_fail_1liner.to_csv(r'D:\Data\Duedate_diagnostic\Duedate_diagnostic_LH_oneliner.csv')
oppath_lhfail_1liner = r'D:\Data\Duedate_diagnostic\Duedate_diagnostic_LH_oneliner.csv'

#print ('Logging in...')
#ftp = ftplib.FTP()
##ftp.connect('119.226.230.94')
#ftp.connect('10.109.230.50')
#print (ftp.getwelcome())
#try:
#    try:
#        ftp.login('IEPROJECTUSER', 'spotStar@123')
#        ftp.cwd('ETA')
#        # move to the desired upload directory
#        print ("Currently in:", ftp.pwd())
#        print ('Uploading...')
#        fullname = oppath_lhfail_1liner
#        name = os.path.split(fullname)[1]
#        f = open(fullname, "rb")
#        ftp.storbinary('STOR ' + name, f)
#        f.close()
#        print ("OK"  )
#        print ("Files:")
#        print (ftp.retrlines('LIST'))
#    finally:
#        print ("Quitting...")
#        ftp.quit()
#except:
#    traceback.print_exc()
### Edit for Oneline LH THC data for JM
#
#print ('Logging in...')
#ftp = ftplib.FTP()
##ftp.connect('119.226.230.94')
#ftp.connect('10.109.230.50')
#print (ftp.getwelcome())
#try:
#    try:
#        ftp.login('IEPROJECTUSER', 'spotStar@123')
#        ftp.cwd('ETA')
#        # move to the desired upload directory
#        print ("Currently in:", ftp.pwd())
#        print ('Uploading...')
#        fullname = oppath_data
#        name = os.path.split(fullname)[1]
#        f = open(fullname, "rb")
#        ftp.storbinary('STOR ' + name, f)
#        f.close()
#        print ("OK"  )
#        print ("Files:")
#        print (ftp.retrlines('LIST'))
#    finally:
#        print ("Quitting...")
#        ftp.quit()
#except:
#    traceback.print_exc()

#FTP Upload ends


# In[44]:

finalsfgrp = finalsf.groupby(['specific_pt','Reason'],{'DOCKNO': agg.COUNT('DOCKNO')})


# In[45]:

#finalsfgrp = finalsfgrp[finalsfgrp['Reason']!='Reached'] #eliminate where getting as reached


# In[46]:

finalsfgrp = finalsfgrp.sort_values('DOCKNO', ascending=False)


# In[47]:

#finalsfgrp.save('finalsfgrp.csv')
finalsfgrp_df = finalsfgrp.to_dataframe()

finalsfgrp_df.to_csv(r'D:\Data\Duedate_diagnostic\Summary\Duedate_diagnostic_summary_'+str(datefilter)+'.csv')

finalsfgrp_df.to_csv(r'D:\Data\Duedate_diagnostic\Duedate_diagnostic_summary.csv')
oppath_summary = r'D:\Data\Duedate_diagnostic\Duedate_diagnostic_summary.csv'


## For publishing email body variables
finalsfgrp_df_lh = finalsfgrp_df[finalsfgrp_df['Reason']=='LH']
lhfailcons = finalsfgrp_df_lh['DOCKNO'].sum()
print 'lhfailcons',lhfailcons
finalsfgrp_df_loc = finalsfgrp_df[finalsfgrp_df['Reason']=='Location']
locfailcons = finalsfgrp_df_loc['DOCKNO'].sum()

totalfailcons = finalsfgrp_df['DOCKNO'].sum()

lhfailperc = pd.np.round((lhfailcons*100.0)/totalfailcons,0)
locfailperc = pd.np.round((locfailcons*100.0)/totalfailcons,0)
## For publishing email body variables


finalsfgrp_df_mail = finalsfgrp_df.head(15)
# In[ ]:

finalsfgrp_df_mail = finalsfgrp_df_mail.to_string(index=False)



# In[ ]:
filePath = oppath_summary
def sendEmail(TO = ["sq_spot@spoton.co.in"],
             #TO = ["rajeesh.vr@spoton.co.in"],
             CC = ["sqtf@spoton.co.in"],
             #TO = ["vishwas.j@spoton.co.in"],
             #CC =  ["vishwas.j@spoton.co.in"],
             #CC =  ["sqtf@spoton.co.in"],
             #CC =  ["supratim@iepfunds.com","rajeesh.vr@spoton.co.in"],
             BCC =  ["mahesh.reddy@spoton.co.in"],
            #FROM="mis.ho@spoton.co.in"):
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
    #HOST = "smpt.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DEPOTWISE OPS Bucket Stock  - "+ str(datefilter)
    msg["Subject"] = "Duedate Diagnostic Report - "+ str(datefilter)
    body_text = """
    Dear All,
    
    PFB the Duedate Diagnostic Report of Duedate """ + str(datefilter) +""" which fail to reach the Destination SC. 
    
    Number of LH failed cons = """+str(lhfailcons)+"""
    Number of Location failed cons = """+str(locfailcons)+"""
    LH Failed cons % = """+str(lhfailperc)+""" %
    Location Failed cons % = """+str(locfailperc)+""" %
       
     Note:
    'LH' means the reason is Linehaul. This means , the con was expected to reach while departing from LH Origin. However when received at LH Destination, the con failed ETA 
    The 'specific_point' attributes the problem to the specific lane.
    
    'Location' means the reason is location. This means the con was expected to reach ETA when the location received a con. However the con failed ETA at the time of departure
    The 'specific_point' attributes the problem to the location-sector.
    
    Total no of cons are mentioned under 'DOCKNO'
            
    
"""+str(finalsfgrp_df_mail)+"""


    For conwise data, please download from the link below
        
    http://spoton.co.in/downloads/IEProjects/ETA/Duedate_diagnostic_data.csv
    
    For LH Failed condata, pleae use the link below. 
    
    http://spoton.co.in/downloads/IEProjects/ETA/Duedate_diagnostic_LH_oneliner.csv
    """
    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    #server.login("mis.ho@spoton.co.in", "Mis@2019")
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
#print('Email sent')

