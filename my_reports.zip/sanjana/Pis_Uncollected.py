
# coding: utf-8

# In[1]:


import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
from datetime import datetime, timedelta, date
import numpy as np
from pandas import ExcelWriter

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
import traceback
# In[2]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=PYTHON_DB;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()


# ### Query and converting to DF

# In[3]:


query = ("""
            SELECT  A.DOCKNO ,
        A.DOCKDT BOOKINGDATE ,
        A.CDELDT DUEDATE ,
        A.CSGNCD SENDERCODE ,
        A.CSGNNM SENDERNAME ,
        A.CSGECD RECEIVERCODE ,
        A.CSGENM RECEIVERNAME ,
        ACTUAL_WEIGHT ,
        A.PKGSNO ,
        DC ,
        DACCC ,
        VTC ,
        FTC ,
        BOOKING_REGION ,
        ORIGIN_BRCODE ,
        ORIGIN_BRNAME ,
        orgareaname ,
        A.PINCODE ,
        A.DESTCD ,
        destareaname ,
        DLV_PINCODE ,
        DESTLOCTYPE ,
        A.BACODE ,
        BANM ,
        INVOICEVALUE ,
        CURR_AREA ,
        CURR_BRANCHCODE ,
        CURR_BRANCHNAME ,
        ARRV_AT_CURR_LOCATION ,
        HOURS_LYING_AT_CURR_LOCATION ,
        ISDEPARTED_FRM_CURRLOC ,
        CurLocConStatusCategory ,
        CurLocConStatusCode ,
        CurLocConStatusDesc ,
        CurLocConStatusReason ,
        CurLocConStatusDate ,
        TIME_STAMP ,
        DATEDIFF(DAY, A.DOCKDT, A.TIME_STAMP) HRS_AFTER_BOOKING ,
        CASE WHEN ( A.CURR_BRANCHCODE = B.ORGNCD ) THEN 'AT_ORIGIN'
             WHEN ( A.CURR_BRANCHCODE = A.DESTCD ) THEN 'AT_DESTN'
             ELSE 'IN_TRANSIT'
        END LOCATION
FROM    dbo.tblTimeConnectionReport_Undelivered_2Hrs A
        INNER JOIN dbo.DOCKET B WITH ( NOLOCK ) ON B.DOCKNO = A.DOCKNO
        INNER JOIN dbo.tblStockCons C WITH ( NOLOCK ) ON C.DOCKNO = A.DOCKNO
WHERE   B.PAYBAS NOT IN ( '2', '3', '4', '5' )
        AND C.CashPISDRSEnabled = 'NO'
            """)

piscons = pd.read_sql(query, Utilities.cnxn)


# In[4]:


piscons = piscons.assign(delaygrp=pd.cut(piscons.HRS_AFTER_BOOKING,bins=[-np.inf,24,48,72,96,np.inf],labels=['0-24','24-48','48-72','72-96','96+']))


# In[5]:




# In[6]:


overallsum = pd.pivot_table(piscons, index=['orgareaname'], columns=['delaygrp'], values=['DOCKNO'],fill_value=0, aggfunc=len,margins=True,margins_name='TOTAL')
overallsum=overallsum[overallsum.index!='TOTAL']
overallsum.loc['TOTAL'] = overallsum.sum(axis=0)

print (overallsum)


# In[7]:


overallhourwise = pd.pivot_table(piscons, index=['orgareaname'], columns=['HRS_AFTER_BOOKING'], values=['DOCKNO'],fill_value=0, aggfunc=len,margins=True,margins_name='TOTAL')
overallhourwise=overallhourwise[overallhourwise.index!='TOTAL']
overallhourwise.loc['TOTAL'] = overallhourwise.sum(axis=0)

# In[8]:


reacheddestdf = piscons[piscons['LOCATION']=='AT_DESTN']
reached_dest = pd.pivot_table(reacheddestdf, index=['orgareaname'], columns=['delaygrp'], values=['DOCKNO'],fill_value=0, aggfunc=len,margins=True,margins_name='TOTAL')
reached_dest=reached_dest[reached_dest.index!='TOTAL']
reached_dest.loc['TOTAL'] = reached_dest.sum(axis=0)
print (reached_dest)
#exit(0)
# In[10]:


greaterthan48 = piscons[piscons['HRS_AFTER_BOOKING']>=48.0]
greaterthan48sum = pd.pivot_table(greaterthan48, index=['orgareaname'], columns=['delaygrp'], values=['DOCKNO'],fill_value=0, aggfunc=len,margins=True,margins_name='TOTAL')
greaterthan48sum=greaterthan48sum[greaterthan48sum.index!='TOTAL']
greaterthan48sum.loc['TOTAL'] = greaterthan48sum.sum(axis=0)

# In[12]:
today=date.today()
today_date=datetime.strftime(today,'%d-%m-%Y')

del piscons['CurLocConStatusReason']

with ExcelWriter(r'D:\Data\PIS _Blocked\Cash_PIS_Blocked_'+str(today)+'.xlsx') as writer:
    overallsum.to_excel(writer, sheet_name='Overall_summary',engine='xlsxwriter')
    overallhourwise.to_excel(writer, sheet_name='Hrs_after_booking_summary',engine='xlsxwriter')
    reached_dest.to_excel(writer, sheet_name='At_Dest_summary',engine='xlsxwriter')
    greaterthan48sum.to_excel(writer, sheet_name='>48_Hrs_summary',engine='xlsxwriter')
    piscons.to_excel(writer, sheet_name='Con_details',engine='xlsxwriter')


filepath = 'D:\Data\PIS _Blocked\Cash_PIS_Blocked_'+str(today)+'.xlsx'

TO=["dom_spot@spoton.co.in","rom_spot@spoton.co.in",'aom_spot@spoton.co.in']
# TO=['pawan.sharma@spoton.co.in']
#TO=['mahesh.reddy@spoton.co.in']
FROM='reports.ie@spoton.co.in'
# CC=['sqtf@spoton.co.in','rajesh.kapase@spoton.co.in','mahesh.reddy@spoton.co.in','shashvat.suhane@spoton.co.in','vishwas.j@spoton.co.in']
# BCC = ['yogesh.singh@spoton.co.in','prabhakar.mahajan@spoton.co.in','nitin.tatyarao@spoton.co.in','vinodkumar.mishra@spoton.co.in','jai.prakash@spoton.co.in','nomesh.ganvir@spoton.co.in','sanjay.panse@spoton.co.in','sunil.khare@spoton.co.in','OPS.HUB.AMDH.1@spoton.co.in','aditya.shekhar@spoton.co.in','chidananda.biswal@spoton.co.in','virendra.singh@spoton.co.in','dhruvnarayan.tiwari@spoton.co.in','anilkumar.mishra@spoton.co.in']
CC=['pawan.sharma@spoton.co.in','shivananda.p@spoton.co.in']
BCC=['vishwas.j@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "Cash PIS Blocked Cons -"+ str(today)

report=""
# report+='<br>'
report+='PFB the overall summary of Cash PIS Blocked cons'
report+='<br>'
report+=''
report+='<br>'+overallsum.to_html()+'<br>'
report+='<br>'
report+='PFB the overall summary of Cash PIS Blocked cons that have already reached the destination SC'
report+='<br>'
report+='<br>'+reached_dest.to_html()+'<br>'

# klm=MIMEText(report,'html')
# msg.attach(klm)
# bcd=MIMEText(senddf1.to_html(),'html')
# msg.attach(bcd)
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()