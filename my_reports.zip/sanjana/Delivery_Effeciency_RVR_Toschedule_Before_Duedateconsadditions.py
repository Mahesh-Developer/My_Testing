
# coding: utf-8

# In[90]:

import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
import calendar
import datetime
from pandas import ExcelWriter

import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import os

# In[91]:

#ocidclosingstockbase = pd.io.excel.read_excel(r'http://spoton.co.in/downloads/OCID/OCID.xls','CLOSING STOCK')
#datenow = date.today()
#dateyest = datenow-timedelta(hours=24)
#ocidclosingstockbase.loc[ocidclosingstockbase.index,'Timestamp'] = dateyest
#ocidclosingstockbase.to_csv(r'D:\\Data\\eta_rank\Destination_sc_closingstock\\Closing_Stock_'+str(dateyest)+'.csv',encoding='utf-8')


openingstock = pd.io.excel.read_excel(r'http://spoton.co.in/downloads/OCID/OCID.xls','OPENING STOCK')
fullincomingstock = pd.io.excel.read_excel(r'http://spoton.co.in/downloads/OCID/OCID.xls','INCOMING')
deliveredstock = pd.io.excel.read_excel(r'http://spoton.co.in/downloads/OCID/OCID.xls','DELIVERED')
closingstockfull = pd.io.excel.read_excel(r'http://spoton.co.in/downloads/OCID/OCID.xls','CLOSING STOCK')

# In[92]:

branchdf = pd.read_csv('D:\Python\Scripts and Files\Path and Graph Files\Branchlist.csv')
branchdf = pd.DataFrame(branchdf,columns=['BRANCH CODE','Area'])

print len(openingstock), len(fullincomingstock), len(deliveredstock)


# In[93]:

openingstock = openingstock[openingstock['DEL LOCATION TYPE']=='STD']
fullincomingstock = fullincomingstock[fullincomingstock['DEL LOCATION TYPE']=='STD']
deliveredstock = deliveredstock[deliveredstock['DEL LOCATION TYPE']=='STD']
closingstockfull = closingstockfull[closingstockfull['DEL LOCATION TYPE']=='STD']

# In[94]:

#ignorestatuscodelist = ['D14', 'UCG']
ignorestatuscodelist = ['UCG']
#ignorestatusdesclist = ['Awaiting for NSL Delivery Confirmation', 'Awaiting for ODA Delivery Confirmation', 'Change of Pincode from STD to ODA - Pending Approval', 'Non Serviceable Location', 'ODA DRS PREPARED', 'Shipment Held for ODA Delivery', 'Shipment held for Sales Tax inspection', 'Shipment Seized By Check Post / Sales Tax','STD to ODA Pincode Change Request - Awaiting CS Confirmation','Tagged For UCG']
openingstock=openingstock[~openingstock['Con Status Code'].isin(ignorestatuscodelist)]
closingstockfull=closingstockfull[~closingstockfull['Con Status Code'].isin(ignorestatuscodelist)]
#openingstock=openingstock[~openingstock['Con Status Desc'].isin(ignorestatusdesclist)]
#openingstock = openingstock[openingstock['DRS Blocked Due to Payment Issues']=='NO']
#openingstock = openingstock[openingstock['DRS Blocked due to ODA Pincode Change']=='NO']
#openingstock = openingstock[openingstock['DRS Blocked due to Demurrage']=='NO']


# In[112]:

incoming12stock = fullincomingstock[(fullincomingstock['INC ARRV CATEGORY']=='<12PM')]
openinggroupby=openingstock.groupby(['DEST BRCD']).agg({'DOCKNO': 'count'}).reset_index()
incoming12groupby=incoming12stock.groupby(['DEST BRCD']).agg({'DOCKNO': 'count'}).reset_index()
deliveredgroupby=deliveredstock.groupby(['DEST BRCD']).agg({'DOCKNO': 'count'}).reset_index()


# In[113]:

merge_effeciency = pd.merge(openinggroupby,incoming12groupby,on=['DEST BRCD'], suffixes=['_op','_in'],how='outer')
merge_effeciency = pd.merge(merge_effeciency,deliveredgroupby, on=['DEST BRCD'], how='outer')


# In[114]:

def getsum(x,y,z):
    try:
        return np.ceil((x*100.0)/(y+z))
    except:
        return 100.0


# In[115]:

merge_effeciency = merge_effeciency.fillna(0)
merge_effeciency['Delivery_Efficiency']= merge_effeciency.apply(lambda x:getsum(x['DOCKNO'],x['DOCKNO_op'],x['DOCKNO_in']),axis=1)
merge_effeciency.rename(columns={'DOCKNO':'DOCKNO_Delivered'}, inplace=True)
merge_effeciency=pd.merge(merge_effeciency,branchdf,left_on=['DEST BRCD'],right_on=['BRANCH CODE'], how = 'inner')
merge_effeciency.head()
merge_effeciency = merge_effeciency.drop(['BRANCH CODE'], axis=1)


# In[119]:

openingcons = merge_effeciency['DOCKNO_op'].sum() 
incomingcons = merge_effeciency['DOCKNO_in'].sum()
deliveredcons = merge_effeciency['DOCKNO_Delivered'].sum()
deliveryefficiency = np.round(deliveredcons*100.0/(incomingcons+openingcons),2)
print openingcons, incomingcons, deliveredcons
#merge_effeciency.to_csv(r'C:\Data\Effeciency_Delivery\deliveryeff_19Nov_notVD1.csv', encoding='utf-8')


# In[118]:

merge_effeciency_area=merge_effeciency.groupby(['Area']).agg({'DOCKNO_op': 'sum','DOCKNO_in': 'sum','DOCKNO_Delivered': 'sum'}).reset_index()
merge_effeciency_area['Delivery_Efficiency']= merge_effeciency_area.apply(lambda x:getsum(x['DOCKNO_Delivered'],x['DOCKNO_op'],x['DOCKNO_in']),axis=1)
merge_effeciency_area.head()



## For CCF % AREA wise in Closing Stock

ccfsrlist = ['SENDER FAILURE', 'RECEIVER FAILURE']
ccfsrdf=closingstockfull[closingstockfull['Con Status Category'].isin(ccfsrlist)]
ccfsrdfgroupby = ccfsrdf.groupby(['DEST AREA']).agg({'DOCKNO': 'count'}).reset_index()

## For NON CCF Cons
nonccfsrdf=closingstockfull[~closingstockfull['Con Status Category'].isin(ccfsrlist)]
nonccfsrdfgroupby = nonccfsrdf.groupby(['DEST AREA']).agg({'DOCKNO': 'count'}).reset_index()
nonccfcons = nonccfsrdfgroupby['DOCKNO'].sum()
## For NON CCF Cons

## For CCF % AREA wise in Closing Stock

###For DueDate Cons
opfilevar =date.today() - timedelta(hours=24)
yesterday = datetime.datetime.today() - datetime.timedelta (days=1) 
new_period=yesterday.replace(hour=12, minute=0).strftime ('%d-%m-%Y %H:%M')

closingstockduecons = closingstockfull[closingstockfull['DUE DATE']==opfilevar]
closingarriv12 = closingstockduecons[closingstockduecons['ARRV AT DEST SC']<=new_period]
closingarriv12free = closingarriv12[closingarriv12['Is Free Con']=='YES']

closingarriv12grp = closingarriv12.groupby(['DEST AREA']).agg({'DOCKNO':len}).reset_index()
closingarriv12freegrp = closingarriv12free.groupby(['DEST AREA']).agg({'DOCKNO':len}).reset_index()

closingnotdel = pd.merge(closingarriv12grp,closingarriv12freegrp,left_on=['DEST AREA'],right_on=['DEST AREA'],suffixes=['_Missed','_Missed_Free'],how='outer')
 
###For DueDate Cons

### For Closing stock Aging

closingstockfullpivot = closingstockfull.groupby(['DEST AREA']).agg({'DOCKNO': 'count'}).reset_index()
closingstockcons = closingstockfullpivot['DOCKNO'].sum()
efficiencyclstock = pd.merge(merge_effeciency_area,closingstockfullpivot,left_on=['Area'],right_on=['DEST AREA'], how = 'inner')

closingstoctl24 = closingstockfull[closingstockfull['REPORTDATE MIN ARRVDT']>=39]
closingstoctl24cons = len(closingstoctl24)
closingstoctl24aging = np.ceil(closingstoctl24['REPORTDATE MIN ARRVDT'].sum()/closingstoctl24cons)

def getavg(x,y):
    return y/x


closingstoctl24groupby=closingstoctl24.groupby(['DEST AREA']).agg({'DOCKNO': 'count', 'REPORTDATE MIN ARRVDT':'sum'}).reset_index()
closingstoctl24groupby['Avg_Cooling_Hrs']=closingstoctl24groupby.apply (lambda x : getavg(x['DOCKNO'],x['REPORTDATE MIN ARRVDT']),axis=1)
closingstoctl24gb = closingstoctl24groupby.groupby(['DEST AREA']).agg({'DOCKNO':'sum','Avg_Cooling_Hrs':np.mean}).reset_index()

efficiencyclstockfull = pd.merge(efficiencyclstock,closingstoctl24gb,left_on=['Area'],right_on=['DEST AREA'], how = 'inner')
efficiencyclstockfull = efficiencyclstockfull.drop(['DEST AREA_x'], axis=1)
efficiencyclstockfull = efficiencyclstockfull.drop(['DEST AREA_y'], axis=1)
efficiencyclstockfull = efficiencyclstockfull.rename(columns={'DOCKNO_x':'Closing_Stock'})
efficiencyclstockfull = efficiencyclstockfull.rename(columns={'DOCKNO_y':'Closing_Stock>24hrs'})
efficiencyclstockfull = efficiencyclstockfull.rename(columns={'Avg_Cooling_Hrs':'Avg_Cooling_Hrs>24hrs'})

### For Closing stock Aging
def ccfperc(x,y):
    return np.ceil((x*100.0)/(y))


efficiencyclstockfullccf = pd.merge(efficiencyclstockfull,ccfsrdfgroupby,left_on=['Area'],right_on=['DEST AREA'], how = 'outer')
efficiencyclstockfullccf['%CCF_Cons'] = efficiencyclstockfullccf.apply (lambda x : ccfperc(x['DOCKNO'],x['Closing_Stock']),axis=1)
efficiencyclstockfullccf = efficiencyclstockfullccf.rename(columns={'DOCKNO':'CCF_Cons'})

ccfconsno = efficiencyclstockfullccf['CCF_Cons'].sum()
ccfpercentagecons = np.round((ccfconsno*100.0)/closingstockcons,2)

def effcheck(x,y):
    if x<65 and y<65:
        return 'Check'
    else:
        return '-'

def setceil(x):
    return np.round(x,0)

## For NON CCF Cons AREA-WISE
efficiencyclstockfullccf = pd.merge(efficiencyclstockfullccf,nonccfsrdfgroupby,left_on=['Area'],right_on=['DEST AREA'], how = 'outer') 
efficiencyclstockfullccf['REMARKS'] = efficiencyclstockfullccf.apply(lambda x :effcheck(x['Delivery_Efficiency'],x['%CCF_Cons']),axis =1)
efficiencyclstockfullccf = efficiencyclstockfullccf.rename(columns={'DOCKNO':'NON_CCF_Cons'})

columnsopreqcols=['Area','DOCKNO_Delivered','Delivery_Efficiency','%CCF_Cons','NON_CCF_Cons','REMARKS']
efficiencyreqcols = pd.DataFrame(efficiencyclstockfullccf,columns=columnsopreqcols)

efficiencyreqcols = efficiencyreqcols.rename(columns={'DOCKNO_Delivered':'DELIVERED'})
efficiencyreqcols = efficiencyreqcols.rename(columns={'Delivery_Efficiency':'DELIVERY_EFFY'})
efficiencyreqcols['DELIVERY_EFFY'] = efficiencyreqcols.apply(lambda x :setceil(x['DELIVERY_EFFY']),axis =1)


sumlist = ['TOTAL',deliveredcons,deliveryefficiency,ccfpercentagecons,nonccfcons,'-']
col_list = ['Area','DELIVERED','DELIVERY_EFFY','%CCF_Cons','NON_CCF_Cons','REMARKS']
totalsdf = pd.DataFrame(data=[sumlist], columns = col_list)
efficiencyreqcols = efficiencyreqcols.append(totalsdf,ignore_index=True)

## For NON CCF Cons AREA-WISE
efficiencyclstockfullccf = efficiencyclstockfullccf.drop(['DEST AREA_x','DEST AREA_y','REMARKS'], axis=1)

## For CCF % AREA wise in Closing Stock


oppath2=r'D:\Data\eta_rank\Delivery_Efficiency\Delivery_Efficiency_'+str(opfilevar)+'.xlsx'

# In[ ]:

with ExcelWriter(r'D:\Data\eta_rank\Delivery_Efficiency\Delivery_Efficiency_'+str(opfilevar)+'.xlsx') as writer:
    ###orginal_cancel_basedata.to_excel(writer, sheet_name='Sheet1',engine='xlsxwriter')
    merge_effeciency.to_excel(writer, sheet_name='SC_WISE',engine='xlsxwriter')
    efficiencyclstockfullccf.to_excel(writer, sheet_name='AREA_WISE',engine='xlsxwriter')
    #efficiencyreqcols.to_excel(writer, sheet_name='MailRequiredcolumns',engine='xlsxwriter')

efficiencyclstockfull.to_csv(r'D:\Data\eta_rank\STD_DE.csv', encoding='utf-8')


filePath = oppath2
def sendEmail(#TO = ["aom_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in","spot_ops-coordinators@spoton.co.in","rajesh.mishra@spoton.co.in","raghavendra.rao@spoton.co.in","ashwani.gangwar@spoton.co.in"],
            #TO = ["rajeesh.vr@spoton.co.in"],
            #CC = ["rajeesh.vr@spoton.co.in"],
            TO = ["vishwas.j@spoton.co.in"],
            CC = ["vishwas.j@spoton.co.in"],
            #CC = ["sqtf@spoton.co.in","SQ_spot@spoton.co.in","supratim@iepfunds.com","Ankit@iepfunds.com","sukumar.sakthivel@spoton.co.in","vishwas.j@spoton.co.in","rajeesh.vr@spoton.co.in"],
    FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    body_text = """
    Dear All,
    
    Delivered = """+str(deliveredcons)+"""
    Opening Stock = """+str(openingcons)+"""
    Incoming Stock = """+str(incomingcons)+"""
    Closing Stock = """+str(closingstockcons)+"""
    Closing Stock > 24hrs = """+str(closingstoctl24cons)+"""
    Average Ageing of Closing Stock >24hrs = """+str(closingstoctl24aging)+""" hrs
    Cons of Duedate """+str(opfilevar)+""" Not Delivered = """+str(totalduecons)+"""
    CCF Cons % of Closing Stock = """+str(ccfpercentagecons)+""" %
    
    The Overall Delivery efficiency of STD cons is """+str(deliveryefficiency)+"""%
    
    PFB the Delivery Efficiency Area wise as of """ + str(opfilevar) +"""
    
    """+str(efficiencyreqcols)+"""
    
    The AREA-WISE and SC-WISE summary has been attached in the mail.
    
    For the base data, please refer the link http://spoton.co.in/downloads/OCID/OCID.xls
    

    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.co.in", "#Xat694#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends
