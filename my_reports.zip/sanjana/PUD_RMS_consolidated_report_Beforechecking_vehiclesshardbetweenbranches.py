
# coding: utf-8

# In[1]:

import pandas as pd
import smtplib
import os
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import datetime
from datetime import datetime
from datetime import timedelta
from pandas import ExcelWriter


# In[2]:

branchdf = pd.read_csv('D:\Python\Scripts and Files\Path and Graph Files\Branchlist.csv')
branchdfcols = ['BRANCH CODE','Depot','Region','Area']
branchdf = pd.DataFrame(branchdf,columns=branchdfcols)

pudrmsbasedata = pd.read_csv(r'http://10.109.230.50/downloads/IEProjects/PRCU/PRCU.csv')

## TO exclude not enabled PUD RMS branches PNQK and DELN
pudrmsbrcdtoexclude = ['DELN','PNQK']
pudrmsbasedata = pudrmsbasedata[~pudrmsbasedata['Brcd'].isin(pudrmsbrcdtoexclude)]
## TO exclude not enabled PUD RMS branches PNQK and DELN

pudrmsbasedata['VEHICLE_CAPACITY_NEW'] = pudrmsbasedata.apply(lambda x:abs(x['VEHICLECAPACITY']),axis=1)

branchdfpmdmerge = pd.merge(pudrmsbasedata,branchdf,left_on='Brcd',right_on='BRANCH CODE',how='left')
pudrmsdata = branchdfpmdmerge
pudrmsdata = pudrmsdata.drop('BRANCH CODE',axis=1)


### For VehicleContractType Market and Fixed
pudrmsdata.VehicleContractType.fillna('Others',inplace=True)
ix = pudrmsdata[(pudrmsdata['VehicleContractType']=='Others')&(pudrmsdata['VendorType']=='MKT')].index
pudrmsdata.loc[ix,'VehicleContractType'] = 'MARKET'
iy = pudrmsdata[(pudrmsdata['VehicleContractType']=='Others')&(pudrmsdata['VendorType']=='FIX')].index
pudrmsdata.loc[iy,'VehicleContractType'] = 'FIXED'

len(pudrmsdata[pudrmsdata['VehicleContractType']=='MARKET'])

pudrmsdata = pudrmsdata[pudrmsdata['VehicleContractType']!='MARKET']     #TO EXCLUDE MARKET in All_Vehicles Report and Summary
len(pudrmsdata)
### For VehicleContractType Market and Fixed
# In[3]:

pudrmsdataforremovingdups = pudrmsdata.drop_duplicates(cols='VehicleNo')
pudrmsdataforremovingdupsgrp = pudrmsdataforremovingdups.groupby(['Region','Depot']).agg({'VEHICLE_CAPACITY_NEW':sum}).reset_index() 
pudrmsdataforremovingdupsgrp['VEHICLE_CAPACITY_NEW'].sum()

## For getting BA names for the vehicle numbers
pudrmsdatabanames = pd.DataFrame(pudrmsdataforremovingdups,columns=['VehicleNo','Banm'])

## For getting BA names for the vehicle numbers

# In[4]:

pudrmsdata = pudrmsdata.dropna(subset=['VehicleType'])
print len(pudrmsdata)
pudrmsdata = pudrmsdata.rename(columns={'\xef\xbb\xbfDy':'Date'})


# In[5]:

def utilcalc(vehcap,ofdwt,pkpwt):
    totalwt = ofdwt+pkpwt
    try:
        util = (pd.np.round((totalwt/vehcap),4))*100
        return util
    except:
        return 0

def distancecalc(deldist,pickdist):
    totaldist = deldist+pickdist
    return totaldist


def utilcutoff(utilzn):
    if utilzn >= 300:
        return 'High_utilization'
    elif utilzn <= 50 :
        return 'Low_utilization'
    else:
        return 'NA'

def mispickupperc(totalpickups,mispickups):
    try:
        totalassignedpickups = totalpickups+mispickups
        mispickupperc = (pd.np.round((mispickups*1.0/totalassignedpickups),4))*100
        return mispickupperc
    except:
        mispickupperc = 0
        return mispickupperc

def undelperc(undelcons,ofdcons):
    #undelperc = pd.np.round(((undelcons/ofdcons)*100.0),2)
    undelperc = (pd.np.round((undelcons*1.0/ofdcons),4))*100
    return undelperc


# In[6]:

pudrmsdata['Total_distance'] = pudrmsdata.apply(lambda x:distancecalc(x['DEL_TRAVELDISTANCE'],x['PKP_TRAVELDISTANCE']),axis=1)


# In[7]:
print 'pudrmsdata columns are',pudrmsdata.columns.tolist()
pudrmsdatagrp = pudrmsdata.groupby(['Date','Area','Brcd','VehicleNo','VEHICLE_CAPACITY_NEW','VehicleContractType']).agg({'OFD_CONS':sum,'TOT_DRS':sum,'OFD_ACTWT':sum,'PKP_ACTWT':sum,'DLV_UNIQUEPINCODES':sum,'MISSPICKUPS':sum,'NONDLV_CONS':sum,'Total_distance':sum}).reset_index()

## Merging BA names with Vehicles numbers
pudrmsdatagrp = pd.merge(pudrmsdatagrp,pudrmsdatabanames,on='VehicleNo',how='left')
## Merging BA names with Vehicles numbers

##$$pudrmsdatagrp = pudrmsdata.groupby(['Date','Brcd','VehicleNo','Banm','VEHICLE_CAPACITY_NEW','VehicleContractType']).agg({'OFD_CONS':sum,'TOT_DRS':sum,'OFD_ACTWT':sum,'PKP_ACTWT':sum,'DLV_UNIQUEPINCODES':sum,'MISSPICKUPS':sum,'NONDLV_CONS':sum,'Total_distance':sum}).reset_index()
#pudrmsdatagrp = pudrmsdata.groupby(['Date','Brcd','VehicleNo','VEHICLE_CAPACITY_NEW']).agg({'OFD_CONS':sum,'TOT_DRS':sum,'OFD_ACTWT':sum,'PKP_ACTWT':sum,'DLV_UNIQUEPINCODES':sum,'MISSPICKUPS':sum,'NONDLV_CONS':sum,'Total_distance':sum}).reset_index()


# In[9]:

pudrmsdatagrp['Utilization'] = pudrmsdatagrp.apply(lambda x:utilcalc(x['VEHICLE_CAPACITY_NEW'],x['OFD_ACTWT'],x['PKP_ACTWT']),axis=1)


# In[10]:

pudrmsdatagrp['Utilization_Remarks'] = pudrmsdatagrp.apply(lambda x:utilcutoff(x['Utilization']),axis=1)


# In[11]:

pudrmsdatagrp1forsummary = pudrmsdata.groupby(['Region','Depot','VehicleNo','VEHICLE_CAPACITY_NEW']).agg({'OFD_CONS':sum,'OFD_ACTWT':sum,'PKP_ACTWT':sum,'DLV_UNIQUEPINCODES':sum,'MISSPICKUPS':sum,'NONDLV_CONS':sum,'Total_distance':sum,'TOT_PKPS':sum}).reset_index()


# In[12]:

pudrmsdatagrpsummary = pudrmsdatagrp1forsummary.groupby(['Region','Depot']).agg({'OFD_CONS':sum,'OFD_ACTWT':sum,'PKP_ACTWT':sum,'DLV_UNIQUEPINCODES':sum,'MISSPICKUPS':sum,'NONDLV_CONS':sum,'Total_distance':sum,'TOT_PKPS':sum}).reset_index()
#pudrmsdatagrpsummary['Utilization'] = pudrmsdatagrpsummary.apply(lambda x:utilcalc(x['VEHICLE_CAPACITY_NEW'],x['OFD_ACTWT'],x['PKP_ACTWT']),axis=1)
pudrmssummary = pd.merge(pudrmsdatagrpsummary,pudrmsdataforremovingdupsgrp,on=['Region','Depot'],how='outer')
pudrmssummary['Utilization'] = pudrmssummary.apply(lambda x:utilcalc(x['VEHICLE_CAPACITY_NEW'],x['OFD_ACTWT'],x['PKP_ACTWT']),axis=1)
pudrmssummary['Mispickup%'] = pudrmssummary.apply(lambda x:mispickupperc(x['TOT_PKPS'],x['MISSPICKUPS']),axis=1)
pudrmssummary['Undel%'] = pudrmssummary.apply(lambda x:undelperc(x['NONDLV_CONS'],x['OFD_CONS']),axis=1)
pudrmssummary
mailcols = ['Region','Depot','Utilization','Mispickup%','Undel%']
pudrmssummarymail = pd.DataFrame(pudrmssummary,columns=mailcols)
pudrmssummarymail


# In[13]:

now = datetime.now()
yestday = now-timedelta(hours=24)
yestdate = yestday.date()


# In[14]:

#pudrmsdatagrp.to_csv(r'C:\Data\PUD_RMS\PUD_RMS_Report_Vehiclewise_'+str(yestdate)+'.csv')
#oppath1 = r'C:\Data\PUD_RMS\PUD_RMS_Report_Vehiclewise_'+str(yestdate)+'.csv'


#### STD Vehicles not reported Start
vehnotprovided = pd.read_csv(r'http://10.109.230.50/downloads/IEProjects/PRSFVNPV/PRSFVNPV.csv') 
vehnotprovided = vehnotprovided.rename(columns={'\xef\xbb\xbfDay':'Day'})
vehnotprovided = vehnotprovided.drop_duplicates(subset=['Day','Vehicle_Number'])

vendornames = pd.DataFrame(vehnotprovided,columns=['Vehicle_Number','Vendor_Name'])
vendornames = vendornames.drop_duplicates(subset = ['Vehicle_Number'])

yesterdate = (datetime.today()- timedelta(days=1)).date()
print yesterdate

def convertdate(date):
    try:
        pudrmsdate = datetime.strptime(date,'%d-%b-%y').date()
        return pudrmsdate
    except:
        pudrmsdate = datetime.strptime(date,'%d %b %Y').date()
        return pudrmsdate
    
def dayofweek(datetimedate):
    #datetimedate = str(datetimedate)
    dayofweek = datetime.strftime(datetimedate,'%a')
    return dayofweek

def reportedyest(date):
    if date == yesterdate:
        return 'No'
    else:
        return '-'
    
vehnotprovided['Date'] = vehnotprovided.apply(lambda x:convertdate(x['Day']),axis=1)
vehnotprovided['Day_of_week'] = vehnotprovided.apply(lambda x:dayofweek(x['Date']),axis=1)
vehnotprovided['Reported_yesterday'] = vehnotprovided.apply(lambda x:reportedyest(x['Date']),axis=1)

vehnotprovidedyest = vehnotprovided[vehnotprovided['Reported_yesterday']=='No']
vehnotprovidedyest = pd.DataFrame(vehnotprovidedyest,columns=['Date','Vehicle_Number','Reported_yesterday'])

#For excluding sundays in the report
vehnotprovided = vehnotprovided[vehnotprovided['Day_of_week']!='Sun']
#For excluding sundays in the report

# For excluding Samsung Fixed vehicles in the report
vehnotprovided = vehnotprovided[~vehnotprovided['Vendor_Name'].str.contains("SAMSUNG")]
# For excluding Samsung Fixed vehicles in the report

vehnotprovidedgrp = vehnotprovided.groupby(['Region','Depot','Vehicle_Number']).agg({'Day':len}).reset_index()

vehnotprovidedgrpmerge = pd.merge(vehnotprovidedgrp,vehnotprovidedyest,on='Vehicle_Number',how='left')
vehnotprovidedgrpmerge = vehnotprovidedgrpmerge.drop_duplicates(subset=['Date','Vehicle_Number'])

vehnotprovidedgrpmerge = pd.merge(vehnotprovidedgrpmerge,vendornames,on='Vehicle_Number',how='left')
vehnotprovidedgrpmerge = vehnotprovidedgrpmerge.drop('Date',axis=1)

#### STD Vehicles not reported End

#### STD Vehicles used as ADHOC Start
######### IMPORTANT

## STD Vehicle master - Have removed all Fixed, Samsung, Non contractual vehicles and ODA vehicles in the STD Vehicle master 
## Fixed Vehicle master - From PMD, Fixed vehicles have been taken with certain columns renamed and is appended to the STD Vehicle master in order to get the vehicle master

######### IMPORTANT

def datestring(x):
    try:
        fulldate = datetime.strptime(x,'%d %b %Y %H:%M')
        return fulldate.date()
    except:
        fulldate = datetime.strptime(x,'%d-%m-%Y')
        return fulldate.date()
    
def losscal(cpkadhoc,cpkstd,actwt):
    loss1 = pd.np.round(((cpkadhoc-cpkstd)*actwt),2)
    loss = max(0,loss1)
    return loss
    
vehiclemaster = pd.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\Vehicle_master.csv')
vehiclemaster_vehno_vendor = pd.DataFrame(vehiclemaster,columns=['Vehicle Number','Vendor Name'])
vehiclemaster_vehno_vendor = vehiclemaster_vehno_vendor.drop_duplicates(subset='Vehicle Number')

## To get the list of the vendor names for a vehicles
#vehiclemaster_vehno_vendor_grp = vehiclemaster_vehno_vendor.groupby(['Vehicle Number']).agg({'Vendor Name':lambda x:list(set(x))}).reset_index()
#vehiclemaster_vehno_vendor_grp = pd.DataFrame(vehiclemaster_vehno_vendor_grp,columns=['Vehicle Number','Vendor Name'])
## To get the list of the vendor names for a vehicles

vehcileslist = vehiclemaster['Vehicle Number'].tolist()

pmddata = pd.read_csv(r'http://10.109.230.50/downloads/PMD/PMD.csv')
print pmddata.columns.tolist()
pmddata = pmddata.rename(columns={'\xef\xbb\xbfCON_ID2':'CON_ID2'})
pmddata = pd.DataFrame(pmddata,columns=['CON_ID2','DATE2','REGION2','DEPOT2','AREA2','BRANCH_CODE2','BRANCH_NAME2','ACT_WT2','CHRG_WT2','PUDTYPE2','BAVEHNO','BAVEHCAP','CONT_AMOUNT','MarketHireReqId','MKT_HIRE_REASON','MKT_HIRE_REMARKS','TYP2','COST2'])

pmddata['Date'] = pmddata.apply(lambda x:datestring(x['DATE2']),axis=1)

stdfixedlist = ['STD','FIXED']
pmddata_stdfixed = pmddata[pmddata['PUDTYPE2'].isin(stdfixedlist)]
stdvehdf = pmddata_stdfixed[pmddata_stdfixed['BAVEHNO'].isin(vehcileslist)]
len(stdvehdf)
stdvehdfsummary = stdvehdf.groupby(['BAVEHNO','PUDTYPE2']).agg({'CON_ID2':len,'ACT_WT2':sum,'COST2':sum}).reset_index()
stdvehdfsummary['ACT_WT_CPKG_STD'] = stdvehdfsummary.apply(lambda x: pd.np.round(x['COST2']/x['ACT_WT2'],2),axis=1)
stdvehdfsummary = pd.DataFrame(stdvehdfsummary,columns=['BAVEHNO','PUDTYPE2','ACT_WT_CPKG_STD'])


pmddata_adhoc = pmddata[pmddata['PUDTYPE2']=='ADHOC']

## For detecting if a vehicle is used as both STD/Fixed as well as ADHOC in a single day
pmddata_stdfixedgrp = pmddata_stdfixed.groupby(['Date','BAVEHNO']).agg({'CON_ID2':len}).reset_index()
pmddata_stdfixedgrp.drop('CON_ID2',axis=1)
pmddata_adhocgrp = pmddata_adhoc.groupby(['Date','BAVEHNO']).agg({'CON_ID2':len}).reset_index()
pmddata_adhocgrp.drop('CON_ID2',axis=1)
len(pmddata_adhocgrp),len(pmddata_stdfixedgrp)
vehicleboth_std_adhoc = pd.merge(pmddata_stdfixedgrp,pmddata_adhocgrp,on=['Date','BAVEHNO'],how='inner')
len(vehicleboth_std_adhoc)
## For detecting if a vehicle is used as both STD/Fixed as well as ADHOC in a single day


stdvehinadhoc = pmddata_adhoc[pmddata_adhoc['BAVEHNO'].isin(vehcileslist)]
len(stdvehinadhoc)

stdvehinadhocsummary = stdvehinadhoc.groupby(['AREA2','BRANCH_CODE2','BRANCH_NAME2','Date','BAVEHNO','CONT_AMOUNT','MarketHireReqId','MKT_HIRE_REASON','MKT_HIRE_REMARKS','BAVEHCAP']).agg({'CON_ID2':len,'ACT_WT2':sum,'CHRG_WT2':sum}).reset_index()
stdvehinadhocsummary['ACT_WT_CPKG'] = stdvehinadhocsummary.apply(lambda x: pd.np.round(x['CONT_AMOUNT']/x['ACT_WT2'],2),axis=1)
stdvehinadhocsummary['CHG_WT_CPKG'] = stdvehinadhocsummary.apply(lambda x: pd.np.round(x['CONT_AMOUNT']/x['CHRG_WT2'],2),axis=1)


stdvehinadhocsummarymerge = pd.merge(stdvehinadhocsummary,stdvehdfsummary,on=['BAVEHNO'],how='left')
stdvehinadhocsummarymerge.ACT_WT_CPKG_STD.fillna(0,inplace=True)

stdvehinadhocsummarymerge['LOSS'] = stdvehinadhocsummarymerge.apply(lambda x: losscal(x['ACT_WT_CPKG'],x['ACT_WT_CPKG_STD'],x['ACT_WT2']),axis=1)

stdvehinadhocsummarymerge = pd.merge(stdvehinadhocsummarymerge,vehiclemaster_vehno_vendor,left_on=['BAVEHNO'],right_on=['Vehicle Number'],how='left')
stdvehinadhocsummarymerge = stdvehinadhocsummarymerge.drop('Vehicle Number',axis=1)
stdvehinadhocsummarymerge = pd.DataFrame(stdvehinadhocsummarymerge,columns=['AREA2','BRANCH_CODE2','BRANCH_NAME2','Date','BAVEHNO','Vendor Name','PUDTYPE2','CONT_AMOUNT','BAVEHCAP','MarketHireReqId','MKT_HIRE_REASON','MKT_HIRE_REMARKS','CON_ID2','ACT_WT2','CHRG_WT2','ACT_WT_CPKG','CHG_WT_CPKG','ACT_WT_CPKG_STD','LOSS'])
stdvehinadhocsummarymerge.PUDTYPE2.fillna('STD',inplace=True)

## For detecting if a vehicle is used as both STD/Fixed as well as ADHOC in a single day
stdvehinadhocsummarymerge_std_adhoc = pd.merge(stdvehinadhocsummarymerge,vehicleboth_std_adhoc,on=['Date','BAVEHNO'],suffixes=['_M','_STD_Adhoc'],how='left')
## For detecting if a vehicle is used as both STD/Fixed as well as ADHOC in a single day

stdvehinadhocsummarymerge_std_adhoc = stdvehinadhocsummarymerge_std_adhoc.drop('CON_ID2_x',axis=1)
stdvehinadhocsummarymerge_std_adhoc.CON_ID2_y.fillna(0,inplace=True)

def stdaswellasadhoc(cons):
    if cons>0:
        return 'Yes'
    elif cons==0:
        return 'No'
    else:
        'Check'
        
stdvehinadhocsummarymerge_std_adhoc['Used_in_STD'] = stdvehinadhocsummarymerge_std_adhoc.apply(lambda x:stdaswellasadhoc(x['CON_ID2_y']),axis=1)
stdvehinadhocsummarymerge_std_adhoc = stdvehinadhocsummarymerge_std_adhoc.drop('CON_ID2_y',axis=1)

stdadhocfixlist = ['STD','ADHOC','FIXED']
pudrmsactwt2t = pmddata[(pmddata['BAVEHNO'].isin(vehcileslist))&(pmddata['ACT_WT2']>=2000)&(pmddata['PUDTYPE2'].isin(stdadhocfixlist))]

#pudrmsactwt2t.to_csv(r'C:\Data\PUD_RMS\STD_vehicle_used_under_market\pudrmsactwt2tgrp.csv')
pudrmsactwt2tgrp = pudrmsactwt2t.groupby(['Date','BAVEHNO']).agg({'CON_ID2':len}).reset_index()

pudrmsactwt2tgrp = pudrmsactwt2tgrp.rename(columns={'CON_ID2':'Wt_per_con_2T'})


pudrms_actwt2t_std_in_adhoc = pd.merge(stdvehinadhocsummarymerge_std_adhoc,pudrmsactwt2tgrp,on=['Date','BAVEHNO'],how='left')
pudrms_actwt2t_std_in_adhoc.Wt_per_con_2T.fillna(0,inplace=True)

#### STD Vehicles used as ADHOC End

# In[15]:

with ExcelWriter(r'D:\Data\PUD_RMS\Vehiclewise\PUD_RMS_Report_Vehiclewise_'+str(yestdate)+'.xlsx') as writer:
     ###orginal_cancel_basedata.to_excel(writer, sheet_name='Sheet1',engine='xlsxwriter')
     pudrmsdatagrp.to_excel(writer, sheet_name='All_vehicles',engine='xlsxwriter')
     pudrmssummary.to_excel(writer, sheet_name='PAN_INDIA_Summary',engine='xlsxwriter')
     vehnotprovidedgrpmerge.to_excel(writer, sheet_name='STD_Vehicles_not_reported',engine='xlsxwriter')
     pudrms_actwt2t_std_in_adhoc.to_excel(writer, sheet_name='STD_Vehicles_in_ADHOC',engine='xlsxwriter')
     
oppath2 = r'D:\Data\PUD_RMS\Vehiclewise\PUD_RMS_Report_Vehiclewise_'+str(yestdate)+'.xlsx'


# In[16]:

pudrmssummarymail = pudrmssummarymail.to_string(index=False)


# In[17]:

filePath = oppath2
def sendEmail(TO = ["goutam.barik@spoton.co.in","sukumar.sakthivel@spoton.co.in"],
              #TO = ["vishwas.j@spoton.co.in"],
              #TO = ["rajeesh.vr@spoton.co.in"],
              CC = ["abhik.mitra@spoton.co.in","rajeesh.vr@spoton.co.in"],
              #CC = ["vishwas.j@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "PUD RMS Report - "+ str(yestdate)
    msg["Subject"] = "PUD RMS Report - "+ str(yestdate)
    body_text = """
    Dear All,
    
    PFB the PUD RMS summay for PAN-INDIA for """+str(yestdate)+"""
    
"""+str(pudrmssummarymail)+"""
    
    
    Sheet Legends:
    1) 'All_vehicles' sheet has vehicewise utilization of the PUD RMS enabled branches. 'Utilization_Remarks' column indicates how well the vehicle has been utilized. If the utilization is more than 300%, a remark of High utilization is given. 
    If the utilization is less than 50%, a remark of Low utilization is given.
    2) 'PAN_INDIA_Summary' gives the Depot-wise summary of the Utilization, Mispickups and Undelivered % 
    3) 'STD_Vehicles_not_reported' gives the number of days a STD/Fixed vehicle not reported
    4) 'STD_Vehicles_in_ADHOC' gives the list of STD/Fixed vehicles which were used as market vehicles
    
    """
    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends

