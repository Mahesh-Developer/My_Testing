
# coding: utf-8

# In[ ]:


import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
import calendar
import datetime
from pandas import ExcelWriter
import os
import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from string import Template
import ftplib
from sqlalchemy import *
import pandas.io.sql
import sys
import Utilities


reload(sys).setdefaultencoding("ISO-8859-1")


#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.87;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
#cursor = cnxn.cursor() 
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()

try:
    opfilevar =date.today() - timedelta(hours=24)
    opfilevarhours =datetime.datetime.now() - timedelta(hours=24)
    #yesterday = datetime.datetime.today() - datetime.timedelta (days=1) 
    new_period=opfilevarhours.replace(hour=12, minute=0).strftime ('%Y-%m-%d %H:%M:%S')
    print (new_period)

    query = ("""
            EXEC UBESP_PUD_ANALYSIS_OPEN_CLOSE_STOCK_ARRV_DELV_SSRS_OS
            """)

    openingstock=pd.read_sql(query, Utilities.cnxn)
    # openingstock=pd.read_sql(query, cnxn)


    query1 = ("""
            EXEC UBESP_PUD_ANALYSIS_OPEN_CLOSE_STOCK_ARRV_DELV_SSRS_IN
            """)

    fullincomingstock=pd.read_sql(query1, Utilities.cnxn)
    # fullincomingstock=pd.read_sql(query1, cnxn)

    query2 = ("""
            EXEC UBESP_PUD_ANALYSIS_OPEN_CLOSE_STOCK_ARRV_DELV_SSRS_DL
            """)

    deliveredstock=pd.read_sql(query2, Utilities.cnxn)
    # deliveredstock=pd.read_sql(query2, cnxn)


    query3 = ("""
            EXEC UBESP_PUD_ANALYSIS_OPEN_CLOSE_STOCK_ARRV_DELV_SSRS_CS
            """)


    closingstockfull=pd.read_sql(query3, Utilities.cnxn)
    # closingstockfull=pd.read_sql(query3, cnxn)


    print len(openingstock), len(fullincomingstock), len(deliveredstock), len(closingstockfull)


    print (len(openingstock),len(fullincomingstock),len(deliveredstock))
    openingstock.rename(columns={'CDELDT':'DUE DATE','DeliveryStatus': 'Delivery Status','REPORTDATE_MIN_ARRVDT':'REPORTDATE MIN ARRVDT','ConStatusCode':'Con Status Code','DEL_LOCATION_TYPE':'DEL LOCATION TYPE','DEST_BRCD':'DEST BRCD','DEST_AREA':'DEST AREA'},inplace=True)
    fullincomingstock.rename(columns={'INC_ARRV_CATEGORY':'INC ARRV CATEGORY','ConStatusCode':'Con Status Code','DEL_LOCATION_TYPE':'DEL LOCATION TYPE','DEST_BRCD':'DEST BRCD','DEST_AREA':'DEST AREA'},inplace=True)
    deliveredstock.rename(columns={'CDELDT':'DUE DATE','DELY_DT':'DELY DT','ConStatusCode':'Con Status Code','DEL_LOCATION_TYPE':'DEL LOCATION TYPE','DEST_BRCD':'DEST BRCD','DEST_AREA':'DEST AREA'},inplace=True)
    closingstockfull.rename(columns={ 'CDELDT':'DUE DATE','REPORTDATE_MIN_ARRVDT':'REPORTDATE MIN ARRVDT','IS_FREE_CON':'Is Free Con','ARRV_AT_DEST_SC':'ARRV AT DEST SC','ConStatusCategory':'Con Status Category','ConStatusCode':'Con Status Code','DEL_LOCATION_TYPE':'DEL LOCATION TYPE','DEST_BRCD':'DEST BRCD','DEST_AREA':'DEST AREA'},inplace=True)

    # openingstock = pd.io.excel.read_excel(r'http://10.109.230.50/downloads/OCID/OCID.xls','OPENING STOCK')
    # fullincomingstock = pd.io.excel.read_excel(r'http://10.109.230.50/downloads/OCID/OCID.xls','INCOMING')
    # deliveredstock = pd.io.excel.read_excel(r'http://10.109.230.50/downloads/OCID/OCID.xls','DELIVERED')
    # closingstockfull = pd.io.excel.read_excel(r'http://10.109.230.50/downloads/OCID/OCID.xls','CLOSING STOCK')

    ### Fillna for blank Parent and other codes

    openingstock=openingstock.fillna({'PARENTCODE':0,'CSGNCD':0,'CSGECD':0})
    fullincomingstock=fullincomingstock.fillna({'PARENTCODE':0,'CSGNCD':0,'CSGECD':0})
    deliveredstock=deliveredstock.fillna({'PARENTCODE':0,'CSGNCD':0,'CSGECD':0})
    closingstockfull=closingstockfull.fillna({'PARENTCODE':0,'CSGNCD':0,'CSGECD':0})



    # To exclude Liberty FOC cons
    liblist = ['000119721']
    openingstock = openingstock[~(openingstock['CSGNCD'].isin(liblist))&~(openingstock['CSGECD'].isin(liblist))]
    deliveredstock = deliveredstock[~(deliveredstock['CSGNCD'].isin(liblist))&~(deliveredstock['CSGECD'].isin(liblist))]
    fullincomingstock = fullincomingstock[~(fullincomingstock['CSGNCD'].isin(liblist))&~(fullincomingstock['CSGECD'].isin(liblist))]

    ## To Exclude Reliance project cons ## Added pantaloons on 12-09-2018 ## Adding NCR on 03-12-2018
    projectparentcodesexclist = ['000117991','000118040','000118041','000118042','000118043','000118075','000111007','000114381','000120083']
    #projectparentcodesexclist = [000111007.0]
    openingstock = openingstock[~(openingstock['PARENTCODE'].isin(projectparentcodesexclist))]
    fullincomingstock = fullincomingstock[~(fullincomingstock['PARENTCODE'].isin(projectparentcodesexclist))]
    deliveredstock = deliveredstock[~(deliveredstock['PARENTCODE'].isin(projectparentcodesexclist))]

    print len(openingstock), len(fullincomingstock), len(deliveredstock)


    projectconsgcd = ['000117991','000118040','000118041','000118043','000111007','000118042','000118075','000114381']
    openingstock = openingstock[~(openingstock['CSGNCD'].isin(projectconsgcd))&~(openingstock['CSGECD'].isin(projectconsgcd))]
    fullincomingstock = fullincomingstock[~(fullincomingstock['CSGNCD'].isin(projectconsgcd))&~(fullincomingstock['CSGECD'].isin(projectconsgcd))]
    deliveredstock = deliveredstock[~(deliveredstock['CSGNCD'].isin(projectconsgcd))&~(deliveredstock['CSGECD'].isin(projectconsgcd))]

    parentcodesexclist = ['000116867','000118067','000118068','000108751','000118554']
    destareaexcludelist = ['BOMA','HYDA', 'NCRA', 'BLRA'] ## Added HYDA on 27-10-2017
    openingstock = openingstock[~((openingstock['PARENTCODE'].isin(parentcodesexclist)) & (openingstock['DEST AREA'].isin(destareaexcludelist)))]
    fullincomingstock = fullincomingstock[~((fullincomingstock['PARENTCODE'].isin(parentcodesexclist))& (fullincomingstock['DEST AREA'].isin(destareaexcludelist)))]
    deliveredstock = deliveredstock[~((deliveredstock['PARENTCODE'].isin(parentcodesexclist)) & (deliveredstock['DEST AREA'].isin(destareaexcludelist)))]


    delbranchdf=deliveredstock[['DEST BRCD','DEST AREA']]
    opbranchdf=openingstock[['DEST BRCD','DEST AREA']]
    branchdf = pd.merge(delbranchdf,opbranchdf,on=['DEST BRCD','DEST AREA'],how='outer')
    branchdf.rename(columns={'DEST BRCD':'BRANCH CODE','DEST AREA':'Area'}, inplace=True)
    branchdf = branchdf.drop_duplicates(['BRANCH CODE'])


    ## Connecting to db
    # cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
    # cursor = cnxn.cursor()

    ## For Holiday exclusion
    holidayquery = ("""
            select * from tblYearlyHolidayMst with (nolock) where HDAY_DATE>'2016-01-01'
            """)


    holidaymaster = pd.read_sql(holidayquery, Utilities.cnxn)

    def datestring(x):
        try:
            x = str(x)
            fulldate = datetime.datetime.strptime(x,'%Y-%m-%d %H:%M:%S')
            return fulldate
        except:
            x = str(x)
            fulldate = datetime.datetime.strptime(x,'%d-%m-%Y %H:%M')
            return fulldate


    holidaymaster['HDAY_DATE'] = holidaymaster.apply(lambda x : datestring(x['HDAY_DATE']),axis=1)


    now = datetime.datetime.now()
    selectdate = now-timedelta(days=1)
    selectdate = selectdate.replace(hour=0, minute=0, second=0).strftime('%Y-%m-%d %H:%M:%S')
    selectdate = datetime.datetime.strptime(selectdate,'%Y-%m-%d %H:%M:%S')

    holidaylist = list(set(holidaymaster['HDAY_DATE'].tolist()))

    ## check yesterday in holiday list
    if selectdate in holidaylist:
        print ('Yesterday in holiday list')
        selectdf = holidaymaster[holidaymaster['HDAY_DATE']==selectdate]
        selectdfbrcdlist = selectdf['BRCD'].tolist()
        selectdfbrcdlist = list(set(selectdfbrcdlist))
        selectdfarealist = selectdf['ControlArea'].tolist()
        selectdfarealist = list(set(selectdfarealist))
        print (selectdfbrcdlist)
        print (selectdfarealist)
        
        openingstock = openingstock[~(openingstock['DEST BRCD'].isin(selectdfbrcdlist))]
        openingstock = openingstock[~(openingstock['DEST AREA'].isin(selectdfarealist))]
        
        fullincomingstock = fullincomingstock[~(fullincomingstock['DEST BRCD'].isin(selectdfbrcdlist))]
        fullincomingstock = fullincomingstock[~(fullincomingstock['DEST AREA'].isin(selectdfarealist))]
        
        deliveredstock = deliveredstock[~(deliveredstock['DEST BRCD'].isin(selectdfbrcdlist))]
        deliveredstock = deliveredstock[~(deliveredstock['DEST AREA'].isin(selectdfarealist))]
    else:
        selectdfbrcdlist = []
        selectdfarealist = []
        print ('Yesterday not in holiday list')



    ### Filtering out DRS Blocked for Pay issues. Added this snippet on 03-12-2018

    openingstock = openingstock[openingstock['CON_BLOCKED_FOR_PAY_ISSUES']=='NO']
    fullincomingstock = fullincomingstock[fullincomingstock['CON_BLOCKED_FOR_PAY_ISSUES']=='NO']
    # deliveredstock = deliveredstock[deliveredstock['CON_BLOCKED_FOR_PAY_ISSUES']=='NO']
    closingstockfull = closingstockfull[closingstockfull['CON_BLOCKED_FOR_PAY_ISSUES']=='NO']

    ## Filtering STD 

    openingstock_std = openingstock[openingstock['DEL LOCATION TYPE']=='STD']
    fullincomingstock_std = fullincomingstock[fullincomingstock['DEL LOCATION TYPE']=='STD']
    deliveredstock_std = deliveredstock[deliveredstock['DEL LOCATION TYPE']=='STD']
    closingstockfull_std = closingstockfull[closingstockfull['DEL LOCATION TYPE']=='STD']

    ##ignorestatuscodelist
    ignorestatuscodelist = ['UCG','SSC','UG1','UG2','UG3','SHS']
    #ignorestatuscodelist = ['UCG','SSC','UG1','UG2','UG3']
    #ignorestatusdesclist = ['Awaiting for NSL Delivery Confirmation', 'Awaiting for ODA Delivery Confirmation', 'Change of Pincode from STD to ODA - Pending Approval', 'Non Serviceable Location', 'ODA DRS PREPARED', 'Shipment Held for ODA Delivery', 'Shipment held for Sales Tax inspection', 'Shipment Seized By Check Post / Sales Tax','STD to ODA Pincode Change Request - Awaiting CS Confirmation','Tagged For UCG']
    openingstock_std=openingstock_std[~openingstock_std['Con Status Code'].isin(ignorestatuscodelist)]
    closingstockfull_std=closingstockfull_std[~closingstockfull_std['Con Status Code'].isin(ignorestatuscodelist)]


    incoming12stock_std = fullincomingstock_std[(fullincomingstock_std['INC ARRV CATEGORY']=='<12PM')]
    openinggroupby_std=openingstock_std.groupby(['DEST BRCD']).agg({'DOCKNO': 'count'}).reset_index()
    incoming12groupby_std=incoming12stock_std.groupby(['DEST BRCD']).agg({'DOCKNO': 'count'}).reset_index()
    deliveredgroupby_std=deliveredstock_std.groupby(['DEST BRCD']).agg({'DOCKNO': 'count'}).reset_index()


    merge_effeciency_std = pd.merge(openinggroupby_std,incoming12groupby_std,on=['DEST BRCD'], suffixes=['_op','_in'],how='outer')
    merge_effeciency_std = pd.merge(merge_effeciency_std,deliveredgroupby_std, on=['DEST BRCD'], how='outer')
    merge_effeciency_std = merge_effeciency_std.fillna(0)


    merge_effeciency_std['Delivery_Efficiency']=pd.np.round((merge_effeciency_std['DOCKNO']*100.0/(merge_effeciency_std['DOCKNO_op']+merge_effeciency_std['DOCKNO_in'])).replace([np.inf,-np.inf],np.nan).fillna(0),2)

    merge_effeciency_std.rename(columns={'DOCKNO':'DOCKNO_Delivered'}, inplace=True)
    merge_effeciency_std=pd.merge(merge_effeciency_std,branchdf,left_on=['DEST BRCD'],right_on=['BRANCH CODE'], how = 'inner')
    merge_effeciency_std = merge_effeciency_std.drop(['BRANCH CODE'], axis=1)

    openingcons_std = merge_effeciency_std['DOCKNO_op'].sum() 
    incomingcons_std = merge_effeciency_std['DOCKNO_in'].sum()
    deliveredcons_std = merge_effeciency_std['DOCKNO_Delivered'].sum()
    deliveryefficiency_std = pd.np.round(deliveredcons_std*100.0/(incomingcons_std+openingcons_std),2)
    merge_effeciency_area_std=merge_effeciency_std.groupby(['Area']).agg({'DOCKNO_op': 'sum','DOCKNO_in': 'sum','DOCKNO_Delivered': 'sum'}).reset_index()


    merge_effeciency_area_std['Delivery_Efficiency']=pd.np.round((merge_effeciency_area_std['DOCKNO_Delivered']*100.0/(merge_effeciency_area_std['DOCKNO_op']+merge_effeciency_area_std['DOCKNO_in'])).replace([np.inf,-np.inf],np.nan).fillna(0),2)

    ## For CCF % AREA wise in Closing Stock
    ccfsrlist = ['SENDER FAILURE', 'RECEIVER FAILURE']
    ccfsrdf_std=closingstockfull_std[closingstockfull_std['Con Status Category'].isin(ccfsrlist)]
    ccfsrdfgroupby_std = ccfsrdf_std.groupby(['DEST AREA']).agg({'DOCKNO': 'count'}).reset_index()

    ## For NON CCF Cons
    nonccfsrdf_std=closingstockfull_std[~closingstockfull_std['Con Status Category'].isin(ccfsrlist)]
    nonccfsrdfgroupby_std = nonccfsrdf_std.groupby(['DEST AREA']).agg({'DOCKNO': 'count'}).reset_index()
    nonccfcons_std = nonccfsrdfgroupby_std['DOCKNO'].sum()


    def datetimesplit(x):
        fulldate = datetime.strptime(x.split(' '),'%d-%m-%Y %H:%M:S')
        return fulldate


    opfilevar =date.today() - timedelta(hours=24)

    closingstockduecons_std = closingstockfull_std[closingstockfull_std['DUE DATE']==opfilevar]
    print len(closingstockduecons_std)
    closingstockduecons_std['ARRV_AT_DEST_SC'] = closingstockduecons_std.apply(lambda x:(x['ARRV AT DEST SC']),axis=1)
    closingarriv12_std = closingstockduecons_std[closingstockduecons_std['ARRV_AT_DEST_SC']<=new_period]
    closingarriv12free_std = closingarriv12_std[closingarriv12_std['Is Free Con']=='YES']

    closingarriv12grp_std = closingarriv12_std.groupby(['DEST AREA']).agg({'DOCKNO':len}).reset_index()
    totalduecons_std = closingarriv12grp_std['DOCKNO'].sum()
    closingarriv12freegrp_std = closingarriv12free_std.groupby(['DEST AREA']).agg({'DOCKNO':len}).reset_index()
    totaldueconsfree_std = closingarriv12freegrp_std['DOCKNO'].sum()

    cutoffformorefreecons = 0.1*totaldueconsfree_std
    cutoffformorefreecons


    morefreeconsdestarealist_std = closingarriv12freegrp_std[closingarriv12freegrp_std['DOCKNO']>=cutoffformorefreecons]['DEST AREA'].tolist()
    morefreeconsdestarealist = [str(x) for x in morefreeconsdestarealist_std]
    morefreeconslist_std = closingarriv12freegrp_std[closingarriv12freegrp_std['DOCKNO']>=cutoffformorefreecons]['DOCKNO'].tolist()
    morefreeconslist = [str(x) for x in morefreeconslist_std]
    combinedfreeconlist_std = zip(morefreeconsdestarealist,morefreeconslist)

    closingnotdel_std = pd.merge(closingarriv12grp_std,closingarriv12freegrp_std,left_on=['DEST AREA'],right_on=['DEST AREA'],suffixes=['_MissedDD','_Missed_FreeDD'],how='outer')

    ### For Closing stock Aging

    closingstockfullpivot_std = closingstockfull_std.groupby(['DEST AREA']).agg({'DOCKNO': 'count'}).reset_index()
    closingstockcons_std = closingstockfullpivot_std['DOCKNO'].sum()
    efficiencyclstock_std = pd.merge(merge_effeciency_area_std,closingstockfullpivot_std,left_on=['Area'],right_on=['DEST AREA'], how = 'inner')

    closingstoctl24_std = closingstockfull_std[closingstockfull_std['REPORTDATE MIN ARRVDT']>=39]
    closingstoctl24cons_std = len(closingstoctl24_std)
    closingstoctl24aging_std = np.ceil(closingstoctl24_std['REPORTDATE MIN ARRVDT'].sum()/closingstoctl24cons_std)


    closingstoctl24groupby_std=closingstoctl24_std.groupby(['DEST AREA']).agg({'DOCKNO': 'count', 'REPORTDATE MIN ARRVDT':'sum'}).reset_index()


    #closingstoctl24groupby['Avg_Cooling_Hrs']=closingstoctl24groupby.apply (lambda x : getavg(x['DOCKNO'],x['REPORTDATE MIN ARRVDT']),axis=1)
    closingstoctl24groupby_std['Avg_Cooling_Hrs']=closingstoctl24groupby_std['REPORTDATE MIN ARRVDT']/closingstoctl24groupby_std['DOCKNO']


    closingstoctl24gb_std = closingstoctl24groupby_std.groupby(['DEST AREA']).agg({'DOCKNO':'sum','Avg_Cooling_Hrs':np.mean}).reset_index()


    efficiencyclstockfull_std = pd.merge(efficiencyclstock_std,closingstoctl24gb_std,left_on=['Area'],right_on=['DEST AREA'], how = 'inner')
    efficiencyclstockfull_std = efficiencyclstockfull_std.drop(['DEST AREA_x'], axis=1)
    efficiencyclstockfull_std = efficiencyclstockfull_std.drop(['DEST AREA_y'], axis=1)


    efficiencyclstockfull_std.rename(columns={'DOCKNO_x':'Closing_Stock','DOCKNO_y':'Closing_Stock>24hrs','Avg_Cooling_Hrs':'Avg_Cooling_Hrs>24hrs'},inplace=True)


    def ccfperc(x,y):
        return np.ceil((x*100.0)/(y))


    efficiencyclstockfullccf_std = pd.merge(efficiencyclstockfull_std,ccfsrdfgroupby_std,left_on=['Area'],right_on=['DEST AREA'], how = 'outer')
    efficiencyclstockfullccf_std['%CCF_Cons'] = efficiencyclstockfullccf_std.apply (lambda x : ccfperc(x['DOCKNO'],x['Closing_Stock']),axis=1)
    efficiencyclstockfullccf_std = efficiencyclstockfullccf_std.rename(columns={'DOCKNO':'CCF_Cons'})


    ccfconsno_std = efficiencyclstockfullccf_std['CCF_Cons'].sum()
    ccfpercentagecons_std = pd.np.round((ccfconsno_std*100.0)/closingstockcons_std,2)


    def effcheck(x,y):
        if x<65 and y<65:
            return 'Check'
        else:
            return '-'


    def setceil(x):
        return pd.np.round(x,0)


    efficiencyclstockfullccf_std = pd.merge(efficiencyclstockfullccf_std,nonccfsrdfgroupby_std,left_on=['Area'],right_on=['DEST AREA'], how = 'outer') 
    efficiencyclstockfullccf_std = pd.merge(efficiencyclstockfullccf_std,closingnotdel_std,left_on=['Area'],right_on=['DEST AREA'], how = 'outer') 
    efficiencyclstockfullccf_std['REMARKS'] = efficiencyclstockfullccf_std.apply(lambda x :effcheck(x['Delivery_Efficiency'],x['%CCF_Cons']),axis =1)

    efficiencyclstockfullccf_std.rename(columns={'DOCKNO':'NON_CCF_Cons','DOCKNO_MissedDD':'Due_Undel','DOCKNO_Missed_FreeDD':'Due_Undel_Free'},inplace=True)

    columnsopreqcols=['Area','DOCKNO_Delivered','Delivery_Efficiency','%CCF_Cons','NON_CCF_Cons','REMARKS','Due_Undel','Due_Undel_Free']
    efficiencyreqcols_std = pd.DataFrame(efficiencyclstockfullccf_std,columns=columnsopreqcols)


    efficiencyreqcols_std.rename(columns={'DOCKNO_Delivered':'DELIVERED','Delivery_Efficiency':'DELIVERY_EFFY'},inplace=True)


    efficiencyreqcols_std['DELIVERY_EFFY'] = efficiencyreqcols_std.apply(lambda x :setceil(x['DELIVERY_EFFY']),axis =1)


    sumlist = ['TOTAL',deliveredcons_std,deliveryefficiency_std,ccfpercentagecons_std,nonccfcons_std,'-',totalduecons_std,totaldueconsfree_std]
    col_list = ['Area','DELIVERED','DELIVERY_EFFY','%CCF_Cons','NON_CCF_Cons','REMARKS','Due_Undel','Due_Undel_Free']
    totalsdf_std = pd.DataFrame(data=[sumlist], columns = col_list)
    efficiencyreqcols_std = efficiencyreqcols_std.append(totalsdf_std,ignore_index=True)
    efficiencyclstockfullccf_std = efficiencyclstockfullccf_std.drop(['DEST AREA_x','DEST AREA_y','REMARKS'], axis=1)

    merge_effeciency_std =merge_effeciency_std[~(merge_effeciency_std['DEST BRCD'].isin(selectdfbrcdlist))]
    efficiencyclstockfullccf_std =efficiencyclstockfullccf_std[~(efficiencyclstockfullccf_std['Area'].isin(selectdfarealist))]
    efficiencyreqcols_std=efficiencyreqcols_std[~(efficiencyreqcols_std['Area'].isin(selectdfarealist))]

    oppath1=r'D:\Data\eta_rank\Delivery_Efficiency\Delivery_Efficiency_'+str(opfilevar)+'.xlsx'

    with ExcelWriter(r'D:\Data\eta_rank\Delivery_Efficiency\Delivery_Efficiency_'+str(opfilevar)+'.xlsx') as writer:
        ###orginal_cancel_basedata.to_excel(writer, sheet_name='Sheet1',engine='xlsxwriter')
        merge_effeciency_std.to_excel(writer, sheet_name='SC_WISE',engine='xlsxwriter')
        efficiencyclstockfullccf_std.to_excel(writer, sheet_name='AREA_WISE',engine='xlsxwriter')

    merge_effeciency_std.to_csv(r'D:\Data\eta_rank\STD_DE_SC.csv', encoding='utf-8')
    efficiencyclstockfullccf_std.to_csv(r'D:\Data\eta_rank\STD_DE.csv', encoding='utf-8')


    def datestring2(tsp):
        tsp = str(tsp)
        try:
            return datetime.datetime.strptime(tsp.split(' ')[0], '%d-%m-%Y')
        except:
            return datetime.datetime.strptime(tsp.split(' ')[0], '%Y-%m-%d')


    def datestring(x):
        try:
            fulldate = datetime.datetime.strptime(x,'%Y-%m-%d')
            return fulldate
        except:
            fulldate = datetime.datetime.strptime(x,'%d-%m-%Y')
            return fulldate


    deliveredstock_std['Delivery_Date']= deliveredstock_std.apply(lambda x: datestring2(x['DELY DT']), axis=1)
    deliveredstock_std['Due_date'] = deliveredstock_std.apply(lambda x: datestring2(x['DUE DATE']), axis=1)
    deliveredstock_std['DD_DelyDt'] = deliveredstock_std.apply(lambda x: (x['Delivery_Date']-x['Due_date']).days,axis=1)

    sumofdiffdays_std = deliveredstock_std['DD_DelyDt'].sum()
    avrghoursofdelcons_std = pd.np.round((sumofdiffdays_std*24.0)/deliveredcons_std,2)

    filePath1 = oppath1
    #efficiencyreqcols_std=efficiencyreqcols_std.dropna()
    efficiencyreqcols_std=efficiencyreqcols_std.fillna(0)

    #vishwas.j@spoton.co.in
    # TO=["vishwas.j@spoton.co.in"]
    TO = ["reports.ie@spoton.co.in"]
    FROM="reports.ie@spoton.co.in"
    # CC=["vishwas.j@spoton.co.in"]
    CC = ["sqtf@spoton.co.in","SQ_spot@spoton.co.in","vishwas.j@spoton.co.in","abhik.mitra@spoton.co.in"]
    # BCC=["vishwas.j@spoton.co.in"]
    BCC = ["shashvat.suhane@spoton.co.in","mahesh.reddy@spoton.co.in","sachidanand.pandey@spoton.co.in","renugopal.l@spoton.co.in","sathya.chander@spoton.co.in","alagu.mahendran@spoton.co.in","awadhesh.kumar.mishra@spoton.co.in","sanjay.parab@spoton.co.in","ramesh.s@spoton.co.in","md.zaya@spoton.co.in","Pradyumna.Kumar@Spoton.Co.In","rajesh.mishra@spoton.co.in","raghavendra.rao@spoton.co.in","ashwani.gangwar@spoton.co.in","pramod.pandey@spoton.co.in","trilochan.panda@spoton.co.in","sunil.nakte@spoton.co.in","chandrima.banerjee@spoton.co.in", "suresh.d@spoton.co.in", "pankaj.jha@spoton.co.in","aom_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in","narendra.londhe@spoton.co.in"]
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    html='''<html>
    <style>
    p
    {
      margin:0;
      margin-top: 5px;
      padding:0;
      font-size:15px;
        line-height:20px;
    }
    </style>
    <h4>Dear All,</h4>
    <p>Delivered = $deliveredcons_std</p>
    <p>Opening Stock = $openingcons_std</p>
    <p>Incoming Stock = $incomingcons_std</p>
    <p>The Overall Delivery efficiency of STD cons is $deliveryefficiency_std %</p>
    <p>PFB the Delivery Efficiency Area wise as of $opfilevar</p>
    </html>'''

    html3='''
    <h5>The AREA-WISE and SC-WISE summary has been attached in the mail.</h5>
    <h5> For the base data, please refer the link </h5>
    <p><a href= "http://10.109.230.50/downloads/OCID/OCID.xls"</a>http://10.109.230.50/downloads/OCID/OCID.xls</p></b>
    '''
    s = Template(html).safe_substitute(deliveryefficiency_std=deliveryefficiency_std,avrghoursofdelcons_std=avrghoursofdelcons_std,ccfpercentagecons_std=ccfpercentagecons_std,combinedfreeconlist_std=combinedfreeconlist_std,totaldueconsfree_std=totaldueconsfree_std,totalduecons_std=totalduecons_std,opfilevar=opfilevar,closingstoctl24aging_std=closingstoctl24aging_std,closingstoctl24cons_std=closingstoctl24cons_std,closingstockcons_std=closingstockcons_std,incomingcons_std=incomingcons_std,openingcons_std=openingcons_std,deliveredcons_std=deliveredcons_std)
    report=""
    report+=s
    report+='<br>'
    report+='<br>'+efficiencyreqcols_std.to_html()+'<br>'
    report+=html3
    abc=MIMEText(report,'html')
    msg.attach(abc)
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath1,"rb").read() )
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath1))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    # server=smtplib.SMTP('smtp.gmail.com', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    # server.login('vishwas.j@spoton.co.in', 'Nov@2018')
    failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
    server.quit()


    ### Removed parameters from the email on 29-01-2019
    # <p>Closing Stock = $closingstockcons_std</p>
    # <p>Closing Stock > 24hrs =$closingstoctl24cons_std</p>
    # <p>Average Ageing of Closing Stock >24hrs = $closingstoctl24aging_std hrs</p>
    # <p>Cons of Duedate $opfilevar not delivered = $totalduecons_std</p>
    # <p>CCF Cons % of Closing Stock = $ccfpercentagecons_std %</p>
    # <p>Average Delay Hours of Delivered Cons = $avrghoursofdelcons_std Hrs</p>


    with ExcelWriter(r'D:\Data\DE_Conwise_Stock\DE_STD\Delivery_Efficiency_STD_'+str(opfilevar)+'.xlsx') as writer:
        openingstock.to_excel(writer, sheet_name='OPENING_STOCK',engine='xlsxwriter')
        incoming12stock_std.to_excel(writer, sheet_name='INCOMING_STOCK',engine='xlsxwriter')
        deliveredstock.to_excel(writer, sheet_name='DELIVERED',engine='xlsxwriter')
        closingstockfull.to_excel(writer, sheet_name='CLOSING_STOCK',engine='xlsxwriter')


    # ODA Delivery Efficiency starts from here


    openingstock_oda = openingstock[openingstock['DEL LOCATION TYPE']=='ODA']
    deliveredstock_oda = deliveredstock[deliveredstock['DEL LOCATION TYPE']=='ODA']

    openingstock_oda=openingstock_oda[~openingstock_oda['Con Status Code'].isin(ignorestatuscodelist)]


    openingstock_oda = openingstock_oda[(openingstock_oda['REPORTDATE MIN ARRVDT']>48)]
    openinggroupby_oda=openingstock_oda.groupby(['DEST BRCD']).agg({'DOCKNO': 'count'}).reset_index()

    deliveredgroupby_oda=deliveredstock_oda.groupby(['DEST BRCD']).agg({'DOCKNO': 'count'}).reset_index()
    merge_effeciency_oda = pd.merge(openinggroupby_oda,deliveredgroupby_oda, on=['DEST BRCD'], suffixes=['_open','_d'], how='outer')
    merge_effeciency_oda = merge_effeciency_oda.fillna(0)

    merge_effeciency_oda['Delivery_Efficiency']=pd.np.round((merge_effeciency_oda['DOCKNO_d']*100.0/merge_effeciency_oda['DOCKNO_open']).replace([np.inf,-np.inf],np.nan).fillna(0),2)

    merge_effeciency_oda.rename(columns={'DOCKNO_d':'DOCKNO_Delivered'}, inplace=True)
    merge_effeciency_oda=pd.merge(merge_effeciency_oda,branchdf,left_on=['DEST BRCD'],right_on=['BRANCH CODE'], how = 'inner')

    merge_effeciency_oda = merge_effeciency_oda.drop(['BRANCH CODE'], axis=1)
    openingcons_oda = merge_effeciency_oda['DOCKNO_open'].sum() 
    deliveredcons_oda = merge_effeciency_oda['DOCKNO_Delivered'].sum()
    deliveryefficiency_oda = pd.np.round(deliveredcons_oda*100.0/(openingcons_oda),2)

    merge_effeciency_area_oda=merge_effeciency_oda.groupby(['Area']).agg({'DOCKNO_open': 'sum','DOCKNO_Delivered': 'sum'}).reset_index()

    merge_effeciency_area_oda['Delivery_Efficiency']=pd.np.round((merge_effeciency_area_oda['DOCKNO_Delivered']*100.0/merge_effeciency_area_oda['DOCKNO_open']).replace([np.inf,-np.inf],np.nan).fillna(0),2)
    #merge_effeciency_area['Delivery_Efficiency']= merge_effeciency_area.apply(lambda x:getsum(x['DOCKNO_Delivered'],x['DOCKNO_open']),axis=1)

    sumlist_oda = ['TOTAL',deliveredcons_oda,openingcons_oda,deliveryefficiency_oda]
    col_list_oda = ['Area','DOCKNO_Delivered','DOCKNO_open','Delivery_Efficiency']
    totalsdf_oda = pd.DataFrame(data=[sumlist_oda], columns = col_list_oda)
    merge_effeciency_area_oda = merge_effeciency_area_oda.append(totalsdf_oda,ignore_index=True)

    openingstocknotdel_oda = openingstock_oda[openingstock_oda['Delivery Status']=='NO']
    dueyestopening_oda = openingstocknotdel_oda[openingstocknotdel_oda['DUE DATE']==opfilevar]
    dueyestopeningcons_oda = len(dueyestopening_oda)

    merge_effeciency_oda =merge_effeciency_oda[~(merge_effeciency_oda['DEST BRCD'].isin(selectdfbrcdlist))]
    merge_effeciency_area_oda =merge_effeciency_area_oda[~(merge_effeciency_area_oda['Area'].isin(selectdfarealist))]


    oppath2=r'D:\Data\eta_rank\Delivery_Efficiency_ODA\Delivery_Efficiency_ODA_'+str(opfilevar)+'.xlsx'


    with ExcelWriter(r'D:\Data\eta_rank\Delivery_Efficiency_ODA\Delivery_Efficiency_ODA_'+str(opfilevar)+'.xlsx') as writer:
        merge_effeciency_oda.to_excel(writer, sheet_name='SC_WISE',engine='xlsxwriter')
        merge_effeciency_area_oda.to_excel(writer, sheet_name='AREA_WISE',engine='xlsxwriter')


    with ExcelWriter(r'D:\Data\DE_Conwise_Stock\DE_ODA\Delivery_Efficiency_ODA_'+str(opfilevar)+'.xlsx') as writer:
        openingstock_oda.to_excel(writer, sheet_name='OPENING_STOCK',engine='xlsxwriter')
        deliveredstock_oda.to_excel(writer, sheet_name='DELIVERED',engine='xlsxwriter')

    merge_effeciency_oda.to_csv(r'D:\Data\eta_rank\ODA_DE_SC.csv', encoding='utf-8')
    merge_effeciency_area_oda.to_csv(r'D:\Data\eta_rank\ODA_DE.csv', encoding='utf-8')


    deliveredstock_oda['Delivery_Date']= deliveredstock_oda.apply(lambda x: datestring2(x['DELY DT']), axis=1)
    deliveredstock_oda['Due_date'] = deliveredstock_oda.apply(lambda x: datestring2(x['DUE DATE']), axis=1)
    deliveredstock_oda['DD_DelyDt'] = deliveredstock_oda.apply(lambda x: (x['Delivery_Date']-x['Due_date']).days,axis=1)

    #### For Average Delay hours of DELIVERED CONS
    sumofdiffdays_oda = deliveredstock_oda['DD_DelyDt'].sum()
    avrghoursofdelcons_oda = pd.np.round((sumofdiffdays_oda*24.0)/deliveredcons_oda,2)

    filePath2 = oppath2

    ## Mail part for ODA Delivery Efficiency
    # TO=["vishwas.j@spoton.co.in"]
    TO = ["reports.ie@spoton.co.in"]
    FROM="reports.ie@spoton.co.in"
    # CC=["vishwas.j@spoton.co.in"]
    CC = ["sqtf@spoton.co.in","SQ_spot@spoton.co.in","vishwas.j@spoton.co.in","abhik.mitra@spoton.co.in"]
    # BCC=["vishwas.j@spoton.co.in"]
    BCC = ['mahesh.reddy@spoton.co.in',"sachidanand.pandey@spoton.co.in","renugopal.l@spoton.co.in","sathya.chander@spoton.co.in","alagu.mahendran@spoton.co.in","awadhesh.kumar.mishra@spoton.co.in","sanjay.parab@spoton.co.in","ramesh.s@spoton.co.in","md.zaya@spoton.co.in","Pradyumna.Kumar@Spoton.Co.In","rajesh.mishra@spoton.co.in","raghavendra.rao@spoton.co.in","ashwani.gangwar@spoton.co.in","pramod.pandey@spoton.co.in","trilochan.panda@spoton.co.in","sunil.nakte@spoton.co.in","chandrima.banerjee@spoton.co.in", "suresh.d@spoton.co.in", "pankaj.jha@spoton.co.in","aom_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in","narendra.londhe@spoton.co.in"]
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "ODA DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    html='''<html>
    <style>
    p
    {
      margin:0;
      margin-top: 5px;
      padding:0;
      font-size:17px;
        line-height:20px;
    }
    </style>
    <h4>Dear All,</h4>
    <p>Delivered = $deliveredcons_oda</p>
    <p>Opening Stock = $openingcons_oda</p>
    <p>The Overall Delivery efficiency of ODA cons is $deliveryefficiency_oda %</p>
    <p>PFB the ODA Delivery Efficiency Area wise as of $opfilevar</p>
    <p>The AREA-WISE and SC-WISE summary has been attached in the mail.</p>
    </html>'''

    html3='''
    <h5> For the base data, please refer the link </h5>
    <p><a href= "http://spoton.co.in/downloads/OCID/OCID.xls"</a>http://spoton.co.in/downloads/OCID/OCID.xls</p></b>
    '''
    s = Template(html).safe_substitute(deliveryefficiency_oda=deliveryefficiency_oda,avrghoursofdelcons_oda=avrghoursofdelcons_oda,deliveredcons_oda=deliveredcons_oda,openingcons_oda=openingcons_oda,dueyestopeningcons_oda=dueyestopeningcons_oda,opfilevar=opfilevar)
    report=""
    report+=s
    report+='<br>'
    report+='<br>'+merge_effeciency_area_oda.to_html()+'<br>'
    report+=html3
    abc=MIMEText(report,'html')
    msg.attach(abc)
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath2,"rb").read() )
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath2))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    # server=smtplib.SMTP('smtp.gmail.com', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    # server.login('vishwas.j@spoton.co.in', 'Nov@2018')
    failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
    server.quit()


    ## Removed parameters from mail body
    # <p>Cons of Duedate $opfilevar Not Delivered = $dueyestopeningcons_oda</p>
    # <p>Average Delay Hours of Delivered Cons = $avrghoursofdelcons_oda Hrs</p>


    # Total Delivery Efficiency starts from here

    # stdyest = pd.read_excel(r'C:\Users\rajeeshv\Downloads\Rajesh\mahesh\Total_DE_2018-03-14.xlsx','STD')
    # odayest = pd.read_excel(r'C:\Users\rajeeshv\Downloads\Rajesh\mahesh\Total_DE_2018-03-14.xlsx','ODA')
    # totalyest = pd.read_excel(r'C:\Users\rajeeshv\Downloads\Rajesh\mahesh\Total_DE_2018-03-14.xlsx','Total')

    stdyest = pd.io.excel.read_excel(r'D:\Data\eta_rank\Total_DE.xlsx','STD')
    odayest = pd.io.excel.read_excel(r'D:\Data\eta_rank\Total_DE.xlsx','ODA')
    totalyest = pd.io.excel.read_excel(r'D:\Data\eta_rank\Total_DE.xlsx','Total')


    ## Assigning std and oda dataframes
    stdtoday = efficiencyclstockfull_std
    odatoday = merge_effeciency_area_oda


    opfilevar =date.today() - timedelta(hours=24)
    opfilevarhours = datetime.datetime.now() - timedelta(hours=24)
    #yesterday = datetime.datetime.today() - datetime.timedelta (days=1) 
    new_period=opfilevarhours.replace(hour=12, minute=0).strftime ('%Y-%m-%d %H:%M:%S')

    ## complete closing stock
    #closingstockcomplete = pd.read_excel(r'C:\Users\S2769MAH\Downloads\OCID.xls','CLOSING STOCK')
    #closingstockcomplete = pd.io.excel.read_excel(r'http://10.109.230.50/downloads/OCID/OCID.xls','CLOSING STOCK')
    closingstockcomplete=closingstockfull
    ##ignorestatuscodelist
    ignorestatuscodelist = ['UCG','SSC','UG1','UG2','UG3','SHS']
    openingstock_total=openingstock[~openingstock['Con Status Code'].isin(ignorestatuscodelist)]
    closingstockfull_total=closingstockfull[~closingstockfull['Con Status Code'].isin(ignorestatuscodelist)]
    closingstockfull_total = closingstockfull_total[closingstockfull_total['DEL LOCATION TYPE']=='STD']


    closingstockduecons_total = closingstockfull_total[closingstockfull_total['DUE DATE']==opfilevar]
    closingstockduecons_total['ARRV_AT_DEST_SC'] = closingstockduecons_total.apply(lambda x:x['ARRV AT DEST SC'],axis=1)
    closingarriv12_total = closingstockduecons_total[closingstockduecons_total['ARRV_AT_DEST_SC']<=new_period]
    closingarriv12free_total = closingarriv12_total[closingarriv12_total['Is Free Con']=='YES']

    closingarriv12freegrp_total = closingarriv12free_total.groupby(['DEST AREA']).agg({'DOCKNO':len}).reset_index()

    totalduecons_std_total = len(closingarriv12_total)
    totalduecons12free_std_total = len(closingarriv12free_total)


    openingstock_total = openingstock_total[openingstock_total['DEL LOCATION TYPE']=='ODA']
    openingstock_total = openingstock_total[(openingstock_total['REPORTDATE MIN ARRVDT']>48)]
    openingstocknotdel_total = openingstock_total[openingstock_total['Delivery Status']=='NO']
    dueyestopening_total = openingstocknotdel_total[openingstocknotdel_total['DUE DATE']==opfilevar]
    odadueconlist_total = dueyestopening_total['DOCKNO'].tolist()

    odaduecons_closingstock_total = closingstockcomplete[closingstockcomplete['DOCKNO'].isin(odadueconlist_total)]


    def addstock (x,y,z):
        return x+y+z


    def delivered (x,y):
        return x+y


    def efficiency (x,y):
        if y>0:
            a = pd.np.round(((x*1.0)*100/y),0)
            return a
        else:
            return 100



    def variance (x,y):
        return (x-y)


    columnsop_total = ['Area','Delivery_Efficiency']
    stdyest1_total = pd.DataFrame(stdyest,columns=columnsop_total)
    stdyest1_total=stdyest1_total.rename(columns={'Delivery_Efficiency':'Delivery_Efficiency_Yday'})


    stddf_total = pd.merge(stdtoday,stdyest1_total,left_on=['Area'],right_on=['Area'],how='outer')
    stddf_total['Variance_DE']= stddf_total.apply(lambda x:variance(x['Delivery_Efficiency'],x['Delivery_Efficiency_Yday']),axis=1)
    columnsopstd_total = ['Area','DOCKNO_op','DOCKNO_in','DOCKNO_Delivered','Delivery_Efficiency','Delivery_Efficiency_Yday','Variance_DE','Closing_Stock','Closing_Stock>24hrs','Avg_Cooling_Hrs>24hrs']
    stddf_total = pd.DataFrame(stddf_total,columns=columnsopstd_total)


    columnsop_total = ['Area','Delivery_Efficiency']
    odayest1_total = pd.DataFrame(odayest,columns=columnsop_total)
    odayest1_total=odayest1_total.rename(columns={'Delivery_Efficiency':'Delivery_Efficiency_Yday'})

    odadf_total = pd.merge(odatoday,odayest1_total,left_on=['Area'],right_on=['Area'],how='outer')
    odadf_total['Variance_DE']= odadf_total.apply(lambda x:variance(x['Delivery_Efficiency'],x['Delivery_Efficiency_Yday']),axis=1)
    columnsopoda_total = ['Area','DOCKNO_open','DOCKNO_Delivered','Delivery_Efficiency','Delivery_Efficiency_Yday','Variance_DE']
    odadf_total = pd.DataFrame(odadf_total,columns=columnsopoda_total)


    totaldf_total = pd.merge(stddf_total,odadf_total,left_on =['Area'], right_on=['Area'],suffixes = ['_STD','_ODA'],how='outer')
    #totaldf = pd.merge(stddf,odadf,left_on =['Area'], right_on=['Area'],suffixes = ['_STD','_ODA'],how='left')

    totaldf_total=totaldf_total.fillna(0)

    totaldf_total['Total_Stock']= totaldf_total.apply(lambda x:addstock(x['DOCKNO_op'],x['DOCKNO_in'],x['DOCKNO_open']),axis=1)
    totaldf_total['Total_Delivered']= totaldf_total.apply(lambda x:delivered(x['DOCKNO_Delivered_STD'],x['DOCKNO_Delivered_ODA']),axis=1)
    totaldf_total['Delivery_Efficiency']= totaldf_total.apply(lambda x:efficiency(x['Total_Delivered'],x['Total_Stock']),axis=1)

    columnsoptotaldf=['Area','Total_Stock','Total_Delivered','Delivery_Efficiency']
    totaldf1_total = totaldf_total[['Area','Total_Stock','Total_Delivered','Delivery_Efficiency']]


    columnsopy=['Area','Delivery_Efficiency']
    totalyest_total = pd.DataFrame(totalyest,columns=columnsopy)
    totalyest1_total =totalyest_total.rename(columns={'Delivery_Efficiency':'Delivery_Efficiency_Yday'})


    totaldfwithvar_total = pd.merge(totaldf1_total,totalyest1_total,left_on =['Area'], right_on=['Area'],how='outer')
    columnsop_total=['Area','Total_Stock','Total_Delivered','Delivery_Efficiency','Delivery_Efficiency_Yday']
    totaldfwithvar1_total = pd.DataFrame(totaldfwithvar_total,columns=columnsop_total)


    totaldfwithvar1_total['Variance_DE'] = totaldfwithvar1_total.apply(lambda x:variance(x['Delivery_Efficiency'],x['Delivery_Efficiency_Yday']),axis=1) 
    columnsop1=['Area','Total_Stock','Total_Delivered','Delivery_Efficiency','Delivery_Efficiency_Yday','Variance_DE']
    totaldfwithvar2_total = pd.DataFrame(totaldfwithvar1_total,columns=columnsop1)
    #totaldfwithvar2.to_csv(r'C:\Data\Delivery_efficiency\for_totaldeleffi\totaldfwithvar2.csv')
    totaldfwithvar2_total = totaldfwithvar2_total.drop(totaldfwithvar2_total.tail(1).index)

    stockcons_total = totaldfwithvar2_total['Total_Stock'].sum()
    totaldeliveredcons_total = totaldfwithvar2_total['Total_Delivered'].sum()
    totalefficiency_total = pd.np.round((totaldeliveredcons_total*100.0)/stockcons_total,2)
    sumlist2 = ['TOTAL',stockcons_total,totaldeliveredcons_total,totalefficiency_total,'-','-']
    col_list2 = ['Area','Total_Stock','Total_Delivered','Delivery_Efficiency','Delivery_Efficiency_Yday','Variance_DE']
    totalsdf_total = pd.DataFrame(data=[sumlist2], columns = col_list2)
    totaldfwithvar2_total = totaldfwithvar2_total.append(totalsdf_total,ignore_index=True)

    ## SC WISE TOTAL DELIVERY EFFICIENCY
    stdscwise_total = merge_effeciency_std
    odascwise_total = merge_effeciency_oda

    stdscwise_total.to_csv(r'D:\STD_Summary.csv')
    odascwise_total.to_csv(r'D:\ODA_Summary.csv')


    scwise_total = pd.merge(stdscwise_total,odascwise_total,on=['DEST BRCD','Area'],suffixes=['_STD','_ODA'],how='outer')

    print (scwise_total[scwise_total['DEST BRCD']=='BARF'])

    scwise_total.to_csv(r'D:\SCwise_Merge_Summary.csv')

    scwise_total = pd.DataFrame(scwise_total,columns = ['DEST BRCD','Area','DOCKNO_op','DOCKNO_in','DOCKNO_Delivered_STD','Delivery_Efficiency_STD','DOCKNO_open','DOCKNO_Delivered_ODA','Delivery_Efficiency_ODA'])
    scwise_total=scwise_total.rename(columns={'DOCKNO_op':'DOCK_open_STD','DOCKNO_in':'DOCKNO_in_STD','DOCKNO_open':'DOCKNO_open_ODA'})
    scwise_total = scwise_total.fillna(0)




    scwise_total['Total_Stock']= scwise_total.apply(lambda x:addstock(x['DOCK_open_STD'],x['DOCKNO_in_STD'],x['DOCKNO_open_ODA']),axis=1)
    scwise_total['Total_Delivered']= scwise_total.apply(lambda x:delivered(x['DOCKNO_Delivered_STD'],x['DOCKNO_Delivered_ODA']),axis=1)
    scwise_total['Delivery_Efficiency']= scwise_total.apply(lambda x:efficiency(x['Total_Delivered'],x['Total_Stock']),axis=1)

    scwisesummary_total = pd.DataFrame(scwise_total,columns = ['DEST BRCD','Area','Total_Stock','Total_Delivered','Delivery_Efficiency'])


    stddf_total =stddf_total[~(stddf_total['Area'].isin(selectdfarealist))]
    odadf_total =odadf_total[~(odadf_total['Area'].isin(selectdfarealist))]
    totaldfwithvar2_total =totaldfwithvar2_total[~(totaldfwithvar2_total['Area'].isin(selectdfarealist))]
    scwisesummary_total =scwisesummary_total[~(scwisesummary_total['DEST BRCD'].isin(selectdfbrcdlist))]


    with ExcelWriter(r'D:\Data\eta_rank\Total_DE.xlsx') as writer:
        stddf_total.to_excel(writer, sheet_name='STD',engine='xlsxwriter')
        odadf_total.to_excel(writer, sheet_name='ODA',engine='xlsxwriter')
        totaldfwithvar2_total.to_excel(writer, sheet_name='Total',engine='xlsxwriter')
        scwisesummary_total.to_excel(writer, sheet_name='SC_WISE',engine='xlsxwriter')

    oppath3=r'D:\Data\eta_rank\Total_DE.xlsx'

    with ExcelWriter(r'D:\Data\eta_rank\Delivery_Efficiency_Total\Total_DE_'+str(opfilevar)+'.xlsx') as writer:
        stddf_total.to_excel(writer, sheet_name='STD',engine='xlsxwriter')
        odadf_total.to_excel(writer, sheet_name='ODA',engine='xlsxwriter')
        totaldfwithvar2_total.to_excel(writer, sheet_name='Total',engine='xlsxwriter')
        scwisesummary_total.to_excel(writer, sheet_name='SC_WISE',engine='xlsxwriter')

    oppath4 = r'D:\Data\eta_rank\Delivery_Efficiency_Total\Total_DE_'+str(opfilevar)+'.xlsx'
    filePath4 = oppath4

    ## Mail part for Total Delivery Efficiency

    #vishwas.j@spoton.co.in
    # TO=['vishwas.j@spoton.co.in','shivananda.p@spoton.co.in']
    TO = ["reports.ie@spoton.co.in"]
    # TO=['vishwas.j@spoton.co.in']
    FROM="reports.ie@spoton.co.in"
    # CC=["vishwas.j@spoton.co.in"]
    CC = ["sqtf@spoton.co.in","SQ_spot@spoton.co.in","vishwas.j@spoton.co.in","abhik.mitra@spoton.co.in"]
    BCC = ["shashvat.suhane@spoton.co.in","mahesh.reddy@spoton.co.in","sachidanand.pandey@spoton.co.in","renugopal.l@spoton.co.in","sathya.chander@spoton.co.in","alagu.mahendran@spoton.co.in","awadhesh.kumar.mishra@spoton.co.in","sanjay.parab@spoton.co.in","ramesh.s@spoton.co.in","md.zaya@spoton.co.in","Pradyumna.Kumar@Spoton.Co.In","rajesh.mishra@spoton.co.in","raghavendra.rao@spoton.co.in","ashwani.gangwar@spoton.co.in","pramod.pandey@spoton.co.in","trilochan.panda@spoton.co.in","sunil.nakte@spoton.co.in","chandrima.banerjee@spoton.co.in", "suresh.d@spoton.co.in", "pankaj.jha@spoton.co.in","aom_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in","narendra.londhe@spoton.co.in"]
    # BCC=["vishwas.j@spoton.co.in"]
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "TOTAL DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    html='''<html>
    <style>
    p
    {
      margin:0;
      margin-top: 5px;
      padding:0;
      font-size:15px;
        line-height:20px;
    }
    </style>
    <h4>Dear All,</h4>
    <p>Total Delivered = $totaldeliveredcons_total</p>
    <p>Total Stock = $stockcons_total</p>
    <p>Total Delivery Efficiency = $totalefficiency_total</p>
    <p>PFB the Total Delivery Efficiency as of $opfilevar</p>
    </html>'''

    html3='''
    <h5> To download the Duedate cons Undel, Please click the link below </h5>
    <p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Duedate_cons_undel.xlsx"</a>http://spoton.co.in/downloads/IEProjects/ETA/Duedate_cons_undel.xlsx</p></b>
    '''
    s = Template(html).safe_substitute(opfilevar=opfilevar,totalefficiency_total=totalefficiency_total,stockcons_total=stockcons_total,totaldeliveredcons_total=totaldeliveredcons_total)
    report=""
    report+=s
    report+='<br>'
    report+='<br>'+totaldfwithvar2_total.to_html()+'<br>'
    report+=html3
    abc=MIMEText(report,'html')
    msg.attach(abc)
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath4,"rb").read() )
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath4))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    # server=smtplib.SMTP('smtp.gmail.com', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    # server.login('vishwas.j@spoton.co.in', 'Nov@2018')
    failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
    server.quit()

    duedateconsundel = closingarriv12_total.append(odaduecons_closingstock_total,ignore_index=True)
    duedateconsundelfree = duedateconsundel[duedateconsundel['Is Free Con']=='YES']
    print len(duedateconsundel), len(duedateconsundelfree)
    #exit(0)
    oppath3=r'D:\Data\DE_Conwise_Stock_New\DE_Due_undel\Duedate_cons_undel_'+str(opfilevar)+'.xlsx'
    with ExcelWriter(r'D:\Data\DE_Conwise_Stock_New\DE_Due_undel\Duedate_cons_undel_'+str(opfilevar)+'.xlsx') as writer:
        duedateconsundel.to_excel(writer, sheet_name='DUE_UNDEL',engine='xlsxwriter')
        
        
    oppath3=r'D:\Data\DE_Conwise_Stock_New\Duedate_cons_undel.xlsx'
    with ExcelWriter(r'D:\Data\DE_Conwise_Stock_New\Duedate_cons_undel.xlsx') as writer:
        duedateconsundel.to_excel(writer, sheet_name='DUE_UNDEL',engine='xlsxwriter')    

    print ('Logging in...')
    ftp = ftplib.FTP()
    ftp.connect('10.109.230.50')
    print (ftp.getwelcome())
    try:
        try:
            ftp.login('IEPROJECTUSER', 'spotStar@123')
            ftp.cwd('ETA')
            # move to the desired upload directory
            print ("Currently in:", ftp.pwd())
            print ('Uploading...')
            fullname = oppath3
            name = os.path.split(fullname)[1]
            f = open(fullname, "rb")
            ftp.storbinary('STOR ' + name, f)
            f.close()
            print ("OK"  )
            print ("Files:")
            print (ftp.retrlines('LIST'))
        finally:
            print ("Quitting...")
            ftp.quit()
    except:
        traceback.print_exc()


except:
  TO=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  #msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "ODA&STD Delivery Efficiency Error in Execution" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in ODA&STD Delivery Efficiency'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO, msg.as_string())
  server.quit()