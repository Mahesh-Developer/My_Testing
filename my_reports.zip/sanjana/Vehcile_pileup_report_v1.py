# -*- coding: utf-8 -*-
"""
Created on Fri Oct 07 18:00:43 2016

@author: rajeeshv
"""

import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
#import datetime
import os
import Utilities
#dsn = 'vishwas'
#user = 'sa'
#password = 'password@123'
#database = 'ESTL_CRP2'
#
#con_string = 'DSN=%s;UID=%s;PWD=%s;DATABASE=%s;' % (dsn, user, password, database)
#conn = pyodbc.connect(con_string)
#conn.autocommit = True
#cursor = conn.cursor()


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()
#cursor.execute("select TOP 10 DOCKNO from docket")
#rows = cursor.fetchall()
#for row in rows:
#    print row.DOCKNO

query = ("""
        ( SELECT    TC.thcno AS ThcNo ,
           CASE WHEN ISNULL(vs.SourceCode,'') = ''
		   THEN TC.sourcehb 
		   ELSE
           vs.SourceCode
		   END sourcehb, 

		    CASE WHEN ISNULL(vs.DestinationCode,'') = ''
		   THEN TC.tobh_code 
		   ELSE
           vs.DestinationCode
		   END tobh_code, 
          
            TC.routety ,
            CASE WHEN TC.routety = 'D' THEN GETDATE()
                 ELSE dbo.UFN_GET_THC_ARRCTIME_ASPER_GPS_CNM_NEW(TC.thcno,
                                                              NULL)
            END AS ArrivalTime_ASPER_GPS_CNM ,
            CAST(CONVERT(VARCHAR, hd2.actarrv_dt, 112) + ' ' + hd2.actarrv_tm AS SMALLDATETIME) Arrivaltime ,
            TR.TCHDRFLAG ,
            CASE WHEN hd2.tobh_code IS NULL THEN 'Y'
                 WHEN hd2.tobh_code = 'Null' THEN 'Y'
                 ELSE 'N'
            END AlreadyArrived ,
            SUM(d.ACTUWT) AS ld_actuwt
  FROM       THCHDR TC WITH ( NOLOCK )
  
            LEFT OUTER JOIN tbl_VehicleRunningStatus_New vs WITH ( NOLOCK ) ON vs.ThcNo = TC.thcno
                                                             
            LEFT OUTER JOIN THCHDR hd2 WITH ( NOLOCK ) ON TC.thcno = hd2.thcno
                                                          AND TC.tobh_code = hd2.sourcehb
            LEFT OUTER JOIN dbo.TCHDR TR WITH ( NOLOCK ) ON TR.THCNO = TC.thcno
                                                            AND TR.ToBH_CODE = TC.tobh_code
            LEFT OUTER  JOIN dbo.TCTRN d WITH ( NOLOCK ) ON d.TCNO = TR.TCNO
  WHERE     TC.actarrv_dt >= CONVERT(DATE, GETDATE() - 15)
          --  AND TC.tobh_code = 'BLRH'
            AND TC.tobh_code <> 'Null'
            AND ( hd2.thcno IS  NULL
                  OR TR.TCHDRFLAG = 'Y'
                )--INCLUDE THE CONS WHICH ARE NOT INSCANNED YET   
            AND hd2.sourcehb IS NOT NULL -- TO GET ONLY ARRIVED THC's
		--	AND tc.thcno = 'NTDELHX0073861'
  GROUP BY  TC.thcno ,
           
            TC.sourcehb ,
            TC.tobh_code ,
            TC.routety ,
            hd2.actarrv_dt ,
            hd2.actarrv_tm ,
            TR.TCHDRFLAG ,
            hd2.tobh_code,vs.SourceCode, vs.DestinationCode
 )
        """)
#rows = cursor.fetchall()
#df = pd.DataFrame(query.fetchall())



veh_pileup_df = pd.read_sql(query, Utilities.cnxn)

veh_pileup_df.to_csv(r'D:\Data\Vehicle_pileup_report\veh_pileup_df.csv')

veh_pileup_df = veh_pileup_df.drop_duplicates(subset='ThcNo')
veh_pileup_df = veh_pileup_df.drop(['TCHDRFLAG'],axis=1)

veh_pileup_df = veh_pileup_df[veh_pileup_df['routety']!='D']

corehublist = ['AMCH','AMDH','BLRH','BOMH','BRGH','CCUH','DELH','HYDH','MAAH','NAGH','PNQH','VPIH','VZAH','SXVF','IDRH','CJBH','GAUB','GAUH','COKB','JAIH','BGMH','PATF','PATH','BBIH','IXRB']

veh_pileup_df = veh_pileup_df[veh_pileup_df['tobh_code'].isin(corehublist)]

## Edit on 16-10-2016 for filtering out not reached THCs
veh_pileup_df = veh_pileup_df[veh_pileup_df['AlreadyArrived']=='Y']
## Edit on 16-10-2016 for filtering out not reached THCs

ts= datetime.now()
opfilevar=ts.date()
opfilevar1=ts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=pd.np.round(float(currhrs)/60)


veh_pileup_df.loc[veh_pileup_df.index,'CurrentTime'] = ts


def diffhr(currtime,arrivetime):
    diff = (currtime - arrivetime)
    return pd.np.round(diff.total_seconds()/3600,1)
    #return diffhrs
def get3hrscount(timediff):
    if timediff>3:
        return 1
    else:
        return 0

veh_pileup_df['Time_diff'] = veh_pileup_df.apply(lambda x:diffhr (x['CurrentTime'],x['Arrivaltime']),axis=1)
veh_pileup_df['>3Hrs'] = veh_pileup_df.apply(lambda x:get3hrscount (x['Time_diff']),axis=1)



veh_pileup_df_grp = veh_pileup_df.groupby(['tobh_code']).agg({'ThcNo':len,'ld_actuwt':sum,'Time_diff':sum,'>3Hrs':sum}).reset_index()
veh_pileup_df_grp['WtTimeDiff'] = veh_pileup_df_grp.apply(lambda x:pd.np.round((x['Time_diff']/x['ThcNo']),1),axis=1)
veh_pileup_df_grp = pd.DataFrame(veh_pileup_df_grp,columns=['tobh_code','ThcNo','ld_actuwt','WtTimeDiff','>3Hrs'])
veh_pileup_df_grp = veh_pileup_df_grp.rename(columns={'tobh_code':'LOC','ld_actuwt':'Wt(T)'})


def loadroundoff(wt):
    wt_in_ton = pd.np.round(wt/1000.0,1)
    return wt_in_ton

veh_pileup_df_grp['Wt(T)'] = veh_pileup_df_grp.apply(lambda x:loadroundoff(x['Wt(T)']),axis=1)
veh_pileup_df_grp = veh_pileup_df_grp.sort_values('Wt(T)',ascending=False)
veh_pileup_df_grp = veh_pileup_df_grp.to_string(index=False)


## For converting datetime in readable format. Edit on 27-10-2016
veh_pileup_df['ArrivalTime_ASPER_GPS_CNM'] = veh_pileup_df.apply(lambda x:datetime.strftime(x['ArrivalTime_ASPER_GPS_CNM'],"%Y-%m-%d %H:%M:%S"),axis=1)
veh_pileup_df['Arrivaltime'] = veh_pileup_df.apply(lambda x:datetime.strftime(x['Arrivaltime'],"%Y-%m-%d %H:%M:%S"),axis=1)
veh_pileup_df['CurrentTime'] = veh_pileup_df.apply(lambda x:datetime.strftime(x['CurrentTime'],"%Y-%m-%d %H:%M:%S"),axis=1)
## For converting datetime in readable format. Edit on 27-10-2016

veh_pileup_df.to_csv(r'D:\Data\Vehicle_pileup_report\THCwise_data\Vehicle_pileup_report_'+str(opfilevar)+str('-')+str(opfilevar2)+'.csv')

oppath_veh_pileup = r'D:\Data\Vehicle_pileup_report\THCwise_data\Vehicle_pileup_report_'+str(opfilevar)+str('-')+str(opfilevar2)+'.csv'

filePath = oppath_veh_pileup
def sendEmail(TO = ["hubmgr_spot@spoton.co.in","Cnm@Spoton.Co.In","Raghavendra.Rao@Spoton.Co.In","OPS.HUB.IDRH.1@SPOTON.CO.IN","Rajesh.Mishra@Spoton.Co.In","dom_spot@spoton.co.in","rom_spot@spoton.co.in"],
            #TO = ["rajeesh.vr@spoton.co.in"],
            #TO = ["vishwas.j@spoton.co.in"],
            #CC = ["vishwas.j@spoton.co.in"],
            CC = ["rajeesh.vr@spoton.co.in","sqtf@spoton.co.in","pawan.sharma@spoton.co.in","prasanna.hegde@spoton.co.in","rajesh.kapase@spoton.co.in"],
            BCC = ['yogesh.singh@spoton.co.in','prabhakar.mahajan@spoton.co.in','nitin.tatyarao@spoton.co.in','vinodkumar.mishra@spoton.co.in','jai.prakash@spoton.co.in','nomesh.ganvir@spoton.co.in','sanjay.panse@spoton.co.in','sunil.khare@spoton.co.in'],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    msg["Subject"] = "Vehicle Pileup Report " + '- ' + str(opfilevar)+str('-')+ str(opfilevar2)
    body_text = """
    Dear All,
    
    PFB the summary of THCs arrived at a location and yet to be unloaded.
    WtTimeDiff : This column gives the total weighted average time difference in hours
    >3Hrs : No of THCs pending for unloading pending from more than 3 hours

"""+str(veh_pileup_df_grp)+"""
    
    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
#print('Email sent')
#Sending output file via mail ends