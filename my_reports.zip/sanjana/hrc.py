
# coding: utf-8

# In[1]:


# import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select 
import pyodbc 
from pandas import ExcelWriter 
from datetime import datetime, timedelta
import unidecode
import string


# In[2]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()


# In[6]:


# OFFC
cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=PYTHON_DB;UID=PythonOnline;PWD=P@ssw0rd123$;")
cursor = cnxn.cursor()


# In[7]:


# HME
cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=PYTHON_DB;UID=PythonOnline;PWD=P@ssw0rd123$;")
cursor = cnxn.cursor()


# In[3]:


startdate2='2019-08-01'
enddate2=datetime.strftime(datetime.now(),"%Y-%m-%d %H:%M:%S")


# In[53]:


enddate2


# In[ ]:


# startdate=datetime.strftime((datetime.now()-timedelta(days=1)).replace(day=1),"%Y-%m-%d")
# enddate=datetime.strftime(datetime.now(),"%Y-%m-%d")


# In[4]:


query=("""
SELECT  C.PermCaseID ,
        b.CreatedOn ,
        C.Status ,
        a.DockNo ,
        D.CSGNCD ,
        D.CSGNNM ,
        a.Dest_Path ,
        b.SecurityType ,
        b.IncidentLoc,
        D. DECLVAL
FROM    dbo.tblHRCCustDocketDtls a WITH ( NOLOCK )
        INNER JOIN dbo.tblSecIncidentReporting b WITH ( NOLOCK ) ON a.DockNo = b.ConNo
        INNER JOIN dbo.tblSecApprovedIncidents C WITH ( NOLOCK ) ON C.IncidentID = b.Id
        INNER JOIN dbo.DOCKET D WITH ( NOLOCK ) ON D.DOCKNO = a.DockNo
WHERE   b.SecurityType IN ( 'B', 'D' )
        AND
        b.CreatedOn BETWEEN '{0}'
                     AND    '{1}'
 

""").format (startdate2, enddate2) 


# In[26]:


# a=("""
# SELECT  top 10 *
# FROM    dbo.tblHRCCustDocketDtls a WITH ( NOLOCK )
#         INNER JOIN dbo.tblSecIncidentReporting b WITH ( NOLOCK ) ON a.DockNo = b.ConNo
#         INNER JOIN dbo.tblSecApprovedIncidents C WITH ( NOLOCK ) ON C.IncidentID = b.Id
#         INNER JOIN dbo.DOCKET D WITH ( NOLOCK ) ON D.DOCKNO = a.DockNo
# WHERE   b.SecurityType IN ( 'B', 'D' )


# """)


# In[5]:


v1=pd.read_sql(query,cnxn)


# In[7]:


v2=v1['DockNo'].astype(int)


# In[8]:


v2=v1.drop_duplicates(subset='DockNo')


# In[9]:


v2=v2[~v2['Status'].isin(['C'])]


# In[10]:


v3B=v2[v2['SecurityType'].isin(['B'])]


# In[11]:


v3D=v2[v2['SecurityType'].isin(['D'])]


# In[36]:


v3B['Resolving hrs']=pd.to_datetime(enddate2)-v3B.apply(lambda x:x['CreatedOn'],axis=1)


# In[40]:


import numpy as np


# In[41]:


v3B['Resolving hrs']=v3B['Resolving hrs']/ np.timedelta64(1, 'h')


# In[43]:


def a(hrs):
    if hrs>=48:
        return 'Crossed timelimit'
    else:
        return 'Ok'


# In[45]:


v3B['Deadline']=v3B.apply(lambda x:a(x['Resolving hrs']),axis=1)


# In[50]:


v4B=v3B[v3B['Deadline']!='Ok']


# In[51]:


v4B


# In[76]:


def d(rh):
    if rh<=60:
        return '48-60 Hrs'
    if rh<=72:
        return '61-72 Hrs'
    else:
        return '> 72 Hrs'   


# In[77]:


v4B['time bracket']=v4B.apply(lambda x: d(x['Resolving hrs']),axis=1)


# In[78]:


v5B=v4B.pivot_table(index=['time bracket'],values=['DockNo'],aggfunc={'DockNo':len}).reset_index()


# In[79]:


v3D['Resolving hrs']=pd.to_datetime(enddate2)-v3D.apply(lambda x:x['CreatedOn'],axis=1)


# In[80]:


v3D['Resolving hrs']=v3D['Resolving hrs']/ np.timedelta64(1, 'h')


# In[81]:


def b(hrs):
    if hrs>=2:
        return 'Crossed timelimit'
    else:
        return 'Ok'


# In[82]:


v3D['Deadline']=v3D.apply(lambda x:b(x['Resolving hrs']),axis=1)


# In[83]:


v4D=v3D[v3D['Deadline']!='Ok']


# In[84]:


def c(rh):
    if rh<=5:
        return '3-5 Hrs'
    if rh<=10:
        return '6-10 Hrs'
    else:
        return '> 10 Hrs'   


# In[85]:


v4D['time bracket']=v4D.apply(lambda x: c(x['Resolving hrs']),axis=1)


# In[86]:


v5D=v4D.pivot_table(index=['time bracket'],values=['DockNo'],aggfunc={'DockNo':len}).reset_index()


# In[87]:


v4B


# In[88]:


v5B


# In[89]:


v4D


# In[90]:


v5D

