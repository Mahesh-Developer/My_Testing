
# coding: utf-8

# In[1]:

from suds.client import Client
import pandas as pd
import json
import requests as req
import datetime


# In[2]:

gpsdata = pd.read_csv(r'D:\\Python\\Scripts and Files\\Path and Graph Files\\GPS_details_Report_280116.csv')
ippath4 = r'D:\Python\Scripts and Files\Path and Graph Files\ApilistGC.xlsx'
xl4 = pd.ExcelFile(ippath4)
APIlist = xl4.parse('Sheet10')
keylist = APIlist['API list'].tolist()
divisionbase= len(keylist)


# In[3]:

url_service = 'http://118.67.240.88:5009/Service.asmx?WSDL'
client = Client(url_service)
url1 = 'https://maps.googleapis.com/maps/api/geocode/json?'


# In[4]:

ts = datetime.datetime.now()


# In[5]:

for i in range (0, len(gpsdata)):
    simno = gpsdata.iloc[i]['Vehicle Alias']
    routepath = gpsdata.iloc[i]['Route']
    vehno = gpsdata.iloc[i]['Vehicle Rto No']
    try:
        response = client.service.Get_Information(User_Id="stladmin1", vehicle_Id=str(simno))
        output = response.split('::')
        phone_id = output[0]
        ping_time = output[3]
        lati=output[5]
        longi=output[6]
        speed = output[7]
        
        gpsdata.loc[i,'Ping_Time'] = ping_time
        gpsdata.loc[i,'Latitude'] = lati
        gpsdata.loc[i,'Longitude'] = longi
        gpsdata.loc[i,'Speed'] = speed
        gpsdata.loc[i,'Remarks'] = 'OK'
        gpsdata.loc[i,'Timestamp'] = ts
        
        
    except:
        gpsdata.loc[i,'Remarks'] = 'Check'
        pass
    
    
    try:
        latlong = str(lati)+','+str(longi)
        rowmode= i%divisionbase
        url3='&key='+ str (keylist[rowmode])
        url = url1+str('latlng='+str(latlong))+url3
        r = req.get(url)
        text = r.text
        json_data=json.loads(text)
        addcheck= json_data['status']
        #print('addcheck is',addcheck)
        if addcheck == 'NOT_FOUND' or addcheck == 'ZERO_RESULTS' or addcheck == 'UNKNOWN_ERROR':
            print('Address not found')
            gpsdata.loc[i,'AddressError'] = 'Check Address'
        else:
            #a = json_data['results'][0]['geometry']['location']
            gpsdata.loc[i,'Address'] = json_data['results'][0]['formatted_address']
            
    except:
        pass


# In[8]:

datetimenow = datetime.datetime.now()

opfilevar=datetimenow.date()
opfilevar1=datetimenow.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=pd.np.round((float(currhrs)/60),1)

gpsdata.to_csv('D:\\Data\\CNM_All_Lanes_28012016\\GPSdetails_NEW_OP_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv', encoding='utf-8') 


# In[ ]:



