
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd

from IPython import display
from datetime import datetime
from datetime import datetime,timedelta
from datetime import datetime, timedelta
import smtplib
import ftplib
import traceback
import calendar
import os
import pyodbc
from pymongo import MongoClient
import Utilities

# In[2]:


#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")


# In[3]:


client = MongoClient('mongodb://localhost:27017/')
#path_schedule_master_may_30
db = client['path_schedule_master_May11_19']
loading = 1*90 
unloading = 1*90
virtualmovement = 3*60


# In[4]:


query=("EXEC USP_HUB_THROUGHPUT_DETAILS_SALES_ONEHOUR")
combs_df = pd.read_sql(query,Utilities.cnxn)
print ('inv',len(combs_df))



# In[5]:


totalcons=len(combs_df)
combs_df.rename(columns={'Hub SC Location': 'Location','Destn Branch': 'Destination','Origin Branch': 'Origin','Act Wt In Tonnes': 'Wt','Del Location Type': 'DestType','TIMESTAMP': 'Ts','Arrival Date Hub':'ArrTs','Due Date': 'DueDate','Next Frwd Loc': 'nextloc'},inplace=True)
intransitdf=pd.read_excel(r'http://spoton.co.in/downloads/TCR_UND_2HRS/TCR_UND_ISDEPART_YES_2HRS.xls')


# In[6]:

combs_df['Con Number']=combs_df['Con Number'].astype(int)
mergedf = pd.merge(combs_df,intransitdf,left_on=['Con Number'], right_on=['DOCKNO'], how='inner')
combs_df=combs_df[~combs_df['Con Number'].isin(mergedf['Con Number'])]
len(combs_df)


# In[7]:


combs_df=combs_df[combs_df['DestnDepot']!='UCGD']
combs_df = combs_df[combs_df['Hub/SC Location']!=combs_df['DestnBranch']]
len(combs_df)


# In[8]:


# depspaperworkcodelist = ['SRE','SRD','SRS','SRP','DLP','SWP','PWS','HCM','HPM','MOP','SRH','HOC','ONR','SPH','SPO','DBO','DIP','SHS','SSC','HIP','RNX','APT','APN','SHD','SMT','SPL','MSH','UCG','RRA','HPE','WIA','UG1','UG2','UG3','HMP','HWC','NPE','HIM']
# combs_df = combs_df[~combs_df['LatestStatusCode'].isin(depspaperworkcodelist)]
# len(combs_df)


# In[9]:


def oldcon(arrv,ts):
    dt=str(ts).split(' ')[0]
    dtt=pd.to_datetime(dt)
    if arrv< dtt-timedelta(days=30):
        return 'Old'
    else:
        return 'New'


# In[10]:


combs_df['Obsev_1']=combs_df.apply(lambda x: oldcon(x['BookingDate'],x['Ts']),axis=1)


# In[11]:


htr=combs_df[combs_df['Obsev_1']=='New']
htr['ArrTs']=pd.to_datetime(htr['Arrival Date @ Hub'])
htr['DueDate']=pd.to_datetime(htr['DueDate'])
htr['Ts']=pd.to_datetime(htr['Ts'])


# In[12]:


virtualmovement = 3*60
htr['Td'] = (htr.Ts-htr.ArrTs)/np.timedelta64(1,'h')
### this is an adjustment to the current time in case the con has arrived less than 3 hours prior to the current time
htr['AdjTS'] = [arr + np.timedelta64(loading,'m') if td*60<=loading else ts for td,arr,ts in zip(htr.Td,htr.ArrTs,htr.Ts)] #con reflects in inventory only once unloading complete, but htr has this veh accepted load as well #corrected1
htr['DueDate2'] = htr.DueDate+np.timedelta64(12*60,'m')
# htr['AdjDueDate'] = [dd if dest=='STD' else dd-np.timedelta64(odadays,'m') for dd,dest in zip(htr.DueDate2,htr.DestType)]  #why, we should infact be using up the 1 day of 3 to delay such cons? - can only allow max 2 days transit / consolidations
# ODA Transit Day


# In[13]:


htr['AdjDueDate'] = [dd if dest=='STD' else dd-np.timedelta64(odadays*24*60,'m') for dd,dest,odadays in zip(htr.DueDate2,htr['Del. Location Type'],htr['ODAExtraTransitDay'])]
currdt = np.datetime64(str(htr.Ts.unique()[0]).split('T')[0]+' 00:00:00','ms')


# In[14]:


htr=htr[~htr['AccountType'].isnull()]
len(htr)


# In[15]:


errordict = {}
def geteta(origin,destination,currts):
    #print (origin,destination,currts)
    #print (type(currts))
    #print (currts)
    global virtualmovement, loading, unloading, errordict
    currdt = np.datetime64(str(currts).split('T')[0]+' 00:00:00','ms')
    schdict = db.master.find_one({'origin': origin,'destination': destination})
    retdict = {}
    if schdict:
        schedules = schdict['legdata']
        #print ('schedules',schedules,len(schedules))
        path = schdict['conpath']
        #print ('path',path)
        journeydict = {}
        for legno in range(1,len(schedules)+1):
            step=schedules.get(str(legno))
            journeydict[(step[0],step[1])] = []
            options = step[2]
            if options:
                try:
                    transithours = [np.timedelta64(int((option[0]).split(':')[1])+60*int((option[0]).split(':')[0]),'m') for option in options] #this is actually mins from day beginning
                    convertedoptions = currdt+transithours
                    #convertedoptionsbool = [option for option in convertedoptions if option>=currts+np.timedelta64(loading,'m')]
                    convertedoptions = [option if option>=currts+np.timedelta64(loading,'m') else option+np.timedelta64(24*60,'m') for option in convertedoptions  ]
                    convertedoptionsbool = [option if option>=currts+np.timedelta64(loading,'m') else option+np.timedelta64(24*60,'m') for option in convertedoptions  ]

                    
                    if not convertedoptionsbool:
                        convertedoptions = np.timedelta64(24*60,'m') + convertedoptions
                    convertedoptionsbool = [option for option in convertedoptions if option>=currts+np.timedelta64(loading,'m')]
                    if not convertedoptionsbool:
                        convertedoptions = np.timedelta64(24*60,'m') + convertedoptions #two steps needed since for 12:30am etc it is still beyond loading time
                    timeoptions = [(conv,conv+np.timedelta64(int(opt[1])*60,'m')+np.timedelta64(unloading,'m')) for opt,conv in zip(options,convertedoptions) if conv>=currts+np.timedelta64(loading,'m')] #+np.timedelta64(loading,'m') - cnt add loading
                    try:
                        optimaloption = sorted(timeoptions, key=lambda x: x[1])[0]
                    except:
                        print (convertedoptionsbool,convertedoptions,timeoptions)
                    journeydict[(step[0],step[1])] = optimaloption
                    arrtime = optimaloption[1]
                except:
                    retdict['path'] = path
                    retdict['journey'] = {'error': options}
                    errordict[(step[0],step[1])] = 'error in time of schedule'
                    return retdict
                    
            else:
                deptime = currts
                arrtime = currts+np.timedelta64(virtualmovement,'m')
                journeydict[(step[0],step[1])] = (deptime,arrtime)
            currts = arrtime
            currdt = np.datetime64(str(currts).split('T')[0]+' 00:00:00','ms')
        retdict['path'] = path
        retdict['journey'] = journeydict
        journeytimes = journeydict.values()
        try:
            eta = sorted(journeytimes, key=lambda x: x[1], reverse=True)[0][1]
            retdict['eta'] = eta
        except:
            print ('retdict',retdict)
        #print ('retdict',retdict)
        return retdict
    else:
        print (schdict, origin, destination)
        errordict[(origin,destination)] = 'no path'
        return False


# In[16]:


htr['journeydict'] = [geteta(loc,dest,ts) for loc,dest,ts in zip(htr['Hub/SC Location'].values,htr['DestnBranch'].values,htr['Ts'].values)]


# In[ ]:


#htr['journeydict_1'] = [geteta(loc,dest,ts) for loc,dest,ts in zip(htr['Origin'].values,htr['DestnBranch'].values,htr['Ts'].values)]


# In[17]:


path_false=htr[htr['journeydict']==False]
print (len(path_false))


# In[18]:


htr['path'] = [i.get('path') if i else i for i in htr.journeydict.values]
htr['eta'] = [i.get('eta') if i else i for i in htr.journeydict.values]
inventory=htr[htr['eta']!=False]


# In[19]:


inventory['eta']=pd.to_datetime(inventory['eta'])
inventory['neweta']=inventory['eta'].apply(lambda x: x+timedelta(days=1) if x.hour>12 else x)
inventory['neweta']=inventory['neweta'].apply(lambda x: str(x).split(' ')[0])
inventory['neweta']=pd.to_datetime(inventory['neweta'])


# In[20]:


inventory['ETA_Slip']=[1 if eta>duedate else 0 for eta,duedate in zip(inventory['neweta'],inventory['AdjDueDate'])]
inventory['Days_Diff']=inventory['neweta']-inventory['AdjDueDate']
inventory['Days']=inventory['Days_Diff'].apply(lambda x:int(str(x).split(' ')[0]))


# In[ ]:


## Main Summary


# In[21]:


inventory['Revised_ETA']=inventory.apply(lambda x: x['neweta']+timedelta(days=int(x['ODAExtraTransitDay'])),axis=1)


# In[22]:


slip_df=inventory[inventory['ETA_Slip']==1]
len(slip_df)


# In[23]:


slip_df1=slip_df[slip_df['Days']==1]
len(slip_df1)


# In[24]:


slip_df1['journeydict_1'] = [geteta(loc,dest,ts) for loc,dest,ts in zip(slip_df1['Origin'].values,slip_df1['DestnBranch'].values,slip_df1['Ts'].values)]


# In[25]:


slip_df1['path_1'] = [i.get('path') if i else i for i in slip_df1.journeydict_1.values]


# In[26]:


def getRemarks(path,location):
    try:
        if len(path)==1:
            return None
        else:
            origin=path[0]
            nextloc=path[1]
            destination=path[-2]
            if len(path)==1:
                return None
            elif origin==location:
                return "Origin"
            elif location==nextloc:
                return "Origin Hub"
            elif location==destination:
                return "Destination Hub"
            else:
                return "Tranship Location"
    except:
        return None


# In[27]:


slip_df1['Remarks']=slip_df1.apply(lambda x:getRemarks(x['path_1'],x['Hub/SC Location']),axis=1)


# In[28]:


slip_df1['Remarks'].unique()


# In[29]:


inventory_summary=slip_df1[['Hub/SC Location','Origin','DestnBranch','Remarks','ETA_Slip','Days','AccountCode', 'AccountName', 'AccountType','Con Number','Del. Location Type', 'LatestStatusCode',
       'LatestStatus', 'LatestStatusDate', 'LatestStatusReason','DueDate','Revised_ETA','ODAExtraTransitDay']]


# In[30]:


inventory_summary['Type']='Inventory'


# In[60]:


# inventory[inventory['Con Number']=='519412936']


# In[ ]:


##Intransit summary


# In[31]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()
stockquery = ("""SELECT  A.* ,

        B.CustCode ,

        B.CustName ,

        C.AccountType ,

        TL.ODAExtraTransitDay AS ODA_DAYS

FROM    dbo.tblTimeConnectionReport_Undelivered_2Hrs A WITH ( NOLOCK )

        CROSS APPLY dbo.UFN_GET_CUSTCODE_FOR_CON(A.DOCKNO) B

        LEFT OUTER JOIN dbo.PCUST_MAIN PM WITH ( NOLOCK ) ON PM.ptmsptcd = B.CustCode

        LEFT OUTER JOIN dbo.tblSicMst indus WITH ( NOLOCK ) ON indus.sicid = PM.SICID

        LEFT OUTER JOIN dbo.tblAccountTypeMst C WITH ( NOLOCK ) ON C.AccountTypeID = PM.AccountTypeID

        INNER JOIN dbo.DOCKET DK WITH ( NOLOCK ) ON A.DOCKNO = DK.DOCKNO

        INNER JOIN dbo.tblLocationMst TL WITH ( NOLOCK ) ON DK.DestnLocID = TL.LocationID

WHERE   ISDEPARTED_FRM_CURRLOC = 'YES' """)
tcr = pd.read_sql_query(stockquery, cnxn)
print (len(tcr))


# In[ ]:


# tcr['Check_MA']=tcr['AccountType'].apply(lambda x: True if "MA" in x else False)
# tcr=tcr[tcr['Check_MA']==True]
# len(tcr)


# In[32]:


tcr.rename(columns={'CURR_BRANCHCODE':'CURR BRANCHCODE','DEPARTURE_TIME_FRM_CURLOC':'DEPARTURE TIME FRM CURLOC','ACTUAL_WEIGHT':'Wt'},inplace=True)

#tcr = tcr.set_index('DOCKNO')
tcr=tcr.rename(columns={'ISDEPARTED_FRM_CURRLOC': 'Departed'})
totalcons=len(tcr)
depspaperworkcodelist = ['SRE','SRD','SRS','SRP','DLP','SWP','PWS','HCM','HPM','MOP','SRH','HOC','ONR','SPH','SPO','DBO','DIP','SHS','SSC','HIP','RNX','APT','APN','SHD','SMT','SPL','MSH','UCG','RRA','HPE','WIA','UG1','UG2','UG3','HMP','HWC','NPE','HIM']
tcr = tcr[~tcr['CurLocConStatusCode'].isin(depspaperworkcodelist)]
len(tcr)

odadays = 2*24*60
# tcr['CDELDT']=pd.to_datetime(tcr['CDELDT'])
tcr['CDELDT'] = [dd if dest=='STD' else dd-np.timedelta64(int(odady)*24*60,'m') for dd,dest,odady in zip(tcr.CDELDT,tcr.DESTLOCTYPE,tcr['ODA_DAYS'])]
tcr=tcr[tcr['CURR BRANCHCODE']!=tcr['DESTCD']]
len(tcr)
def oldcon(arrv,ts):
    dt=str(ts).split(' ')[0]
    dtt=pd.to_datetime(dt)
    if arrv< dtt-timedelta(days=30):
        return 'Old'
    else:
        return 'New'
tcr['Obsev_1']=tcr.apply(lambda x: oldcon(x['CDELDT'],x['TIME_STAMP']),axis=1)
tcr=tcr[tcr['Obsev_1']=='New']
len(tcr)


# In[33]:


errordict1 = {}
def geteta(origin,destination,currts):
    global virtualmovement, loading, unloading, errordict
    currdt = np.datetime64(str(currts).split('T')[0]+' 00:00:00','ms')
    schdict = db.master.find_one({'origin': origin,'destination': destination})
    retdict = {}
    if schdict:
        schedules = schdict['legdata']
        path = schdict['conpath']
        journeydict = {}
        for legno in range(1,len(schedules)+1):
            step=schedules.get(str(legno))
            journeydict[(step[0],step[1])] = []
            options = step[2]
            if options:
                try:
                    transithours = [np.timedelta64(int((option[0]).split(':')[1])+60*int((option[0]).split(':')[0]),'m') for option in options] #this is actually mins from day beginning
                    hours = min([int(option[1]) for option in options]) #this is actually mins from day beginning
                    if legno==1:
                        arrtime=currts+(np.timedelta64(hours*60,'m'))+np.timedelta64(unloading,'m')
                        journeydict[(step[0],step[1])] = (currts,arrtime)
                    else:
                        convertedoptions = currdt+transithours
                        convertedoptionsbool = [option for option in convertedoptions if option>=currts+np.timedelta64(loading,'m')]
                        if not convertedoptionsbool:
                            convertedoptions = np.timedelta64(24*60,'m') + convertedoptions
                        convertedoptionsbool = [option for option in convertedoptions if option>=currts+np.timedelta64(loading,'m')]
                        if not convertedoptionsbool:
                            convertedoptions = np.timedelta64(24*60,'m') + convertedoptions #two steps needed since for 12:30am etc it is still beyond loading time
                        timeoptions = [(conv,conv+np.timedelta64(int(opt[1])*60,'m')+np.timedelta64(unloading,'m')) for opt,conv in zip(options,convertedoptions) if conv>=currts+np.timedelta64(loading,'m')] #+np.timedelta64(loading,'m') - cnt add loading
                        try:
                            optimaloption = sorted(timeoptions, key=lambda x: x[1])[0]
                        except:
                            print (convertedoptionsbool,convertedoptions,timeoptions)
                        journeydict[(step[0],step[1])] = optimaloption
                        arrtime = optimaloption[1]
                except:
                    retdict['path'] = path
                    retdict['journey'] = {'error': options}
                    errordict1[(step[0],step[1])] = 'error in time of schedule'
                    return retdict
                    
            else:
                deptime = currts
                arrtime = currts+np.timedelta64(virtualmovement,'m')
                journeydict[(step[0],step[1])] = (deptime,arrtime)
            currts = arrtime
            currdt = np.datetime64(str(currts).split('T')[0]+' 00:00:00','ms')
        retdict['path'] = path
        retdict['journey'] = journeydict
        journeytimes = journeydict.values()
        try:
            eta = sorted(journeytimes, key=lambda x: x[1], reverse=True)[0][1]
            retdict['eta'] = eta
        except:
            # print (retdict)
            pass
        
        return retdict
    else:
        print (schdict, origin, destination)
        errordict1[(origin,destination)] = 'no path'
        return False


# In[34]:


tcr['journeydict'] = [geteta(loc,dest,ts) for loc,dest,ts in zip(tcr['CURR BRANCHCODE'].values,tcr['DEPARTURE_TO_LOC_FRM_CURLOC'].values,tcr['DEPARTURE TIME FRM CURLOC'].values)]
tcr['path'] = [i.get('path') if i else i for i in tcr.journeydict.values]
tcr['eta'] = [i.get('eta') if i else i for i in tcr.journeydict.values]
tcr=tcr[tcr['eta']!=False]
tcr=tcr[~tcr['eta'].isnull()]
len(tcr)
tcr['eta']=pd.to_datetime(tcr['eta'])


# In[37]:



errordict = {}
def geteta2(origin,destination,currts):
    print (origin,destination,currts)
    #print (type(currts))
    #print (currts)
    global virtualmovement, loading, unloading, errordict
    currdt = np.datetime64(str(currts).split('T')[0]+' 00:00:00','ms')
    schdict = db.master.find_one({'origin': origin,'destination': destination})
    retdict = {}
    if schdict:
        schedules = schdict['legdata']
        #print ('schedules',schedules,len(schedules))
        path = schdict['conpath']
        #print ('path',path)
        journeydict = {}
        for legno in range(1,len(schedules)+1):
            step=schedules.get(str(legno))
            journeydict[(step[0],step[1])] = []
            options = step[2]
            if options:
                try:
                    transithours = [np.timedelta64(int((option[0]).split(':')[1])+60*int((option[0]).split(':')[0]),'m') for option in options] #this is actually mins from day beginning
                    convertedoptions = currdt+transithours
                    # convertedoptionsbool = [option for option in convertedoptions if option>=currts+np.timedelta64(loading,'m')]
                    convertedoptions = [option if option>=currts+np.timedelta64(loading,'m') else option+np.timedelta64(24*60,'m') for option in convertedoptions  ]
                    convertedoptionsbool = [option if option>=currts+np.timedelta64(loading,'m') else option+np.timedelta64(24*60,'m') for option in convertedoptions  ]

                    if not convertedoptionsbool:
                        convertedoptions = np.timedelta64(24*60,'m') + convertedoptions
                    convertedoptionsbool = [option for option in convertedoptions if option>=currts+np.timedelta64(loading,'m')]
                    if not convertedoptionsbool:
                        convertedoptions = np.timedelta64(24*60,'m') + convertedoptions #two steps needed since for 12:30am etc it is still beyond loading time
                    timeoptions = [(conv,conv+np.timedelta64(int(opt[1])*60,'m')+np.timedelta64(unloading,'m')) for opt,conv in zip(options,convertedoptions) if conv>=currts+np.timedelta64(loading,'m')] #+np.timedelta64(loading,'m') - cnt add loading
                    try:
                        optimaloption = sorted(timeoptions, key=lambda x: x[1])[0]
                    except:
                        print (convertedoptionsbool,convertedoptions,timeoptions)
                    journeydict[(step[0],step[1])] = optimaloption
                    arrtime = optimaloption[1]
                except:
                    retdict['path'] = path
                    retdict['journey'] = {'error': options}
                    errordict[(step[0],step[1])] = 'error in time of schedule'
                    return retdict
                    
            else:
                deptime = currts
                arrtime = currts+np.timedelta64(virtualmovement,'m')
                journeydict[(step[0],step[1])] = (deptime,arrtime)
            currts = arrtime
            currdt = np.datetime64(str(currts).split('T')[0]+' 00:00:00','ms')
        retdict['path'] = path
        retdict['journey'] = journeydict
        journeytimes = journeydict.values()
        try:
            eta = sorted(journeytimes, key=lambda x: x[1], reverse=True)[0][1]
            retdict['eta'] = eta
        except:
            print ('retdict',retdict)
        #print ('retdict',retdict)
        return retdict
    else:
        print (schdict, origin, destination)
        errordict[(origin,destination)] = 'no path'
        return False


# In[38]:


tcr['journeydict_1'] = [geteta2(loc,dest,ts) for loc,dest,ts in zip(tcr['DEPARTURE_TO_LOC_FRM_CURLOC'].values,tcr['DESTCD'].values,tcr['eta'].values)]


# In[40]:


tcr['path_1'] = [i.get('path') if i else i for i in tcr.journeydict_1.values]
tcr['eta_1'] = [i.get('eta') if i else i for i in tcr.journeydict_1.values]


# In[44]:


tcr=tcr[~tcr['eta_1'].isnull()]
len(tcr)


# In[45]:


def getEta(toloc,dest,eta,eta1):
    if toloc==dest:
        return eta
    else:
        return eta1

tcr['Final_ETA']=tcr.apply(lambda x:getEta(x['DEPARTURE_TO_LOC_FRM_CURLOC'],x['DESTCD'],x['eta'],x['eta_1']),axis=1)
tcr['eta_1']=pd.to_datetime(tcr['eta_1'])
tcr['Final_ETA']=pd.to_datetime(tcr['Final_ETA'])
tcr['neweta']=tcr['Final_ETA'].apply(lambda x: x+timedelta(days=1) if x.hour>12 else x)

tcr['neweta']=tcr['neweta'].apply(lambda x: str(x).split(' ')[0])
tcr['neweta']=pd.to_datetime(tcr['neweta'])

tcr['ETA_Slip']=[1 if eta>duedate else 0 for eta,duedate in zip(tcr['neweta'],tcr['CDELDT'])]
tcr['Days_Diff']=tcr['neweta']-tcr['CDELDT']
tcr['Days']=tcr['Days_Diff'].apply(lambda x: int(str(x).split(' ')[0]))


# In[46]:


tcr['Revised_ETA']=tcr.apply(lambda x: x['neweta']+timedelta(days=int(x['ODA_DAYS'])),axis=1)


# In[47]:


tcr1=tcr[tcr['ETA_Slip']==1]


# In[48]:


tcr1=tcr1[tcr1['Days']==1]
len(tcr1)


# In[49]:


def getEtapath(origin,destination):
    schdict = db.master.find_one({'origin': origin,'destination': destination})
    path = schdict['conpath']
    return path


# In[50]:


# tcr1['origin_path'] = tcr1.apply(lambda x:getEtapath(x['ORIGIN_BRCODE'],x['DESTCD']),axis=1)
tcr1['journeydict_2'] = [geteta2(loc,dest,ts) for loc,dest,ts in zip(tcr1['ORIGIN_BRCODE'].values,tcr1['DESTCD'].values,tcr1['eta'].values)]


# In[51]:


tcr1['path_2'] = [i.get('path') if i else i for i in tcr1.journeydict_2.values]


# In[52]:


tcr1['Remarks']=tcr1.apply(lambda x:getRemarks(x['path_2'],x['CURR BRANCHCODE']),axis=1)


# In[53]:


intransit_summary=tcr1[['CURR BRANCHCODE','ORIGIN_BRCODE','DESTCD','ETA_Slip','Days','CustName','AccountType','Remarks','CustCode','DOCKNO','CDELDT','DESTLOCTYPE','Revised_ETA','ODA_DAYS']]


# In[54]:


intransit_summary['Type']='Intransit'


# In[55]:


intransit_summary.rename(columns={'CURR BRANCHCODE':'Location','ORIGIN_BRCODE':'Origin','DESTCD':'Destn','DOCKNO':'Con Number','CDELDT':'DueDate'},inplace=True)


# In[56]:


inventory_summary.rename(columns={'Hub/SC Location':'Location','DestnBranch':'Destn','AccountCode':'CustCode','AccountName':'CustName','Del. Location Type':'DESTLOCTYPE','ODAExtraTransitDay':'ODA_DAYS'},inplace=True)


# In[57]:


merge=pd.concat([inventory_summary,intransit_summary],ignore_index=True)


# In[58]:


todate=datetime.strftime(datetime.now(),'%Y-%m-%d')
merge.to_csv(r'D:\Data\ETA_Slip_Report\1day_slip\All_Customers_1day_SlipData'+str(todate)+'.csv')
merge.to_csv(r'D:\Data\ETA_Slip_Report\1day_slip\All_Customers_1day_SlipData.csv')


# In[61]:


merge['Check_MA']=merge['AccountType'].apply(lambda x: True if "MA" in x else False)
merge=merge[merge['Check_MA']==True]
len(tcr)


# In[62]:


summary1=merge.pivot_table(index=['CustCode','CustName','AccountType'],aggfunc={'Con Number':len}).reset_index()


# In[63]:


summary1.rename(columns={'DOCKNO':'Cons > 2 ETA Slip'},inplace=True)


# In[ ]:


##To get Total Count of Cons


# In[64]:


intrn_df=tcr[['CustName','AccountType','CustCode','DOCKNO']]
inv_df=inventory[['AccountCode', 'AccountName', 'AccountType', 'Con Number']]


# In[65]:


inv_df.rename(columns={'AccountCode':'CustCode','AccountName':'CustName','Con Number':'DOCKNO'},inplace=True)


# In[66]:


merg2=pd.concat([intrn_df,inv_df],ignore_index=True)


# In[67]:


len(merg2['DOCKNO'])


# In[68]:


merg2['Check_MA']=merg2['AccountType'].apply(lambda x: True if "MA" in x else False)
merg2=merg2[merg2['Check_MA']==True]
len(merg2)


# In[69]:


summary2=merg2.pivot_table(index=['CustCode','CustName','AccountType'],aggfunc={'DOCKNO':len}).reset_index()


# In[70]:


summary2.rename(columns={'DOCKNO':'Total Cons in network'},inplace=True)


# In[71]:


final_summary=pd.merge(summary1,summary2,on=['AccountType', 'CustCode', 'CustName'],how='outer').fillna(0)


# In[ ]:


##Remarks Summary


# In[72]:


summary3=merge.pivot_table(index=['CustCode','CustName','AccountType'],columns=['Remarks'],aggfunc={'Con Number':len}).fillna(0)


# In[73]:


final_summary1=final_summary.set_index(['CustCode','CustName','AccountType'])


# In[74]:


final_summary2=pd.merge(summary3,final_summary1,left_index=True,right_index=True,how='outer').fillna(0)


# In[75]:


final_summary2


# In[76]:


intransit_data=tcr1[['CURR BRANCHCODE','ORIGIN_BRCODE','DESTCD','ETA_Slip','Days','CustName','AccountType','Remarks','CustCode','DOCKNO','Revised_ETA','CDELDT','ODA_DAYS','DESTLOCTYPE']]


# In[77]:


intransit_data['Type']='Intransit'


# In[78]:


inventory_data=slip_df1[['Hub/SC Location','Con Number','Origin','DestnBranch','AccountCode', 'AccountName', 'AccountType','DueDate','Revised_ETA','ETA_Slip', 'Days', 'Remarks','LatestStatusCode',
       'LatestStatus', 'LatestStatusDate', 'LatestStatusReason','ODAExtraTransitDay','Del. Location Type']]


# In[79]:


inventory_data['Type']='Inventory'


# In[80]:


intransit_data.rename(columns={'CURR BRANCHCODE':'Hub/SC Location','DOCKNO':'Con Number','ORIGIN_BRCODE':'Origin','DESTCD':'DestnBranch','CustCode':'AccountCode','CustName':'AccountName','CDELDT':'DueDate','DESTLOCTYPE':'Del. Location Type','ODA_DAYS':'ODAExtraTransitDay'},inplace=True)


# In[81]:


data=pd.concat([inventory_data,intransit_data],ignore_index=True)


# In[83]:


data.to_csv(r'D:\Data\ETA_Slip_Report\1day_slip\All_Customers_Conwise_1day_SlipData'+str(todate)+'.csv')
data.to_csv(r'D:\Data\ETA_Slip_Report\1day_slip\All_Customers_Conwise_1day_SlipData.csv')


# In[84]:


data['Check_MA']=data['AccountType'].apply(lambda x: True if "MA" in x else False)
data=data[data['Check_MA']==True]
len(data)


# In[85]:


final_summary2.rename(columns={('Con Number', 'Destination Hub'):'Destination Hub',('Con Number', 'Origin'):'Origin',('Con Number', 'Origin Hub'):'Origin Hub',('Con Number', 'Tranship Location'):'Tranship Location','Con Number':'Cons > 2 ETA Slip'},inplace=True)


# In[86]:


final_summary2.head()


# In[87]:


final_summary2=final_summary2[['Total Cons in network','Cons > 2 ETA Slip','Origin','Origin Hub','Tranship Location','Destination Hub']]


# In[88]:


final_summary2=final_summary2.sort_values('Cons > 2 ETA Slip',ascending=False)


# In[89]:


data['WeekDay']=data['Revised_ETA'].dt.weekday


# In[90]:


data['Revised_ETA']=data.apply(lambda x: x['Revised_ETA']+timedelta(days=1) if x['WeekDay']==6 else x['Revised_ETA'],axis=1)


# In[91]:


del data['WeekDay']


# In[92]:


final_summary2.to_csv(r'D:\Data\ETA_Slip_Report\1day_slip\MA_Customer_ETA_1daySlip'+str(todate)+'.csv')
final_summary2.to_csv(r'D:\Data\ETA_Slip_Report\1day_slip\MA_Customer_ETA_1daySlip.csv')
filepath=r'D:\Data\ETA_Slip_Report\1day_slip\MA_Customer_ETA_1daySlip.csv'

data.to_csv(r'D:\Data\ETA_Slip_Report\1day_slip\MA_Customer_ETA_1daySlip_Data'+str(todate)+'.csv')
data.to_csv(r'D:\Data\ETA_Slip_Report\1day_slip\MA_Customer_ETA_1daySlip_Data.csv')
filepath1=r'D:\Data\ETA_Slip_Report\1day_slip\MA_Customer_ETA_1daySlip_Data.csv'


# writer = pd.ExcelWriter(r'MA_Customer_ETA_1daySlip'+str(todate)+'.xlsx', engine='xlsxwriter')
# final_summary2.to_excel(writer,sheet_name='Summary')
# data.to_excel(writer,sheet_name='ETA_Slip_Data')
# writer.save()
# writer = pd.ExcelWriter(r'MA_Customer_ETA_1daySlip.xlsx', engine='xlsxwriter')
# final_summary2.to_excel(writer,sheet_name='Summary')
# data.to_excel(writer,sheet_name='ETA_Slip_Data')
#writer.save()


# In[ ]:


# writer = pd.ExcelWriter(r'Customer_ETA_Slip_v1.xlsx', engine='xlsxwriter')
# final_summary2.to_excel(writer,sheet_name='Summary')
# data1.to_excel(writer,sheet_name='ETA_Slip_Data')
# writer.save()


# In[ ]:


todate=datetime.strftime(datetime.now(),"%Y-%m-%d")


# In[93]:


filepath=r'D:\Data\ETA_Slip_Report\1day_slip\MA_Customer_ETA_1daySlip.csv'

filepath1=r'D:\Data\ETA_Slip_Report\1day_slip\MA_Customer_ETA_1daySlip_Data.csv'

# In[94]:


from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template
import pyodbc


# In[95]:


# TO=['mahesh.reddy@spoton.co.in']
TO=['sharmistha.majumdar@spoton.co.in']
CC=["abhik.mitra@spoton.co.in","mahesh.reddy@spoton.co.in",'jothi.menon@spoton.co.in','shivananda.p@spoton.co.in',"vishal.gp@spoton.co.in"]
#CC=['mahesh.reddy@spoton.co.in']
FROM="reports.ie@spoton.co.in"
# FROM="mahesh.reddy@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)

msg["Subject"] = "ETA slip customerwise Report - 1Day" + " - " + str(todate)

report=""
report+="Dear All"
report+='<br>'
report+='Please ETA slip customerwise Report - 1Day'
report+='<br>'
report+='Customer Wise Summary'
report+='<br>'
report+='<br>'+final_summary2.head(20).to_html()+'<br>'
report+='<br>'

abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(filepath1,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
msg.attach(part1)


# server=smtplib.SMTP('smtp.sendgrid.net', 587)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("mahesh.reddy@spoton.co.in", "Nov@2018")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()

