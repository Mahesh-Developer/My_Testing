
# coding: utf-8

# In[1]:



import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta
import sys
import datetime
import sys
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
# import Utilities


# In[2]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()


# In[3]:


querydate=date.today()
querydate


# In[4]:


query1=("""EXEC USP_UCG_GET_LETTERS_REPORT 'ALL','ALL','ALL','2018-01-01','{0}','3','ALL'  """.format(querydate))


# In[5]:


df=pd.read_sql(query1,cnxn)
# df


# In[6]:


len(df)


# In[7]:


df1=df[df['FinalStatusDate']=='']


# In[8]:


df1['Remarks']=''


# In[9]:


df1=df1[df1['FinalStatusDesc'].isin(['','DELIVERED'])]
len(df1)


# In[10]:


df2=df1[(df1['ConsignorCourierName'].isin(['Registered Post', 'Speedpost'])) & (df1['ConsigneeCourierName'].isin(['Registered Post', 'Speedpost']))]
len(df2)


# In[22]:


df2['Remarks']='Sender & Receiver Register Post Updated'
df1.loc[df2.index,'Remarks']=df2['Remarks']
print (df1['Remarks'].unique())


# In[23]:


df3=df1[df1['Remarks']=='']
scan_df=df3[(df3['InvoiceScanFile_1']=='Y')]


# In[24]:


scan_df['Remarks']='Invoice Uploaded'
df1.loc[scan_df.index,'Remarks']=scan_df['Remarks']


# In[25]:


peding_df=df1[df1['Remarks']=='']


# In[26]:


peding_df['Remarks']='Pending'
df1.loc[peding_df.index,'Remarks']=peding_df['Remarks']


# In[27]:


ddf=df1[df1['Remarks'].isin(['Pending','Invoice Uploaded'])]
dfPiv=df1[df1['Remarks']!='Sender & Receiver Register Post Updated']
summary1=dfPiv.pivot_table(index=['Depot'],columns=['Remarks'],values=['ConNumber'],aggfunc={'ConNumber':len})


# In[28]:


summary1


# In[29]:


print (df1['Remarks'].unique())
ageing_dffff=df1[df1['Remarks'].isin(['Sender & Receiver Register Post Updated'])]
print (len(ageing_dffff))


# In[30]:


len(ageing_dffff[ageing_dffff['ConsigneeCourierEntryDate']!='-'])


# In[31]:



ageing_dffff['Current Date']=datetime.datetime.now().date()


# In[32]:


ageing_dffff=ageing_dffff[ageing_dffff['ConsigneeCourierEntryDate']!='-']
print (len(ageing_dffff))


# In[33]:


len(ageing_dffff)


# In[34]:


month_dict = {'Jan': '01','Feb': '02','Mar': '03','Apr':'04','May':'05','Jun':'06','Jul':'07','Aug':'08','Sep':'09','Oct':'10','Nov':'11','Dec':'12'}


# In[35]:


def getDate(x):
    if x=='-':
        return 0
    else:
        x1=x.split(' ')[2]+'-'+month_dict.get(x.split(' ')[1])+'-'+x.split(' ')[0]
        return x1


# In[36]:


ageing_dffff['ConsigneeEntryDate']=ageing_dffff.apply(lambda x:getDate(x['ConsigneeCourierEntryDate']),axis=1)


# In[37]:


ageing_dffff['ConsigneeEntryDate']=pd.to_datetime(ageing_dffff['ConsigneeEntryDate'])


# In[38]:


ageing_dffff['Current Date']=pd.to_datetime(ageing_dffff['Current Date'])


# In[39]:



ageing_dffff['Diff']=(ageing_dffff['Current Date']-ageing_dffff['ConsigneeEntryDate']).dt.days


# In[40]:


ageing_df=ageing_dffff[ageing_dffff['Diff']>10]
len(ageing_df)


# In[41]:


ageing_df.rename(columns={'Diff':'Reg_Post_Updated >10Days'},inplace=True)


# In[42]:


ageing_df_summary=ageing_df.pivot_table(index=['CurrentLocationDepot'],values=['Reg_Post_Updated >10Days'],aggfunc={'Reg_Post_Updated >10Days':len})


# In[43]:


ageing_df_summary.sort_values(by='Reg_Post_Updated >10Days',ascending= False)


# In[44]:


df1_summary=df1.pivot_table(index=['Remarks'],values=['ConNumber'],aggfunc={'ConNumber':len})


# In[45]:


df1_summary


# In[46]:


df1


# In[47]:


ageing_df


# In[48]:


#df1.to_csv(r'UCG_Final_Data.csv')
df1.to_csv(r'D:\Data\UCG\UCG_Final_Data.csv')

#ageing_df.to_csv(r'UCG_Final_Ageing_Data.csv')
ageing_df.to_csv(r'D:\Data\UCG\UCG_Final_Ageing_Data.csv')


# In[50]:


#df1.to_csv(r'UCG_Final_Data'+str(querydate)+'.csv')

#ageing_df.to_csv(r'UCG_Final_Ageing_Data'+str(querydate)+'.csv')

df1.to_csv(r'D:\Data\UCG\UCG_Final_Data'+str(querydate)+'.csv')
ageing_df.to_csv(r'D:\Data\UCG\UCG_Final_Ageing_Data'+str(querydate)+'.csv')


# In[37]:


filepath1=r'D:\Data\UCG\UCG_Final_Data.csv'
filepath2=r'D:\Data\UCG\UCG_Final_Ageing_Data.csv'
#filepath1=r'UCG_Final_Data.csv'
#filepath2=r'UCG_Final_Ageing_Data.csv'


# In[38]:


import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback
for i in [filepath1,filepath2]:
    oppath1=i
    #FTP Upload starts
    print ('Logging in...')
    ftp = ftplib.FTP()  
    ftp.connect('10.109.230.50')  
    print (ftp.getwelcome())
    try:  
        try:  
            ftp.login('HOSQTeam', 'Te@mH0$q')
            print ('login done')
            ftp.cwd('Auto_reports')  
            #ftp.cwd('FIFO')
            # move to the desired upload directory  
            print ("Currently in:", ftp.pwd()) 
            print ('Uploading...')  
            fullname = oppath1
            name = os.path.split(fullname)[1]  
            f = open(fullname, "rb")  
            ftp.storbinary('STOR ' + name, f)  
            f.close()  
            print ("OK"  )
            print ("Files:")  
            print (ftp.retrlines('LIST'))
        finally:  
            print ("Quitting...")
            ftp.quit()  
    except:  
        traceback.print_exc()


# In[39]:


from_addr = 'mis.ho@spoton.co.in'
# to_addr = ['anitha.thyagarajan@spoton.co.in']
to_addr = ['anitha.thyagarajan@spoton.co.in','sq_spot@spoton.co.in']
# bcc_addr = ['mahesh.reddy@spoton.co.in','sanjana.narayana@spoton.co.in']
bcc_addr = ['mis.ho@spoton.co.in','sanjana.narayana@spoton.co.in','sq_spot@spoton.co.in','rom_spot@spoto.co.in','dom_spot@spoton.co.in','aom_spot@spoton.co.in','scincharge_spot@spoton.co.in','anitha.thyagarajan@spoton.co.in','mahesh.reddy@spoton.co.in','shravani.g@spoton.co.in']
# bcc_addr = ['sanjana.narayana@spoton.co.in']

username = 'mis.ho@spoton.co.in'
password = 'Spot@123'

msg = MIMEMultipart()

msg['From'] = from_addr
msg['To'] = ', '.join(to_addr)
#msg['cc'] = ', '.join(cc_addr)
msg['bcc'] = ', '.join(bcc_addr)
msg['Subject'] = 'UCG - Final Notice Pending details'
html='''<html>
<h4>Dear All</h4>
<p>Please find the attached report for Depot wise UCG Final notice Pending / Invoice Uploaded / Sender register post Updated in the system.</p>
</html>'''
html3='''
<h5> Note : For data please open below link.</h5>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/UCG_Final_Data.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/UCG_Final_Data.csv</p></b>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/UCG_Final_Ageing_Data.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/UCG_Final_Ageing_Data.csv</p></b>

'''
html1='''<h5>Thanks & Regards</h5></b>
<h5>HO-SQ</h5>'''

#  msg.attach(part10)

report=""
report+=html
report+='<br>'
report+='Pending -  Branch yet to upload the Scan Customer Invoice copy into the UCG portal.'
report+='<br>'
report+='Invoice Uploaded -  Branch already uploaded Customer Invoice copy.'
report+='<br>'
report+='<br>'
report+='<br>'+summary1.to_html()+'<br>'
report+='<br>'
report+='The below cons completed UCG final notice process and are ready to move to UCG location.'
report+='<br>'
report+='Kindly move the cons to respective UCG location.'
report+='<br>'
report+='<br>'+ageing_df_summary.to_html()+'<br>'
report+='<br>'
report+=html3
report+='<br>'
report+=html1
abc=MIMEText(report,'html')
msg.attach(abc)

part=MIMEBase('application','octet-stream')
# part1=MIMEBase('application','octet-stream')
#part.set_payload(open(filepath,'rb').read())
# part1.set_payload(open(filepath1,'rb').read())
#encoders.encode_base64(part)
# Encoders.encode_base64(part1)
#part.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath))
# part1.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath1))
#msg.attach(part)
# msg.attach(part1)


# server = smtplib.SMTP('smtp.spoton.co.in',587)
# server.ehlo()
# server.starttls()
# server.ehlo()
# server.login('mis.ho@spoton.co.in','Mis@2019')
# server.sendmail(from_addr,bcc_addr,msg.as_string())
# print ('mail sent succesfully')
# server.quit()

server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login('spoton.net.in', 'Star@123#')
failed = server.sendmail(from_addr,bcc_addr, msg.as_string())
server.quit()

