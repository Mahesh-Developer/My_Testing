
# coding: utf-8

# In[1]:

import pandas as pd
from datetime import datetime, timedelta
import numpy as np
from ortools.algorithms import pywrapknapsack_solver
from sqlalchemy import *
import ast
pd.set_option("display.max_columns",100)
from collections import Counter
import collections



ts= datetime.now()
opfilevar=ts.date()
opfilevar1=ts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=pd.np.floor(float(currhrs)/60)
# In[2]:

# SWITCH!
#1. BLRH
hubname="BLRH" #"PNQH"
sclist=['BLRN','BLRR','BLRT','BLRB','BLRC','DBLR'] #['PNQC','PHRB','DPNQ']
sectorroutelist=["DD-BLRN","DD-BLRR","DD-BLRT","DD-BLRB"] #["DD-PNQC","DD-PHRB"]
vehcaplist=[5200,5200,2200,2200,1250] #[2200,2200]
l5200list=["KA01ES5200","KA02ES5200"] #l2200list=["MH12GT7369","MH16AE8549"]
l2200list=["KA04ES2200","KA05ES2200"]
l1250list=["KA08ES1250"]
# l750list=["KA10ES750"]

#2. PNQH
# hubname="PNQH"
# sclist=['PNQC','PHRB','DPNQ']
# sectorroutelist=["DD-PNQC","DD-PHRB"]
# vehcaplist=[2200,2200]
# l2200list=["MH12GT7369","MH16AE8549"]

#3.
#change mimey

#4. send email


# In[3]:

#1. Downloading df and datetime,int conversions
df=pd.read_excel(r'http://spoton.co.in/downloads/OCID_CLOSINGSTOCK_1HR/OCID_CLOSINGSTOCK_1HR.xls') # df=pd.read_excel(r'C:/users/ankit/desktop/OCID_CLOSINGSTOCK_1HR.xls')
df['ACTUWT']=df['ACTUWT'].astype(int)
df['ACTUWT'] = df.apply(lambda x: max(x['ACTUWT'],x['VOLUME']*6.0) if x['VOLUME']*6.0<3*x["ACTUWT"] else x["ACTUWT"],axis=1)
df['ACTUWT']=df['ACTUWT'].astype(int)
df['DOCKNO']=df['DOCKNO'].astype(int)
df['PARENTCODE']=df['PARENTCODE'].fillna(0).astype(int)
df["PIECES"]=df['PIECES'].astype(int)


# In[4]:

#2 FILTERS
dff=df[(df["DEST BRCD"].isin(sclist))&(df["DEL LOCATION TYPE"]=='STD')].sort_values("ACTUWT",ascending=False)
dff=dff[dff["Sector Route"].isin(sectorroutelist)]
dff=dff[~((dff["Potential Customer"]=="YES")&(dff["Appointment Date"]=="No Apt"))]

ucgstatcodes=['UCG','UG1','UG2','UG3']
depsstatcodes=['DIR','EIR','PIR','SIR','SRD','SRE','SRP','SRS']
otherelims=['MRS','CDA','CNC','DCN','DRB','HIP','HPE','HWC','NRP','NSL','PSO','PSP','PSR','RNA','RNX', 'RRA','RRL','SDR','SHD','SHO','SHS','SPS','SRR','SSC','WIP', 'CCD', 'CPN', 'DNR', 'DRA', 'DRJ', 'DRR', 'FNR', 'HOC', 'ONR', 'PSC', 'RDH', 'RRC', 'RRF', 'RRG', 'RRP', 'VNR', 'AFS', 'AND', 'DIP', 'HIM', 'HMP', 'PSS', 'RRO', 'RRT', 'SEL', 'SRA', 'SRH', 'SRJ', 'WIA']
dff=dff[~((dff["Con Status Code"].isin(ucgstatcodes))|(dff["Con Status Code"].isin(otherelims))|(dff["Con Status Code"].isin(depsstatcodes))|(dff["CON BLOCKED FOR ODA PIN ISSUES"]=='YES')|(dff["CON BLOCKED FOR PAY ISSUES"]=='YES')|(dff["CON BLOCKED FOR DEMURRAGE"]=='YES')|(dff["CSGNCD"]==119721))]

aptcons=["APN","APT"]
dff["Appointment Date"]=pd.to_datetime(dff["Appointment Date"],errors='coerce')
try:
    dff["APN Today"]=dff.apply(lambda x: True if x["Appointment Date"]==pd.to_datetime('today') else False,axis=1)
    dff=dff[~((dff["Con Status Code"].isin(aptcons))&(dff["APN Today"]==False))]
except:
    pass
dff=dff[dff["ARRV AT DEST SC"]>pd.datetime(2017,11,27)]


# In[6]:

#2B: Dedicated
try:
    dedicdf=pd.read_excel(r"D:\Python\Scripts and Files\Path and Graph Files\Dedicated.xlsx")
    lastdeldf=pd.read_excel(r"D:\Python\Scripts and Files\Path and Graph Files\Last_Delivery.xlsx")
except:
    dedicdf=pd.read_excel(r"D:\Python\Scripts and Files\Path and Graph Files\Dedicated.xlsx")
    lastdeldf=pd.read_excel(r"D:\Python\Scripts and Files\Path and Graph Files\Last_Delivery.xlsx")
dedicdf["Dedickey"]=dedicdf["Sender Code"].astype(str)+dedicdf["Dest Pin code"].astype(str)
dedicdflist=dedicdf["Dedickey"].tolist()
dff["Dedickey"]=dff["Customer Code"].astype(str)+dff["DEST PINCODE"].astype(str)
dff["Dedicated"]=dff["Dedickey"].map(lambda x: True if x in dedicdflist else False)
dedicconlist=dff[dff["Dedicated"]==True]["DOCKNO"].tolist()


# In[7]:

#2C: Last Delivery
lastdeldf["lastdelkey"]=lastdeldf["Sender Code"].astype(str)+lastdeldf["Dest Pin code"].astype(str)
lastdeldflist=lastdeldf["lastdelkey"].tolist()
dff["lastdelkey"]=dff["Customer Code"].astype(str)+dff["DEST PINCODE"].astype(str)
dff["Last_Delivery"]=dff["lastdelkey"].map(lambda x: True if x in lastdeldflist else False)
lastdelconlist=dff[dff["Last_Delivery"]==True]["DOCKNO"].tolist()


# ## KNAPSACK

# In[8]:

#3. Solver creation
stopdict={5200:4,2200:4,1250:5,750:5} ##############
capacity=vehcaplist ##############
stops=[stopdict.get(i) for i in capacity]

solver = pywrapknapsack_solver.KnapsackSolver(pywrapknapsack_solver.KnapsackSolver.KNAPSACK_MULTIDIMENSION_BRANCH_AND_BOUND_SOLVER,'Multi-dimensional solver')
def vconfig(pdseries,conseries,capacity=capacity,stops=[stopdict.get(i) for i in capacity],capceil=75.0):
    conwtdict=dict(zip(conseries,pdseries))
    conlist=conwtdict.keys()
    pdlist=[conwtdict.get(i) for i in conlist] #to maintain order of weights
    counter=0
    outputdf = pd.DataFrame(columns=['Veh Payload','Cons','Wts'], index=[])
    
    for cap in capacity:
        caplist=[cap,stops[capacity.index(cap)]] 
        weights = [pdlist,[1 if int(i) not in dedicconlist else stopdict.get(cap) for i in conlist]] #constraint 1 (wt) and constraint 2 (stops complexity)    
        values=weights[0] #3e. so that a higher weight is selected 
        solver.Init(values, weights, caplist)
        output=solver.Solve() ##3g. solved
        cap1check=(output*100.0/caplist[0])>capceil
        if cap1check==True:
            counter=counter+1 #3i. add to list of vehicles
            packed_items=[x for x in range(0, len(weights[0])) if solver.BestSolutionContains(x)] #3j index of packed items
            output_items=[weights[0][i] for i in packed_items] #3k: weights of packed items
            conbins=[conlist[i] for i in packed_items] #3l: con nos. added
            conlist=list(set(conlist)-set(conbins)) #3m. hope that the order is same as pdlist #pls check
            pdlist=[conwtdict.get(i) for i in conlist]
#             weights = [pdlist,[1 if int(i) not in dedicconlist else stopdict.get(cap) for i in conlist]]
#             values=weights[0]
            outputdf.loc[counter] = pd.Series({'Veh Payload':caplist[0],'Cons':conbins,'Wts':output_items})
    return outputdf


# pdseries=sdfsum[sdfsum['Sector Route']=='DD-BLRN']['ACTUWT'].values[0]
# conseries=sdfsum[sdfsum['Sector Route']=='DD-BLRN']['DOCKNO'].values[0]
# conwtdict=dict(zip(conseries,pdseries))
# conlist=conwtdict.keys()
# pdlist=[conwtdict.get(i) for i in conlist]

# In[9]:

#4. Applying the Optimizer
sdfsum=dff.pivot_table(index=["Sector Route"],aggfunc={"ACTUWT":lambda x: tuple(x),"DOCKNO":lambda x: tuple(x)}).reset_index()
order=sectorroutelist
for sc1 in order:
    sc=sc1[3:7]
    try:
        exec(str(sc).lower()+'df'+"=vconfig(sdfsum[sdfsum['Sector Route']==sc1]['ACTUWT'].values[0],sdfsum[sdfsum['Sector Route']==sc1]['DOCKNO'].values[0],capacity=capacity,stops=stops)")
        exec(str(sc).lower()+'df["Util"]='+str(sc).lower()+'df["Wts"].map(lambda x: np.sum(x))*100.0/'+str(sc).lower()+'df["Veh Payload"]')
        exec(str(sc).lower()+'df["SC"]="'+str(sc)+'"')
        exec('capacity=list((Counter(capacity)-Counter('+str(sc).lower()+'df["Veh Payload"].astype(int).tolist())).elements())')
        capacity.sort(reverse=True)
        stops=[stopdict.get(i) for i in capacity]
    except:
        exec(str(sc).lower()+'df'+"=pd.DataFrame([(5200,[3,1,2],[2,3,4],92.3,'BLRB')],columns=['Veh Payload', 'Cons', 'Wts', 'Util', 'SC'])[0:0]")


# In[10]:

masterdf=pd.DataFrame()
for sc1 in order:
    sc=sc1[3:7]
    exec("masterdf=masterdf.append("+str(sc).lower()+"df)")

def flatten(l):
    for el in l:
        if isinstance(el, collections.Iterable) and not isinstance(el, basestring):
            for sub in flatten(el):
                yield sub
        else:
            yield el
ddcons=[i for i in flatten(masterdf["Cons"].values)]
nonddconsdf=dff[~(dff["DOCKNO"].isin(ddcons))]
sdfsum=nonddconsdf.pivot_table(index=["Sector Route"],aggfunc={"ACTUWT":lambda x: tuple(x),"DOCKNO":lambda x: tuple(x)}).reset_index()


# In[11]:

for sc1 in order:
    sc=sc1[3:7]
    try:
        exec(str(sc).lower()+'df2'+"=vconfig(sdfsum[sdfsum['Sector Route']==sc1]['ACTUWT'].values[0],sdfsum[sdfsum['Sector Route']==sc1]['DOCKNO'].values[0],capacity=capacity,stops=stops,capceil=50.0)")
        exec(str(sc).lower()+'df2["Util"]='+str(sc).lower()+'df2["Wts"].map(lambda x: np.sum(x))*100.0/'+str(sc).lower()+'df2["Veh Payload"]')
        exec(str(sc).lower()+'df2["SC"]="'+str(sc)+'"')
        exec(str(sc).lower()+'df='+str(sc).lower()+'df.append('+str(sc).lower()+'df2)')
        exec('capacity=list((Counter(capacity)-Counter('+str(sc).lower()+'df2["Veh Payload"].astype(int).tolist())).elements())')
        capacity.sort(reverse=True)
        stops=[stopdict.get(i) for i in capacity]
    except:
        exec(str(sc).lower()+'df2'+"=pd.DataFrame([(5200,[3,1,2],[2,3,4],92.3,'BLRB')],columns=['Veh Payload', 'Cons', 'Wts', 'Util', 'SC'])[0:0]")        


# In[12]:

masterdf=pd.DataFrame()
for sc1 in order:
    sc=sc1[3:7]
    exec("masterdf=masterdf.append("+str(sc).lower()+"df)")
ddcons=[i for i in flatten(masterdf["Cons"].values)]
nonddconsdf=dff[~dff["DOCKNO"].isin(ddcons)]
sdfsum=nonddconsdf.pivot_table(index=["Sector Route"],aggfunc={"ACTUWT":lambda x: tuple(x),"DOCKNO":lambda x: tuple(x)}).reset_index()


# In[13]:

for sc1 in order:
    sc=sc1[3:7]
    try:
        exec(str(sc).lower()+'df2'+"=vconfig(sdfsum[sdfsum['Sector Route']==sc1]['ACTUWT'].values[0],sdfsum[sdfsum['Sector Route']==sc1]['DOCKNO'].values[0],capacity=capacity,stops=stops,capceil=25.0)")
        exec(str(sc).lower()+'df2["Util"]='+str(sc).lower()+'df2["Wts"].map(lambda x: np.sum(x))*100.0/'+str(sc).lower()+'df2["Veh Payload"]')
        exec(str(sc).lower()+'df2["SC"]="'+str(sc)+'"')
        exec(str(sc).lower()+'df='+str(sc).lower()+'df.append('+str(sc).lower()+'df2)')
        exec('capacity=list((Counter(capacity)-Counter('+str(sc).lower()+'df2["Veh Payload"].astype(int).tolist())).elements())')
        capacity.sort(reverse=True)
        stops=[stopdict.get(i) for i in capacity]
    except:
        exec(str(sc).lower()+'df2'+"=pd.DataFrame([(5200,[3,1,2],[2,3,4],92.3,'BLRB')],columns=['Veh Payload', 'Cons', 'Wts', 'Util', 'SC'])[0:0]")


# In[14]:

masterdf=pd.DataFrame()
for sc1 in order:
    sc=sc1[3:7]
    exec("masterdf=masterdf.append("+str(sc).lower()+"df)")
ddcons=[i for i in flatten(masterdf["Cons"].values)]
ddconsdf=dff[dff["DOCKNO"].isin(ddcons)]


# In[16]:

#4B. Adding Pincode list & attachment
pindict=ddconsdf.loc[:,["DOCKNO","DEST PINCODE"]].set_index("DOCKNO")["DEST PINCODE"].to_dict()
masterdf["Pincodes"]=masterdf["Cons"].map(lambda x: [pindict.get(i) for i in x])


# In[52]:

#5. Implementing VRP
import simplejson
import urllib
import pyodbc
cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=PYTHON_DB;UID=PythonOnline;PWD=P@ssw0rd123$")

df = pd.read_sql("SELECT * FROM hubmaster",cnxn)
hubpindict=df.loc[:,["HUB","Pincode"]].set_index("HUB")["Pincode"].to_dict()
if datetime.utcnow().hour<5:
    departtime=int((datetime.utcnow().replace(hour=5) - datetime(1970, 1, 1)).total_seconds())
else:
    departtime=int((datetime.utcnow().replace(hour=5)+timedelta(days=1) - datetime(1970, 1, 1)).total_seconds())

def stopoptimizer(sc,listofpins):
    scpin=hubpindict.get(sc)
    waypoints=('|').join([str(i) for i in listofpins])
    url="https://maps.googleapis.com/maps/api/directions/json?origin={0}&destination={1}&waypoints=optimize:true|{2}&mode=driving&language=en-EN&sensor=false&departure_time={3}&key=AIzaSyD_sv9kerFNsijx98r1p_0mzPHVcf8vVF0".format(scpin,scpin,waypoints,departtime) #&key=YOUR_API_KEY
    result= simplejson.load(urllib.urlopen(url))
    try:
        waypoint_order = result["routes"][0]['waypoint_order']
    except:
        waypoint_order=range(0,len(listofpins))#str(result)
    
    try:
        km=0
        for i in range(0,len(listofpins)+1):
            km=km+float(result['routes'][0]['legs'][i]['distance']['text'].split(' ')[0])
    except:
        km=0
        
    try:
        timelist=[]
        for i in range(0,len(listofpins)+1):
            timelist=timelist+[result['routes'][0]['legs'][i]['duration']['value']]
    except:
        timelist=[1 for i in range(0,len(listofpins))]
    return [waypoint_order,km,timelist]


# In[54]:

masterdf["Optimizer"]=masterdf.apply(lambda x: stopoptimizer(hubname,x["Pincodes"]),axis=1)


# In[56]:

def lastconcorrection(conlist,optimizer):
    try:
        lastcons=[conlist.index(i) for i in set(lastdelconlist).intersection(set(conlist))]
        firstelem=list(set(optimizer[0])-set(lastcons))+lastcons
        newarrange=[optimizer[0].index(firstelem[i]) for i in range(0,len(firstelem))]
        lastelem=[optimizer[2][0]]+list(set([optimizer[2][i] for i in newarrange])-set([optimizer[2][0]]))+[optimizer[2][-1]]
        return [firstelem,optimizer[1],lastelem]
    except:
        return optimizer


# In[57]:

masterdf["Optimizer"]=masterdf.apply(lambda x: lastconcorrection(x["Cons"],x["Optimizer"]),axis=1)


# In[58]:

masterdf["Optimal_Route"]=masterdf.apply(lambda x: x["Optimizer"][0],axis=1)
masterdf["Kms"]=masterdf.apply(lambda x: x["Optimizer"][1],axis=1)
masterdf["Timeslots"]=masterdf.apply(lambda x: x["Optimizer"][2],axis=1)
masterdf["Cons"]=masterdf.apply(lambda x: [x["Cons"][i] for i in x["Optimal_Route"]],axis=1) # if x["Optimal_Route"]!=['error'] else
masterdf["Wts"]=masterdf.apply(lambda x: [x["Wts"][i] for i in x["Optimal_Route"]],axis=1)
masterdf["Pincodes"]=masterdf.apply(lambda x: [x["Pincodes"][i] for i in x["Optimal_Route"]],axis=1)


# In[59]:

def timeconversion(timeslots):
    starttime=datetime.now().replace(hour=9,minute=0)
    retlist=[datetime.strftime(starttime,"%H:%M")]
    timeperstop=60*90
    for i in timeslots:
        endtime=starttime+timedelta(seconds=i)
        if i!=timeslots[-1]:
            freetime=endtime+timedelta(seconds=timeperstop)
            retlist=retlist+[(datetime.strftime(endtime,"%H:%M"),datetime.strftime(freetime,"%H:%M"))]
        else:
            freetime=endtime
            retlist=retlist+[datetime.strftime(endtime,"%H:%M")]
        starttime=freetime
    return retlist


# In[60]:

masterdf["Timeslots"]=masterdf.apply(lambda x: timeconversion(x["Timeslots"]),axis=1)
masterdf["Util"]=np.round(masterdf["Util"].astype(float),1)


# In[61]:

def vehno(payload):
    if payload==5200:
        vehno=l5200list[0]
        global l5200list
        l5200list=list(set(l5200list)-set([vehno]))
    elif payload==2200:
        vehno=l2200list[0]
        global l2200list
        l2200list=list(set(l2200list)-set([vehno]))
    elif payload==1250:
        vehno=l1250list[0]
        global l1250list
        l1250list=list(set(l1250list)-set([vehno]))
    else:
        vehno=l750list[0]
        global l750list
        l750list=list(set(l750list)-set([vehno]))
    return vehno
masterdf["VehNo"]=masterdf.apply(lambda x: vehno(x["Veh Payload"]),axis=1)


# In[62]:

for sc1 in order:
    sc=sc1[3:7]
    exec(str(sc).lower()+'df=masterdf[masterdf["SC"]=="'+str(sc)+'"].loc[:,["Veh Payload","Cons","Wts","Pincodes","Util","Kms","Timeslots","VehNo"]]')


# In[63]:

#sqldf
sqldf=masterdf.loc[:,["VehNo","Veh Payload","Cons","SC"]]
sqldf["Veh Payload"]=sqldf["Veh Payload"].astype(int)
sqldf=sqldf.reset_index().drop("index",axis=1)


# In[64]:

sqldf=sqldf['Cons'].apply(pd.Series).stack().reset_index(level=1, drop=True).to_frame('Cons').join(sqldf[["Veh Payload","VehNo","SC"]], how='left')
sqldf["Cons"]=sqldf["Cons"].astype(int)


# In[65]:

#Unallocated:
unalloc_vehlist=capacity
unalloc_conlist=list(set(dff["DOCKNO"].tolist())-set(ddcons))
unalloc_dedicconlist=list(set(unalloc_conlist).intersection(dedicconlist))
unallocdf=dff[dff["DOCKNO"].isin(unalloc_conlist)].loc[:,["DOCKNO","ACTUWT","Sector Route","Dedicated","Last_Delivery"]].set_index("DOCKNO")
wts_unalloc=unallocdf["ACTUWT"].sum()


# In[66]:

# filepath='C:/users/ankitgoel888/downloads/DDcons.csv'
# filepath2='C:/users/ankit/desktop/DDcons.csv'
# filepath3='C:/users/ankitgoel888/downloads/Custlist.csv'
# filepath4='C:/users/ankit/desktop/Custlist.csv'
# try:
#     ddconsdf.to_csv(filepath,encoding='utf-8')
#     pd.Series(ddconsdf["PARENTNAME"].unique()).to_csv(filepath3,encoding='utf-8')
# except:
#     ddconsdf.to_csv(filepath2,encoding='utf-8')
#     pd.Series(ddconsdf["PARENTNAME"].unique()).to_csv(filepath4,encoding='utf-8')


# In[67]:
sqldf.to_csv(r'D:\Data\Direct_delivery\BLR\Sqldf\sqldf_BLR_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv')
oppath1 = r'D:\Data\Direct_delivery\BLR\Sqldf\sqldf_BLR_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv'


# In[24]:

masterdf.to_csv(r'D:\Data\Direct_delivery\BLR\Masterdf\masterdf_BLR_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv')
oppath2 = r'D:\Data\Direct_delivery\BLR\Masterdf\masterdf_BLR_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv'


# In[ ]:
import pandas.io.sql
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
import os


# In[ ]:

# server = '10.109.230.13'
# database = 'ESTL_CRP2'
# username = 'sa'
# password = 'password@123'
#conn = pyodbc.connect('DRIVER={ODBC Driver 13 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
cnxn.autocommit = True
cursor = cnxn.cursor()

vehlist = masterdf['VehNo'].tolist()

for u in range (0,len(vehlist)):

    payld = masterdf.iloc[u]['Veh Payload']

    con = masterdf.iloc[u]['Cons']
    con = str(con)

    wt = masterdf.iloc[u]['Wts']
    wt = str(wt)

    util= masterdf.iloc[u]['Util']

    sc = masterdf.iloc[u]['SC']

    pincodes  = masterdf.iloc[u]['Pincodes']
    pincodes = str(pincodes)

    optimizer  = masterdf.iloc[u]['Optimizer']
    optimizer = str(optimizer)

    optroute  = masterdf.iloc[u]['Optimal_Route']
    optroute = str(optroute)

    kms  = masterdf.iloc[u]['Kms']

    timeslot  = masterdf.iloc[u]['Timeslots']

    timeslot = str(timeslot)
    
    vehnos  = masterdf.iloc[u]['VehNo']
    
    cursor.execute("""
    INSERT INTO  TblDirectDelivery_Data (VehiclePayload, cons, weights, Utilisation, Brcd, Pincodes, Optimizer, OptimalRoute, Kms, TimeSlots, vehicleNo) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """,(payld, con, wt, util, sc, pincodes, optimizer, optroute, kms, timeslot, vehnos))
    


conlist = sqldf['Cons'].tolist()

for u in range (0,len(conlist)):
    connumber = sqldf.iloc[u]['Cons']
    connumber =str(connumber)
    vehicleno = sqldf.iloc[u]['VehNo']
    vehicleno = str(vehicleno)

    payld = sqldf.iloc[u]['Veh Payload']

    sc = sqldf.iloc[u]['SC']

    cursor.execute("""
    INSERT INTO TblDirectDelivery_Conwise (ConNo, VehicleNo, VehPayLoad, BRCD) values (?, ?, ?, ?)
    """,(connumber, vehicleno, payld, sc))



filePath = oppath2
def sendEmail(TO = ["vishwas.j@spoton.co.in"],
            #TO = ["rajeesh.vr@spoton.co.in"],
            #TO = ["vishwas.j@spoton.co.in"],
            #CC = ["vishwas.j@spoton.co.in"],
            CC = ["vishwas.j@spoton.co.in"],
            BCC = ["vishwas.j@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    msg["Subject"] = "Direct Delivery Upload BLR"+ '- ' + str(opfilevar)+str('-')+ str(opfilevar2)
    body_text = """

    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()


print 'Done'