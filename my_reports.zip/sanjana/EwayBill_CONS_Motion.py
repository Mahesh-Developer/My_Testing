
# coding: utf-8

# In[1]:

import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
import Utilities

# In[2]:

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()


# In[3]:

query=("""EXEC USP_EWAYBILL_MOTIONCONS_SQ""")


# In[4]:

df=pd.read_sql(query,Utilities.cnxn)


# In[5]:

print (len(df))




# In[6]:

df.columns


# In[7]:

df=df[df['IsExempted']=='N']


# In[8]:

len(df)


try:

    ewdf=df[(df['IS_EWAYBILL_REQUIRE']=='YES')& (df['IS_EWAYBILL_AVLB']=='NO')]


    # In[10]:

    len(ewdf)


    # In[11]:

    pivot_ewdf=ewdf.pivot_table(index=['TCBR'],values=['DOCKNO'],aggfunc={'DOCKNO':len})


    # In[12]:

    pivot_ewdf


    # In[13]:

    not_ewdf=df[(df['IS_EWAYBILL_REQUIRE']=='YES')& (df['IS_EWAYBILL_AVLB']=='YES')&(df['IS_UPDATED']=='NO')]


    # In[14]:

    len(not_ewdf)


    # In[15]:

    pivot_not_ewdf=not_ewdf.pivot_table(index=['TCBR'],values=['DOCKNO'],aggfunc={'DOCKNO':len})


    # In[16]:

    pivot_not_ewdf


    # In[17]:

    sc_ewdf=ewdf[ewdf['ORG_TYPE']=="N"]


    # In[18]:

    len(sc_ewdf)


    # In[19]:

    hub_ewdf=ewdf[ewdf['ORG_TYPE']=="Y"]


    # In[20]:

    len(hub_ewdf)


    # In[21]:

    pivot_sc_ewdf=sc_ewdf.pivot_table(index=['TCBR'],values=['DOCKNO'],aggfunc={'DOCKNO':len})


    # In[22]:

    pivot_sc_ewdf


    # In[23]:

    pivot_hub_ewdf=hub_ewdf.pivot_table(index=['TCBR'],values=['DOCKNO'],aggfunc={'DOCKNO':len})


    # In[24]:

    pivot_hub_ewdf


    # In[25]:

    sc_not_ewdf=not_ewdf[not_ewdf['ORG_TYPE']=='N']


    # In[26]:

    pivot_sc_not_ewdf=sc_not_ewdf.pivot_table(index=['TCBR'],values=['DOCKNO'],aggfunc={'DOCKNO':len})


    # In[27]:

    pivot_sc_not_ewdf


    # In[28]:

    hub_not_ewdf=not_ewdf[not_ewdf['ORG_TYPE']=='Y']


    # In[29]:

    pivot_hub_not_ewdf=hub_not_ewdf.pivot_table(index=['TCBR'],values=['DOCKNO'],aggfunc={'DOCKNO':len})


    # In[30]:

    len(hub_not_ewdf)


    # In[31]:

    pivot_hub_not_ewdf


    # In[32]:

    reportts = datetime.now()
    opfilevar=reportts.date()
    opfilevar1=reportts.time()
    ct2= str (opfilevar1)
    currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

    opfilevar2=pd.np.round((float(currhrs)/60),0)



    # In[33]:

    ewdf.to_csv(r'D:\Data\Ewaybill\Cons Booked\EWB_Cons_Motion_Not_Avlb'+str(opfilevar)+'_'+str(opfilevar2)+'.csv')
    not_ewdf.to_csv(r'D:\Data\Ewaybill\Cons Booked\EWB_Cons_Motion_PartB_Nt_Updated'+str(opfilevar)+'_'+str(opfilevar2)+'.csv')


    ewdf.to_csv(r'D:\Data\Ewaybill\Cons Booked\EWB_Cons_Motion_Not_Avlb.csv')
    not_ewdf.to_csv(r'D:\Data\Ewaybill\Cons Booked\EWB_Cons_Motion_PartB_Nt_Updated.csv')


    # In[34]:

    oppath1 = r'D:\Data\Ewaybill\Cons Booked\EWB_Cons_Motion_Not_Avlb.csv'
    oppath2 = r'D:\Data\Ewaybill\Cons Booked\EWB_Cons_Motion_PartB_Nt_Updated.csv'


    # In[35]:

    for i in [oppath1,oppath2]:
        import numpy as np
        import pandas as pd
        import itertools
        import json
        from pandas import ExcelWriter
        from pandas import pivot_table
        from datetime import datetime
        import os
        import ftplib
        import traceback

        oppath1=i
        #FTP Upload starts
        print ('Logging in...')
        ftp = ftplib.FTP()  
        ftp.connect('10.109.230.50')  
        print (ftp.getwelcome())
        try:  
            try:  
                ftp.login('HOSQTeam', 'Te@mH0$q')
                print ('login done')
                ftp.cwd('Auto_reports')  
                #ftp.cwd('FIFO')
                # move to the desired upload directory  
                print ("Currently in:", ftp.pwd()) 
                print ('Uploading...')  
                fullname = oppath1
                name = os.path.split(fullname)[1]  
                f = open(fullname, "rb")  
                ftp.storbinary('STOR ' + name, f)  
                f.close()  
                print ("OK"  )
                print ("Files:")  
                print (ftp.retrlines('LIST'))
            finally:  
                print ("Quitting...")
                ftp.quit()  
        except:  
            traceback.print_exc()


    # In[36]:

    TO=["hubmgr_spot@spoton.co.in","cnm@spoton.co.in","sq_spot@spoton.co.in",'HUBEWBcontroller@spoton.co.in']
    CC=['sqtf@spoton.co.in','rajesh.kapase@spoton.co.in']
    BCC=['mahesh.reddy@spoton.co.in','shashvat.suhane@spoton.co.in']

    #TO=['mahesh.reddy@spoton.co.in','shivananda.p@spoton.co.in']
    #CC=['mahesh.reddy@spoton.co.in']
    #BCC=['mahesh.reddy@spoton.co.in']
    FROM='mis.ho@spoton.co.in'

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "Ewaybill Exception Report Cons In MOTION-HUB -" + str(opfilevar)+"-"+str(opfilevar2)
    html='''<html>
    <h4>Dear All,</h4>
    </html>'''
    html3='''

    <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EWB_Cons_Motion_Not_Avlb.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EWB_Cons_Motion_Not_Avlb.csv</p></b>
    <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EWB_Cons_Motion_PartB_Nt_Updated.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EWB_Cons_Motion_PartB_Nt_Updated.csv</p></b>
    '''


    report=""
    report+='Dear All,'

    report+='<br>'
    report+='Below is the location wise summary for the cons for which has been departed from Current location'
    report+='<br>'
    report+='<br>'
    report+= 'Cons for which there is no Ewaybill = '+str(len(hub_ewdf))
    report+='<br>'
    report+= 'Cons for which Ewaybill is available but Part B is not updated = '+str(len(hub_not_ewdf))
    report+='<br>'
    report+='<br>'
    report+='Location wise summary for the cons for which there is no Ewaybill'
    report+='<br>'
    report+=''
    report+='<br>'+pivot_hub_ewdf.to_html()+'<br>'
    report+='Below is the summary of the cons for which Part B of Ewaybill is not updated'
    report+='<br>'
    report+='<br>'+pivot_hub_not_ewdf.to_html()+'<br>'
    report+=html3
    abc=MIMEText(report,'html')
    msg.attach(abc)

    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(oppath1,"rb").read() )
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
    #msg.attach(part)

    part1 = MIMEBase('application', "octet-stream")
    part1.set_payload( open(oppath2,"rb").read() )
    encoders.encode_base64(part1)
    part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath2))
    #msg.attach(part1)


    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
    server.quit()


    # In[37]:

    TO=["dom_spot@spoton.co.in","rom_spot@spoton.co.in","cnm@spoton.co.in","sq_spot@spoton.co.in","aom_spot@spoton.co.in",'scincharge_spot@spoton.co.in']
    CC=['sqtf@spoton.co.in','rajesh.kapase@spoton.co.in']
    BCC=['mahesh.reddy@spoton.co.in','shashvat.suhane@spoton.co.in']


    #TO=['mahesh.reddy@spoton.co.in','shivananda.p@spoton.co.in']
    #CC=['mahesh.reddy@spoton.co.in']
    #BCC=['mahesh.reddy@spoton.co.in']
    FROM='mis.ho@spoton.co.in'

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "Ewaybill Exception Report Cons In MOTION-SC -" + str(opfilevar)+"-"+str(opfilevar2)
    html='''<html>
    <h4>Dear All,</h4>
    </html>'''
    html3='''
    <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EWB_Cons_Motion_Not_Avlb.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EWB_Cons_Motion_Not_Avlb.csv</p></b>
    <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EWB_Cons_Motion_PartB_Nt_Updated.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EWB_Cons_Motion_PartB_Nt_Updated.csv</p></b>
    '''


    report=""
    report+='Dear All,'

    report+='<br>'
    report+='Below is the location wise summary for the cons for which has been departed from Current location'
    report+='<br>'
    report+='<br>'
    report+= 'Cons for which there is no Ewaybill = '+str(len(sc_ewdf))
    report+='<br>'
    report+= 'Cons for which Ewaybill is available but Part B is not updated = '+str(len(sc_not_ewdf))
    report+='<br>'
    report+='<br>'
    report+='Location wise summary for the cons for which there is no Ewaybill'
    report+='<br>'
    report+=''
    report+='<br>'+pivot_sc_ewdf.to_html()+'<br>'
    report+='Below is the summary of the cons for which Part B of Ewaybill is not updated'
    report+='<br>'
    report+='<br>'+pivot_sc_not_ewdf.to_html()+'<br>'
    report+=html3
    abc=MIMEText(report,'html')
    msg.attach(abc)

    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(oppath1,"rb").read() )
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
    #msg.attach(part)

    part1 = MIMEBase('application', "octet-stream")
    part1.set_payload( open(oppath2,"rb").read() )
    encoders.encode_base64(part1)
    part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath2))
    #msg.attach(part1)


    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
    server.quit()

except:
    TO=['mahesh.reddy@spoton.co.in','shivananda.p@spoton.co.in']
    FROM='mis.ho@spoton.co.in'
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    #msg["CC"] = ",".join(CC)
    #msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "ERROR Report" 
    report=""
    report+='Hi,'

    report+='<br>'
    report+='There was some error in Ewaybill Exception Report Cons In MOTION-SC and MOTION-HUB Reports.'
    report+='<br>'
    
    abc=MIMEText(report.encode('utf-8'),'html')
    msg.attach(abc)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO, msg.as_string())
    server.quit()




# In[ ]:



