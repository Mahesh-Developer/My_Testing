
# coding: utf-8

# In[ ]:

import pandas as pd
from datetime import datetime, timedelta, date
import numpy as np
import zipfile as zf
#from urllib import urlopen
import io
from calendar import monthrange
from sqlalchemy import *
import pyodbc

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template
import Utilities


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=PYTHON_DB;UID=PythonOnline;PWD=P@ssw0rd123$")

startdate="'"+datetime.strftime((datetime.now()-timedelta(days=1)).replace(day=1),"%Y-%m-%d")+"'"
enddate="'"+datetime.strftime(datetime.now(),"%Y-%m-%d")+"'"
df = pd.read_sql("SELECT * FROM revenuebkg WHERE PICKUP_DATE >= {0} AND PICKUP_DATE < {1}".format(startdate,enddate),cnxn) 
# df.to_csv(r'Revenuedata_check.csv')
print (len(df), df['NetRev'].sum())
df=df[df['Product Type']!='AR']
yeststart = datetime.combine((datetime.now()-timedelta(days=1)).date(), datetime.min.time())


# In[ ]:



yestrevenue=round(df[df["PICKUP_DATE"]>=yeststart]["NetRev"].sum()*0.9675/100000.0,1)


horevenue=pd.np.round(df[df['salearea']=='HO']['NetRev'].sum(),2)
blhd_dict={'BLHD':horevenue}



# In[ ]:

#mtdrevenue = round(df["NetRev"].sum()*0.9675/100000.0,1)
yestrevenue=0
if yestrevenue!=0:
    yestrevenue=round(df[df["PICKUP_DATE"]>=yeststart]["NetRev"].sum()*0.9675/100000.0,1)
else:
    startdate=datetime.strftime((datetime.now()-timedelta(days=1)),"%Y-%b-%d")
    enddate=datetime.strftime(datetime.now(),"%Y-%b-%d")
    df=pd.read_csv(r'http://spoton.co.in/downloads/PMD_PL_DL_RV/PMDPLDLRL.csv')
    df=df[df['Product_Type']!='AR']
    def getDate(dt):
        dt1=(dt.split(' ')[2]+'-'+dt.split(' ')[1]+'-'+dt.split(' ')[0])
        return dt1
    df['PICKUP DATE']=df.apply(lambda x:getDate(x['PICKUP_DATE']),axis=1)
    yestrevenue=round(df[df["PICKUP DATE"]>=startdate]["NetRev"].sum()*0.9675/100000.0,1)
    mtdrevenue = round(df["NetRev"].sum()*0.9675/100000.0,1)
# blhdlist=[29910, 30784, 44929, 50163, 50592, 51306, 51558, 56105, 63465, 64858, 65139, 66235, 66788, 67313, 67514, 67862, 68027, 68029, 68031, 68032, 68033, 68034, 68035, 68036, 68037, 68038, 68039, 68040, 68041, 68042, 68043, 68044, 68045, 68046, 68047, 68048, 68049, 68051, 68052, 68055, 68058, 68060, 68061, 68062, 68063, 68064, 68065, 68066, 68067, 68069, 68077, 68078, 68080, 68081, 68082, 68084, 68085, 68087, 68089, 68093, 68094, 68095, 68096, 68098, 68099, 68101, 68102, 68103, 68104, 68105, 68106, 68107, 68108, 68111, 68113, 68114, 68115, 68116, 68117, 68118, 68119, 68120, 68121, 68122, 68123, 69950, 72155, 73084, 73085, 73086, 73087, 75818, 75954, 76360, 77029, 79107, 80663, 81244, 83074, 83579, 85314, 85315, 86387, 86782, 87167, 87201, 87205, 87206, 87207, 87208, 87209, 87210, 87211, 87212, 87213, 87296, 87297, 87298, 87338, 87340, 87342, 87356, 87437, 87854, 88131, 88165, 88489, 89425, 89824, 90150, 90187, 90203, 90642, 91124, 91125, 92325, 92569, 92570, 93450, 94560, 95302, 95657, 95658, 95659, 95660, 95662, 95663, 95664, 95665, 95666, 95667, 95668, 96045, 96119, 96297, 96307, 96333, 96334, 96725, 96828, 96970, 96971, 97174, 97175, 98464, 99041, 99393, 99394, 99551, 99707, 99708, 99709, 99710, 99804, 99813, 99814, 99815, 100226, 100227, 100228, 100229, 100230, 100231, 100232, 100233, 100234, 100235, 100374, 101109, 102557, 102956, 103064, 103348, 103914, 104374, 104375, 104376, 104377, 105974, 106156, 106415, 106657, 106658, 107495, 107923, 108058, 108083, 108274, 109003, 112951, 112952, 112953, 112954, 112955, 113823, 113824, 115924, 116216, 116615, 114288, 111617, 106472, 106625,108619]
# df.loc[df["CUSTOMERCODE"].isin(blhdlist),['CUSTOMER_SIGNED_AT_DEPOT']]="BLHD"
regcleandict = {'AHMEDABAD':'W', 'BENGALURU':'S', 'CHANDIGARH':'N', 'NOIDA':'N', 'GURGAON':'N', 'CHENNAI':'S', 'HEAD OFFICE':'H', 'HO TNT':'H','HYDERABAD':'S','INDORE':'W','KOLKATA':'E','MUMBAI':'W','NEW DELHI':'N','PUNE':'W','ROTN/KL':'S','UP':'N','UTTARAKHAND':'N'}
df["Region"] = df["SaleDepott"].map(regcleandict)
depocleandict = {'AHMEDABAD':'AMDD', 'BENGALURU':'BLRD', 'GURGAON':'NCRD', 'NOIDA':'NCRD', 'CHANDIGARH':'IXCD','CHENNAI':'MAAD', 'HEAD OFFICE':'BLHD', 'HO TNT':'BLHD','HYDERABAD':'HYDD','INDORE':'IDRD','KOLKATA':'CCUD','MUMBAI':'BOMD','NEW DELHI':'NCRD','PUNE':'PNQD','ROTN/KL':'RTKD','UP':'LKOD','UTTARAKHAND':'UKND'}
df.replace({"SaleDepott":depocleandict},inplace=True)


# In[ ]:





# In[ ]:

df1=df[df['DEST_REGION']!='H']
print (len(df1),'df1')


# In[ ]:


# In[ ]:
try:
  cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
  cursor = cnxn.cursor()
  startdate1=datetime.strftime((datetime.today()-timedelta(1)).replace(day=1,hour=0,minute=0,second=0),"%Y-%m-%d %H:%M:%S")
  enddate1=datetime.strftime((datetime.today()-timedelta(1)).replace(hour=23,minute=0,second=0),"%Y-%m-%d %H:%M:%S")
  targetdate=datetime.strftime((datetime.today()-timedelta(1)),"%Y-%m-%d")
  q_query=("SELECT * FROM tblSaleDepotTargetDtls WHERE TARGET_DATE BETWEEN '{0}' AND '{1}'").format(startdate1,enddate1)
  r_df=pd.read_sql(q_query,Utilities.cnxn)


  # In[ ]:

  r_df['per_day_target'].sum()


  # In[ ]:

  yesttarget=pd.np.round((r_df[r_df['TARGET_DATE']==targetdate]['per_day_target'].sum()*0.9675)/100000.0,2)+(100000.0/100000.0)
  yesttarget=pd.np.round(yesttarget,2)
  yesttarget


  # In[ ]:

  r_df['day']=r_df['TARGET_DATE'].dt.weekday
  r_df1=r_df[r_df['day']!=6]
  n=len(r_df1['TARGET_DATE'].unique())
  #mtdtarget=pd.np.round((r_df['per_day_target'].sum()*0.9675)/100000.0,2)+(n*100000.0)/100000.0


  # In[ ]:

  n


  # In[ ]:

  blhd_df=pd.DataFrame([{'opsDepot_code':'BLHD','per_day_target':0*100000.0,'Region':'H'}])
  r_df=pd.concat([r_df,blhd_df],ignore_index=True)
  region_dict={'CCUD':'E','IXCD':'N','LKOD':'N','UKND':'N','NCRD':'N','BLRD':'S','BLHD':'H','HYDD':'S','MAAD':'S','RTKD':'S','AMDD':'W','BOMD':'W','IDRD':'W','PNQD':'W'}
  r_df['Region']=r_df['opsDepot_code'].map(region_dict)
  summar=r_df.pivot_table(index=['Region','opsDepot_code'],values=['per_day_target'],aggfunc={'per_day_target':sum})


  # In[ ]:

  summary1=summar.reset_index()
  summary1


  # In[ ]:

  from datetime import datetime
  cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
  cursor = cnxn.cursor()

  query1=("SELECT * FROM TBL_BRANCH_PUD_TARGET_MASTER where [IS ACTIVE]='Y'")
  dfff=pd.read_sql(query1,cnxn)
  startdate2=datetime.strftime((datetime.today()-timedelta(1)).replace(day=1,hour=0,minute=0,second=0),"%Y-%m-%d %H:%M:%S")
  enddate2=datetime.strftime((datetime.today()-timedelta(1)).replace(day=30,hour=23,minute=0,second=0),"%Y-%m-%d %H:%M:%S")
  dfff=dfff[(dfff['CREATED ON']>=startdate2) & (dfff['CREATED ON']<=enddate2)]


  # In[ ]:

  dfff['TARGET REVENUE'].sum()


  # In[ ]:

  dfff['TARGET REVENUE']=dfff.apply(lambda x:x['TARGET REVENUE']*100000.0,axis=1)


  # In[ ]:

  dfff['TARGET REVENUE'].sum()/100000


  # In[ ]:

  lyear,lmonth,ldate=datetime.now().replace(day=30).year,datetime.now().replace(day=30).month,datetime.now().replace(day=30).day
  fyear,fmonth,fdate=(datetime.now()-timedelta(days=2)).replace(day=1).year,(datetime.now()-timedelta(days=2)).replace(day=1).month,(datetime.now()-timedelta(days=2)).replace(day=1).day
  import datetime

  def workdays(d, end):
    days = []
    while d.date() <= end.date():
        if d.isoweekday()!=7:
            days.append(d)
        d += datetime.timedelta(days=1)
    return days

  import datetime
  no_of_days=workdays(datetime.datetime(fyear,fmonth,fdate),datetime.datetime(lyear, lmonth, ldate))
  len(no_of_days)


  # In[ ]:
  #dfff['Per_Day_Target']=dfff['TARGET REVENUE']
  dfff['Per_Day_Target']=pd.np.round(dfff['TARGET REVENUE']/26,1)


  # In[ ]:

  dfff=dfff.replace([np.inf,-np.inf],np.nan).fillna(0)


  # In[ ]:

  dfff['Per_Day_Target']=dfff['Per_Day_Target'].apply(lambda x: x*n)


  dfff.rename(columns={'Per_Day_Target':'Cash_Target','DEPOCODE':'DEPOT_CODE'},inplace=True)
  def xyz(x):
    if x=='GRGD':
        return "NCRD"
    elif x=='NOID':
        return "NCRD"
    else:
        return x
  dfff['DEPOT_CODE']=dfff.apply(lambda x: xyz(x['DEPOT_CODE']),axis=1)

  dfff=dfff.pivot_table(index=['DEPOT_CODE'],aggfunc={'Cash_Target':sum}).reset_index()
  summary1.rename(columns={'opsDepot_code':'DEPOT_CODE'},inplace=True)



  # In[ ]:

  summary2=pd.merge(summary1,dfff,how='left',on='DEPOT_CODE')
  summary2=summary2.fillna(0)
  summary2


  # In[ ]:

  # summary2['REVENUE']=pd.np.round(summary2['REVENUE']+summary2['Cash_Revenue'],1)
  summary2['TOTTARGET']=pd.np.round(summary2['per_day_target']+summary2['Cash_Target'],1)
  summary2['TOTTARGET'].sum()
  startdate=(datetime.datetime.now()-timedelta(days=1)).replace(day=1)
  enddate=(datetime.datetime.now())
  days=(enddate-startdate).days
  yestbranchrevenue=pd.np.round(summary2['Cash_Target'].sum()/days/100000,2)
  # In[ ]:

  depotdf=df.pivot_table(index=["Region","SaleDepott"],values=["NetRev"],aggfunc={"NetRev":sum},margins=False).reset_index()
  depotdf.rename(columns={'SaleDepott':'DEPOT_CODE'},inplace=True)

  # depotdf['NetRev']=depotdf.apply(lambda x: blhd_dict.get(x['DEPOT_CODE']) if blhd_dict.get(x['DEPOT_CODE'])!=None else x['NetRev'],axis=1)
  # In[ ]:

  summary3=pd.merge(depotdf,summary2[['DEPOT_CODE','TOTTARGET']],how='outer',on='DEPOT_CODE')


  # In[ ]:

  summary3['NetRev'].sum(),summary3['TOTTARGET'].sum()


  # In[ ]:

  summary3['NetRev']=pd.np.round(summary3['NetRev']*0.9675)
  summary3['TOTTARGET']=pd.np.round(summary3['TOTTARGET']*0.9675)


  # In[ ]:

  summary3['NetRev']=pd.np.round(summary3['NetRev']/100000.0,1)
  summary3['TOTTARGET']=pd.np.round(summary3['TOTTARGET']/100000.0,1)


  # In[ ]:

  summary3['NetRev'].sum(),summary3['TOTTARGET'].sum()


  # In[ ]:

  summary4=summary3.pivot_table(index=['Region','DEPOT_CODE'],aggfunc={'NetRev':sum,'TOTTARGET':sum})


  # In[ ]:

  depotdftots1 = summary4.groupby(level='Region').sum()


  # In[ ]:

  depotdftots1.index = [depotdftots1.index, ['Total'] * len(depotdftots1)]
  depotpivot1 = np.round(pd.concat([summary4,depotdftots1]).sort_index().append(summary4.sum().rename(('Grand', 'Total'))),2)


except:
  depotdf=df.pivot_table(index=["Region","SaleDepott"],values=["NetRev"],aggfunc={"NetRev":sum},margins=False).reset_index()
  depotdf.rename(columns={'SaleDepott':'DEPOT_CODE'},inplace=True)
  # depotdf['NetRev']=depotdf.apply(lambda x: blhd_dict.get(x['DEPOT_CODE']) if blhd_dict.get(x['DEPOT_CODE'])!=None else x['NetRev'],axis=1)
  depotdf['NetRev']=pd.np.round(depotdf['NetRev']*0.9675)
  depotdf['NetRev']=pd.np.round(depotdf['NetRev']/100000.0)
  depotdf=depotdf.pivot_table(index=['Region','DEPOT_CODE'],aggfunc={'NetRev':sum})
  depotdftots1 = depotdf.groupby(level='Region').sum()
  depotdftots1.index = [depotdftots1.index, ['Total'] * len(depotdftots1)]
  depotpivot1 = np.round(pd.concat([depotdf,depotdftots1]).sort_index().append(depotdf.sum().rename(('Grand', 'Total'))),2)


depotpivot1=depotpivot1.reset_index()
mtd_revenue=depotpivot1[depotpivot1['Region']=='Grand']['NetRev'].values[0]
try:
    mtd_target=depotpivot1[depotpivot1['Region']=='Grand']['TOTTARGET'].values[0]
except:
    mtd_target=0.0
try:
    depotpivot1.rename(columns={'NetRev':'GrossRev','TOTTARGET':'Target'},inplace=True)
    depotpivot1['%Ach']=pd.np.round(depotpivot1['GrossRev']*100.0/depotpivot1['Target'],1)
except:
    depotpivot1.rename(columns={'NetRev':'GrossRev'},inplace=True)


# In[ ]:

print (mtd_target,mtd_revenue)


# In[ ]:


try:
    yesttarget=pd.np.round((r_df[r_df['TARGET_DATE']==targetdate]['per_day_target'].sum()*0.9675)/100000.0+(100000.0/100000.0)+yestbranchrevenue,2)
except:
    yesttarget=0.0
print (yestrevenue,yesttarget)


# In[66]:



# In[ ]:

yestrevenue,yesttarget


# In[ ]:

regpivot=np.round(df1.pivot_table(index="ORG_REGION",columns="DEST_REGION",values=["NetRev"],aggfunc={"NetRev":lambda x: (x*0.9675/1e5).sum()*100.0/mtd_revenue},margins=True),1)

regpivot.columns=pd.MultiIndex(levels=[[""],['All','E','N','S','W']],labels=[[0, 0, 0, 0, 0],[1, 2, 3, 4, 0]],names=[None,None])
print (regpivot)


# In[ ]:

from datetime import date,timedelta
todate=date.today()
todate


# In[68]:


df.to_csv(r'D:\Data\Revenue Reports\Data\Revenue_Data_'+str(todate)+'.csv')
depotpivot1.to_csv(r'D:\Data\Revenue Reports\Summaries\Depot_Summary_'+str(todate)+'.csv')
regpivot.to_csv(r'D:\Data\Revenue Reports\Summaries\Region_Summary_'+str(todate)+'.csv')

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

# TO=['satya.pal@spoton.co.in','mahesh.reddy@spoton.co.in']  
# TO=['mahesh.reddy@spoton.co.in']  

TO=["krishna.chandrasekar@spoton.co.in","abhik.mitra@spoton.co.in",'satya.pal@spoton.co.in','uday.sharma@spoton.co.in']
FROM="reports.ie@spoton.co.in"
#CC=['mahesh.reddy@spoton.co.in']
CC=['mahesh.reddy@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = "Revenue Variance Report RDB (RevenueBkg Table)" + " - " + str(todate)
html='''<html>
<style>
p
{
margin:0;
margin-top: 5px;
padding:0;
font-size:17px;
line-height:20px;
}
</style>
</html>'''

report="Dear All,"
report+='<br>'
report+='<br>'
report+="Revenue for yesterday is Rs. "+str(round(yestrevenue,2))+' lakhs (Target Rs. '+str(yesttarget)+' lakhs @3.25% CN)'
report+='<br>'
report+='<br>'
report+="MTD Revenue is Rs. "+str(mtd_revenue)+' lakhs (Target Rs. '+str(mtd_target)+' lakhs @3.25% CN)'
report+='<br>'
report+='<br>'
report+='A. MTD REGION TO REGION TRADING PATTERN (%)'
report+='<br>'
report+='<br>'+regpivot.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='DEPOTWISE TRADING:'
report+='<br>'
report+='<br>'+depotpivot1.to_html()+'<br>'

#report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)
# part = MIMEBase('application', "octet-stream")
# part.set_payload( open(filepath,"rb").read() )
# encoders.encode_base64(part)
# part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
# msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()



# In[ ]:



