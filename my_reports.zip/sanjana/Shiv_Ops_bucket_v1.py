
# coding: utf-8

# In[10]:

import pandas as pd
from pandas import ExcelWriter
import os
import traceback
import math
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta

#sys.setdefaultencoding("Windows-1252")


# In[11]:
try:
    #stockdata = pd.read_csv(r'D:\Data\Shiv_closingstock_automation\Ops_bucket\CLSSTKSUM_25042016.csv')
    stockdata = pd.read_csv(r'http://10.109.230.50/downloads/IEPROJECTS/CLSSTKSUM/CLSSTKSUM.csv')

    ### Can Skip Unicode error while writing to Excel. In order to remove junk characters in column name and skip unicode errors

    stockdata=stockdata.rename(columns={'\xef\xbb\xbfPARENTCODE1':'PARENTCODE1'})

    ### Can Skip Unicode error while writing to Excel. In order to remove junk characters in column name and skip unicode errors
    # In[12]:

    opsbucketlist = ['3_OPS/Free Con Bucket-Old','4_OPS/Free Con Bucket-New','4_OPS/Free Con Bucket-NEW','6_DEPS-OPS','7_Others/Timelag','5_OPS Dem Drs Block']
    stockdataops = stockdata[stockdata['STATUS1'].isin(opsbucketlist)]
    stockdataops = stockdataops.drop(['STATUS1','LATEST_CON_REC_COMM1','CSGENM2'],axis=1)
    print stockdataops.columns.tolist()


    stockdataops['PARENTNAME1'] = stockdataops['PARENTNAME1'].str.decode('utf-8').replace(u'\0xe2', '-')
    #stockdataops['RECEIVER NAME'] = stockdataops['RECEIVER NAME'].str.decode('utf-8').replace(u'\0x96', '-')
    #stockdataops['SENDER NAME'] = stockdataops['SENDER NAME'].str.decode('utf-8').replace(u'\0x96', '-')
    stockdataops['ConStatusReason2'] = stockdataops['ConStatusReason2'].str.decode('utf-8').replace(u'\0xe2', '-')

    # In[13]:

    stockdataopslist = ['CDELDT1','ARRV_AT_DEST_SC2','ConStatusDate2']
    print stockdataopslist


    print stockdataops['ARRV_AT_DEST_SC2'].values[0]
    print pd.unique(stockdataops['CDELDT1'])
    print pd.unique(stockdataops['ARRV_AT_DEST_SC2'])
    print pd.unique(stockdataops['ConStatusDate2'])

    timeformat1 = '%d/%m/%Y %H:%M:%S %p'
    dayzero1 = '30/12/2011 00:00:00 AM'
    dayzero = datetime.strptime(dayzero1,timeformat1)

    stockdataops.ConStatusDate2.fillna(dayzero1, inplace=True)

    def datestring(x):
        x = str(x)
        try:
            fulldate = datetime.strptime(x,'%m/%d/%Y %H:%M:%S %p')
            return fulldate
        except:
            fulldate = datetime.strptime(x,'%d/%m/%Y %H:%M:%S %p')
            return fulldate

    print stockdataops['ARRV_AT_DEST_SC2'].values[0]

    for cols in stockdataopslist:
        stockdataops[cols] = stockdataops.apply(lambda x:datestring(x[cols]),axis=1)
        

    stockdataopsamdd = stockdataops[stockdataops['DEST_DEPOT2']=='AMDD']
    stockdataopsblrd = stockdataops[stockdataops['DEST_DEPOT2']=='BLRD']
    stockdataopsbomd = stockdataops[stockdataops['DEST_DEPOT2']=='BOMD']
    stockdataopsccud = stockdataops[stockdataops['DEST_DEPOT2']=='CCUD']
    stockdataopshydd = stockdataops[stockdataops['DEST_DEPOT2']=='HYDD']
    stockdataopsidrd = stockdataops[stockdataops['DEST_DEPOT2']=='IDRD']
    stockdataopsixcd = stockdataops[stockdataops['DEST_DEPOT2']=='IXCD']
    stockdataopslkod = stockdataops[stockdataops['DEST_DEPOT2']=='LKOD']
    stockdataopsmaad = stockdataops[stockdataops['DEST_DEPOT2']=='MAAD']
    stockdataopsncrd = stockdataops[stockdataops['DEST_DEPOT2']=='NCRD']
    stockdataopspnqd = stockdataops[stockdataops['DEST_DEPOT2']=='PNQD']
    stockdataopsrtkd = stockdataops[stockdataops['DEST_DEPOT2']=='RTKD']
    stockdataopsuknd = stockdataops[stockdataops['DEST_DEPOT2']=='UKND']


    # In[14]:

    datetoday= datetime.today()
    datefilter = datetoday-timedelta(hours=24)
    datefilter=datefilter.date()
    datefilter


    # In[15]:

    stockdataops.to_csv('D:\Data\Shiv_closingstock_automation\Ops_bucket\All_depots\Closingstock_OPS_Bucket_'+str(datefilter)+'.csv')


    # In[16]:



    # In[17]:
    with ExcelWriter(r'D:\Data\Shiv_closingstock_automation\Ops_bucket\Closingstock_OPS_Bucket_'+str(datefilter)+'.xlsx') as writer:
        #stockdataops.to_excel(writer, sheet_name='FULL',engine='xlsxwriter')
        stockdataopsamdd.to_excel(writer, sheet_name='AMDD',engine='xlsxwriter')
        stockdataopsblrd.to_excel(writer, sheet_name='BLRD',engine='xlsxwriter')
        stockdataopsbomd.to_excel(writer, sheet_name='BOMD',engine='xlsxwriter')
        stockdataopsccud.to_excel(writer, sheet_name='CCUD',engine='xlsxwriter')
        stockdataopshydd.to_excel(writer, sheet_name='HYDD',engine='xlsxwriter')
        stockdataopsidrd.to_excel(writer, sheet_name='IDRD',engine='xlsxwriter')
        stockdataopsixcd.to_excel(writer, sheet_name='IXCD',engine='xlsxwriter')
        stockdataopslkod.to_excel(writer, sheet_name='LKOD',engine='xlsxwriter')
        stockdataopsmaad.to_excel(writer, sheet_name='MAAD',engine='xlsxwriter')
        stockdataopsncrd.to_excel(writer, sheet_name='NCRD',engine='xlsxwriter')
        stockdataopspnqd.to_excel(writer, sheet_name='PNQD',engine='xlsxwriter')
        stockdataopsrtkd.to_excel(writer, sheet_name='RTKD',engine='xlsxwriter')
        stockdataopsuknd.to_excel(writer, sheet_name='UKND',engine='xlsxwriter')

    oppath1 = r'D:\Data\Shiv_closingstock_automation\Ops_bucket\Closingstock_OPS_Bucket_'+str(datefilter)+'.xlsx'

    # In[18]:

    filePath1 = oppath1
    def sendEmail(TO = ["rom_spot@spoton.co.in","dom_spot@spoton.co.in","aom_spot@spoton.co.in","sunil.nakte@spoton.co.in","trilochan.panda@spoton.co.in"],
                 #TO = ["anitha.thyagarajan@spoton.co.in"],
                 #TO = ["vishwas.j@spoton.co.in"],
                 CC = ["shivananda.p@spoton.co.in","rajesh.kumar@spoton.co.in","anitha.thyagarajan@spoton.co.in"],
                 BCC =  ["mahesh.reddy@spoton.co.in"],
                 #CC = ["vishwas.j@spoton.co.in"],
                FROM="mis.ho@spoton.co.in"):
        HOST = "smtp.spoton.co.in"
    #smtplib.SMTP('smtp.spoton.co.in', 25)

        msg = MIMEMultipart()
        msg["From"] = FROM
        msg["To"] = ",".join(TO)
        msg["CC"] = ",".join(CC)
        msg["BCC"] = ",".join(BCC)
        #msg["Subject"] = "DEPOTWISE OPS Bucket Stock  - "+ str(datefilter)
        msg["Subject"] = "DEPOTWISE OPS Bucket Stock  - "+ str(datefilter)
        body_text = """
        Dear All,
        
        PFA the DEPOTWISE OPS Bucket Stock for """+str(datefilter)+"""
        
        The depots are segregated sheetwise and each sheet has cons belonging to respective depots under OPS Bucket
        
        """
        if body_text:
            msg.attach( MIMEText(body_text) )
        part = MIMEBase('application', "octet-stream")
        part.set_payload( open(filePath1,"rb").read() )
        Encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath1))
        msg.attach(part)
        server=smtplib.SMTP('smtp.sendgrid.net', 587)
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login("spoton.net.in", "Star@123#")

        try:
            failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
            server.close()
        except Exception, e:
            errorMsg = "Unable to send email. Error: %s" % str(e)

    if __name__ == "__main__":
        sendEmail()
    print('Email sent')
    #Sending output file via mail ends

except:

  TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in'] 
  CC=['mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "DEPOTWISE OPS Bucket Stock Error in Execution" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in DEPOTWISE OPS Bucket Stock'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO+CC, msg.as_string())
  server.quit()



# In[ ]:



