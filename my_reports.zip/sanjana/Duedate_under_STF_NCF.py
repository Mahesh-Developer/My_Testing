# -*- coding: utf-8 -*-
"""
Created on Tue Aug 01 14:52:01 2017

@author: rajeeshv
"""

# In[1]:

import graphlab as gl
import graphlab.aggregate as agg
import pandas as pd
from datetime import datetime, timedelta
import networkx as nx
import time

import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
import os
import Utilities

datetoday = datetime.today().date()
lastmonth = datetoday-timedelta(days=31)
print 'lastmonth', lastmonth

datetoday = datetime.today()
datefilter = datetoday-timedelta(hours=24)
datefilter=datefilter.date()
datefilter

# In[2]:
#condata = gl.SFrame(r'D:\Python\Scripts and Files\Path and Graph Files\Con_data_201016.csv')
#condata = gl.SFrame(r'http://spoton.co.in/downloads/IEP_CON_DATA_TO_SQ/IEP_CON_DATA_TO_SQ.csv')

## Edit on 19-12-2016

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()


duedateconquery = ("""
        SELECT  DOCKNO ,
        DOCKDT Pickupdate,
        CDELDT Duedate ,
        B.ETADate ,
        DC ,
        DACCC ,
        VTC ,
        FTC ,
        BOOKING_REGION ,
        ACTUAL_WEIGHT ,
        PKGSNO ,
        VOLUME ,
        ORIGIN_BRCODE ,
        ORIGIN_BRNAME ,
        orgareaname ,
        DESTCD ,
        destareaname ,
        DESTHUB ,
        DESTLOCTYPE ,
        INVOICEVALUE ,
        CURR_AREA ,
        CURR_BRANCHCODE ,
        CURR_BRANCHNAME ,
        ARRV_AT_CURR_LOCATION ,
        HOURS_LYING_AT_CURR_LOCATION ,
        A.ISDEPARTED_FRM_CURRLOC ,
        A.LatestConStatusCategory ,
        A.LatestConStatusCode,
        A.LatestConStatusDesc ,
        A.LatestConStatusDate ,
        CSGNCD ,
        REPLACE(REPLACE(CSGENM,CHAR(13) + CHAR(10), ' '), '"', '') CSGENM ,
        CSGECD ,
        REPLACE(REPLACE(CSGENM,CHAR(13) + CHAR(10), ' '), '"', '') CSGENM ,
        DLV_PINCODE ,
        CSAgentEmpCode ,
        C.EMPNM CSAgentName,
        A.TIME_STAMP
FROM    dbo.tblTimeConnectionReport_Undelivered_2Hrs A
INNER JOIN dbo.tblETAData B WITH (NOLOCK) ON A.DOCKNO = B.ConNo
INNER JOIN dbo.EMPMST C WITH (NOLOCK) ON A.CSAgentEmpCode = C.EMPCD
WHERE   --ISDEPARTED_FRM_CURRLOC = 'NO' AND

                                ( ( B.ETADate > A.CDELDT ) OR A.CDELDT = CONVERT(DATE,GETDATE()))

AND ISNULL(A.LatestConStatusCategory,'') NOT IN ('SENDER FAILURE','RECEIVER FAILURE')

AND A.CURR_BRANCHCODE NOT LIKE '%UCG%'

        """)


duedatecondata = pd.read_sql(duedateconquery, Utilities.cnxn)
print (len(duedatecondata))

#duedatecondata = duedatecondata.rename(columns={'\xef\xbb\xbfDOCKNO': 'DOCKNO'})

duedatecondata.to_csv(r'D:\Data\Duedate_STF_NCF\Duedate_STF_NCF_'+str(datefilter)+'.csv')

duedatecondatapath = r'D:\Data\Duedate_STF_NCF\Duedate_STF_NCF_'+str(datefilter)+'.csv'

filePath = duedatecondatapath
def sendEmail(#TO = ["spot_cstl@spoton.co.in","sharmistha.majumdar@spoton.co.in"],
             TO = ["mahesh.reddy@spoton.co.in"],
             CC = ["mahesh.reddy@spoton.co.in"],
             BCC = ["mahesh.reddy@spoton.co.in","anitha.thyagarajan@spoton.co.in"],
             #BCC = ["vishwas.j@spoton.co.in"],
             #CC = ["rajesh.kumar@spoton.co.in","shivananda.p@spoton.co.in","jothi.menon@spoton.co.in"],
    FROM="mis.ho@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "Duedate cons under STF&NCF" + " - " + str(datefilter)
    body_text = """
    Hi All,
    
    Pls find attached Due date cons which is under STF & NCF Status.
    
    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
