
# coding: utf-8

# In[1]:

import pandas as pd
#import sframe as gl
import graphlab as gl
from datetime import datetime, timedelta
#import sframe.aggregate as agg
import graphlab.aggregate as agg
from itertools import permutations
import numpy as np

import os
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from pandas import ExcelWriter
from email import encoders


# In[2]:

inventory_pd = pd.read_excel('http://spoton.co.in/downloads/HTR_1HR/HTR_1HR.xls')

timestampforsave = inventory_pd['TIMESTAMP'].values[0]

## For removing DEPS Paperwork related Status codes in the code

depspaperworkcodelist = ['SRE','SRD','SRS','SRP','DLP','SWP','PWS','HCM','HPM','MOP','SRH','HOC','ONR','SPH','SPO','DBO','DIP','SHS','SSC','HIP','RNX','APT','APN','SHD','SMT','SPL','MSH','UCG','RRA','HPE','WIA','UG1','UG2','UG3','HMP','HWC','NPE','HIM']
inventory_pd = inventory_pd[~(inventory_pd['Latest Status Code'].isin(depspaperworkcodelist))]
    
## For removing DEPS Paperwork related Status codes in the code

keeplist = ["Hub SC Location","Arrival Date Hub","Next Frwd Loc","Con Number","Destn Branch","Act Wt In Tonnes","Latest Status Code","Volume","TIMESTAMP"]
col = [i for i in inventory_pd.columns if i in keeplist]
inventory_pd = inventory_pd[col]
inventory_pd["Act Wt In Tonnes"]=inventory_pd.apply(lambda x: float(x["Act Wt In Tonnes"]), axis =1)
inventory_pd["Volume"]=inventory_pd.apply(lambda x: float(x["Volume"]), axis =1)

inventory_pd = inventory_pd.fillna(8861785475)
inventory_pd = inventory_pd.replace(8861785475,'other')

inventory = gl.SFrame(inventory_pd)


# In[3]:

inventory["Arrival Date Hub"]=inventory.apply(lambda x: datetime.strptime((str(x["Arrival Date Hub"])
                                                                .split("+")[0]),"%Y-%m-%d %H:%M:%S"))
inventory["TIMESTAMP"]=inventory.apply(lambda x: datetime.strptime
                                       ((str(x["TIMESTAMP"]).split(".")[0]),"%Y-%m-%d %H:%M:%S"))
inventory["Ageing_Hours"]=inventory.apply(lambda x: round
                                          ((x["TIMESTAMP"]-x["Arrival Date Hub"]).seconds*1.0/3600,2))
inventory = inventory[inventory["Ageing_Hours"]>2.0]


# In[4]:

inventory_grp = inventory.groupby(key_columns=['Hub SC Location','Next Frwd Loc'],
                                  operations={'Sum': agg.SUM('Act Wt In Tonnes')})
inventory_grp.rename({"Hub SC Location":"Origin","Next Frwd Loc":"Destination"})


# In[5]:

relev_time = inventory["TIMESTAMP"].unique()[0]
relev_date = datetime.strptime(str(relev_time).split(" ")[0],"%Y-%m-%d")
relev_date


# In[6]:

schedule1 = gl.SFrame.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\Non_ops_basefiles\Sch Dep Times - Feb 17.csv')
schedule = schedule1.sort_values('CPKGPL', ascending=True)
schedule['depart_t1'] = schedule.apply(lambda x: relev_date+timedelta(hours=
        (int(str(x["Departure time"]).split(":")[0])+int(str(x["Departure time"]).split(":")[1])/60)))
schedule['depart_t2'] = schedule.apply(lambda x: relev_date+timedelta(days=1,hours=
        (int(str(x["Departure time"]).split(":")[0])+int(str(x["Departure time"]).split(":")[1])/60)))
schedule['chosen_t1']=schedule.apply(lambda x:x['depart_t2'] if x['depart_t1'].hour<relev_time.hour 
                                     else x['depart_t1'])
schedule['relevant_sch']=schedule.apply(lambda x:True 
            if (x['chosen_t1']-relev_time).total_seconds()*1.0/3600 <= 3 else False)
schedule = schedule[schedule['relevant_sch']==1]


# In[7]:

schedule["Route Details_list"] = schedule.apply(lambda x: x["Route Details"].split("-"))
schedule["Residual_Path"]=schedule.apply(lambda x:
                x['Route Details_list'][x['Route Details_list'].index(x['Origin']): ])

## Edit on 10:26 16-02-2017

schedule['From_Org'] = schedule.apply(lambda x: 'Yes' if x['Route Details_list'][0] == x['Origin'] else 'No')
schedule = schedule[schedule['From_Org']=='Yes'] 

## Edit on 10:26 16-02-2017
# In[8]:

path_dist= gl.SFrame.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\Non_ops_basefiles\Path Distances.csv')
path_loc_list = list(set(list(path_dist["org"].unique())+list(path_dist["dest"].unique())))
path_distg = path_dist.groupby(["org","dest"],{"AvgDist": agg.MIN("dist")})

pathdict ={}
for i in path_distg:
    pathdict.update({(i["org"],i["dest"]):i["AvgDist"]})
for j in path_loc_list:
    pathdict.update({(j,j):0.0})


# In[9]:

schedule['options'] = schedule.apply(lambda x: [[i[0],i[1]] for i in permutations(x['Residual_Path'],2)
                            if (x['Residual_Path'].index(i[0])<x['Residual_Path'].index(i[1])) and 
                            (pathdict.get((x["Residual_Path"][0],i[0]))<400)])


# In[10]:

final_table = schedule.stack("options",new_column_name="OD")[["OD","Route Code","Route Details","Payload","CPKGPL"]]
final_table = final_table.sort_values("CPKGPL", ascending=True)

def getorigin(x):
        try:
            return x[0]
        except:
            pass
def getdest(x):
        try:
            return x[-1]
        except:
            pass
        
final_table["Origin"]=final_table.apply(lambda x: getorigin(x["OD"]))
final_table["Destination"]=final_table.apply(lambda x: getdest(x["OD"]))


# In[11]:

final_table = final_table.fillna("Origin","others")
final_table = final_table.fillna("Destination","others")
inventory_grp = inventory_grp.fillna("Origin","others")
inventory_grp = inventory_grp.fillna("Destination","others")
inventory_grp = inventory_grp.fillna("Sum",0.0)


# In[12]:

grp_finaltable = final_table.groupby(["Origin","Destination"],{"Code": agg.CONCAT("Route Code")})
grp_finaltable["Code"]=grp_finaltable.apply(lambda x: list(set(x["Code"])))
grp_finaltable = grp_finaltable.join(inventory_grp, on = ["Origin","Destination"])


# In[13]:

schedule1.head(2)


# In[14]:

grp_schedule = schedule.groupby(["Route Code","Route Details"], {"PL": agg.MEAN("Payload"),"CPK": agg.MEAN("CPKGPL")})
grp_schedule = grp_schedule.sort_values("CPK", ascending=True)
dict_codes = {}
for i in schedule1:
    dict_codes.update({(i["Route Code"]): (i["CPKGPL"], i["Payload"])})


# In[15]:

grp_finaltable["CPK"] = grp_finaltable.apply(lambda x: [dict_codes.get(i)[0] for i in x["Code"]])


# In[16]:

grp_finaltable["Code"]=grp_finaltable.apply(lambda x: [i for (y,i) in sorted(zip(x["CPK"],x["Code"]))])
grp_finaltable["CPK"]=grp_finaltable.apply(lambda x: [i for (i,y) in sorted(zip(x["CPK"],x["Code"]))])
grp_finaltable["PL"] = grp_finaltable.apply(lambda x: [dict_codes.get(i)[1] for i in x["Code"]])
grp_finaltable["CumPL"] = grp_finaltable.apply(lambda x: np.cumsum(x["PL"]))
grp_finaltable["Util%"] = grp_finaltable.apply(lambda x: [round(x["Sum"]*1000/(i),2) for i in x["CumPL"]])


# In[17]:

schedule['runningtcs'] = schedule.apply(lambda x: [[i[0],i[1]] for i in permutations(x['Route Details_list'],2) if (x['Route Details_list'].index(i[0])<x['Route Details_list'].index(i[1])) and (x['Route Details_list'].index(i[0])<x['Route Details_list'].index(x["Origin"])) and (x['Route Details_list'].index(i[1])>x['Route Details_list'].index(x["Origin"]))])

def nonblank(x):
    if len(x) >1:
        return x
    else:
        return list()

schedule['runningtcs'] = schedule.apply(lambda x: nonblank(x["runningtcs"]))


# In[18]:

schedule2 = schedule.stack("runningtcs",new_column_name="runningstack")
schedule2 = schedule2.dropna("runningstack")
schedule2["TC Origin"] = schedule2.apply(lambda x: getorigin(x["runningstack"]))
schedule2["TC Dest"] = schedule2.apply(lambda x: getdest(x["runningstack"]))


# In[19]:

runningtcfile = gl.SFrame("http://spoton.co.in/downloads/IEP_USP_LIVE_THC_IE_SQ/IEP_USP_LIVE_THC_IE_SQ.csv")


# In[20]:

grprunningtcfile = runningtcfile.groupby(["routecd","TCBR","ToBH_CODE"],{"Sum": agg.SUM("ACTWEIGHT")})


# In[21]:

grprunningtcfile = grprunningtcfile[grprunningtcfile["routecd"]!="9888"]


# In[22]:

def getpl(x):
    try:
        pl = dict_codes.get(x)[1]
        return pl
    except:
        print x     


# In[23]:

grprunningtcfile["PL"] = grprunningtcfile.apply(lambda x: getpl(x["routecd"]))
grprunningtcfile = grprunningtcfile.dropna("PL")
grprunningtcfile["UtilisationR%"] = grprunningtcfile.apply(lambda x: round(x["Sum"]*1/x["PL"],2))
grprunningtcfile=grprunningtcfile.rename({"TCBR":"Origin","ToBH_CODE":"Destination"})


# In[24]:

grp_finaltable["Zipped"]=grp_finaltable.apply(lambda x: list(zip(x["Code"],x["CPK"],x["PL"],x["CumPL"],x["Util%"])))
grp_finaltable2 = grp_finaltable.stack("Zipped","ZippedStack")
grp_finaltable2['Utilisation%'] = grp_finaltable2.apply(lambda x: x['ZippedStack'][4])
grp_finaltable2['routecd'] = grp_finaltable2.apply(lambda x: x['ZippedStack'][0])


# In[25]:

grp_finaltable2 = grp_finaltable2.join(grprunningtcfile, on=["routecd","Origin","Destination"], how='left')
grp_finaltable2["FinalUtil%"]=grp_finaltable2.apply(lambda x: x["Utilisation%"]+max(x["UtilisationR%"],0))


# In[26]:

premium = gl.SFrame(r"D:\Python\Scripts and Files\Path and Graph Files\Non_ops_basefiles\premium.csv")


# In[27]:

premiumdict = {}
for i in premium:
    premiumdict.update({(i["PL Reclassified"],i["Origin"],i["Destination"]):i["Premium"]})
    
premiumdict2 = {}
for i in premium:
    premiumdict2.update({(i["Origin"],i["Destination"]):i["Premium"]})


# In[28]:

def getpremium(PL,ORG,DEST):
    if premiumdict.get((PL,ORG,DEST))>0:
        return premiumdict.get((PL,ORG,DEST))
    elif premiumdict2.get((ORG,DEST))>0:
        return premiumdict2.get((ORG,DEST))
    else:
        return 0.3


# In[29]:

grp_finaltable2["Premium"]=grp_finaltable2.apply(lambda x: getpremium(x["PL.1"],x["Origin"],x["Destination"]))


# In[30]:

grp_finaltable2["NONOPS"]=grp_finaltable2.apply(lambda x:False if x["Premium"]>(1-x["FinalUtil%"]) else True)
grp_finaltable2['PL'] = grp_finaltable2.apply(lambda x: x['PL'][x['Code'].index(x['routecd'])]) #to escape from list and get a number
grp_finaltable2 = grp_finaltable2.rename({'routecd':'route','Sum':'Wt(T)','Origin':'Org','Destination':'Dest','PL':'Payload'})
print grp_finaltable2
# In[31]:

#grp_finaltable2.head(2)
reportts = datetime.now()

opfilevar=reportts.date()
opfilevar1=reportts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=np.round((float(currhrs)/60),0)
# In[32]:

grp_finaltable2['Timestamp'] = grp_finaltable2.apply(lambda x:timestampforsave)

grp_finaltable2.save(r'D:\Data\Non_ops\NON_OPS_'+str(opfilevar)+str('-')+str(opfilevar2)+'.csv')

## For email body and attachment
grp_finaltable2_mail = grp_finaltable2[['route','Org','Dest','Payload','Wt(T)','FinalUtil%','NONOPS']]
print grp_finaltable2_mail
grp_finaltable2_mail = grp_finaltable2_mail.sort_values('Payload', ascending = False)

grp_finaltable2_mail.save(r'D:\Python\Scripts and Files\Path and Graph Files\NON_OPS.csv')
oppathatchmt = r'D:\Python\Scripts and Files\Path and Graph Files\NON_OPS.csv'

grp_finaltable2_maildf = grp_finaltable2_mail.to_dataframe()


grp_finaltable2_maildf = grp_finaltable2_maildf[(grp_finaltable2_maildf['Payload']==13500) & (grp_finaltable2_maildf['NONOPS']==1)]

if len(grp_finaltable2_maildf) != 0:
    grp_finaltable2_maildf = grp_finaltable2_maildf
else:
    grp_finaltable2_maildf = pd.DataFrame()


## For email body and attachment


filePath = oppathatchmt
def sendEmail(#TO = ["supratim@iepfunds.com","rajeesh.vr@spoton.co.in"],
            #TO = ["cnm@spoton.co.in","raghavendra.rao@spoton.co.in","HUBMGR_SPOT@spoton.co.in"],
            #TO = ["rajeesh.vr@spoton.co.in"],
            TO = ["mahesh.reddy@spoton.co.in"],
            CC = ["mahesh.reddy@spoton.co.in"],
            #TO = ["supratim@iepfunds.com","Ankit@iepfunds.com","prasanna.hegde@spoton.co.in","rajeesh.vr@spoton.co.in"],
            #CC = ["vishwas.j@spoton.co.in"],
            #CC = ["supratim@iepfunds.com","pawan.sharma@spoton.co.in","Ankit@iepfunds.com","sqtf@spoton.co.in","shivananda.p@spoton.co.in","prasanna.hegde@spoton.co.in","rajeesh.vr@spoton.co.in","vishwas.j@spoton.co.in", "rajesh.debnath@spoton.co.in"],
            #BCC = ["vinayak.kumbhar@spoton.co.in","vinodkumar.mishra@spoton.co.in","nitin.tatyarao@spoton.co.in","kiran.pawar@spoton.co.in","jai.prakash@spoton.co.in","yogesh.singh@spoton.co.in"] ,
            BCC = ["mahesh.reddy@spoton.co.in"] ,
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "Load Available for movement @ "+ str(opfilevar)+"-"+str(opfilevar2)
    msg["Subject"] = "NON-OPS Report @ "+ str(opfilevar)+"-"+str(opfilevar2)
    body_text = """
    Dear All,
    
    PFB the NON OPS Report @ """ +str(opfilevar)+"-"+str(opfilevar2)+"""

    
    """+str(grp_finaltable2_maildf)+"""
    
    
    """
    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends



