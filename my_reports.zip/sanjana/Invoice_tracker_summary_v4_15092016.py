
# coding: utf-8

# In[1]:

import pandas as pd
from datetime import datetime, date
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import os
import traceback
import ftplib
import glob


# In[2]:

fullinvoicedata = pd.read_csv('http://spoton.co.in/downloads/INVOICE_TRACKER_IEP/INVOICE_TRACKER_IEP_REPORT.csv')
print len(fullinvoicedata)

#fullinvoicedata = fullinvoicedata[fullinvoicedata['Type_of_Invoice']=='Freight']
#print len(fullinvoicedata)
# In[3]:



fullinvoicedata = fullinvoicedata[fullinvoicedata['CustomerType']!='Cash']
# In[4]:

# timeformat1 = '%d/%m/%y'
# dayzero1 = '30/12/11'

timeformat1 = '%d/%m/%Y'
dayzero1 = '30/12/2011'
dayzero = datetime.strptime(dayzero1,timeformat1)


# In[5]:

fullinvoicedata = fullinvoicedata.rename(columns={'\xef\xbb\xbfRegion':'Region'})
fullinvoicedata.columns.tolist()


# In[6]:

fullinvoicedata['HO_Despatch_Date'].values[0]


# In[7]:


#fullinvoicedata['CC_Recv_Date'].fillna(dayzero1,inplace=True)

#fullinvoicedata['Physically_Received_by_Authorized_Customer_Date'].fillna(dayzero1,inplace=True)

fullinvoicedata['PIS_Date'].fillna(dayzero1,inplace=True)

fullinvoicedata['Invoice_Date'].fillna(dayzero1,inplace=True)

fullinvoicedata['Submission_to_the_Customer_Date'].fillna(dayzero1,inplace=True)
fullinvoicedata['Date_Of_Confirmation'].fillna(dayzero1,inplace=True)

fullinvoicedata['HO_Despatch_Date'] = fullinvoicedata['HO_Despatch_Date'].str.replace('-',dayzero1)
#stdvehinadhocsummarymerge.PUDTYPE2.fillna('STD',inplace=True)


# In[8]:

#fullinvoicedata.to_csv('fullinvoicedata.csv')


# In[9]:

#datecols = [i for i in fullinvoicedata.columns if 'Date' in i]
datecols = ['PIS_Date','Invoice_Date','HO_Despatch_Date','Submission_to_the_Customer_Date','Date_Of_Confirmation','Delivery_Date_Update']
type(datecols)


# In[10]:

def convertdate(x):
    try:
        
        x = x.split(' ')[0]
        return datetime.strptime(x,timeformat1)
    except:
        return dayzero


# In[11]:

for datecol in datecols:
    #invoice = invoice.fillna(datecol, dayzero1)
    #invoice = invoice[(invoice[datecol]!='-') or (invoice[datecol]) or (invoice[datecol]!='N') or (invoice[datecol]!='')]
    fullinvoicedata[datecol] = fullinvoicedata.apply(lambda x: convertdate(x[datecol]),axis=1)
    print datecol, len(fullinvoicedata)


# In[12]:

fullinvoicedata['HO_Despatch_Date'].values[0]


# In[13]:

# For elimination of all PIS generated invoices
fullinvoicedata = fullinvoicedata[fullinvoicedata['PIS_Date']==dayzero]
print 'pis eliminated', len(fullinvoicedata)
# For elimination of all PIS generated invoices


# For elimination of all invoices except Freight & Octroi . Changed to only frieght on 03-10-2016
##invoicetypelist = ['Freight','Octroi']
invoicetypelist = ['Freight']
fullinvoicedata = fullinvoicedata[fullinvoicedata['Type_of_Invoice'].isin(invoicetypelist)]
# For elimination of all invoices except Freight & Octroi
print len(fullinvoicedata)


## Removed octroi invoices on 03-10-2016
#ix = fullinvoicedata[fullinvoicedata['Type_of_Invoice']=='Octroi'].index
#fullinvoicedata.loc[ix,'Category'] = 'Octroi'
## Removed octroi invoices on 03-10-2016

# In[14]:

stage1df = fullinvoicedata[(fullinvoicedata['Invoice_Date']!=dayzero) & (fullinvoicedata['HO_Despatch_Date']==dayzero) & (fullinvoicedata['Date_Of_Confirmation']==dayzero)]
stage2df = fullinvoicedata[(fullinvoicedata['Invoice_Date']!=dayzero) & (fullinvoicedata['HO_Despatch_Date']!=dayzero) & (fullinvoicedata['Delivery_Date_Update']!=dayzero) & (fullinvoicedata['Date_Of_Confirmation']==dayzero)]

stage2df_dd = stage2df[stage2df['DespatchType']=='Direct Despatch'] 
stage2df_hd = stage2df[stage2df['DespatchType']=='Hand Delivery']

stage3df = fullinvoicedata[(fullinvoicedata['Invoice_Date']!=dayzero) & (fullinvoicedata['HO_Despatch_Date']!=dayzero) & (fullinvoicedata['Date_Of_Confirmation']!=dayzero) & (fullinvoicedata['PIS_Date']==dayzero)]


#len(stage1df), dayzero, type(dayzero), fullinvoicedata['HO_RODespatchDate'].values[0], type(fullinvoicedata['HO_RODespatchDate'].values[0])
#stage1df.to_csv('D:\Data\Invoice_tracker\stage1df.csv')
#stage2df.to_csv('D:\Data\Invoice_tracker\stage2df.csv')
#stage3df.to_csv('D:\Data\Invoice_tracker\stage3df.csv')

len(stage1df),len(stage2df),len(stage3df)


# In[15]:

todaydate1 = datetime.today()
def diffdate(passdate):
    #passdate = fullinvoicedata['InvoiceDate'].values[0]
    a1 = pd.to_datetime(str(passdate)).replace(tzinfo=None)
    diffdays = int((todaydate1-a1).days)
    return diffdays


# In[16]:

##fullinvoicedata.to_csv('fullinvoicedata.csv')


# In[17]:

stage1df['Stage1_diffdays'] =  stage1df.apply(lambda x : diffdate(x['Invoice_Date']),axis=1)
stage2df['Stage2_diffdays'] =  stage2df.apply(lambda x : diffdate(x['Delivery_Date_Update']),axis=1)

stage2df_hd['Stage2_diffdays'] =  stage2df_hd.apply(lambda x : diffdate(x['Delivery_Date_Update']),axis=1)
stage2df_dd['Stage2_diffdays'] =  stage2df_dd.apply(lambda x : diffdate(x['Delivery_Date_Update']),axis=1)

stage3df['Stage3_diffdays'] =  stage3df.apply(lambda x : diffdate(x['Submission_to_the_Customer_Date']),axis=1)


# In[21]:

def tatstage1(podtype):
    if podtype == 'CD Copy':
        return 9    ## Previously 7. Edit on 27-01-2017. Changed to 9 to give 2 days for printing of invoice
    elif podtype == 'Hard Copy':
        return 12   ## Previously 12. Edit on 27-01-2017. Changed to 14 to give 2 days for printing of invoice
    elif podtype == 'Soft Copy':
        return 9    ## Previously 7. Edit on 27-01-2017. Changed to 9 to give 2 days for printing of invoice
    elif podtype == 'Not Required':
        return 3    ## Previously 1. Edit on 27-01-2017. Changed to 3 to give 2 days for printing of invoice
    elif podtype == 'Octroi':
        return 3
    else:
        return 'check'


# In[22]:

stage1df['TAT'] = stage1df.apply(lambda x:tatstage1(x['Category']),axis=1)


# In[23]:
## For TAT for Octroi invoices

def tatstage2(invoicetype):
    if invoicetype == 'Freight':
        return 3
    elif invoicetype == 'Octroi':
        return 7
    else:
        return 'check'

## For TAT for Octroi invoices

stage2df['TAT'] = stage2df.apply(lambda x:tatstage2(x['Type_of_Invoice']),axis=1)

stage2df_hd['TAT'] = stage2df_hd.apply(lambda x:tatstage2(x['Type_of_Invoice']),axis=1)
stage2df_dd['TAT'] = stage2df_dd.apply(lambda x:tatstage2(x['Type_of_Invoice']),axis=1)
#stage3df.loc[stage3df.index,'TAT'] = 30


# In[24]:

stage1df['DSO_value'] = stage1df.apply(lambda x :pd.np.round((x['Stage1_diffdays'])*(x['Invoice_Amt']),0),axis=1)
stage2df['DSO_value'] = stage2df.apply(lambda x :pd.np.round((x['Stage2_diffdays'])*(x['Invoice_Amt']),0),axis=1)

stage2df_hd['DSO_value'] = stage2df_hd.apply(lambda x :pd.np.round((x['Stage2_diffdays'])*(x['Invoice_Amt']),0),axis=1)
stage2df_dd['DSO_value'] = stage2df_dd.apply(lambda x :pd.np.round((x['Stage2_diffdays'])*(x['Invoice_Amt']),0),axis=1)

stage3df['DSO_value'] = stage3df.apply(lambda x :pd.np.round((x['Stage3_diffdays'])*(x['Invoice_Amt']),0),axis=1)


# In[25]:

def crosstat(tat1,diffdays1):
    if diffdays1>tat1:
        return 'Yes'
    else:
        return 'No'


## Removed octroi invoices on 03-10-2016
#iy = stage3df[stage3df['Type_of_Invoice']=='Octroi'].index
#stage3df.loc[iy,'CreditPeriod'] = 15
## Removed octroi invoices on 03-10-2016

# In[26]:

stage1df['Crossed_TAT'] = stage1df.apply(lambda x :crosstat(x['TAT'],x['Stage1_diffdays']),axis=1)
stage2df['Crossed_TAT'] = stage2df.apply(lambda x :crosstat(x['TAT'],x['Stage2_diffdays']),axis=1)

stage2df_hd['Crossed_TAT'] = stage2df_hd.apply(lambda x :crosstat(x['TAT'],x['Stage2_diffdays']),axis=1)
stage2df_dd['Crossed_TAT'] = stage2df_dd.apply(lambda x :crosstat(x['TAT'],x['Stage2_diffdays']),axis=1)

stage3df['Crossed_TAT'] = stage3df.apply(lambda x :crosstat(x['CreditPeriod'],x['Stage3_diffdays']),axis=1)

### For POD availability invoices
def podavail(custagreed,podavailable,podtype):
    if podtype=='POD':
        if podavailable>=custagreed:
            return 1
        else:
            return 0
    else:
        return 0

stage1df['Invoice_POD_Available'] = stage1df.apply(lambda x :podavail(x['Customer_Agreed_Perc'],x['POD_Available_Perc'],x['POD_NPOD']),axis=1)

### For POD availability invoices
# In[28]:

##stage1dfgrp = stage1df.groupby(['Category']).agg({'Invoice_No':len,'Invoice_Amt':sum,'DSO_value':sum,'Stage1_diffdays':pd.np.mean}).reset_index()

stage1dfgrp = stage1df.groupby(['Category']).agg({'Invoice_No':len,'Invoice_Amt':sum,'DSO_value':sum,'Stage1_diffdays':pd.np.mean,'Invoice_POD_Available':sum}).reset_index()

stage2dfgrp = stage2df.groupby(['Depot']).agg({'Invoice_No':len,'Invoice_Amt':sum,'DSO_value':sum,'Stage2_diffdays':pd.np.mean}).reset_index()

stage2dfgrp_hd = stage2df_hd.groupby(['Depot']).agg({'Invoice_No':len,'Invoice_Amt':sum,'DSO_value':sum,'Stage2_diffdays':pd.np.mean}).reset_index()
stage2dfgrp_dd = stage2df_dd.groupby(['Depot']).agg({'Invoice_No':len,'Invoice_Amt':sum,'DSO_value':sum,'Stage2_diffdays':pd.np.mean}).reset_index()

stage3dfgrp = stage3df.groupby(['Depot']).agg({'Invoice_No':len,'Invoice_Amt':sum,'DSO_value':sum,'Stage3_diffdays':pd.np.mean}).reset_index()


# In[29]:

stage1tatyes = stage1df[stage1df['Crossed_TAT']=='Yes']
stage2tatyes = stage2df[stage2df['Crossed_TAT']=='Yes']

stage2tatyes_hd = stage2df_hd[stage2df_hd['Crossed_TAT']=='Yes']
stage2tatyes_dd = stage2df_dd[stage2df_dd['Crossed_TAT']=='Yes']

stage3tatyes = stage3df[stage3df['Crossed_TAT']=='Yes']


# In[30]:

#stage1tatyesgrp = stage1tatyes.groupby(['Category']).agg({'Invoice_No':len,'Invoice_Amt':sum,'DSO_value':sum,'Stage1_diffdays':pd.np.mean}).reset_index()

stage1tatyesgrp = stage1tatyes.groupby(['Category']).agg({'Invoice_No':len,'Invoice_Amt':sum,'DSO_value':sum,'Stage1_diffdays':pd.np.mean,'Invoice_POD_Available':sum}).reset_index()

stage2tatyesgrp = stage2tatyes.groupby(['Depot']).agg({'Invoice_No':len,'Invoice_Amt':sum,'DSO_value':sum,'Stage2_diffdays':pd.np.mean}).reset_index()

stage2tatyesgrp_hd = stage2tatyes_hd.groupby(['Depot']).agg({'Invoice_No':len,'Invoice_Amt':sum,'DSO_value':sum,'Stage2_diffdays':pd.np.mean}).reset_index()
stage2tatyesgrp_dd = stage2tatyes_dd.groupby(['Depot']).agg({'Invoice_No':len,'Invoice_Amt':sum,'DSO_value':sum,'Stage2_diffdays':pd.np.mean}).reset_index()

stage3tatyesgrp = stage3tatyes.groupby(['Depot']).agg({'Invoice_No':len,'Invoice_Amt':sum,'DSO_value':sum,'Stage3_diffdays':pd.np.mean}).reset_index()


# In[31]:

stage1final = pd.merge(stage1dfgrp,stage1tatyesgrp,on=['Category'],suffixes=['_total','_crossed_TAT'],how='outer')
stage2final = pd.merge(stage2dfgrp,stage2tatyesgrp,on=['Depot'],suffixes=['_total','_crossed_TAT'],how='outer')

stage2final_hd = pd.merge(stage2dfgrp_hd,stage2tatyesgrp_hd,on=['Depot'],suffixes=['_total','_crossed_TAT'],how='outer')
stage2final_dd = pd.merge(stage2dfgrp_dd,stage2tatyesgrp_dd,on=['Depot'],suffixes=['_total','_crossed_TAT'],how='outer')

stage3final = pd.merge(stage3dfgrp,stage3tatyesgrp,on=['Depot'],suffixes=['_total','_crossed_TAT'],how='outer')


# In[32]:

# stage1final.to_csv('stage1final.csv')
# stage2final.to_csv('stage2final.csv')
# stage3final.to_csv('stage3final.csv')
stage1final['Weighted_avg_DSO'] = stage1final.apply(lambda x:pd.np.round(x['DSO_value_total']/x['Invoice_Amt_total'],0),axis=1)
stage2final['Weighted_avg_DSO'] = stage2final.apply(lambda x:pd.np.round(x['DSO_value_total']/x['Invoice_Amt_total'],0),axis=1)

stage2final_hd['Weighted_avg_DSO'] = stage2final_hd.apply(lambda x:pd.np.round(x['DSO_value_total']/x['Invoice_Amt_total'],0),axis=1)
stage2final_dd['Weighted_avg_DSO'] = stage2final_dd.apply(lambda x:pd.np.round(x['DSO_value_total']/x['Invoice_Amt_total'],0),axis=1)

stage3final['Weighted_avg_DSO'] = stage3final.apply(lambda x:pd.np.round(x['DSO_value_total']/x['Invoice_Amt_total'],0),axis=1)

# In[33]:

stage1final['Weighted_avg_DSO_crossedTAT'] = stage1final.apply(lambda x:pd.np.round(x['DSO_value_crossed_TAT']/x['Invoice_Amt_crossed_TAT'],0),axis=1)
stage2final['Weighted_avg_DSO_crossedTAT'] = stage2final.apply(lambda x:pd.np.round(x['DSO_value_crossed_TAT']/x['Invoice_Amt_crossed_TAT'],0),axis=1)

stage2final_hd['Weighted_avg_DSO_crossedTAT'] = stage2final_hd.apply(lambda x:pd.np.round(x['DSO_value_crossed_TAT']/x['Invoice_Amt_crossed_TAT'],0),axis=1)
stage2final_dd['Weighted_avg_DSO_crossedTAT'] = stage2final_dd.apply(lambda x:pd.np.round(x['DSO_value_crossed_TAT']/x['Invoice_Amt_crossed_TAT'],0),axis=1)

stage3final['Weighted_avg_DSO_crossedTAT'] = stage3final.apply(lambda x:pd.np.round(x['DSO_value_crossed_TAT']/x['Invoice_Amt_crossed_TAT'],0),axis=1)



def roundoff(diffdays):
    diffdays = pd.np.round(diffdays,0)
    return diffdays

def perc_calc(invoices,cross_tat_invoices):
    perc = pd.np.round((cross_tat_invoices*1.0/invoices)*100,0)
    return perc
    

stage1final['Avg_delay_days_crossedTAT'] = stage1final.apply(lambda x:(roundoff(x['Stage1_diffdays_crossed_TAT'])),axis=1)
stage2final['Avg_delay_days_crossedTAT'] = stage2final.apply(lambda x:(roundoff(x['Stage2_diffdays_crossed_TAT'])),axis=1)

stage2final_hd['Avg_delay_days_crossedTAT'] = stage2final_hd.apply(lambda x:(roundoff(x['Stage2_diffdays_crossed_TAT'])),axis=1)
stage2final_dd['Avg_delay_days_crossedTAT'] = stage2final_dd.apply(lambda x:(roundoff(x['Stage2_diffdays_crossed_TAT'])),axis=1)

stage3final['Avg_delay_days_crossedTAT'] = stage3final.apply(lambda x:(roundoff(x['Stage3_diffdays_crossed_TAT'])),axis=1)

stage1final['%Invoices_crossTAT'] = stage1final.apply(lambda x: perc_calc(x['Invoice_No_total'],x['Invoice_No_crossed_TAT']),axis=1)
stage2final['%Invoices_crossTAT'] = stage2final.apply(lambda x: perc_calc(x['Invoice_No_total'],x['Invoice_No_crossed_TAT']),axis=1)

stage2final_hd['%Invoices_crossTAT'] = stage2final_hd.apply(lambda x: perc_calc(x['Invoice_No_total'],x['Invoice_No_crossed_TAT']),axis=1)
stage2final_dd['%Invoices_crossTAT'] = stage2final_dd.apply(lambda x: perc_calc(x['Invoice_No_total'],x['Invoice_No_crossed_TAT']),axis=1)

stage3final['%Invoices_crossTAT'] = stage3final.apply(lambda x: perc_calc(x['Invoice_No_total'],x['Invoice_No_crossed_TAT']),axis=1)

# In[34]:
stage1final.fillna(0,inplace=True)

stage1final = pd.DataFrame(stage1final,columns=['Category','Invoice_No_total','Invoice_Amt_total','Weighted_avg_DSO','Invoice_POD_Available_total','Invoice_No_crossed_TAT','%Invoices_crossTAT','Invoice_Amt_crossed_TAT','Weighted_avg_DSO_crossedTAT','Avg_delay_days_crossedTAT','Invoice_POD_Available_crossed_TAT'])
stage2final = pd.DataFrame(stage2final,columns=['Depot','Invoice_No_total','Invoice_Amt_total','Weighted_avg_DSO','Invoice_No_crossed_TAT','%Invoices_crossTAT','Invoice_Amt_crossed_TAT','Weighted_avg_DSO_crossedTAT','Avg_delay_days_crossedTAT'])

stage2final_hd = pd.DataFrame(stage2final_hd,columns=['Depot','Invoice_No_total','Invoice_Amt_total','Weighted_avg_DSO','Invoice_No_crossed_TAT','%Invoices_crossTAT','Invoice_Amt_crossed_TAT','Weighted_avg_DSO_crossedTAT','Avg_delay_days_crossedTAT'])
stage2final_dd = pd.DataFrame(stage2final_dd,columns=['Depot','Invoice_No_total','Invoice_Amt_total','Weighted_avg_DSO','Invoice_No_crossed_TAT','%Invoices_crossTAT','Invoice_Amt_crossed_TAT','Weighted_avg_DSO_crossedTAT','Avg_delay_days_crossedTAT'])

stage3final = pd.DataFrame(stage3final,columns=['Depot','Invoice_No_total','Invoice_Amt_total','Weighted_avg_DSO','Invoice_No_crossed_TAT','%Invoices_crossTAT','Invoice_Amt_crossed_TAT','Weighted_avg_DSO_crossedTAT','Avg_delay_days_crossedTAT'])


## Invoice data for FTP

def diffdate_others(date1,date2):
    #passdate = fullinvoicedata['InvoiceDate'].values[0]
    a1 = pd.to_datetime(str(date1)).replace(tzinfo=None)
    diffdays = int((date2-a1).days)
    return diffdays

stage2df['Stage2_1_diff'] =  stage2df.apply(lambda x : diffdate_others(x['Invoice_Date'],x['HO_Despatch_Date']),axis=1)
stage3df['Stage3_1_diff'] =  stage3df.apply(lambda x : diffdate_others(x['Invoice_Date'],x['HO_Despatch_Date']),axis=1)
stage3df['Stage3_2_diff'] =  stage3df.apply(lambda x : diffdate_others(x['HO_Despatch_Date'],x['Submission_to_the_Customer_Date']),axis=1)


stage2df['TAT_1_2'] = stage2df.apply(lambda x:tatstage1(x['Category']),axis=1)
stage3df['TAT_1_3'] = stage3df.apply(lambda x:tatstage1(x['Category']),axis=1)
stage3df.loc[stage3df.index,'TAT_2_3'] = 5


stage1df.loc[stage1df.index,'Disptached'] = 'No'
stage1df.loc[stage1df.index,'Submitted'] = 'No'
stage1df.loc[stage1df.index,'Collected'] = 'No'

stage2df.loc[stage2df.index,'Disptached'] = 'Yes'
stage2df.loc[stage2df.index,'Submitted'] = 'No'
stage2df.loc[stage2df.index,'Collected'] = 'No'

stage3df.loc[stage3df.index,'Disptached'] = 'Yes'
stage3df.loc[stage3df.index,'Submitted'] = 'Yes'
stage3df.loc[stage3df.index,'Collected'] = 'No'

stage1df['Disptached_crossedTAT'] = stage1df.apply(lambda x:x['Crossed_TAT'],axis=1)
stage2df['Submitted_crossedTAT'] = stage2df.apply(lambda x:x['Crossed_TAT'],axis=1)
stage3df['Collected_crossedTAT'] = stage3df.apply(lambda x:x['Crossed_TAT'],axis=1)

stage2df['Disptached_crossedTAT'] = stage2df.apply(lambda x :crosstat(x['TAT_1_2'],x['Stage2_1_diff']),axis=1)
stage3df['Disptached_crossedTAT'] = stage3df.apply(lambda x :crosstat(x['TAT_1_3'],x['Stage3_1_diff']),axis=1)
stage3df['Submitted_crossedTAT'] = stage3df.apply(lambda x :crosstat(x['TAT_2_3'],x['Stage3_2_diff']),axis=1)


stage1df.loc[stage1df.index,'Stage'] = 'Invoiced_but_not_dispatched'
stage2df.loc[stage2df.index,'Stage'] = 'Dispatched_but_not_submitted'
stage3df.loc[stage3df.index,'Stage'] = 'Submitted_but_not_collected'

stage12df = stage1df.append(stage2df,ignore_index=True)
allstagedf = stage12df.append(stage3df,ignore_index=True)

allstagedf = allstagedf.rename(columns={'Physically_Received_by_Authorized_Customer_Y_N':'Date_Of_Confirmation_Y_N'})

allstagedf = pd.DataFrame(allstagedf,columns=['Region','Depot','Invoice_No','Invoice_Date','InvoiceMonth','Invoice_Amt','Type_of_Invoice','DespatchType','Account_Code','Account_Name','Account_Type','POD_NPOD','Category','Customer_Agreed_Perc','POD_Available_Perc','CC_Name','Despatched_From_HO','HO_Despatch_Date','Reason_for_Not_Despatching_from_HO','Courier_No','Courier_Name','Delivery_Date_Update','Delivery_Status_Remarks','Billing_Co_ordinator_HandOver_Date','Submission_to_the_Customer_Date','Date_Of_Confirmation_Y_N','Date_Of_Confirmation','Date_Of_Acceptance','Equery_No','PIS_No','PIS_Date','PIS_Amount','Latest_Record_Communication','Dunning_Letter_1','Dunning_Letter_2','Dunning_Letter_3','CreditPeriod','Stage','Disptached','Disptached_crossedTAT','Submitted','Submitted_crossedTAT','Collected','Collected_crossedTAT','Invoice_POD_Available'])
allstagedf['Invoice_POD_Available'].fillna('-',inplace=True)


todaydate = date.today() 
allstagedf.to_csv(r'D:\Data\Invoice_tracker\Invoice_data\Invoice_data_'+str(todaydate)+'.csv')
allstagedf.to_csv(r'D:\Data\Invoice_tracker\Invoice_data.csv')

oppath_invoice = r'D:\Data\Invoice_tracker\Invoice_data.csv'


print ('Logging in...')
ftp = ftplib.FTP()
#ftp.connect('119.226.230.94')
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppath_invoice
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()
## Invoice data for FTP

## For trendline of invoices
stage1final_trend = pd.DataFrame(stage1final,columns=['Category','Invoice_No_crossed_TAT','%Invoices_crossTAT'])
stage1final_trend.loc[stage1final_trend.index,'Date'] = todaydate
stage1final_trend.to_csv(r'D:\Data\Invoice_tracker\Trendlines\Invoiced_not_dispatched\Invoiced_not_dispatched_trend_'+str(todaydate)+'.csv')

path =r'D:\Data\Invoice_tracker\Trendlines\Invoiced_not_dispatched' # use your path

allFiles = glob.glob(path + "/*.csv")
frame = pd.DataFrame()
list_ = []
for file_ in allFiles:
    df = pd.read_csv(file_,index_col=None, header=0)
    list_.append(df)
frame = pd.concat(list_)

frame = pd.DataFrame(frame,columns=['Date','Category','Invoice_No_crossed_TAT','%Invoices_crossTAT'])

def datetimefunc(date):
    try:
        datenumber = (datetime.strptime(date,'%d-%m-%Y')).date()
    except:
        datenumber = (datetime.strptime(date,'%Y-%m-%d')).date()
    return datenumber
    
frame['Date'] = frame.apply(lambda x:datetimefunc(x['Date']),axis=1)

frame.to_csv(r'D:\Data\Invoice_tracker\Trendlines\Invoiced_not_dispatched_trend.csv')
## For trendline of invoices

## For trendline of Delivered to CC but not submitted to Customer
stage2final_trend_hd = pd.DataFrame(stage2final_hd,columns=['Depot','Invoice_No_crossed_TAT','%Invoices_crossTAT'])
stage2final_trend_hd.loc[stage2final_trend_hd.index,'Date'] = todaydate
stage2final_trend_hd.to_csv(r'D:\Data\Invoice_tracker\Trendlines\CC_not_submitted\CC_not_submitted_'+str(todaydate)+'.csv')

path_not_submitted =r'D:\Data\Invoice_tracker\Trendlines\CC_not_submitted' # use your path

allFiles = glob.glob(path_not_submitted + "/*.csv")
frame_not_submitted = pd.DataFrame()
list_ = []
for file_ in allFiles:
    df = pd.read_csv(file_,index_col=None, header=0)
    list_.append(df)
frame_not_submitted = pd.concat(list_)

frame_not_submitted = pd.DataFrame(frame_not_submitted,columns=['Date','Depot','Invoice_No_crossed_TAT','%Invoices_crossTAT'])
    
frame_not_submitted['Date'] = frame_not_submitted.apply(lambda x:datetimefunc(x['Date']),axis=1)

frame_not_submitted.to_csv(r'D:\Data\Invoice_tracker\Trendlines\CC_not_submitted_trend.csv')
## For trendline of Delivered to CC but not submitted to Customer

## For trendline of Delivered to Cusomter but not confirmed by CC
stage2final_trend_dd = pd.DataFrame(stage2final_dd,columns=['Depot','Invoice_No_crossed_TAT','%Invoices_crossTAT'])
stage2final_trend_dd.loc[stage2final_trend_dd.index,'Date'] = todaydate
stage2final_trend_dd.to_csv(r'D:\Data\Invoice_tracker\Trendlines\CC_not_confirmed\CC_not_confirmed_'+str(todaydate)+'.csv')

path_not_confimed =r'D:\Data\Invoice_tracker\Trendlines\CC_not_confirmed' # use your path

allFiles = glob.glob(path_not_confimed + "/*.csv")
frame_not_confirmed = pd.DataFrame()
list_ = []
for file_ in allFiles:
    df = pd.read_csv(file_,index_col=None, header=0)
    list_.append(df)
frame_not_confirmed = pd.concat(list_)

frame_not_confirmed = pd.DataFrame(frame_not_confirmed,columns=['Date','Depot','Invoice_No_crossed_TAT','%Invoices_crossTAT'])
    
frame_not_confirmed['Date'] = frame_not_confirmed.apply(lambda x:datetimefunc(x['Date']),axis=1)

frame_not_confirmed.to_csv(r'D:\Data\Invoice_tracker\Trendlines\CC_not_confirmed_trend.csv')
## For trendline of Delivered to Cusomter but not confirmed by CC




with ExcelWriter(r'D:\Data\Invoice_tracker\Invoice_tracker_summary\Invoice_tracker_summary_'+str(todaydate)+'.xlsx') as writer:
    stage1final.to_excel(writer, sheet_name='Invoiced_not_dispatched',engine='xlsxwriter')
    #stage2final.to_excel(writer, sheet_name='Dispatched_not_submitted',engine='xlsxwriter')
    stage2final_hd.to_excel(writer, sheet_name='Delv_CC_not_submitted',engine='xlsxwriter')
    stage2final_dd.to_excel(writer, sheet_name='Delv_Cust_not_confirmed_by_CC',engine='xlsxwriter')
    frame.to_excel(writer, sheet_name='Invoices_not_dispatched_Trend',engine='xlsxwriter')
    frame_not_submitted.to_excel(writer, sheet_name='CC_not_submitted_trend',engine='xlsxwriter')
    frame_not_confirmed.to_excel(writer, sheet_name='CC_not_confirmed_trend',engine='xlsxwriter')

#### For variables to publish on the email body
invoices_not_dispatched = stage1final['Invoice_No_total'].sum()
invoices_not_dispatched_crossedTAT = stage1final['Invoice_No_crossed_TAT'].sum()

invoices_not_dispatched_pod_avail = stage1final['Invoice_POD_Available_total'].sum()
invoices_not_dispatched_crossedTAT_pod_avail = stage1final['Invoice_POD_Available_crossed_TAT'].sum()

disatched_not_submitted_hd = stage2final_hd['Invoice_No_total'].sum()
disatched_not_submitted_crossedTAT_hd = stage2final_hd['Invoice_No_crossed_TAT'].sum()
disatched_not_submitted_dd = stage2final_dd['Invoice_No_total'].sum()
disatched_not_submitted_crossedTAT_dd = stage2final_dd['Invoice_No_crossed_TAT'].sum()
submitted_not_collected = stage3final['Invoice_No_total'].sum()
submitted_not_collected_crossedTAT = stage3final['Invoice_No_crossed_TAT'].sum()
#### For variables to publish on the email body

# In[40]:

oppath1 = r'D:\Data\Invoice_tracker\Invoice_tracker_summary\Invoice_tracker_summary_'+str(todaydate)+'.xlsx'


# In[42]:


filePath = oppath1
def sendEmail(TO = ["Manzil.Bhattacharya@Spoton.Co.In","sanath.j@spoton.co.in"],
              #TO = ["vishwas.j@spoton.co.in"],
              #CC = ["vishwas.j@spoton.co.in"],
              CC = ["krishna.chandrasekar@spoton.co.in","abhik.mitra@spoton.co.in","rajeesh.vr@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "Invoice Tracker Summary" + ' - ' + str(todaydate)
    body_text = """
    Dear All,
    
    PFA the Invoice Tracker Summary as of """+str(todaydate)+"""
    
    Invoices not dispatced :
    Invoices = """+str(invoices_not_dispatched)+"""
    Invoices crossed TAT = """+str(invoices_not_dispatched_crossedTAT)+"""
    
    Invoices not dispatced where % POD available :
    Invoices  = """+str(invoices_not_dispatched_pod_avail)+"""
    Invoices crossed TAT = """+str(invoices_not_dispatched_crossedTAT_pod_avail)+"""
    
    Invoices delivered to Customers (Direct Dispatch) but not confirmed by CCs :
    Invoices = """+str(disatched_not_submitted_dd)+"""
    Invoices crossed TAT = """+str(disatched_not_submitted_crossedTAT_dd)+"""
    
    Invoices delivered to CCs but not submitted to customer :
    Invoices = """+str(disatched_not_submitted_hd)+"""
    Invoices crossed TAT = """+str(disatched_not_submitted_crossedTAT_hd)+"""
    
    The report contains the following sheets:
    1) Invoiced_not_dispatched - Summary of all invoices not dispatched
    2) Delv_CC_not_submitted - Summary of invoices which is delivered to CC but not submitted to customer
    3) Delv_Cust_not_confirmed_by_CC - Summary of invoices which is delivered to Customer but not confirmed by CC
    4) Invoices_not_dispatched_Trend - Trend of Invoices not dispatched day-wise and category-wise
    5) CC_not_submitted_trend - Trend of Invoices which CCs not submitted day-wise and Depot-wise
    6) CC_not_confirmed_trend - Trend of Invoices delivered to customers but not confirmed by CCs day-wise and Depot-wise
    
    
    For the invoice level base data, please use the link below
    
    http://spoton.co.in//downloads/IEProjects/ETA/Invoice_data.csv
    
    """ 

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')


# In[ ]:



