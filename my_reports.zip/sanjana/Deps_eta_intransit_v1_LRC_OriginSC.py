
# coding: utf-8

# In[1]:

import pandas as pd
import numpy as np
import datetime
from datetime import date, timedelta
import glob
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import os
import sys
from email import encoders
reload(sys)
sys.setdefaultencoding("UTF8")

"""
def save_xls(list_dfs, name_dfs, xls_path):
   i = 0
   writer = ExcelWriter(xls_path)   
   for dataframe in list_dfs:
       sheetname = name_dfs[i]
       dataframe.to_excel(writer, sheetname, merge_cells = False)
       i = i+1
   writer.save()
"""

path =r'D:\Data\eta_rank\origin_eta_folder_rankfiles' # use your path
allFiles = glob.glob(path + "/*.csv")
frame = pd.DataFrame()
list_ = []
for file_ in allFiles:
    df = pd.read_csv(file_,index_col=None, header=0)
    list_.append(df)
frame = pd.concat(list_)
frame.to_csv(r'D:\Data\eta_rank\origin_eta_folder_rankfiles\OP\Combined_for_eta_OriginSC.csv')

# In[2]:

cons = pd.read_csv(r'D:\Data\eta_rank\origin_eta_folder_rankfiles\OP\Combined_for_eta_OriginSC.csv')

## Vishwas Edit 13/02/2016
paperworkslist = ['HIP','SRH']
def paperworks(latestconstatus):
    if latestconstatus in paperworkslist:
        return 1
    else:
        return 0

cons['Paperworks'] = cons.apply(lambda x:paperworks(x['LastConStatusCode']),axis=1)

## Vishwas Edit 13/02/2016
cons = cons.rename(columns={'\xef\xbb\xbfDOCKNO_x':'Con Number_x'})
cons.columns.tolist()

# In[3]:

#a=datetime.datetime.strptime('07/10/2015','%d/%m/%Y')
#b=datetime.datetime.strptime('09/10/2015','%d/%m/%Y')
a = datetime.datetime.now()
b = a - timedelta(hours=24)

# In[4]:

conspivot = pd.pivot_table(cons, index = ['Con Number_x','ORGBRCD','Delaydays','ActionHrs','TimeStamp'], values = ['Rank'], aggfunc = 'count').reset_index()
conspivot.columns = ['Con_No','Location','Delaydays','AH','Ts','Rank']


# In[5]:

conspivot['Ts2'] = conspivot['Ts'].apply(lambda x: datetime.datetime.strptime(x,'%m/%d/%Y %H:%M:%S %p'))
conspivot = conspivot[conspivot['Ts2']<a]
conspivot = conspivot[conspivot['Ts2']>b]
conspivot['Ts2'].values[0]


# In[6]:

ix2 = conspivot[conspivot['Delaydays']>0].index
condelayspivot = conspivot.loc[ix2]
condelays = pd.pivot_table(condelayspivot, index = ['Con_No','Delaydays'], values = 'Ts2', aggfunc = 'max').reset_index()
delaygraph = pd.merge(condelays,condelayspivot,left_on = ['Con_No','Delaydays','Ts2'], right_on = ['Con_No','Delaydays','Ts2'], how = 'inner')



# In[24]:



#@ list
#@ clean delaygraph dataframe 

# In[25]:
#@ change to groupby

lowdepspivot = delaygraph.groupby(['Con_No','Location']).agg({'Delaydays':'count'}).reset_index()

#####$$$$$$depspivot=pd.pivot_table(mergedeps,index= ['DOCKNO','Location'],values=['Delaydays'],aggfunc='count').reset_index()

#@ change to groupby Repeat for clean dd

lowdepspivot=lowdepspivot.rename(columns={'Delaydays':'Count of Slips'})
lowdepspivotmt1 = lowdepspivot[lowdepspivot['Count of Slips']>1].sort_values('Count of Slips',ascending=False)
lowdepspivotmt2 = lowdepspivotmt1.sort_values(['Count of Slips','Location'],ascending=[False,True])
##rajeesh edit
lowriskcon_tspivot = pd.pivot_table(cons, index = ['Con Number_x'], values = ['TimeStamp'], aggfunc = 'max').reset_index()
lowcontsdepsscore = pd.merge(lowdepspivotmt2,lowriskcon_tspivot,left_on=['Con_No'],right_on=['Con Number_x'], how = 'inner')
lowriskbasedata = pd.merge(cons,lowcontsdepsscore,left_on=['Con Number_x', 'TimeStamp'],right_on=['Con_No','TimeStamp'], how = 'inner')
columnsop=['Con_No','BOOKINGDATE','BOOKINGENTRYDATE','Location','DUEDATE','CUSTOMERCODE','CUSTOMERNAME','ORGBRCD','DLVBRCD','LastConStatusCode','LastConStatusDesc','LatStatusBranch','LatConStatusCategory','PIECES','VOLUME','Count of Slips','Paperworks','TimeStamp','ORGAREA','DLVAREA']
lowriskbasedatareqcols=pd.DataFrame(lowriskbasedata,columns=columnsop)
#lowriskbasedatareqcols=lowriskbasedata


##For Getting slips branch wise to paste in mail body

## lowdepspivotmt2grpby1 Changed from slips to count of paperwork cons
lowdepspivotmt2grpby1 = lowriskbasedatareqcols.groupby(['Location']).agg({'Paperworks':sum}).reset_index()
ppwkcons = lowdepspivotmt2grpby1['Paperworks'].sum()
## lowdepspivotmt2grpby1 Changed from slips to count of paperwork cons

lowdepspivotmt2grpby2 = lowdepspivotmt2.groupby(['Location']).agg({'Con_No':'count'}).reset_index()
lowdepspivotmt2grpbytop20 = lowdepspivotmt2grpby2.sort_values('Con_No',ascending=False).head(20)

lowdepspivotmt2grpbymergemail = pd.merge(lowdepspivotmt2grpby1,lowdepspivotmt2grpbytop20,on='Location',how='inner')
#lowdepspivotmt2grpbymergepivotmail = pd.pivot_table(lowdepspivotmt2grpbymergemail,index=["Location"],columns=["Count of Slips"],values=["Con_No"],aggfunc = sum,fill_value=0,margins=True)

lowdepspivotmt2grpbymerge = pd.merge(lowdepspivotmt2grpby1,lowdepspivotmt2grpby2,on='Location',how='outer')
#lowdepspivotmt2grpbymergepivot = pd.pivot_table(lowdepspivotmt2grpbymerge,index=["Location"],columns=["Count of Slips"],values=["Con_No"],aggfunc = sum,fill_value=0,margins=True)

##For Getting slips branch wise to paste in mail body

##rajeesh edit
#depslocpivot=pd.pivot_table(mergedeps,index= ['Location'],values=['Delaydays','DOCKNO'],aggfunc='count').reset_index()
#depslocpivot1=depslocpivot[depslocpivot['Delaydays']>1].sort_values('Delaydays',ascending=False)


ts= datetime.datetime.now()
opfilevar=ts.date()
opfilevar1=ts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=np.ceil(float(currhrs)/60)
lowriskbasedata.columns.tolist()

# In[28]:
oppath2=r'D:\Data\eta_rank\origin_eta_folder_rankfiles\OP\Origin_SC_Slips'+'-'+str(opfilevar)+'-'+str(opfilevar2)+'.xlsx'

#mergepivot.to_csv(r'C:\Data\DEPS_Pred_061015\High_risk_DEPS_DESTSC_Pivot.csv',encoding='utf-8')
"""
printlist =  [depspivotmt2,depslocpivot1,basedatareqcols]
namelist = ['Data','Summary','BaseData']
save_xls (printlist, namelist, oppath1)
"""


othercons = len(lowdepspivotmt2)


with ExcelWriter(r'D:\Data\eta_rank\origin_eta_folder_rankfiles\OP\Origin_SC_Slips'+'-'+str(opfilevar)+'-'+str(opfilevar2)+'.xlsx') as writer:
    lowdepspivotmt2grpbymerge.to_excel(writer, sheet_name='Combined',engine='xlsxwriter')
    lowdepspivotmt2.to_excel(writer, sheet_name='Data_Others',engine='xlsxwriter')
    lowriskbasedatareqcols.to_excel(writer, sheet_name='BaseData_Others',engine='xlsxwriter')
    #lowdepspivotmt2grpbymergepivot.to_excel(writer, sheet_name='Pivot',engine='xlsxwriter')
    
    
#lowdepspivotmt2grpbymergepivot.to_csv(r'D:\Data\eta_rank\origin_eta_folder_rankfiles\Branchwise_slips_origin\Origin_Stock_Slips'+'-'+str(opfilevar)+'-'+str(opfilevar2)+'.csv')

oppath1 = r'D:\Data\eta_rank\origin_eta_folder_rankfiles\Branchwise_slips_origin\Origin_Stock_Slips'+'-'+str(opfilevar)+'-'+str(opfilevar2)+'.csv'
filePath = oppath2
def sendEmail(TO = ["pawan.sharma@spoton.co.in","aom_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in"],
             #TO = ["rajeesh.vr@spoton.co.in"],
             #CC = ["vishwas.j@spoton.co.in"],
             #TO = ["vishwas.j@spoton.co.in"],
             CC = ["sqtf@spoton.co.in","rajeesh.vr@spoton.co.in","mahesh.reddy@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "Origin SC ETA Slips" + " - " + str(opfilevar)+ " - " +str(opfilevar2)
    msg["Subject"] = "Origin SC ETA Slips" + " - " + str(opfilevar)+ " - " +str(opfilevar2)
    body_text = """
    
    Dear All,

    This report shows the cons which got delayed multiple (ETA Slips) times at a origin.
    The attachment contains the details of the cons and their respective locations which caused the delays
    
    No of cons slipped ETA @ origin = """+str(othercons)+"""
    Paperwork Issue cons = """+str(ppwkcons)+"""
    

    PFB the TOP 20 location wise slips

    """+str(lowdepspivotmt2grpbymergemail)+"""

    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')

