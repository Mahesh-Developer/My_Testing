
# coding: utf-8

# In[ ]:


import pandas as pd
import numpy as np
from pymongo import MongoClient
from string import Template
import smtplib
import os
from datetime import datetime, timedelta
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import smtplib
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os


# In[ ]:


client = MongoClient('mongodb://localhost:27017/')
#path_schedule_master_may_30
db = client['path_schedule_master_May11_19']


# In[ ]:


loading = 1*90 
unloading = 1*90
virtualmovement = 3*60
# odadays = 2*24*60


# In[ ]:


htrlink = 'http://spoton.co.in/downloads/HTR_1HR/HTR_1HR.xls'
combs_df = pd.read_excel(htrlink)
print ('inv',len(combs_df))
# combs_df=combs_df[combs_df['Con Number']==517935069]
totalcons=len(combs_df)
# In[ ]:


#combs_df=combs_df.rename(columns={'Con Number':'DOCKNO'}).set_index('DOCKNO')
combs_df.rename(columns={'Hub SC Location': 'Location','Destn Branch': 'Destination','Origin Branch': 'Origin','Act Wt In Tonnes': 'Wt','Del Location Type': 'DestType','TIMESTAMP': 'Ts','Arrival Date Hub':'ArrTs','Due Date': 'DueDate','Next Frwd Loc': 'nextloc'},inplace=True)


# In[ ]:


intransitdf=pd.read_excel(r'http://spoton.co.in/downloads/TCR_UND_2HRS/TCR_UND_ISDEPART_YES_2HRS.xls')


# In[ ]:


mergedf = pd.merge(combs_df,intransitdf,left_on=['Con Number'], right_on=['DOCKNO'], how='inner')
combs_df=combs_df[~combs_df['Con Number'].isin(mergedf['Con Number'])]
len(combs_df)


# In[ ]:


combs_df=combs_df[combs_df['Destn Depot']!='UCGD']
len(combs_df)


# In[ ]:


combs_df = combs_df[combs_df['Location']!=combs_df['Destination']]
len(combs_df)


# In[ ]:


depspaperworkcodelist = ['SRE','SRD','SRS','SRP','DLP','SWP','PWS','HCM','HPM','MOP','SRH','HOC','ONR','SPH','SPO','DBO','DIP','SHS','SSC','HIP','RNX','APT','APN','SHD','SMT','SPL','MSH','UCG','RRA','HPE','WIA','UG1','UG2','UG3','HMP','HWC','NPE','HIM']
combs_df = combs_df[~combs_df['Latest Status Code'].isin(depspaperworkcodelist)]
len(combs_df)

aftremdeps=len(combs_df)
aftremdeps
# In[ ]:


# combs_df=combs_df[combs_df['Booking Date']>='2019-02-07']
# len(combs_df)


# In[ ]:


def oldcon(arrv):
    if arrv< combs_df['Ts'][0]-timedelta(days=30):
        return 'Old'
    else:
        return 'New'


# In[ ]:


combs_df['Obsev_1']=combs_df.apply(lambda x: oldcon(x['Booking Date']),axis=1)
print (combs_df)

# In[ ]:


htr=combs_df[combs_df['Obsev_1']=='New']
len(htr)


# In[ ]:


htr['ArrTs']=pd.to_datetime(htr['ArrTs'])
htr['DueDate']=pd.to_datetime(htr['DueDate'])
#htr['Booking Date']=pd.to_datetime(htr['Booking Date'])
#htr['Ts']=pd.to_datetime(htr['Ts'])


# In[ ]:


htr['Ts']=pd.to_datetime(htr['Ts'])


# In[ ]:


# loading = 1*90 
# unloading = 1*60
virtualmovement = 3*60
htr['Td'] = (htr.Ts-htr.ArrTs)/np.timedelta64(1,'h')
### this is an adjustment to the current time in case the con has arrived less than 3 hours prior to the current time
htr['AdjTS'] = [arr + np.timedelta64(loading,'m') if td*60<=loading else ts for td,arr,ts in zip(htr.Td,htr.ArrTs,htr.Ts)] #con reflects in inventory only once unloading complete, but htr has this veh accepted load as well #corrected1
htr['DueDate2'] = htr.DueDate+np.timedelta64(12*60,'m')
# htr['AdjDueDate'] = [dd if dest=='STD' else dd-np.timedelta64(odadays,'m') for dd,dest in zip(htr.DueDate2,htr.DestType)]  #why, we should infact be using up the 1 day of 3 to delay such cons? - can only allow max 2 days transit / consolidations
# ODA Transit Day
htr['AdjDueDate'] = [dd if dest=='STD' else dd-np.timedelta64(odadays,'m') for dd,dest,odadays in zip(htr.DueDate2,htr.DestType,htr['ODA Transit Day'])]
currdt = np.datetime64(str(htr.Ts.unique()[0]).split('T')[0]+' 00:00:00','ms')


# In[ ]:


combs_df=htr


# In[ ]:


# combs_df=combs_df[~(combs_df['Location'].isin(['DBLR','DPNQ','DHYD','DCCU','BLRC','BLRX','SUCG','EUCG','NUCG','WUCG','CCUD']))]
# combs_df=combs_df[~(combs_df['Destination'].isin(['DBLR','DPNQ','DHYD','DCCU','BLRC','BLRX','SUCG','EUCG','NUCG','WUCG','CCUD']))]
combs_df=combs_df.replace("MNSB ","MNSB")
#combs_df['Depttime']=pd.to_datetime(combs_df['Depttime'])


# In[ ]:


len(combs_df)


# In[ ]:


errordict = {}
def geteta(origin,destination,currts):
    #print (origin,destination,currts)
    #print (type(currts))
    #print (currts)
    global virtualmovement, loading, unloading, errordict
    currdt = np.datetime64(str(currts).split('T')[0]+' 00:00:00','ms')
    schdict = db.master.find_one({'origin': origin,'destination': destination})
    retdict = {}
    if schdict:
        schedules = schdict['legdata']
        #print ('schedules',schedules,len(schedules))
        path = schdict['conpath']
        #print ('path',path)
        journeydict = {}
        for legno in range(1,len(schedules)+1):
            step=schedules.get(str(legno))
            journeydict[(step[0],step[1])] = []
            options = step[2]
            if options:
                try:
                    transithours = [np.timedelta64(int((option[0]).split(':')[1])+60*int((option[0]).split(':')[0]),'m') for option in options] #this is actually mins from day beginning
                    convertedoptions = currdt+transithours
                    #convertedoptionsbool = [option for option in convertedoptions if option>=currts+np.timedelta64(loading,'m')]
                    convertedoptions = [option if option>=currts+np.timedelta64(loading,'m') else option+np.timedelta64(24*60,'m') for option in convertedoptions  ]
                    convertedoptionsbool = [option if option>=currts+np.timedelta64(loading,'m') else option+np.timedelta64(24*60,'m') for option in convertedoptions  ]

                    
                    if not convertedoptionsbool:
                        convertedoptions = np.timedelta64(24*60,'m') + convertedoptions
                    convertedoptionsbool = [option for option in convertedoptions if option>=currts+np.timedelta64(loading,'m')]
                    if not convertedoptionsbool:
                        convertedoptions = np.timedelta64(24*60,'m') + convertedoptions #two steps needed since for 12:30am etc it is still beyond loading time
                    timeoptions = [(conv,conv+np.timedelta64(int(opt[1])*60,'m')+np.timedelta64(unloading,'m')) for opt,conv in zip(options,convertedoptions) if conv>=currts+np.timedelta64(loading,'m')] #+np.timedelta64(loading,'m') - cnt add loading
                    try:
                        optimaloption = sorted(timeoptions, key=lambda x: x[1])[0]
                    except:
                        print (convertedoptionsbool,convertedoptions,timeoptions)
                    journeydict[(step[0],step[1])] = optimaloption
                    arrtime = optimaloption[1]
                except:
                    retdict['path'] = path
                    retdict['journey'] = {'error': options}
                    errordict[(step[0],step[1])] = 'error in time of schedule'
                    return retdict
                    
            else:
                deptime = currts
                arrtime = currts+np.timedelta64(virtualmovement,'m')
                journeydict[(step[0],step[1])] = (deptime,arrtime)
            currts = arrtime
            currdt = np.datetime64(str(currts).split('T')[0]+' 00:00:00','ms')
        retdict['path'] = path
        retdict['journey'] = journeydict
        journeytimes = journeydict.values()
        try:
            eta = sorted(journeytimes, key=lambda x: x[1], reverse=True)[0][1]
            retdict['eta'] = eta
        except:
            print ('retdict',retdict)
        #print ('retdict',retdict)
        return retdict
    else:
        print (schdict, origin, destination)
        errordict[(origin,destination)] = 'no path'
        return False


# In[ ]:


inventory=combs_df


# In[ ]:


#inventory['journeydict'] = [geteta(loc,dest,ts) for loc,dest,ts in zip(inventory.currloc.values,inventory.dest.values,inventory.Depttime.values)]
inventory['journeydict'] = [geteta(loc,dest,ts) for loc,dest,ts in zip(inventory.Location.values,inventory.Destination.values,inventory.Ts.values)]
#inventory['journeydict'] = [geteta(loc,dest,ts) for loc,dest,ts in zip(inventory.Location.values,inventory.Destination.values,inventory.Ts.values)]
path_false=inventory[inventory['journeydict']==False]
print (len(path_false))
# path_false.to_csv(r'C:\Users\rajeeshv\Downloads\No_Schedule.csv')
# In[ ]:


# inventory1=inventory[(inventory['currloc']=='VIKL') & (inventory['dest']=='MHPF')]
inventory1=inventory


# In[ ]:


len(inventory1)


# In[ ]:


inventory['path'] = [i.get('path') if i else i for i in inventory.journeydict.values]
inventory['eta'] = [i.get('eta') if i else i for i in inventory.journeydict.values]


# In[ ]:


inventory=inventory[inventory['eta']!=False]


inventory['nextloc']=inventory['path'].apply(lambda x: x[1])

len(inventory)


# In[ ]:


inventory['eta']=pd.to_datetime(inventory['eta'])


# In[ ]:


inventory['neweta']=inventory['eta'].apply(lambda x: x+timedelta(days=1) if x.hour>12 else x)
inventory['neweta']=inventory['neweta'].apply(lambda x: str(x).split(' ')[0])
# tcr['CDELDT']=tcr['CDELDT'].dt.date
# tcr['CDELDT']=tcr['CDELDT'].astype(str)

inventory['neweta']=pd.to_datetime(inventory['neweta'])


# In[ ]:


inventory['ETA_Slip']=[0 if eta>duedate else 1 for eta,duedate in zip(inventory['neweta'],inventory['AdjDueDate'])]
inventory['Days_Diff']=inventory['neweta']-inventory['AdjDueDate']
inventory['Days']=inventory['Days_Diff'].apply(lambda x:int(str(x).split(' ')[0]))

# In[ ]:


len(inventory[inventory['ETA_Slip']==1])

grt2days=len(inventory[inventory['Days']>=2])
grt2days
eta_slped_consdf=inventory[inventory['ETA_Slip']==0]
eta_slped_cons=len(inventory[inventory['ETA_Slip']==0])
eta_slped_cons
# In[ ]:


reached_cons=len(inventory[inventory['ETA_Slip']==1])
reached_cons


# In[ ]:


perce=pd.np.round(reached_cons*100.0/len(inventory),1)
perce


# In[ ]:


todate=datetime.strftime(datetime.now(),'%Y-%m-%d %H')
todate


# In[ ]:


def diffhr(curtime,arrvtime):
    diff=curtime-arrvtime
    return pd.np.round(diff.total_seconds()/3600,1)


# In[ ]:


inventory['pu_diff']=inventory.apply(lambda x:diffhr(x['Ts'],x['Booking Date']),axis=1)


# In[ ]:


avghraftpkp=pd.np.ceil(inventory['pu_diff'].sum()*1.0/len(inventory))
avghraftpkp


# In[ ]:


inventory['due_diff']=inventory.apply(lambda x:diffhr(x['DueDate'],x['Ts']),axis=1)


# In[ ]:


avghrduedt=pd.np.ceil(inventory['due_diff'].sum()*1.0/len(inventory))
avghrduedt


# In[ ]:


urgent_cons=inventory[inventory['ETA_Slip']==0]
len(urgent_cons)


# In[ ]:


urgnt_perc=pd.np.round(len(urgent_cons)*100.0/len(inventory),1)
urgnt_perc


# In[ ]:


# inventory=inventory.reset_index()


# In[ ]:


# inventory.dtypes


# In[ ]:


inventory['Time_diff']=inventory.apply(lambda x:diffhr(x['Ts'],x['ArrTs']),axis=1)


mail_summary=inventory.pivot_table(index=['Location','nextloc'],values=['Wt','Con Number','ETA_Slip'],
                     aggfunc={'Con Number':len,'Wt':sum,'ETA_Slip':sum}).reset_index()

mail_summary['Failed_Cons']=mail_summary['Con Number']-mail_summary['ETA_Slip']
mail_summary['Failed%']=pd.np.round(mail_summary['Failed_Cons']*100.0/mail_summary['Con Number'],0)
mail_summary['Wt']=pd.np.round(mail_summary['Wt'],1)
mail_summary.sort_values('Failed_Cons',ascending=False,inplace=True)

mail_summary1=mail_summary[['Location','nextloc','Con Number','Failed_Cons','Failed%','Wt']]
summary=inventory.pivot_table(index=['Location','nextloc'],values=['Wt','Con Number','ETA_Slip','Time_diff'],
                     aggfunc={'Con Number':len,'Wt':sum,'ETA_Slip':sum,'Time_diff':sum}).reset_index().sort_values('Wt',ascending=False)


# In[ ]:


summary['WtTimeDiff']=pd.np.round(summary['Time_diff']/summary['Con Number'],1)
summary.head()


# In[ ]:


summary['Reach%']=pd.np.round(summary['ETA_Slip']*100.0/summary['Con Number'],1)


# In[ ]:


summary['Wt']=pd.np.round(summary['Wt'],1)


# In[ ]:


summary.rename(columns={'Location':'CurrLoc','Wt':'wt(T)','Con Number':'Con'},inplace=True)


# In[ ]:


summary1=summary[['CurrLoc','nextloc','wt(T)','Con','Reach%','WtTimeDiff']]

failedsummary=inventory[inventory['ETA_Slip']==0].pivot_table(index=['Location','nextloc'],values=['Wt','Con Number','ETA_Slip','Time_diff'],
                     aggfunc={'Con Number':len,'Wt':sum,'ETA_Slip':sum,'Time_diff':sum}).reset_index().sort_values('Wt',ascending=False)
failedsummary['WtTimeDiff']=pd.np.round(failedsummary['Time_diff']/failedsummary['Con Number'],1)
failedsummary['Reach%']=pd.np.round(failedsummary['ETA_Slip']*100.0/failedsummary['Con Number'],1)
failedsummary['Wt']=pd.np.round(failedsummary['Wt'],1)
failedsummary.rename(columns={'Location':'CurrLoc','Wt':'wt(T)','Con Number':'Con'},inplace=True)
failedsummary1=failedsummary[['CurrLoc','nextloc','wt(T)','Con','WtTimeDiff']]
failedsummary1.head()



# inventory.to_csv(r'D:\Data\Sector_BuildUP\inventory'+str(todate)+'.csv',encoding='cp1252')
# summary.to_csv(r'D:\Data\Sector_BuildUP\summary'+str(todate)+'.csv',encoding='cp1252')
# mail_summary.to_csv(r'D:\Data\Sector_BuildUP\failed_summary'+str(todate)+'.csv',encoding='cp1252')

# inventory.to_csv(r'D:\Data\Sector_BuildUP\inventory'+str(todate)+'.csv',encoding='cp1252')
# summary.to_csv(r'D:\Data\Sector_BuildUP\summary'+str(todate)+'.csv',encoding='cp1252')
# mail_summary.to_csv(r'D:\Data\Sector_BuildUP\failed_summary'+str(todate)+'.csv',encoding='cp1252')

writer = pd.ExcelWriter(r'D:\Data\Sector_BuildUP\Inventory'+str(todate)+'.xlsx', engine='xlsxwriter')
inventory.to_excel(writer,sheet_name='Data')
mail_summary.to_excel(writer,sheet_name='Failed_Cons')
summary.to_excel(writer,sheet_name='Reached_Cons')
writer.save()

writer = pd.ExcelWriter(r'D:\Data\Sector_BuildUP\Inventory.xlsx', engine='xlsxwriter')
inventory.to_excel(writer,sheet_name='Data')
mail_summary.to_excel(writer,sheet_name='Failed_Cons')
summary.to_excel(writer,sheet_name='Reached_Cons')
writer.save()

filepath=r'D:\Data\Sector_BuildUP\Inventory.xlsx'

import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback

oppath1=filepath
#FTP Upload starts
print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = filepath
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()

# TO=['mahesh.reddy@spoton.co.in']
TO=['abhik.mitra@spoton.co.in','jothi.menon@spoton.co.in','pawan.sharma@spoton.co.in','shivananda.p@spoton.co.in','satya.pal@spoton.co.in']
CC=['mahesh.reddy@spoton.co.in']
# CC=['mahesh.reddy@spoton.co.in']
FROM="reports.ie@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
# msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "Sector Load Buildup-W" + ' - ' +todate
html3='''
<h5> To download the data , Please click the link below </h5>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Inventory.xlsx"</a>http://spoton.co.in/downloads/IEProjects/ETA/Inventory.xlsx</p></b>

'''
report=""
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='PFA the Sector Load Buildup at '+todate
report+='<br>'
report+='Total cons in inventory = '+str(totalcons)
report+='<br>'
report+='Total cons after excluding deps = '+str(aftremdeps)
report+='<br>'
report+='Total expected Reach% of the current inventory = '+str(perce)+ '%'
report+='<br>'
report+='ETA Slipped Cons = '+str(eta_slped_cons)
report+='<br>'
report+='ETA Slipped Cons >2days = '+str(grt2days)
report+='<br>'
report+='Average Hours after pickup = '+str(avghraftpkp)
report+='<br>'
report+='Average Hours to due date = '+str(avghrduedt)
report+='<br>'

report+='<br>'
#report+='Total cons in urgent status ='+str(len(urgent_cons))
#report+='<br>'
#report+='Total expected Reach % of urgent status cons ='+str(urgnt_perc)+'%'
#report+='<br>'
#report+='Total cons in other status ='+str(reached_cons)
#report+='<br>'
#report+='Total expected Reach % of other status cons ='+str(perce)+'%'
report+='<br>'
report+='<br>'+mail_summary1.head(25).to_html()+'<br>'
report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)
# part = MIMEBase('application', "octet-stream")
# part.set_payload( open(filepath1,"rb").read() )
# encoders.encode_base64(part)
# part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
# msg.attach(part)

# part2 = MIMEBase('application', "octet-stream")
# part2.set_payload( open(filepath2,"rb").read() )
# encoders.encode_base64(part2)
# part2.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath2))
# msg.attach(part2)



server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("spoton.net.in", "Star@123#")
server.login('spoton.net.in', 'Star@123#')
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
cnxn.autocommit = True
cursor = cnxn.cursor()

db_df=eta_slped_consdf
db_df=db_df[db_df['neweta']>db_df['ETADATE']]
db_df['ETA']=db_df['neweta'].dt.date
conlist= db_df['Con Number'].values.tolist()
len(conlist)

db_df.rename(columns={'Destination':'DEST','Location':'HUB_SC','Origin':'ORIGIN','Ts':'TIMESTAMP','nextloc':'NEXT_LOC'},inplace=True)

db_df['FLAG']="Inventory"
db_df['THC_ETA']='-'
db_df['THCNO']='-'
print (db_df['TIMESTAMP'].dtype)
# db_df['TIMESTAMP']=db_df['TIMESTAMP'].astype(str)


try:
    for u in range (0,len(conlist)):
        connumber = db_df.iloc[u]['Con Number']
        connumber=str(connumber)
        #print('Con number is ',connumber)
        destbr = db_df.iloc[u]['DEST']
        #print ('destbr',destbr)
        conflag = db_df.iloc[u]['FLAG']
        hubscloc = db_df.iloc[u]['HUB_SC']
        orgbr= db_df.iloc[u]['ORIGIN']
        thceta= db_df.iloc[u]['THC_ETA']
        thcno  = db_df.iloc[u]['THCNO']
        timest  =db_df.iloc[u]['TIMESTAMP']
        etaofcon  = str(db_df.iloc[u]['ETA']).replace('T',' ').split('.')[0]
        nextloc  = db_df.iloc[u]['NEXT_LOC']
        #print ("""INSERT INTO TBLDOCKETETADATA_PYTHON (ConNo, DEST, FLAG, HUB_SC, ORIGIN, THC_ETA, THCNO, TIMESTAMP, ETA, NEXT_LOC) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",(connumber, destbr, conflag, hubscloc, orgbr, thceta, thcno, timest, etaofcon, nextloc))
        
        cursor.execute("""
        INSERT INTO TBLDOCKETETADATA_PYTHON (ConNo, DEST, FLAG, HUB_SC, ORIGIN, THC_ETA, THCNO, TIMESTAMP, ETA, NEXT_LOC) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,(connumber, destbr, conflag, hubscloc, orgbr, thceta, thcno, timest, etaofcon, nextloc))

except:
    TO=['mahesh.reddy@spoton.co.in']
    FROM="mahesh.reddy@spoton.co.in"
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    #msg["CC"] = ",".join(CC)
    #msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "Inventory Data Not Uploaded" 
    report=""
    report+='Hi,'

    report+='<br>'
    report+='Inventory Data Not Uploaded'
    report+='<br>'

    abc=MIMEText(report.encode('utf-8'),'html')
    msg.attach(abc)
    # part = MIMEBase('application', "octet-stream")
    # part.set_payload( open(filepath,"rb").read() )
    # encoders.encode_base64(part)
    # part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
    # msg.attach(part)

    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO, msg.as_string())
    server.quit()



