
# coding: utf-8

# In[36]:

import pandas as pd
from datetime import datetime, timedelta, date
from pandas import ExcelWriter

import os
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from pandas import ExcelWriter
from email import encoders
# In[2]:

pmddata = pd.read_csv(r'http://10.109.230.50/downloads/PMD/PMD.csv')


# In[3]:

len(pmddata)


# In[4]:

def adhocstdoda(pudtype,pintype):
    if pudtype == 'ADHOC':
        return 'MKT'+str('-')+str(pintype)
    else:
        return pudtype


# In[5]:

pmddata['PUDTYPES'] = pmddata.apply(lambda x: adhocstdoda (x['PUDTYPE2'],x['PINTYPE']),axis=1)


# In[6]:

#pmddata.to_csv(r'C:\Data\OCID_PMD\Monitoring_report_automation\PMD_test.csv')


# In[7]:

pmddatagrp = pmddata.groupby(['REGION2','PUDTYPES']).agg({'ACT_WT2':sum,'COST2':sum}).reset_index()
pmddatagrp = pmddatagrp.fillna(0)

# In[8]:

pmddatagrp['CPKG'] = pmddatagrp.apply(lambda x: round(x['COST2']/x['ACT_WT2'],2),axis=1)



# In[9]:

pmddatagrpfull = pmddata.groupby(['PUDTYPES']).agg({'ACT_WT2':sum,'COST2':sum}).reset_index()
pmddatagrpfull['CPKG'] = pmddatagrpfull.apply(lambda x: round(x['COST2']/x['ACT_WT2'],2),axis=1)


# In[10]:

pmddatagrpfull.loc[pmddatagrpfull.index,'REGION2'] = 'ALL_INDIA'
columnsop = ['REGION2','PUDTYPES','COST2','ACT_WT2','CPKG']
pmddatagrpfull = pd.DataFrame(pmddatagrpfull,columns=columnsop)


# In[11]:

totalpmd = pmddatagrpfull.append(pmddatagrp,ignore_index=True)


# In[12]:

totalpmdgrp = totalpmd.groupby(['REGION2']).agg({'COST2':sum,'ACT_WT2':sum}).reset_index()
totalpmdgrp['CPKG'] = totalpmdgrp.apply(lambda x: round(x['COST2']/x['ACT_WT2'],2),axis=1)


# In[13]:

totalpmdmtd = pd.merge(totalpmdgrp,totalpmd,on=['REGION2'],how='outer')


# In[14]:

totalpmdmtd['% ACT_WT'] = totalpmdmtd.apply(lambda x: round(x['ACT_WT2_y']*100.0/x['ACT_WT2_x'],2),axis=1)


# In[15]:

totalpmdmtd = totalpmdmtd.drop(['COST2_x', 'ACT_WT2_x', 'CPKG_x'], axis=1)
totalpmdmtd = totalpmdmtd.rename(columns={'COST2_y':'COST'})
totalpmdmtd = totalpmdmtd.rename(columns={'ACT_WT2_y':'ACT_WT'})
totalpmdmtd = totalpmdmtd.rename(columns={'CPKG_y':'CPKG'})


# ### FOR YESTERDAY

# In[17]:

def datestring(x):
    fulldate = datetime.strptime(x,'%d %b %Y %H:%M')
    return fulldate


# In[18]:

pmddata['DATE'] = pmddata.apply (lambda x:datestring (x['DATE2']),axis=1)


# In[19]:

pmddata['DATE'].values[0]


# In[20]:

yesterdate=date.today()-timedelta(hours=24)


# In[21]:

yesterdaydf = pmddata[(pmddata['DATE'] >= yesterdate)]
len(yesterdaydf)


# In[22]:

pmddatagrpyest = yesterdaydf.groupby(['REGION2','PUDTYPES']).agg({'ACT_WT2':sum,'COST2':sum}).reset_index()
pmddatagrpyest['CPKG'] = pmddatagrpyest.apply(lambda x: round(x['COST2']/x['ACT_WT2'],2),axis=1)


# In[23]:

pmddatagrpfullyest = yesterdaydf.groupby(['PUDTYPES']).agg({'ACT_WT2':sum,'COST2':sum}).reset_index()
pmddatagrpfullyest['CPKG'] = pmddatagrpfullyest.apply(lambda x: round(x['COST2']/x['ACT_WT2'],2),axis=1)


# In[24]:

pmddatagrpfullyest.loc[pmddatagrpfullyest.index,'REGION2'] = 'ALL_INDIA'
columnsop = ['REGION2','PUDTYPES','COST2','ACT_WT2','CPKG']
pmddatagrpfullyest = pd.DataFrame(pmddatagrpfullyest,columns=columnsop)


# In[25]:

totalpmdyest = pmddatagrpfullyest.append(pmddatagrpyest,ignore_index=True)


# In[26]:

totalpmdgrpyest = totalpmdyest.groupby(['REGION2']).agg({'COST2':sum,'ACT_WT2':sum}).reset_index()
totalpmdgrpyest['CPKG'] = totalpmdgrpyest.apply(lambda x: round(x['COST2']/x['ACT_WT2'],2),axis=1)


# In[27]:

totalpmdyest = pd.merge(totalpmdgrpyest,totalpmdyest,on=['REGION2'],how='outer')
totalpmdyest['% ACT_WT'] = totalpmdyest.apply(lambda x: round(x['ACT_WT2_y']*100.0/x['ACT_WT2_x'],2),axis=1)


# In[29]:

totalpmdyest = totalpmdyest.drop(['COST2_x', 'ACT_WT2_x', 'CPKG_x'], axis=1)
totalpmdyest = totalpmdyest.rename(columns={'COST2_y':'COST'})
totalpmdyest = totalpmdyest.rename(columns={'ACT_WT2_y':'ACT_WT'})
totalpmdyest = totalpmdyest.rename(columns={'CPKG_y':'CPKG'})


# In[31]:

totalpmdmerge = pd.merge(totalpmdyest,totalpmdmtd,on=['REGION2','PUDTYPES'],suffixes=['_YDAY','_MTD'],how='outer')
columnsoptotal = ['REGION2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST_MTD','CPKG_MTD']
totalpmdmerge = pd.DataFrame(totalpmdmerge,columns=columnsoptotal)


# In[37]:



# In[34]:
dfformail = totalpmdmerge[totalpmdmerge['REGION2']=='ALL_INDIA']
peractwtyday = pd.np.round(dfformail['% ACT_WT_YDAY'].sum(),2)
actwtyday = dfformail['ACT_WT_YDAY'].sum()
costyday = dfformail['COST_YDAY'].sum()
cpkyday = pd.np.round((costyday/actwtyday),2)
peractwtmtd = dfformail['% ACT_WT_MTD'].sum()
actwtmtd = dfformail['ACT_WT_MTD'].sum()
costmtd = dfformail['COST_MTD'].sum()
cpkmtd = pd.np.round((costmtd/actwtmtd),2)


# In[35]:

sumlist = ['GRAND_TOTAL','-',peractwtyday,actwtyday,costyday,cpkyday,peractwtmtd,actwtmtd,costmtd,cpkmtd]
col_list = ['REGION2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST_MTD','CPKG_MTD']
totalsdf = pd.DataFrame(data=[sumlist], columns = col_list)
dfformail = dfformail.append(totalsdf,ignore_index=True)
 
columnsreq=['PUDTYPES','% ACT_WT_YDAY','CPKG_YDAY','% ACT_WT_MTD','CPKG_MTD']
dfformailreqcols = pd.DataFrame(dfformail,columns=columnsreq)
dfformailreqcols = dfformailreqcols.rename(columns={'% ACT_WT_YDAY':'%WT_YDAY'})
dfformailreqcols = dfformailreqcols.rename(columns={'% ACT_WT_MTD':'%WT_MTD'})

## For EAST TOTALS
easttotaldf = totalpmdmerge[totalpmdmerge['REGION2']=='E']
peractwtydayeast = pd.np.round(easttotaldf['% ACT_WT_YDAY'].sum(),2)
actwtydayeast = easttotaldf['ACT_WT_YDAY'].sum()
costydayeast = easttotaldf['COST_YDAY'].sum()
cpkydayeast = pd.np.round((costydayeast/actwtydayeast),2)
peractwtmtdeast = easttotaldf['% ACT_WT_MTD'].sum()
actwtmtdeast = easttotaldf['ACT_WT_MTD'].sum()
costmtdeast = easttotaldf['COST_MTD'].sum()
cpkmtdeast = pd.np.round((costmtdeast/actwtmtdeast),2)
sumlisteast = ['EAST_TOTAL','-',peractwtydayeast,actwtydayeast,costydayeast,cpkydayeast,peractwtmtdeast,actwtmtdeast,costmtdeast,cpkmtdeast]
col_list = ['REGION2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST_MTD','CPKG_MTD']
totalsdfeast = pd.DataFrame(data=[sumlisteast], columns = col_list)
dfformaileast = easttotaldf.append(totalsdfeast,ignore_index=True)
## For EAST TOTALS

## For NORTH TOTALS
northtotaldf = totalpmdmerge[totalpmdmerge['REGION2']=='N']
peractwtydaynorth = pd.np.round(northtotaldf['% ACT_WT_YDAY'].sum(),2)
actwtydaynorth = northtotaldf['ACT_WT_YDAY'].sum()
costydaynorth = northtotaldf['COST_YDAY'].sum()
cpkydaynorth = pd.np.round((costydaynorth/actwtydaynorth),2)
peractwtmtdnorth = northtotaldf['% ACT_WT_MTD'].sum()
actwtmtdnorth = northtotaldf['ACT_WT_MTD'].sum()
costmtdnorth = northtotaldf['COST_MTD'].sum()
cpkmtdnorth = pd.np.round((costmtdnorth/actwtmtdnorth),2)

sumlistnorth = ['NORTH_TOTAL','-',peractwtydaynorth,actwtydaynorth,costydaynorth,cpkydaynorth,peractwtmtdnorth,actwtmtdnorth,costmtdnorth,cpkmtdnorth]
col_list = ['REGION2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST_MTD','CPKG_MTD']
totalsdfnorth = pd.DataFrame(data=[sumlistnorth], columns = col_list)
dfformailnorth = northtotaldf.append(totalsdfnorth,ignore_index=True)
## For NORTH TOTALS

## For SOUTH TOTALS
southtotaldf = totalpmdmerge[totalpmdmerge['REGION2']=='S']
peractwtydaysouth = pd.np.round(southtotaldf['% ACT_WT_YDAY'].sum(),2)
actwtydaysouth = southtotaldf['ACT_WT_YDAY'].sum()
costydaysouth = southtotaldf['COST_YDAY'].sum()
cpkydaysouth = pd.np.round((costydaysouth/actwtydaysouth),2)
peractwtmtdsouth = southtotaldf['% ACT_WT_MTD'].sum()
actwtmtdsouth = southtotaldf['ACT_WT_MTD'].sum()
costmtdsouth = southtotaldf['COST_MTD'].sum()
cpkmtdsouth = pd.np.round((costmtdsouth/actwtmtdsouth),2)

sumlistsouth = ['SOUTH_TOTAL','-',peractwtydaysouth,actwtydaysouth,costydaysouth,cpkydaysouth,peractwtmtdsouth,actwtmtdsouth,costmtdsouth,cpkmtdsouth]
col_list = ['REGION2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST_MTD','CPKG_MTD']
totalsdfsouth = pd.DataFrame(data=[sumlistsouth], columns = col_list)
dfformailsouth = southtotaldf.append(totalsdfsouth,ignore_index=True)
## For SOUTH TOTALS

## For WEST TOTALS
westtotaldf = totalpmdmerge[totalpmdmerge['REGION2']=='W']
peractwtydaywest = pd.np.round(westtotaldf['% ACT_WT_YDAY'].sum(),2)
actwtydaywest = westtotaldf['ACT_WT_YDAY'].sum()
costydaywest = westtotaldf['COST_YDAY'].sum()
cpkydaywest = pd.np.round((costydaywest/actwtydaywest),2)
peractwtmtdwest = westtotaldf['% ACT_WT_MTD'].sum()
actwtmtdwest = westtotaldf['ACT_WT_MTD'].sum()
costmtdwest = westtotaldf['COST_MTD'].sum()
cpkmtdwest = pd.np.round((costmtdwest/actwtmtdwest),2)

sumlistwest = ['WEST_TOTAL','-',peractwtydaywest,actwtydaywest,costydaywest,cpkydaywest,peractwtmtdwest,actwtmtdwest,costmtdwest,cpkmtdwest]
col_list = ['REGION2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST_MTD','CPKG_MTD']
totalsdfwest = pd.DataFrame(data=[sumlistwest], columns = col_list)
dfformailwest = westtotaldf.append(totalsdfwest,ignore_index=True)
## For WEST TOTALS



eastpanindia = dfformail.append(dfformaileast,ignore_index=True)
eastpinorth = eastpanindia.append(dfformailnorth,ignore_index=True)
eastpinorthsouth = eastpinorth.append(dfformailsouth,ignore_index=True)
eastpinorthsouthwest = eastpinorthsouth.append(dfformailwest,ignore_index=True)


### Accessing Particular cells

mktoda = dfformailreqcols[dfformailreqcols['PUDTYPES']=='MKT-ODA']
mktmtdodacpk = mktoda['CPKG_MTD'].values[0]
mktydayodacpk = mktoda['CPKG_YDAY'].values[0]

mktstd = dfformailreqcols[dfformailreqcols['PUDTYPES']=='MKT-STD']
mktmtdstdcpk = mktstd['CPKG_MTD'].values[0]
mktydaystdcpk = mktstd['CPKG_YDAY'].values[0]
    
ctn = dfformailreqcols[dfformailreqcols['PUDTYPES']=='COUNTER']
mtdctncpk = ctn['CPKG_MTD'].values[0]
ydayctncpk = ctn['CPKG_YDAY'].values[0]

std = dfformailreqcols[dfformailreqcols['PUDTYPES']=='STD']
mtdstdcpk = std['CPKG_MTD'].values[0]
ydaystdcpk = std['CPKG_YDAY'].values[0]

oda = dfformailreqcols[dfformailreqcols['PUDTYPES']=='ODA']
mtdodacpk = oda['CPKG_MTD'].values[0]
ydayodacpk = oda['CPKG_YDAY'].values[0]
    
fixed = dfformailreqcols[dfformailreqcols['PUDTYPES']=='FIXED']
mtdfixedcpk = fixed['CPKG_MTD'].values[0]
ydayfixedcpk = fixed['CPKG_YDAY'].values[0]

if ydayfixedcpk>=0:  
     ydayfixedcpk = ydayfixedcpk
else:
    ydayfixedcpk =  0
    
smedf = dfformailreqcols[dfformailreqcols['PUDTYPES']=='SME']
try:
    mtdsmedfcpk = smedf['CPKG_MTD'].values[0]
except:
    mtdsmedfcpk=0

try:
    ydaysmedfcpk = smedf['CPKG_YDAY'].values[0]
except:
    ydaysmedfcpk = 0
### Accessing Particular cells

# In[ ]:
with ExcelWriter(r'D:\Data\Monitoring_report\Monitoring_Report_'+str(yesterdate)+'.xlsx') as writer:
    eastpinorthsouthwest.to_excel(writer, sheet_name='Monitoring_Report',engine='xlsxwriter')

oppath = r'D:\Data\Monitoring_report\Monitoring_Report_'+str(yesterdate)+'.xlsx'
filePath = oppath
def sendEmail(#TO = ["supratim@iepfunds.com","Ankit@iepfunds.com","abhik.mitra@spoton.co.in","krishna.chandrasekar@spoton.co.in","sukumar.sakthivel@spoton.co.in","Anto.Paul@Spoton.Co.In"],
             TO = ["mahesh.reddy@spoton.co.in"],
             CC = ["mahesh.reddy@spoton.co.in"],
             #CC = ["vishwas.j@spoton.co.in","rajeesh.vr@spoton.co.in","goutam.barik@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "Monitoring Report " + '- ' + str(yesterdate)
    msg["Subject"] = "Monitoring Report " + '- ' + str(yesterdate)
    body_text = """
    Dear All,
    
    PFB the PAN-INDIA Monitoring Report as of """+str(yesterdate)+ """
    
    Overall CPKG YDAY = """+str(cpkyday)+"""
    STD CPKG YDAY = """+str(ydaystdcpk)+"""
    ODA CPKG YDAY = """+str(ydayodacpk)+"""
    FIXED CPKG YDAY = """+str(ydayfixedcpk)+"""
    COUNTER CPKG YDAY = """+str(ydayctncpk)+"""
    MKT-STD CPKG YDAY = """+str(mktydaystdcpk)+"""
    MKT-ODA CPKG YDAY = """+str(mktydayodacpk)+"""
    SME CPKG YDAY = """+str(ydaysmedfcpk)+"""
    
    Overall CPKG MTD = """+str(cpkmtd)+"""
    STD CPKG MTD = """+str(mtdstdcpk)+"""
    ODA CPKG MTD = """+str(mtdodacpk)+"""
    FIXED CPKG MTD = """+str(mtdfixedcpk)+"""
    COUNTER CPKG MTD = """+str(mtdctncpk)+"""
    MKT-STD CPKG MTD = """+str(mktmtdstdcpk)+"""
    MKT-ODA CPKG MTD = """+str(mktmtdodacpk)+"""
    SME CPKG MTD = """+str(mtdsmedfcpk)+"""
    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends



