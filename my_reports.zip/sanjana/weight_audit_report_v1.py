
# coding: utf-8

# In[1]:

import pandas as pd
import numpy as np
from pymongo import MongoClient
from string import Template
import smtplib
import os
from datetime import datetime, timedelta
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import smtplib
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
import Utilities

# In[2]:

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


# In[3]:
# try:
# start_date=datetime.strftime(datetime.now()-timedelta(days=1),'%Y-%m-%d')+' 00:00:00'
start_date=datetime.strftime((datetime.now()-timedelta(days=1)).replace(day=1),"%Y-%m-%d")+' 00:00:00'
enddate=datetime.strftime(datetime.now()-timedelta(days=1),'%Y-%m-%d')+' 23:59:00'
start_date,enddate


# In[4]:

query=("EXEC dbo.USP_WEIGHT_AUDIT_REPORT_SQ '{0}','{1}'").format(start_date,enddate)

print (query)
# In[5]:

df=pd.read_sql(query,Utilities.cnxn)

print (df.columns)
# In[6]:


len(df)


# In[ ]:

# df.to_csv(r'Weight_Audit_Data_2019-05-07.csv')


# In[7]:

required_cols=df.columns.tolist()


# In[8]:

def getAuditWt(actwt,volwt):
    if actwt>volwt:
        return actwt
    else:
        return volwt


# In[9]:

df['Audited_Charge_Wt']=df.apply(lambda x:getAuditWt(x['AuditWt'],x['AUDIT_VOL_WT']),axis=1)


# In[10]:

def wtdiff(adtwt,minwt):
    if adtwt>minwt:
        return adtwt
    else:
        return minwt


# In[11]:

df['Audited_Charge_Wt']=df.apply(lambda x: wtdiff(x['Audited_Charge_Wt'],x['MIN_CHRG_WT']),axis=1)


# In[28]:

def getWtDiff(x,y):
    try:
        val=x/y-1
        return pd.np.round(val*100.0,0)
    except:
        return 0.0


# In[29]:

df['%Diff_Audit_System_Wt']=df.apply(lambda x: getWtDiff(x['AuditWt'],x['ACTUWT']),axis=1)
#df['%Diff_Audit_System_Wt_Overstated']=df.apply(lambda x: getWtDiff(x['ACTUWT'],x['AuditWt']),axis=1)

# In[30]:

df['%Diff_Audit_System_Vol_Wt']=df.apply(lambda x:getWtDiff(x['AUDIT_VOL_WT'],x['VOL_WT']),axis=1)


# In[31]:

df['%Diff_Audit_System_Charge_Wt']=df.apply(lambda x:getWtDiff(x['Audited_Charge_Wt'],x['CHRGWT']),axis=1)


# In[32]:

df['Diff_Audit_System_Actual_Wt']=pd.np.round(df['AuditWt']-df['ACTUWT'],0)
#df['Diff_Audit_System_Actual_Wt_Overstaed']=pd.np.round(df['ACTUWT']-df['AuditWt'],0)
df['Diff_Audit_System_Vol_Wt']=pd.np.round(df['AUDIT_VOL_WT']-df['VOL_WT'],0)
df['Diff_Audit_System_Charge_Wt']=pd.np.round(df['Audited_Charge_Wt']-df['CHRGWT'],0)


# In[ ]:

## Report2


# In[34]:

df.head()


# In[36]:

def getX(x,y):
    if x>10 or y>10:
        return True
    else:
        return False


# In[37]:

#df['CHECK']=df.apply(lambda x:getX(x['Diff_Audit_System_Actual_Wt'],x['%Diff_Audit_System_Wt']),axis=1)
df['CHECK']=df.apply(lambda x:True if x['Diff_Audit_System_Actual_Wt']>10 else False,axis=1)
df1=df[df['CHECK']==True]
len(df1)
df1['CHECK1']=df1.apply(lambda x:True if x['%Diff_Audit_System_Wt']>10 else False,axis=1)
first_summary=df1[df1['CHECK1']==True]

# In[39]:

# first_summary=df[df['CHECK']==True]
# fourth_df=df[df['CHECK']==False]

def getY(x,y):
    if x<-10 or y<-10:
        return True
    else:
        return False

df['CHECK11']=df.apply(lambda x: True if x['Diff_Audit_System_Actual_Wt']<-10 else False,axis=1)
df2=df[df['CHECK11']==True]
df2['CHECK12']=df2.apply(lambda x:True if x['%Diff_Audit_System_Wt']<-10 else False,axis=1)

fourth_summary=df2[df2['CHECK12']==True]
# In[40]:

first_summary


# In[ ]:

##Report3


# In[41]:

def getDf(x,y):
    if (x>25) or (y>10):
        return True
    else:
        return False


# In[42]:

df['Check']=df.apply(lambda x: True if x['Diff_Audit_System_Charge_Wt']>15 else False ,axis=1)
df3=df[df['Check']==True]
df3['Check1']=df3.apply(lambda x: True if x['%Diff_Audit_System_Charge_Wt']>10 else False ,axis=1)
second_summary=df3[df3['Check1']==True]
# In[46]:

def getDf(x,y):
    if (x<-25) or (y<-5):
        return True
    else:
        return False


# In[47]:

df['Check12']=df.apply(lambda x: True if x['Diff_Audit_System_Charge_Wt']<-15 else False ,axis=1)
df4=df[df['Check12']==True]
df4['Check123']=df4.apply(lambda x: True if x['%Diff_Audit_System_Charge_Wt']<-10 else False ,axis=1)
third_summary=df4[df4['Check123']==True]


# In[48]:


# In[59]:

del df['DockId']
del df['CFT_TOTAL']
del df['CFT2KG']
del df['MIN_CHRG_WT']
# del df['AUDIT_CFT_TOTAL']

first_summary=first_summary[['DockNo','ORGNCD','REASSIGN_DESTCD','Customer Code','Customer Name','ParentCode','ParentName','Audit_dATE','Customer_Type','PICKUP_VENDOR','PKGSNO','ACTUWT','VOL_WT','CHRGWT','AUDIT_BR','EMPNM','AuditWt','AUDIT_VOL_WT','Audited_Charge_Wt','%Diff_Audit_System_Wt','Diff_Audit_System_Actual_Wt']]
second_summary=second_summary[['DockNo','ORGNCD','REASSIGN_DESTCD','Customer Code','Customer Name','ParentCode','ParentName','Audit_dATE','Customer_Type','PICKUP_VENDOR','PKGSNO','ACTUWT','VOL_WT','CHRGWT','AUDIT_BR','EMPNM','AuditWt','AUDIT_VOL_WT','Audited_Charge_Wt','%Diff_Audit_System_Charge_Wt','Diff_Audit_System_Charge_Wt']]
third_summary=third_summary[['DockNo','ORGNCD','REASSIGN_DESTCD','Customer Code','Customer Name','ParentCode','ParentName','Audit_dATE','Customer_Type','PICKUP_VENDOR','PKGSNO','ACTUWT','VOL_WT','CHRGWT','AUDIT_BR','EMPNM','AuditWt','AUDIT_VOL_WT','Audited_Charge_Wt','%Diff_Audit_System_Charge_Wt','Diff_Audit_System_Charge_Wt']]
fourth_summary=fourth_summary[['DockNo','ORGNCD','REASSIGN_DESTCD','Customer Code','Customer Name','ParentCode','ParentName','Audit_dATE','Customer_Type','PICKUP_VENDOR','PKGSNO','ACTUWT','VOL_WT','CHRGWT','AUDIT_BR','EMPNM','AuditWt','AUDIT_VOL_WT','Audited_Charge_Wt','%Diff_Audit_System_Wt','Diff_Audit_System_Actual_Wt']]

todate=datetime.strftime(datetime.now(),'%Y-%m-%d')
todate

# In[60]:

writer = pd.ExcelWriter(r'D:\Data\weight_audit_report\Weight_Audit_Report'+str(todate)+'.xlsx', engine='xlsxwriter')
first_summary1=first_summary
first_summary1['Remarks']='actual weight understated'
second_summary1=second_summary
second_summary1['Remarks']='CHG weight understated'
third_summary1=third_summary
third_summary1['Remarks']='CHG weight overstated'
fourth_summary1=fourth_summary
fourth_summary1['Remarks']='actual weight overrstated'
first_summary1.rename(columns={'%Diff_Audit_System_Wt':'%Diff_Wt','Diff_Audit_System_Actual_Wt':'Diff_Wt'},inplace=True)
second_summary1.rename(columns={'%Diff_Audit_System_Charge_Wt':'%Diff_Wt','Diff_Audit_System_Charge_Wt':'Diff_Wt'},inplace=True)
third_summary1.rename(columns={'%Diff_Audit_System_Charge_Wt':'%Diff_Wt','Diff_Audit_System_Charge_Wt':'Diff_Wt'},inplace=True)
fourth_summary1.rename(columns={'%Diff_Audit_System_Wt':'%Diff_Wt','Diff_Audit_System_Actual_Wt':'Diff_Wt'},inplace=True)

master_summary=pd.concat([first_summary1,second_summary1,third_summary1,fourth_summary1],ignore_index=True)
extradf=pd.merge(df,master_summary[['DockNo','Remarks']],on=['DockNo'],how='outer')

master_summary=master_summary[['DockNo','ORGNCD','REASSIGN_DESTCD','Customer Code','Customer Name','ParentCode','ParentName','Audit_dATE','Customer_Type','PICKUP_VENDOR','PKGSNO','ACTUWT','VOL_WT','CHRGWT','AUDIT_BR','EMPNM','AuditWt','AUDIT_VOL_WT','Audited_Charge_Wt','%Diff_Wt','Diff_Wt','Remarks']]

del first_summary['Remarks']
del second_summary['Remarks']
del third_summary['Remarks']
del fourth_summary['Remarks']
first_summary.to_excel(writer,sheet_name='actual weight understated')
second_summary.to_excel(writer,sheet_name='CHG weight understated')
third_summary.to_excel(writer,sheet_name='CHG weight overstated')
fourth_summary.to_excel(writer,sheet_name='actual weight overrstated')
master_summary.to_excel(writer,sheet_name='Master Data')
extradf.to_excel(writer,sheet_name='Base Data')
writer.save()


writer = pd.ExcelWriter(r'D:\Data\weight_audit_report\Weight_Audit_Report.xlsx', engine='xlsxwriter')

first_summary.to_excel(writer,sheet_name='actual weight understated')
second_summary.to_excel(writer,sheet_name='CHG weight understated')
third_summary.to_excel(writer,sheet_name='CHG weight overstated')
fourth_summary.to_excel(writer,sheet_name='actual weight overrstated')
master_summary.to_excel(writer,sheet_name='Master Data')
extradf.to_excel(writer,sheet_name='Base Data')
writer.save()

# In[32]:


# In[51]:



# In[ ]:




# In[57]:

filepath=r'D:\Data\weight_audit_report\Weight_Audit_Report.xlsx'


# In[58]:

TO=['rom_spot@spoton.co.in','aom_spot@spoton.co.in','dom_spot@spoton.co.in','hubmgr_spot@spoton.co.in','sc_incharge@spoton.co.in']
# TO=['mahesh.reddy@spoton.co.in']
CC=['sq_spot@spoton.co.in','abhik.mitra@spoton.co.in','krishna.chandrasekar@spoton.co.in','jothi.menon@spoton.co.in','shivananda.p@spoton.co.in','pawan.sharma@spoton.co.in','anitha.thyagarajan@spoton.co.in','rajesh.kumar@spoton.co.in','baskar.t@spoton.co.in','mahesh.reddy@spoton.co.in']
# CC=['mahesh.reddy@spoton.co.in']
FROM="reports.ie@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
# msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "weight audit report " + '- ' +todate
html3='''
<h5> To download the data , Please click the link below </h5>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Hub_Perfor_Data.csv"</a>http://spoton.co.in/downloads/IEProjects/ETA/Hub_Perfor_Data.csv</p></b>

<h5> To download the condata of DEPS/excluded cons , Please click the link below </h5>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Hub_Perfor_DEPS_condata.csv"</a>http://spoton.co.in/downloads/IEProjects/ETA/Hub_Perfor_DEPS_condata.csv</p></b>

'''
report=""
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='PFA weight audit report  '+todate
report+='<br>'
#report+='For Data and Summary use attached files.'
#report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)

part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

# part2 = MIMEBase('application', "octet-stream")
# part2.set_payload( open(filepath2,"rb").read() )
# encoders.encode_base64(part2)
# part2.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath2))
# msg.attach(part2)



server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("spoton.net.in", "Star@123#")
server.login('spoton.net.in', 'Star@123#')
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()

# except:

#   TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in']  
#   CC=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
#   FROM="mahesh.reddy@spoton.co.in"
#   msg = MIMEMultipart()
#   msg["From"] = FROM
#   msg["To"] = ",".join(TO)
#   msg["CC"] = ",".join(CC)
#   #msg["BCC"] = ",".join(BCC)
#   #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
#   msg["Subject"] = "ERROR Report" 
#   report=""
#   report+='Hi,'

#   report+='<br>'
#   report+='There was some error in weight audit report.'
#   report+='<br>'
  
#   abc=MIMEText(report.encode('utf-8'),'html')
#   msg.attach(abc)
#   server=smtplib.SMTP('smtp.sendgrid.net', 587)
#   server.ehlo()
#   server.starttls()
#   server.ehlo()
#   server.login("spoton.net.in", "Star@123#")
#   failed = server.sendmail(FROM, TO+CC, msg.as_string())
#   server.quit()





# In[ ]:



