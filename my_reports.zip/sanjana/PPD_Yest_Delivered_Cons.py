
# coding: utf-8

# In[1]:

import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta, date
import os
import ftplib
import traceback
import Utilities


# In[2]:
#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
#
try:
	query = ("""
	        EXEC USP_PART_PIECE_DLVD_DAILY_SQ
	        """)


	# In[3]:

	df = pd.read_sql(query, Utilities.cnxn)
	len(df)


	# In[4]:

	df.columns


	# In[5]:

	df['Date']=df['dely_dt'].dt.date


	# In[ ]:

	df[['Date','dely_dt']]


	# In[12]:

	df.rename(columns={'dockno':'DOCKNO'},inplace=True)


	# In[7]:

	yest_date=datetime.strftime(datetime.now()-timedelta(1),'%Y-%m-%d')
	yest_date


	# In[10]:

	df['Date'].unique()


	# In[13]:

	area_pivot=df.pivot_table(index=['DEST_AREA'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').reset_index()


	# In[15]:

	area_pivot1=area_pivot.sort_values('DOCKNO',ascending=False)


	# In[16]:

	branch_pivot=df.pivot_table(index=['REASSIGN_DESTCD'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').reset_index()


	# In[17]:

	branch_pivot1=branch_pivot.sort_values('DOCKNO',ascending=False)


	# In[18]:

	branch_pivot1.head()


	# In[19]:

	today=datetime.strftime(datetime.now(),'%Y-%m-%d')
	today


	# In[20]:

	from pandas import ExcelWriter
	# with ExcelWriter(r'D:\Data\PPD_Yest_Delivered_Cons\PPD_Yest_Delivered_Cons-'+str(today)+'.xlsx') as writer:
	#     area_pivot.to_excel(writer,engine='xlsxwriter',sheet_name='Area Wise Summary')
	#     branch_pivot.to_excel(writer,engine='xlsxwriter',sheet_name='Branch Wise Summary')
	#     df.to_excel(writer,engine='xlsxwriter',sheet_name='Con Data')
	    
	area_pivot.to_csv(r'D:\Data\PPD_Yest_Delivered_Cons\PPD_Yest_Delivered_Area Summary-'+str(today)+'.csv')
	branch_pivot.to_csv(r'D:\Data\PPD_Yest_Delivered_Cons\PPD_Yest_Delivered_Branch Summary-'+str(today)+'.csv')
	df.to_csv(r'D:\Data\PPD_Yest_Delivered_Cons\PPD_Yest_Delivered_Condata-'+str(today)+'.csv')


	area_pivot.to_csv(r'D:\Data\PPD_Yest_Delivered_Cons\PPD_Yest_Delivered_Area Summary.csv')
	branch_pivot.to_csv(r'D:\Data\PPD_Yest_Delivered_Cons\PPD_Yest_Delivered_Branch Summary.csv')
	df.to_csv(r'D:\Data\PPD_Yest_Delivered_Cons\PPD_Yest_Delivered_Condata.csv')

	# In[21]:

	# with ExcelWriter(r'D:\Data\PPD_Yest_Delivered_Cons\PPD_Yest_Delivered_Cons.xlsx') as writer:
	#     area_pivot.to_excel(writer,engine='xlsxwriter',sheet_name='Area Wise Summary')
	#     branch_pivot.to_excel(writer,engine='xlsxwriter',sheet_name='Branch Wise Summary')
	#     df.to_excel(writer,engine='xlsxwriter',sheet_name='Con Data')


	# In[22]:

	filepath=r'D:\Data\PPD_Yest_Delivered_Cons\PPD_Yest_Delivered_Area Summary.csv'
	filepath1=r'D:\Data\PPD_Yest_Delivered_Cons\PPD_Yest_Delivered_Branch Summary.csv'
	filepath2=r'D:\Data\PPD_Yest_Delivered_Cons\PPD_Yest_Delivered_Condata.csv'


	# In[23]:

	FROM='mis.ho@spoton.co.in'

	TO=["dom_spot@spoton.co.in","rom_spot@spoton.co.in","aom_spot@spoton.co.in",'scincharge_spot@spoton.co.in',"SQ_SPOT@spoton.co.in"]
	CC=['sqtf@spoton.co.in','rajesh.kumar@spoton.co.in','abhik.mitra@spoton.co.in','jothi.menon@spoton.co.in','shivananda.p@spoton.co.in']
	BCC=['mahesh.reddy@spoton.co.in']
	#TO=['mahesh.reddy@spoton.co.in']
	#CC=['mahesh.reddy@spoton.co.in']
	#BCC=['mahesh.reddy@spoton.co.in']

	msg = MIMEMultipart()
	msg["From"] = FROM
	msg["To"] = ",".join(TO)
	msg["CC"] = ",".join(CC)
	msg["BCC"] = ",".join(BCC)
	#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
	msg["Subject"] = "PPD Yesterday Delivered Cons " + str(today)

	report=""
	report+='Dear All,'
	report+='<br>'
	report+='<br>'
	report+='PFA PPD Yesterday Delivered Cons'
	report+='<br>'
	report+='<br>'
	#report+='Total PPD Request Raised Cons :'+str(len(ppd_raised_df))
	#report+='<br>'
	#report+='<br>'
	report+='PPD Yesterday Delivered Cons AreaWise Summary'
	report+='<br>'
	report+='<br>'+area_pivot1.to_html()+'<br>'
	report+='<br>'



	#report+=html3
	abc=MIMEText(report,'html')
	msg.attach(abc)

	part = MIMEBase('application', "octet-stream")
	part.set_payload( open(filepath,"rb").read() )
	encoders.encode_base64(part)
	part.add_header('Content-Disposition', 'attachment; filename="%s"' % 
	os.path.basename(filepath))
	msg.attach(part)

	part1 = MIMEBase('application', "octet-stream")
	part.set_payload( open(filepath1,"rb").read() )
	encoders.encode_base64(part1)
	part1.add_header('Content-Disposition', 'attachment; filename="%s"' % 
	os.path.basename(filepath1))
	msg.attach(part1)

	part2= MIMEBase('application', "octet-stream")
	part2.set_payload( open(filepath2,"rb").read() )
	encoders.encode_base64(part2)
	part2.add_header('Content-Disposition', 'attachment; filename="%s"' % 
	os.path.basename(filepath2))
	msg.attach(part2)


	server=smtplib.SMTP('smtp.sendgrid.net', 587)
	server.ehlo()
	server.starttls()
	server.ehlo()
	server.login("spoton.net.in", "Star@123#")
	failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
	server.quit()


except:

  TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in'] 
  CC=['mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "PPD Yesterday Delivered Cons Error in Execution" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in PPD Yesterday Delivered Cons'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO+CC, msg.as_string())
  server.quit()


# In[ ]:



