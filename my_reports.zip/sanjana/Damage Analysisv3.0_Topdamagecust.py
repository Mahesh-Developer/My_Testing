# -*- coding: utf-8 -*-
"""
Created on Tue Dec 13 10:50:23 2016

@author: rajeeshv
"""

# coding: utf-8

# In[1]:

# import graphlab as gl
# import graphlab.aggregate as agg
import sframe as gl
import sframe.aggregate as agg

import pandas as pd
from datetime import datetime, timedelta
import networkx as nx
import time

import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
import os
import Utilities

datetoday = datetime.today().date()
#yestrdy = datetoday-timedelta(days=1)
yestrdy = datetoday-timedelta(days=1)
#lastweek = datetoday-timedelta(days=7)
lastweek = datetoday-timedelta(days=8)
print 'lastweek', lastweek

# In[2]:
#condata = gl.SFrame(r'D:\Python\Scripts and Files\Path and Graph Files\Con_data_201016.csv')
#condata = gl.SFrame(r'http://spoton.co.in/downloads/IEP_CON_DATA_TO_SQ/IEP_CON_DATA_TO_SQ.csv')

## Edit on 19-12-2016

#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
#cursor = cnxn.cursor()

conquery = ("""
        EXEC USP_CON_DATA_SQ_IE_DOCTDT
        """)

condata_df = pd.read_sql(conquery, Utilities.cnxn)
condata_df.to_csv(r'D:\Data\Damage_report_TopDamageCustomer\Condata_df.csv')
print condata_df.columns
condata_df = condata_df.rename({'\xef\xbb\xbfDOCKNO': 'DOCKNO'})
#
#condata = gl.SFrame(data=condata_df)
#print type(condata_df)

condata = gl.SFrame.read_csv(r'D:\Data\Damage_report_TopDamageCustomer\Condata_df.csv')
## Edit on 19-12-2016

#condata = condata.rename({'\xef\xbb\xbfDOCKNO': 'DOCKNO'})
print len(condata)
condata = condata[condata['TOPDAMAGECUSTOMER']=='YES']
print len(condata)

# In[3]:

# Edit on 19-12-2016 to handle KeyError: ('Pickupdate', u'occurred at index DOCKNO')
condata['pkphr'] = condata.apply(lambda x: int(x['Pickupdate'].split(' ')[1].split(':')[0]))

#condata['pkphr'] = condata.apply(lambda x: int(x['Pickupdate'].split(' ')[1].split(':')[0]),axis=1)
# Edit on 19-12-2016 to handle KeyError: ('Pickupdate', u'occurred at index DOCKNO')

dayzero = datetime.strptime('01/01/2016','%d/%m/%Y')
timeformat2 = '%Y-%m-%d'
timeformat3 = '%d/%m/%y'
timeformat4 = '%d-%b-%y'
timeformat5 = '%d-%m-%Y'

def convertdate2(*vars):
    x = vars[0]
    flag = vars[1]
    timeformata = timeformat2
    timeformatb = timeformat3
    timeformatc = timeformat4
    timeformatd = timeformat5
    
    try:       
        x = x.split(' ')[0]
        return datetime.strptime(x,timeformata)
    except:
        try:
            x = x.split(' ')[0]
            return datetime.strptime(x,timeformatb)
        except:
            try:
                x = x.split(' ')[0]
                return datetime.strptime(x,timeformatc)
            except:
                try:
                    x = x.split(' ')[0]
                    return datetime.strptime(x,timeformatd)    
                except:
                    if flag=='today':
                        return datetime.today()
                    else:
                        return dayzero
condata['PickupDate'] = condata.apply(lambda x: convertdate2(x['Pickupdate'],'dayz'))

condata_yest = condata[condata['PickupDate']==yestrdy]
print 'condata_yest', len(condata_yest)
condata_wk = condata[condata['PickupDate']>=lastweek]
print 'condata_wk', len(condata_wk)
# In[4]:

#last 30 days short data
#shortdata = gl.SFrame.read_csv_with_errors(r'D:\Python\Scripts and Files\Path and Graph Files\Deps_data_201016.csv')
shortdata = gl.SFrame(r'http://spoton.co.in/downloads/IEP_DAMAGE_DATA_TO_SQ/IEP_DAMAGE_DATA_TO_SQ.csv')
shortdata.rename({'\xef\xbb\xbfDOCKNO': 'DOCKNO'})
print 'damage data columns', shortdata.column_names()
print len(shortdata)
shortdata = shortdata[shortdata['TOPDAMAGECUSTOMER']=='YES']
print 'DEPS data', len(shortdata)


#shortdata = shortdata.rename({'\xef\xbb\xbfDOCKNO': 'DOCKNO'})

#including only bad POD Union as asked by Supratim
badpoddata = gl.SFrame(r'http://spoton.co.in/downloads/IE_BADPOD_DATA_TO_SQ/IE_BADPOD_DATA_TO_SQ.csv')
#badpoddata.rename({'\xef\xbb\xbfDOCKNO': 'DOCKNO'})

### Edit for renaming Code to CODE  on 12-12-2016
badpoddata.rename({'\xef\xbb\xbfDOCKNO': 'DOCKNO','CODE':'Code'})
### Edit for renaming Code to CODE  on 12-12-2016

print 'badpod columns', badpoddata.column_names()
badpoddata = badpoddata[badpoddata['TOPDAMAGECUSTOMER']=='YES']
print 'BAD POD data', len(badpoddata)

badpoddata = badpoddata.remove_column('DEPS')
shortdata = shortdata.append(badpoddata)
print 'damage total cons', len(shortdata)


shortdata['PickupDate'] = shortdata.apply(lambda x: convertdate2(x['DOCKDT'],'dayz'))
shortdata['statusdate'] = shortdata.apply(lambda x: convertdate2(x['ConStatusDate'],'dayz'))


datetoday = datetime.today()
datefilter = datetoday-timedelta(hours=24)
datefilter=datefilter.date()
datefilter

shortdata.save(r'D:\Data\Damage_report_TopDamageCustomer\Damage_Badpod_cons\Damage_Badpod_cons_'+str(datefilter)+'.csv')

shortdata_yest = shortdata[shortdata['statusdate']==yestrdy]
shortdata_wk = shortdata[shortdata['statusdate']>=lastweek]
#shortdata_wk.save(r'shortdata_wk_check.csv')

#including only bad POD Union as asked by Supratim

## For all cons picked up and Damage data
condatagrp = condata.groupby(['PARENTCODE','PARENTNAME'],{'totalcon': agg.COUNT_DISTINCT('DOCKNO')})
condatagrp_wk = condata_wk.groupby(['PARENTCODE','PARENTNAME'],{'Con_wk': agg.COUNT_DISTINCT('DOCKNO')})
condatagrp_yest = condata_yest.groupby(['PARENTCODE','PARENTNAME'],{'Con_yest': agg.COUNT_DISTINCT('DOCKNO')})

condatagrp_mth_wk = condatagrp.join(condatagrp_wk, on = ['PARENTCODE','PARENTNAME'], how='left')
condatagrp_mth_wk_yest = condatagrp_mth_wk.join(condatagrp_yest, on = ['PARENTCODE','PARENTNAME'], how='left')

## For filling it as 1 just for handling divisional error

condatagrp_mth_wk_yest = condatagrp_mth_wk_yest.fillna('Con_yest', 1)
condatagrp_mth_wk_yest = condatagrp_mth_wk_yest.fillna('Con_wk', 1)

## For filling it as 1 just for handling divisional error

shortdatagrp = shortdata.groupby(['PARENTCODE','PARENTNAME'],{'D_mth': agg.COUNT_DISTINCT('DOCKNO')})
print 'MTD DAMAGE CONS', shortdatagrp['D_mth'].sum()
shortdatagrp_wk = shortdata_wk.groupby(['PARENTCODE','PARENTNAME'],{'D_wk': agg.COUNT_DISTINCT('DOCKNO')})
print 'Week DAMAGE CONS', shortdatagrp_wk['D_wk'].sum()
shortdatagrp_yest = shortdata_yest.groupby(['PARENTCODE','PARENTNAME'],{'D_yest': agg.COUNT_DISTINCT('DOCKNO')})
print 'Yesterday DAMAGE CONS', shortdatagrp_yest['D_yest'].sum()


summary_mth = condatagrp_mth_wk_yest.join(shortdatagrp, on = ['PARENTCODE','PARENTNAME'], how='left')
summary_mth_wk = summary_mth.join(shortdatagrp_wk, on = ['PARENTCODE','PARENTNAME'], how='left')
damage_cust_summary = summary_mth_wk.join(shortdatagrp_yest, on = ['PARENTCODE','PARENTNAME'], how='left')

damage_cust_summary = damage_cust_summary.fillna('D_mth', 0)
damage_cust_summary = damage_cust_summary.fillna('D_wk', 0)
damage_cust_summary = damage_cust_summary.fillna('D_yest', 0)


#damage_cust_summary.save(r'D:\Python\Scripts and Files\Path and Graph Files\damagesummary.csv')


# In[12]:

damage_cust_summary['%'] = damage_cust_summary.apply(lambda x: round(x['D_mth']*100.0/x['totalcon'],2))
damage_cust_summary['%Wk'] = damage_cust_summary.apply(lambda x: round((x['D_wk']*100.0)/(x['Con_wk']),2))
damage_cust_summary['%Y'] = damage_cust_summary.apply(lambda x: round((x['D_yest']*100.0)/(x['Con_yest']),2))


# In[14]:

damage_cust_summary = damage_cust_summary.sort([('D_mth',False),('%',False)])


# In[15]:

damage_cust_summary = damage_cust_summary['PARENTCODE','PARENTNAME','totalcon','D_mth','Con_wk','D_wk','Con_yest','D_yest','%','%Wk','%Y']
#damage_cust_summary = damage_cust_summary['org','dest','totalcon','D_Con','D_Con_Wk','D_Con_Y','perc','perc_Wk','perc_Y']


# In[16]:



#damage_cust_summary.save('damage_cust_summary_new.csv') #to write it into attachment + save it using ts
finaldf = damage_cust_summary.to_dataframe()

shortcons_30 = finaldf['D_mth'].sum()
shortcons_7 = finaldf['D_wk'].sum()
shortcons_y = finaldf['D_yest'].sum()
totalcons = finaldf['totalcon'].sum()
totalcons_wk = finaldf['Con_wk'].sum()
totalcons_yest = finaldf['Con_yest'].sum()

shortperc_30 = pd.np.round((shortcons_30*1.0/totalcons)*100.0,2)
shortperc_7 = pd.np.round((shortcons_7*1.0/totalcons_wk)*100.0,2)
shortperc_y = pd.np.round((shortcons_y*1.0/totalcons_yest)*100.0,2)

#### Edit to change column names as per Jothi Mam's request
finaldf.rename(columns={'D_mth': 'D_Con_M', 'D_yest': 'D_Con_dy','D_wk': 'D_Con_wk','%':'%M','%Y':'%dy'}, inplace=True)

damage_cust_summary = damage_cust_summary.rename({'D_mth': 'D_Con_M', 'D_wk': 'D_Con_Wk' ,'D_yest': 'D_Con_dy','%':'%M','%Y':'%dy'})
#### Edit to change column names as per Jothi Mam's request
finaldf.loc[finaldf.index,'Date'] = datefilter

finaldf.to_csv(r'D:\Data\Damage_report_TopDamageCustomer\Summary\Top_Damage_Customer_Damage_report_'+str(datefilter)+'.csv')
oppath1 = r'D:\Data\Damage_report_TopDamageCustomer\Summary\Top_Damage_Customer_Damage_report_'+str(datefilter)+'.csv'
# In[17]:

#####$$$$ damage_cust_summary_mail = damage_cust_summary['org','dest','D_Con_M','D_Con_Wk','D_Con_dy','%','%Wk','%Y'] ## Before changing column names on 21112016
damage_cust_summary_mail = damage_cust_summary['PARENTCODE','PARENTNAME','D_Con_M','D_Con_Wk','D_Con_dy','%M','%Wk','%dy']
damage_cust_summary_mail #mail body
finaldf_mail = damage_cust_summary_mail.to_dataframe().head(15)
#finaldf_mail.rename(columns={'org':'Origin'}, inplace=True)

finaldf_mail = finaldf_mail.to_string(index=False)



# In[ ]:
filePath = oppath1
def sendEmail(TO = ["sq_spot@spoton.co.in",'abhishek.cv@spoton.co.in','dhiraj.patil@spoton.co.in','mani.kumar@spoton.co.in'],
             #TO = ["vishwas.j@spoton.co.in","shivananda.p@spoton.co.in"],
             #TO = ["mahesh.reddy@spoton.co.in"],
             #BCC =  ["vishwas.j@spoton.co.in","shivananda.p@spoton.co.in"],
             CC =  ["sqtf@spoton.co.in"],
             #CC =  ["mahesh.reddy@spoton.co.in"],
             BCC =  ["mahesh.reddy@spoton.co.in"],
            #FROM="mis.ho@spoton.co.in"):
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
    #HOST = "smpt.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DEPOTWISE OPS Bucket Stock  - "+ str(datefilter)
    msg["Subject"] = "Top Damage Customers Report - "+ str(datefilter)
    body_text = """
    Dear All,
    
    This report gives the Damage(Both internal as well as Bad Pod (Union)) trendline for the customers with high damage cases    
    
    PFB the Damage Report for Top Damage customers as of """ + str(datefilter) +"""
    
    Overall reported Transhipment Damage %-ge for last 30 days = """ +str(shortperc_30)+""" %
    Overall reported Transhipment Damage %-ge for last 7 days = """ +str(shortperc_7)+""" %
    Overall reported Transhipment Damage %-ge for yesterday = """ +str(shortperc_y)+""" %
    
"""+str(finaldf_mail)+"""
     
    Note: 
    D_Con_M : No of cons updated Damage status during last 30 days
    %M : % Of Total pickup cons updated as Damage in the last 30 days    
    D_Con_Wk : No of cons updated Damage status during last 7 days
    %Wk : % Of Total pickup cons updated as Damage in the last 7 days    
    D_Con_dy : No of cons updated Damage status yesterday
    %dy : % Of Total pickup cons updated as Damage yesterday  
    For Damage and Badpod Conwise data use below links:

    http://spoton.co.in/downloads/IEP_DAMAGE_DATA_TO_SQ/IEP_DAMAGE_DATA_TO_SQ.csv
    http://spoton.co.in/downloads/IE_BADPOD_DATA_TO_SQ/IE_BADPOD_DATA_TO_SQ.csv
    """
    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    #server.login("mis.ho@spoton.co.in", "Mis@2019")
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
#print('Email sent')


