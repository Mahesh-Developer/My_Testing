
# coding: utf-8

# In[1]:

import pandas as pd
from datetime import datetime, date, timedelta
import pyodbc
from sqlalchemy import create_engine, MetaData, Table, select
import os
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from pandas import ExcelWriter
from email import encoders
import Utilities
# In[2]:

##pmdadhoc = pd.read_csv(r'PMD_ADHOC.csv')
#pmddatafull = pd.read_csv(r'PMD.csv')

# 






query=("""SELECT CASE WHEN PUDTYPE = 'ADHOC'   

                          AND (( A.MKT_SBA_APPLICABLE = 'Y'   

                                OR A.MKT_HIRE_REASON = 'DEDICATED FOR SINGLE CUSTOMER'   

                                OR A.MKT_HIRE_REASON = 'NSL SHIPMENT'   

                                OR A.MKT_HIRE_REASON = 'LATE NIGHT/EARLY MORNING'   

                              )   

                          OR ( A.SENDERCODE = '000119837'    

                               OR A.SENDERCODE = '000118040'   

                               OR A.SENDERCODE = '000118041'   

                               OR A.SENDERCODE = '000119721'   

                               OR A.SENDERCODE = '000120083'   

                             )) THEN 'ADHOC-Special'   

                     ELSE PUDTYPE   

                END PUDTYPE_STATUS ,a.* FROM dbo.tblPUDYestMtdData  a  WITH (NOLOCK)""")
print ('yes')
pmddatafull=pd.read_sql(query,Utilities.cnxn)
#pmddatafull = pd.read_csv(r'http://spoton.co.in/downloads/PMD/PMD.csv')
pmddatafull.rename(columns={'DATE':'DATE2','PUDTYPE_STATUS':'PUDTYPE2','REGION':'REGION2','DEPOT':'DEPOT2','AREA':'AREA2','BRANCH_CODE':'BRANCH_CODE2','ACT_WT':'ACT_WT2','COST':'COST2'},inplace=True)


# In[3]:

def datestring(x):
    try:
        fulldate = datetime.strptime(x,'%d-%m-%Y %H:%M')
    except:
        fulldate = datetime.strptime(x,'%d %b %Y %H:%M')
    return fulldate.date()

#pmddatafull['Date'] = pmddatafull.apply (lambda x:datestring (x['DATE2']),axis=1)

pmddatafull['Date'] = pmddatafull['DATE2'].dt.date
# In[4]:
print (len(pmddatafull))
yesterday = date.today() - timedelta(days=1)
yesterday


# In[5]:

pmddata_yest = pmddatafull[pmddatafull['Date']>= yesterday]
print len(pmddata_yest)

pmddataadhoc_yest = pmddata_yest[pmddata_yest['PUDTYPE2']=='ADHOC']
len(pmddataadhoc_yest)


# In[6]:

pmdadhoc = pmddatafull[pmddatafull['PUDTYPE2']=='ADHOC']
len(pmddatafull), len(pmdadhoc)


# In[7]:

pmddatafullgrp = pmddatafull.groupby(['REGION2','DEPOT2','AREA2','BRANCH_CODE2','Date']).agg({'ACT_WT2':sum}).reset_index()


# In[8]:

pmdadhocgrp = pmdadhoc.groupby(['REGION2','DEPOT2','AREA2','BRANCH_CODE2','Date']).agg({'ACT_WT2':sum,'COST2':sum,'MKT_SBA_AMT':sum,'BAVEHNO':lambda x: x.nunique()}).reset_index()


# In[9]:

#pmdadhocgrp.to_csv(r'pmdadhocgrp.csv')
#pmddatafullgrp.to_csv(r'pmddatafullgrp.csv')


# In[10]:

pmdadhoc_merge = pd.merge(pmdadhocgrp,pmddatafullgrp,suffixes=['_Adhoc','_Full'],on=['REGION2','DEPOT2','AREA2','BRANCH_CODE2','Date'],how='left')


# In[11]:

pmdadhoc_merge['NET_COST'] = pmdadhoc_merge.apply(lambda x:x['COST2']-x['MKT_SBA_AMT'],axis=1)


# In[12]:

pmdadhoc_merge['%WT_in_Market'] = pmdadhoc_merge.apply(lambda x:pd.np.round((x['ACT_WT2_Adhoc']/x['ACT_WT2_Full'])*100.0,2),axis=1)


# In[13]:

pmdadhoc_merge['CPK'] = pmdadhoc_merge.apply(lambda x:pd.np.round(x['COST2']/x['ACT_WT2_Adhoc'],2),axis=1)
pmdadhoc_merge['NET_CPK'] = pmdadhoc_merge.apply(lambda x:pd.np.round(x['NET_COST']/x['ACT_WT2_Adhoc'],2),axis=1)


# In[14]:

pmdadhoc_merge_pivot = pmdadhoc_merge.pivot_table(index=['REGION2','DEPOT2','AREA2','BRANCH_CODE2'],columns=['Date'],values=['MKT_SBA_AMT','COST2','BAVEHNO','ACT_WT2_Adhoc','ACT_WT2_Full','NET_COST','%WT_in_Market'],aggfunc=pd.np.mean)


# In[15]:

pmdadhoc_merge.to_csv(r'D:\Data\Market_usage_report\Summary_daywise\Market_usage_report_'+str(yesterday)+'.csv')
#pmdadhoc_merge_pivot.to_csv(r'pmdadhoc_merge_pivot.csv')


# ### For MTD

# In[16]:

pmddatafullgrp_mtd = pmddatafull.groupby(['REGION2','DEPOT2','AREA2','BRANCH_CODE2']).agg({'ACT_WT2':sum}).reset_index()
pmdadhocgrp_mtd = pmdadhoc.groupby(['REGION2','DEPOT2','AREA2','BRANCH_CODE2','Date']).agg({'ACT_WT2':sum,'COST2':sum,'MKT_SBA_AMT':sum,'BAVEHNO':lambda x: x.nunique(),'MarketHireReqId':lambda x: x.nunique()}).reset_index()

pmdadhocgrp_mtd = pmdadhocgrp_mtd.groupby(['REGION2','DEPOT2','AREA2','BRANCH_CODE2']).agg({'ACT_WT2':sum,'COST2':sum,'MKT_SBA_AMT':sum,'BAVEHNO':sum,'MarketHireReqId':sum}).reset_index()

pmdadhoc_merge_mtd = pd.merge(pmdadhocgrp_mtd,pmddatafullgrp_mtd,suffixes=['_Adhoc','_Full'],on=['REGION2','DEPOT2','AREA2','BRANCH_CODE2'],how='left')
pmdadhoc_merge_mtd['NET_COST'] = pmdadhoc_merge_mtd.apply(lambda x:x['COST2']-x['MKT_SBA_AMT'],axis=1)
pmdadhoc_merge_mtd['%WT_in_Market'] = pmdadhoc_merge_mtd.apply(lambda x:pd.np.round((x['ACT_WT2_Adhoc']/x['ACT_WT2_Full'])*100.0,2),axis=1)
pmdadhoc_merge_mtd['CPK'] = pmdadhoc_merge_mtd.apply(lambda x:pd.np.round(x['COST2']/x['ACT_WT2_Adhoc'],2),axis=1)
pmdadhoc_merge_mtd['NET_CPK'] = pmdadhoc_merge_mtd.apply(lambda x:pd.np.round(x['NET_COST']/x['ACT_WT2_Adhoc'],2),axis=1)


# In[17]:

#pmdadhoc_merge_mtd.to_csv(r'pmdadhoc_merge_mtd.csv')


# ### For Yesterday

# In[18]:

pmddatafullgrp_yest = pmddata_yest.groupby(['REGION2','DEPOT2','AREA2','BRANCH_CODE2']).agg({'ACT_WT2':sum}).reset_index()
pmdadhocgrp_yest = pmddataadhoc_yest.groupby(['REGION2','DEPOT2','AREA2','BRANCH_CODE2']).agg({'ACT_WT2':sum,'COST2':sum,'MKT_SBA_AMT':sum,'BAVEHNO':lambda x: x.nunique(),'MarketHireReqId':lambda x: x.nunique()}).reset_index()

pmdadhocgrp_yest = pmdadhocgrp_yest.groupby(['REGION2','DEPOT2','AREA2','BRANCH_CODE2']).agg({'ACT_WT2':sum,'COST2':sum,'MKT_SBA_AMT':sum,'BAVEHNO':sum,'MarketHireReqId':sum}).reset_index()

pmdadhoc_merge_yest = pd.merge(pmdadhocgrp_yest,pmddatafullgrp_yest,suffixes=['_Adhoc','_Full'],on=['REGION2','DEPOT2','AREA2','BRANCH_CODE2'],how='left')
pmdadhoc_merge_yest['NET_COST'] = pmdadhoc_merge_yest.apply(lambda x:x['COST2']-x['MKT_SBA_AMT'],axis=1)
pmdadhoc_merge_yest['%WT_in_Market'] = pmdadhoc_merge_yest.apply(lambda x:pd.np.round((x['ACT_WT2_Adhoc']/x['ACT_WT2_Full'])*100.0,2),axis=1)
pmdadhoc_merge_yest['CPK'] = pmdadhoc_merge_yest.apply(lambda x:pd.np.round(x['COST2']/x['ACT_WT2_Adhoc'],2),axis=1)
pmdadhoc_merge_yest['NET_CPK'] = pmdadhoc_merge_yest.apply(lambda x:pd.np.round(x['NET_COST']/x['ACT_WT2_Adhoc'],2),axis=1)

#exit(0)
# In[19]:
with ExcelWriter(r'D:\Data\Market_usage_report\All\Market_usage_report_'+str(yesterday)+'.xlsx') as writer:
    pmdadhoc_merge.to_excel(writer, sheet_name='Daywise',engine='xlsxwriter')
    pmdadhoc_merge_mtd.to_excel(writer, sheet_name='MTD',engine='xlsxwriter')
    pmdadhoc_merge_yest.to_excel(writer, sheet_name='YESTERDAY',engine='xlsxwriter')

pathformail = r'D:\Data\Market_usage_report\All\Market_usage_report_'+str(yesterday)+'.xlsx'

filePath = pathformail
def sendEmail(#TO = ["supratim@iepfunds.com","rajeesh.vr@spoton.co.in"],
            #TO = ["ops.hub.delh.1@spoton.co.in", "krishan.kaushik@spoton.co.in", "krishna.kumar.bhardwaj@spoton.co.in","Cnm@Spoton.Co.In","Raghavendra.Rao@Spoton.Co.In"],
            #TO = ["vishwas.j@spoton.co.in"],
            TO = ["goutam.barik@spoton.co.in"],
            #CC = ["supratim@iepfunds.com","pawan.sharma@spoton.co.in","Ankit@iepfunds.com","sqtf@spoton.co.in","shivananda.p@spoton.co.in","prasanna.hegde@spoton.co.in","rajeesh.vr@spoton.co.in","vishwas.j@spoton.co.in"],
            CC = ["mahesh.reddy@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "DELH to SCs - Load Available -"+ str(opfilevar)+"-"+str(opfilevar2)
    msg["Subject"] = "Market Usage report -"+ str(yesterday)
    body_text = """
    Dear All,

    PFA the Market usage details daywise report
    
    """
    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')

