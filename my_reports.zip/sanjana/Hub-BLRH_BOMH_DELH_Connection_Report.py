
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta,datetime
import sys
import Utilities
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

reload(sys).setdefaultencoding("ISO-8859-1")


# In[2]:


# cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")


# # In[3]:


# cursor=cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()
# In[4]:

try:

    query=("""EXEC USP_HUB_OTP_REPORT_SCH 'D' """)
    query


    # In[5]:


    df=pd.read_sql(query,Utilities.cnxn)


    # In[6]:


    area_df=pd.read_excel(r'C:\Users\rajeeshv\Downloads\Rajesh\mahesh\Book8.xlsx')


    # In[7]:


    len(area_df)


    # In[8]:


    area_df.rename(columns={'SC-Code':'NEXT_LOC','Controlling Area':'Controlling Area1'},inplace=True)


    # In[9]:


    df = pd.merge(df, area_df, how='left',
            left_on='NEXT_LOC', right_on='NEXT_LOC')


    # In[10]:


    df.rename(columns={'Controlling Area1':'NEXT LOC'},inplace=True)


    # In[11]:


    len(df)


    # In[12]:


    blrh_df=df[df['HUB']=='BLRH']
    len(blrh_df)


    # In[13]:


    pivot_blrh_df2=pd.pivot_table(blrh_df,index=['HUB','NEXT LOC'],columns=['FLAG'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total')


    # In[14]:


    pivot_blrh_df2=pivot_blrh_df2.replace([-np.inf,np.inf],np.nan).fillna(0).astype(int)


    # In[15]:


    #hub performance for BOMH
    pivot_blrh_df2[('DOCKNO','%')]=(pivot_blrh_df2[('DOCKNO','SUCCESS')]*100/pivot_blrh_df2[('DOCKNO','Total')]).replace([-np.inf,np.inf],np.nan).fillna(0).astype(int).astype(str)+'%'


    # In[16]:


    pivot_blrh_df3=pivot_blrh_df2.fillna(0)


    # In[17]:


    pivot_blrh_df3


    # In[18]:


    bomh_df=df[df['HUB']=='BOMH']


    # In[19]:


    len(bomh_df)


    # In[20]:


    pivot_bomh_df2=pd.pivot_table(bomh_df,index=['HUB','NEXT LOC'],columns=['FLAG'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total')


    # In[21]:


    pivot_bomh_df2=pivot_bomh_df2.replace([-np.inf,np.inf],np.nan).fillna(0).astype(int)


    # In[22]:


    #hub performance for BOMH
    pivot_bomh_df2[('DOCKNO','%')]=(pivot_bomh_df2[('DOCKNO','SUCCESS')]*100/pivot_bomh_df2[('DOCKNO','Total')]).replace([-np.inf,np.inf],np.nan).fillna(0).astype(int).astype(str)+'%'


    # In[23]:


    pivot_bomh_df3=pivot_bomh_df2.fillna(0)


    # In[24]:


    pivot_bomh_df3


    # In[25]:


    delh_df=df[df['HUB']=='DELH']


    # In[26]:


    len(delh_df)


    # In[27]:


    pivot_delh_df2=pd.pivot_table(delh_df,index=['HUB','NEXT LOC'],columns=['FLAG'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total')


    # In[28]:


    pivot_delh_df2=pivot_delh_df2.replace([-np.inf,np.inf],np.nan).fillna(0).astype(int)


    # In[29]:


    #hub performance for DELH
    pivot_delh_df2[('DOCKNO','%')]=(pivot_delh_df2[('DOCKNO','SUCCESS')]*100/pivot_delh_df2[('DOCKNO','Total')]).replace([-np.inf,np.inf],np.nan).fillna(0).astype(int).astype(str)+'%'


    # In[30]:


    pivot_delh_df3=pivot_delh_df2.fillna(0)


    # In[31]:


    pivot_delh_df3


    # In[32]:


    #C:\Users\S2769MAH\Downloads\SQ\sreedhar\Origin_Feeder_Connection_report_'+str(date2)+'.xlsx') as writer:
    from pandas import ExcelWriter
    with ExcelWriter(r'D:\Data\ODA_Loads_Ton_wise\BLRH_BOMH&DELH_Hub_performance_report.xlsx') as writer:
        pivot_blrh_df3.to_excel(writer,engine='xlsxwriter',sheet_name='BLRH Summary')
        pivot_bomh_df3.to_excel(writer,engine='xlsxwriter',sheet_name='BOMH Summary')
        pivot_delh_df3.to_excel(writer,engine='xlsxwriter',sheet_name='DELH Summary')
        df.to_excel(writer,engine='xlsxwriter',sheet_name='Data')
        
        
        


    # In[33]:


    filepath=r'D:\Data\ODA_Loads_Ton_wise\BLRH_BOMH&DELH_Hub_performance_report.xlsx'


    # In[34]:


    import numpy as np
    import pandas as pd
    import itertools
    import json
    from pandas import ExcelWriter
    from pandas import pivot_table
    from datetime import datetime
    import os
    import ftplib
    import traceback

    oppath1=filepath
    #FTP Upload starts
    print ('Logging in...')
    ftp = ftplib.FTP()  
    ftp.connect('10.109.230.50')  
    print (ftp.getwelcome())
    try:  
        try:  
            ftp.login('HOSQTeam', 'Te@mH0$q')
            print ('login done')
            ftp.cwd('Auto_reports')  
            #ftp.cwd('FIFO')
            # move to the desired upload directory  
            print ("Currently in:", ftp.pwd()) 
            print ('Uploading...')  
            fullname = oppath1
            name = os.path.split(fullname)[1]  
            f = open(fullname, "rb")  
            ftp.storbinary('STOR ' + name, f)  
            f.close()  
            print ("OK"  )
            print ("Files:")  
            print (ftp.retrlines('LIST'))
        finally:  
            print ("Quitting...")
            ftp.quit()  
    except:  
        traceback.print_exc()


    # In[35]:


    from datetime import date,timedelta
    d=date.today()
    print (type(d))
    date1=d-timedelta(1)
    date2=datetime.strftime(date1,'%d-%b-%y')


    # In[36]:




    from_addr = 'mis.ho@spoton.co.in'
    to_addr = ['rajesh.debnath@spoton.co.in','dinesh.kumar.sharma@Spoton.co.in']
    #to_addr = ['maheshmahesh11464@gmail.com','mahesh.reddy@spoton.co.in']
    cc_addr=['abhik.mitra@spoton.co.in','jothi.menon@spoton.co.in','Rajesh.kumar@spoton.co.in','shivananda.p@spoton.co.in','prafulla.masurkar@spoton.co.in','vijay.verma@spoton.co.in','sharanagouda.biradar@spoton.co.in','sreedhar.m@spoton.co.in','SQ_spot@spoton.co.in','anitha.thyagarajan@spoton.co.in']
    #cc_addr = ['rajesh.mp@spoton.co.in']


    username = 'mis.ho@spoton.co.in'
    password = 'Raj@spot12.mp'

    msg = MIMEMultipart()

    msg['From'] = from_addr
    # msg['To'] = ', '.join(to_addr)
    msg['cc'] = ', '.join(to_addr)
    msg['bcc'] = ', '.join(cc_addr)
    msg['Subject'] = 'Hub-BLRH, BOMH and DELH Connection performance of'+str(date2)
    html='''<html>
    <h4>Dear All,</h4>
    <p>Please find attached BOMH and DELH Hub connection performance report for $date.</p>
    <h5>Summary</h5>
    <p style="color:red;">BLRH-CONNECTION PERFORMANCE</p>
    </html>'''
    html2='''
    <p style="color:red;">BOMH-CONNECTION PERFORMANCE</p>'''
    html3='''
    <p style="color:red;">DELH-CONNECTION PERFORMANCE</p>
    '''

    html5='''
    <h5> Note : For data please click on the below link: </h5>
    <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/BLRH_BOMH&DELH_Hub_performance_report.xlsx"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/BLRH_BOMH&DELH_Hub_performance_report.xlsx</p></b>
    '''
    html4='''
    <p style="color:red;"> % Wise Performance</p>'''
    html1='''<h5>Thanks & Regards</h5></b>
    <h5>HO-SQ</h5>'''
        
    #  msg.attach(part10)
    s = Template(html).safe_substitute(date=date2)
    report=""
    report+=s
    report+='<br>'
    # report+='<br>'
    report+='<br>'+pivot_blrh_df3.to_html()+'<br>'
    report+='<br>'
    report+=html2
    report+='<br>'+pivot_bomh_df3.to_html()+'<br>'
    report+='<br>'
    report+=html3
    report+='<br>'
    report+='<br>'+pivot_delh_df3.to_html()+'<br>'
    # report+=html4
    # report+='<br>'
    # report+='<br>'+per_after_boma1.to_html()+'<br>'
    report+='<br>'
    report+=html5
    report+='<br>'
    report+=html1
    abc=MIMEText(report,'html')
    msg.attach(abc)
    part=MIMEBase('application','octet-stream')
    # part1=MIMEBase('application','octet-stream')
    part.set_payload(open(filepath,'rb').read())
    # part1.set_payload(open(filepath1,'rb').read())
    encoders.encode_base64(part)
    # Encoders.encode_base64(part1)
    part.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath))
    # part1.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath1))
    #msg.attach(part)
    # msg.attach(part1)

    # server = smtplib.SMTP('smtp.spoton.co.in',587)
    # server.ehlo()
    # server.starttls()
    # server.ehlo()
    # server.login('mis.ho@spoton.co.in','Mis@2019')
    # server.sendmail(from_addr,to_addr+cc_addr,msg.as_string())
    # print ('mail sent succesfully')
    # server.quit()

    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(from_addr,to_addr+cc_addr, msg.as_string())
    print ('mail sent succesfully')
    server.quit()

except:

  TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in']  
  CC=['mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "ERROR Report" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in Hub-BLRH, BOMH and DELH Connection performance of'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO+CC, msg.as_string())
  server.quit()

