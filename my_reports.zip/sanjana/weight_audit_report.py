
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
from pymongo import MongoClient
from string import Template
import smtplib
import os
from datetime import datetime, timedelta
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import smtplib
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os


# In[2]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()


# In[6]:


start_date=datetime.strftime(datetime.now()-timedelta(days=1),'%Y-%m-%d')+' 00:00:00'
enddate=datetime.strftime(datetime.now()-timedelta(days=1),'%Y-%m-%d')+' 23:59:00'
start_date,enddate


# In[7]:


query=("EXEC dbo.USP_WEIGHT_AUDIT_REPORT_SQ '{0}','{1}'").format(start_date,enddate)


# In[8]:


df=pd.read_sql(query,cnxn)


# In[9]:


len(df)


# In[10]:


required_cols=df.columns.tolist()


# In[11]:


def getAuditWt(actwt,volwt):
    if actwt>volwt:
        return actwt
    else:
        return volwt


# In[12]:


df['Audited_Charge_Wt']=df.apply(lambda x:getAuditWt(x['AuditWt'],x['AUDIT_VOL_WT']),axis=1)


# In[13]:


def getWtDiff(x,y):
    try:
        val=pd.np.round((x-y)*100.0/y,0)
        return val
    except:
        return 0


# In[14]:


df['%Diff_Audit_System_Wt']=df.apply(lambda x: getWtDiff(x['AuditWt'],x['ACTUWT']),axis=1)


# In[15]:


df['%Diff_Audit_System_Vol_Wt']=df.apply(lambda x:getWtDiff(x['AUDIT_VOL_WT'],x['VOL_WT']),axis=1)


# In[16]:


df['%Diff_Audit_System_Charge_Wt']=df.apply(lambda x:getWtDiff(x['Audited_Charge_Wt'],x['CHRGWT']),axis=1)


# In[17]:


df['Diff_Audit_System_Actual_Wt']=pd.np.round(df['AuditWt']-df['ACTUWT'],1)
df['Diff_Audit_System_Vol_Wt']=pd.np.round(df['AUDIT_VOL_WT']-df['VOL_WT'],1)
df['Diff_Audit_System_Charge_Wt']=pd.np.round(df['Audited_Charge_Wt']-df['CHRGWT'],1)


# In[ ]:


## Report2


# In[18]:


rp1_df=df[(df['Diff_Audit_System_Charge_Wt']>0.0)&(df['Diff_Audit_System_Charge_Wt']<5.0)&(df['Diff_Audit_System_Actual_Wt']>10)]


# In[19]:


rp1_df=rp1_df[rp1_df['Diff_Audit_System_Actual_Wt']>10]


# In[20]:


first_summary=rp1_df


# In[21]:


first_summary


# In[ ]:


##Report3


# In[22]:


def getDf(x,y):
    if (x>25) or (y>10):
        return True
    else:
        return False


# In[23]:


df['Check']=df.apply(lambda x:getDf(x['Diff_Audit_System_Charge_Wt'],x['%Diff_Audit_System_Charge_Wt']),axis=1)


# In[24]:


rp2_df=df[df['Check']==True]
len(rp2_df)


# In[25]:


del rp2_df['Check']


# In[26]:


second_summary=rp2_df


# In[27]:


def getDf(x,y):
    if (x<-25) or (y<-5):
        return True
    else:
        return False


# In[28]:


df['Check1']=df.apply(lambda x:getDf(x['Diff_Audit_System_Charge_Wt'],x['%Diff_Audit_System_Charge_Wt']),axis=1)


# In[29]:


rp3_df=df[df['Check1']==True]
len(rp3_df)


# In[30]:


third_summary=rp3_df


# In[31]:
todate=datetime.strftime(datetime.now(),'%Y-%m-%d')
todate

writer = pd.ExcelWriter(r'D:\Data\weight_audit_report\Weight_Audit_Report'+str(todate)+'.xlsx', engine='xlsxwriter')
df.to_excel(writer,sheet_name='Data')
first_summary.to_excel(writer,sheet_name='actual weight overstated')
second_summary.to_excel(writer,sheet_name='CHG weight overstated')
third_summary.to_excel(writer,sheet_name='CHG weight understated')
writer.save()


writer = pd.ExcelWriter(r'D:\Data\weight_audit_report\Weight_Audit_Report.xlsx', engine='xlsxwriter')
df.to_excel(writer,sheet_name='Data')
first_summary.to_excel(writer,sheet_name='actual weight overstated')
second_summary.to_excel(writer,sheet_name='CHG weight overstated')
third_summary.to_excel(writer,sheet_name='CHG weight understated')
writer.save()

# In[32]:





# In[33]:


filepath=r'D:\Data\weight_audit_report\Weight_Audit_Report.xlsx'


# In[36]:


TO=['krishna.chandrasekar@spoton.co.in','jothi.menon@spoton.co.in']
# TO=['anitha.thyagarajan@spoton.co.in']
CC=['shivananda.p@spoton.co.in','mahesh.reddy@spoton.co.in']
# CC=['mahesh.reddy@spoton.co.in']
FROM="reports.ie@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
# msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "weight audit report " + '- ' +todate
html3='''
<h5> To download the data , Please click the link below </h5>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Hub_Perfor_Data.csv"</a>http://spoton.co.in/downloads/IEProjects/ETA/Hub_Perfor_Data.csv</p></b>

<h5> To download the condata of DEPS/excluded cons , Please click the link below </h5>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Hub_Perfor_DEPS_condata.csv"</a>http://spoton.co.in/downloads/IEProjects/ETA/Hub_Perfor_DEPS_condata.csv</p></b>

'''
report=""
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='PFA weight audit report  '+todate
report+='<br>'
#report+='For Data and Summary use attached files.'
#report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)

part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

# part2 = MIMEBase('application', "octet-stream")
# part2.set_payload( open(filepath2,"rb").read() )
# encoders.encode_base64(part2)
# part2.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath2))
# msg.attach(part2)



server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("spoton.net.in", "Star@123#")
server.login('spoton.net.in', 'Star@123#')
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()

