
# coding: utf-8

# In[1]:

import pandas as pd
from datetime import datetime, timedelta
import numpy as np
from sqlalchemy import *
import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import sys
import Utilities
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

reload(sys).setdefaultencoding("ISO-8859-1")

#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.87;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
#cursor = cnxn.cursor()
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
#cursor = cnxn.cursor()

query = ("""
        EXEC USP_CLOSINGSTOCK_REPORT_1HR_IE
        """)
df = pd.read_sql(query, Utilities.cnxn)
df.rename(columns={'DRS_PREPARED':'DRS PREPARED','DEST_DEPOT':'DEST DEPOT',"TimestateDate":'Timestate Date',"ARRV_AT_DEST_SC":'ARRV AT DEST SC',"ConStatusCode":'Con Status Code',"CON_BLOCKED_FOR_ODA_PIN_ISSUES":'CON BLOCKED FOR ODA PIN ISSUES',"CON_BLOCKED_FOR_PAY_ISSUES":'CON BLOCKED FOR PAY ISSUES',"CON_BLOCKED_FOR_DEMURRAGE":'CON BLOCKED FOR DEMURRAGE'},inplace=True)
pd.set_option("display.max_columns",100)
from fuzzywuzzy import fuzz
from fuzzywuzzy import process
#df=pd.read_excel(r'http://spoton.co.in/downloads/OCID_CLOSINGSTOCK_1HR/OCID_CLOSINGSTOCK_1HR.xls')
df["Delay_Hours"]=np.round((df["Timestate Date"]-df["ARRV AT DEST SC"])/np.timedelta64(1, 'h'),0)
df["PARENTCODE"]=df["PARENTCODE"].fillna(0.0).astype(int).astype(str)
df = df.assign(delaygrp=pd.cut(df.Delay_Hours,bins=[-np.inf,24,48,np.inf],labels=['0-24','24-48','48+']))
apnstatcodes=['APT']
ucgstatcodes=['UCG','UG1','UG2','UG3']
depsstatcodes=['DIR','EIR','PIR','SIR','SRD','SRE','SRP','SRS']
ofdstatuscode=['AOD']
addressissues=['CDA','WIA','CNC','CPN']
df["APNCons"]=df.apply(lambda x: True if x["Con Status Code"] in apnstatcodes else False,axis=1)
dff=df[(df["APNCons"]==True)]
dff=dff[(dff["CON BLOCKED FOR ODA PIN ISSUES"]!='YES')&(dff["CON BLOCKED FOR PAY ISSUES"]!='YES')&(dff["CON BLOCKED FOR DEMURRAGE"]!='YES')&(dff["CSGNCD"]!=119721)]
dff['delaycat']=dff['delaygrp'].astype(str)
print (dff.columns)
dff["Appointment Date"]=pd.to_datetime(dff["Appointment Date"],format='%d/%m/%Y',errors='coerce')
dff["APN Today"]=dff.apply(lambda x: True if x["Appointment Date"]==pd.to_datetime('today') else False,axis=1)
dff2=dff[(dff["APN Today"]==True)&dff["APNCons"]==True]
total_apt_cons=len(dff2)
dff3=dff2[dff2["DRS_STATUS"]=="NA"]
dff3_open=dff2[dff2["DRS_STATUS"]=="OPEN"]
drs_open=len(dff3_open)
appdf=dff3.pivot_table(index=["DEST DEPOT"],columns=["DRS PREPARED",'delaycat'],values=["DOCKNO"],aggfunc={"DOCKNO":len},margins=True).reset_index().sort_values(("DOCKNO","All"),ascending=False)
appdf=appdf.set_index(("DEST DEPOT",""))#head(2)
print (appdf)
appdf=appdf.fillna(0.0).astype(int)
appdf=appdf.sort_values(("DOCKNO","All"),ascending=False)
topfailinglocation=appdf.index[1]
example=appdf.loc[:,("DOCKNO","All")][0]
example1=appdf.loc[:,("DOCKNO","All")][1]
consgrter48hrs=appdf.values[0][2]
print ('consgrter48hrs',consgrter48hrs)
print ('topfailinglocation',topfailinglocation)
print ('example',example)
print ('example1',example1)
dff3["CSGENM_2"]=dff3["CSGENM"].astype(str).str[0:12]
matchdict={}
choices = dff3["CSGENM_2"].tolist()
knownlist=["Aurobindo","Britannia","Coffee Day","Globus","Prestige","Bharti","Cloudtail","Avenue","Max","Trent","Aditya Birla", "Fine tech","S Chand","Walmart","Bosch","BOROSIL","TATA","Future","Johnson","Uflex","Luxor","Reliable","Freudenberg","BOSCH","Myntra","Reliance","Amazon","Crossword","Metro","Pantaloons","Narendra","Flipkart"]
for i in knownlist:
    for j in process.extract(i,choices,scorer=fuzz.ratio):
        if j[1]>60:
            matchdict.update({j[0]:i})
dff3["CSGENM_2"]=dff3["CSGENM_2"].map(matchdict)
dff3.CSGENM_2.fillna(dff3["CSGENM"].astype(str).str[0:12],inplace=True)
csgnmdf=dff3.pivot_table(index=["CSGENM_2","DEST DEPOT"],values=["DOCKNO"],aggfunc={"DOCKNO":len},margins=True).reset_index().sort_values("DOCKNO",ascending=False)[0:15]

filepath1=r'D:\Data\Appointment Reports\apn.csv'
filepath3=r'D:\Data\Appointment Reports\apn.csv'
try:
    dff3.to_csv(filepath1)
except:
    dff3.to_csv(filepath3)


filePath=r'D:\Data\Appointment Reports\apn.csv'
df.to_csv(r'D:\Data\Appointment Reports\ConWise_APN_Data.csv')
filepathh=r'D:\Data\Appointment Reports\ConWise_APN_Data.csv'
import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback
for i in [filepathh]:
    oppath1=i
    #FTP Upload starts
    print ('Logging in...')
    ftp = ftplib.FTP()  
    ftp.connect('10.109.230.50')  
    print (ftp.getwelcome())
    try:  
        try:  
            ftp.login('HOSQTeam', 'Te@mH0$q')
            print ('login done')
            ftp.cwd('Auto_reports')  
            #ftp.cwd('FIFO')
            # move to the desired upload directory  
            print ("Currently in:", ftp.pwd()) 
            print ('Uploading...')  
            fullname = oppath1
            name = os.path.split(fullname)[1]  
            f = open(fullname, "rb")  
            ftp.storbinary('STOR ' + name, f)  
            f.close()  
            print ("OK"  )
            print ("Files:")  
            print (ftp.retrlines('LIST'))
        finally:  
            print ("Quitting...")
            ftp.quit()  
    except:  
        traceback.print_exc()
from datetime import date,timedelta
todate=date.today()
today_date=datetime.strftime(todate,'%d-%m-%Y')
today_date
#vishwas.j@spoton.co.in
#<p>Total Appointment cons due today, Still DRS in Open : $drs_open</p> 

TO=["sq_spot@spoton.co.in", "aom_spot@spoton.co.in", "dom_spot@spoton.co.in", "rom_spot@spoton.co.in","ganesh.m@spoton.co.in","vinit.tiwari@spoton.co.in"]
#TO=['mahesh.reddy@spoton.co.in']
FROM="reports.ie@spoton.co.in"
CC=["pawan.sharma@spoton.co.in","rajesh.kumar@spoton.co.in","krishna.chandrasekar@spoton.co.in","abhik.mitra@spoton.co.in","jothi.menon@spoton.co.in","sharmistha.majumdar@spoton.co.in"]
BCC=['mahesh.reddy@spoton.co.in']
#CC=['mahesh.reddy@spoton.co.in']
#BCC=['mahesh.reddy@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = "Appointment Cons due Today - Not OFD" + " : " + str(today_date)
html='''<html>
<style>
p
{
  margin:0;
  margin-top: 5px;
  padding:0;
  font-size:17px;
    line-height:20px;
}
</style>
<h4>Dear All,</h4>
<p>Please action on the following:</p>
<h4>Appointment Cons due today, not OFD yet:</h4>
<p>Total Appointment Cons due today: $total_apt_cons</p>

<p>Total Appointment cons due today, not OFD is:$example, of which cons lying at SC for >48 hours is $consgrter48hrs</p>
<p>Top Failure location is :$topfailinglocation</p>
<h4>Depot-wise Break-up:</h4>
<p>Eg: $example1 Appointment cons at $topfailinglocation is due today, but not OFD yet.
</html>'''

html3='''
<h4>Top consignees with Appointments due today, not OFD yet:</h4>

'''
html5='''
<h5> Note : For data please open below link.</h5>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/ConWise_APN_Data.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/ConWise_APN_Data.csv</p></b>
'''

s = Template(html).safe_substitute(drs_open=drs_open,total_apt_cons=total_apt_cons,date=today_date,example=example,topfailinglocation=topfailinglocation,example1=example1,consgrter48hrs=consgrter48hrs)
report=""
report+=s
report+='<br>'
report+='<br>'+appdf.to_html()+'<br>'
report+=html3
report+='<br>'+csgnmdf.to_html()+'<br>'
report+=html5
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filePath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()


# except:
#   TO=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
#   FROM="mahesh.reddy@spoton.co.in"
#   msg = MIMEMultipart()
#   msg["From"] = FROM
#   msg["To"] = ",".join(TO)
#   #msg["CC"] = ",".join(CC)
#   #msg["BCC"] = ",".join(BCC)
#   #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
#   msg["Subject"] = "ERROR Report" 
#   report=""
#   report+='Hi,'

#   report+='<br>'
#   report+='There was some error in Appointment Cons due today - Not OFD'
#   report+='<br>'

#   abc=MIMEText(report.encode('utf-8'),'html')
#   msg.attach(abc)
#   server=smtplib.SMTP('smtp.sendgrid.net', 587)
#   server.ehlo()
#   server.starttls()
#   server.ehlo()
#   server.login("spoton.net.in", "Star@123#")
#   failed = server.sendmail(FROM, TO, msg.as_string())
#   server.quit()






# import nexmo

# client = nexmo.Client(key='a8343db4', secret='834e2cdd2c489e2e')
# client.send_message({
#     'from': 'mahesh',
#     'to': [+919110235325,+918792172625],
#     'text': 'Appointment Cons due today - Not OFD Was Executed Successfully',
# })