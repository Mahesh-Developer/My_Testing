
# coding: utf-8

# In[1]:

import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
import calendar
#import datetime
from pandas import ExcelWriter
from IPython.display import HTML
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import os
import ftplib
import traceback
import Utilities

import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter


# In[2]:
now = datetime.now()
today = now.strftime("%a")
print today

stdyest = pd.io.excel.read_excel(r'D:\Data\eta_rank\Total_DE.xlsx','STD')
odayest = pd.io.excel.read_excel(r'D:\Data\eta_rank\Total_DE.xlsx','ODA')
totalyest = pd.io.excel.read_excel(r'D:\Data\eta_rank\Total_DE.xlsx','Total')
#stdtoday = pd.io.excel.read_excel(r'C:\Data\Delivery_efficiency\for_totaldeleffi\Delivery_Efficiency_2015-11-28_Total.xlsx','STD')
#odatoday = pd.io.excel.read_excel(r'C:\Data\Delivery_efficiency\for_totaldeleffi\Delivery_Efficiency_2015-11-28_Total.xlsx','ODA')

stdtoday = pd.read_csv(r'D:\Data\eta_rank\STD_DE.csv')
odatoday = pd.read_csv(r'D:\Data\eta_rank\ODA_DE.csv')


##$$ For Duedate cons in TOTAL DELIVERY EFFICIENCY

opfilevar =date.today() - timedelta(hours=24)
opfilevarhours = datetime.now() - timedelta(hours=24)
#yesterday = datetime.datetime.today() - datetime.timedelta (days=1) 
new_period=opfilevarhours.replace(hour=12, minute=0).strftime ('%Y-%m-%d %H:%M:%S')
print new_period

openingstock = pd.io.excel.read_excel(r'http://10.109.230.50/downloads/OCID/OCID.xls','OPENING STOCK')
closingstockfull = pd.io.excel.read_excel(r'http://10.109.230.50/downloads/OCID/OCID.xls','CLOSING STOCK')


### To exclude Liberty FOC cons
liblist = [000119721.0]
openingstock = openingstock[~(openingstock['CSGNCD'].isin(liblist))]
openingstock = openingstock[~(openingstock['CSGECD'].isin(liblist))]
### To exclude Liberty FOC cons

## To Exclude Reliance project cons
projectparentcodesexclist = [000117991.0,000118040.0,000118041.0,000118042.0,000118043.0,000118075.0,000111007.0,000114381.0]
openingstock = openingstock[~(openingstock['PARENTCODE'].isin(projectparentcodesexclist))]

projectconsgcd = [000117991.0,000118040.0,000118041.0,000118043.0,000111007.0,000118042.0,000118075.0,000114381.0]
openingstock = openingstock[~(openingstock['CSGNCD'].isin(projectconsgcd))]

openingstock = openingstock[~(openingstock['CSGECD'].isin(projectconsgcd))]


## Exclude Srinagar due to Embargo. Included on 19-12-2016
#excludebranchlist = ['SXRF']
#openingstock = openingstock[~(openingstock['DEST BRCD'].isin(excludebranchlist))]
## Exclude Srinagar due to Embargo. Included on 19-12-2016


## To Exclude Pantaloons
##parentcodesexclist = [000116867.0,000113916.0,000096307.0]

parentcodesexclist = [000116867.0,000118067.0,000118068.0,000108751.0,000118554.0]
#destareaexcludelist = ['BOMA','CCUA'] ## Added BLRA on 07-11-2016 and deleted BLRA on 11-11-2016, Deleted CCUA on 23022017
destareaexcludelist = ['BOMA','HYDA'] ## Added HYDA on 27-10-2017
openingstock = openingstock[~((openingstock['PARENTCODE'].isin(parentcodesexclist)) & (openingstock['DEST AREA'].isin(destareaexcludelist)))]

## To Exclude Pantaloons,

##$$ Closing stock for ODA Free cons
closingstockcomplete = pd.io.excel.read_excel(r'http://10.109.230.50/downloads/OCID/OCID.xls','CLOSING STOCK')
##$$ Closing stock for ODA Free cons


## For Holiday exclusion
holidaymaster = pd.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\Holiday_list_2016_test.csv')

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

holidayquery = ("""
        select * from tblYearlyHolidayMst with (nolock) where HDAY_DATE>'2016-01-01'
        """)

holidaymaster = pd.read_sql(holidayquery, Utilities.cnxn)
print len(holidaymaster)

def datestring(x):
    try:
        x = str(x)
        fulldate = datetime.strptime(x,'%Y-%m-%d %H:%M:%S')
        return fulldate
    except:
        x = str(x)
        fulldate = datetime.strptime(x,'%d-%m-%Y %H:%M')
        return fulldate


holidaymaster['HDAY_DATE'] = holidaymaster.apply(lambda x : datestring(x['HDAY_DATE']),axis=1)
selectdate = now-timedelta(days=1)
selectdate = selectdate.replace(hour=0, minute=0, second=0).strftime('%Y-%m-%d %H:%M:%S')
selectdate = datetime.strptime(selectdate,'%Y-%m-%d %H:%M:%S')
print selectdate,type(selectdate)

holidaylist = holidaymaster['HDAY_DATE']
holidaylist = list(set(holidaylist))

if selectdate in holidaylist:
    print 'Yesterday in holiday list'
    selectdf = holidaymaster[holidaymaster['HDAY_DATE']==selectdate]
    selectdfbrcdlist = selectdf['BRCD'].tolist()
    selectdfbrcdlist = list(set(selectdfbrcdlist))
    selectdfarealist = selectdf['ControlArea'].tolist()
    selectdfarealist = list(set(selectdfarealist))
    print selectdfbrcdlist
    print selectdfarealist
    
    openingstock = openingstock[~(openingstock['DEST BRCD'].isin(selectdfbrcdlist))]
    openingstock = openingstock[~(openingstock['DEST AREA'].isin(selectdfarealist))]
    
else:
    selectdfbrcdlist = []
    selectdfarealist = []
    print 'Yesterday not in holiday list'

## For Holiday exclusion


ignorestatuscodelist = ['UCG','SSC','UG1','UG2','UG3','SHS']
openingstock=openingstock[~openingstock['Con Status Code'].isin(ignorestatuscodelist)]
closingstockfull=closingstockfull[~closingstockfull['Con Status Code'].isin(ignorestatuscodelist)]
closingstockfull = closingstockfull[closingstockfull['DEL LOCATION TYPE']=='STD']


def datetimesplit(x):
    fulldate = datetime.strptime(x.split(' '),'%d-%m-%Y %H:%M:S')
    return fulldate
    
closingstockduecons = closingstockfull[closingstockfull['DUE DATE']==opfilevar]
closingstockduecons['ARRV_AT_DEST_SC'] = closingstockduecons.apply(lambda x:x['ARRV AT DEST SC'],axis=1)
closingarriv12 = closingstockduecons[closingstockduecons['ARRV_AT_DEST_SC']<=new_period]

closingarriv12free = closingarriv12[closingarriv12['Is Free Con']=='YES']

closingarriv12freegrp = closingarriv12free.groupby(['DEST AREA']).agg({'DOCKNO':len}).reset_index()

totalduecons_std = len(closingarriv12)
totalduecons12free_std = len(closingarriv12free)


openingstock = openingstock[openingstock['DEL LOCATION TYPE']=='ODA']
openingstock = openingstock[(openingstock['REPORTDATE MIN ARRVDT']>48)]
openingstocknotdel = openingstock[openingstock['Delivery Status']=='NO']
dueyestopening = openingstocknotdel[openingstocknotdel['DUE DATE']==opfilevar]
odadueconlist = dueyestopening['DOCKNO'].tolist()

odaduecons_closingstock = closingstockcomplete[closingstockcomplete['DOCKNO'].isin(odadueconlist)]
# dueyestopening_free = odaduecons_closingstock[odaduecons_closingstock['Is Free Con']=='YES']

# dueyestopening_freegrp = dueyestopening_free.groupby(['DEST AREA']).agg({'DOCKNO':len}).reset_index()

# totalduecons_oda = len(dueyestopening)
# totalduecons_oda_free = len(dueyestopening_free)

# totalduecons = totalduecons_std + totalduecons_oda
# totaldueconsfree = totalduecons12free_std + totalduecons_oda_free

# closingarriv12freegrp.to_csv(r'D:\Data\DE_Conwise_Stock\closingarriv12freegrp.csv')
# dueyestopening_freegrp.to_csv(r'D:\Data\DE_Conwise_Stock\dueyestopening_freegrp.csv')

# freeconsodastd = pd.merge(closingarriv12freegrp,dueyestopening_freegrp,on='DEST AREA',suffixes = ['_STD_Free','_ODA_Free'],how='outer')
# freeconsodastd = freeconsodastd.fillna(0)
# print freeconsodastd.head()
# freeconsodastd['Total_free'] = freeconsodastd.apply(lambda x:(x['DOCKNO_STD_Free']+x['DOCKNO_ODA_Free']),axis=1)

# cutoffformorefreecons = 0.1*totaldueconsfree
# morefreeconsdestarealist = freeconsodastd[freeconsodastd['Total_free']>=cutoffformorefreecons]['DEST AREA'].tolist()
# morefreeconsdestarealist = [str(x) for x in morefreeconsdestarealist]

# morefreeconslist = freeconsodastd[freeconsodastd['Total_free']>=cutoffformorefreecons]['Total_free'].tolist()
# morefreeconslist = [str(x) for x in morefreeconslist]

# combinedfreeconlist = zip(morefreeconsdestarealist,morefreeconslist)
# ##$$ For Duedate cons in TOTAL DELIVERY EFFICIENCY

# In[3]:

def addstock (x,y,z):
    return x+y+z

def delivered (x,y):
    return x+y

def efficiency (x,y):
    if y>0:
        a = pd.np.round(((x*1.0)*100/y),0)
        return a
    else:
        return 100

def variance (x,y):
    return (x-y)


# In[4]:

columnsop = ['Area','Delivery_Efficiency']
stdyest1 = pd.DataFrame(stdyest,columns=columnsop)
stdyest1=stdyest1.rename(columns={'Delivery_Efficiency':'Delivery_Efficiency_Yday'})

stddf = pd.merge(stdtoday,stdyest1,left_on=['Area'],right_on=['Area'],how='outer')
stddf['Variance_DE']= stddf.apply(lambda x:variance(x['Delivery_Efficiency'],x['Delivery_Efficiency_Yday']),axis=1)
columnsopstd = ['Area','DOCKNO_op','DOCKNO_in','DOCKNO_Delivered','Delivery_Efficiency','Delivery_Efficiency_Yday','Variance_DE','Closing_Stock','Closing_Stock>24hrs','Avg_Cooling_Hrs>24hrs']
stddf = pd.DataFrame(stddf,columns=columnsopstd)
#stddf


# In[5]:

columnsop = ['Area','Delivery_Efficiency']
odayest1 = pd.DataFrame(odayest,columns=columnsop)
odayest1=odayest1.rename(columns={'Delivery_Efficiency':'Delivery_Efficiency_Yday'})

odadf = pd.merge(odatoday,odayest1,left_on=['Area'],right_on=['Area'],how='outer')
odadf['Variance_DE']= odadf.apply(lambda x:variance(x['Delivery_Efficiency'],x['Delivery_Efficiency_Yday']),axis=1)
columnsopoda = ['Area','DOCKNO_open','DOCKNO_Delivered','Delivery_Efficiency','Delivery_Efficiency_Yday','Variance_DE']
odadf = pd.DataFrame(odadf,columns=columnsopoda)
#odadf


# In[6]:

totaldf = pd.merge(stddf,odadf,left_on =['Area'], right_on=['Area'],suffixes = ['_STD','_ODA'],how='outer')
#totaldf = pd.merge(stddf,odadf,left_on =['Area'], right_on=['Area'],suffixes = ['_STD','_ODA'],how='left')
#### For Filling NA as zero

totaldf=totaldf.fillna(0)

#totaldf.to_csv(r'C:\Data\Delivery_efficiency\for_totaldeleffi\test1totalcombine.csv')
totaldf.columns


# In[7]:

totaldf['Total_Stock']= totaldf.apply(lambda x:addstock(x['DOCKNO_op'],x['DOCKNO_in'],x['DOCKNO_open']),axis=1)
totaldf['Total_Delivered']= totaldf.apply(lambda x:delivered(x['DOCKNO_Delivered_STD'],x['DOCKNO_Delivered_ODA']),axis=1)
totaldf['Delivery_Efficiency']= totaldf.apply(lambda x:efficiency(x['Total_Delivered'],x['Total_Stock']),axis=1)

columnsoptotaldf=['Area','Total_Stock','Total_Delivered','Delivery_Efficiency']
totaldf = pd.DataFrame(totaldf,columns=columnsoptotaldf)

#columnsop=['Area','Total_Stock','Total_Delivered','Delivery_Efficiency']
##closingstock = closingstock.drop(['Validity_Status', 'FreeCon_Status', 'Trans_Validity', 'Code_Validity', 'ATB_CV1_Status'], axis=1)
columnsopy=['Area','Delivery_Efficiency']
totalyest = pd.DataFrame(totalyest,columns=columnsopy)
totalyest1 =totalyest.rename(columns={'Delivery_Efficiency':'Delivery_Efficiency_Yday'})


totaldfwithvar = pd.merge(totaldf,totalyest1,left_on =['Area'], right_on=['Area'],how='outer')
columnsop=['Area','Total_Stock','Total_Delivered','Delivery_Efficiency','Delivery_Efficiency_Yday']
totaldfwithvar1 = pd.DataFrame(totaldfwithvar,columns=columnsop)
#totaldfwithvar1.to_csv(r'C:\Data\Delivery_efficiency\for_totaldeleffi\test1totalcombine.csv')

totaldfwithvar1['Variance_DE'] = totaldfwithvar1.apply(lambda x:variance(x['Delivery_Efficiency'],x['Delivery_Efficiency_Yday']),axis=1) 
columnsop=['Area','Total_Stock','Total_Delivered','Delivery_Efficiency','Delivery_Efficiency_Yday','Variance_DE']
totaldfwithvar2 = pd.DataFrame(totaldfwithvar1,columns=columnsop)
#totaldfwithvar2.to_csv(r'C:\Data\Delivery_efficiency\for_totaldeleffi\totaldfwithvar2.csv')
totaldfwithvar2 = totaldfwithvar2.drop(totaldfwithvar2.tail(1).index)


stockcons = totaldfwithvar2['Total_Stock'].sum()
totaldeliveredcons = totaldfwithvar2['Total_Delivered'].sum()
totalefficiency = pd.np.round((totaldeliveredcons*100.0)/stockcons,2)


sumlist = ['TOTAL',stockcons,totaldeliveredcons,totalefficiency,'-','-']
col_list = ['Area','Total_Stock','Total_Delivered','Delivery_Efficiency','Delivery_Efficiency_Yday','Variance_DE']
totalsdf = pd.DataFrame(data=[sumlist], columns = col_list)
totaldfwithvar2 = totaldfwithvar2.append(totalsdf,ignore_index=True)

# In[8]:
## SC WISE TOTAL DELIVERY EFFICIENCY
stdscwise = pd.read_csv(r'D:\Data\eta_rank\STD_DE_SC.csv')
odascwise = pd.read_csv( r'D:\Data\eta_rank\ODA_DE_SC.csv')

scwise = pd.merge(stdscwise,odascwise,on=['DEST BRCD','Area'],suffixes=['_STD','_ODA'],how='outer')
scwise = pd.DataFrame(scwise,columns = ['DEST BRCD','Area','DOCKNO_op','DOCKNO_in','DOCKNO_Delivered_STD','Delivery_Efficiency_STD','DOCKNO_open','DOCKNO_Delivered_ODA','Delivery_Efficiency_ODA'])
scwise=scwise.rename(columns={'DOCKNO_op':'DOCK_open_STD','DOCKNO_in':'DOCKNO_in_STD','DOCKNO_open':'DOCKNO_open_ODA'})
scwise = scwise.fillna(0)

scwise['Total_Stock']= scwise.apply(lambda x:addstock(x['DOCK_open_STD'],x['DOCKNO_in_STD'],x['DOCKNO_open_ODA']),axis=1)
scwise['Total_Delivered']= scwise.apply(lambda x:delivered(x['DOCKNO_Delivered_STD'],x['DOCKNO_Delivered_ODA']),axis=1)
scwise['Delivery_Efficiency']= scwise.apply(lambda x:efficiency(x['Total_Delivered'],x['Total_Stock']),axis=1)

scwisesummary = pd.DataFrame(scwise,columns = ['DEST BRCD','Area','Total_Stock','Total_Delivered','Delivery_Efficiency'])

### For excluding holiday areas and branches

stddf =stddf[~(stddf['Area'].isin(selectdfarealist))]
odadf =odadf[~(odadf['Area'].isin(selectdfarealist))]
totaldfwithvar2 =totaldfwithvar2[~(totaldfwithvar2['Area'].isin(selectdfarealist))]
scwisesummary =scwisesummary[~(scwisesummary['DEST BRCD'].isin(selectdfbrcdlist))]

### For excluding holiday areas and branches

## SC WISE TOTAL DELIVERY EFFICIENCY

with ExcelWriter(r'D:\Data\eta_rank\Total_DE.xlsx') as writer:
    stddf.to_excel(writer, sheet_name='STD',engine='xlsxwriter')
    odadf.to_excel(writer, sheet_name='ODA',engine='xlsxwriter')
    totaldfwithvar2.to_excel(writer, sheet_name='Total',engine='xlsxwriter')
    scwisesummary.to_excel(writer, sheet_name='SC_WISE',engine='xlsxwriter')

oppath1=r'D:\Data\eta_rank\Total_DE.xlsx'

opfilevar =date.today() - timedelta(hours=24)
print 'opfilevar',opfilevar


with ExcelWriter(r'D:\Data\eta_rank\Delivery_Efficiency_Total\Total_DE_'+str(opfilevar)+'.xlsx') as writer:
    stddf.to_excel(writer, sheet_name='STD',engine='xlsxwriter')
    odadf.to_excel(writer, sheet_name='ODA',engine='xlsxwriter')
    totaldfwithvar2.to_excel(writer, sheet_name='Total',engine='xlsxwriter')
    scwisesummary.to_excel(writer, sheet_name='SC_WISE',engine='xlsxwriter')

oppath2 = r'D:\Data\eta_rank\Delivery_Efficiency_Total\Total_DE_'+str(opfilevar)+'.xlsx'
### CHECK FOR HTML ATTACHMENT
#h = HTML(totaldfwithvar2.to_html())
#my_file = open(r'D:\Data\eta_rank\Delivery_Efficiency_Total\some_file.html', 'w')
#my_file.write(h.data)
#my_file.close()
#oppath1 = r'D:\Data\eta_rank\Delivery_Efficiency_Total\some_file.html'
### CHECK FOR HTML ATTACHMENT

# In[ ]:
filePath = oppath2
# def sendEmail(TO = ["aom_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in","rajesh.mishra@spoton.co.in","raghavendra.rao@spoton.co.in","ashwani.gangwar@spoton.co.in","pramod.pandey@spoton.co.in","trilochan.panda@spoton.co.in","sunil.nakte@spoton.co.in","chandrima.banerjee@spoton.co.in", "suresh.d@spoton.co.in", "pankaj.jha@spoton.co.in"],
#             # TO = ["mahesh.reddy@spoton.co.in"],
#             # CC = ["mahesh.reddy@spoton.co.in"],
#             # BCC = ["mahesh.reddy@spoton.co.in"],
#             CC = ["sqtf@spoton.co.in","SQ_spot@spoton.co.in","supratim@iepfunds.com","Ankit@iepfunds.com","vishwas.j@spoton.co.in"],
#             BCC = ["sachidanand.pandey@spoton.co.in","renugopal.l@spoton.co.in","sathya.chander@spoton.co.in","alagu.mahendran@spoton.co.in","awadhesh.kumar.mishra@spoton.co.in","sanjay.parab@spoton.co.in","ramesh.s@spoton.co.in","md.zaya@spoton.co.in"],
#             FROM="mahesh.reddy@spoton.co.in"):
#     HOST = "smtp.spoton.co.in"
# #smtplib.SMTP('smtp.spoton.co.in', 25)

#     msg = MIMEMultipart()
#     msg["From"] = FROM
#     msg["To"] = ",".join(TO)
#     msg["CC"] = ",".join(CC)
#     msg["BCC"] = ",".join(BCC)
#     #msg["Subject"] = "TOTAL DELIVERY EFFICIENCY" + " - " + str(opfilevar)
#     msg["Subject"] = "TOTAL DELIVERY EFFICIENCY" + " - " + str(opfilevar)
#     body_text = """
#     Dear All,
    
#     Total Delivered = """+str(totaldeliveredcons)+"""
#     Total Stock = """+str(stockcons)+"""
#     Total Delivery Efficiency = """+str(totalefficiency)+"""
#     PFB the Total Delivery Efficiency as of """+str(opfilevar)+"""
    
# """+str(totaldfwithvar2)+"""


#     To download the Duedate cons Undel, Please click the link below
    
#     http://spoton.co.in/downloads/IEProjects/ETA/Duedate_cons_undel.xlsx

#     """

#     if body_text:
#         msg.attach( MIMEText(body_text) )
#     part = MIMEBase('application', "octet-stream")
#     part.set_payload( open(filePath,"rb").read() )
#     Encoders.encode_base64(part)
#     part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
#     msg.attach(part)
#     server=smtplib.SMTP('smtp.sendgrid.net', 587)
#     server.ehlo()
#     server.starttls()
#     server.ehlo()
#     server.login("spoton.net.in", "Star@123#")

#     try:
#         failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
#         server.close()
#     except Exception, e:
#         errorMsg = "Unable to send email. Error: %s" % str(e)

# if __name__ == "__main__":
#     sendEmail()
# print('Email sent')

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template
#vishwas.j@spoton.co.in
# TO=['vishwas.j@spoton.co.in']
TO = ["aom_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in","rajesh.mishra@spoton.co.in","raghavendra.rao@spoton.co.in","ashwani.gangwar@spoton.co.in","pramod.pandey@spoton.co.in","trilochan.panda@spoton.co.in","sunil.nakte@spoton.co.in","chandrima.banerjee@spoton.co.in", "suresh.d@spoton.co.in", "pankaj.jha@spoton.co.in"]
# TO=['vishwas.j@spoton.co.in']
FROM='reports.ie@spoton.co.in'
# CC=['vishwas.j@spoton.co.in']
CC = ["sqtf@spoton.co.in","SQ_spot@spoton.co.in"]
BCC = ["shashvat.suhane@spoton.co.in","mahesh.reddy@spoton.co.in","sachidanand.pandey@spoton.co.in","renugopal.l@spoton.co.in","sathya.chander@spoton.co.in","alagu.mahendran@spoton.co.in","awadhesh.kumar.mishra@spoton.co.in","sanjay.parab@spoton.co.in","ramesh.s@spoton.co.in","md.zaya@spoton.co.in","Pradyumna.Kumar@Spoton.Co.In"]
# BCC = ['vishwas.j@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "TOTAL DELIVERY EFFICIENCY" + " - " + str(opfilevar)
html='''<html>
<style>
p
{
  margin:0;
  margin-top: 5px;
  padding:0;
  font-size:17px;
    line-height:20px;
}
</style>
<h4>Dear All,</h4>
<p>Total Delivered = $totaldeliveredcons</p>
<p>Total Stock = $stockcons</p>
<p>Total Delivery Efficiency = $totalefficiency</p>
<p>PFB the Total Delivery Efficiency as of $opfilevar</p>
</html>'''

html3='''
<h5> To download the Duedate cons Undel, Please click the link below </h5>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Duedate_cons_undel.xlsx"</a>http://spoton.co.in/downloads/IEProjects/ETA/Duedate_cons_undel.xlsx</p></b>
'''
s = Template(html).safe_substitute(opfilevar=opfilevar,totalefficiency=totalefficiency,stockcons=stockcons,totaldeliveredcons=totaldeliveredcons)
report=""
report+=s
report+='<br>'
report+='<br>'+totaldfwithvar2.to_html()+'<br>'
report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filePath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()
#Sending output file via mail ends


## For FTP-ing the Duedate cons not delivered. Edit 05/07/2016
duedateconsundel = closingarriv12.append(odaduecons_closingstock,ignore_index=True)
duedateconsundelfree = duedateconsundel[duedateconsundel['Is Free Con']=='YES']
print len(duedateconsundel), len(duedateconsundelfree)

oppath3=r'D:\Data\DE_Conwise_Stock\DE_Due_undel\Duedate_cons_undel_'+str(opfilevar)+'.xlsx'
with ExcelWriter(r'D:\Data\DE_Conwise_Stock\DE_Due_undel\Duedate_cons_undel_'+str(opfilevar)+'.xlsx') as writer:
    duedateconsundel.to_excel(writer, sheet_name='DUE_UNDEL',engine='xlsxwriter')
    
    
oppath3=r'D:\Data\DE_Conwise_Stock\Duedate_cons_undel.xlsx'
with ExcelWriter(r'D:\Data\DE_Conwise_Stock\Duedate_cons_undel.xlsx') as writer:
    duedateconsundel.to_excel(writer, sheet_name='DUE_UNDEL',engine='xlsxwriter')    


# In[ ]:
print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppath3
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()
## For FTP-ing the Duedate cons not delivered. Edit 05/07/2016