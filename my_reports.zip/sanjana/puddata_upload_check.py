
# coding: utf-8

# In[ ]:

import pandas as pd
from datetime import datetime, timedelta
import numpy as np
pd.set_option('display.max_columns',40)
from sqlalchemy import *
import pyodbc
import os
import ftplib
import traceback
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template



# In[ ]:

cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=PYTHON_DB;UID=PythonOnline;PWD=P@ssw0rd123$")


# In[ ]:

startdate="'"+datetime.strftime((datetime.now()-timedelta(days=1)),"%Y-%m-%d")+"'"
enddate="'"+datetime.strftime(datetime.now(),"%Y-%m-%d")+"'"


# In[ ]:

query=("select cast( DATE2 as datetime) as date2,* from puddata where cast( DATE2 as datetime) between {0} and {1}").format(startdate,enddate)


# In[ ]:

query


# In[ ]:

pud_data=pd.read_sql(query,cnxn)


# In[ ]:

len(pud_data)


# In[ ]:

if len(pud_data)>=4000:
    pass
else:
    #vishwas.j@spoton.co.in
    FROM='vishwas.j@spoton.co.in'
    TO=['mahesh.reddy@spoton.co.in']
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["Subject"] = "PudData Not Uploaded"
    html='''<html>
    <h4>Hi,</h4>
    <p></p>
    </html>'''
    report=""
    report+='<br>'
    report+='The Pud Data Uploaded Count is ='+str(len(rev_df))
    report+='<br>'
    report+='<br>'
    report+='There was error in Uploading Revenue Data Betwen :'+str(startdate)+' - '+str(enddate)
    report+='<br>'
    abc=MIMEText(report,'html')
    msg.attach(abc)

    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO, msg.as_string())
    server.quit()



# In[ ]:



