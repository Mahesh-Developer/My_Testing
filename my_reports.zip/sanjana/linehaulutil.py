
# coding: utf-8

# In[1]:

import pandas as pd
import datetime
import collections
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import smtplib
import requests as req
import json
import os


# In[2]:

data= pd.read_excel(r'http://spoton.co.in/downloads/PMDLH/PMDLH.xls')
# data=pd.read_excel('PMDLH.xlsx')


# In[3]:

data=data[~(data['Vech Type'].isin(['VIRTUALHUB','DATAVECHILE']))]


# In[4]:

data['DATE']=data.apply(lambda x:x['THC DATE'].strftime('%d'),axis=1)


# In[5]:

yesterday=int(max(data['DATE'].unique()))-1


# In[6]:

data=data[data['DATE']!=str(yesterday+1)]


# In[7]:

def freq(series):
    l=dict(series.value_counts())
    s=dict((k.encode('ascii'), v) for (k, v) in l.items())
    return s


# In[8]:

def dates(series):
    l=len(pd.np.unique(series))
    return l


# In[9]:

grp1=data.pivot_table(index=['NEW PATH'],aggfunc={'ROUTE CODE':freq},fill_value=0).reset_index()


# In[10]:

market=data[data['ROUTE CODE']=='9888']


# In[11]:

mkt=market.pivot_table(index=['NEW PATH'],aggfunc={'ROUTE CODE':freq,'DATE':dates},fill_value=0).reset_index()


# In[12]:

def cutoff(no):
    try:
        l=(no*1.0/yesterday)*100
        return round(l)
    except:
        return 0


# In[13]:

mkt['Market_days%']=mkt.apply(lambda x:cutoff(x['DATE']),axis=1)


# In[14]:

mkt=mkt[['NEW PATH','DATE','Market_days%']]


# In[15]:

dff=mkt[mkt['Market_days%']>30]


# In[16]:

grp1


# In[17]:

# def convert(input):
#     if isinstance(input, dict):
#         return {convert(key): convert(value) for key, value in input.iteritems()}
#     elif isinstance(input, list):
#         return [convert(element) for element in input]
#     elif isinstance(input, unicode):
#         return input.encode('utf-8')
#     else:
#         return input


# In[18]:

# grp1['Vech Type']=grp1.apply(lambda x:convert(x['Vech Type']),axis=1)


# In[19]:

# convert(grp1['Vech Type'][4])


# In[20]:

grp2=data.pivot_table(index=['NEW PATH','Vech Type'],aggfunc={'COST':sum,'VEHICLE PAYLOAD':sum},fill_value=0).reset_index()


# In[21]:

grp2['CPK']=grp2.apply(lambda x:round((x['COST']*1.0)/x['VEHICLE PAYLOAD'],2),axis=1)


# In[22]:

grp2=grp2.pivot_table(index='NEW PATH',columns='Vech Type',values='CPK',fill_value=0).reset_index()


# In[23]:

def cpk(market,vendor):
    l={}
    l[str('M')]=market
    l[str('V')]=vendor
    return l


# In[24]:

grp2['CPK']=grp2.apply(lambda x:cpk(x['MARKET'],x['VENDOR']),axis=1)


# In[25]:

grp2=grp2[['NEW PATH','CPK']]


# In[26]:

grp1=pd.merge(grp1,grp2,on='NEW PATH',how='left')


# In[27]:

grp3=data.pivot_table(index=['NEW PATH','Vech Type'],aggfunc={'TOTAL ACTUAL LOAD':sum,'VEHICLE PAYLOAD':sum},fill_value=0).reset_index()


# In[28]:

def util(load,payload):
    return round((load/payload)*100)


# In[29]:

grp3['Utilization']=grp3.apply(lambda x:util(x['TOTAL ACTUAL LOAD'],x['VEHICLE PAYLOAD']),axis=1)


# In[30]:

grp3=grp3.pivot_table(index='NEW PATH',columns='Vech Type',values='Utilization',fill_value=0).reset_index()


# In[31]:

grp3['UTILIZATION']=grp3.apply(lambda x:cpk(x['MARKET'],x['VENDOR']),axis=1)


# In[32]:

grp3=grp3[['NEW PATH','UTILIZATION']]


# In[33]:

grp1=pd.merge(grp1,grp3,on='NEW PATH',how='left')


# In[34]:

yesterday


# In[35]:

yestdata=data[data['DATE']==str(yesterday)]


# In[36]:

pivot1=yestdata.pivot_table(index=['NEW PATH'],aggfunc={'ROUTE CODE':freq},fill_value=0).reset_index()


# In[37]:

pivot2=yestdata.pivot_table(index=['NEW PATH','Vech Type'],aggfunc={'COST':sum,'VEHICLE PAYLOAD':sum},fill_value=0).reset_index()


# In[38]:

pivot2['CPK']=pivot2.apply(lambda x:round((x['COST']*1.0)/x['VEHICLE PAYLOAD'],2),axis=1)


# In[39]:

pivot2=pivot2.pivot_table(index='NEW PATH',columns='Vech Type',values='CPK',fill_value=0).reset_index()


# In[40]:

pivot2['CPK']=pivot2.apply(lambda x:cpk(x['MARKET'],x['VENDOR']),axis=1)


# In[41]:

pivot2=pivot2[['NEW PATH','CPK']]


# In[42]:

pivot1=pd.merge(pivot1,pivot2,on='NEW PATH',how='left')


# In[43]:

pivot3=yestdata.pivot_table(index=['NEW PATH','Vech Type'],aggfunc={'TOTAL ACTUAL LOAD':sum,'VEHICLE PAYLOAD':sum},fill_value=0).reset_index()


# In[44]:

pivot3['Utilization']=pivot3.apply(lambda x:util(x['TOTAL ACTUAL LOAD'],x['VEHICLE PAYLOAD']),axis=1)


# In[45]:

pivot3=pivot3.pivot_table(index='NEW PATH',columns='Vech Type',values='Utilization',fill_value=0).reset_index()


# In[46]:

pivot3['UTILIZATION']=pivot3.apply(lambda x:cpk(x['MARKET'],x['VENDOR']),axis=1)


# In[47]:

pivot3=pivot3[['NEW PATH','UTILIZATION']]


# In[48]:

pivot1=pd.merge(pivot1,pivot3,on='NEW PATH',how='left')


# In[49]:

pivot1.rename_axis({'ROUTE CODE':'Freq:Yest','CPK':'CPK:Yest','UTILIZATION':'UTIL%:Yest'},axis=1,inplace=True)


# In[50]:

grp1.rename_axis({'ROUTE CODE':'Freq:MTD','CPK':'CPK:MTD','UTILIZATION':'UTIL%:MTD'},axis=1,inplace=True)


# In[51]:

pivot=pd.merge(grp1,pivot1,on='NEW PATH',how='left')


# In[52]:

pivot=pivot[['NEW PATH','Freq:MTD','Freq:Yest','CPK:MTD','CPK:Yest','UTIL%:MTD','UTIL%:Yest']]


# In[53]:

pivot=pivot.fillna('Na')


# In[54]:

corehublist = ['AMCH','AMDH','BLRH','BOMH','BRGH','CCUH','DELH','HYDH','MAAH','NAGH','PNQH','VPIH','VZAH','SXVF','IDRH']


# In[55]:

pivot['origin']=pivot.apply(lambda x: x['NEW PATH'].split('-')[0],axis=1)
pivot['dest']=pivot.apply(lambda x: x['NEW PATH'].split('-')[1],axis=1)


# In[56]:

df=pivot[(pivot['origin'].isin(corehublist)) & (pivot['dest'].isin(corehublist))]


# In[57]:

del df['origin']
del df['dest']
del pivot['origin']
del pivot['dest']


# In[58]:

df.to_csv('D:\Data\linehaulutilization\lhutilization.csv')


# In[59]:

abc=pd.read_csv('D:\Data\linehaulutilization\lhutilization.csv')
del abc['Unnamed: 0']


# In[60]:

pivot=pd.merge(pivot,mkt,on='NEW PATH',how='left')


# In[61]:

pivot['Timestamp']=datetime.datetime.today().date()


# In[62]:

pivot.to_csv('D:\Data\linehaulutilization\lhutilization_'+str(datetime.datetime.today().date())+'.csv')


# In[63]:

pivot.to_csv('D:\Data\linehaulutilization\lhutilization_send.csv')


# In[64]:

abc=pd.merge(abc,dff,on='NEW PATH',how='inner')


# In[69]:

len(abc)


# In[66]:

df=abc.to_html()


# In[67]:

filePath='D:\Data\linehaulutilization\lhutilization_send.csv'


# In[68]:

def sendEmail(#TO = ["hubmgr_spot@spoton.co.in","raghavendra.rao@spoton.co.in","cnm@spoton.co.in"],
            TO = ["shashvat.suhane@spoton.co.in"],
            # TO = ['krishna.chandrasekar@spoton.co.in'],
            CC = ["shashvat.suhane@spoton.co.in"],
            #CC = ["supratim@iepfunds.com","pawan.sharma@spoton.co.in","sqtf@spoton.co.in"],
            #BCC = ["vinayak.kumbhar@spoton.co.in","vinodkumar.mishra@spoton.co.in","nitin.tatyarao@spoton.co.in","kiran.pawar@spoton.co.in","jai.prakash@spoton.co.in","rajesh.mishra@spoton.co.in","ops.hub.idrh.1@spoton.co.in"] ,
            #BCC = ["vishwas.j@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["BCC"] = ",".join(BCC)
    msg["Subject"] = "LH-Freq-Util-Report_"+str(datetime.datetime.today().date())+''
    body_text = df
    msgtext="""Dear All ,"""
    msg.attach( MIMEText(msgtext) )
    msg.attach( MIMEText('<br>'+body_text+'<br>','html') )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()


# In[ ]:



