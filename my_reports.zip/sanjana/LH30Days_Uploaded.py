
# coding: utf-8

# In[ ]:

import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from datetime import datetime, timedelta, date
import os
import ftplib
import traceback
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template


# In[ ]:

startdate='"'+datetime.strftime(datetime.now()-timedelta(1),'%Y-%m-%d')+'"'
startdate


# In[ ]:

enddate='"'+datetime.strftime(datetime.now(),'%Y-%m-%d')+'"'
enddate


# In[ ]:

cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=PYTHON_DB;UID=PythonOnline;PWD=P@ssw0rd123$")


# In[ ]:

thcdatapd = pd.read_sql("SELECT * FROM LH30days WHERE [THC DATE] >= '{0}' AND [THC DATE] <= '{1}'".format(eval(startdate)+" 09:00:00",eval(enddate)+" 09:00:00"),cnxn)


# In[ ]:

len(thcdatapd)


# In[ ]:

if len(thcdatapd)>=200:
    pass
else:
    #vishwas.j@spoton.co.in
    FROM='mahesh.reddy@spoton.co.in'
    TO=['mahesh.reddy@spoton.co.in']
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["Subject"] = "THC Data Not Uploaded"
    html='''<html>
    <h4>Hi,</h4>
    <p></p>
    </html>'''
    report=""
    report+='<br>'
    report+='The THC Data Uploaded Count is ='+str(len(thcdatapd))
    report+='<br>'
    report+='<br>'
    report+='There was error in Uploading THC Data Betwen :'+str(startdate)+' - '+str(enddate)
    report+='<br>'
    abc=MIMEText(report,'html')
    msg.attach(abc)

    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO, msg.as_string())
    server.quit()


# In[ ]:



