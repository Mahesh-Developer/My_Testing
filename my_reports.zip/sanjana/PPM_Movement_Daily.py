
# coding: utf-8

# In[ ]:

import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
import Utilities

# In[ ]:
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
#try:
query =("""EXEC USP_PART_PIECE_MOVEMENT_DAILY_SQ""")


# In[ ]:

df=pd.read_sql(query,Utilities.cnxn)

print (len(df))
print (df.columns)

# In[ ]:

#df=pd.read_csv(r'/home/mahesh/Documents/USP_PART_PIECE_MOVEMENT_DAILY_SQ.csv')
len(df)


# In[ ]:

df.columns


# In[ ]:

df=df.fillna(0)


# In[ ]:

main_pivot=df.pivot_table(index=['TYPE'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').reset_index()


# In[ ]:

main_pivot['DOCKNO']=main_pivot['DOCKNO'].astype(int)


# In[ ]:

main_pivot


# In[ ]:

hubtohubdf=df[df['TYPE']=='HUB-HUB']
len(hubtohubdf)


# In[ ]:

hubtohubdf_pivot=hubtohubdf.pivot_table(index=['TCBR'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').reset_index()


# In[ ]:

hubtohubdf_pivot['DOCKNO']=hubtohubdf_pivot['DOCKNO'].astype(int)
hubtohubdf_pivot=hubtohubdf_pivot.sort_values('DOCKNO',ascending=False)

# In[ ]:

hubtoscdf=df[df['TYPE']=='HUB-SC']
len(hubtoscdf)


# In[ ]:

hubtoscdf_pivot=hubtoscdf.pivot_table(index=['TCBR'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').reset_index()


# In[ ]:

hubtoscdf_pivot['DOCKNO']=hubtoscdf_pivot['DOCKNO'].astype(int)
hubtoscdf_pivot=hubtoscdf_pivot.sort_values('DOCKNO',ascending=False)

# In[ ]:

sctohubdf=df[df['TYPE']=='SC-HUB']
len(sctohubdf)


# In[ ]:

sctohubdf_pivot=sctohubdf.pivot_table(index=['TCBR'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').reset_index()


# In[ ]:

sctohubdf_pivot['DOCKNO']=sctohubdf_pivot['DOCKNO'].astype(int)
sctohubdf_pivot=sctohubdf_pivot.sort_values('DOCKNO',ascending=False)

# In[ ]:

sctoscdf=df[df['TYPE']=='SC-SC']
len(sctoscdf)


# In[ ]:

sctoscdf_pivot=sctoscdf.pivot_table(index=['TCBR'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').reset_index()


# In[ ]:

sctoscdf_pivot['DOCKNO']=sctoscdf_pivot['DOCKNO'].astype(int)
sctoscdf_pivot=sctoscdf_pivot.sort_values('DOCKNO',ascending=False)

# In[ ]:

today=datetime.strftime(datetime.now(),'%Y-%m-%d')
today


# In[ ]:

with ExcelWriter(r'D:\Data\PPM Movement Daily\DATA\PPM_Movement_Daily'+str(today)+'.xlsx') as writer:
    main_pivot.to_excel(writer, sheet_name='Summary',engine='xlsxwriter')
    df.to_excel(writer, sheet_name='Con Wise Data',engine='xlsxwriter')
      


# In[ ]:

with ExcelWriter(r'D:\Data\PPM Movement Daily\PPM_Movement_Daily.xlsx') as writer:
    main_pivot.to_excel(writer, sheet_name='Summary',engine='xlsxwriter')
    df.to_excel(writer, sheet_name='Con Wise Data',engine='xlsxwriter')
      


# In[ ]:

filepath=r'D:\Data\PPM Movement Daily\PPM_Movement_Daily.xlsx'


# In[ ]:

FROM='mis.ho@spoton.co.in'


TO=['HUBMGR_SPOT@spoton.co.in',"SQ_SPOT@spoton.co.in",'amit.s@spoton.co.in','plt.vigilance_sw@spoton.co.in','plt.vigilance_ne@spoton.co.in']
CC=['sqtf@spoton.co.in','rajesh.kumar@spoton.co.in','abhik.mitra@spoton.co.in','jothi.menon@spoton.co.in','shivananda.p@spoton.co.in','rajesh.kapase@spoton.co.in','pawan.sharma@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in']

#TO=['mahesh.reddy@spoton.co.in']
#CC=['mahesh.reddy@spoton.co.in']
#BCC=['mahesh.reddy@spoton.co.in']

msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "PPM Movement Cons Daily Report -" + str(today)

report=""
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='Summary'
report+='<br>'
report+='<br>'
report+='<br>'+main_pivot.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='HUB-HUB'
report+='<br>'
report+='<br>'+hubtohubdf_pivot.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='HUB-SC'
report+='<br>'+hubtoscdf_pivot.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='SC-HUB'
report+='<br>'+sctohubdf_pivot.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='SC-SC'
report+='<br>'+sctoscdf_pivot.to_html()+'<br>'
report+='<br>'
report+='<br>'



#report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)

part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)



server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()

# except:

#   TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in'] 
#   CC=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
#   FROM="mahesh.reddy@spoton.co.in"
#   msg = MIMEMultipart()
#   msg["From"] = FROM
#   msg["To"] = ",".join(TO)
#   msg["CC"] = ",".join(CC)
#   #msg["BCC"] = ",".join(BCC)
#   #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
#   msg["Subject"] = "PPM Movement Cons Daily Report Error in Execution" 
#   report=""
#   report+='Hi,'

#   report+='<br>'
#   report+='There was some error in PPM Movement Cons Daily Report'
#   report+='<br>'

#   abc=MIMEText(report.encode('utf-8'),'html')
#   msg.attach(abc)
#   server=smtplib.SMTP('smtp.sendgrid.net', 587)
#   server.ehlo()
#   server.starttls()
#   server.ehlo()
#   server.login("spoton.net.in", "Star@123#")
#   failed = server.sendmail(FROM, TO+CC, msg.as_string())
#   server.quit()


# In[ ]:



