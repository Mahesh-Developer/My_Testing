
# coding: utf-8

# In[1]:

import pandas as pd
import datetime
from datetime import timedelta, date
from pandas import ExcelWriter
import smtplib
import os
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText


# In[2]:

todaydate = datetime.date.today()
print todaydate
yesterdate = todaydate-timedelta(days = 1)
aweekbefore = todaydate-timedelta(days = 7)
start_date = datetime.date(todaydate.year, todaydate.month, 1)
##$$previousmonthlast = start_date-timedelta(days=1)
previousmonthlast = start_date-timedelta(days=2)
print previousmonthlast
print aweekbefore


# In[3]:

pipelinedata = pd.read_csv(r'https://spoton.co.in/downloads/PIPELINE_LEAD_REPORT/PIPELINE_LEAD_REPORT.csv')
pipelinedataold = pd.read_csv(r'D:\Data\Sales_lead_management\Pipeline_raw\Pipeline_raw_'+str(previousmonthlast)+'.csv')
pipelinedataweekold = pd.read_csv(r'D:\Data\Sales_lead_management\Pipeline_raw\Pipeline_raw_'+str(aweekbefore)+'.csv')
len(pipelinedataweekold)

#print pipelinedata.columns.tolist()
#print pipelinedataold.columns.tolist()
#print pipelinedataweekold.columns.tolist()
# In[4]:

pipelinedata = pipelinedata.rename(columns={'\xef\xbb\xbfLeadid':'Leadid'})
pipelinedataold = pipelinedataold.rename(columns={'\xef\xbb\xbfLeadid':'Leadid'})
pipelinedataweekold = pipelinedataweekold.rename(columns={'\xef\xbb\xbfLeadid':'Leadid'})

# In[5]:

pipelinedataold = pipelinedataold.drop_duplicates(cols = 'Leadid')
pipelinedata = pipelinedata.drop_duplicates(cols = 'Leadid')
pipelinedataweekold = pipelinedataweekold.drop_duplicates(cols = 'Leadid')


# In[6]:

columnsforold = ['Leadid','LastStatusCode','LastStatusDate','LeadStatus']
pipelinedataold = pd.DataFrame(pipelinedataold,columns=columnsforold)

pipelinedataweekold = pd.DataFrame(pipelinedataweekold,columns=columnsforold)
pipelinedataweekold.columns.tolist()


# In[7]:

pipelinedatamerge = pd.merge(pipelinedata,pipelinedataold,on=['Leadid'],suffixes=['_New','_Old'],how='left')
len(pipelinedatamerge)


# In[8]:

pipelinedatamerge.LastStatusCode_Old.fillna('New',inplace=True)
pipelinedatamerge.LeadStatus_Old.fillna('New',inplace=True)


# In[9]:

#pipelinedatamerge.to_csv(r'C:\Data\Customer_lead_management\Pipeline_27042016\Pipeline_oldnew_merge.csv')


# In[10]:

len(pipelinedatamerge)


# In[11]:

# For removing inactive leads from both old and new files
iy = pipelinedatamerge[pipelinedatamerge['LeadStatus_Old']=='Inactive'][pipelinedatamerge['LeadStatus_New']=='Inactive'].index
pipelinedatamerge.loc[iy,'Seperatecolumn'] = 'Remove'
pipelinedatamerge = pipelinedatamerge[pipelinedatamerge['Seperatecolumn']!='Remove']
pipelinedatamerge = pipelinedatamerge.drop('Seperatecolumn',axis=1)
len(pipelinedatamerge)

ix = pipelinedatamerge[pipelinedatamerge['LeadStatus_New']=='Inactive'].index
pipelinedatamerge.loc[ix,'LastStatusCode_New'] = 'Inactive'
len(pipelinedatamerge)

pipelinedatamergepivot = pd.pivot_table(pipelinedatamerge,index=['SalesPersonName','LastStatusCode_Old'],columns=['LastStatusCode_New'],values='Leadid',aggfunc=len,fill_value=0).reset_index()


# In[12]:

#pipelinedatamerge.to_csv(r'C:\Data\Customer_lead_management\Pipeline_27042016\Pipeline_oldnew_merge.csv')


# In[13]:

pipelinedatamergeweek = pd.merge(pipelinedata,pipelinedataweekold,on=['Leadid'],suffixes=['_New','_Lastweek'],how='left')
#pipelinedatamergeweek = pipelinedatamergeweek.rename(columns={'LastStatusCode':'LastStatusCode_Lastweek','LastStatusDate':'LastStatusDate_Lastweek','LeadStatus':'LeadStatus_Lastweek'})

pipelinedatamergeweek.LastStatusCode_Lastweek.fillna('New',inplace=True)
pipelinedatamergeweek.LeadStatus_Lastweek.fillna('New',inplace=True)


iw = pipelinedatamergeweek[pipelinedatamergeweek['LeadStatus_Lastweek']=='Inactive'][pipelinedatamergeweek['LeadStatus_New']=='Inactive'].index
pipelinedatamergeweek.loc[iw,'Seperatecolumn'] = 'Remove'
#pipelinedatamergeweek = pipelinedatamergeweek[pipelinedatamergeweek['Seperatecolumn']!='Remove']
#pipelinedatamergeweek = pipelinedatamergeweek.drop('Seperatecolumn',axis=1)
len(pipelinedatamergeweek)

iv = pipelinedatamergeweek[pipelinedatamergeweek['LeadStatus_New']=='Inactive'].index
pipelinedatamergeweek.loc[iv,'LastStatusCode_New'] = 'Inactive'
len(pipelinedatamergeweek)


pipelinedatamergeweekpivot = pd.pivot_table(pipelinedatamergeweek,index=['SalesPersonName','LastStatusCode_Lastweek'],columns=['LastStatusCode_New'],values='Leadid',aggfunc=len,fill_value=0).reset_index()
pipelinedatamergeweek.to_csv(r'D:\Data\Sales_lead_management\Pipeline_report\Week_Comparison_data_'+str(yesterdate)+'.csv')

# In[14]:

## For leads and potential revenue toady and last month
pipelineactivedata = pd.read_csv(r'https://spoton.co.in/downloads/PIPELINE_LEAD_REPORT/PIPELINE_LEAD_REPORT.csv')
pipelineactivedatalastmonth = pd.read_csv(r'D:\Data\Sales_lead_management\Pipeline_raw\Pipeline_raw_'+str(previousmonthlast)+'.csv')

pipelineactivedata = pipelineactivedata.rename(columns={'\xef\xbb\xbfLeadid':'Leadid'})
pipelineactivedatalastmonth = pipelineactivedatalastmonth.rename(columns={'\xef\xbb\xbfLeadid':'Leadid'})

pipelineactivedata = pipelineactivedata.drop_duplicates(cols = 'Leadid')
pipelineactivedatalastmonth = pipelineactivedatalastmonth.drop_duplicates(cols = 'Leadid')

pipelineactivedata = pipelineactivedata[pipelineactivedata['LeadStatus']=='Active']
pipelineactivedatalastmonth = pipelineactivedatalastmonth[pipelineactivedatalastmonth['LeadStatus']=='Active']

pipelineactivedatapivot = pd.pivot_table(pipelineactivedata,index=['SaleRegion','saleDepot','Channel','SalesPersonName','LastStatusCode'],values=['Leadid','PotentialRevenueInLakhs'],aggfunc={'Leadid':len,'PotentialRevenueInLakhs':pd.np.sum}).reset_index()
pipelineactivedatalastmonthpivot = pd.pivot_table(pipelineactivedatalastmonth,index=['SaleRegion','saleDepot','Channel','SalesPersonName','LastStatusCode'],values=['Leadid','PotentialRevenueInLakhs'],aggfunc={'Leadid':len,'PotentialRevenueInLakhs':pd.np.sum}).reset_index()

leadstatusnowtolastmonthend = pd.merge(pipelineactivedatapivot,pipelineactivedatalastmonthpivot,on=['SaleRegion','saleDepot','Channel','SalesPersonName','LastStatusCode'],suffixes=['_Today','_Lastmonth'],how='outer')

## For leads and potential revenue toady and last month
# In[15]:

with ExcelWriter(r'D:\Data\Sales_lead_management\Pipeline_report\Pipeline_report_'+str(yesterdate)+'.xlsx') as writer:
    pipelinedatamergepivot.to_excel(writer, sheet_name='Last_month_comparison',engine='xlsxwriter')
    #pipelinedatamerge.to_excel(writer, sheet_name='Last_month_comparison_data',engine='xlsxwriter')
    pipelinedatamergeweekpivot.to_excel(writer, sheet_name='Last_week_comparison',engine='xlsxwriter')
    leadstatusnowtolastmonthend.to_excel(writer, sheet_name='Lead_status_MTD',engine='xlsxwriter')

oppath1 = r'D:\Data\Sales_lead_management\Pipeline_report\Pipeline_report_'+str(yesterdate)+'.xlsx'
# In[ ]:

filePath1 = oppath1
def sendEmail(#TO = ["sukumar.sakthivel@spoton.co.in"],
              TO = ["vishwas.j@spoton.co.in"],
             #TO = ["rajeesh.vr@spoton.co.in"],
             #CC = ["supratim@iepfunds.com","abhik.mitra@spoton.co.in","rajeesh.vr@spoton.co.in","vishwas.j@spoton.co.in"],
            CC = ["vishwas.j@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "Sales_Pipeline_report"
    body_text = """
    Dear All,
    
    PFA the Sales pipeline report
    
    
    """
    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath1,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath1))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends

