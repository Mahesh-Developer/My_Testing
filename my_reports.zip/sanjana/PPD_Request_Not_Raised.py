
# coding: utf-8

# In[ ]:


import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
import Utilities

# In[ ]:
#cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")

try:
	query =("""EXEC USP_PART_PIECE_AT_DESTN_SQ""")


	# In[ ]:


	df=pd.read_sql(query,Utilities.cnxn)


	# In[ ]:


	#df=pd.read_csv(r'/home/mahesh/Documents/USP_PART_PIECE_AT_DESTN_SQ.csv')


	# In[ ]:


	df.rename(columns={'destareaname':'Dest Area'},inplace=True)


	# In[ ]:


	not_ppd_raised_df=df[df['PPD_REQUEST_RAISED']=='NO']
	len(not_ppd_raised_df)


	# In[ ]:


	area_not_ppd_raised_df=not_ppd_raised_df.pivot_table(index=['Dest Area'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').reset_index()


	# In[ ]:


	area_not_ppd_raised_df['DOCKNO']=area_not_ppd_raised_df['DOCKNO'].astype(int)


	# In[ ]:


	area_not_ppd_raised_df1=area_not_ppd_raised_df.sort_values('DOCKNO',ascending=False)


	# In[ ]:


	branch_not_ppd_raised_df=not_ppd_raised_df.pivot_table(index=['REASSIGN_DESTCD'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').reset_index()


	# In[ ]:


	branch_not_ppd_raised_df['DOCKNO']=branch_not_ppd_raised_df['DOCKNO'].astype(int)


	# In[ ]:


	branch_not_ppd_raised_df


	# In[ ]:


	today=datetime.strftime(datetime.now(),'%Y-%m-%d')
	today


	# In[ ]:


	# with ExcelWriter(r'D:\Data\PPD Request Not Raised\PPD_At_Dest_Not_Raised_Requested'+str(today)+'.xlsx') as writer:
	#     area_not_ppd_raised_df.to_excel(writer, sheet_name='Area Wise Summary',engine='xlsxwriter')
	#     branch_not_ppd_raised_df.to_excel(writer, sheet_name='Branch Wise Summary',engine='xlsxwriter')
	#     not_ppd_raised_df.to_excel(writer,sheet_name='PPD Status Pending Con Data',engine='xlsxwriter')   

	area_not_ppd_raised_df.to_csv(r'D:\Data\PPD Request Not Raised\PPD_Not_Raised_Requested_Area Summary'+str(today)+'.csv')
	branch_not_ppd_raised_df.to_csv(r'D:\Data\PPD Request Not Raised\PPD_Not_Raised_Requested_Branch Summary'+str(today)+'.csv')
	not_ppd_raised_df.to_csv(r'D:\Data\PPD Request Not Raised\PPD_Not_Raised_Requested_Data'+str(today)+'.csv')   



	area_not_ppd_raised_df.to_csv(r'D:\Data\PPD Request Not Raised\PPD_Not_Raised_Requested_Area Summary.csv')
	branch_not_ppd_raised_df.to_csv(r'D:\Data\PPD Request Not Raised\PPD_Not_Raised_Requested_Branch Summary.csv')
	not_ppd_raised_df.to_csv(r'D:\Data\PPD Request Not Raised\PPD_Not_Raised_Requested_Data.csv')   


	# In[ ]:


	# with ExcelWriter(r'D:\Data\PPD Request Not Raised\PPD_At_Dest_Not_Raised_Requested.xlsx') as writer:
	#     area_not_ppd_raised_df.to_excel(writer, sheet_name='Area Wise Summary',engine='xlsxwriter')
	#     branch_not_ppd_raised_df.to_excel(writer, sheet_name='Branch Wise Summary',engine='xlsxwriter')
	#     not_ppd_raised_df.to_excel(writer,sheet_name='PPD Status Pending Con Data',engine='xlsxwriter')   


	# In[ ]:


	filepath=r'D:\Data\PPD Request Not Raised\PPD_Not_Raised_Requested_Area Summary.csv'
	filepath1=r'D:\Data\PPD Request Not Raised\PPD_Not_Raised_Requested_Branch Summary.csv'
	filepath2=r'D:\Data\PPD Request Not Raised\PPD_Not_Raised_Requested_Data.csv'


	# In[ ]:


	FROM='mis.ho@spoton.co.in'

	TO=["dom_spot@spoton.co.in","rom_spot@spoton.co.in","aom_spot@spoton.co.in",'scincharge_spot@spoton.co.in',"SQ_SPOT@spoton.co.in"]
	CC=['sqtf@spoton.co.in','rajesh.kumar@spoton.co.in','abhik.mitra@spoton.co.in','jothi.menon@spoton.co.in','shivananda.p@spoton.co.in']
	BCC=['mahesh.reddy@spoton.co.in']
	#TO=['mahesh.reddy@spoton.co.in']
	#CC=['mahesh.reddy@spoton.co.in']
	#BCC=['mahesh.reddy@spoton.co.in']

	msg = MIMEMultipart()
	msg["From"] = FROM
	msg["To"] = ",".join(TO)
	msg["CC"] = ",".join(CC)
	msg["BCC"] = ",".join(BCC)
	#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
	msg["Subject"] = "Request Not Raised PPD Cons Lying At Destination -" + str(today)

	report=""
	report+='Dear All,'
	report+='<br>'
	report+='<br>'
	report+='PFA Request Not Raised PPD Cons Lying At Destination'
	report+='<br>'
	report+='<br>'
	#report+='Total PPD Request Raised Cons :'+str(len(ppd_raised_df))
	#report+='<br>'
	#report+='<br>'
	report+='Request Not Raised PPD Cons AreaWise Summary'
	report+='<br>'
	report+='<br>'+area_not_ppd_raised_df1.to_html()+'<br>'
	report+='<br>'



	#report+=html3
	abc=MIMEText(report,'html')
	msg.attach(abc)

	part = MIMEBase('application', "octet-stream")
	part.set_payload( open(filepath,"rb").read() )
	encoders.encode_base64(part)
	part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
	msg.attach(part)

	part1 = MIMEBase('application', "octet-stream")
	part1.set_payload( open(filepath1,"rb").read() )
	encoders.encode_base64(part1)
	part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
	msg.attach(part1)

	part2 = MIMEBase('application', "octet-stream")
	part2.set_payload( open(filepath2,"rb").read() )
	encoders.encode_base64(part2)
	part2.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath2))
	msg.attach(part2)




	server=smtplib.SMTP('smtp.sendgrid.net', 587)
	server.ehlo()
	server.starttls()
	server.ehlo()
	server.login("spoton.net.in", "Star@123#")
	failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
	server.quit()

except:

  TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in'] 
  CC=['mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "Request Not Raised PPD Cons Lying At Destination Error in Execution" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in Request Not Raised PPD Cons Lying At Destination'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO+CC, msg.as_string())
  server.quit()
