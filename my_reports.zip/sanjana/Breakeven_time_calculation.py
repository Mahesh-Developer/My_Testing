import pandas as pd
import datetime
from datetime import datetime, timedelta
import calendar
import copy
import graphlab as gl
import graphlab.aggregate as agg
#import sframe as gl
#import sframe.aggregate as agg
from itertools import izip
import ftplib
import traceback

import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import os
import traceback
import ftplib

# In[2]:

print datetime.now()
opfilevar=datetime.now().date()
opfilevar1=datetime.now().time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=pd.np.round((float(currhrs)/60),0)


# In[3]:

# In[2]:

timeformatstring = '%m/%d/%Y %H:%M:%S %p'
timeformatstring2 = '%Y-%m-%d %H:%M:%S'
timeformatstring3 = '%m/%d/%Y %I:%M:%S %p'
conprocessing = 1.0
slackhours = 3.0
dayzero = datetime.strptime('2015-1-1 00:00:00', timeformatstring2)
dayminu = datetime.strptime('2014-1-1 00:00:00', timeformatstring2)
dayfirst = datetime.strptime('2001-1-1 00:00:00', timeformatstring2)
link = 'http://spoton.co.in/downloads/TCR_UND_2HRS/TCR_UND_ISDEPART_YES_2HRS_NEXT_TO_NEXT.xls'
#link = 'TCR_UND_ISDEPART_YES_2HRS_NEXT_TO_NEXT.xls'
#csvfilename = r'D:\Python\Scripts and Files\Path and Graph Files\dfbase_breakeven.csv'


# In[3]:

dfbase = pd.read_excel(link)


# In[4]:

#dfbase = dfbase.fillna('THC ARRV AT HUB', dayfirst)
dfbase['THC ARRV AT HUB']=dfbase['THC ARRV AT HUB'].fillna(dayfirst)


# In[5]:

print dfbase['TIME STAMP'][1], type(dfbase['TIME STAMP'][1])
print dfbase['THC ARRV AT HUB'][1], type(dfbase['THC ARRV AT HUB'][1])


# In[6]:

#print len(dfbase)

# In[4]:

dfdroplist = ['Latest Status Date','Latest Status Reason','Latest Status Branch','Latest Status Category','Account Name','SENDERNAME','RECEIVERNAME']
dfkeeplist = [i for i in dfbase.columns.tolist() if i not in dfdroplist]
dfbase = dfbase[dfkeeplist]
dfbase.to_csv(r'D:\Python\Scripts and Files\Path and Graph Files\dfbase_breakeven.csv')
#dfbase.to_csv(csvfilename)
#print len(dfbase)


# In[5]:

#csvfilename = 'debug_ip.csv'
#invsf = gl.SFrame.read_csv(csvfilename)
#print len(invsf)
invsf = gl.SFrame.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\dfbase_breakeven.csv')
loclist = ['DESTCD','CURR BRANCHCODE','ORIGIN BRCODE']
maplist = dict({'MAAG': 'MAAC','NEIR': 'GAUB','RJPR': 'PTLF','SIKM': 'SILB','KLMF':'COKB','AMDE':'AMDO'})

totalconsinv = len(invsf)

## To remove VGAF and GNTF as Sri Krishna Pushkaralu till 24th August

#excludebranchlist = ['VGAF','GNTF']
#invsf = invsf.filter_by(excludebranchlist, 'Destn Branch', exclude=True)

## To remove VGAF and GNTF as Sri Krishna Pushkaralu till 24th August

## Check done 


# In[7]:

def convloc(location):
    get_dict = maplist.get(location)
    #print 'get_dict',get_dict
    if get_dict is None:
        #print 'location',location
        return location
    else:
        return get_dict
    
#dfbase.to_csv(r'D:\Data\Routing_logic_sector_buildup\debug123.csv')
  
for locnames in loclist:
    invsf[locnames] = invsf.apply(lambda x: convloc(x[locnames]))
#print len(invsf)
#dfbase.to_csv(r'D:\Data\Routing_logic_sector_buildup\debug.csv')

# In[6]:

#print len(invsf)
#invsf = invsf[invsf['Destn Depot']!='UCGD']
#excludeucginv = len(invsf)
invsf = invsf[invsf['CURR BRANCHCODE']!=invsf['DESTCD']]
#print len(invsf)


dataignorelist=['DATA-VEH']
invsf = invsf.filter_by(dataignorelist, 'DEPARTED FRM CURRLOC VEHNO', exclude=True)


# In[8]:

#dfbase.to_csv(r'D:\Data\Routing_logic_sector_buildup\debug_dest_branch.csv')
# In[7]:

#paperwork-deps-exclusion
#depspaperworkcodelist = ['SRE','SRD','SRS','SRP','DLP','SWP','PWS','HCM','HPM','MOP','SRH','HOC','ONR','SPH','SPO','DBO','DIP','SHS','SSC','HIP','RNX','APT','APN','SHD','SMT','SPL','MSH','UCG','RRA','HPE','WIA','UG1','UG2','UG3','HMP','HWC','NPE','HIM']
#invsf = invsf.filter_by(depspaperworkcodelist, 'Latest Con Status Code', exclude=True)
#invaft_deps_paperwork = len(invsf)
#paperwork-deps-exclusion


# In[9]:

# In[8]:
pathsf = gl.SFrame.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\final_pathv3.csv')
lhscheduledf = gl.SFrame.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\Timegraph.csv')
#thcbasedata = gl.SFrame.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\sector_buildup_routing\THC_DATA_1.csv')


# In[9]:

vbdf = pd.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\Hublist.csv')


# In[10]:

vblist = vbdf['VB'].tolist()


# In[10]:

lhscheduledfgrp = lhscheduledf.groupby(['Origin','Destination','Type'],{'Departure Time':agg.CONCAT('Departure Time'),'Total leg TT': agg.CONCAT('Total leg TT')})
#print lhscheduledfgrp.head(50)
#xyz1 = lhscheduledfgrp[(lhscheduledfgrp['Origin']=='BOMH') & (lhscheduledfgrp['Destination']=='DELH')]
#print xyz1 
lhscheduledf_dict = {}
for org, dest, deptime, transithrs,vbtype in izip(lhscheduledfgrp['Origin'], lhscheduledfgrp['Destination'],
                                     lhscheduledfgrp['Departure Time'], lhscheduledfgrp['Total leg TT'], lhscheduledfgrp['Type']):
    lhscheduledf_dict[(org, dest)] = [deptime,transithrs,vbtype]


# In[14]:

path_dict = {}
for org, dest, paths in izip(pathsf['Origin'], pathsf['Destination'],pathsf['pathlist']):
    path_dict[(org, dest)] = paths


# In[11]:

# In[15]:

def getconpath(origin,location,destination):
    #print origin, location, destination
    try:
        conpathall1 = path_dict.get((origin,destination))
        if conpathall1 is None:
            conpathall = None
        else:
            conpathall = [i for i in conpathall1 if location in i]
        auxpathall = path_dict.get((location,destination))
        if conpathall is None:
            conpathall = []
        if auxpathall is None:
            auxpathall = []
        if (len(conpathall)==0) and (len(auxpathall)==0):
            return ['error']
        elif (len(conpathall)==0):
            lenlist = [len(i) for i in auxpathall]
            return auxpathall[lenlist.index(min(lenlist))]
        else:
            lenlist = [len(i) for i in conpathall]
            minconpath = conpathall[lenlist.index(min(lenlist))]
            return minconpath[minconpath.index(location):]
    except:
        ['checkerror']


# In[16]:

def getdeparturetime(org, dest, currtime):
    try:
        currtimedt = str(currtime).split(' ')[0]+' 00:00:00'
        currtimedt = datetime.strptime(currtimedt,'%Y-%m-%d %H:%M:%S')
        deptime_total = lhscheduledf_dict.get((org, dest))
        if deptime_total is None:
            return dayzero, dayzero
        deptime, transithrs, vbtype = deptime_total
        if vbtype == 'Normal':
            timerellist = []
            for i in range(0,len(deptime)):
                deptime1 = timedelta(hours=deptime[i])+(currtimedt)
                deptime2 = timedelta(hours=(deptime[i]+24.0))+(currtimedt)
                arrtime1 = deptime1 + timedelta(hours=transithrs[i])
                arrtime2 = deptime2 + timedelta(hours=transithrs[i])
                if deptime1<=currtime:
                    timerellist.append((deptime2,arrtime2))
                else:
                    timerellist.append((deptime1,arrtime1))
            
            sorted_by_first = sorted(timerellist, key=lambda tup: tup[0], reverse=False)
            return sorted_by_first[0][0],sorted_by_first[0][1]
        elif vbtype == 'VB':
            deptime = timedelta(hours=3.0)+(currtime)
            return deptime,deptime
    except:
        return dayzero,dayzero


# In[17]:

def getidealtimes(con,conpath,pickuptime,arratcurrloc):
    ### pickuptime is current time
    
    ### To get the ETA at Arrival time. Modifying Timestamp to Arrival+3Hours
    pickuptime = arratcurrloc+timedelta(hours=2.0)
    ### To get the ETA at Arrival time. Modifying Timestamp to Arrival+3Hours
    try:
        idealtimelist = []
        hrsatcurrloc = (pickuptime-arratcurrloc).total_seconds()*1.0/3600
        if hrsatcurrloc<=conprocessing:
            adjtimeatloc = conprocessing-hrsatcurrloc
        else:
            adjtimeatloc = 0
        currtime = pickuptime+timedelta(hours=adjtimeatloc)
        idealtimelist.append(pickuptime)
        for i in range (1,len(conpath)):
            org = conpath[i-1]
            dest = conpath[i]
            departuretime,arrivaltime = getdeparturetime(org,dest,currtime)
            if (departuretime==dayzero)or(arrivaltime==dayzero):
                idealtimelist=[dayzero]
                break    
            else:
                if (dest == conpath[-1]) and (departuretime.weekday()==arrivaltime.weekday()==6) and (arrivaltime.hour<=12):
                    departuretime = departuretime+timedelta(hours=24)
                    arrivaltime = arrivaltime+timedelta(hours=24)
                idealtimelist.append(departuretime)
                idealtimelist.append(arrivaltime)
                currtime = arrivaltime

        return idealtimelist[-1]
    except:
        return dayzero


# In[12]:

# In[21]:
invsf.save(r'D:\Data\Breakeventime_calculation\debug.csv')
invsf['conpath'] = invsf.apply(lambda x: getconpath(x['ORIGIN BRCODE'],x['CURR BRANCHCODE'],x['DESTCD']))
invsf['Origin Branch'] = invsf.apply(lambda x: x['ORIGIN BRCODE'].upper())
invsf['Destn Branch'] = invsf.apply(lambda x: x['DESTCD'].upper())
invsf['Hub SC Location'] = invsf.apply(lambda x: x['CURR BRANCHCODE'].upper())
print invsf['THC ARRV AT HUB'][0], type(invsf['THC ARRV AT HUB'][0])

print 'before', len(invsf)

invsf['arratcurrloc'] = invsf.apply(lambda x: datetime.strptime(x['THC ARRV AT HUB'].split('.')[0],timeformatstring2))


invsf = invsf[invsf['arratcurrloc']!=dayfirst]
print 'after', len(invsf)

print invsf['arratcurrloc'][0], type(invsf['arratcurrloc'][0])
invsf['currtime'] = invsf.apply(lambda x: datetime.strptime(x['TIME STAMP'].split('.')[0],timeformatstring2))
invsf['Duedt'] = invsf.apply(lambda x: datetime.strptime(x['DUE DATE'].split('.')[0],timeformatstring2))
 
#### For weighted average times between locations. Edit on 28-10-2016
 
def diffhr(currtime,arrivetime):
    diff = (currtime - arrivetime)
    return pd.np.round(diff.total_seconds()/3600,1) 

invsf['Time_diff'] = invsf.apply(lambda x:diffhr (x['currtime'],x['arratcurrloc']))
 
#### For weighted average times between locations. Edit on 28-10-2016
 
invsf['E_T'] = invsf.apply(lambda x: getidealtimes(x['DOCKNO'],x['conpath'],x['currtime'],x['arratcurrloc']))

#print len(invsf)


# In[13]:

invsf.save(r'D:\Data\Breakeventime_calculation\debug1.csv')


# In[14]:

def etairrerem(currtime,e_t):
    if e_t<=currtime:
        return 'Remove'
    else:
        return 'Keep'


# In[15]:

invsf['E_IRR_Rem'] = invsf.apply(lambda x: etairrerem(x['currtime'],x['E_T']))


# In[16]:

invsf = (invsf[invsf['E_IRR_Rem']!='Remove'])


# In[17]:

def geteta(dockno,path,currtime,arrvtime):
    etadttime = getidealtimes(dockno,path,currtime,arrvtime)
    etadt = etadttime.date()
    return etadt  


# In[18]:

invsf['ETA_DT'] = invsf.apply(lambda x: geteta(x['DOCKNO'],x['conpath'],x['currtime'],x['arratcurrloc']))


# In[19]:

print datetime.now()


# In[20]:

def getbetm(dockno,path,currtime,arrvtime,etadt):
    lowerlim = 0
    upperlim = 24
    isfound = 0
    eta24 = geteta(dockno,path,currtime,arrvtime+timedelta(hours=24))
    etadt = etadt.date()
    #print eta24,etadt  
    if eta24 <= etadt:
        return arrvtime+timedelta(hours=24)
    else:
        while isfound == 0:
            midval = int((lowerlim+upperlim)/2)
            neweta = geteta(dockno,path,currtime,arrvtime+timedelta(hours=midval))
            if neweta == etadt:
                lowerlim = midval
            else:
                upperlim = midval
            if (upperlim-lowerlim) <=1:
                isfound = 1
        return arrvtime+timedelta(hours=upperlim)


# In[21]:

def getneweta(dockno,path,currtime,arrvtime,etadt):
    lowerlim = 0
    upperlim = 24
    isfound = 0
    eta24 = geteta(dockno,path,currtime,arrvtime+timedelta(hours=24))
    etadt = etadt.date()
    print eta24,etadt  
    if eta24 <= etadt:
        return eta24
    else:
        while isfound == 0:
            midval = int((lowerlim+upperlim)/2)
            neweta = geteta(dockno,path,currtime,arrvtime+timedelta(hours=midval))
            if neweta == etadt:
                lowerlim = midval
            else:
                upperlim = midval
            if (upperlim-lowerlim) <=1:
                isfound = 1
        return neweta


# In[22]:

invsf['BE_Time'] = invsf.apply(lambda x: getbetm(x['DOCKNO'],x['conpath'],x['currtime'],x['arratcurrloc'],x['ETA_DT']))
#invsf.save(r'D:\Data\Breakeventime_calculation\debug2aa.csv')
invsf.save(r'D:\Data\Breakeventime_calculation\Breakeventime.csv')
#invsf.save(r'D:\Data\Breakeventime_calculation\debug2a.csv')
invsf.save(r'D:\Data\Breakeventime_calculation\Till_BE_calculation\Breakeventime_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv')
#invsf.save(r'D:\Data\Breakeventime_calculation\debug2b.csv')
oppath2 = r'D:\Data\Breakeventime_calculation\conBreakeventime.csv'

ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
invsf.save(r'D:\Data\Breakeventime_calculation\debug2.csv')
#print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        #print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppath2
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        #print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()

# In[23]:

invsf['New_ETA'] = invsf.apply(lambda x: getneweta(x['DOCKNO'],x['conpath'],x['currtime'],x['arratcurrloc'],x['ETA_DT']))
invsf.save(r'D:\Data\Breakeventime_calculation\debug3.csv')

# In[24]:

print datetime.now()


# In[25]:

invsf['Diff_time'] = invsf.apply(lambda x: (x['BE_Time']-x['arratcurrloc']).total_seconds()/3600)
invsf['Diff_ETA'] = invsf.apply(lambda x: (x['New_ETA']-x['ETA_DT']).total_seconds()/3600)


# In[26]:

invsf.save(r'D:\Data\Breakeventime_calculation\conBreakeventime_New_ETA.csv')
invsf.save(r'D:\Data\Breakeventime_calculation\Complete_data\conBreakeventime_New_ETA_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv')

oppath3 = r'D:\Data\Breakeventime_calculation\conBreakeventime_New_ETA.csv'
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
#print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        #print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppath3
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        #print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()
# In[27]:

print datetime.now()


# In[ ]:
recipients = ["mahesh.reddy@spoton.co.in"]
#recipients = ["vishwas.j@spoton.co.in","rajeesh.vr@spoton.co.in"]
sender = "spoton.net.in"
subject = "Breakeven Time " + "- "+ str(opfilevar)+"-"+str(opfilevar2)
body = """
    Dear All,

    PFA the Breakeven time report link """ + str(opfilevar)+"-"+str(opfilevar2) +"""
    
    Breakeven Time Link    
    http://spoton.co.in/downloads/IEProjects/ETA/Breakeventime.csv
    
    Breakeven Time with New ETA Link
    http://spoton.co.in/downloads/IEProjects/ETA/Breakeventime_New_ETA.csv

"""

# make up message
msg = MIMEText(body)
msg['Subject'] = subject
msg['From'] = sender
msg['To'] = ", ".join(recipients)

# sending
session = smtplib.SMTP('smtp.sendgrid.net', 587)
session.starttls()
session.login(sender, 'Star@123#')
send_it = session.sendmail(sender, recipients, msg.as_string())
session.quit()


