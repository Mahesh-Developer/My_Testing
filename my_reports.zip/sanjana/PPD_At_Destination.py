
# coding: utf-8

# In[ ]:


import pandas.io.sql
import pandas as pd
import numpy as np
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
import Utilities

# In[ ]:

# cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
#try:
query =("""EXEC USP_PART_PIECE_AT_DESTN_SQ""")


# In[ ]:


# df=pd.read_sql(query,Utilities.cnxn)
df=pd.read_sql(query,Utilities.cnxn)


# In[ ]:


#df=pd.read_csv(r'/home/mahesh/Documents/USP_PART_PIECE_AT_DESTN_SQ.csv')


# In[ ]:


len(df)


# In[ ]:


df.columns


# In[ ]:




# In[ ]:


df.rename(columns={'destareaname':'Dest Area'},inplace=True)


# In[ ]:


## Area Wise Summary
area_pivot=df.pivot_table(index=['Dest Area'],columns=['@loccation'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').reset_index()
area_pivot=area_pivot.replace([np.inf,-np.inf],np.nan).fillna(0)

# In[ ]:


area_pivot['DOCKNO']=area_pivot['DOCKNO'].astype(int)


# In[ ]:


area_pivot1=area_pivot.sort_values(('DOCKNO','Total'),ascending=False)
print (area_pivot1)



# In[ ]:


##Branch Wise Summary
branch_pivot=df.pivot_table(index=['REASSIGN_DESTCD'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').reset_index()


# In[ ]:


branch_pivot['DOCKNO']=branch_pivot['DOCKNO'].astype(int)


# In[ ]:


branch_pivot1=branch_pivot.sort_values('DOCKNO',ascending=False)


# In[ ]:


branch_pivot1.head()


# In[ ]:


today=datetime.strftime(datetime.now(),'%Y-%m-%d')
today


# In[ ]:


with ExcelWriter(r'D:\Data\PPD Destination Cons\Part_Piece_At_Dest_'+str(today)+'.xlsx') as writer:
    area_pivot.to_excel(writer, sheet_name='Area Wise Summary',engine='xlsxwriter')
    branch_pivot.to_excel(writer, sheet_name='Branch Wise Summary',engine='xlsxwriter')
    #df.to_excel(writer,sheet_name='Con Data',engine='xlsxwriter')   


# In[ ]:


with ExcelWriter(r'D:\Data\PPD Destination Cons\Part_Piece_At_Dest_.xlsx') as writer:
    area_pivot.to_excel(writer, sheet_name='Area Wise Summary',engine='xlsxwriter')
    branch_pivot.to_excel(writer, sheet_name='Branch Wise Summary',engine='xlsxwriter')
    #df.to_excel(writer,sheet_name='Con Data',engine='xlsxwriter')   

df.to_csv(r'D:\Data\PPD Destination Cons\Con Data_'+str(today)+'.csv')
df.to_csv(r'D:\Data\PPD Destination Cons\Con Data.csv')

# In[ ]:


filepath=r'D:\Data\PPD Destination Cons\Part_Piece_At_Dest_.xlsx'
filepath1=r'D:\Data\PPD Destination Cons\Con Data.csv'


# In[ ]:


FROM='mis.ho@spoton.co.in'

TO=["dom_spot@spoton.co.in","rom_spot@spoton.co.in","aom_spot@spoton.co.in",'scincharge_spot@spoton.co.in',"SQ_SPOT@spoton.co.in"]
CC=['sqtf@spoton.co.in','rajesh.kumar@spoton.co.in','abhik.mitra@spoton.co.in','jothi.menon@spoton.co.in','shivananda.p@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in']
# TO=['mahesh.reddy@spoton.co.in']
# CC=['mahesh.reddy@spoton.co.in']
# BCC=['mahesh.reddy@spoton.co.in']

msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "PPD Cons Lying At Destination -" + str(today)
html3='''
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EWB_Cons_Booked_Not_available_Data.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EWB_Cons_Booked_Not_available_Data.csv</p></b>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EWB_Cons_Booked_PartB_Not_updated_Data.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/EWB_Cons_Booked_PartB_Not_updated_Data.csv</p></b>
'''
report=""
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='PFA PPD Cons Lying At Destination'
report+='<br>'
report+='AreaWise Summary'
report+='<br>'
report+='<br>'+area_pivot1.to_html()+'<br>'



#report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)

part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(filepath1,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
msg.attach(part1)

server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()

# except:

#   TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in'] 
#   CC=['mahesh.reddy@spoton.co.in']
#   FROM="mahesh.reddy@spoton.co.in"
#   msg = MIMEMultipart()
#   msg["From"] = FROM
#   msg["To"] = ",".join(TO)
#   msg["CC"] = ",".join(CC)
#   #msg["BCC"] = ",".join(BCC)
#   #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
#   msg["Subject"] = "PPD Cons Lying At Destination Error in Execution" 
#   report=""
#   report+='Hi,'

#   report+='<br>'
#   report+='There was some error in PPD Cons Lying At Destination'
#   report+='<br>'
  
#   abc=MIMEText(report.encode('utf-8'),'html')
#   msg.attach(abc)
#   server=smtplib.SMTP('smtp.sendgrid.net', 587)
#   server.ehlo()
#   server.starttls()
#   server.ehlo()
#   server.login("spoton.net.in", "Star@123#")
#   failed = server.sendmail(FROM, TO+CC, msg.as_string())
#   server.quit()


