# -*- coding: utf-8 -*-
"""
Created on Wed Dec 21 11:02:15 2016

@author: rajeeshv
"""

# -*- coding: utf-8 -*-

# In[1]:

import graphlab as gl
import graphlab.aggregate as agg
import pandas as pd
from datetime import datetime, timedelta
import networkx as nx
import time

import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
import os
import Utilities

datetoday = datetime.today().date()
lastmonth = datetoday-timedelta(days=31)
print 'lastmonth', lastmonth

datetoday = datetime.today()
datefilter = datetoday-timedelta(hours=24)
datefilter=datefilter.date()
datefilter

# In[2]:
#condata = gl.SFrame(r'D:\Python\Scripts and Files\Path and Graph Files\Con_data_201016.csv')
#condata = gl.SFrame(r'http://spoton.co.in/downloads/IEP_CON_DATA_TO_SQ/IEP_CON_DATA_TO_SQ.csv')

## Edit on 19-12-2016

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
#cursor = cnxn.cursor()

conquery = ("""
        EXEC USP_CON_DATA_SQ_IE_DOCTDT
        """)


condata = pd.read_sql(conquery, Utilities.cnxn)
print type(condata)
condata = condata.rename(columns={'\xef\xbb\xbfDOCKNO': 'DOCKNO'})

#
#condata = gl.SFrame(data=condata_df)
#print type(condata_df)

##condata = gl.SFrame.read_csv(r'D:\Data\Damage_BADPOD_Customerwise\Condata_df.csv')
## Edit on 19-12-2016

#condata = condata.rename({'\xef\xbb\xbfDOCKNO': 'DOCKNO'})

# In[3]:

# Edit on 19-12-2016 to handle KeyError: ('Pickupdate', u'occurred at index DOCKNO')
condata['pkphr'] = condata.apply(lambda x: int(x['Pickupdate'].split(' ')[1].split(':')[0]),axis=1)

#condata['pkphr'] = condata.apply(lambda x: int(x['Pickupdate'].split(' ')[1].split(':')[0]),axis=1)
# Edit on 19-12-2016 to handle KeyError: ('Pickupdate', u'occurred at index DOCKNO')

dayzero = datetime.strptime('01/01/2016','%d/%m/%Y')
timeformat2 = '%Y-%m-%d'
timeformat3 = '%d/%m/%y'
timeformat4 = '%d-%b-%y'
timeformat5 = '%d-%m-%Y'
timeformat6 = '%d/%m/%Y'

def convertdate2(*vars):
    x = vars[0]
    flag = vars[1]
    timeformata = timeformat2
    timeformatb = timeformat3
    timeformatc = timeformat4
    timeformatd = timeformat5
    timeformate = timeformat6
    
    try:       
        x = x.split(' ')[0]
        return datetime.strptime(x,timeformata)
    except:
        try:
            x = x.split(' ')[0]
            return datetime.strptime(x,timeformatb)
        except:
            try:
                x = x.split(' ')[0]
                return datetime.strptime(x,timeformatc)
            except:
                try:
                    x = x.split(' ')[0]
                    return datetime.strptime(x,timeformatd)    
                except:
                    try:
                        x = x.split(' ')[0]
                        return datetime.strptime(x,timeformate)
                    except:
                        if flag=='today':
                            return datetime.today()
                        else:
                            return dayzero
condata['PickupDate'] = condata.apply(lambda x: convertdate2(x['Pickupdate'],'dayz'),axis=1)

# In[4]:

#last 30 days short data
#badpoddata_full = gl.SFrame(r'http://spoton.co.in/downloads/IE_BADPOD_CUST_DATA/IE_BADPOD_CUST_DATA.csv')
badpoddata_full = pd.read_csv(r'http://spoton.co.in/downloads/IE_BADPOD_CUST_DATA/IE_BADPOD_CUST_DATA.csv')
#badpoddata.rename({'\xef\xbb\xbfDOCKNO': 'DOCKNO'})
badpoddata_full.to_csv(r'D:\Data\Damage_BADPOD_Customerwise\BAD_POD_basedata_Full\Damage_Badpod_Custwise_cons_'+str(datefilter)+'.csv')

### Edit for renaming Code to CODE  on 12-12-2016
badpoddata_full.rename(columns={'\xef\xbb\xbfDOCKNO': 'DOCKNO'})
### Edit for renaming Code to CODE  on 12-12-2016


badpoddata_full['PickupDate'] = badpoddata_full.apply(lambda x: convertdate2(x['DOCKDT'],'dayz'),axis=1)
badpoddata_full['statusdate'] = badpoddata_full.apply(lambda x: convertdate2(x['ConStatusDate'],'dayz'),axis=1)


## Slicing Dataframe to get cons with status updates in last 30 days
badpoddata = badpoddata_full[badpoddata_full['statusdate']>=lastmonth]
print len(badpoddata)
badpoddata.to_csv(r'D:\Data\Damage_BADPOD_Customerwise\BAD_POD_basedata_MTH\Damage_Badpod_Custwise_MTH_'+str(datefilter)+'.csv')
## Slicing Dataframe to get cons with status updates in last 30 days


condatagrp = condata.groupby(['Customer_Code','Customer_Name']).agg({'DOCKNO': len}).reset_index()
print 'condata cust code',condata['Customer_Code'].values[0],float(condata['Customer_Code'].values[0])
condatagrp['Customer_Code'] = condatagrp.apply(lambda x:float(x['Customer_Code']),axis=1)

badpoddatapivot = pd.pivot_table(badpoddata,index=['Customer_Code','Customer_Name'],columns=['Type'],values=['DOCKNO'],aggfunc=[len]).reset_index()
print 'before columns',badpoddatapivot.columns.tolist()
badpoddatapivot.columns = [' '.join(col).strip() for col in badpoddatapivot.columns.values]
print 'after columns',badpoddatapivot.columns.tolist()

badpoddatapivot = badpoddatapivot.rename(columns={'len Damage':'Damage','len Damge and Theft':'Damage&Theft','len Pilferage':'Pilferage','len Shortage':'Shortage'})
print 'badpoddatapivot cust code',badpoddatapivot['Customer_Code'].values[0],type(badpoddatapivot['Customer_Code'].values[0])
# In[12]:
badpodsummary = pd.merge(condatagrp,badpoddatapivot,on=['Customer_Code','Customer_Name'],how='left')
badpodsummary = badpodsummary.fillna(0)

badpodsummary['%Dmg'] = badpodsummary.apply(lambda x:round(x['Damage']*100.0/x['DOCKNO'],1),axis=1)
badpodsummary['%D_T'] = badpodsummary.apply(lambda x:round(x['Damage&Theft']*100.0/x['DOCKNO'],1),axis=1)
badpodsummary['%Pil'] = badpodsummary.apply(lambda x:round(x['Pilferage']*100.0/x['DOCKNO'],1),axis=1)
badpodsummary['%Short'] = badpodsummary.apply(lambda x:round(x['Shortage']*100.0/x['DOCKNO'],1),axis=1)

badpodsummary['Total_DEPS'] = badpodsummary.apply(lambda x:(x['Damage']+x['Damage&Theft']+x['Pilferage']+x['Shortage']),axis=1)
badpodsummary = badpodsummary.sort_values('Total_DEPS',ascending=False)

badpodsummary = pd.DataFrame(badpodsummary,columns=['Customer_Code','Customer_Name','DOCKNO','Total_DEPS','Damage','%Dmg','Damage&Theft','%D_T','Pilferage','%Pil','Shortage','%Short'])

badpodsummary_mail = pd.DataFrame(badpodsummary,columns=['Customer_Code','Customer_Name','%Dmg','%D_T','%Pil','%Short'])
badpodsummary_mail = badpodsummary_mail.head(15)
badpodsummary_mail = badpodsummary_mail.to_string(index=False)
# In[14]:


# In[16]:
badpodsummary.loc[badpodsummary.index,'Date'] = datefilter
badpodsummary.to_csv(r'D:\Data\Damage_BADPOD_Customerwise\Report_summary\BADPOD_Customerwise_Report_'+str(datefilter)+'.csv')
oppath1 = r'D:\Data\Damage_BADPOD_Customerwise\Report_summary\BADPOD_Customerwise_Report_'+str(datefilter)+'.csv'

# In[ ]:
filePath = oppath1
def sendEmail(TO = ["sq_spot@spoton.co.in","rom_spot@spoton.co.in","dom_spot@spoton.co.in",'abhishek.cv@spoton.co.in','dhiraj.patil@spoton.co.in'],
             #TO = ["vishwas.j@spoton.co.in"],
             #TO = ["rajeesh.vr@spoton.co.in"],
             #BCC =  ["vishwas.j@spoton.co.in","shivananda.p@spoton.co.in"],
             CC =  ["sqtf@spoton.co.in"],
             #CC =  ["vishwas.j@spoton.co.in"],
             BCC =  ["mahesh.reddy@spoton.co.in"],
            #FROM="mis.ho@spoton.co.in"):
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
    #HOST = "smpt.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DEPOTWISE OPS Bucket Stock  - "+ str(datefilter)
    msg["Subject"] = "Bad Pod Category-Customerwise Report - "+ str(datefilter)
    body_text = """
    Dear All,
    
    This report gives the Bad Pod cons (categorywise) in comparison with the Total cons picked up for the customers in last 30 days
    
    PFB the Bad Pod Category - Customerwise Report as of """ + str(datefilter) +"""
    
"""+str(badpodsummary_mail)+"""
     
    Note:
    %Dmg : % Of Total pickup cons updated as Damage in the last 30 days
    %D_T : % Of Total pickup cons updated as Damage/Theft in the last 30 days
    %Pil : % Of Total pickup cons updated as Pilferage in the last 30 days
    %Short : % Of Total pickup cons updated as Shortage in the last 30 days
    
    """
    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    #server.login("mis.ho@spoton.co.in", "Mis@2019")
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
#print('Email sent')


