
# coding: utf-8

# In[1]:

import pandas as pd
import smtplib
import os
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import datetime
from datetime import datetime
from datetime import timedelta


# In[2]:

pudrmsdata = pd.read_csv(r'http://spoton.co.in/downloads/IEProjects/PRCU/PRCU.csv')
print len(pudrmsdata)
pudrmsdata = pudrmsdata.dropna(subset=['VehicleType'])
print len(pudrmsdata)
pudrmsdata = pudrmsdata.rename(columns={'\xef\xbb\xbfDy':'Date'})


# In[3]:

pudrmsdatagrp = pudrmsdata.groupby(['Date','Brcd','Banm','VehicleNo','PUDRouteName','VEHICLECAPACITY']).agg({'OFD_CONS':sum,'OFD_ACTWT':sum,'PKP_ACTWT':sum,'DLV_UNIQUEPINCODES':sum,'MISSPICKUPS':sum,'NONDLV_CONS':sum}).reset_index()
pudrmsdatagrp['VEHICLE_CAPACITY_NEW'] = pudrmsdatagrp.apply(lambda x:abs(x['VEHICLECAPACITY']),axis=1)

# In[4]:

def utilcalc(vehcap,ofdwt,pkpwt):
    totalwt = ofdwt+pkpwt
    try:
        util = (pd.np.round((totalwt/vehcap),4))*100
        return util
    except:
        return 0


# In[5]:

pudrmsdatagrp['Utilization'] = pudrmsdatagrp.apply(lambda x:utilcalc(x['VEHICLE_CAPACITY_NEW'],x['OFD_ACTWT'],x['PKP_ACTWT']),axis=1)


# In[6]:

now = datetime.now()
yestday = now-timedelta(hours=24)
yestdate = yestday.date()


# In[7]:

pudrmsdatagrp.to_csv(r'D:\Data\PUD_RMS\Vehiclewise_routewise\PUD_RMS_Report_'+str(yestdate)+'.csv')
oppath1 = r'D:\Data\PUD_RMS\Vehiclewise_routewise\PUD_RMS_Report_'+str(yestdate)+'.csv'


# In[8]:

filePath = oppath1
def sendEmail(TO = ["goutam.barik@spoton.co.in","sukumar.sakthivel@spoton.co.in"],
              #TO = ["vishwas.j@spoton.co.in"],
             #TO = ["rajeesh.vr@spoton.co.in"],
             CC = ["abhik.mitra@spoton.co.in","rajeesh.vr@spoton.co.in"],
             #CC = ["vishwas.j@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "PUD RMS Report - "+ str(yestdate)
    body_text = """
    Dear All,
    
    PFA the PUD RMS report for """+str(yestdate)+"""
    
    
    """
    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("vishwas.j@spoton.co.in", "Startrek!123")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends

