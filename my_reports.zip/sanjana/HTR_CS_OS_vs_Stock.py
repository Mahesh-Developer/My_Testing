
# coding: utf-8

# In[1]:


import pandas as pd
from datetime import datetime, date, timedelta
import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import Utilities
import numpy as np
# In[2]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()


# In[3]:


destquery = ("""EXEC USP_CLOSINGSTOCK_REPORT_1HR_IE""")
destsc = pd.read_sql(destquery, cnxn) 


# In[4]:


orgquery = ("""EXEC USP_ORIGINSC_STOCK """)
originstock = pd.read_sql(orgquery, cnxn)


# In[5]:


htrquery = ("""EXEC USP_HUB_THROUGHPUT_DETAILS_SALES_ONEHOUR""")
invdf = pd.read_sql(htrquery, cnxn)


# In[6]:


len(invdf), len(originstock),len(destsc)


# In[7]:


destsc = destsc[destsc['DRS_PREPARED']=='NO']


# In[8]:


originstock['Dest_Check'] = originstock.apply(lambda x: True if x['ORGBRCD']== x['DLVBRCD'] else False, axis=1)
originstock = originstock[originstock['Dest_Check']==False]


# In[9]:


invdf['Org_Check'] = invdf.apply(lambda x: True if x['Hub/SC Location']== x['Origin Branch'] else False, axis=1)
invdf = invdf[invdf['Org_Check']==False]


# In[10]:


len(invdf), len(originstock)


# In[11]:


invgrp = invdf.groupby(['Hub/SC Location']).agg({'Act.WtInTonnes':sum}).reset_index()
invgrp['Act.WtInTonnes'] = pd.np.round(invgrp['Act.WtInTonnes'],2)
invgrp.rename(columns={'Hub/SC Location':'Location','Act.WtInTonnes':'WT'},inplace=True)


# In[12]:


origingrp = originstock.groupby(['ORGBRCD']).agg({'ACTUWT':sum}).reset_index()
origingrp['ACTUWT'] = pd.np.round(origingrp['ACTUWT']/1000.0,2)
origingrp.rename(columns={'ORGBRCD':'Location','ACTUWT':'WT'},inplace=True)


# In[13]:


destscgrp = destsc.groupby(['DEST_BRCD']).agg({'ACTUWT':sum}).reset_index()
destscgrp['ACTUWT'] = pd.np.round(destscgrp['ACTUWT']/1000.0,2)
destscgrp.rename(columns={'DEST_BRCD':'Location','ACTUWT':'WT'},inplace=True)


# In[14]:


orgdest = pd.merge(origingrp, destscgrp , on=['Location'],suffixes=['_Org','_Dest'],how='outer')
mergedf = pd.merge(orgdest, invgrp, on='Location', how='outer')


# In[15]:


mergedf.fillna(0,inplace=True)


# In[16]:


mergedf


# In[17]:


stockquery = ("""SELECT  * ,
        ( SELECT TOP 1
                    CONVERT(DATE, Delv_Appo_ReminderDate) AppDt
          FROM      tblCONStatusCodes WITH ( NOLOCK )

          WHERE     DOCKNO = [ConNumber]

          ORDER BY  Delv_Appo_ReminderDate DESC

        ) APPOINTMENTDATE ,

        ( SELECT TOP 1

                    CONStatusReason

          FROM      tblCONStatusCodes WITH ( NOLOCK )

          WHERE     DOCKNO = [ConNumber]

          ORDER BY  Delv_Appo_ReminderDate DESC

        ) APPOINTMENT_REMARKS

FROM    ( SELECT DISTINCT

                    A.DOCKNO [ConNumber] ,

                    CONVERT(date, B.DOCKDT) AS [BookingDate] ,

                    CONVERT(VARCHAR, B.DOCKDT, 108) AS [BookingTime] ,

                    CONVERT(date, B.CDELDT) AS [DueDate] ,

                    OBR.DEPOT_CODE [OriginDepot] ,

                    OBR.ControlArea [OriginArea] ,

                    B.ORGNCD [OriginBranch] ,

                    DBR.DEPOT_CODE [DestnDepot] ,

                    DBR.ControlArea [DestnArea] ,

                    B.REASSIGN_DESTCD [DestnBranch] ,

                    CBR.DEPOT_CODE [CurrentDepot] ,

                    CBR.ControlArea [CurrentArea] ,

                    S.DOC_CURLOC [CurrentBranch] ,

                    CONVERT(date, S.PCS_ARRV_DT) AS [ArrivalDateAtCurrentBranch] ,

                    CONVERT(VARCHAR, S.PCS_ARRV_DT, 108) AS [ArrivalTimeAtCurrentBranch] ,

                    DATEDIFF(HH, S.PCS_ARRV_DT, GETDATE()) [Lying Hours] ,

                    DATEDIFF(DAY, S.PCS_ARRV_DT, GETDATE()) AS [LyingDays] ,

                    --ta.AccountType AS [CATEGORY OF CUSTOMER] ,

             

                    B.CSGNCD [SenderCode] ,

                    B.CSGNNM [SenderName] ,

                    B.CSGECD [ReceiverCode] ,

                    B.CSGENM [ReceiverName] ,

                    B.CSGEPHONE AS [ReceiverPhno] ,

                    B.PKGSNO [TotalNoOfPackages] ,

                    B.ACTUWT [TotalActualWeight] ,

                    B.CFT_TOTAL [VolumeInCFT] ,

                    B.CHRGWT [ChargedWeight] ,

                    S.AvailPiecesAtLoc [Available Stock Pieces] ,

                    S.AvailPiecesWtAtLoc [Available Stock Pieces - Actual Weight] ,

            

    


                    NULL DeliveryDate ,

                    LA.ConStatusCode [LatestStatusCode] ,

                    uty.Description [LatestStatus] ,

                    CONVERT(date, LA.ConStatusDate) AS [LatestStatusDate] ,

                    LA.ConStatusReason [LatestStatusReason] ,

                    LA.StatusBranch [LatestStatusBranch] ,

                    CASE WHEN ( uty.Code = 'L' ) THEN 'LINEHAUL FAILURE'

                         WHEN ( uty.Code = 'O' ) THEN 'ORIGIN FAILURE'

                         WHEN ( uty.Code = 'S' ) THEN 'SENDER FAILURE'

                         WHEN ( uty.Code = 'N' )

                         THEN 'NON-CONTROLLABLE FAILURE'

                         WHEN ( uty.Code = 'D' ) THEN 'DESTINATION FAILURE'

                         WHEN ( uty.Code = 'R' ) THEN 'RECEIVER FAILURE'

                         WHEN ( uty.Code = 'P' ) THEN 'PROCESS FAILURE'

                         WHEN ( uty.Code = 'F' ) THEN 'FINAL STATUS'

                         WHEN ( uty.Code = 'E' ) THEN 'DEPS'

                         WHEN ( uty.Code = 'H' ) THEN 'HUB FAILURE'

                         ELSE uty.Code

                    END [LatestStatusCategory] ,

                    CASE WHEN ( LA.DEPSPcs IS NULL ) THEN ''

                         ELSE CAST(LA.DEPSPcs AS VARCHAR)

                    END [DEPSPieces] ,

               

                    CASE WHEN B.REASSIGN_DESTCD != S.DOC_CURLOC THEN 'NO'

                         ELSE CASE WHEN ISNULL(ISFREECON_ASPER_DEM, 'Y') = 'Y'

                                   THEN 'NO'

                                   ELSE 'YES'

                              END

                    END DEM_DRS_BLOCK_STATUS ,

                    A.FREE_STORAGE_DAYS FreeStorageDays ,

                    CASE WHEN B.REASSIGN_DESTCD != S.DOC_CURLOC THEN ''

                         ELSE CASE WHEN ( A.DEMCHRG_APPLICABLE = 'N' )

                                   THEN 'DRS ALLOWED, DEMURRAGE CHARGE IS NOT APPLICABLE'

                                   WHEN ( ISNULL(A.DCMRNO, '') <> ''

                                          AND A.DEM_ISAPPROVED = 'P'

                                        )

                                   THEN 'DRS BLOCKED, WAITING FOR CS/RSM APPROVAL'

                                   WHEN ( ISNULL(A.DCMRNO, '') = ''

                                          AND A.DEM_ISAPPROVED = 'P'

                                        )

                                   THEN 'DRS BLOCKED, MR NEEDS TO BE GENERATED'

                                   WHEN ( ISNULL(A.DCMRNO, '') <> ''

                                          AND A.DEM_ISAPPROVED = 'A'

                                          AND ( ISNULL(A.DEM_PIS_CustomerAgreedBy,

                                                       '') = 'R'

                                                OR A.DEM_CreditPaymentType = 'CR'

                                              )

                                        ) THEN 'DRS ALLOWED'

                                   WHEN ( ISNULL(A.DCMRNO, '') <> ''

                                          AND A.DEM_ISAPPROVED = 'A'

                                          AND ISNULL(A.DEM_PIS_CustomerAgreedBy,

                                                     '') = 'S'

                                          AND A.DEM_PISCollectionDone = 'N'

                                        )

                                   THEN 'DRS BLOCKED, WAITING FOR ORIGIN PIS ENTRY'

                                   WHEN ( ISNULL(A.DCMRNO, '') <> ''

                                          AND A.DEM_ISAPPROVED = 'A'

                                          AND ISNULL(A.DEM_PIS_CustomerAgreedBy,

                                                     '') = 'S'

                                          AND A.DEM_PISCollectionDone = 'Y'

                                        ) THEN 'DRS ALLOWED'

                                   ELSE ''

                              END

                    END DEM_DRS_BLOCK_REMARKS ,ppm.pcustno [Parent code],ppm.PCUSTNAME [Parent Name]

                  

          FROM      ( SELECT    S.DOCKNO ,

                                pcs.pcs_curloc DOC_CURLOC ,

                                MIN(pcs.pcs_arrvdt) PCS_ARRV_DT ,

                                COUNT(pcs.PartNo) AvailPiecesAtLoc ,

                                SUM(pcs.pcs_actuwt) AvailPiecesWtAtLoc

                      FROM      tblStockCons S WITH ( NOLOCK )

                                INNER JOIN PCR_PIECES_Detail pcs WITH ( NOLOCK ) ON S.DOCKNO = pcs.Dockno

                      WHERE     pcs.isActive = 1

                                AND ISNULL(pcs.pcs_thcno, '') = ''

                                AND ISNULL(pcs.pcs_dly, 'N') = 'N'

                                AND ISNULL(pcs.pcs_DRSNo, '') = ''

                      GROUP BY  S.DOCKNO ,

                                pcs.pcs_curloc

                    ) S

                    INNER JOIN tblStockCons A WITH ( NOLOCK ) ON A.DOCKNO = S.DOCKNO

                    INNER JOIN dbo.DOCKET B WITH ( NOLOCK ) ON A.DOCKNO = B.DOCKNO

                    LEFT OUTER JOIN PCUST_MAIN pcm WITH ( NOLOCK ) ON pcm.ptmsptcd = B.CONSIGNOR

                    LEFT OUTER JOIN ESTL_CRP2.dbo.tblAccountTypeMst ta WITH ( NOLOCK ) ON ta.AccountTypeID = pcm.AccountTypeID

                    LEFT OUTER JOIN dbo.tblTop50CustomersList CL WITH ( NOLOCK ) ON CL.PTMSPTCD = pcm.ptmsptcd

                    INNER JOIN dbo.brms BR WITH ( NOLOCK ) ON BR.BRCD = S.DOC_CURLOC

                    LEFT OUTER JOIN dbo.tblDocketFinalStatus F WITH ( NOLOCK ) ON F.DOCKNO = A.DOCKNO

                    LEFT OUTER JOIN dbo.tblCONStatusCodesLatest LA WITH ( NOLOCK ) ON A.DOCKNO = LA.Dockno

                    LEFT OUTER JOIN dbo.tblConRecordCommLatest RCLA WITH ( NOLOCK ) ON A.DOCKNO = RCLA.ConNo

                    LEFT OUTER JOIN dbo.tblOperationsUtyMst uty WITH ( NOLOCK ) ON LA.ConStatusCode = uty.OpCode

                    INNER JOIN brms OBR WITH ( NOLOCK ) ON OBR.BRCD = B.ORGNCD

                    INNER JOIN brms DBR WITH ( NOLOCK ) ON DBR.BRCD = B.REASSIGN_DESTCD

                    INNER JOIN brms CBR WITH ( NOLOCK ) ON CBR.BRCD = S.DOC_CURLOC

                    INNER JOIN dbo.tblPaymentBasisTypeMst PM WITH ( NOLOCK ) ON PM.PaymentBasisTypeID = B.PAYBAS

                    INNER JOIN dbo.tblLocationMst DLM WITH ( NOLOCK ) ON B.DestnLocID = DLM.LocationID
					LEFT JOIN (SELECT PCUSTNO,PCUSTNAME,isparent,ptmsptcd FROM dbo.PCUST_MAIN WHERE isparent=1) ppm ON ppm.ptmsptcd=b.consignor

          WHERE     F.DOCKNO IS NULL

                    AND B.PAYBAS <> '6'

                    AND YEAR(B.DOCKDT) = 2019

                    AND CBR.BRCD IN (SELECT brcd FROM dbo.brms WITH(nolock))

                    AND DATEDIFF(HH, ISNULL(S.PCS_ARRV_DT, GETDATE()),

                                 GETDATE()) >= 0 AND pcm.isparent=1
          UNION
          SELECT DISTINCT
                    B.DOCKNO [ConNumber] ,
                    CONVERT(date, B.DOCKDT) AS [BookingDate] ,
                    CONVERT(VARCHAR, B.DOCKDT, 108) AS [BookingTime] ,
                    CONVERT(date, B.CDELDT) AS [DueDate] ,
                    OBR.DEPOT_CODE [OriginDepot] ,
                    OBR.ControlArea [OriginArea] ,
                    B.ORGNCD [OriginBranch] ,
                    DBR.DEPOT_CODE [DestnDepot] ,
                    DBR.ControlArea [DestnArea] ,
                    B.REASSIGN_DESTCD [DestnBranch] ,
                    CBR.DEPOT_CODE [CurrentDepot] ,
                    CBR.ControlArea [CurrentArea] ,
                    S.DOC_CURLOC [CurrentBranch] ,
                    CONVERT(date, S.PCS_ARRV_DT) AS [ArrivalDateAtCurrentBranch] ,
                    CONVERT(VARCHAR, S.PCS_ARRV_DT, 108) AS [ArrivalTimeAtCurrentBranch] ,
                    DATEDIFF(HH, S.PCS_ARRV_DT, GETDATE()) AS [Lying Hours] ,
                    DATEDIFF(DAY, S.PCS_ARRV_DT, GETDATE()) AS [LyingDays] ,
                    --ta.AccountType AS [CATEGORY OF CUSTOMER] ,
                    --CASE WHEN ( B.CSGNCD = CL.PTMSPTCD ) THEN 'YES'
                    --     ELSE 'NO'
                    --END AS TOP50CUST ,
                    B.CSGNCD [SenderCode] ,
                    B.CSGNNM [SenderName] ,
                    B.CSGECD [ReceiverCode] ,
                    B.CSGENM [ReceiverName] ,
                    B.CSGEPHONE AS [ReceiverPhno] ,
                    B.PKGSNO [TotalNoOfPackages] ,
                    B.ACTUWT [TotalActualWeight] ,
                    B.CFT_TOTAL [VolumeInCFT] ,
                    B.CHRGWT [ChargedWeight] ,
                    S.AvailPiecesAtLoc [Available Stock Pieces] ,
                    S.AvailPiecesWtAtLoc [Available Stock Pieces - Actual Weight] ,
                    NULL DeliveryDate ,
                    LA.ConStatusCode [LatestStatusCode] ,
                    uty.Description [LatestStatus] ,
                    CONVERT(date, LA.ConStatusDate) AS [LatestStatusDate] ,
                    LA.ConStatusReason [LatestStatusReason] ,
                    LA.StatusBranch [LatestStatusBranch] ,
                    CASE WHEN ( uty.Code = 'L' ) THEN 'LINEHAUL FAILURE'
                         WHEN ( uty.Code = 'O' ) THEN 'ORIGIN FAILURE'
                         WHEN ( uty.Code = 'S' ) THEN 'SENDER FAILURE'
                         WHEN ( uty.Code = 'N' )
                         THEN 'NON-CONTROLLABLE FAILURE'
                         WHEN ( uty.Code = 'D' ) THEN 'DESTINATION FAILURE'
                         WHEN ( uty.Code = 'R' ) THEN 'RECEIVER FAILURE'
                         WHEN ( uty.Code = 'P' ) THEN 'PROCESS FAILURE'
                         WHEN ( uty.Code = 'F' ) THEN 'FINAL STATUS'
                         WHEN ( uty.Code = 'E' ) THEN 'DEPS'
                         WHEN ( uty.Code = 'H' ) THEN 'HUB FAILURE'
                         ELSE uty.Code
                    END [LatestStatusCategory] ,
                    CASE WHEN ( LA.DEPSPcs IS NULL ) THEN ''
                         ELSE CAST(LA.DEPSPcs AS VARCHAR)
                    END [DEPSPieces] ,
                    CASE WHEN B.REASSIGN_DESTCD != S.DOC_CURLOC THEN 'NO'
                         ELSE CASE WHEN ( ISNULL(UFN.DCMRNO, '') <> ''
                                          AND UFN.ISAPPROVED = 'P'
                                        ) THEN 'YES'
                                   WHEN ( ISNULL(UFN.DCMRNO, '') = ''
                                          AND UFN.ISAPPROVED = 'P'
                                        ) THEN 'YES'
                                   WHEN ( ISNULL(UFN.DCMRNO, '') <> ''
                                          AND UFN.ISAPPROVED = 'A'
                                          AND ( ISNULL(UFN.PIS_CustomerAgreedBy,
                                                       '') = 'R'
                                                OR UFN.CreditPaymentType = 'CR'
                                              )
                                        ) THEN 'NO'
                                   WHEN ( ISNULL(UFN.DCMRNO, '') <> ''
                                          AND UFN.ISAPPROVED = 'A'
                                          AND ISNULL(UFN.PIS_CustomerAgreedBy,
                                                     '') = 'S'
                                          AND UFN.PISCollectionDone = 'N'
                                        ) THEN 'YES'
                                   WHEN ( ISNULL(UFN.DCMRNO, '') <> ''
                                          AND UFN.ISAPPROVED = 'A'
                                          AND ISNULL(UFN.PIS_CustomerAgreedBy,
                                                     '') = 'S'
                                          AND UFN.PISCollectionDone = 'Y'
                                        ) THEN 'YES'
                                   ELSE 'NO'
                              END
                    END DEM_DRS_BLOCK_STATUS ,
                    dbo.UFN_GET_FREESTORAGEDAYS(B.DOCKNO) FreeStorageDays ,
                    CASE WHEN B.REASSIGN_DESTCD != S.DOC_CURLOC THEN ''
                         ELSE CASE WHEN ( UFN.DEMCHRG_APPLICABLE = 'N' )
                                   THEN 'DRS ALLOWED, DEMURRAGE CHARGE IS NOT APPLICABLE'
                                   WHEN ( ISNULL(UFN.DCMRNO, '') <> ''
                                          AND UFN.ISAPPROVED = 'P'
                                        )
                                   THEN 'DRS BLOCKED, WAITING FOR CS/RSM APPROVAL'
                                   WHEN ( ISNULL(UFN.DCMRNO, '') = ''
                                          AND UFN.ISAPPROVED = 'P'
                                        )
                                   THEN 'DRS BLOCKED, MR NEEDS TO BE GENERATED'
                                   WHEN ( ISNULL(UFN.DCMRNO, '') <> ''
                                          AND UFN.ISAPPROVED = 'A'
                                          AND ( ISNULL(UFN.PIS_CustomerAgreedBy,
                                                       '') = 'R'
                                                OR UFN.CreditPaymentType = 'CR'
                                              )
                                        ) THEN 'DRS ALLOWED'
                                   WHEN ( ISNULL(UFN.DCMRNO, '') <> ''
                                          AND UFN.ISAPPROVED = 'A'
                                          AND ISNULL(UFN.PIS_CustomerAgreedBy,
                                                     '') = 'S'
                                          AND UFN.PISCollectionDone = 'N'
                                        )
                                   THEN 'DRS BLOCKED, WAITING FOR ORIGIN PIS ENTRY'
                                   WHEN ( ISNULL(UFN.DCMRNO, '') <> ''
                                          AND UFN.ISAPPROVED = 'A'
                                          AND ISNULL(UFN.PIS_CustomerAgreedBy,
                                                     '') = 'S'
                                          AND UFN.PISCollectionDone = 'Y'
                                        ) THEN 'DRS ALLOWED'
                                   ELSE ''
                              END
                    END DEM_DRS_BLOCK_REMARKS ,ppm.pcustno [Parent code],ppm.PCUSTNAME [Parent Name]
          FROM      ( SELECT    S.DOCKNO ,
                                pcs.pcs_curloc DOC_CURLOC ,
                                MIN(pcs.pcs_arrvdt) PCS_ARRV_DT ,
                                COUNT(pcs.PartNo) AvailPiecesAtLoc ,
                                SUM(pcs.pcs_actuwt) AvailPiecesWtAtLoc
                      FROM      DOCKET S WITH ( NOLOCK )
                                INNER JOIN PCR_PIECES_Detail pcs WITH ( NOLOCK ) ON S.DOCKNO = pcs.Dockno
                      WHERE     ( pcs.pcs_arrvdt >= '2019-04-30'
                                  OR S.EntryDate >= '2019-04-30'
                                )
                                AND YEAR(S.DOCKDT) = 2019
                                AND S.PAYBAS <> '6'
                                AND pcs.isActive = 1
                                AND ISNULL(pcs.pcs_thcno, '') = ''
                                AND ISNULL(pcs.pcs_dly, 'N') = 'N'
                                AND ISNULL(pcs.pcs_DRSNo, '') = ''
                      GROUP BY  S.DOCKNO ,
                                pcs.pcs_curloc
                    ) S
                    INNER JOIN dbo.DOCKET B WITH ( NOLOCK ) ON S.DOCKNO = B.DOCKNO
                    LEFT OUTER JOIN PCUST_MAIN pcm WITH ( NOLOCK ) ON pcm.ptmsptcd = B.CONSIGNOR
                    LEFT OUTER JOIN ESTL_CRP2.dbo.tblAccountTypeMst ta WITH ( NOLOCK ) ON ta.AccountTypeID = pcm.AccountTypeID
                    LEFT OUTER JOIN dbo.tblTop50CustomersList CL WITH ( NOLOCK ) ON CL.PTMSPTCD = pcm.ptmsptcd
                    INNER JOIN dbo.brms BR WITH ( NOLOCK ) ON BR.BRCD = S.DOC_CURLOC
                    LEFT OUTER JOIN dbo.tblDocketFinalStatus F WITH ( NOLOCK ) ON F.DOCKNO = B.DOCKNO
                    LEFT OUTER JOIN dbo.tblCONStatusCodesLatest LA WITH ( NOLOCK ) ON B.DOCKNO = LA.Dockno
                    LEFT OUTER JOIN dbo.tblConRecordCommLatest RCLA WITH ( NOLOCK ) ON B.DOCKNO = RCLA.ConNo
                    LEFT OUTER JOIN dbo.tblOperationsUtyMst uty WITH ( NOLOCK ) ON LA.ConStatusCode = uty.OpCode
                    INNER JOIN brms OBR WITH ( NOLOCK ) ON OBR.BRCD = B.ORGNCD
                    INNER JOIN brms DBR WITH ( NOLOCK ) ON DBR.BRCD = B.REASSIGN_DESTCD
                    INNER JOIN brms CBR WITH ( NOLOCK ) ON CBR.BRCD = S.DOC_CURLOC
                    INNER JOIN dbo.tblPaymentBasisTypeMst PM WITH ( NOLOCK ) ON PM.PaymentBasisTypeID = B.PAYBAS
                    INNER JOIN dbo.tblLocationMst DLM WITH ( NOLOCK ) ON B.DestnLocID = DLM.LocationID
                    LEFT OUTER JOIN dbo.CO_Mail_Account COM WITH ( NOLOCK ) ON B.CSGNCD = COM.PTMSPTCD
LEFT JOIN (SELECT PCUSTNO,PCUSTNAME,isparent,ptmsptcd FROM dbo.PCUST_MAIN WHERE isparent=1) ppm ON ppm.ptmsptcd=b.consignor
                    CROSS APPLY dbo.UFN_GET_DEMURRAGE_DTLS_OF_CON(B.DOCKNO) UFN
--(SELECT PCUSTNO,PCUSTNAME,isparent,ptmsptcd FROM dbo.PCUST_MAIN WHERE isparent=1) ppm ON ppm.ptmsptcd=b.consignor
          WHERE     F.DOCKNO IS NULL 
                    AND CBR.BRCD IN ( SELECT brcd  FROM brms WITH(NOLOCK)) 
                    AND DATEDIFF(HH, ISNULL(S.PCS_ARRV_DT, GETDATE()),
                                 GETDATE()) >= 0
        ) AB
WHERE   DeliveryDate IS NULL
ORDER BY [Lying Hours] DESC""")


# In[18]:


stockdf = pd.read_sql(stockquery, cnxn)



# In[19]:


len(stockdf)


# In[20]:


stockdf_summary=stockdf.pivot_table(index=['CurrentBranch'],aggfunc={'Available Stock Pieces - Actual Weight':sum}).reset_index()


# In[21]:


stockdf_summary['Available Stock Pieces - Actual Weight']=pd.np.round(stockdf_summary['Available Stock Pieces - Actual Weight']/1000,2)


# In[22]:


stockdf_summary.rename(columns={'CurrentBranch':'Location','Available Stock Pieces - Actual Weight':'Stock_Wt'},inplace=True)


# In[23]:


final_summary=pd.merge(mergedf,stockdf_summary,on='Location',how='outer')


# In[24]:


final_summary=final_summary.fillna(0)


# In[25]:


final_summary['Total_Wt']=final_summary['WT_Org']+final_summary['WT_Dest']+final_summary['WT']


# In[26]:


final_summary['Diff_Wt(Stock-Total)']=final_summary['Stock_Wt']-final_summary['Total_Wt']
final_summary['%Diff']=pd.np.round(final_summary['Diff_Wt(Stock-Total)']*100.0/final_summary['Stock_Wt'],0)

final_summary=final_summary.replace([np.inf,-np.inf],np.nan).fillna(0)
# In[27]:


final_summary.sort_values('Diff_Wt(Stock-Total)',ascending=False,inplace=True)


# In[28]:


for i in final_summary.columns.tolist():
    if i=='Location':
        pass
    else:
        final_summary[i]=pd.np.round(final_summary[i],1)


# In[29]:


final_summary=final_summary[['Location','WT_Org','WT_Dest','WT','Total_Wt','Stock_Wt','Diff_Wt(Stock-Total)','%Diff']]

postive_summary=final_summary[final_summary['Diff_Wt(Stock-Total)']>0]
negative_summary=final_summary[final_summary['Diff_Wt(Stock-Total)']<0]
negative_summary=negative_summary.sort_values('Diff_Wt(Stock-Total)',ascending=True)
# In[ ]:
print (negative_summary.head(30))

#final_summary.sort_values('Diff_Wt(Stock-Reports)',ascending=False).to_csv(r'Bhargv_Query_Summary.csv')


# In[30]:


email_summary=postive_summary.head(15)
negative_email_summary=negative_summary.head(15)
print (negative_email_summary.head(10))

# In[35]:


todate=datetime.strftime(datetime.now(),'%Y-%m-%d -%H')
todate


# In[36]:


final_summary['Timestamp']=todate


# In[37]:


final_summary.to_csv(r'D:\Data\Inventory_Comparision\Weight_Summary'+str(todate)+'.csv')
stockdf.to_csv(r'D:\Data\Inventory_Comparision\Stock_Data'+str(todate)+'.csv')

# In[38]:


final_summary.to_csv(r'D:\Data\Inventory_Comparision\Weight_Summary.csv')


# In[39]:


filepath=r'D:\Data\Inventory_Comparision\Weight_Summary.csv'


# In[40]:


from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template
import pyodbc
import smtplib
import ftplib
import traceback


# In[41]:


TO=['satya.pal@spoton.co.in','syed.hussain@spoton.co.in']
CC=['mahesh.reddy@spoton.co.in']
FROM="reports.ie@spoton.co.in"

msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)

msg["Subject"] = "Inventory Comparasions @ Location " + " : " + str(todate)
html='''<html>
<h4>Dear All,</h4>
<p>PFA the Air Monitoring Report for $date</p>
</html>'''

report=""
report+="Dear All"
report+='<br>'
report+='Please find the Weight comparisions of Inventory, Closing Stock, Origin Stock and Stock Query'
report+='<br>'
report+='Please find the Top 15 Locations (Where Stock Wt is More)'
report+='<br>'
report+='<br>'+email_summary.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='Please find the Top 15 Locations (Where Stock Wt is less)'
report+='<br>'
report+='<br>'+negative_email_summary.to_html()+'<br>'
report+='<br>'


abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

# part1 = MIMEBase('application', "octet-stream")
# part1.set_payload( open(filepath1,"rb").read() )
# encoders.encode_base64(part1)
# part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
# msg.attach(part1)


# server=smtplib.SMTP('smtp.sendgrid.net', 587)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("mahesh.reddy@spoton.co.in", "Nov@2018")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()

