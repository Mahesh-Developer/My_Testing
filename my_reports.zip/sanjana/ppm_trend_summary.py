
# coding: utf-8

# In[1]:

import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
import glob


# In[2]:

glob.glob("D:\Data\PPM Movement Daily\DATA\PPM_Movement*.xlsx")


# In[3]:

all_data = pd.DataFrame()
con_data=pd.DataFrame()
for f in glob.glob("D:\Data\PPM Movement Daily\DATA\PPM_Movement*.xlsx"):
    df = pd.read_excel(f,"Summary")
    df_data=pd.read_excel(f,"Con Wise Data")
    file1=f.split('Daily')[2]
    date=file1.split('.')[0]
    print (date)
    date=datetime.strptime(date,'%Y-%m-%d')-timedelta(days=1)
    df['Timestamp']=date
    # df_data['Timestamp']=date
    all_data = all_data.append(df,ignore_index=True)
    con_data = con_data.append(df_data,ignore_index=True)
print len(all_data)
print (len(con_data))
#all_data.drop('Latest Status Reason',axis=1,inplace=True)


# In[4]:

all_data1=all_data[all_data['TYPE']!='Total']
len(all_data1)
# con_data=con_data.drop_duplicates('DOCKNO',inplace=True)

# In[5]:

all_data2=all_data1.pivot_table(index=['Timestamp'],columns=['TYPE'],aggfunc={'DOCKNO':sum}).reset_index().fillna(0)
all_data2['Total']=all_data2['DOCKNO'].sum(axis=1)

# In[6]:

all_data2['DOCKNO']=all_data2['DOCKNO'].astype(int)
all_data2['Total']=all_data2['Total'].astype(int)

all_data2.sort_values('Timestamp',ascending=False,inplace=True)

# In[7]:


# In[ ]:

# all_data2.to_csv(r'D:\Data\PPM Movement Daily\PPM Trend\')


# In[8]:

today=datetime.strftime(datetime.now(),'%Y-%m-%d')
today
with ExcelWriter(r'D:\Data\PPM Movement Daily\PPM Trend\PPM_Trend-'+str(today)+'.xlsx') as writer:
    all_data2.to_excel(writer, sheet_name='Trend Summary',engine='xlsxwriter')
    con_data.to_excel(writer, sheet_name='Data',engine='xlsxwriter')
with ExcelWriter(r'D:\Data\PPM Movement Daily\PPM Trend\PPM_Trend.xlsx') as writer:
    all_data2.to_excel(writer, sheet_name='Trend Summary',engine='xlsxwriter')
    con_data.to_excel(writer, sheet_name='Data',engine='xlsxwriter')


# In[9]:

filepath=r'D:\Data\PPM Movement Daily\PPM Trend\PPM_Trend.xlsx'


# In[10]:

FROM='mis.ho@spoton.co.in'


# TO=['HUBMGR_SPOT@spoton.co.in',"SQ_SPOT@spoton.co.in",'amit.s@spoton.co.in','plt.vigilance_sw@spoton.co.in','plt.vigilance_ne@spoton.co.in']
CC=['abhik.mitra@spoton.co.in','jothi.menon@spoton.co.in','shivananda.p@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in']

# TO=['mahesh.reddy@spoton.co.in']
#CC=['mahesh.reddy@spoton.co.in']
#BCC=['mahesh.reddy@spoton.co.in']

msg = MIMEMultipart()
msg["From"] = FROM
# msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "PPM Trend Summary -" + str(today)

report=""
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='PPM Summary'
report+='<br>'
report+='<br>'
report+='<br>'+all_data2.to_html()+'<br>'


#report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)

part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)



server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, CC+BCC, msg.as_string())
server.quit()



# In[ ]:



