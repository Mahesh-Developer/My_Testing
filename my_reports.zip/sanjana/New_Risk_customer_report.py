import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
import os
import glob
import Utilities


import sys
reload(sys).setdefaultencoding("ISO-8859-1")

datetoday = datetime.now().date()

todayminus1 = datetoday-timedelta(days=1)
todayminus2 = datetoday-timedelta(days=2)
todayminus3 = datetoday-timedelta(days=3)
todayminus4 = datetoday-timedelta(days=4)


# In[ ]:

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

def roundofffuncdiv(a,b):
    perc = pd.np.round((a*1.0/b)*100.0,2)
    return perc

crmpkpquery = ("""
        EXEC USP_RISK_CUST_CRM_PICKUP_DETAIL 'Y'
        """)
crmpkpdata = pd.read_sql(crmpkpquery, Utilities.cnxn)

print (crmpkpdata.head())