
# coding: utf-8

# In[1]:

import pandas as pd
from datetime import datetime, timedelta
import numpy as np
from sqlalchemy import *
import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import sys
import Utilities
import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

reload(sys).setdefaultencoding("ISO-8859-1")
pd.set_option("display.max_columns",100)
# engine = create_engine("mysql+pymysql://spotonhr:spoton54321@104.199.198.197/condata")
pd.set_option("display.max_columns",100)


# In[2]:

#1. Read the file and compute delay hours

#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
#cursor = cnxn.cursor() 
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()
try:
    query = ("""
            EXEC USP_CLOSINGSTOCK_REPORT_1HR_IE
            """)
    df = pd.read_sql(query,Utilities.cnxn) 
    # df = pd.read_sql(query,cnxn) 
    print (df.columns)
    # print (Utilities.cnxn)
    print ('df',len(df))
    df.rename(columns={ 'ApptmntDelDate': 'Apptmnt Del Date','IsApptmntDel': 'Is Apptmnt Del','IS_FREE_CON_NEW': 'IS FREE CON NEW','ConStatusDate': 'Con Status Date','ConStatusReason': 'Con Status Reason','ConStatusDesc': 'Con Status Desc','ConStatusCode': 'Con Status Code','ConStatusCategory': 'Con Status Category','DEST_PINCODE': 'DEST PINCODE','ORG_PINCODE': 'ORG PINCODE','ORG_DEPOT': 'ORG DEPOT','ORG_AREA':'ORG AREA','ORG_BRNM': 'ORG BRNM','ORG_BRCD': 'ORG BRCD','DEST_AREA': 'DEST AREA','DEST_REGION':'DEST REGION','DEST_BRNM':'DEST BRNM','DEL_LOCATION_TYPE':'DEL LOCATION TYPE','DRS_STATUS':'DRS CLOSING STATUS','Is_ADC':'Is ADC','CustomerName':'Customer Name','DEST_BRCD':'DEST BRCD','DRS_PREPARED':'DRS PREPARED','DEST_DEPOT':'DEST DEPOT',"TimestateDate":'Timestate Date',"ARRV_AT_DEST_SC":'ARRV AT DEST SC',"ConStatusCode":'Con Status Code',"CON_BLOCKED_FOR_ODA_PIN_ISSUES":'CON BLOCKED FOR ODA PIN ISSUES',"CON_BLOCKED_FOR_PAY_ISSUES":'CON BLOCKED FOR PAY ISSUES',"CON_BLOCKED_FOR_DEMURRAGE":'CON BLOCKED FOR DEMURRAGE'},inplace=True)
    #df=pd.read_excel(r'http://spoton.co.in/downloads/OCID_CLOSINGSTOCK_1HR/OCID_CLOSINGSTOCK_1HR.xls')

    df["Delay_Hours"]=np.round((df["Timestate Date"]-df["ARRV AT DEST SC"])/np.timedelta64(1, 'h'),0)
    df["PARENTCODE"]=df["PARENTCODE"].fillna(0.0).astype(int).astype(str)


    # In[3]:

    #2. Delay Hours buckets
    df = df.assign(delaygrp=pd.cut(df.Delay_Hours,bins=[-np.inf,24,48,96,np.inf],labels=['0-24','24-48','48-96','96+']))
    df['DRS CLOSING STATUS']=df['DRS CLOSING STATUS'].astype(str).replace('NA','NO')

    print (df['DRS CLOSING STATUS'].unique())
    #exit(0)
    # In[4]:

    #3. Predictabe-CCF Col
    try:
        potccflist=pd.read_csv(r"C:\Users\rajeeshv\Downloads\Rajesh\mahesh\Potential_CCF.csv")
    except:
        potccflist=pd.read_csv(r"C:\Users\rajeeshv\Downloads\Rajesh\mahesh\Appointment Reports\Potential_CCF.csv")
    potccflist["Key"]=potccflist["Destn"].astype(str)+potccflist["PARENTCODE"].astype(str)
    potccflist=potccflist["Key"].values.tolist() 
    df["Key"]=df["DEST BRCD"].astype(str)+df["PARENTCODE"]
    df["PotCCF"]=df.apply(lambda x: True if x["Key"] in potccflist else False,axis=1)


    # In[5]:
    #, 'APN'
    #3. CCF col
    ccfstatcodes=['SPH','AFS', 'APT','AND', 'CCD', 'CDA', 'CNC', 'CPN', 'DCN', 'DIP', 'DNR', 'DRA', 'DRB', 'DRJ', 'DRR', 'FNR', 'HIM', 'HIP', 'HMP', 'HOC', 'HPE', 'HWC', 'NRP', 'NSL', 'PSC', 'PSO', 'PSP', 'PSR', 'PSS', 'RDH', 'RNA', 'RNX', 'RRA', 'RRC', 'RRF', 'RRG', 'RRL', 'RRO', 'RRP', 'RRT', 'SDR', 'SHD', 'SPS', 'SRA', 'SRH', 'SRJ', 'SRR', 'SSC', 'VNR', 'WIA', 'WIP','APN']
    ucgstatcodes=['UCG','UG1','UG2','UG3']
    depsstatcodes=['DIR','EIR','PIR','SIR','SRD','SRE','SRP','SRS']
    ofdstatuscode=['AOD']
    addressissues=['CDA','WIA','CNC','CPN']
    print (df['Con Status Code'].unique())
    df["ActCCF"]=df.apply(lambda x: True if x["Con Status Code"] in ccfstatcodes else False,axis=1)
    dd=df[df['Con Status Code']=='APN']
    print (len(dd))
    # exit(0)
    # In[6]:

    #4. NonCCF DF
    ccfdf=df[(df["ActCCF"]==True)|(df["PotCCF"]==True)|(df["Con Status Code"].isin(ucgstatcodes))|(df["Con Status Code"].isin(depsstatcodes))|(df["CON BLOCKED FOR ODA PIN ISSUES"]=='YES')|(df["CON BLOCKED FOR PAY ISSUES"]=='YES')|(df["CON BLOCKED FOR DEMURRAGE"]=='YES')|(df["CSGNCD"]==119721)]
    ccfdf=ccfdf[ccfdf["DRS CLOSING STATUS"]!='OPEN']
    total_ccf_cons=len(ccfdf[ccfdf["DRS CLOSING STATUS"]!='OPEN'])
    depotpivotccfdf=ccfdf.pivot_table(index=["DEST AREA"],columns=["DRS CLOSING STATUS",'delaygrp'],values=["DOCKNO"],aggfunc={"DOCKNO":len},margins=True).sort_values(("DOCKNO","All"),ascending=False)
    depotpivotccfdf=depotpivotccfdf.fillna(0).astype(int)
    print (depotpivotccfdf)
    depotpivotccfdf_ccf_cons=depotpivotccfdf.loc[:,("DOCKNO","NO","48-96")][0]+depotpivotccfdf.loc[:,("DOCKNO","NO","96+")][0]
    nonccfdf=df.merge(ccfdf,how='outer',indicator=True)
    nonccfdf=nonccfdf[nonccfdf["_merge"]=='left_only']
    nonccfdf=nonccfdf[~nonccfdf["Con Status Code"].isin(ofdstatuscode)]
    nonccfdf['delaycat']=nonccfdf['delaygrp'].astype(str)
    nonccfdf_notofd=nonccfdf[nonccfdf["DRS CLOSING STATUS"]!='OPEN']




    # In[7]:

    #5. Crit-NonCCFDF (48+ hours)
    critnonccfdf=nonccfdf[(nonccfdf["delaygrp"]!="0-24")&(nonccfdf["delaygrp"]!="24-48")]
    critnonccfdf['delaycat']=critnonccfdf['delaygrp'].astype(str)
    critnonccfdf_notofd=critnonccfdf[critnonccfdf["DRS CLOSING STATUS"]!='OPEN']



    # In[8]:

    #4B. Descriptions
    critnonccfcons=len(critnonccfdf)
    critnonccfdf_notofdcons=len(critnonccfdf_notofd)
    totnonccfcons=len(nonccfdf)
    totnonccf_notofdcons=len(nonccfdf_notofd)
    # ccfcons=len(ccfdf)
    # addresscons=len(df[df["Con Status Code"].isin(addressissues)])
    # ucgcons=len(df[df["Con Status Code"].isin(ucgstatcodes)])


    # In[9]:

    #5. Pivot

    depotpivot=nonccfdf_notofd.pivot_table(index=["DEST AREA"],columns=["DRS CLOSING STATUS",'delaycat'],values=["DOCKNO"],aggfunc={"DOCKNO":len},margins=True).reset_index().sort_values(("DOCKNO","All"),ascending=False)
    depotpivot=depotpivot.set_index(("DEST AREA",""))#head(2)
    depotpivot=depotpivot.fillna(0.0).astype(int)
    depotpivot=depotpivot.sort_values(("DOCKNO","All"),ascending=False)

    topfailinglocation=depotpivot.index[1]
    example=depotpivot.loc[:,("DOCKNO","All")][1]


    # In[10]:

    #6. Separating STD
    nonccfdf_std=nonccfdf_notofd[nonccfdf_notofd["DEL LOCATION TYPE"]=="STD"]
    depotpivot_std=nonccfdf_std.pivot_table(index=["DEST AREA"],columns=["DRS CLOSING STATUS",'delaycat'],values=["DOCKNO"],aggfunc={"DOCKNO":len},margins=True).reset_index().sort_values(("DOCKNO","All"),ascending=False)
    depotpivot_std=depotpivot_std.set_index(("DEST AREA",""))#head(2)
    depotpivot_std=depotpivot_std.fillna(0.0).astype(int)
    depotpivot_std=depotpivot_std.sort_values(("DOCKNO","NO","96+"),ascending=False)
    # critnonccfcons_std=len(nonccfdf_std)
    nonccfdf_std_notofdcons=len(nonccfdf_std[nonccfdf_std["DRS CLOSING STATUS"]!='OPEN'])

    critnonccfdf_std_notofdcons=depotpivot_std.loc[:,("DOCKNO","NO","48-96")][0]+depotpivot_std.loc[:,("DOCKNO","NO","96+")][0]

    from datetime import date,timedelta
    # todate=date.today()
    today_date=datetime.strftime(datetime.now(),'%Y-%m-%d %H:%M:%S')
    today_date12=datetime.strftime(datetime.now(),'%Y-%m-%d %H')
    print (today_date)

    nonccfdf_notofd=nonccfdf_notofd.loc[:,["DOCKNO","ACTUWT","VOLUME","PIECES","DEST BRCD","DEST BRNM","DEST REGION","DEST DEPOT","DEST AREA","DEL LOCATION TYPE","VTC","FTC","DACC","DC",'CSGECD','CSGENM','ARRV AT DEST SC','CSGNCD','CSGNNM','ORG BRCDREVENUE','DECLVAL',"ORG BRCD","ORG BRNM","ORG AREA","ORG DEPOT",'ORG PINCODE','DEST PINCODE','Con Status Category','Con Status Code','Con Status Desc','Con Status Reason','Con Status Date','CON BLOCKED FOR PAY ISSUES','PARENTCODE','PARENTNAME','CON BLOCKED FOR ODA PIN ISSUES','CON BLOCKED FOR DEMURRAGE','IS FREE CON NEW','Is Apptmnt Del','Apptmnt Del Date','CDELDT',"Timestate Date",'Delay_Hours','DRS PREPARED','PotCCF','ActCCF','delaycat']]


    # filepath=r'D:\Data\Appointment Reports\Delayed Cons\Detailed_Report_'+str(today_date12)+'.csv'
    # filepath2=r'D:\Data\Appointment Reports\Detailed_Report_'+str(today_date12)+'.csv'
    filepath3=r'D:\Data\Appointment Reports\Delayed Cons\Detailed_Report.csv'
    filepath4=r'D:\Data\Appointment Reports\Detailed_Report.csv'
    try:
        nonccfdf_notofd.to_csv(r'D:\Data\Appointment Reports\Delayed Cons\Detailed_Report_'+str(today_date12)+'.csv')
    except:
        nonccfdf_notofd.to_csv(r'D:\Data\Appointment Reports\Detailed_Report_'+str(today_date12)+'.csv')

    try:
        nonccfdf_notofd.to_csv(filepath3)
    except:
        nonccfdf_notofd.to_csv(filepath4)

    # 'Total Free cons (STD + ODA) not OFD is <b>'+str(totnonccf_notofdcons)+'</b>, '+
    #                        'of which cons lying at SC for >48 hours is <b>'+str(critnonccfdf_notofdcons)+'</b>. '+
    #                        '<br>STD cons in these is <b>'+str(nonccfdf_std_notofdcons)+'</b> of which cons lying at SC for >48 hours is <b>'+str(critnonccfdf_std_notofdcons)+'</b>'+
    #                        #'are CCF due to address/contact issue and <b>'+str(ucgcons)+'</b> '+
    #                        #'are UCG cons. <b>'+
    #                        '.<br>Top Failure location is : <b>'+str(topfailinglocation)+'</b>'+
    #                        '<br><br><b> Break-up of free cons, not OFD :</b>'+
    #                        '<br><i> Eg: '+str(example)+' cons at '+str(topfailinglocation)+' are free, but not OFD yet.</i><br>'+
    #                        depotpivot.to_html()+'<br><br><b> Break-up of free cons (STD only), not OFD :</b><br>'+depotpivot_std.to_html(), 'html')
    # send_email(["ankit@iepfunds.com","supratim@iepfunds.com","pawan.sharma@spoton.co.in","krishna.chandrasekar@spoton.co.in","abhik.mitra@spoton.co.in","vishwas.j@spoton.co.in","nikhil.saxena@spoton.co.in", "jothi.menon@spoton.co.in","sharmistha.majumdar@spoton.co.in","sq_spot@spoton.co.in", "aom_spot@spoton.co.in", "dom_spot@spoton.co.in", "rom_spot@spoton.co.in"])

    # exit(0)
    # In[ ]:

    

    fullname=filepath3
    print ('Logging in...')
    ftp = ftplib.FTP()
    ftp.connect('10.109.230.50')
    print (ftp.getwelcome())
    try:
        try:
            ftp.login('IEPROJECTUSER', 'spotStar@123')
            ftp.cwd('ETA')
            # move to the desired upload directory
            print ("Currently in:", ftp.pwd())
            print ('Uploading...')
            fullname = fullname
            name = os.path.split(fullname)[1]
            f = open(fullname, "rb")
            ftp.storbinary('STOR ' + name, f)
            f.close()
            print ("OK"  )
            print ("Files:")
            print (ftp.retrlines('LIST'))
        finally:
            print ("Quitting...")
            ftp.quit()
    except:
        traceback.print_exc()
    # In[71]:



    

    TO=["pawan.sharma@spoton.co.in","krishna.chandrasekar@spoton.co.in","abhik.mitra@spoton.co.in","vishwas.j@spoton.co.in", "jothi.menon@spoton.co.in","sharmistha.majumdar@spoton.co.in","sq_spot@spoton.co.in", "aom_spot@spoton.co.in", "dom_spot@spoton.co.in", "rom_spot@spoton.co.in","rajesh.kumar@spoton.co.in","shivananda.p@spoton.co.in",'kanad.jana@spoton.co.in']
    # TO=['mahesh.reddy@spoton.co.in']
    FROM="reports.ie@spoton.co.in"
    # CC=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
    BCC=['mahesh.reddy@spoton.co.in']
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    #msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    msg["Subject"] = "Delayed Cons" + " : " + str(today_date)
    html='''<html>
    <style>
    p
    {
      margin:0;
      margin-top: 5px;
      padding:0;
      font-size:17px;
        line-height:20px;
    }
    </style>
    <h4>Dear All,</h4>
    <p>Total Free cons (STD + ODA) not OFD is $totnonccf_notofdcons of which cons lying at SC for >48 hours is $critnonccfdf_notofdcons.</p>
    <p>STD cons in these is $nonccfdf_std_notofdcons of which cons lying at SC for >48 hours is $critnonccfdf_std_notofdcons</p>
    <h4>Top Failure location is : $topfailinglocation</h4>
    <h4>Break-up of free cons, not OFD :</h4>
    <p>Eg: $example  cons at $topfailinglocation are free, but not OFD yet.</p>
    </html>'''

    html3='''
    <h3>Break-up of free cons (STD only), not OFD :</h3>

    '''
    html4='''
    <p>Total CCF cons (STD + ODA) not OFD is of $total_ccf_cons which cons lying at SC for >48 hours is $depotpivotccfdf_ccf_cons</p>

    '''
    html5='''
    <h5> To download the cons data , Please click the link below </h5>
    <p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Detailed_Report.csv"</a>http://spoton.co.in/downloads/IEProjects/ETA/Detailed_Report.csv</p></b>
    '''
    s = Template(html).safe_substitute(depotpivotccfdf_ccf_cons=depotpivotccfdf_ccf_cons,total_ccf_cons=total_ccf_cons,example=example,topfailinglocation=topfailinglocation,critnonccfdf_std_notofdcons=critnonccfdf_std_notofdcons,critnonccfdf_notofdcons=critnonccfdf_notofdcons,nonccfdf_std_notofdcons=nonccfdf_std_notofdcons,totnonccf_notofdcons=totnonccf_notofdcons,date=today_date)
    s1 = Template(html4).safe_substitute(total_ccf_cons=total_ccf_cons,depotpivotccfdf_ccf_cons=depotpivotccfdf_ccf_cons )
    #s1 = Template(html4).safe_substitute(depotpivotccfdf_ccf_cons=depotpivotccfdf_ccf_cons,total_ccf_cons=total_ccf_cons)
    report=""
    report+=s
    report+='<br>'
    report+='<br>'+depotpivot.to_html()+'<br>'
    report+=html3
    #depotpivot_std
    report+='<br>'+depotpivot_std.to_html()+'<br>'
    report+=s1
    report+='<br>'+depotpivotccfdf.to_html()+'<br>'
    report+=html5
    abc=MIMEText(report,'html')
    msg.attach(abc)
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filepath3,"rb").read() )
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath3))
    #msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO+BCC, msg.as_string())
    server.quit()

except:
  TO=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  #msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "ERROR Report" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in Delayed Cons'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO, msg.as_string())
  server.quit()


