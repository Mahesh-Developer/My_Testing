# -*- coding: utf-8 -*-
"""
Created on Wed Feb 03 14:52:42 2016

@author: rajeeshv
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
import calendar
import datetime
from pandas import ExcelWriter

pmddata = pd.read_csv(r'http://10.109.230.50/downloads/PMD/PMD.csv')

datenow = date.today()
dateyest = datenow-timedelta(hours=24)


pmddata.to_csv(r'D:\\Data\\PMD_Save\\PMD_'+str(dateyest)+'.csv',encoding='utf-8')
print 'PMD saving done'