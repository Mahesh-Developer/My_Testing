
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
from datetime import datetime,timedelta
import pyodbc
from fuzzywuzzy import fuzz
import pandas as pd
import pyodbc
from datetime import datetime,timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
import ftplib
# import Utilities
from calendar import monthrange
import smtplib


# In[2]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")


# In[3]:


df=pd.read_sql('EXEC USP_CNM_Feeder_Vehicle_Daily_Report',cnxn)


# In[4]:


len(df)


# In[5]:


df=df[df['routecd']!='9888']


# In[6]:


len(df)


# In[7]:


df['Sch_Delay']=(df['ActDeptDATETIME']-df['SchDeptDATETIME'])/np.timedelta64(1,'m')
df['Arrv_Delay']=(df['ActArrvDATETIME']-df['SchArrvDATETIME'])/np.timedelta64(1,'m')


# In[ ]:


# df[['SchDeptDATETIME','ActDeptDATETIME','Sch_Delay','SchArrvDATETIME','ActArrvDATETIME','Arrv_Delay']]
# df[df['Sch_Delay']>30]


# In[8]:


df['Sch_Delay']=pd.np.round(df['Sch_Delay'],1)
df['Arrv_Delay']=pd.np.round(df['Arrv_Delay'],1)


# In[9]:


df['IsDeptOntime']=df['Sch_Delay'].apply(lambda x: 'Ontime' if x<=30 else 'Late')
df['IsArrvOntime']=df['Arrv_Delay'].apply(lambda x: 'Ontime' if x<=30 else 'Late')


# In[ ]:


#df[['SchDeptDATETIME','ActDeptDATETIME','Sch_Delay','IsDeptOntime','SchArrvDATETIME','ActArrvDATETIME','Arrv_Delay','IsArrvOntime']]


# In[ ]:


df.head()


# In[12]:


# delh_sc=['DELM', 'QNFB', 'DELN', 'DELB', 'MNSB', 'GZBB', 'DELC', 'DWKB',
#        'PALB', 'ROHF', 'NMWF', 'GTBB','NDAH']

delh_sc=['DELM', 'QNFB', 'DELN', 'DELB', 'MNSB', 'GZBB', 'DELC', 'DWKB',
       'PALB',  'GTBB','NDAH']

# In[ ]:


##BOMH Departure


# In[13]:


bomhdf=df[df['sourcehb']=='DELH']
bomhdf=bomhdf[bomhdf['tobh_code'].isin(delh_sc)]


# In[14]:


bomhdf_dep=bomhdf.pivot_table(index=['routename'],columns=['IsDeptOntime'],values=['thcno'],aggfunc={'thcno':len},margins=True,margins_name='Total').fillna(0)


# In[15]:


if 'Late' in bomhdf['IsDeptOntime'].unique().tolist():
    pass
else:
    bomhdf_dep[('thcno','Late')]=0.0


# In[16]:


bomhdf_dep['thcno','Total']=bomhdf_dep[('thcno','Late')]+bomhdf_dep[('thcno','Ontime')]


# In[17]:


bomhdf_dep['thcno','Ontime%']=pd.np.round(bomhdf_dep[('thcno','Ontime')]*100.0/bomhdf_dep[('thcno','Total')],0)


# In[ ]:


# bomhdf_dep1=bomhdf_dep[[('thcno','Ontime'),('thcno','Late'),('thcno','Total'),('thcno','Ontime%')]]


# In[18]:


bomhdf_dep


# In[19]:


bomhdf_arrv=bomhdf.pivot_table(index=['routename'],columns=['IsArrvOntime'],values=['thcno'],aggfunc={'thcno':len},margins=True,margins_name='Total').fillna(0)


# In[20]:


if 'Late' in bomhdf['IsArrvOntime'].unique().tolist():
    pass
else:
    bomhdf_arrv[('thcno','Late')]=0.0


# In[21]:


bomhdf_arrv['thcno','Total']=bomhdf_arrv[('thcno','Late')]+bomhdf_arrv[('thcno','Ontime')]
bomhdf_arrv['thcno','Ontime%']=pd.np.round(bomhdf_arrv[('thcno','Ontime')]*100.0/bomhdf_arrv[('thcno','Total')],0)
# bomhdf_arrv1=bomhdf_arrv[[('thcno','Ontime'),('thcno','Late'),('thcno','Total'),('thcno','Ontime%')]]


# In[22]:


bomhdf_arrv


# In[23]:


bomhdf_arrv['thcno']=bomhdf_arrv['thcno'].astype(int)


# In[24]:


bomhdf_dep['thcno']=bomhdf_dep['thcno'].astype(int)


# In[25]:

todate=datetime.strftime(datetime.now()-timedelta(days=1),'%Y-%m-%d')
todate
bomhdf.to_csv(r'D:\Data\CNM_Arrv_Dep\Feeder_Performance\DELH\DELH_SC_Data'+str(todate)+'.csv')

bomhdf.to_csv(r'D:\Data\CNM_Arrv_Dep\Feeder_Performance\DELH\DELH_SC_Data.csv')

# In[26]:


filepath=r'D:\Data\CNM_Arrv_Dep\Feeder_Performance\DELH\DELH_SC_Data.csv'


# In[27]:





# In[ ]:


##BLRA Performance


# In[28]:


bomadf=df[df['sourcehb'].isin(delh_sc)]
bomadf=bomadf[bomadf['tobh_code']=='DELH']


# In[29]:


bomadf_dep=bomadf.pivot_table(index=['routename'],columns=['IsDeptOntime'],values=['thcno'],aggfunc={'thcno':len},margins=True,margins_name='Total').fillna(0)


# In[30]:


bomadf_dep


# In[31]:


if 'Late' in bomadf['IsDeptOntime'].unique().tolist():
    pass
else:
    bomadf_dep[('thcno','Late')]=0.0


# In[32]:


bomadf_dep['thcno','Total']=bomadf_dep[('thcno','Late')]+bomadf_dep[('thcno','Ontime')]
bomadf_dep['thcno','Ontime%']=pd.np.round(bomadf_dep[('thcno','Ontime')]*100.0/bomadf_dep[('thcno','Total')],0)
# bomadf_dep1=bomhdf_arrv[[('thcno','Ontime'),('thcno','Late'),('thcno','Total'),('thcno','Ontime%')]]


# In[33]:


bomadf_dep['thcno']=bomadf_dep['thcno'].astype(int)


# In[34]:


bomadf_arrv=bomadf.pivot_table(index=['routename'],columns=['IsArrvOntime'],values=['thcno'],aggfunc={'thcno':len},margins=True,margins_name='Total').fillna(0)


# In[35]:


if 'Late' in bomadf['IsArrvOntime'].unique().tolist():
    pass
else:
    bomadf_arrv[('thcno','Late')]=0.0


# In[36]:


bomadf_arrv['thcno','Total']=bomadf_arrv[('thcno','Late')]+bomadf_arrv[('thcno','Ontime')]
bomadf_arrv['thcno','Ontime%']=pd.np.round(bomadf_arrv[('thcno','Ontime')]*100.0/bomadf_arrv[('thcno','Total')],0)
# bomadf_arrv1=bomhdf_arrv[[('thcno','Ontime'),('thcno','Late'),('thcno','Total'),('thcno','Ontime%')]]


# In[37]:


bomadf_arrv['thcno']=bomadf_arrv['thcno'].astype(int)


# In[39]:


bomadf.to_csv(r'D:\Data\CNM_Arrv_Dep\Feeder_Performance\DELH\SC_NCRA_Feeder_Data'+str(todate)+'.csv')

bomadf.to_csv(r'D:\Data\CNM_Arrv_Dep\Feeder_Performance\DELH\SC_NCRA_Feeder_Data.csv')

# In[40]:


filepath1=r'D:\Data\CNM_Arrv_Dep\Feeder_Performance\DELH\SC_NCRA_Feeder_Data.csv'


# In[41]:


TO=['dinesh.kumar.sharma@spoton.co.in','amit.aggarwal@spoton.co.in','mahesh.srivastava@spoton.co.in','chandra.prakash@spoton.co.in','sandeep.sachdeva@spoton.co.in','krishna.kumar.bhardwaj@spoton.co.in','jaisingh.chauhan@spoton.co.in','jaswant.gusain@spoton.co.in']
# TO=["krishna.kumar.bhardwaj@spoton.co.in","ramachandran.p@spoton.co.in","Rajnish.pathak@spoton.co.in","jaivir.singh@spoton.co.in","sopanrao.bhoite@spoton.co.in","pawan.sharma@spoton.co.in","ashwani.gangwar@spoton.co.in","prasanna.hegde@spoton.co.in","onkar.sharma@spoton.co.in","manoj.pareek@spoton.co.in","narendra.londhe@spoton.co.in","rajesh.ks@spoton.co.in","pramod.pandey@spoton.co.in","rajesh.mishra@spoton.co.in","sukesh.mishra@spoton.co.in","ashok.dwivedi@spoton.co.in","lingaraj.chidambaram@spoton.co.in"]
# CC= ["abhik.mitra@spoton.co.in","rom_spot@spoton.co.in","Avinash.Singh@spoton.co.in","dinesh.kumar.sharma@spoton.co.in","sasikumar.kannan@spoton.co.in","rajesh.debnath@spoton.co.in","jothi.menon@spoton.co.in","ananth.m@spoton.co.in","rajesh.kumar@spoton.co.in","bushra.jamadar@spoton.co.in","anushree.gadre@spoton.co.in","vimal.s@spoton.co.in","satya.pal@spoton.co.in","vishwas.j@spoton.co.in","shivananda.p@spoton.co.in","mahesh.reddy@spoton.co.in","abhishek.cv@spoton.co.in","shruthi.sk@spoton.co.in"]
CC=['pawan.sharma@spoton.co.in','deepak.sharma@spoton.co.in','soham.kakade@spoton.co.in','rajesh.kumar@spoton.co.in','raghavendra.rao@spoton.co.in','abhik.mitra@spoton.co.in','jothi.menon@spoton.co.in','shivananda.p@spoton.co.in','amit.aggarwal@spoton.co.in','sandeep.sachdeva@spoton.co.in','prasanna.hegde@spoton.co.in','ashwani.gangwar@spoton.co.in','cnm@spoton.co.in',"mahesh.reddy@spoton.co.in"]
FROM="reports.ie@spoton.co.in"
# FROM="mahesh.reddy@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "DELH > Feeder Report On" + " - " + str(todate)
html='''<html>
<h4>Dear All,</h4>
<p>PFA the Air Monitoring Report for $date</p>
</html>'''
#s = Template(html).safe_substitute(date=yest_date)
report=""
report+="Dear KK Sir, "
report+='<br>'
report+='Please Find '+str(todate)+' Feeder Performance '
report+='<br>'
#report+='Need corrective actions on the highlighted lane '
report+='<br>'
report+='DELH-SC Departure Performance :'
report+='<br>'
report+='<br>'+bomhdf_dep.to_html()+'<br>'
report+='<br>'
report+='DELH-SC Arrival Performance :'
report+='<br>'
report+='<br>'+bomhdf_arrv.to_html()+'<br>'
report+='<br>'



abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

# part1 = MIMEBase('application', "octet-stream")
# part1.set_payload( open(filepath1,"rb").read() )
# encoders.encode_base64(part1)
# part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
# msg.attach(part1)


# server=smtplib.SMTP('smtp.sendgrid.net', 587)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("mahesh.reddy@spoton.co.in", "Nov@2018")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()


# In[ ]:


##BOMA


# In[ ]:


bomadf_dep


# In[ ]:


bomadf_dep


# In[ ]:


bomadf_arrv


# In[ ]:


#TO=['mahesh.reddy@spoton.co.in','deepak.sharma@spoton.co.in','raghavendra.rao@spoton.co.in','soham.kakade@spoton.co.in']

# TO=["krishna.kumar.bhardwaj@spoton.co.in","ramachandran.p@spoton.co.in","Rajnish.pathak@spoton.co.in","jaivir.singh@spoton.co.in","sopanrao.bhoite@spoton.co.in","pawan.sharma@spoton.co.in","ashwani.gangwar@spoton.co.in","prasanna.hegde@spoton.co.in","onkar.sharma@spoton.co.in","manoj.pareek@spoton.co.in","narendra.londhe@spoton.co.in","rajesh.ks@spoton.co.in","pramod.pandey@spoton.co.in","rajesh.mishra@spoton.co.in","sukesh.mishra@spoton.co.in","ashok.dwivedi@spoton.co.in","lingaraj.chidambaram@spoton.co.in"]
# CC= ["abhik.mitra@spoton.co.in","rom_spot@spoton.co.in","Avinash.Singh@spoton.co.in","dinesh.kumar.sharma@spoton.co.in","sasikumar.kannan@spoton.co.in","rajesh.debnath@spoton.co.in","jothi.menon@spoton.co.in","ananth.m@spoton.co.in","rajesh.kumar@spoton.co.in","bushra.jamadar@spoton.co.in","anushree.gadre@spoton.co.in","vimal.s@spoton.co.in","satya.pal@spoton.co.in","vishwas.j@spoton.co.in","shivananda.p@spoton.co.in","mahesh.reddy@spoton.co.in","abhishek.cv@spoton.co.in","shruthi.sk@spoton.co.in"]
#CC=["mahesh.reddy@spoton.co.in"]
FROM="reports.ie@spoton.co.in"
# FROM="mahesh.reddy@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "NCRA > Feeder Report On" + " - " + str(todate)
html='''<html>
<h4>Dear All,</h4>
<p>PFA the Air Monitoring Report for $date</p>
</html>'''
#s = Template(html).safe_substitute(date=yest_date)
report=""
report+="Dear Dinesh Sir,"
report+='<br>'
report+='Please Find '+str(todate)+' Feeder Performance from SC - Hub,'
report+='<br>'
report+='Need corrective actions on the highlighted lane '
report+='<br>'
report+='SC-DELH Departure Performance :'
report+='<br>'
report+='<br>'+bomadf_dep.to_html()+'<br>'
report+='<br>'
report+='SC-DELH Arrival Performance :'
report+='<br>'
report+='<br>'+bomadf_arrv.to_html()+'<br>'


abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath1,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
msg.attach(part)


# server=smtplib.SMTP('smtp.sendgrid.net', 587)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("mahesh.reddy@spoton.co.in", "Nov@2018")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()

