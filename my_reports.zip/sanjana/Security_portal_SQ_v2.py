
# coding: utf-8

# In[31]:


import pandas as pd
import numpy as np
from datetime import datetime
import pyodbc
import smtplib
import os
import ftplib
import traceback
import Utilities


# In[32]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=HOSQTEAM;PWD=$potH0U$r")
# cursor = cnxn.cursor()


# In[33]:


# query=("Security_Portal_SQ_Anitha '2018-04-01'")
query=("EXEC dbo.usp_Security_Portal_SQ '2018-04-01' ")


# In[34]:


df=pd.read_sql(query,Utilities.cnxn)
#df=pd.read_sql(query,cnxn)
# df.to_csv(r'Security_Data.csv')
# exit(0)
# In[35]:


df=df[df['Status']!='Close']
len(df)


# In[36]:


df=df[df['IncidentLoc']!='BLHO']


# In[37]:


df=df[df['IncidentLoc']!='BLHO']

len(df)
# In[38]:


df['Month']=df['CaseDate'].apply(lambda x : datetime.strftime(x,'%b'))


# In[9]:


# In[39]:


cols=df['Month'].unique().tolist()
from datetime import datetime
days_sorted = sorted(cols, key=lambda day: datetime.strptime(day, "%b"))


# In[10]:


days_sorted


# In[11]:


# In[40]:


months_list=[]
for i in days_sorted:
    months_list.append(('ConNo',i))


# In[13]:


months_list


# In[41]:


# In[22]:


summary=df.pivot_table(index=[' Assigned To','Status'],columns=['Month'],values=['ConNo'],aggfunc={'ConNo':len}).fillna(0).reindex(columns=months_list)


# In[23]:


summary=summary.fillna(0)


# In[42]:


# In[25]:
print (summary)

summary['ConNo']=summary['ConNo'].astype(int)


# In[43]:


# In[24]:


summary['Total']=summary['ConNo'].sum(axis=1)


# In[44]:


# In[26]:


depotdftots = summary.groupby(level=' Assigned To').sum()
depotdftots.index = [depotdftots.index, ['total'] * len(depotdftots)]
        


# In[45]:


depotdftots


# In[46]:


summary1 = np.round(pd.concat([summary,depotdftots]).sort_index().append(summary.sum().rename(('Grand', 'Total'))),2)


# In[47]:


summary1


# In[48]:


######## edit- sanjana #######


# In[52]:


DF2=pd.read_sql(query,Utilities.cnxn)
# DF2

DF2['Month']=DF2['CaseDate'].apply(lambda x : datetime.strftime(x,'%b-%Y'))
DF2.columns

colsDF=DF2['Month'].unique().tolist()

from datetime import datetime
days_sortedDF = sorted(colsDF, key=lambda day: datetime.strptime(day, "%b-%Y"))

months_listDF=[]
for i in days_sortedDF:
    months_listDF.append(('ConNo',i))



DF2[' Assigned To']=DF2[' Assigned To'].fillna('unassigned')
# DF2



edit=DF2.pivot_table(index=[' Assigned To','Status'],
                       columns=['Month'],values=['ConNo'],
                       aggfunc={'ConNo':len}, margins=True).fillna(0).reindex(columns=months_listDF)
edit


# In[53]:


date=datetime.strftime(datetime.now(),'%Y-%m-%d')
date


# In[57]:


# df.to_csv(r'F:\Portal_Report_Data'+str(date)+'.csv')
# df.to_csv(r'F:\Portal_Report_Data.csv')
# filepath=r'F:\Portal_Report_Data.csv'


# In[62]:


# edit.to_csv(r'F:\Portal_Report_Data_open&close'+str(date)+'.csv')
# edit.to_csv(r'F:\Portal_Report_Data_open&close.csv')
# filepath2=r'F:\Portal_Report_Data_open&close.csv'
DF2.to_csv(r'D:\Data\security_portal_report\Open_Close_DatA'+str(date)+'.csv')
DF2.to_csv(r'D:\Data\security_portal_report\Open_Close_DatA.csv')

df.to_csv(r'D:\Data\security_portal_report\Portal_Report_DatA'+str(date)+'.csv')
df.to_csv(r'D:\Data\security_portal_report\Portal_Report_DatA.csv')
print (len(df))
edit.to_csv(r'D:\Data\security_portal_report\Portal_Report_Data_open&close'+str(date)+'.csv')
edit.to_csv(r'D:\Data\security_portal_report\Portal_Report_Data_open&close.csv')

filepath=r'D:\Data\security_portal_report\Portal_Report_DatA.csv'
filepath2=r'D:\Data\security_portal_report\Portal_Report_Data_open&close.csv'
filepath3=r'D:\Data\security_portal_report\Open_Close_DatA.csv'


# In[65]:


for i in [filepath,filepath2,filepath3]:
  oppath1=i
  print ('Logging in...')
  ftp = ftplib.FTP()
  ftp.connect('10.109.230.50')
  print (ftp.getwelcome())
  try:
      try:
          ftp.login('IEPROJECTUSER', 'spotStar@123')
          ftp.cwd('ETA')
          # move to the desired upload directory
          print ("Currently in:", ftp.pwd())
          print ('Uploading...')
          fullname = oppath1
          name = os.path.split(fullname)[1]
          f = open(fullname, "rb")
          ftp.storbinary('STOR ' + name, f)
          f.close()
          print ("OK"  )
          print ("Files:")
          print (ftp.retrlines('LIST'))
      finally:
          print ("Quitting...")
          ftp.quit()
  except:
      traceback.print_exc()

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

TO=['spot_security@spoton.co.in','SQ_SPOT@spoton.co.in']
# TO=['mahesh.reddy@spoton.co.in',"amit.singh@spoton.co.in"]
FROM="mis.ho@spoton.co.in"
CC=['jothi.menon@spoton.co.in','anitha.thyagarajan@spoton.co.in','shivananda.p@spoton.co.in','mahesh.reddy@spoton.co.in']
# BCC=['sanjana.narayana@spoton.co.in']
# CC=['sanjana.narayana@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
msg["Subject"] = "Security Portal Report " + " : " + date
html='''<html>
<style>
p
{
  margin:0;
  margin-top: 5px;
  padding:0;
  font-size:17px;
    line-height:20px;
}
</style>
<h3>Dear All,</h3>
<p>Please Find POD's Summary.</p>
</html>'''


s = Template(html).safe_substitute()
report=""
#report+=s
#report+='<br>'+final_dff5.to_html()+'<br>'
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='Please Find the Security Portal Report Update :'
report+='<br>'
report+='<br>'+summary1.to_html()+'<br>'
report+='<br>'
html5='''
<h5> To download the data , Please click the link below </h5>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Portal_Report_DatA.csv"</a>http://spoton.co.in/downloads/IEProjects/ETA/Portal_Report_DatA.csv</p></b>

<h5> To download the data , Please click the link below </h5>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Portal_Report_Data_open&close.csv"</a>http://spoton.co.in/downloads/IEProjects/ETA/Portal_Report_Data_open&close.csv</p></b>

<h5> To download the data , Please click the link below </h5>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Open_Close_DatA.csv"</a>http://spoton.co.in/downloads/IEProjects/ETA/Open_Close_DatA.csv</p></b>


    '''
report+=html5
abc=MIMEText(report,'html')
msg.attach(abc)
# part = MIMEBase('application', "octet-stream")
# part.set_payload( open(filePath,"rb").read() )
# encoders.encode_base64(part)
# part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
# msg.attach(part)
# part1 = MIMEBase('application', "octet-stream")
# part1.set_payload( open(filePath1,"rb").read() )
# encoders.encode_base64(part1)
# part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath1))
# msg.attach(part1)

server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()

