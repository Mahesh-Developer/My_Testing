
# coding: utf-8

# In[ ]:

import pandas as pd
import numpy as np
from pymongo import MongoClient
from string import Template
import smtplib
import os
from datetime import datetime, timedelta
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import smtplib
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os


# In[ ]:

cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()


# In[ ]:

query=("EXEC USP_Servicelevel_MA_BD 'Y'")


# In[ ]:

yest_df=pd.read_sql(query,cnxn)
len(yest_df)


# In[ ]:

yest_df['Reach%']=pd.np.round(yest_df['Reach']*100.0/yest_df['TOTAL CONS'])
yest_df['OPP%']=pd.np.round(yest_df['OPP_Cons']*100.0/yest_df['TOTAL CONS'])
yest_df['CEM%']=pd.np.round(yest_df['CEM_Cons']*100.0/yest_df['TOTAL CONS'])
yest_df['Damage%']=pd.np.round(yest_df['DAMAGE']*100.0/yest_df['TOTAL CONS'])
yest_df['Theft%']=pd.np.round(yest_df['THEFT']*100.0/yest_df['TOTAL CONS'])


# In[ ]:

yest_df


# In[ ]:

##Weekly


# In[ ]:

weekquery=("EXEC USP_Servicelevel_MA_BD 'W'")


# In[ ]:

weekdf=pd.read_sql(weekquery,cnxn)
len(weekdf)


# In[ ]:

weekdf['Reach%']=pd.np.round(weekdf['Reach']*100.0/weekdf['TOTAL CONS'])
weekdf['OPP%']=pd.np.round(weekdf['OPP_Cons']*100.0/weekdf['TOTAL CONS'])
weekdf['CEM%']=pd.np.round(weekdf['CEM_Cons']*100.0/weekdf['TOTAL CONS'])
weekdf['Damage%']=pd.np.round(weekdf['DAMAGE']*100.0/weekdf['TOTAL CONS'])
weekdf['Theft%']=pd.np.round(weekdf['THEFT']*100.0/weekdf['TOTAL CONS'])


# In[ ]:

weekdf


# In[ ]:

monthquery=("EXEC USP_Servicelevel_MA_BD 'M'")


# In[ ]:

monthdf=pd.read_sql(monthquery,cnxn)
len(monthdf)


# In[ ]:

monthdf['Reach%']=pd.np.round(monthdf['Reach']*100.0/monthdf['TOTAL CONS'])
monthdf['OPP%']=pd.np.round(monthdf['OPP_Cons']*100.0/monthdf['TOTAL CONS'])
monthdf['CEM%']=pd.np.round(monthdf['CEM_Cons']*100.0/monthdf['TOTAL CONS'])
monthdf['Damage%']=pd.np.round(monthdf['DAMAGE']*100.0/monthdf['TOTAL CONS'])
monthdf['Theft%']=pd.np.round(monthdf['THEFT']*100.0/monthdf['TOTAL CONS'])


# In[ ]:

monthdf.columns


# In[ ]:

monthdf.head()


# In[ ]:

mail_monthdf=monthdf[[u'PARENTCODE', u'PARENTNAME','ACT_MTH', u'TOTAL CONS',u'Reach%',u'OPP%', u'CEM%', u'Damage%', u'Theft%']]

mail_monthdf.sort_values('TOTAL CONS',ascending=False,inplace=True)
# In[ ]:

mail_weekdf=weekdf[[u'PARENTCODE', u'PARENTNAME','ACT_MTH', u'TOTAL CONS',u'Reach%',u'OPP%', u'CEM%', u'Damage%', u'Theft%']]

mail_weekdf.sort_values('TOTAL CONS',ascending=False,inplace=True)
# In[ ]:

mail_yest_df=yest_df[[u'PARENTCODE', u'PARENTNAME','ACT_MTH', u'TOTAL CONS',u'Reach%',u'OPP%', u'CEM%', u'Damage%', u'Theft%']]

mail_yest_df.sort_values('TOTAL CONS',ascending=False,inplace=True)
# In[ ]:

todate=datetime.strftime(datetime.now(),'%Y-%m-%d')
todate


# In[ ]:

writer = pd.ExcelWriter(r'D:\Data\MA_BD_NewCustomer\MA_BD_Data'+str(todate)+'.xlsx', engine='xlsxwriter')
yest_df.to_excel(writer,sheet_name='Yesterday')
weekdf.to_excel(writer,sheet_name='Week')
monthdf.to_excel(writer,sheet_name='Month')
writer.save()


# In[ ]:

writer = pd.ExcelWriter(r'D:\Data\MA_BD_NewCustomer\MA_BD_Data.xlsx', engine='xlsxwriter')
yest_df.to_excel(writer,sheet_name='Yesterday')
weekdf.to_excel(writer,sheet_name='Week')
monthdf.to_excel(writer,sheet_name='Month')
writer.save()


# In[ ]:




# In[ ]:

filepath=r'D:\Data\MA_BD_NewCustomer\MA_BD_Data.xlsx'


# In[ ]:

# TO=['mahesh.reddy@spoton.co.in']
TO=['asm_spot@spoton.co.in','dsm_spot@spoton.co.in','rsm_spot@spoton.co.in']
# CC=['mahesh.reddy@spoton.co.in']
CC=['rom_spot@spoton.co.in','dom_spot@spoton.co.in','aom_spot@spoton.co.in','sqtf@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in','anitha.thyagarajan@spoton.co.in']
FROM="reports.ie@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "MA BD New Customer" + ' - ' +todate
html3='''
<h5> To download the data , Please click the link below </h5>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Inventory.xlsx"</a>http://spoton.co.in/downloads/IEProjects/ETA/Inventory.xlsx</p></b>

'''
report=""
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='PFA the MA BD New Customer Summaries '+todate
report+='<br>'
report+='Yesterday summary :'
report+='<br>'
report+='<br>'+mail_yest_df.to_html()+'<br>'
report+='<br>'
report+='Weekly summary :'
report+='<br>'
report+='<br>'+mail_weekdf.to_html()+'<br>'
report+='<br>'
report+='Monthly summary :'
report+='<br>'
report+='<br>'+mail_monthdf.to_html()+'<br>'
report+='<br>'

#report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

# part2 = MIMEBase('application', "octet-stream")
# part2.set_payload( open(filepath2,"rb").read() )
# encoders.encode_base64(part2)
# part2.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath2))
# msg.attach(part2)



server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("spoton.net.in", "Star@123#")
server.login('spoton.net.in', 'Star@123#')
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()


# In[ ]:



