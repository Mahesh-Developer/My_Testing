
# coding: utf-8

# In[1]:

import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta
import sys
import datetime
import sys
import Utilities
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os

reload(sys)
sys.setdefaultencoding("utf8")

# In[2]:
try:
    querydate=date.today()
    querydate


    # In[3]:

    cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")

    # cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
    # cursor = cnxn.cursor()


    # In[4]:

    query1=("""EXEC USP_UCG_GET_LETTERS_REPORT 'ALL','ALL','ALL','2018-01-01','{0}','ALL','ALL'  """.format(querydate))


    # In[5]:

    df=pd.read_sql(query1,cnxn)
    print (len(df))
    
    #exit(0)
    # In[6]:

    len(df)


    # In[7]:

    def getDate(x):
        dd=datetime.datetime.strftime(datetime.datetime.strptime((x.split('/')[1]+'-'+x.split('/')[2]),'%m-%Y'),'%b-%Y')
        return dd


    # In[8]:

    df['MONTH']=df['UCGDate'].apply(lambda x: getDate(x))


    # In[9]:
    df=df[df['FinalStatusDesc']=='']
    df=df[df['UCGNotice']=='Final Notice']


    # In[10]:

    len(df)


    # In[11]:

    df1=df[df['UCGApprovalStatus']=='Pending']


    # In[12]:

    len(df1)


    # In[15]:

    df['InvoiceScanFile'].unique()


    # In[13]:

    df1=df1[df1['InvoiceScanFile']=='N']


    # In[14]:

    len(df1)


    # In[17]:

    pivot=df1.pivot_table(index=['Depot'],columns=['MONTH'],values=['ConNumber'],aggfunc={'ConNumber':len},margins=True,margins_name='Total')


    # In[18]:

    pivot=pivot.fillna(0)


    # In[19]:

    pivot=pivot.astype(int)


    # In[20]:

    pivot_p=pivot['ConNumber']

    del pivot_p['Total']
    # In[21]:

    days1=pivot_p.columns.tolist()
    days1


    # In[22]:

    days_sorted1=sorted(days1,key=lambda day:datetime.datetime.strptime(day,'%b-%Y'))


    # In[23]:

    pivot_p1=pivot_p[days_sorted1]


    # In[24]:

    pivot_p1


    # In[25]:

    df2=df[df['ConsigneeCourierName'].isin(['Speedpost','Registered Post'])]


    # In[26]:

    df2.columns


    # In[27]:

    df2=df2[df2['ConsignorCourierName'].isin(['Speedpost','Registered Post'])]


    # In[28]:

    len(df2)


    # In[29]:

    df2=df2[df2['CurrentLocationDepot']!='UCGD']


    # In[30]:

    len(df2)


    # In[31]:

    pivot2=df2.pivot_table(index=['Depot'],columns=['MONTH'],values=['ConNumber'],aggfunc={'ConNumber':len},margins=True,margins_name='Total')


    # In[32]:

    pivot2=pivot2.fillna(0)


    # In[33]:

    pivot2=pivot2.astype(int)


    # In[34]:

    pivot3=pivot2['ConNumber']
    del pivot3['Total']

    # In[35]:

    pivot3


    # In[36]:

    days=pivot3.columns.tolist()
    days


    # In[37]:

    days_sorted=sorted(days,key=lambda day:datetime.datetime.strptime(day,'%b-%Y'))


    # In[38]:

    pivot4=pivot3[days_sorted]


    # In[39]:

    pivot4


    # In[40]:
    df1.to_csv(r'D:\Data\UCG\UCG_Final_Notice_Pending_Final Notice Pending.csv')

    df2.to_csv(r'D:\Data\UCG\UCG_Final_Notice_Pending_RegisterPost.csv')
    #from pandas import ExcelWriter
    #with ExcelWriter(r'D:\Data\UCG\UCG_Final_Notice_Pending.xlsx') as writer:
    #    df1.to_excel(writer,engine='xlsxwriter',sheet_name='Final Notice Pending')
    #    df2.to_excel(writer,engine='xlsxwriter',sheet_name='RegisterPost')
        

    df1.to_csv(r'D:\Data\UCG\UCG_Final_Notice_Pending_Final Notice Pending-'+str(querydate)+'.csv')

    df2.to_csv(r'D:\Data\UCG\UCG_Final_Notice_Pending_RegisterPost-'+str(querydate)+'.csv')
    # In[41]:

    #with ExcelWriter(r'D:\Data\UCG\UCG_Final_Notice_Pending-'+str(querydate)+'.xlsx') as writer:
    #    df1.to_excel(writer,engine='xlsxwriter',sheet_name='Final Notice Pending')
    #    df2.to_excel(writer,engine='xlsxwriter',sheet_name='RegisterPost')


    # In[42]:

    filepath1=r'D:\Data\UCG\UCG_Final_Notice_Pending_Final Notice Pending.csv'
    filepath2=r'D:\Data\UCG\UCG_Final_Notice_Pending_RegisterPost.csv'
    query2=("""EXEC USP_UCG_GET_LETTERS_REPORT 'ALL','ALL','ALL','2018-01-01','{0}','3','ALL'  """.format(querydate))

    dummy_df=pd.read_sql(query2,Utilities.cnxn)
    print (len(dummy_df))
    dummy_df.to_csv(r'D:\Data\UCG\UCG_Data.csv')
    filepath3=r'D:\Data\UCG\UCG_Data.csv'

    # In[43]:

    import numpy as np
    import pandas as pd
    import itertools
    import json
    from pandas import ExcelWriter
    from pandas import pivot_table
    from datetime import datetime
    import os
    import ftplib
    import traceback
    for i in [filepath1,filepath2]:
        oppath1=i
        #FTP Upload starts
        print ('Logging in...')
        ftp = ftplib.FTP()  
        ftp.connect('10.109.230.50')  
        print (ftp.getwelcome())
        try:  
            try:  
                ftp.login('HOSQTeam', 'Te@mH0$q')
                print ('login done')
                ftp.cwd('Auto_reports')  
                #ftp.cwd('FIFO')
                # move to the desired upload directory  
                print ("Currently in:", ftp.pwd()) 
                print ('Uploading...')  
                fullname = oppath1
                name = os.path.split(fullname)[1]  
                f = open(fullname, "rb")  
                ftp.storbinary('STOR ' + name, f)  
                f.close()  
                print ("OK"  )
                print ("Files:")  
                print (ftp.retrlines('LIST'))
            finally:  
                print ("Quitting...")
                ftp.quit()  
        except:  
            traceback.print_exc()


    # In[44]:


    from_addr = 'mis.ho@spoton.co.in'
    #to_addr = ['anitha.thyagarajan@spoton.co.in']
    cc_addr = ['anitha.thyagarajan@spoton.co.in']
    #bcc_addr = ['mahesh.reddy@spoton.co.in']
    bcc_addr = ['sq_spot@spoton.co.in','rom_spot@spoto.co.in','dom_spot@spoton.co.in','aom_spot@spoton.co.in','scincharge_spot@spoton.co.in','anitha.thyagarajan@spoton.co.in','mahesh.reddy@spoton.co.in']

    username = 'mis.ho@spoton.co.in'
    password = 'Spot@123'

    msg = MIMEMultipart()

    msg['From'] = from_addr
    # msg['To'] = ', '.join(to_addr)
    #msg['cc'] = ', '.join(cc_addr)
    msg['bcc'] = ', '.join(bcc_addr)
    msg['Subject'] = 'UCG - Final Notice Pending details'
    html='''<html>
    <h4>Dear All</h4>
    <p>Please find the attached report for Depot wise UCG Final notice Pending in the system.</p>
    </html>'''
    html3='''
    <h5> Note : For data please open below link.</h5>
    <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/UCG_Final_Notice_Pending_Final Notice Pending.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/UCG_Final_Notice_Pending_Final Notice Pending.csv</p></b>
    <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/UCG_Final_Notice_Pending_RegisterPost.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/UCG_Final_Notice_Pending_RegisterPost.csv</p></b>

    '''
    html1='''<h5>Thanks & Regards</h5></b>
    <h5>HO-SQ</h5>'''
        
    #  msg.attach(part10)

    report=""
    report+=html
    report+='<br>'
    report+='Depot wise Pending cons for Final Notice- Upload the scan invoice (Receiver address) copy in the UCG Invoice upload page.'
    report+='<br>'
    report+='<br>'+pivot_p1.to_html()+'<br>'
    report+='<br>'
    report+='Depot wise Register post updated cons - Post 10 days pls move the cons to respective UCG Location.'
    report+='<br>'
    report+='<br>'+pivot4.to_html()+'<br>'
    report+='<br>'
    report+=html3
    report+='<br>'
    report+=html1
    abc=MIMEText(report,'html')
    msg.attach(abc)
    server = smtplib.SMTP('smtp.spoton.co.in',587)
    part=MIMEBase('application','octet-stream')
    # part1=MIMEBase('application','octet-stream')
    #part.set_payload(open(filepath,'rb').read())
    # part1.set_payload(open(filepath1,'rb').read())
    #encoders.encode_base64(part)
    # Encoders.encode_base64(part1)
    #part.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath))
    # part1.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath1))
    #msg.attach(part)
    # msg.attach(part1)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login('mis.ho@spoton.co.in','Mis@2019')
    server.sendmail(from_addr,bcc_addr,msg.as_string())
    print ('mail sent succesfully')
    server.quit()



    

except:

  TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in'] 
  CC=['mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "UCG - Final Notice Pending details Error in Execution" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in UCG - Final Notice Pending details'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO+CC, msg.as_string())
  server.quit()



# In[ ]:



