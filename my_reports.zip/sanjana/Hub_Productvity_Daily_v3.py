
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd

from IPython import display
from datetime import datetime
from datetime import datetime,timedelta
from datetime import datetime, timedelta
import smtplib
import ftplib
import traceback
import calendar
import os
import pyodbc


# In[2]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")


# In[3]:


date2=datetime.strftime(datetime.now()-timedelta(2),'%Y-%m-%d')
date3=datetime.strftime(datetime.now()-timedelta(1),'%Y-%m-%d')
date2,date3


# In[4]:
try:

    inbound=pd.DataFrame()
    for i in range(1,3):
        date1=datetime.strftime(datetime.now()-timedelta(i),'%Y-%m-%d')
        startdate=date1+' 00:00:00'
        enddate=date1+' 23:59:00'
        query=("""SELECT  b.ToBH_CODE ,
            ORG.ControlArea ,
            DST.ControlArea ,-- b.TCBR, CONVERT(DATE,a.actarrv_dt) arv_dt ,
            YEAR(a.actarrv_dt) YR ,
            MONTH(a.actarrv_dt) MTH ,
            COUNT(c.DOCKNO) In_CONS ,
            SUM(c.ACTUWT) WT ,
            SUM(c.NOPKGS) PCS ,
            SUM(DK.CHRGWT) CHRGWT --, SUM(dk.CFT_TOTAL) Volume
            FROM    dbo.THCHDR a WITH ( NOLOCK )
                    INNER JOIN dbo.TCHDR b WITH ( NOLOCK ) ON a.thcno = b.THCNO
                                                              AND a.sourcehb = b.ToBH_CODE
                    INNER JOIN dbo.TCTRN c WITH ( NOLOCK ) ON c.TCNO = b.TCNO
                    INNER JOIN dbo.DOCKET DK WITH ( NOLOCK ) ON c.DOCKNO = DK.DOCKNO
                    INNER JOIN dbo.brms ORG WITH ( NOLOCK ) ON DK.ORGNCD = ORG.BRCD
                    INNER JOIN dbo.brms DST WITH ( NOLOCK ) ON DK.REASSIGN_DESTCD = DST.BRCD
                    INNER JOIN dbo.brms D WITH ( NOLOCK ) ON D.BRCD = b.ToBH_CODE
            WHERE   a.actarrv_dt BETWEEN '{0}'
                                 AND     '{1}'
                    AND D.HUBCENTER = 'Y' 
                    --AND B.ToBH_CODE IN ( 'BOMH','BLRH','DELH')  
            GROUP BY b.ToBH_CODE ,
                    ORG.ControlArea ,
                    DST.ControlArea ,
                    YEAR(a.actarrv_dt) ,
                    MONTH(a.actarrv_dt)
            ORDER BY 1 ,
                    2""").format(startdate,enddate)
        yestdf=pd.read_sql(query,cnxn)
        
        inbound_summary=yestdf.pivot_table(index=['ToBH_CODE'],values=['WT'],aggfunc={'WT':sum}).reset_index()
        maah_wt=inbound_summary[inbound_summary['ToBH_CODE']=='MAAH']['WT'].values[0]
        maab_wt=inbound_summary[inbound_summary['ToBH_CODE']=='MAAB']['WT'].values[0]
        total_maah_wt=maah_wt+maab_wt
        inbound_summary=inbound_summary[~inbound_summary['ToBH_CODE'].isin(['MAAB','MAAH'])]
        inbound_summary1=pd.DataFrame([{'ToBH_CODE':'MAAH','WT':total_maah_wt,'Date':date1}])
        inbound_summary['Date']=date1
        inbound_summary=pd.concat([inbound_summary,inbound_summary1],ignore_index=True)
        inbound=pd.concat([inbound,inbound_summary],ignore_index=True)


    # In[5]:


    #inbound=pd.read_sql(query,cnxn)
    len(inbound)


    # In[6]:


    inbound=inbound[inbound['ToBH_CODE'].isin(['BLRH','BOMH','DELH','AMDH','PNQH','AMCH','CCUH','HYDH','MAAH','IDRH','KNPH','NAGH','NDAH'])]


    # In[7]:


    summary=inbound.pivot_table(index=['ToBH_CODE'],columns=['Date'],values=['WT'],aggfunc={'WT':sum})


    # In[ ]:


    summary


    # In[ ]:


    ##OUt bound


    # In[8]:


    outbound=pd.DataFrame()
    for i in range(1,3):
        date1=datetime.strftime(datetime.now()-timedelta(i),'%Y-%m-%d')
        startdate=date1+' 00:00:00'
        enddate=date1+' 23:59:00'
        query=("""SELECT  b.TCBR ,
            ORG.ControlArea ,
            DST.ControlArea , --b.ToBH_CODE, CONVERT(DATE,a.actdept_dt) dept_dt ,
            YEAR(a.actdept_dt) YR ,
            MONTH(a.actdept_dt) MTH ,
            COUNT(c.DOCKNO) Out_CONS ,
            SUM(c.ACTUWT) WT ,
            SUM(c.NOPKGS) PCS ,
            SUM(DK.CHRGWT) CHRGWT --, SUM(dk.CFT_TOTAL) Volume
            FROM    dbo.THCHDR a WITH ( NOLOCK )
            INNER JOIN dbo.TCHDR b WITH ( NOLOCK ) ON a.thcno = b.THCNO
                                                      AND a.sourcehb = b.TCBR
            INNER JOIN dbo.TCTRN c WITH ( NOLOCK ) ON c.TCNO = b.TCNO
            INNER JOIN dbo.DOCKET DK WITH ( NOLOCK ) ON c.DOCKNO = DK.DOCKNO
            INNER JOIN dbo.brms ORG WITH ( NOLOCK ) ON DK.ORGNCD = ORG.BRCD
            INNER JOIN dbo.brms DST WITH ( NOLOCK ) ON DK.REASSIGN_DESTCD = DST.BRCD
            INNER JOIN dbo.brms D WITH ( NOLOCK ) ON D.BRCD = b.TCBR
            WHERE   a.actdept_dt BETWEEN '{0}'
                         AND     '{1}'
            AND D.HUBCENTER = 'Y'
            --AND b.TCBR IN ( 'BOMH','BLRH','DELH')          
            GROUP BY b.TCBR ,
            ORG.ControlArea ,
            DST.ControlArea ,
            YEAR(a.actdept_dt) ,
            MONTH(a.actdept_dt)
            ORDER BY 1 ,
            2 """).format(startdate,enddate)
        yestdf=pd.read_sql(query,cnxn)
        inbound_summary=yestdf.pivot_table(index=['TCBR'],values=['WT'],aggfunc={'WT':sum}).reset_index()
        maah_wt=inbound_summary[inbound_summary['TCBR']=='MAAH']['WT'].values[0]
        maab_wt=inbound_summary[inbound_summary['TCBR']=='MAAB']['WT'].values[0]
        total_maah_wt=maah_wt+maab_wt
        inbound_summary=inbound_summary[~inbound_summary['TCBR'].isin(['MAAB','MAAH'])]
        inbound_summary1=pd.DataFrame([{'TCBR':'MAAH','WT':total_maah_wt,'Date':date1}])
        inbound_summary['Date']=date1
        inbound_summary=pd.concat([inbound_summary,inbound_summary1],ignore_index=True)
        outbound=pd.concat([outbound,inbound_summary],ignore_index=True)


    # In[9]:


    len(outbound)


    # In[10]:


    outbound=outbound[outbound['TCBR'].isin(['BLRH','BOMH','DELH','AMDH','PNQH','AMCH','CCUH','HYDH','MAAH','IDRH','KNPH','NAGH','NDAH'])]
    outboundsummary=outbound.pivot_table(index=['TCBR'],columns=['Date'],values=['WT'],aggfunc={'WT':sum})


    # In[11]:


    final_df=pd.DataFrame()


    # In[12]:


    date2,date3


    # In[13]:


    final_df['Wt_'+date3]=outboundsummary['WT',date3]+summary['WT',date3]
    final_df['Wt_'+date2]=outboundsummary['WT',date2]+summary['WT',date2]


    # In[14]:


    final_df=final_df.reset_index()


    # In[15]:


    hub_atted_df=pd.read_sql("select * from tbl_HubAttendance where SDate='{0}'".format(date3),cnxn)


    # In[ ]:


    hub_atted_df


    # In[16]:


    hub_staff_df=pd.read_sql("SELECT BRCD,StaffCount FROM dbo.tbl_HubStaffCount",cnxn)


    # In[17]:


    hub_count_df=pd.merge(hub_staff_df,hub_atted_df,left_on='BRCD',right_on='HubCode',how='outer')


    # In[18]:


    hub_count_df=hub_count_df.fillna(0)


    # In[19]:


    hub_count_df=hub_count_df[['BRCD','StaffCount','TStaff','CStaff','CHandlers']]


    # In[21]:


    targetdf=pd.read_excel(r'D:\Python\Scripts and Files\Python Scripts\Master HUB head_v1.xlsx')
    targetdf=targetdf[['Branch Code','Target  (TPMD)','Handler Target(tpmd)']]


    # In[23]:


    hub_count_df


    # In[24]:


    hub_count_df=pd.merge(hub_count_df,targetdf,left_on='BRCD',right_on='Branch Code',how='outer')


    # In[25]:


    merge=pd.merge(final_df,hub_count_df,left_on='TCBR',right_on='BRCD',how='outer')


    # In[26]:


    merge=merge.fillna(0)


    # In[27]:


    merge['Wt_'+date3]=pd.np.round(merge['Wt_'+date3]/1000.0,1)
    merge['Wt_'+date2]=pd.np.round(merge['Wt_'+date2]/1000.0,1)


    # In[ ]:


    # merge['Prod_'+date2]=pd.np.round(merge['Wt_'+date2]/merge['# Staff in JUNE'],0)


    # In[28]:


    merge['StaffCount']=merge['StaffCount'].astype(int)


    # In[29]:


    merge['Prod_'+date3]=pd.np.round(merge['Wt_'+date3]/merge['StaffCount'],0)


    # In[30]:


    merge['Scaled_'+date3]=pd.np.round(merge['Prod_'+date3]*100.0/merge['Target  (TPMD)'],0)


    # In[31]:


    merge['Scaled_'+date3]=merge['Scaled_'+date3].apply(lambda x:str(x)+'%')


    # In[68]:


    f1=merge[['TCBR','StaffCount','Target  (TPMD)','Prod_'+date3,'Scaled_'+date3,'CStaff']]


    # In[69]:


    f1.sort_values('Target  (TPMD)',ascending=False,inplace=True)


    # In[70]:


    f1


    # In[ ]:


    ##Handler summary


    # In[35]:


    handler_summary=merge[['TCBR','Handler Target(tpmd)','Wt_'+date3,'CHandlers']]


    # In[36]:


    handler_summary[date3+' Handler count']=handler_summary['CHandlers'].astype(int)


    # In[37]:


    handler_summary['Prod_'+date3]=pd.np.round(handler_summary['Wt_'+date3]/handler_summary['CHandlers'],0)


    # In[38]:


    handler_summary['Scaled_'+date3]=pd.np.round(handler_summary['Prod_'+date3]*100.0/handler_summary['Handler Target(tpmd)'],0)


    # In[ ]:


    handler_summary


    # In[39]:


    handler_summary=handler_summary.replace([np.inf,-np.inf],np.nan).fillna(0)


    # In[40]:


    handler_summary['Scaled_'+date3]=handler_summary['Scaled_'+date3].apply(lambda x:str(x)+'%')


    # In[41]:


    f2=handler_summary[['TCBR','Handler Target(tpmd)','Wt_'+date3,'CHandlers','Prod_'+date3,'Scaled_'+date3]]


    # In[ ]:


    f2


    # In[ ]:


    ##Detailed Summary


    # In[42]:


    detailed_inbound=pd.DataFrame()
    for i in range(1,3):
        date1=datetime.strftime(datetime.now()-timedelta(i),'%Y-%m-%d')
        startdate=date1+' 00:00:00'
        enddate=date1+' 23:59:00'
        query=("""SELECT  b.ToBH_CODE ,
            ORG.ControlArea ,
            DST.ControlArea ,-- b.TCBR, CONVERT(DATE,a.actarrv_dt) arv_dt ,
            YEAR(a.actarrv_dt) YR ,
            MONTH(a.actarrv_dt) MTH ,
            COUNT(c.DOCKNO) In_CONS ,
            SUM(c.ACTUWT) WT ,
            SUM(c.NOPKGS) PCS ,
            SUM(DK.CHRGWT) CHRGWT --, SUM(dk.CFT_TOTAL) Volume
            FROM    dbo.THCHDR a WITH ( NOLOCK )
                    INNER JOIN dbo.TCHDR b WITH ( NOLOCK ) ON a.thcno = b.THCNO
                                                              AND a.sourcehb = b.ToBH_CODE
                    INNER JOIN dbo.TCTRN c WITH ( NOLOCK ) ON c.TCNO = b.TCNO
                    INNER JOIN dbo.DOCKET DK WITH ( NOLOCK ) ON c.DOCKNO = DK.DOCKNO
                    INNER JOIN dbo.brms ORG WITH ( NOLOCK ) ON DK.ORGNCD = ORG.BRCD
                    INNER JOIN dbo.brms DST WITH ( NOLOCK ) ON DK.REASSIGN_DESTCD = DST.BRCD
                    INNER JOIN dbo.brms D WITH ( NOLOCK ) ON D.BRCD = b.ToBH_CODE
            WHERE   a.actarrv_dt BETWEEN '{0}'
                                 AND     '{1}'
                    AND D.HUBCENTER = 'Y' 
                    --AND B.ToBH_CODE IN ( 'BOMH','BLRH','DELH')  
            GROUP BY b.ToBH_CODE ,
                    ORG.ControlArea ,
                    DST.ControlArea ,
                    YEAR(a.actarrv_dt) ,
                    MONTH(a.actarrv_dt)
            ORDER BY 1 ,
                    2""").format(startdate,enddate)
        yestdf=pd.read_sql(query,cnxn)
    #     print (yestdf[yestdf['ToBH_CODE']=='MAAH'])
        inbound_summary=yestdf.pivot_table(index=['ToBH_CODE'],values=['WT','PCS'],aggfunc={'WT':sum,'PCS':sum}).reset_index()
        #print (inbound_summary)
        maah_wt=inbound_summary[inbound_summary['ToBH_CODE']=='MAAH']['WT'].values[0]
        maab_wt=inbound_summary[inbound_summary['ToBH_CODE']=='MAAB']['WT'].values[0]
        total_maah_wt=maah_wt+maab_wt
        #print ('total_maah_wt',total_maah_wt)
        maah_wt_pcs=inbound_summary[inbound_summary['ToBH_CODE']=='MAAH']['PCS'].values[0]
        maab_wt_pcs=inbound_summary[inbound_summary['ToBH_CODE']=='MAAB']['PCS'].values[0]
        total_maah_wt_pcs=maah_wt_pcs+maab_wt_pcs
        
        inbound_summary=inbound_summary[~inbound_summary['ToBH_CODE'].isin(['MAAB','MAAH'])]
        inbound_summary1=pd.DataFrame([{'ToBH_CODE':'MAAH','WT':total_maah_wt,'Date':date1,'PCS':total_maah_wt_pcs}])
        inbound_summary['Date']=date1
        inbound_summary=pd.concat([inbound_summary,inbound_summary1],ignore_index=True)
        detailed_inbound=pd.concat([detailed_inbound,inbound_summary],ignore_index=True)


    # In[43]:


    detailed_inbound=detailed_inbound[detailed_inbound['ToBH_CODE'].isin(['BLRH','BOMH','DELH','AMDH','PNQH','AMCH','CCUH','HYDH','MAAH','IDRH','KNPH','NAGH','NDAH'])]
    detailed_summary=detailed_inbound.pivot_table(index=['ToBH_CODE'],columns=['Date'],values=['WT','PCS'],aggfunc={'WT':sum,'PCS':sum})


    # In[44]:


    detailed_outbound=pd.DataFrame()
    for i in range(1,3):
        date1=datetime.strftime(datetime.now()-timedelta(i),'%Y-%m-%d')
        startdate=date1+' 00:00:00'
        enddate=date1+' 23:59:00'
        query=("""SELECT  b.TCBR ,
            ORG.ControlArea ,
            DST.ControlArea , --b.ToBH_CODE, CONVERT(DATE,a.actdept_dt) dept_dt ,
            YEAR(a.actdept_dt) YR ,
            MONTH(a.actdept_dt) MTH ,
            COUNT(c.DOCKNO) Out_CONS ,
            SUM(c.ACTUWT) WT ,
            SUM(c.NOPKGS) PCS ,
            SUM(DK.CHRGWT) CHRGWT --, SUM(dk.CFT_TOTAL) Volume
    FROM    dbo.THCHDR a WITH ( NOLOCK )
            INNER JOIN dbo.TCHDR b WITH ( NOLOCK ) ON a.thcno = b.THCNO
                                                      AND a.sourcehb = b.TCBR
            INNER JOIN dbo.TCTRN c WITH ( NOLOCK ) ON c.TCNO = b.TCNO
            INNER JOIN dbo.DOCKET DK WITH ( NOLOCK ) ON c.DOCKNO = DK.DOCKNO
            INNER JOIN dbo.brms ORG WITH ( NOLOCK ) ON DK.ORGNCD = ORG.BRCD
            INNER JOIN dbo.brms DST WITH ( NOLOCK ) ON DK.REASSIGN_DESTCD = DST.BRCD
            INNER JOIN dbo.brms D WITH ( NOLOCK ) ON D.BRCD = b.TCBR
    WHERE   a.actdept_dt BETWEEN '{0}'
                         AND     '{1}'
            AND D.HUBCENTER = 'Y'
            --AND b.TCBR IN ( 'BOMH','BLRH','DELH')          
    GROUP BY b.TCBR ,
            ORG.ControlArea ,
            DST.ControlArea ,
            YEAR(a.actdept_dt) ,
            MONTH(a.actdept_dt)
    ORDER BY 1 ,
            2 """).format(startdate,enddate)
        yestdf=pd.read_sql(query,cnxn)
    #     print (yestdf)
        inbound_summary=yestdf.pivot_table(index=['TCBR'],values=['WT','PCS'],aggfunc={'WT':sum,'PCS':sum}).reset_index()
        maah_wt=inbound_summary[inbound_summary['TCBR']=='MAAH']['WT'].values[0]
        maab_wt=inbound_summary[inbound_summary['TCBR']=='MAAB']['WT'].values[0]
        total_maah_wt=maah_wt+maab_wt
        maah_wt_pcs=inbound_summary[inbound_summary['TCBR']=='MAAH']['PCS'].values[0]
        maab_wt_pcs=inbound_summary[inbound_summary['TCBR']=='MAAB']['PCS'].values[0]
        total_maah_wt_pcs=maah_wt_pcs+maab_wt_pcs
        
        inbound_summary=inbound_summary[~inbound_summary['TCBR'].isin(['MAAB','MAAH'])]
        inbound_summary1=pd.DataFrame([{'TCBR':'MAAH','WT':total_maah_wt,'Date':date1,'PCS':total_maah_wt_pcs}])
        inbound_summary['Date']=date1
        inbound_summary=pd.concat([inbound_summary,inbound_summary1],ignore_index=True)
        detailed_outbound=pd.concat([detailed_outbound,inbound_summary],ignore_index=True)


    # In[45]:



    detailed_outbound=detailed_outbound[detailed_outbound['TCBR'].isin(['BLRH','BOMH','DELH','AMDH','PNQH','AMCH','CCUH','HYDH','MAAH','IDRH','KNPH','NAGH','NDAH'])]
    outbound_detailed_summary=detailed_outbound.pivot_table(index=['TCBR'],columns=['Date'],values=['WT','PCS'],aggfunc={'WT':sum,'PCS':sum})


    # In[46]:


    detailed_df=pd.DataFrame()


    # In[47]:


    detailed_df['Wt_'+date3]=outbound_detailed_summary['WT',date3]+detailed_summary['WT',date3]
    detailed_df['Wt_'+date2]=outbound_detailed_summary['WT',date2]+detailed_summary['WT',date2]
    detailed_df['Pcs_'+date3]=outbound_detailed_summary['PCS',date3]+detailed_summary['PCS',date3]
    detailed_df['Pcs_'+date2]=outbound_detailed_summary['PCS',date2]+detailed_summary['PCS',date2]


    # In[ ]:


    detailed_df


    # In[48]:


    detailed_df=detailed_df.reset_index()


    # In[49]:


    detailed_df['Wt_'+date3]=pd.np.round(detailed_df['Wt_'+date3]/1000.0,1)


    # In[ ]:


    detailed_df.head()


    # In[ ]:


    hub_count_df


    # In[50]:


    merge2=pd.merge(detailed_df,hub_count_df,left_on='TCBR',right_on='BRCD',how='outer')


    # In[51]:


    merge2['StaffCount']=merge2['StaffCount'].astype(int)


    # In[52]:


    # merge2
    merge2['Wt_Prod_'+date3]=pd.np.round(merge2['Wt_'+date3]/merge2['StaffCount'],0)


    # In[53]:


    merge2['Pcs_Prod_'+date3]=pd.np.round(merge2['Pcs_'+date3]/merge2['StaffCount'],0)


    # In[55]:


    merge2.columns


    # In[56]:


    f3=merge2[['TCBR', 'Target  (TPMD)','StaffCount','Wt_'+date3, 'Pcs_'+date3,
           'Wt_Prod_'+date3, 'Pcs_Prod_'+date3]]


    # In[ ]:


    f3


    # In[57]:


    handler_summary_detailed=merge2[['TCBR','Wt_'+date3,'Pcs_'+date3,'CHandlers','Handler Target(tpmd)','StaffCount']]


    # In[58]:


    handler_summary_detailed['CHandlers']=handler_summary_detailed['CHandlers'].astype(int)


    # In[59]:


    handler_summary_detailed['Wt_Prod_'+date3]=pd.np.round(handler_summary_detailed['Wt_'+date3]/handler_summary_detailed['StaffCount'],0)


    # In[60]:


    handler_summary_detailed['Pcs_Prod_'+date3]=pd.np.round(handler_summary_detailed['Pcs_'+date3]/handler_summary_detailed['StaffCount'],0)


    # In[61]:


    f4=handler_summary_detailed[['TCBR','Handler Target(tpmd)','StaffCount','Wt_'+date3,'Pcs_'+date3,'Wt_Prod_'+date3,'Pcs_Prod_'+date3,'CHandlers']]


    # In[62]:


    f4


    # In[63]:


    writer = pd.ExcelWriter(r'D:\Data\Hub_Productvity_Daily\Hub_Productvity_Daily_v7.xlsx', engine='xlsxwriter')
    f1.to_excel(writer,sheet_name='Staff_Productvity')
    f2.to_excel(writer,sheet_name='Handler_Productvity')
    f3.to_excel(writer,sheet_name='Staff_Productvity(Detailed)')
    f4.to_excel(writer,sheet_name='Handler_Productvity(Detailed)')
    writer.save()


    # In[64]:


    todate=datetime.strftime(datetime.now(),'%Y-%m-%d')
    todate


    # In[65]:


    filepath=r'D:\Data\Hub_Productvity_Daily\Hub_Productvity_Daily_v7.xlsx'


    # In[66]:


    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    from email.mime.base import MIMEBase
    from email import encoders
    import os
    from string import Template
    import pyodbc


    # In[67]:

    # 
    # TO=['abhishek.cv@spoton.co.in']
    TO=["samarjeet.dubey@spoton.co.in","krishna.kumar.bhardwaj@spoton.co.in","ramachandran.p@spoton.co.in","Rajnish.pathak@spoton.co.in","jaivir.singh@spoton.co.in","sopanrao.bhoite@spoton.co.in","pawan.sharma@spoton.co.in","ashwani.gangwar@spoton.co.in","prasanna.hegde@spoton.co.in","onkar.sharma@spoton.co.in","manoj.pareek@spoton.co.in","narendra.londhe@spoton.co.in","rajesh.ks@spoton.co.in","pramod.pandey@spoton.co.in","rajesh.mishra@spoton.co.in","sukesh.mishra@spoton.co.in","ashok.dwivedi@spoton.co.in","lingaraj.chidambaram@spoton.co.in"]
    CC= ["abhik.mitra@spoton.co.in","rom_spot@spoton.co.in","Avinash.Singh@spoton.co.in","dinesh.kumar.sharma@spoton.co.in","sasikumar.kannan@spoton.co.in","rajesh.debnath@spoton.co.in","jothi.menon@spoton.co.in","ananth.m@spoton.co.in","rajesh.kumar@spoton.co.in","bushra.jamadar@spoton.co.in","anushree.gadre@spoton.co.in","vimal.s@spoton.co.in","satya.pal@spoton.co.in","vishwas.j@spoton.co.in","shivananda.p@spoton.co.in","mahesh.reddy@spoton.co.in","abhishek.cv@spoton.co.in","shruthi.sk@spoton.co.in"]
    # CC=["mahesh.reddy@spoton.co.in"]
    FROM="reports.ie@spoton.co.in"

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "Hub Productvity -Daily" + " - " + str(todate)
    html='''<html>
    <h4>Dear All,</h4>
    <p>PFA the Air Monitoring Report for $date</p>
    </html>'''
    #s = Template(html).safe_substitute(date=yest_date)
    report=""
    report+="Dear All"
    report+='<br>'
    report+='Please find Hub Productvity -Daily'
    report+='<br>'
    report+='PFB Staff Productvity Summary'
    report+='<br>'+f1.to_html()+'<br>'
    report+='<br>'
    report+='<br>'
    report+='PFB  Handler Productvity Summary'
    report+='<br>'+f2.to_html()+'<br>'
    report+='<br>'

    abc=MIMEText(report,'html')
    msg.attach(abc)
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filepath,"rb").read() )
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
    msg.attach(part)

    # part1 = MIMEBase('application', "octet-stream")
    # part1.set_payload( open(filepath1,"rb").read() )
    # encoders.encode_base64(part1)
    # part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
    # msg.attach(part1)


    # server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    # server.login("mahesh.reddy@spoton.co.in", "Nov@2018")
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO+CC, msg.as_string())
    server.quit()

except:
    TO=['mahesh.reddy@spoton.co.in','abhishek.cv@spoton.co.in']
    FROM='mis.ho@spoton.co.in'
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    #msg["CC"] = ",".join(CC)
    #msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "ERROR Report" 
    report=""
    report+='Hi,'

    report+='<br>'
    report+='There was some error in Hub_Productvity Daily Report'
    report+='<br>'
    
    abc=MIMEText(report.encode('utf-8'),'html')
    msg.attach(abc)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO, msg.as_string())
    server.quit()

