
# coding: utf-8

# In[1]:

from Networkmeeting_Reach import lhplanning
import numpy as np
import pandas as pd

from IPython import display
from datetime import datetime
from datetime import datetime,timedelta
from datetime import datetime, timedelta
import smtplib
import ftplib
import traceback
import calendar
import os
import pyodbc
import Utilities


# In[2]:

cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")


# In[3]:


start_date=datetime.strftime(datetime.now()-timedelta(days=1),'%Y-%m-%d')+' 00:00:00'
enddate=datetime.strftime(datetime.now()-timedelta(days=1),'%Y-%m-%d')+' 23:59:00'
start_date,enddate



# In[4]:

query=("""SELECT A.sealno_out ,
         B.sealno_in ,a.SealNo_Out1,b.SealNo_In1,
         A.thcno ,
         A.routename ,
         A.routecd ,
         A.sourcehb ,
         A.tobh_code ,
         A.thcdt ,
         A.actarrv_dt ,
         A.actarrv_tm ,
         A.actdept_dt ,
         A.actdept_tm ,
         A.vehno ,
         A.vehtype ,
         A.ld_actuwt ,
         A.ld_pkgs ,
         A.VENDOR_CODE ,
         A.VENDOR_NAME
  FROM   dbo.THCHDR A WITH ( NOLOCK )
         LEFT OUTER JOIN dbo.THCHDR B WITH ( NOLOCK ) ON A.thcno = B.thcno
                                                         AND A.tobh_code
= B.sourcehb
  WHERE a.thcdt between '{0}' and '{1}'""").format(start_date,enddate) 


# In[5]:

df=pd.read_sql(query,Utilities.cnxn)
df=df[df['vehtype']!='D']
len(df)
df=df[df['ld_actuwt']!=0]
df['sealno_in']=df['sealno_in'].astype(str)
df=df[~df['sealno_in'].isin(['None','000000000'])]

# In[ ]:

df.columns


# In[6]:

for i in [u'sealno_out', u'sealno_in', u'SealNo_Out1', u'SealNo_In1']:
    df[i]=df[i].apply(lambda x:x if x==None else x.lower())


# In[7]:

for i in [u'sealno_out', u'SealNo_Out1']:
    df[i]=df[i].apply(lambda x:'-' if x==None else x)


# In[8]:

for i in [u'sealno_in', u'SealNo_In1']:
    df[i]=df[i].apply(lambda x:'.' if x==None else x)


# In[9]:

df['OutList']=df[['sealno_out','SealNo_Out1']].values.tolist()
df['InList']=df[['sealno_in','SealNo_In1']].values.tolist()


# In[10]:

def check(l1,l2):
    if (any(x in l2 for x in l1)):
        return "Match"
    else:
        return "Not Match"


# In[11]:

df['Exception']=df.apply(lambda x:check(x['OutList'],x['InList']),axis=1)


# In[ ]:



# In[ ]:

# def getCheck(x,y):
#     if x==None:
#         return "Not Match"
#     elif x in y:
#         return "Match"
#     elif x not in y:
#         return "Not Match"
#     else:
#         pass


# In[ ]:

#df['Exception']=df.apply(lambda x:getCheck(x['sealno_in'],x['List']),axis=1)


# In[ ]:

# df['Check']=df.apply(lambda x:True if x['sealno_in'] in x['List'] else False,axis=1)


# In[12]:

df['RouteList']=df['routename'].apply(lambda x:x.split('-'))
df['FirstLeg']=df['RouteList'].apply(lambda x:x[0])
df['LastLeg']=df['RouteList'].apply(lambda x:x[-1])
df['FirstLeg']=df['FirstLeg'].apply(lambda x:x.strip(' '))
df['LastLeg']=df['LastLeg'].apply(lambda x:x.strip(' '))


# In[13]:

cnxn1 = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=PYTHON_DB;UID=PythonOnline;PWD=P@ssw0rd123$")


listofdf=pd.read_sql("select * from listoflists",cnxn1)
hublist=listofdf['New Hub'].unique().tolist()
hublist=hublist+['MAAB','BHOH']

lh_dff=pd.read_csv(r'C:\Users\rajeeshv\Downloads\LH.csv')
len(lh_dff)


# In[14]:

lh_dff=lh_dff[lh_dff['CODE']!='9888']
lh_dff_routes=lh_dff[lh_dff['Stat']=='LH']
len(lh_dff_routes)


# In[15]:

feeder_dff_routes=lh_dff[lh_dff['Stat']=='Feeder']
feeder_dff_list=feeder_dff_routes['ROUTE NAME'].tolist()
lh_dff_list=lh_dff_routes['ROUTE NAME'].tolist()


# In[16]:

def getType(routename):
    if routename in lh_dff_list:
        return "LH"
    else:
        return "Feeder"


# In[15]:


x1=[]
def getList(x):
    d=[i.strip(' ') for i in x]
    x12='-'.join(d)
    return x12


# In[17]:

df['RouteList_1']=df.apply(lambda x: getList(x['RouteList']),axis=1)


# In[18]:

df=df[~df['RouteList_1'].isin(['LNIF-PHRB-PNQH','JEJF-PHRB','PNQH-PHRB-LNIF','PHRB-JEJF','BARF-PHRB-PNQH'])]
df['Type']=df.apply(lambda x:getType(x['RouteList_1']),axis=1)


# In[19]:

lh_df=df[df['Type']=='LH']
len(lh_df)


# In[22]:


feeder_df=df[df['Type']=='Feeder']
len(feeder_df)


# In[20]:

summary=lh_df.pivot_table(index=['routename','sourcehb','tobh_code'],columns=['Exception'],aggfunc={'Exception':len}).fillna(0)
summary.sort_values(('Exception','Not Match'),ascending=False,inplace=True)


# In[21]:

summary


# In[22]:

feeder_summary=feeder_df.pivot_table(index=['routename','sourcehb','tobh_code'],columns=['Exception'],aggfunc={'Exception':len}).fillna(0)
feeder_summary.sort_values(('Exception','Not Match'),ascending=False,inplace=True)


# In[23]:

todate=datetime.strftime(datetime.now(),'%Y-%m-%d')                                                                                                                                               
todate
summary.to_csv(r'D:\Data\seal_exception_report\LH_Summary'+str(todate)+'.csv')
summary.to_csv(r'D:\Data\seal_exception_report\LH_Summary.csv')
feeder_summary.to_csv(r'D:\Data\seal_exception_report\Feeder_Summary'+str(todate)+'.csv')
feeder_summary.to_csv(r'D:\Data\seal_exception_report\Feeder_Summary.csv')
df.to_csv(r'D:\Data\seal_exception_report\Data'+str(todate)+'.csv')
df.to_csv(r'D:\Data\seal_exception_report\Data.csv')


# In[24]:

filepath1=r'D:\Data\seal_exception_report\LH_Summary.csv'
filepath2=r'D:\Data\seal_exception_report\Feeder_Summary.csv'
filepath3=r'D:\Data\seal_exception_report\Data.csv'


# In[25]:

import pandas as pd
import numpy as np
# from pymongo import MongoClient
from string import Template
import smtplib
import os
from datetime import datetime, timedelta
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import smtplib
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders


# In[27]:



TO=['mahender.singh@spoton.co.in','scincharge_spot@spoton.co.in','hubmgr_spot@spoton.co.in','aom_spot@spoton.co.in','dom_spot@spoton.co.in','rom_spot@spoton.co.in','umesh.sharma@spoton.co.in','bhupinder.singh@spoton.co.in','shubhanker.sr@spoton.co.in','ashwani.gangwar@spoton.co.in','dilip.singh@spoton.co.in','venkata.kameswara@spoton.co.in']
CC=['abhik.mitra@spoton.co.in','pawan.sharma@spoton.co.in','jothi.menon@spoton.co.in','shivananda.p@spoton.co.in','rajesh.kumar@spoton.co.in','mahesh.reddy@spoton.co.in','abhishek.cv@spoton.co.in','satya.pal@spoton.co.in','saptarshi.pathak@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in']
# TO=['mahesh.reddy@spoton.co.in']
# CC=['abhishek.cv@spoton.co.in']
# BCC=['mahesh.reddy@spoton.co.in']
FROM="reports.ie@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "Seal Exception Report " + '- ' +todate
html3='''
<h5> To download the data , Please click the link below </h5>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Hub_Perfor_Data.csv"</a>http://spoton.co.in/downloads/IEProjects/ETA/Hub_Perfor_Data.csv</p></b>

<h5> To download the condata of DEPS/excluded cons , Please click the link below </h5>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Hub_Perfor_DEPS_condata.csv"</a>http://spoton.co.in/downloads/IEProjects/ETA/Hub_Perfor_DEPS_condata.csv</p></b>

'''
report=""
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='PFA Seal Exception Report '+todate
report+='<br>'
report+='PFA LH Summary :'
report+='<br>'
report+='<br>'
report+='<br>'+summary.head(20).to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='PFA Feeder Summary :'
report+='<br>'
report+='<br>'
report+='<br>'+feeder_summary.head(20).to_html()+'<br>'

report+='For Data and Summary use attached files.'
#report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)

part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath1,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
msg.attach(part)

part2 = MIMEBase('application', "octet-stream")
part2.set_payload( open(filepath2,"rb").read() )
encoders.encode_base64(part2)
part2.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath2))
msg.attach(part2)

part3 = MIMEBase('application', "octet-stream")
part3.set_payload( open(filepath3,"rb").read() )
encoders.encode_base64(part3)
part3.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath3))
msg.attach(part3)



server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("spoton.net.in", "Star@123#")
server.login('spoton.net.in', 'Star@123#')
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()



# In[ ]:



