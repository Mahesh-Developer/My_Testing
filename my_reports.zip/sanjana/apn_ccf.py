
# coding: utf-8

# In[1]:


import pandas as pd
from datetime import datetime, timedelta
import numpy as np
from sqlalchemy import *
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import sys
import Utilities
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template
#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.87;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
#cursor = cnxn.cursor()
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
#cursor = cnxn.cursor()

try:
  query = ("""
          EXEC USP_CLOSINGSTOCK_REPORT_1HR_IE
          """)

  df = pd.read_sql(query, Utilities.cnxn) 

  df.rename(columns={'CS_TemaLeaderName':'CS Team Leader Name','Is_ADC':'Is ADC','CustomerName':'Customer Name','DEST_BRCD':'DEST BRCD','DRS_PREPARED':'DRS PREPARED','DEST_DEPOT':'DEST DEPOT',"TimestateDate":'Timestate Date',"ARRV_AT_DEST_SC":'ARRV AT DEST SC',"ConStatusCode":'Con Status Code',"CON_BLOCKED_FOR_ODA_PIN_ISSUES":'CON BLOCKED FOR ODA PIN ISSUES',"CON_BLOCKED_FOR_PAY_ISSUES":'CON BLOCKED FOR PAY ISSUES',"CON_BLOCKED_FOR_DEMURRAGE":'CON BLOCKED FOR DEMURRAGE'},inplace=True)


  pd.set_option("display.max_columns",100)
  #http://spoton.co.in/downloads/OCID_CLOSINGSTOCK_1HR/OCID_CLOSINGSTOCK_1HR.xls
  #df=pd.read_excel(r'http://spoton.co.in/downloads/OCID_CLOSINGSTOCK_1HR/OCID_CLOSINGSTOCK_1HR.xls')
  df["Delay_Hours"]=np.round((df["Timestate Date"]-df["ARRV AT DEST SC"])/np.timedelta64(1, 'h'),0)
  df["PARENTCODE"]=df["PARENTCODE"].fillna(0.0).astype(int).astype(str)
  df = df.assign(delaygrp=pd.cut(df.Delay_Hours,bins=[-np.inf,24,48,96,np.inf],labels=['0-24','24-48','48-96','96+']))
  try:
      potccflist=pd.read_csv(r"C:\Users\rajeeshv\Downloads\Rajesh\mahesh\Appointment Reports\Potential_CCF.csv")
  except:
      potccflist=pd.read_csv(r"C:\Users\rajeeshv\Downloads\Rajesh\mahesh\Potential_CCF.csv")
  potccflist["Key"]=potccflist["Destn"].astype(str)+potccflist["PARENTCODE"].astype(str)
  potccflist=potccflist["Key"].values.tolist() 
  df["Key"]=df["DEST BRCD"].astype(str)+df["PARENTCODE"]
  df["PotCCF"]=df.apply(lambda x: True if x["Key"] in potccflist else False,axis=1)
  apnstatcodes=['APN', 'APT']
  ucgstatcodes=['UCG','UG1','UG2','UG3']
  depsstatcodes=['DIR','EIR','PIR','SIR','SRD','SRE','SRP','SRS']
  ofdstatuscode=['AOD']
  addressissues=['CDA','WIA','CNC','CPN']
  df["APNCons"]=df.apply(lambda x: (True if x["Con Status Code"] in apnstatcodes or x['Is ADC']=='YES' else False),axis=1)
  print (len(df[df['APNCons']==True]))
  #exit(0)
  dff=df[((df["APNCons"]==True)|(df["PotCCF"]==True))&~(df["Con Status Code"].isin(depsstatcodes))&~(df["Con Status Code"].isin(ucgstatcodes))]
  dff=dff[(dff["CON BLOCKED FOR ODA PIN ISSUES"]!='YES')&(dff["CON BLOCKED FOR PAY ISSUES"]!='YES')&(dff["CON BLOCKED FOR DEMURRAGE"]!='YES')&(dff["CSGNCD"]!=119721)]
  dff['delaycat']=dff['delaygrp'].astype(str)
  dff["Appointment Date"]=pd.to_datetime(dff["Appointment Date"],format='%d/%m/%Y',errors='coerce',dayfirst=True)
  dff["APN Existing"]=dff.apply(lambda x: True if x["Appointment Date"]>=pd.to_datetime('today') else False,axis=1)
  dff2=dff[((dff["APN Existing"]==False)&(dff["APNCons"]==True))|(dff["Con Status Code"]=="APN")]
  appdf=dff2.pivot_table(index=["CS Team Leader Name"],columns=["APN Existing",'delaycat'],values=["DOCKNO"],aggfunc={"DOCKNO":len},margins=True).reset_index().sort_values(("DOCKNO","All"),ascending=False)
  appdf=appdf.set_index(("CS Team Leader Name",""))#head(2)
  appdf=appdf.fillna(0.0).astype(int)
  appdf=appdf.sort_values(("DOCKNO","All"),ascending=False)
  topfailinglocation=appdf.index[1]
  example=appdf.loc[:,("DOCKNO","All")][1]
  totalcons1=len(dff2[dff2['APN Existing']==False])
  consgrter96=appdf.values[0][3]
  print ('totalcons1',totalcons1)
  print ('consgrter96',consgrter96)
  dff3=dff[(dff["Appointment Date"].isnull())&(dff["PotCCF"]==True)]
  pcfdf=dff3.pivot_table(index=["CS Team Leader Name"],columns=["APN Existing",'delaycat'],values=["DOCKNO"],aggfunc={"DOCKNO":len},margins=True).reset_index().sort_values(("DOCKNO","All"),ascending=False)
  pcfdf=pcfdf.set_index(("CS Team Leader Name",""))#head(2)
  pcfdf=pcfdf.fillna(0.0).astype(int)
  pcfdf=pcfdf.sort_values(("DOCKNO","All"),ascending=False)
  topfailinglocation2=pcfdf.index[1]
  example2=pcfdf.loc[:,("DOCKNO","All")][1]
  totalcons2=pcfdf.loc[:,("DOCKNO","All")][0]
  consgrtr962=pcfdf.values[0][3]
  print ('totalcons2',totalcons2)
  print ('consgrter962',consgrtr962)
  filepath1=r'D:\Data\Appointment Reports\No Appointment\apn.csv'
  filepath2=r'D:\Data\Appointment Reports\No Appointment\pcf.csv'
  filepath3=r'D:\Data\Appointment Reports\apn.csv'
  filepath4=r'D:\Data\Appointment Reports\pcf.csv'
  try:
      dff2.to_csv(filepath1)
      dff3.to_csv(filepath2)
  except:
      dff2.to_csv(filepath3)
      dff3.to_csv(filepath4)

  filePath=r'D:\Data\Appointment Reports\No Appointment\apn.csv'
  print ('done')

  from datetime import date,timedelta
  todate=date.today()
  today_date=datetime.strftime(todate,'%d-%m-%Y')
  today_date
  #vishwas.j@spoton.co.in


  TO=["spot_cstl@spoton.co.in","krishna.chandrasekar@spoton.co.in","abhik.mitra@spoton.co.in", "jothi.menon@spoton.co.in","sharmistha.majumdar@spoton.co.in","shivananda.p@spoton.co.in","sq_spot@spoton.co.in"]
  #TO=['mahesh.reddy@spoton.co.in']
  FROM="reports.ie@spoton.co.in"
  #CC=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
  BCC=['mahesh.reddy@spoton.co.in']
  #BCC=['mahesh.reddy@spoton.co.in']
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  #msg["CC"] = ",".join(CC)
  msg["BCC"] = ",".join(BCC)
  msg["Subject"] = "APN & PCF cons - No Appointment Date" + " : " + str(today_date)
  html='''<html>
  <style>
  p
  {
    margin:0;
    margin-top: 5px;
    padding:0;
    font-size:17px;
      line-height:20px;
  }
  </style>
  <h3>A. Appointment Cons</h3>
  <p>Total Appointment cons without valid Appointment Date is:$totalcons1, of which cons lying at SC for >96 hours is $consgrter96</p>
  <h4>Break-up of appt cons, without appt date :</h4>
  <p>Eg: $example cons under $topfailinglocation does not have a valid appt date.</p>
  </html>'''

  html3='''
  <h3>B. PCF Cons</h3>
  <p>Total PCF cons without ANY potential delivery date (past or future) is:$totalcons2, of which cons lying at SC for >96 hours is $consgrtr962</p>
  <h4>Break-up of PCF cons, without any potential delivery date :</h4>
  <p>Eg: $example2 cons under $topfailinglocation2 does not have a potential delivery date.</p>
  '''
  s = Template(html).safe_substitute(date=today_date,totalcons1=totalcons1,consgrter96=consgrter96,example=example,topfailinglocation=topfailinglocation)
  s1 = Template(html3).safe_substitute(totalcons2=totalcons2,consgrtr962=consgrtr962,example2=example2,topfailinglocation2=topfailinglocation2)
  report=""
  report+=s
  report+='<br>'
  report+='<br>'+appdf.to_html()+'<br>'
  report+=s1
  report+='<br>'+pcfdf.to_html()+'<br>'
  abc=MIMEText(report,'html')
  msg.attach(abc)
  part = MIMEBase('application', "octet-stream")
  part.set_payload( open(filePath,"rb").read() )
  encoders.encode_base64(part)
  part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
  msg.attach(part)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO+BCC, msg.as_string())
  server.quit()

except:
  TO=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  #msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "ERROR Report" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in APN & PCF cons - No Appointment Date'
  report+='<br>'

  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO, msg.as_string())
  server.quit()
