
# coding: utf-8

# In[1]:

import pandas as pd
import numpy as np
from datetime import datetime,timedelta
import pyodbc
from fuzzywuzzy import fuzz
import pandas as pd
import pyodbc
from datetime import datetime,timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
import ftplib
# import Utilities
from calendar import monthrange
import smtplib


# In[2]:



cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")


# In[3]:


df=pd.read_sql("sp_spoton_linehaul_arrival",cnxn)


# In[4]:


len(df)


# In[5]:


df=df[df['Route_code']!='9888']
len(df)


# In[6]:


def getStrip(x):
    vals=x.split('-')
    f=[i.strip(' ') for i in vals]
    f2='-'.join(f)
    return f2


# In[7]:


df['Route Path1']=df.apply(lambda x:getStrip(x['routename']),axis=1)


# In[8]:


selected_path=['BBIH-ANGL-SMBH-NAGH','CCUH-KNPH-DELH','CCUH-BLSF-BBIH-BLRH','CCUH-BBIH-VZAH-MAAB','CCUH-NAGH-BOMH','CCUH-IXRB-PNQH',
'PATH-KNPH-BOMH','AMCH-NDAH','AMCH-BLRH','AMCH-HYDH-MAAB','AMCH-IDRH-BOMH','AMCH-SNRH-PNQH','DELH-CCUH','DELH-BLRH','DELH-SXVF-CJBH',
'DELH-HYDH','DELH-MAAB','DELH-HYDH-MAAB','DELH-AMDH','DELH-BOMH','DELH-IDRH-PTMF-BOMH','DELH-VPIH-BOMH','DELH-IDRH-NAGH','DELH-PNQH',
'DELH-SNRH-PNQH','JAIH-BOMH','KNPH-HYDH-BLRH','LKOH-KNPH-IDRH-BOMH','NDAH-CCUH','NDAH-BLRH','NDAH-VPIH-BOMH','BLRH-BBIH-BLSF-CCUH',
'BLRH-HYDH-KNPH','BLRH-JAIH-NDAH','BLRH-BLRT-MAAB','BLRH-MAAB','BLRH-AMDH','BLRH-HYDH-GLBF-BOMH','BLRH-BOMH','BLRH-BGMH-BOMH','BLRH-PNQH',
'CJBH-SXVF-BLRH-JAIH-DELH','CJBH-SXVF-BLRH-PNQH','HYDH-DELH','HYDH-BOMH','MAAH-DELH','MAAH-HYDH-JAIH-DELH','MAAH-NDAH','MAAH-BLRT-BLRH',
'MAAH-HYDH-VPIH-AMDH','MAAH-BOMH','MAAH-HYDH-PNQH','SXVF-BLRH-BOMH','VZAH-HYDH-BOMH','AMDH-DELH','AMDH-BLRH','AMDH-VPIH-HYDH-MAAB','AMDH-BDQH-BOMH',
'BOMH-CCUH','BOMH-PATH','BOMH-VPIH-DELH','BOMH-DELH','BOMH-IDRH-KNPH-LKOH','BOMH-BLRH','BOMH-CJBH-COKH','BOMH-HYDH','BOMH-MAAB','BOMH-BLRH-SXVF',
'BOMH-HYDH-VZAH','BOMH-BDQH-AMDH','BOMH-BGMH-GOIB','GOIB-BGMH-STRF-BOMH','GOIB-BGMH-PNQH','IDRH-PTMF-SNRH-PNQH','NAGH-SMBH-BBIH','NAGH-IDRH-JAIH-DELH',
'PNQH-SNRH-DELH','PNQH-BLRH','PNQH-SXVF-CJBH','PNQH-MAAB','PNQH-BGMH-GOIB','PNQH-SNRH-IDRH','BLRH-DELH','COKH-BOMH','LKOH-PNQH','PNQH-LKOH',
'DELH-CCUH','BLRH-AMCH','PNQH-DELH','MAAH-AMCH','PNQH-CCUH','BLRH-HYDH-AMCH','COKH-CJBH-SXVF-BOMH','MAAH-BLRH','BOMH-AMDH-DELH','PNQH-NAGH-CCUH','PNQH-SNRH-AMCH','DELH-KNPH-CCUH',
'LKOH-KNPH-SNRH-PNQH','NDAH-HYDH-MAAB','BOMH-KNPH-LKOH','BOMH-KNPH-LKOH','PNQH-SNRH-KNPH-LKOH']


df=df[df['Route Path1'].isin(selected_path)]
len(df)



# In[2]:

todate=datetime.strftime(datetime.now()-timedelta(days=1),"%Y-%m-%d")
todate
df=df[df['sched_Arrvl_date']==todate]
df1=df
len(df1)


# In[3]:

df['Lane']=df['Origin_BrCode']+'-'+df['Dest_BrCode']


# In[ ]:

depdf=df[df['Grace_Departure_Remarks']!='DELAY DEPARTURE']
len(depdf)


# In[4]:

ontime=[' 2nd vehicle','2ND VEH','SECOND VEH','SECOND','2nd veh operated','EXCESS LOAD','second vehicle','SECOND VEHICLE OPERATED']
noremarks=['late depart from path','OK','OK.','ok']
spoton=['DUE TO LESSLOAD',' LATE DEPART DUE TO SHIPMENT PART','LESS LOAD','LESS LOAD','LESSLOAD','fully uttiliazed','less load','RAIN DUE TO LATE DEP','VEH LATE DEPT DUE TO LESS LOAD']
vendor=['VEH LATE DEPT DUE TO VEH LATE PROVIDE VENDOR','vehicle late arrival due to late departure','vehicle late departure due to same unloading','late arrival due to veh late departure from origin','vehicle late departure due to vendor late','late dept due to late arrival','VEHICLE LATE DEPARTURE DUE TO VEHICLE LATE ARRIVAL ','Rout veh not available','dep due to inbound veh late arrived']


# In[5]:

def getDepp(x,y):
    if any(ele in x for ele in ontime):
        return 'ONTIME DEPARTURE'
    else:
        return y


# In[6]:

df['Grace_Departure_Remarks']=df.apply(lambda x:getDepp(x['Delay_Dept_Reason'],x['Grace_Departure_Remarks']),axis=1)


# In[7]:

depdf_summary=df.pivot_table(index=['Lane'],columns=['Grace_Departure_Remarks'],values=['thc_No'],aggfunc={'thc_No':len},margins=True,margins_name="TOTAL").fillna(0)


# In[8]:

depdf_summary


# In[9]:

Spoton_Failure=['less load','2ND VEH OPERATE SAME ROUTE','second veh operated due to excess load','second rout veh operate due to excess load','DUE TO LESS LOAD','second veh opetare same day same route','2ND VEH OPERAT SAME ROUTE','less load','veh operated early due to excess load','due to excess load',"EXCESS LOAD","****","00A843589"]
No_Remarks=['Ok','ok','OK']
def getDepatexce(x,y):
    if (x=='DELAY DEPARTURE' ) and (any(ele in y for ele in spoton)):
        return "Spoton Failure"
    elif (x=='DELAY DEPARTURE') and (any(ele in y for ele in noremarks)):
        return "No Remarks"
    elif (x=='DELAY DEPARTURE') and (any(ele in y for ele in vendor)):
        return "Vendor Issue"
    else:
        return None


# In[10]:

def getDep(x,y):
    print (x,y)
    if (x=='DELAY DEPARTURE') & (y==None):
        return "No Remarks"
    else:
        return y


# In[ ]:




# In[11]:

df['Departure_Exception']=df.apply(lambda x:getDepatexce(x['Grace_Departure_Remarks'],x['Delay_Dept_Reason']),axis=1)
df['Departure_Exception']=df.apply(lambda x:getDep(x['Grace_Departure_Remarks'],x['Departure_Exception']),axis=1)
df[df['Grace_Departure_Remarks']=='DELAY DEPARTURE'][['Delay_Dept_Reason','Departure_Exception']]
depdf_exce_summary=df.pivot_table(index=['Lane'],columns=['Departure_Exception'],values=['thc_No'],aggfunc={'thc_No':len},margins=True,margins_name="TOTAL").fillna(0)


# In[2]:

arrvdf=df[df['Grace_Departure_Remarks']=='ONTIME DEPARTURE']
len(arrvdf)


# In[9]:

arrvdf[(arrvdf['Grace_Arrival_Remarks']=='DELAY ARRIVAL')]


# In[3]:

arrvdf_summary=arrvdf.pivot_table(index=['Lane'],columns=['Grace_Arrival_Remarks'],values=['thc_No'],
                                  aggfunc={'thc_No':len}).fillna(0)


# In[4]:

arrvdf_summary.loc['Total']=arrvdf_summary.sum(axis=0)


# In[5]:

arrvdf_summary[('thc_No','Total')]=arrvdf_summary[('thc_No','DELAY ARRIVAL')]+arrvdf_summary[('thc_No','ONTIME ARRIVAL')]


# In[6]:


# In[29]:



# In[40]:

advance_exception=['Money','Advance Issue','Advance Payment Issue','Advance Payment']
accident_exception=['Accidents','Turn Down On','Out Of Coverage Area','Hold At Same Place']
weather_exception=['Heavy Rain','Rainy','Rain']
breakdown_exception=['veh got break down','Veh Breakdown','Vehicle Breakdown','Breakdown','Break down','Break Down','Repair','Starting','tarting']
rto_exception=['RTO','Rto','rto']
driver_exception=['driver issue','Late Arrived','Driver Not Pick The Phone','Number Is Not Connecting','Driver Number Is Not Connecting','Not Getting Address','Driver Issue','Driver Not Given Delay Reason','Delay Reason Driver Not Given','Vehicle Delay Due To Breakdown','Its Getting Delay Due To Second Driver Not Felling Well']
driver_delay_exception=['Vehicle Late Arrived','Driver Not Given Delay','Driver Not Given Delay Reason','Driver Not Pick The Phone']
festival_exception=['Festival']
touching_excepton=['TOUCHING','EXTRA TOUCHING','touching point','Touching Location','extra touching given','Extra Hold','Due To Extra Hold']
noentry_exception=['No Entry']
roadblock_exception=['Road Block','Road Blocked By Police','Road Blocked']
routedivert_exception=['Route Divert']
singledriver_exception=['Single Driver','Driver No. Continues Busy']
traficjam_exception=['trafik jam','TRAFFIC JAM','Traffic','traffic','traffic jam','Traffic Jam']
salestax_exception=['Sale Tax Officer','Sale']


# In[ ]:


def getArrvExc(x):
    if x=='-':
        return x
    elif any(ele in x for ele in advance_exception):
        return "Advance Money"
    elif any(ele in x for ele in accident_exception):
        return "Accident"
    elif any (ele in x for ele in weather_exception):
        return "Bad Weather"
    elif any (ele in x for ele in breakdown_exception):
        return "Breakdown"
    elif any (ele in x for ele in rto_exception):
        return "Caught By RTO"
    elif any (ele in x for ele in driver_delay_exception):
        return "Driver Not Given Delay Reason"
    elif any (ele in x for ele in festival_exception):
        return "Festival"
    elif any (ele in x for ele in touching_excepton):
        return "Extra Hold At Touching Loc"
    elif any (ele in x for ele in noentry_exception):
        return "No Entry"
    elif any (ele in x for ele in roadblock_exception):
        return "Road Block"
    elif any (ele in x for ele in routedivert_exception):
        return "Route Divert"
    elif any (ele in x for ele in singledriver_exception):
        return "Single Driver"
    elif any (ele in x for ele in traficjam_exception):
        return "Traffic Jam"
    elif any (ele in x for ele in driver_exception):
        return "Driver issue"
    elif any (ele in x for ele in salestax_exception):
        return "Caught By Sale Tax Officer"
    else:
        pass


arrvdf['Arrival_Exception']=arrvdf.apply(lambda x:getArrvExc(x['DelayArrivalRemarks']),axis=1)


# In[41]:

def getExtra(x,y,z):
    if (x=='DELAY ARRIVAL') & (y in [0,'0','ok','Ok','OK','Oky','OKY','oky','']):
        return "Driver Not Given Delay Reason"
    elif (x=='DELAY ARRIVAL') & (y in ['0','recd']):
        return "Driver Not Given Delay Reason"
    elif (x=='DELAY ARRIVAL') & (y==''):
        return "Driver Not Given Delay Reason"
    
    else:
        return z


# In[42]:

arrvdf['Arrival_Exception']=arrvdf.apply(lambda x:getExtra(x['Grace_Arrival_Remarks'],x['DelayArrivalRemarks'],x['Arrival_Exception']),axis=1)


# In[43]:

#arrvdf['Lane']=arrvdf['Origin_BrCode']+'-'+arrvdf['Dest_BrCode']
arrvdf['Grace_Arrival_Remarks']=arrvdf['Grace_Arrival_Remarks'].apply(lambda x: 'ONTIME ARRIVAL' if x=='ONTIME ARRIVAL' else 'DELAY ARRIVAL')
#arrvdf_summary=arrvdf.pivot_table(index=['Lane'],columns=['Grace_Arrival_Remarks'],values=['thc_No'],aggfunc={'thc_No':len},margins=True,margins_name="TOTAL").fillna(0)


# In[44]:

arrvdf_summary


# In[39]:

#arrvdf[arrvdf['Grace_Arrival_Remarks']=='DELAY ARRIVAL'][[]]


# In[45]:

arrvdf_excep_summary=arrvdf.pivot_table(index=['Lane'],columns=['Arrival_Exception'],values=['thc_No'],aggfunc={'thc_No':len},margins=True,margins_name="TOTAL").fillna(0)


# In[46]:

arrvdf_excep_summary
df=pd.merge(df,arrvdf[['thc_No','Arrival_Exception']],on='thc_No',how='left')

# In[47]:

df.to_csv(r'D:\Data\CNM_Arrv_Dep\OTD_vs_Late_Arrival\OTD_Late_Arrival_Data'+str(todate)+'.csv')

df.to_csv(r'D:\Data\CNM_Arrv_Dep\OTD_vs_Late_Arrival\OTD_Late_Arrival_Data.csv')

# In[37]:


filepath=r'D:\Data\CNM_Arrv_Dep\OTD_vs_Late_Arrival\OTD_Late_Arrival_Data.csv'



# In[48]:

# TO=['mahesh.reddy@spoton.co.in']
# CC=['mahesh.reddy@spoton.co.in']
TO=['deepak.sharma@spoton.co.in','raghavendra.rao@spoton.co.in','soham.kakade@spoton.co.in']

# TO=["krishna.kumar.bhardwaj@spoton.co.in","ramachandran.p@spoton.co.in","Rajnish.pathak@spoton.co.in","jaivir.singh@spoton.co.in","sopanrao.bhoite@spoton.co.in","pawan.sharma@spoton.co.in","ashwani.gangwar@spoton.co.in","prasanna.hegde@spoton.co.in","onkar.sharma@spoton.co.in","manoj.pareek@spoton.co.in","narendra.londhe@spoton.co.in","rajesh.ks@spoton.co.in","pramod.pandey@spoton.co.in","rajesh.mishra@spoton.co.in","sukesh.mishra@spoton.co.in","ashok.dwivedi@spoton.co.in","lingaraj.chidambaram@spoton.co.in"]
# CC= ["abhik.mitra@spoton.co.in","rom_spot@spoton.co.in","Avinash.Singh@spoton.co.in","dinesh.kumar.sharma@spoton.co.in","sasikumar.kannan@spoton.co.in","rajesh.debnath@spoton.co.in","jothi.menon@spoton.co.in","ananth.m@spoton.co.in","rajesh.kumar@spoton.co.in","bushra.jamadar@spoton.co.in","anushree.gadre@spoton.co.in","vimal.s@spoton.co.in","satya.pal@spoton.co.in","vishwas.j@spoton.co.in","shivananda.p@spoton.co.in","mahesh.reddy@spoton.co.in","abhishek.cv@spoton.co.in","shruthi.sk@spoton.co.in"]
CC=["mahesh.reddy@spoton.co.in","satya.pal@spoton.co.in",'abhik.mitra@spoton.co.in','shivananda.p@spoton.co.in','prasanna.hegde@spoton.co.in']
FROM="reports.ie@spoton.co.in"
# FROM="mahesh.reddy@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "OTD Vs LATE Arrival Performance/Exception On " + " - " + str(todate)

report=""
report+="Dear All"
report+='<br>'
report+='Kindly find the OTD Vs Late Arrival report/Exception on dated '+str(todate)+'. For more info find the attachment. And one more column in Arrival Exception DELAY HRS.'
report+='<br>'
report+="OTD vs Late Arrival Performance :"
report+='<br>'
report+='<br>'+arrvdf_summary.to_html()+'<br>'
report+='<br>'
report+="Arrival Exception :"
report+='<br>'
report+='<br>'+arrvdf_excep_summary.to_html()+'<br>'
report+='<br>'
report+="Departure Performance :"
report+='<br>'
report+='<br>'+depdf_summary.to_html()+'<br>'
report+='<br>'
report+="Departure Exception :"
report+='<br>'
report+='<br>'+depdf_exce_summary.to_html()+'<br>'

abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)


# server=smtplib.SMTP('smtp.sendgrid.net', 587)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("mahesh.reddy@spoton.co.in", "Nov@2018")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()


# In[ ]:



