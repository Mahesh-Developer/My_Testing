
# coding: utf-8

# In[1]:

import pandas as pd
from datetime import datetime, timedelta
import glob
import numpy as np

import os
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from pandas import ExcelWriter
from email import encoders
# In[2]:


path =r'D:\Data\Closing_Stock_1HR' # use your path
allFiles = glob.glob(path + "/*.csv")
frame = pd.DataFrame()
list_ = []
for file_ in allFiles:
    df = pd.read_csv(file_,index_col=None, header=0)
    list_.append(df)
frame = pd.concat(list_)
frame.to_csv(r'D:\Data\Combined_closing_1HR.csv')

closing1yes = pd.read_csv(r'D:\Data\Combined_closing_1HR.csv')
#closing1yes = pd.io.excel.read_excel(r'C:\Data\temp1\OCID_CLOSINGSTOCK_1HR.xls', 'IEP_Closing_Stock_1HR')


# In[3]:
datetimenow = datetime.now()

def datestring(x):
    fulldate = datetime.strptime(x,'%Y-%m-%d %H:%M:%S')
    return fulldate


# In[4]:

def datestring1(x):
    try:
        fulldate1 = datetime.strptime(x,'%Y-%m-%d %H:%M:%S')
        return fulldate1
    except:
        return 0
#def drsprep(drsprepared, prepdate):
    
    


# In[5]:

closing1yes['Timestamp'] = closing1yes.apply(lambda x:datestring (x['Timestate Date']),axis=1)
closing1yes['DRS_Preparation'] = closing1yes.apply(lambda x:datestring1 (x['LASTDRS PREPAREDDATE']),axis=1)

#closing1yes['DRS_Prepared'] = closing1yes.apply(lambda x:drsprep(x['DRS PREPARED'],x['LASTDRS PREPAREDDATE']), axis=1)

#closinggrp = closing1yes.groupby(['Con', 'ORGNAREA', 'DESTNAREA']).agg({'OPP_Met':max, 'Reached_before_time':max, 'Duedate_New':lambda x: monthcalc(x)}).reset_index()


closing1yes['Timestamp_String']= closing1yes.apply(lambda x: str(x['Timestamp']), axis=1)


# In[9]:

def datestring2(tsp):
    return datetime.strptime(tsp.split(' ')[0]+' 00:01:00', '%Y-%m-%d %H:%M:%S')

def datestring3(tsp):
    return datetime.strptime(tsp.split(' ')[0]+' 23:59:00', '%Y-%m-%d %H:%M:%S')

def getdrs(start, end, drsts):
    try:
        if start<=drsts and drsts<=end:
            return 1
        else:
            return 0
    except:
        return 0


# In[10]:

closing1yes['dayTS_start']= closing1yes.apply(lambda x: datestring2(x['Timestamp_String']), axis=1)
closing1yes['dayTS_end']= closing1yes.apply(lambda x: datestring3(x['Timestamp_String']), axis=1)


# In[11]:

closing1yes['Valid_DRS']= closing1yes.apply(lambda x: getdrs(x['dayTS_start'], x['dayTS_end'], x['DRS_Preparation']), axis=1)


# In[12]:

closing1yes['Arrival_New']= closing1yes.apply(lambda x: datestring(x['ARRV AT DEST SC']),axis=1)


# In[13]:

closing1yes['Incoming_Today']= closing1yes.apply(lambda x: getdrs(x['dayTS_start'], x['dayTS_end'], x['Arrival_New']), axis=1)



opfilevar=datetimenow.date()
opfilevar1=datetimenow.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=np.round((float(currhrs)/60),0)


# In[15]:

grpby = closing1yes.groupby(['Timestamp']).agg({'DOCKNO':len,'REPORTDATE MIN ARRVDT':pd.np.sum, 'Valid_DRS':pd.np.sum, 'Incoming_Today':pd.np.sum}).reset_index()
grpby['Avg_Cooling'] = grpby.apply(lambda x: round(x['REPORTDATE MIN ARRVDT']*1.0/x['DOCKNO'],2),axis=1)
grpby= grpby.sort_values(['Timestamp'],ascending=False)
columnsop = ['Timestamp', 'DOCKNO', 'Incoming_Today','Valid_DRS', 'Avg_Cooling']
grpbyfinal = pd.DataFrame(grpby, columns=columnsop)

grpbyfinal.to_csv(r'D:\Data\Closing_Stock_Hourly.csv')

oppath2 = r'D:\Data\Closing_Stock_Hourly.csv'


# In[ ]:
filePath = oppath2
def sendEmail(TO = ["rajeesh.vr@spoton.co.in"],
            #TO = ["vishwas.j@spoton.co.in"],
            CC = ["vishwas.j@spoton.co.in"],
            #CC = ["vishwas.j@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "Hourly_Closing_Stock" + '_' + str(opfilevar)+'_'+str(opfilevar2)
    body_text = """
    Dear All,
    
    PFB the Hourly Closing stock as of """+str(opfilevar)+'_'+str(opfilevar2)+ """
    
    """+str(grpbyfinal)+"""

    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("vishwas.j@spoton.co.in", "Spoton#123")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends



