
# coding: utf-8

# In[1]:

import pandas as pd
from datetime import datetime, timedelta
import numpy as np
from ortools.algorithms import pywrapknapsack_solver
import ast
pd.set_option("display.max_columns",100)
import sframe as gl


# In[2]:

#1. Downloading df and datetime,int conversions
df=pd.read_excel(r'http://spoton.co.in/downloads/OCID_CLOSINGSTOCK_1HR/OCID_CLOSINGSTOCK_1HR.xls')
df['ACTUWT']=df['ACTUWT'].astype(int)
df['DOCKNO']=df['DOCKNO'].astype(int)
df['PARENTCODE']=df['PARENTCODE'].fillna(0).astype(int)
df["PIECES"]=df['PIECES'].astype(int)


# In[3]:

#2-POST. below's Logic to be inbuilt with Unloading sheet, so no need for filters, just apply data on all BLRC - if required, I should map pincodes
#2-POST. One filter that I still need to apply is ccf cleared data for counting in inventory
#2. Filters
 #A. Predictable CCF OR Meets Weight Filter
potccflist=pd.read_csv(r"D:\Python\Scripts and Files\Path and Graph Files\Potential_CCF.csv")


# In[4]:

potccflist = potccflist.rename(columns={'\xef\xbb\xbfDestn':'Destn'})


# In[5]:

potccflist.columns.tolist()


# In[6]:

potccflist["Key"]=potccflist["Destn"].astype(str)+potccflist["PARENTCODE"].astype(str)
potccflist=potccflist["Key"].values.tolist() 
df["Key"]=df["DEST BRCD"].astype(str)+df["PARENTCODE"].astype(str)
df["PotCCF"]=df.apply(lambda x: True if x["Key"] in potccflist else False,axis=1)
df["Wtfilter"]=(df["ACTUWT"]>=750)|((df["ACTUWT"]>=500)&(df["DEST BRCD"].isin(["BLRN","HSRB"])))
newfilterdf=df[(df["PotCCF"]==True)|(df["Wtfilter"]==True)]
 #B: Dest Filter
destlocs=['BLRN','BLRR','BLRT','BLRB','BLRC'] #excluded "PNQK","PNQC","PNQW","PHRB" & BLRF
newfilterdf=newfilterdf[newfilterdf["DEST BRCD"].isin(destlocs)].sort_values("ACTUWT",ascending=False)
 #C. STD Cons
dff=newfilterdf[newfilterdf["DEL LOCATION TYPE"]=='STD']


# In[7]:

#D. Filtering out DEPS ets status codes
ccfstatcodes=['AFS', 'AND', 'APN', 'APT', 'CCD', 'CDA', 'CNC', 'CPN', 'DCN', 'DIP', 'DNR', 'DRA', 'DRB', 'DRJ', 'DRR', 'FNR', 'HIM', 'HIP', 'HMP', 'HOC', 'HPE', 'HWC', 'NRP', 'NSL', 'PSC', 'PSO', 'PSP', 'PSR', 'PSS', 'RDH', 'RNA', 'RNX', 'RRA', 'RRC', 'RRF', 'RRG', 'RRL', 'RRO', 'RRP', 'RRT', 'SDR', 'SHD', 'SPS', 'SRA', 'SRH', 'SRJ', 'SRR', 'SSC', 'VNR', 'WIA', 'WIP']
ucgstatcodes=['UCG','UG1','UG2','UG3']
depsstatcodes=['DIR','EIR','PIR','SIR','SRD','SRE','SRP','SRS']
ofdstatuscode=['AOD']
addressissues=['CDA','WIA','CNC','CPN']
dff=dff[~(dff["Con Status Code"].isin(ucgstatcodes))&~(dff["Con Status Code"].isin(depsstatcodes))&~(dff["CON BLOCKED FOR ODA PIN ISSUES"]=='YES')&~(dff["CON BLOCKED FOR PAY ISSUES"]=='YES')&~(dff["CON BLOCKED FOR DEMURRAGE"]=='YES')&~(dff["CSGNCD"]==119721)]


# ## KNAPSACK

# In[8]:

#3. Solver creation
solver = pywrapknapsack_solver.KnapsackSolver(pywrapknapsack_solver.KnapsackSolver.KNAPSACK_MULTIDIMENSION_BRANCH_AND_BOUND_SOLVER,'Multi-dimensional solver')
def vconfig(pdseries,conseries,capacity=[5200,5200,2200,2200,2200,2200,750,750],stops=[4,4,4,4,4,4,5,5]):
    conwtdict=dict(zip(conseries,pdseries))
    conlist=conwtdict.keys()
    pdlist=[conwtdict.get(i) for i in conlist] #to maintain order of weights
    
    weights = [pdlist,[1 for i in range(0,len(pdlist))]] #constraint 1 (wt) and constraint 2 (stops complexity)
    values=weights[0] #3e. so that a higher weight is selected 
    
    counter=0
    outputdf = pd.DataFrame(columns=['Veh Payload','Cons','Wts'], index=[])
    
    for cap in capacity:
        caplist=[cap,stops[capacity.index(cap)]] 
        solver.Init(values, weights, caplist)
        output=solver.Solve() ##3g. solved
        cap1check=(output*100.0/caplist[0])>75.0
        if cap1check==True:
            counter=counter+1 #3i. add to list of vehicles
            packed_items=[x for x in range(0, len(weights[0])) if solver.BestSolutionContains(x)] #3j index of packed items
            output_items=[weights[0][i] for i in packed_items] #3k: weights of packed items
            conbins=[conlist[i] for i in packed_items] #3l: con nos. added
            conlist=list(set(conlist)-set(conbins)) #3m. hope that the order is same as pdlist #pls check
            pdlist=[conwtdict.get(i) for i in conlist]
            weights = [pdlist,[1 for i in range(0,len(pdlist))]]
            values=weights[0]
            outputdf.loc[counter] = pd.Series({'Veh Payload':caplist[0],'Cons':conbins,'Wts':output_items})
    return outputdf


# In[9]:

#4. Applying the Optimizer
sdfsum=dff.pivot_table(index=["DEST BRCD"],aggfunc={"ACTUWT":lambda x: tuple(x),"DOCKNO":lambda x: tuple(x)}).reset_index()
order=["BLRN","BLRR","BLRT","BLRC","BLRB"]
for sc in order:
    exec(str(sc).lower()+'df'+"=vconfig(sdfsum[sdfsum['DEST BRCD']==sc]['ACTUWT'].values[0],sdfsum[sdfsum['DEST BRCD']==sc]['DOCKNO'].values[0])")
    exec(str(sc).lower()+'df["Util"]='+str(sc).lower()+'df["Wts"].map(lambda x: np.sum(x))*100.0/'+str(sc).lower()+'df["Veh Payload"]')
    exec(str(sc).lower()+'df["SC"]="'+str(sc)+'"')


# In[10]:

#4B. Adding Pincode list & attachment
masterdf=pd.DataFrame()
for sc in order:
    exec("masterdf=masterdf.append("+str(sc).lower()+"df)")
import collections
def flatten(l):
    for el in l:
        if isinstance(el, collections.Iterable) and not isinstance(el, basestring):
            for sub in flatten(el):
                yield sub
        else:
            yield el
ddcons=[i for i in flatten(masterdf["Cons"].values)]
ddconsdf=dff[dff["DOCKNO"].isin(ddcons)]
ddconsdf=ddconsdf.drop(["DEST BA LOC","DEST BRNM","DEST AREA","DEST REGION","REPORTDATE MIN ARRVDT","CUSTOMER REGION","ORG BRNM","ORG AREA","ORG REGION","DRS PREP TIME","DRS UPTO 12PM","DRS BW 12PM 2PM","ANDR DRS UPTO 12PM","ANDR DRS BW 12PM 2PM","IS AVAIL IN OPENING STOCK","LATEST CON REC COMM AVAIL","LATEST CON REC COMM","LATEST CON REC BRANCH","LATEST CON REC COMM ON","RPT TIME MINS LATEST CON REC COMM ON","Log Date","Free Storage Days","DEFAULTHUB"],axis=1)
pindict=ddconsdf.loc[:,["DOCKNO","DEST PINCODE"]].set_index("DOCKNO")["DEST PINCODE"].to_dict()
masterdf["Pincodes"]=masterdf["Cons"].map(lambda x: [pindict.get(i) for i in x])


# In[11]:

#5. Implementing VRP
import simplejson
import urllib
hubpindict={'AMCH': 134007, 'AMDH': 382210, 'BBIH': 752101, 'BDQH': 391740, 'BGMH': 590017, 'BHOH': 462021, 'BLRH': 562123, 'BOMH': 421302, 'BRGH': 832101, 'CCUH': 711114, 'CJBH': 641062, 'DELH': 123401, 'GZBH': 201003, 'HYDH': 501401, 'IDRH': 452010, 'JAIH': 302024, 'JBLH': 482002, 'KNPH': 208014, 'LKOH': 226012, 'MAAH': 600124, 'NAGH': 440023, 'PATH': 800007, 'PGTH': 678623, 'PNQH': 410501, 'RPRH': 492099, 'SMBH': 768006, 'SNRH': 422103, 'SXVF': 636010, 'VPIH': 396105, 'VZAH': 520012}
if datetime.utcnow().hour<5:
    departtime=int((datetime.utcnow().replace(hour=5) - datetime(1970, 1, 1)).total_seconds())
else:
    departtime=int((datetime.utcnow().replace(hour=5)+timedelta(days=1) - datetime(1970, 1, 1)).total_seconds())

def stopoptimizer(sc,listofpins):
    scpin=hubpindict.get(sc)
    waypoints=('|').join([str(i) for i in listofpins])   
    url="https://maps.googleapis.com/maps/api/directions/json?origin={0}&destination={1}&waypoints=optimize:true|{2}&mode=driving&language=en-EN&sensor=false&departure_time={3}&key=AIzaSyD_sv9kerFNsijx98r1p_0mzPHVcf8vVF0".format(scpin,scpin,waypoints,departtime) #&key=YOUR_API_KEY
    result= simplejson.load(urllib.urlopen(url))
    try:
        waypoint_order = result["routes"][0]['waypoint_order']
    except:
        waypoint_order=[0,1,2,3]#str(result)
    
    try:
        km=0
        for i in range(0,len(listofpins)+1):
            km=km+float(result['routes'][0]['legs'][i]['distance']['text'].split(' ')[0])
    except:
        km=0
        
    try:
        timelist=[]
        for i in range(0,len(listofpins)+1):
            timelist=timelist+[result['routes'][0]['legs'][i]['duration']['value']]
    except:
        timelist=[1,1,1,1]
    return [waypoint_order,km,timelist]


# In[12]:

masterdf["Optimizer"]=masterdf.apply(lambda x: stopoptimizer("BLRH",x["Pincodes"]),axis=1)


# In[13]:

masterdf["Optimal_Route"]=masterdf.apply(lambda x: x["Optimizer"][0],axis=1)
masterdf["Kms"]=masterdf.apply(lambda x: x["Optimizer"][1],axis=1)
masterdf["Timeslots"]=masterdf.apply(lambda x: x["Optimizer"][2],axis=1)
masterdf["Cons"]=masterdf.apply(lambda x: [x["Cons"][i] for i in x["Optimal_Route"]],axis=1) # if x["Optimal_Route"]!=['error'] else
masterdf["Wts"]=masterdf.apply(lambda x: [x["Wts"][i] for i in x["Optimal_Route"]],axis=1)
masterdf["Pincodes"]=masterdf.apply(lambda x: [x["Pincodes"][i] for i in x["Optimal_Route"]],axis=1)


# In[14]:

def timeconversion(timeslots):
    starttime=datetime.now().replace(hour=9,minute=0)
    retlist=[datetime.strftime(starttime,"%H:%M")]
    timeperstop=60*90
    for i in timeslots:
        endtime=starttime+timedelta(seconds=i)
        if i!=timeslots[-1]:
            freetime=endtime+timedelta(seconds=timeperstop)
            retlist=retlist+[(datetime.strftime(endtime,"%H:%M"),datetime.strftime(freetime,"%H:%M"))]
        else:
            freetime=endtime
            retlist=retlist+[datetime.strftime(endtime,"%H:%M")]
        starttime=freetime
    return retlist


# In[15]:

masterdf["Timeslots"]=masterdf.apply(lambda x: timeconversion(x["Timeslots"]),axis=1)


# In[16]:

for sc in order:
    exec(str(sc).lower()+'df=masterdf[masterdf["SC"]=="'+str(sc)+'"].loc[:,["Veh Payload","Cons","Wts","Pincodes","Util","Kms","Timeslots"]]')


# In[17]:

#masterdf.head()
masterdf['Vehicle_Rnd'] = np.random.randint(2000,10000, size=len(masterdf))


# In[18]:

sqlsf = gl.SFrame(data=masterdf)
sqlsf = sqlsf.select_columns(['Vehicle_Rnd', 'Cons'])


# In[19]:

sqlsf.head()


# In[20]:

sqlsf = sqlsf.stack('Cons', new_column_name='DOCKNO')


# In[21]:

sqldf=sqlsf.to_dataframe()
sqldf["DOCKNO"]=sqldf["DOCKNO"].astype(float).astype(int)


# In[22]:

# sqldf=masterdf.loc[:,["Cons","Vehicle_Rnd"]]
# sqldf=sqldf['Cons'].apply(pd.Series).stack().reset_index(level=1, drop=True).to_frame('Cons').join(sqldf[['Vehicle_Rnd']], how='left')
# sqldf["Cons"]=sqldf["Cons"].astype(int)
# sqldf=sqldf.drop_duplicates("Cons")


# In[23]:

sqldf.to_csv(r'D:\Python\Scripts and Files\Path and Graph Files\sqldf.csv')


# In[24]:

masterdf.to_csv(r'D:\Python\Scripts and Files\Path and Graph Files\masterdf.csv')



import pandas.io.sql
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta


# In[ ]:

# server = '10.109.230.13'
# database = 'ESTL_CRP2'
# username = 'sa'
# password = 'password@123'
#conn = pyodbc.connect('DRIVER={ODBC Driver 13 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
cnxn.autocommit = True
cursor = cnxn.cursor()

vehrandomlist = masterdf['Vehicle_Rnd'].tolist()

for u in range (0,len(vehrandomlist)):

    payld = masterdf.iloc[u]['Veh Payload']

    con = masterdf.iloc[u]['Cons']
    con = str(con)

    wt = masterdf.iloc[u]['Wts']
    wt = str(wt)

    util= masterdf.iloc[u]['Util']

    sc = masterdf.iloc[u]['SC']

    pincodes  = masterdf.iloc[u]['Pincodes']
    pincodes = str(pincodes)

    optimizer  = masterdf.iloc[u]['Optimizer']
    optimizer = str(optimizer)

    optroute  = masterdf.iloc[u]['Optimal_Route']
    optroute = str(optroute)

    kms  = masterdf.iloc[u]['Kms']

    timeslot  = masterdf.iloc[u]['Timeslots']

    timeslot = str(timeslot)
    vehrandom  = masterdf.iloc[u]['Vehicle_Rnd']
    
    
    cursor.execute("""
    INSERT INTO  TblDirectDelivery_Data (VehiclePayload, cons, weights, Utilisation, Brcd, Pincodes, Optimizer, OptimalRoute, Kms, TimeSlots, vehicleNo) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """,(payld, con, wt, util, sc, pincodes, optimizer, optroute, kms, timeslot, vehrandom))
    


conlist = sqldf['DOCKNO'].tolist()

for u in range (0,len(conlist)):
    connumber = sqldf.iloc[u]['DOCKNO']
    connumber =str(connumber)
    vehrandom = sqldf.iloc[u]['Vehicle_Rnd']
    vehrandom = str(vehrandom)

    cursor.execute("""
    INSERT INTO TblDirectDelivery_Conwise (ConNo, VehicleNo) values (?, ?)
    """,(connumber, vehrandom))



