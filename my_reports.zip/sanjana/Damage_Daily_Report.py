
# coding: utf-8

# In[1]:


import pandas as pd
import pyodbc
from datetime import datetime,timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
import smtplib
import ftplib
import traceback
import calendar
import os
import pyodbc
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import Utilities

# In[2]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")


# In[3]:


startdate=datetime.strftime(datetime.now()-timedelta(days=1),"%Y-%m-%d")
startdate


# In[4]:


query=("USP_DEPS_DATA_TO_SQ_DAMAGE '{0}' , '{1}'").format(startdate,startdate)
query


# In[5]:


df=pd.read_sql(query,Utilities.cnxn)


# In[6]:


len(df)


# In[12]:


final_summary=df.pivot_table(index=['BRTYPE'],values=['DOCKNO','DEPSPcs','PKGSNO'],aggfunc={'DOCKNO':len,'DEPSPcs':sum,'PKGSNO':sum},margins=True,margins_name='Total').reset_index()


# In[13]:


final_summary['Damage(%)']=pd.np.round(final_summary['DEPSPcs']*100.0/final_summary['PKGSNO'],0)


# In[14]:


final_summary.rename(columns={'DOCKNO':'Cons','PKGSNO':'Total_Pkgs','DEPSPcs':'Damage_Pcs'},inplace=True)


# In[15]:


final_summary=final_summary[['BRTYPE','Cons','Total_Pkgs','Damage_Pcs','Damage(%)']]


# In[16]:


final_summary


# In[17]:


hubtohub=df[df['BRTYPE']=='HUB - HUB']
len(hubtohub)


# In[18]:


hubtohub_summary=hubtohub.pivot_table(index=['COMING_FROM'],values=['DOCKNO','DEPSPcs','PKGSNO'],aggfunc={'DOCKNO':len,'PKGSNO':sum,'DEPSPcs':sum},margins=True,margins_name='Total').reset_index().sort_values('DOCKNO',ascending=False)


# In[19]:


hubtohub_summary.rename(columns={'DOCKNO':'Cons','PKGSNO':'Total_Pkgs','DEPSPcs':'Damage_Pcs'},inplace=True)


# In[20]:


hubtohub_summary=hubtohub_summary[['COMING_FROM','Cons','Total_Pkgs','Damage_Pcs']]


# In[ ]:


##SC-HUB


# In[21]:


sctohub=df[df['BRTYPE']=='SC - HUB']
len(sctohub)


# In[22]:


sctohub_summary=sctohub.pivot_table(index=['COMING_FROM'],values=['DOCKNO','DEPSPcs','PKGSNO'],aggfunc={'DOCKNO':len,'PKGSNO':sum,'DEPSPcs':sum},margins=True,margins_name='Total').reset_index().sort_values('DOCKNO',ascending=False)


# In[23]:


sctohub_summary.rename(columns={'DOCKNO':'Cons','PKGSNO':'Total_Pkgs','DEPSPcs':'Damage_Pcs'},inplace=True)


# In[24]:


sctohub_summary=sctohub_summary[['COMING_FROM','Cons','Total_Pkgs','Damage_Pcs']]


# In[ ]:


## HUB-SC


# In[25]:


hubtosc=df[df['BRTYPE']=='HUB - SC']
len(hubtosc)


# In[26]:


hubtosc_summary=hubtosc.pivot_table(index=['COMING_FROM'],values=['DOCKNO','DEPSPcs','PKGSNO'],aggfunc={'DOCKNO':len,'PKGSNO':sum,'DEPSPcs':sum},margins=True,margins_name='Total').reset_index().sort_values('DOCKNO',ascending=False)


# In[27]:


hubtosc_summary.rename(columns={'DOCKNO':'Cons','PKGSNO':'Total_Pkgs','DEPSPcs':'Damage_Pcs'},inplace=True)


# In[28]:


# hubtosc_summary=hubtosc_summary[['COMING_FROM','DOCKNO','DEPSPcs','PKGSNO']]
hubtosc_summary=hubtosc_summary[['COMING_FROM','Cons','Total_Pkgs','Damage_Pcs']]


# In[ ]:


## SC-SC


# In[29]:


sctosc=df[df['BRTYPE']=='SC - SC']
len(sctosc)


# In[30]:


sctosc_summary=sctosc.pivot_table(index=['COMING_FROM'],values=['DOCKNO','DEPSPcs','PKGSNO'],aggfunc={'DOCKNO':len,'PKGSNO':sum,'DEPSPcs':sum},margins=True,margins_name='Total').reset_index().sort_values('DOCKNO',ascending=False)


# In[31]:


sctosc_summary.rename(columns={'DOCKNO':'Cons','PKGSNO':'Total_Pkgs','DEPSPcs':'Damage_Pcs'},inplace=True)


# In[32]:


# sctosc_summary=sctosc_summary[['COMING_FROM','DOCKNO','DEPSPcs','PKGSNO']]
sctosc_summary=sctosc_summary[['COMING_FROM','Cons','Total_Pkgs','Damage_Pcs']]


# In[33]:


date1=datetime.strftime(datetime.now()-timedelta(days=1),"%Y-%m-%d %H")


# In[34]:


df.to_csv(r'D:\Data\Damage_Hourly_Report\Damage_Daily'+str(date1)+'.csv')


# In[35]:


filepath=r'D:\Data\Damage_Hourly_Report\Damage_Daily'+str(date1)+'.csv'


# In[36]:


dt=datetime.strftime(datetime.now()-timedelta(days=1),"%Y-%m-%d %H")


# In[37]:

TO=['Nitin.gaikwad@spoton.co.in','Vivek.kharat@spoton.co.in','Kiran.kannan@spoton.co.in','Pandurang.patil@spoton.co.in','avnish.tripathi@spoton.co.in','anoop.kumar@spoton.co.in','virendra.singh@spoton.co.in','plt.vigilance_sw@spoton.co.in','plt.vigilance_ne@spoton.co.in','vinay.soam@spoton.co.in','HUBMGR_SPOT@spoton.co.in','AOM_SPOT@spoton.co.in','DOM_SPOT@spoton.co.in','ROM_SPOT@spoton.co.in','scincharge_spot@spoton.co.in','RIM_Spot@spoton.co.in','mangesh.gaikwad@spoton.co.in','Maruti.nandan@spoton.co.in','nitin.gaikwad@spoton.co.in','sb.pawar@spoton.co.in','amit.sharma@spoton.co.ins','purna.panda@spoton.co.in','Atul.Khare@spoton.co.in','ugresh.kanth@spoton.co.in','ashok.sahu@spoton.co.in','rakesh.sonawane@spoton.co.in','naresh.yemujala@spoton.co.in','sanjeet.kumar@spoton.co.in','ramakrishna.v@spoton.co.in','rajkumar@spoton.co.in','sb.pawar@spoton.co.in','chethan.h@spoton.co.in','yogesh.singh@spoton.co.in','samarjeet.dubey@spoton.co.in','dinesh.s@spoton.co.in','rajesh.mishra@spoton.co.in','chidananda.biswal@spoton.co.in']
CC=['abhik.mitra@spoton.co.in','rajesh.kapase@spoton.co.in','shivananda.p@spoton.co.in','pawan.sharma@spoton.co.in','jothi.menon@spoton.co.in','rajesh.kumar@spoton.co.in','alok.b@spoton.co.in','sharanagouda.biradar@spoton.co.in','satya.pal@spoton.co.in','shivananda.p@spoton.co.in','mahesh.reddy@spoton.co.in','saptarshi.pathak@spoton.co.in','anitha.thyagarajan@spoton.co.in','sanjana.narayana@spoton.co.in']
    

# TO=['mahesh.reddy@spoton.co.in']
# CC=['mahesh.reddy@spoton.co.in']
# BCC=['mahesh.reddy@spoton.co.in']


FROM='reports.ie@spoton.co.in'
msg = MIMEMultipart()
msg["From"] = FROM
msg["TO"] = ",".join(TO)
msg["CC"] = ",".join(CC)

msg["Subject"] = "Damges Daily Exception Report " + str(dt)

report=""
report+='Dear All,'

report+='<br>'
report+='<br>'
report+='PFA Damges Exception'
report+='<br>'
report+='<br>'
report+='NOTE: Date Range between '+str(startdate)+' 00:00:00'+' - '+str(startdate)+' 23:59:00'
report+='<br>'
report+='<br>'
report+='Total Damge Summary'
report+='<br>'
report+='<br>'
report+='<br>'+final_summary.to_html()+'<br>'

report+='HUB-HUB Damages Summary'
report+='<br>'
report+='<br>'
report+='<br>'+hubtohub_summary.to_html()+'<br>'
report+='HUB-SC Damages Summary'
report+='<br>'
report+='<br>'
report+='<br>'+hubtosc_summary.to_html()+'<br>'
report+='SC-HUB Damages Summary'
report+='<br>'
report+='<br>'
report+='<br>'+sctohub_summary.to_html()+'<br>'
report+='SC-SC Damages Summary'
report+='<br>'
report+='<br>'
report+='<br>'+sctosc_summary.to_html()+'<br>'

abc=MIMEText(report,'html')
msg.attach(abc)
part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part1)



#msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, CC+TO, msg.as_string())
server.quit()


