# -*- coding: utf-8 -*-
"""
Created on Fri Oct 13 18:18:11 2017

@author: rajeeshv
"""


# coding: utf-8

# In[1]:

import pandas as pd
from datetime import datetime, date, timedelta

import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
import os
import gzip

#opfilevarhours =datetime.now() - timedelta(hours=24)
opfilevarhours =datetime.now()
#yesterday = datetime.datetime.today() - datetime.timedelta (days=1) 
new_period=opfilevarhours.replace(hour=12, minute=0).strftime ('%Y-%m-%d %H:%M:%S')
new_period = datetime.strptime(new_period,'%Y-%m-%d %H:%M:%S')
todaymin = opfilevarhours.replace(hour=00, minute=0).strftime ('%Y-%m-%d %H:%M:%S')
todaymin = datetime.strptime(todaymin,'%Y-%m-%d %H:%M:%S')
new_period_constat = opfilevarhours.replace(hour=10, minute=0).strftime ('%Y-%m-%d %H:%M:%S')
new_period_constat = datetime.strptime(new_period_constat,'%Y-%m-%d %H:%M:%S')

# In[2]:

closingstockdata = pd.read_excel('http://spoton.co.in/downloads/OCID_CLOSINGSTOCK_1HR/OCID_CLOSINGSTOCK_1HR.xls','IEP_Closing_Stock_1HR')

timestamp = closingstockdata['Timestate Date'].values[0]
# In[ ]:

statuscodefile = pd.read_csv('D:\Python\Scripts and Files\Path and Graph Files\Status_codes_exclude.csv')
statusexcludelist = statuscodefile['Con Status Code'].tolist()


#def freecons(freeconnew):
#    if freeconnew!='NO':
#        return 1
#    else:
#        return 0
#
#def arrvtime(arrvdate):
#    if arrvdate<new_period:
#        return 1
#    else:
#        return 0
#        
#def statcode(constatuscod):
#    if constatuscod in statusexcludelist:
#        return 1
#    else:
#        return 0
#
#def statcodedt(constatuscoddt):
#    if constatuscoddt>new_period_constat:
#        return 1
#    else:
#        return 0
#        
#def drsprep(drs):
#    if drs=='YES':
#        return 1
#    else:
#        return 0
#        
#def drsblock(blockpayiss):
#    if blockpayiss=='NO':
#        return 1
#    else:
#        return 0
#
#def freeconlogic(freeconnew,arrvdate,constatuscod,constatuscoddt,conblpayissues):
#    if freeconnew==1 & arrvdate==1 & constatuscod==0 & constatuscoddt==0 & conblpayissues==1:
#        return 1
#    else:
#        return 0
#
#
#
#closingstockdata['Freeconcheck'] = closingstockdata.apply(lambda x:freecons(x['IS FREE CON NEW']),axis=1)
#closingstockdata['ArrvBef12'] = closingstockdata.apply(lambda x:arrvtime(x['ARRV AT DEST SC']),axis=1)
#closingstockdata['Statusexclude'] = closingstockdata.apply(lambda x:statcode(x['Con Status Code']),axis=1)
#closingstockdata['Constatuscheck'] = closingstockdata.apply(lambda x:statcodedt(x['Con Status Date']),axis=1)
#closingstockdata['DRS_Prep'] = closingstockdata.apply(lambda x:drsprep(x['DRS PREPARED']),axis=1)
#closingstockdata['DRS_Blocked_pay_issues'] = closingstockdata.apply(lambda x:drsblock(x['CON BLOCKED FOR PAY ISSUES']),axis=1)
#
#closingstockdata['Free_Con_Final'] = closingstockdata.apply(lambda x:freeconlogic(x['Freeconcheck'],x['ArrvBef12'],x['Statusexclude'],x['Constatuscheck'],x['DRS_Blocked_pay_issues']),axis=1)
#
#closingstockdata = closingstockdata.drop(['LATEST CON REC COMM','Customer Name','Con Status Reason','CSGNNM','CSGENM','Delivery Add1','Delivery Add2','Delivery Add3','PARENTNAME','TTS Audit Remarks'], axis=1)
#closingstockdata.to_csv(r'closingstockdata.csv')
#
#closingstocktotalgrp = closingstockdata.groupby(['DEST AREA']).agg({'DOCKNO':len,'Free_Con_Final':sum,'DRS_Prep':sum}).reset_index()
#closingstocktotalgrp.to_excel(r'closingstocktotalgrp.xls')
#
#
#
#avajfiaf

filtereddf = closingstockdata[(closingstockdata['DRS PREPARED']=='NO') & (closingstockdata['IS FREE CON NEW']!='NO')]


def arrivtodyoryest(arrvdt):
    if arrvdt>todaymin:
        return 1
    else:
        return 0
        
filtereddf['Arrv_Today_Yest'] = filtereddf.apply(lambda x: arrivtodyoryest(x['ARRV AT DEST SC']),axis=1)
print filtereddf['Arrv_Today_Yest'].sum()
# In[ ]:

len(filtereddf)


# In[ ]:

freecondf = filtereddf[~(filtereddf['Con Status Code'].isin(statusexcludelist))]


freecondf = freecondf[(freecondf['ARRV AT DEST SC']<new_period)]


# In[ ]:

stdfreecondf = freecondf[(freecondf['DEL LOCATION TYPE']=='ODA') & (freecondf['CON BLOCKED FOR PAY ISSUES']=='NO') & (freecondf['REPORTDATE MIN ARRVDT']>48)]


statusupdaft10df = stdfreecondf[(stdfreecondf['Con Status Date']>new_period_constat)]
consstatusupdaft10df = statusupdaft10df['DOCKNO'].tolist()
#print consstatusupdaft10df


## Excluding cons where status update has been done after 10:00 AM
stdfreecondf = stdfreecondf[~(stdfreecondf['DOCKNO'].isin(consstatusupdaft10df))]
# In[ ]:

stdfreecondf = stdfreecondf.drop(['LATEST CON REC COMM','Customer Name','Con Status Reason','CSGNNM','CSGENM','Delivery Add1','Delivery Add2','Delivery Add3','PARENTNAME','TTS Audit Remarks'], axis=1)
totalstdfreeconsnotofd = len(stdfreecondf)
print totalstdfreeconsnotofd

# In[ ]:

#stdfreecondf.to_excel('stdfreecondf.xls')


# In[ ]:

stdfreegrp = stdfreecondf.groupby(['DEST AREA']).agg({'DOCKNO':len,'Arrv_Today_Yest':sum}).reset_index().sort_values('DOCKNO',ascending=False)

stdfreegrp['Old_free_cons'] = stdfreegrp.apply(lambda x:(x['DOCKNO']-x['Arrv_Today_Yest']),axis=1)
stdfreegrp.rename(columns={'DEST AREA':'Area','DOCKNO':'NotOFD','Arrv_Today_Yest':'ArrToday','Old_free_cons':'ArrTillYest'},inplace=True)
# In[ ]:

stdgrptop = stdfreegrp.head(10)
stdgrptop = stdgrptop.to_string(index=False)


# In[ ]:
opfilevar=opfilevarhours.date()
opfilevar1=opfilevarhours.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=pd.np.round((float(currhrs)/60),0)


#stdfreecondf.to_excel(r'D:\Data\Free_cons_CS1HR\Free_cons_not_OFD.xls')


stdfreecondf.to_csv(r'D:\Data\Free_cons_CS1HR\ODA\Data\Free_cons_not_OFD_'+str(opfilevar)+str('-')+str(opfilevar2)+'.csv')
stdfreecondf.to_csv(r'D:\Data\Free_cons_CS1HR\ODA\Free_cons_not_OFD_ODA.csv')

# In[ ]:

with open("D:\Data\Free_cons_CS1HR\ODA\Free_cons_not_OFD_ODA.csv", "rb") as file_in:
    # Open output file.
    with gzip.open(r"D:\Data\Free_cons_CS1HR\ODA\Free_cons_not_OFD_ODA.csv.gz", "wb") as file_out:
        # Write output.
        file_out.writelines(file_in)

oppath1 = r"D:\Data\Free_cons_CS1HR\ODA\Free_cons_not_OFD_ODA.csv.gz"


stdfreegrp['Timestamp'] = stdfreegrp.apply(lambda x: timestamp,axis=1)
stdfreegrp.to_csv(r'D:\Data\Free_cons_CS1HR\ODA\Summary\Free_cons_not_OFD_Summary_ODA'+str(opfilevar)+str('-')+str(opfilevar2)+'.csv')
# In[ ]:
filePath = oppath1
def sendEmail(#TO = ["Nikhil.Saxena@Spoton.Co.In"],
             TO = ["vishwas.j@spoton.co.in"],
             #BCC =  ["vishwas.j@spoton.co.in","shivananda.p@spoton.co.in"],
             #CC =  ["Abhik.Mitra@Spoton.Co.In","Ankit@iepfunds.com","supratim@iepfunds.com","Krishna.Chandrasekar@Spoton.Co.In","Pawan.Sharma@Spoton.Co.In","vishwas.j@spoton.co.in","shivananda.p@spoton.co.in","rajesh.kumar@spoton.co.in"],
             CC =  ["vishwas.j@spoton.co.in"],
             BCC =  ["vishwas.j@spoton.co.in"],
            #FROM="mis.ho@spoton.co.in"):
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
    #HOST = "smpt.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DEPOTWISE OPS Bucket Stock  - "+ str(datefilter)
    msg["Subject"] = "ODA Free cons not OFD - "+ str(opfilevar)+str('-')+str(opfilevar2)
    body_text = """
    Dear All,
    
    Total ODA Free cons not OFD = """+str(totalstdfreeconsnotofd)+"""    
    
    PFB the Area-wise summary of the freecons not OFD as of """+str(opfilevar)+str('-')+str(opfilevar2)+"""
    
    Teh columns are explained below:
    
    NotOFD column shows the total cons which are free but not OFD (STD)
    The columns ArrToday and ArrTillYest gives the breakup of NotOFD column
    ArrToday - Cons that are free and not OFD, which arrived today
    ArrTillYest - Cons that are free and not OFD, which arrived prior today
    
    """+str(stdgrptop)+"""

    
    Note: The report currently considers only STD cons and cons arrived before 12:00 Hrs
    The attachment has the conwise details and their current statuses
 
    """
    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
#print('Email sent')


# In[ ]:



