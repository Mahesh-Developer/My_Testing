
# coding: utf-8

# In[2]:
import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta,datetime
# import 
import sys
import Utilities
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.MIMEBase import MIMEBase
from email import Encoders
import os

reload(sys).setdefaultencoding("ISO-8859-1")

# In[ ]:


# cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")


# # In[ ]:


# cursor=cnxn.cursor()
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()

# In[ ]:

try:
    query =(""" USP_UNDELIVERED_CONS_GRT_1DAY """ )


    # In[ ]:


    data=pd.read_sql(query,Utilities.cnxn)


    # In[ ]:


    print (len(data))



    # In[ ]:


    query1=(""" SELECT  A.*, CASE WHEN ( CON_BLOCKED_FOR_PAY_ISSUES = 'YES' ) THEN 'A3_PAYMENT_ISSUE'  
                 WHEN ( ConStatusCode IN( 'SSC','SHS' )) THEN 'A4_Seized by Sales Tax'  
                 WHEN ( ConStatusCode IN ('UCG','UG1','UG2','UG3' )) THEN '8_UCG'  
                 WHEN (CON_BLOCKED_FOR_DEMURRAGE = 'YES' AND DEMURRAGE_RESPONSIBILITY = 'CS') THEN '2_CS Dem_Pin Drs Block'--'CS Dem Drs Block'  
                 WHEN (CON_BLOCKED_FOR_DEMURRAGE = 'YES' AND DEMURRAGE_RESPONSIBILITY = 'OPS' AND LatestTicketStatus != 'Open') THEN '5_OPS Dem Drs Block'  
                 WHEN (CON_BLOCKED_FOR_ODA_PIN_ISSUES =  'YES') THEN '2_CS Dem_Pin Drs Block' --'CS PIN DRS BLOCK'  
                 WHEN (REPORTDATE_MIN_ARRVDT > 1440 ) THEN 'A1_DEAD STOCK'  
                 WHEN (IsTTSTicketRaised = 'YES' AND LatestTicketStatus = 'CLOSED' AND LatestTicketStatusCode = ConStatusCode AND REPORTDATE_MIN_ARRVDT >= 40) THEN '3_OPS/Free Con Bucket-Old'  
                 WHEN (IsTTSTicketRaised = 'YES' AND LatestTicketStatus = 'CLOSED' AND LatestTicketStatusCode = ConStatusCode AND REPORTDATE_MIN_ARRVDT < 40) THEN '4_OPS/Free Con Bucket-NEW'  
                 WHEN (IS_FREE_CON_NEW = 'YES' AND REPORTDATE_MIN_ARRVDT >= 40) THEN '3_OPS/Free Con Bucket-Old'  
                 WHEN (IS_FREE_CON_NEW = 'YES' AND REPORTDATE_MIN_ARRVDT < 40) THEN '4_OPS/Free Con Bucket-New'  
                 WHEN (IsTTSTicketRaised = 'YES' AND LatestTicketStatus = 'OPEN') THEN '1_CS Bucket'  
                 WHEN (ConStatusCategory = 'DEPS' AND REPORTDATE_MIN_ARRVDT > 168 ) THEN '9_DEPS-SQ'  
                 WHEN (ConStatusCategory = 'DEPS' AND REPORTDATE_MIN_ARRVDT <= 168 ) THEN '6_DEPS-OPS'  
                 WHEN (ConStatusCategory IN ( 'RECEIVER FAILURE','SENDER FAILURE') )THEN 'A2_CCF without Tickets'   
                 ELSE '7_Others/Timelag'             
            END STATUS1   
    FROM    dbo.tblOCIDClosingStock A  
    WHERE   LogDate >= CONVERT(DATE,GETDATE()-0)  
    """)


    # In[ ]:


    data1=pd.read_sql(query1,Utilities.cnxn)
    print (len(data1))
    rawdata=data1
    # In[ ]:


    len(data1)


    # In[ ]:


    data1 = data1[data1['STATUS1'].isin(['2_CS Dem_Pin Drs Block','5_OPS Dem Drs Block','A3_PAYMENT_ISSUE','A4_Seized by Sales Tax'])]

    # In[ ]:


    data['new']=data['DOCKNO'].isin(data1['DOCKNO']).astype(np.int8)


    # In[ ]:


    data=data[data['new']==0]
    len(data)

    # In[ ]:


    data['Category'].unique()


    # In[ ]:


    data['Category'] = data['Category'].replace(['OPS'], 'STF')


    # In[ ]:


    data['Category'].unique()


    # In[ ]:


    data.head()


    # In[ ]:


    pcategory=pd.pivot_table(data,index=["Category"],columns=["DELIVERY_ODA","AGEING"],values=["DOCKNO"],aggfunc={"DOCKNO":len},fill_value='0',margins=True)


    # In[ ]:


    pcategory


    # In[ ]:


    # pcategory[('DOCKNO','ODA')]=pcategory[('DOCKNO','ODA')][['1 DAYS','2 TO 3 DAYS','4 TO 7 DAYS','8 TO 15 DAYS','16 TO 30 DAYS','> 30 DAYS']]
    # pcategory[('DOCKNO','All')]=pcategory[('DOCKNO','All')]


    # In[ ]:


    pcategory1=pcategory.reindex_axis(['1 DAYS', '2 TO 3 DAYS', '4 TO 7 DAYS','8 TO 15 DAYS','16 TO 30 DAYS','> 30 DAYS'], axis=1, level='AGEING')


    # In[ ]:


    pcategory1


    # In[ ]:


    pcategory1=pcategory1.join(pcategory[('DOCKNO','All')])


    # In[ ]:


    pcategory1.columns


    # In[ ]:


    pcategory1.rename(columns={('DOCKNO', 'STD', '16 TO 30 DAYS'):'16 TO 30 DAYS(STD)',('DOCKNO', 'STD', '1 DAYS'):'1 DAY(STD)',('DOCKNO', 'STD', '2 TO 3 DAYS'):'2 TO 3 DAYS(STD)',('DOCKNO', 'STD', '4 TO 7 DAYS'):'4 TO 7 DAYS(STD)',('DOCKNO', 'STD', '8 TO 15 DAYS'):'8 TO 15 DAYS(STD)',('DOCKNO', 'STD', '> 30 DAYS'):'>30 DAYS(STD)',('DOCKNO', 'ODA', '1 DAYS'):'1 DAY(ODA)',('DOCKNO', 'ODA', '2 TO 3 DAYS'):'2 TO 3 DAYS(ODA)',('DOCKNO', 'ODA', '4 TO 7 DAYS'):'4 TO 7 DAYS(ODA)',('DOCKNO', 'ODA', '8 TO 15 DAYS'):'8 TO 15 DAYS(ODA)',('DOCKNO', 'ODA', '16 TO 30 DAYS'):'16 TO 30 DAYS(ODA)',('DOCKNO', 'ODA', '> 30 DAYS'):'>30 DAYS(ODA)',('DOCKNO', 'All'):'Total'},inplace=True)


    # In[ ]:


    pcategory1


    # In[ ]:


    pcategory1=pcategory1.sort_values(by='Total', ascending=False).astype(int)


    # In[ ]:


    pcategory1


    # In[ ]:


    stfdata=data[data['Category'].isin(['STF','NCF'])]

    print (stfdata['DESTN_AREA'].unique())
    # In[ ]:
    stfdata=stfdata[stfdata['DESTN_AREA']!='']
    print (stfdata['DESTN_AREA'].unique())
    #exit(0)
    pSTF_NCF=pd.pivot_table(stfdata,index=["DESTN_AREA","Category"],columns=["DELIVERY_ODA","AGEING"],values=["DOCKNO"],aggfunc={"DOCKNO":len},fill_value='0',margins=True)


    # In[ ]:


    pSTF_NCF


    # In[ ]:


    pSTF_NCF1=pSTF_NCF.reindex_axis(['1 DAYS', '2 TO 3 DAYS', '4 TO 7 DAYS','8 TO 15 DAYS','16 TO 30 DAYS','> 30 DAYS'], axis=1, level='AGEING')


    # In[ ]:


    pSTF_NCF1


    # In[ ]:


    pSTF_NCF1=pSTF_NCF1.join(pSTF_NCF[('DOCKNO','All')])


    # In[ ]:


    pSTF_NCF1


    # In[ ]:


    pSTF_NCF1.rename(columns={('DOCKNO', 'STD', '16 TO 30 DAYS'):'16 TO 30 DAYS(STD)',('DOCKNO', 'STD', '1 DAYS'):'1 DAY(STD)',('DOCKNO', 'STD', '2 TO 3 DAYS'):'2 TO 3 DAYS(STD)',('DOCKNO', 'STD', '4 TO 7 DAYS'):'4 TO 7 DAYS(STD)',('DOCKNO', 'STD', '8 TO 15 DAYS'):'8 TO 15 DAYS(STD)',('DOCKNO', 'STD', '> 30 DAYS'):'>30 DAYS(STD)',('DOCKNO', 'ODA', '1 DAYS'):'1 DAY(ODA)',('DOCKNO', 'ODA', '2 TO 3 DAYS'):'2 TO 3 DAYS(ODA)',('DOCKNO', 'ODA', '4 TO 7 DAYS'):'4 TO 7 DAYS(ODA)',('DOCKNO', 'ODA', '8 TO 15 DAYS'):'8 TO 15 DAYS(ODA)',('DOCKNO', 'ODA', '16 TO 30 DAYS'):'16 TO 30 DAYS(ODA)',('DOCKNO', 'ODA', '> 30 DAYS'):'>30 DAYS(ODA)',('DOCKNO', 'All'):'Total'},inplace=True)


    # In[ ]:


    pSTF_NCF1['Total']=pSTF_NCF1['Total'].astype(int)


    # In[ ]:


    pSTF_NCF1


    # In[ ]:


    wtdata = data[data['Category']=='CS']


    # In[ ]:


    wtdata = data[data['ACTUWT']>=500]


    # In[ ]:


    pWt500=pd.pivot_table(wtdata,index=["DESTN_DEPOT_CODE"],columns=["DELIVERY_ODA","AGEING"],values=["DOCKNO"],aggfunc={"DOCKNO":len},fill_value='',margins=True)


    # In[ ]:



    # In[21]:


    from pandas import ExcelWriter


    # In[22]:


    with ExcelWriter(r'D:\Data\ODA_Loads_Ton_wise\undeliverd_1day.xlsx') as writer:

           rawdata.to_excel(writer, sheet_name='Con Wise Data',engine='xlsxwriter')
           pcategory1.to_excel(writer, sheet_name='Category',engine='xlsxwriter')
           pSTF_NCF1.to_excel(writer, sheet_name='Area OPS Summary for NCF & STF',engine='xlsxwriter')
           pWt500.to_excel(writer, sheet_name='> 500 KGS',engine='xlsxwriter')


    # In[23]:


    filepath=r'D:\Data\ODA_Loads_Ton_wise\undeliverd_1day.xlsx'


    # In[24]:


    import numpy as np
    import pandas as pd
    import itertools
    import json
    from pandas import ExcelWriter
    from pandas import pivot_table
    from datetime import datetime
    import os
    import ftplib
    import traceback

    oppath1=filepath
    #FTP Upload starts
    print ('Logging in...')
    ftp = ftplib.FTP()  
    ftp.connect('10.109.230.50')  
    print (ftp.getwelcome())
    try:  
        try:  
            ftp.login('HOSQTeam', 'Te@mH0$q')
            print ('login done')
            ftp.cwd('Auto_reports')  
            #ftp.cwd('FIFO')
            # move to the desired upload directory  
            print ("Currently in:", ftp.pwd()) 
            print ('Uploading...')  
            fullname = oppath1
            name = os.path.split(fullname)[1]  
            f = open(fullname, "rb")  
            ftp.storbinary('STOR ' + name, f)  
            f.close()  
            print ("OK"  )
            print ("Files:")  
            print (ftp.retrlines('LIST'))
        finally:  
            print ("Quitting...")
            ftp.quit()  
    except:  
        traceback.print_exc()


    # In[31]:



    from_addr = 'mis.ho@spoton.co.in'
    # to_addr = ['rajesh.mp@spoton.co.in',]
    #cc_addr = ['mahesh.reddy@spoton.co.in']
    cc_addr = ['SQ_spot@spoton.co.in','sqtf@spoton.co.in','scincharge_spot@spoton.co.in','baskar.t@spoton.co.in']
    #bcc_addr = ['sreedhar.m@spoton.co.in']
    bcc_addr = ['aom_spot@spoton.co.in','dom_spot@spoton.co.in','rom_spot@spoton.co.in','scincharge_spot@spoton.co.in','vivek.kumar@spoton.co.in','awadhesh.yadav@spoton.co.in','spot_cstl@spoton.co.in','RSM_spot@spoton.co.in','mahesh.reddy@spoton.co.in']


    msg = MIMEMultipart()

    msg['From'] = from_addr
    msg['cc'] = ', '.join(cc_addr)
    msg['bcc'] = ', '.join(bcc_addr)
    msg['Subject'] = 'Undelivered Cons lying @ Destn SC > 24 Hrs'
    html='''<html>
    <h4>Dear All</h4>
    <p>Please find summary of con's Lying at Destination SC for more than 24 Hrs. Please take action to clear the same.</p>
    <p>You can filter the report based on Categories like (CS, OPS, UCG, DEPS)</p>
    </html>'''

    html3='''
    <h5> To download the cons data , Please click the link below </h5>
    <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/undeliverd_1day.xlsx"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/undeliverd_1day.xlsx</p></b>
    '''
    html1='''<h5>Thanks & Regards</h5></b>
    <h5>HO-SQ</h5>'''
        
    #  msg.attach(part10)
    report=""
    report+=html
    report+='<br>'
    report+='<h4>1.Category wise Summary</h4>'
    # report+='<br>'
    report+='<br>'+pcategory1.to_html()+'<br>'
    # report+='<br>'
    report+='<h4>2.Area ops summary for NCF & STF</h4>'
    # report+='<br>'
    report+='<br>'+pSTF_NCF1.to_html()+'<br>'
    # report+='<br>'
    report+=html3
    report+='<br>'
    report+=html1
    abc=MIMEText(report,'html')
    msg.attach(abc)
    part=MIMEBase('application','octet-stream')

    # server = smtplib.SMTP('smtp.spoton.co.in',587)
    # server.ehlo()
    # server.starttls()
    # server.ehlo()
    # server.login('mis.ho@spoton.co.in','Mis@2019')
    # server.sendmail(from_addr,cc_addr+bcc_addr,msg.as_string())
    # print ('mail sent succesfully')
    # server.quit()

    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(from_addr,cc_addr+bcc_addr, msg.as_string())
    print ('mail sent succesfully')
    server.quit()

except:

  TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in'] 
  #TO=['mahesh.reddy@spoton.co.in']
  CC=['mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "Undelivered Cons lying @ Destn SC > 24 Hrs Error in Execution" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in Undelivered Cons lying @ Destn SC > 24 Hrs'
  report+='<br>'

  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO+CC, msg.as_string())
  server.quit()


