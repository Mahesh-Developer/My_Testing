# -*- coding: utf-8 -*-
"""
Created on Mon Nov 07 12:25:27 2016

@author: rajeeshv
"""


# coding: utf-8

# In[1]:



# In[1]:

import pandas as pd
from datetime import datetime, timedelta
import glob
import numpy as np

import os
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from pandas import ExcelWriter
from email import encoders
import ftplib
import traceback
# In[2]:



#closing1yes = pd.read_csv(r'D:\Data\Combined_closing_1HR.csv')
#closing1yes = pd.io.excel.read_excel('OCID_CLOSINGSTOCK_1HR.xls','IEP_Closing_Stock_1HR')
closing1yes = pd.io.excel.read_excel('http://10.109.230.50/downloads/OCID_CLOSINGSTOCK_1HR/OCID_CLOSINGSTOCK_1HR.xls', 'IEP_Closing_Stock_1HR')
len(closing1yes)


# In[2]:

##closingMAAC = closing1yes[closing1yes['DEST BRCD']=='MAAC']
sclist = ['BLRF','CCUC','HYDO','BWDB','MAAC']
closingMAAC = closing1yes[closing1yes['DEST BRCD'].isin(sclist)]
len(closingMAAC)


# In[3]:

pmd_sep = pd.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\MAAC_Routewise_input\PMD_Sep.csv')
pmdsep1 = pmd_sep[['BRANCH_CODE2','PINCODE2','CUSTOMERCODE','CUSTOMERNAME','PUD_CODE2','PUD_NAME2','PUDTYPE2']]
pmd_aug = pd.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\MAAC_Routewise_input\PMD_Aug.csv')
pmdaug1 = pmd_aug[['BRANCH_CODE2','PINCODE2','CUSTOMERCODE','CUSTOMERNAME','PUD_CODE2','PUD_NAME2','PUDTYPE2']]
pmd_july = pd.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\MAAC_Routewise_input\PMD_July.csv')
pmdjuly1 = pmd_july[['BRANCH_CODE2','PINCODE2','CUSTOMERCODE','CUSTOMERNAME','PUD_CODE2','PUD_NAME2','PUDTYPE2']]
len(pmdsep1), len(pmdaug1), len(pmdjuly1)


# In[4]:

pmdappend = pmdsep1.append(pmdaug1)
pmd = pmdappend.append(pmdjuly1)
len(pmd)


# In[5]:

pmd0 = pmd[pmd['BRANCH_CODE2'].isin(sclist)]
pmd1 = pmd0.drop(['BRANCH_CODE2'], axis=1)
len(pmd1)


# In[6]:

pmd1['primary_key'] = pmd1.apply(lambda x:str(x['PINCODE2'])+str('-')+str(x['CUSTOMERCODE']),axis=1)


# In[7]:

#pmd1.head()
pmd_ids = pmd1.drop_duplicates(cols='primary_key')
len(pmd_ids)
pmd_pincode_ids = pmd1.drop_duplicates(cols='PINCODE2') #to be used later for the merge


# In[8]:

closingMAACpc = pd.merge(closingMAAC, pmd_ids, left_on=['DEST PINCODE','Customer Code'], right_on=['PINCODE2','CUSTOMERCODE'],how='left')
#ymerge_cust=pd.merge(yorginal_success_cust,yorginal_cancel_cust,on=['BRCD','CustCode','PartyType'],suffixes = ['Success','Cancel'],how='outer')


# In[9]:

len(closingMAACpc)


# In[10]:

ccfcategorylist = ['SENDER FAILURE','RECEIVER FAILURE','DEPS']
closingMAACpc = closingMAACpc[~closingMAACpc['Con Status Category'].isin(ccfcategorylist)]


# In[11]:

len(closingMAACpc)


# In[12]:

closingMAACpc_cols = closingMAACpc[['DOCKNO','DEST BRCD', 'DEST PINCODE','ACTUWT','PIECES','VOLUME','Customer Code','Customer Name','CSGENM','CSGNNM','Con Status Category','Con Status Code','Con Status Desc','LASTDRS PREPAREDDATE','PUD_CODE2','PUD_NAME2','PUDTYPE2','Timestate Date']]


# In[13]:

import math
def allocate(pudcode):
    if math.isnan(pudcode):
        return 'Pincode'
    else:
        return 'Cust+Pincode'
    


# In[14]:

closingMAACpc_cols['Allocation'] = closingMAACpc.apply(lambda x: allocate(x['PUD_CODE2']), axis=1)


# In[15]:

closeMAAC_CcPc = closingMAACpc_cols[closingMAACpc_cols['Allocation']=='Cust+Pincode']
closeMAAC_Pc = closingMAACpc_cols[closingMAACpc_cols['Allocation']=='Pincode']


# In[16]:

closeMAAC_Pc1 = closeMAAC_Pc.drop(['PUD_CODE2','PUD_NAME2','PUDTYPE2'], axis=1)


# In[17]:

closeMAAC_Pc_Merge = pd.merge(closeMAAC_Pc1, pmd_pincode_ids, left_on=['DEST PINCODE'], right_on=['PINCODE2'],how='left')


# In[18]:

outputdf = closeMAAC_Pc_Merge.append(closeMAAC_CcPc)
len(outputdf)


# In[19]:

outputdf = outputdf[['DOCKNO','DEST BRCD', 'DEST PINCODE','ACTUWT','PIECES','VOLUME','Customer Code','Customer Name','CSGENM','CSGNNM','Con Status Category','Con Status Code','Con Status Desc','LASTDRS PREPAREDDATE','PUD_CODE2','PUD_NAME2','PUDTYPE2','Allocation','Timestate Date']]
#outputdf.to_csv('out_btw.csv')

#for creating a decent looking df for mailbody
outputdf = outputdf.replace(['PERFECT ROAD TRANSPORT (STD ) NISSAN DLY','T.G. RAJASUBBIRAMANIAN (STD)','PERFECT ROAD TRANSPORT (STD)','T.G. RAJASUBBIRAMANIAN (FIX)','KUMAR E (STD - CAVIN KARE)','B BALAMURUGAN (STD - FIX)','NAVEEN TRANSPORT (STD )','HARISH TRANSPORT (STD)','C R RAJANNA (ODA - PANTALOON/RELIANCE)','C R RAJANNA (ODA - TUMKUR / CHITRADURGA)','SUNDER WELLINGTON (STD - PHILIPS & BEL DELIVERY)','YADNESH BHAIDAS MUKADAM (STD - 3M / PHILIPS)','SIDDALINGAIAH (ODA - PANTALOON/RELIANCE)','TRIDENT SOLUTION (STD-FDC / STAR LOGISTICS)','SANTOSH PANDURANG BHOIR (FIX - ODA)','REKHA SHUKLA (STD - PANTALOON)'],['PERFECT RT NISSAN','T.G. RAJA (STD)','PERFECT RT (STD)','T.G. RAJA (FIX)','KUMAR(STD-CAVINKARE)','B BALAMURGN(STD-FIX)','NAVEEN TRANS(STD)','HARISH TRANS(STD)','C R RAJANNA(PNTL_REL)','C R RAJANNA(TMKR_CDURGA)','SUNDER WLGTN (PHILIPS&BEL)','YADNESH MUKADAM(3M/PHILIPS)','SIDDALINGAIAH(PNTL_REL)','TRIDENT SOLN(FDC&STAR_LGST)','SANTOSH BHOIR(FIX_ODA)','REKHA SHUKLA(PNTL)'])


# In[20]:

grpby=outputdf.groupby(['DEST BRCD','PUD_NAME2']).agg({'DOCKNO': 'count','ACTUWT': 'sum'}).reset_index()


# In[21]:

grpby['wt(T)']= grpby.apply(lambda x: pd.np.round((x['ACTUWT']/1000),1),axis=1)
grpby = grpby.drop(['ACTUWT'], axis=1)


# In[22]:

grpby = grpby.sort_values(['wt(T)'], ascending=False)
grpby = grpby[grpby['PUD_NAME2']!='MARKET']
grpby = grpby[grpby['PUD_NAME2']!='COUNTER']


# In[23]:

grpby


# In[24]:

#outputdf['Timestate Date'].values[100]


# In[25]:

ts = outputdf['Timestate Date'].values[0]


# In[26]:

def datestring1(x):
    try:
        fulldate1 = datetime.strptime(x,'%Y-%m-%d %H:%M:%S')
        return fulldate1
    except:
        return 0
    
def datestringtimestamp(x):
    fulldate = datetime.strptime(x,'%Y-%m-%d %H:%M:%S')
    fulldate = str(fulldate)
    fulldate = fulldate.split(':')[0]
    return fulldate
    
#outputdf['DRS_Preparation'] = outputdf.apply(lambda x:datestring1 (x['LASTDRS PREPAREDDATE']),axis=1)
outputdf['DRS_Preparation'] = outputdf.apply(lambda x:x['LASTDRS PREPAREDDATE'],axis=1)
#outputdf['Timestamp'] = outputdf.apply(lambda x:datestringtimestamp (x['Timestate Date']),axis=1)
#outputdf['Timestamp_String']= outputdf.apply(lambda x: str(x['Timestamp']), axis=1)
outputdf['Timestamp_String']= outputdf.apply(lambda x: str(x['Timestate Date']), axis=1)


# In[27]:

def datestring2(tsp):
    return datetime.strptime(tsp.split(' ')[0]+' 00:00:00', '%Y-%m-%d %H:%M:%S')

def datestring3(tsp):
    return datetime.strptime(tsp.split(' ')[0]+' 23:59:00', '%Y-%m-%d %H:%M:%S')

def getdrs(start, end, drsts):
    try:
        if start<=drsts and drsts<=end:
            return 1
        else:
            return 0
    except:
        return 0


outputdf['dayTS_start']= outputdf.apply(lambda x: datestring2(x['Timestamp_String']), axis=1)
outputdf['dayTS_end']= outputdf.apply(lambda x: datestring3(x['Timestamp_String']), axis=1)

outputdf['Valid_DRS']= outputdf.apply(lambda x: getdrs(x['dayTS_start'], x['dayTS_end'], x['DRS_Preparation']), axis=1)


# In[28]:

outputdf #FTP this data, provide the link in the mail body and save it in the folder. It has a ts field with name 'Timestate Date'
timestampnow = datetime.now()
opfilevar=timestampnow.date()
opfilevar1=timestampnow.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=np.round((float(currhrs)/60),0)

print outputdf.columns.tolist()

print outputdf.head()

with ExcelWriter(r'D:\Data\SC_Routewise_Analysis\Data\SC_Routewise_data_'+str(opfilevar)+"-"+str(opfilevar2)+'.xlsx') as writer:
    ###orginal_cancel_basedata.to_excel(writer, sheet_name='Sheet1',engine='xlsxwriter')
    outputdf.to_excel(writer, sheet_name='DATA',engine='xlsxwriter')


with ExcelWriter(r'D:\Data\SC_Routewise_Analysis\SC_Routewise_data.xlsx') as writer:
    ###orginal_cancel_basedata.to_excel(writer, sheet_name='Sheet1',engine='xlsxwriter')
    outputdf.to_excel(writer, sheet_name='DATA',engine='xlsxwriter')


####outputdf.to_csv(r'D:\Data\SC_Routewise_Analysis\Data\SC_Routewise_data_'+str(opfilevar)+"-"+str(opfilevar2)+'.csv')


###outputdf.to_csv(r'D:\Data\SC_Routewise_Analysis\SC_Routewise_data.csv')
oppath_data = r'D:\Data\SC_Routewise_Analysis\SC_Routewise_data.xlsx'

print ('Logging in...')
ftp = ftplib.FTP()
#ftp.connect('119.226.230.94')
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppath_data
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()
## Invoice data for FTP
# In[29]:

drsoutputdf = outputdf[outputdf['Valid_DRS']==1]


# In[30]:

if len(drsoutputdf)==0: #to handle empty df when no drs's are prepared
    print 'inside'
    drsgrpby = grpby.copy()
    drsgrpby.loc[drsgrpby.index,'DOCKNO'] = 0
    drsgrpby.loc[drsgrpby.index,'wt(T)'] = 0
else:
    print 'else'
    drsgrpby = drsoutputdf.groupby(['DEST BRCD','PUD_NAME2']).agg({'DOCKNO': 'count','ACTUWT': 'sum'}).reset_index()
    drsgrpby['wt(T)']= drsgrpby.apply(lambda x: pd.np.round((x['ACTUWT']/1000),1),axis=1)
    drsgrpby = drsgrpby.drop(['ACTUWT'], axis=1)


# In[31]:

finalgrpby = pd.merge(grpby, drsgrpby, on=['DEST BRCD','PUD_NAME2'],suffixes = ['_All','_DRS'],how='left')

print finalgrpby.columns.tolist()
# In[32]:

finalgrpby


# In[33]:

finalgrpby1 = finalgrpby.fillna(0)


# In[34]:

finalgrpby1['diff_Wt'] = finalgrpby1.apply(lambda x: x['wt(T)_All']-x['wt(T)_DRS'], axis=1)


# In[35]:

finalgrpby1.loc[finalgrpby1.index,'TS'] = ts
finalgrpby1 #finalgrpby1 in the attachment + save in a folder

finalgrpby1.to_csv(r'D:\Data\SC_Routewise_Analysis\Summary_groupby\SC_Routewise_summary_'+str(opfilevar)+"-"+str(opfilevar2)+'.csv')


finalgrpby1.to_csv(r'D:\Data\SC_Routewise_Analysis\SC_Routewise_summary.csv')
oppath_summary = r'D:\Data\SC_Routewise_Analysis\SC_Routewise_summary.csv'
# In[36]:

finalgrpby_mail = finalgrpby1[finalgrpby1['wt(T)_All']>=2.0]
finalgrpby_mail =finalgrpby_mail.rename(columns={'DOCKNO_All':'Con_All', 'DOCKNO_DRS':'Con_DRS','DEST BRCD':'LOCN'}) 
finalgrpby_mail = finalgrpby_mail.drop(['TS'], axis=1)

finalgrpby_mail = finalgrpby_mail.sort_values(['LOCN','wt(T)_All'],ascending=False)



finalgrpby_mail = finalgrpby_mail.to_string(index=False)
finalgrpby_mail #mailbody




filePath = oppath_summary
def sendEmail(TO = ["K.Adinarayana@Spoton.Co.In","Sathya.Chander@Spoton.Co.In","Sandeep.Deshpande@Spoton.Co.In","md.zaya@spoton.co.in","Poornima.V@Spoton.Co.In"],
            #TO = ["vishwas.j@spoton.co.in"],
            #CC = ["rajeesh.vr@spoton.co.in"],
            CC = ["sqtf@spoton.co.in","joseph.arul.seelan@spoton.co.in","renugopal.l@spoton.co.in","pramod.pandey@spoton.co.in","harish.bobade@spoton.co.in","Bn.Jairam@Spoton.Co.In","Swarup.Sarkar@Spoton.Co.In","Rajesh.Debnath@Spoton.Co.In","sasikumar.kannan@spoton.co.in"],
            #CC = ["vishwas.j@spoton.co.in"],
            #BCC = ["vinayak.kumbhar@spoton.co.in","vinodkumar.mishra@spoton.co.in","nitin.tatyarao@spoton.co.in","kiran.pawar@spoton.co.in","jai.prakash@spoton.co.in"] ,
            BCC = ["mahesh.reddy@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "Load Available for movement @ "+ str(opfilevar)+"-"+str(opfilevar2)
    msg["Subject"] = "SC Routewise Summary @ "+ str(opfilevar)+"-"+str(opfilevar2)
    body_text = """
    Dear All,
    
    PFB the SC Routewise Summary @ """ +str(opfilevar)+"-"+str(opfilevar2)+"""

    
    """+str(finalgrpby_mail)+"""
    
    Note:
    The data is exclusive of all CCF and DEPS cons.
    Con_All: Gives the total no of cons for each vendor
    wt(T)_All: Gives the total weight of cons for each vendor
    Con_DRS: Gives the total no of cons for each vendor, for which the DRS has been prepared in the duration of that day
    wt(T)_DRS: Gives the total weight of cons for each vendor, for which the DRS has been prepared in the duration of that day
    diff_Wt: Gives the difference between wt(T)_All and wt(T)_DRS in tonnes
    
    To download the con level data, Please click the link below
    
    http://spoton.co.in/downloads/IEProjects/ETA/SC_Routewise_data.xlsx
    
    """
    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends