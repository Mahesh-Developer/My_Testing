
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta
import sys
import datetime
import sys
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
import Utilities

# In[2]:


# reload(sys)
# sys.setdefaultencoding("utf8")
querydate=date.today()
querydate


# In[3]:


# cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
query1=("""EXEC USP_UCG_GET_LETTERS_REPORT 'ALL','ALL','ALL','2018-01-01','{0}','3','ALL'  """.format(querydate))


# In[4]:


df=pd.read_sql(query1,Utilities.cnxn)
print (len(df))

#df.rename(columns={'InvoiceScanFile':'InvoiceScanFile_1'},inplace=True)
# In[5]:


df1=df[df['FinalStatusDate']=='']


# In[6]:


len(df1)


# In[7]:


df1['Remarks']=''


# In[8]:


df1=df1[df1['FinalStatusDesc'].isin(['','DELIVERED'])]
len(df1)

# df1=df1[(df1[])]
# In[9]:


df2=df1[(df1['ConsignorCourierName'].isin(['Registered Post', 'Speedpost'])) & (df1['ConsigneeCourierName'].isin(['Registered Post', 'Speedpost']))]
len(df2)


# In[10]:


df2['Remarks']='Sender & Receiver Register Post Updated'
df1.loc[df2.index,'Remarks']=df2['Remarks']
print (df1['Remarks'].unique())

# In[11]:


# df3=df2[df2['ConsigneeCourierName'].isin(['Registered Post','Speedpost'])]
# len(df3)
#df3=df1[df1['ConsigneeCourierName'].isin(['Registered Post','Speedpost'])]
#len(df3)


# In[12]:


#df3['Remarks']='Sender & Receiver Register Post'
#df1.loc[df3.index,'Remarks']=df3['Remarks']


# In[13]:


# scan_df=df3[df3['InvoiceScanFile']=='Y']
# len(scan_df)
#scan_df=df1[(df1['InvoiceScanFile_1']=='Y') & (df1['Remarks']=='')]
df3=df1[df1['Remarks']=='']
scan_df=df3[(df3['InvoiceScanFile_1']=='Y')]



# In[ ]:


#len(df2[df2['InvoiceScanFile']=='Y'])


# In[14]:


scan_df['Remarks']='Invoice Uploaded'
df1.loc[scan_df.index,'Remarks']=scan_df['Remarks']


# In[15]:


peding_df=df1[df1['Remarks']=='']


# In[16]:


peding_df['Remarks']='Pending'
df1.loc[peding_df.index,'Remarks']=peding_df['Remarks']


# In[17]:

ddf=df1[df1['Remarks'].isin(['Pending','Invoice Uploaded'])]
summary1=df1.pivot_table(index=['Depot'],columns=['Remarks'],values=['ConNumber'],aggfunc={'ConNumber':len},margins=True)


# In[18]:


summary1


# In[19]:


len(df2)


# In[20]:

print (df1['Remarks'].unique())
ageing_dffff=df1[df1['Remarks'].isin(['Sender & Receiver Register Post Updated'])]
print (len(ageing_dffff))


# In[21]:


len(ageing_dffff[ageing_dffff['ConsigneeCourierEntryDate']!='-'])


# In[22]:


ageing_dffff['Current Date']=datetime.datetime.now().date()


# In[23]:


ageing_dffff=ageing_dffff[ageing_dffff['ConsigneeCourierEntryDate']!='-']
print (len(ageing_dffff))

# In[24]:


len(ageing_dffff)


# In[25]:


month_dict = {'Jan': '01','Feb': '02','Mar': '03','Apr':'04','May':'05','Jun':'06','Jul':'07','Aug':'08','Sep':'09','Oct':'10','Nov':'11','Dec':'12'}


# In[26]:


def getDate(x):
    if x=='-':
        return 0
    else:
        x1=x.split(' ')[2]+'-'+month_dict.get(x.split(' ')[1])+'-'+x.split(' ')[0]
        return x1


# In[27]:


ageing_dffff['ConsigneeEntryDate']=ageing_dffff.apply(lambda x:getDate(x['ConsigneeCourierEntryDate']),axis=1)


# In[28]:


ageing_dffff['ConsigneeEntryDate']=pd.to_datetime(ageing_dffff['ConsigneeEntryDate'])


# In[29]:


ageing_dffff['Current Date']=pd.to_datetime(ageing_dffff['Current Date'])


# In[30]:


ageing_dffff['Diff']=(ageing_dffff['Current Date']-ageing_dffff['ConsigneeEntryDate']).dt.days


# In[31]:


ageing_df=ageing_dffff[ageing_dffff['Diff']>10]
len(ageing_df)


# In[32]:


ageing_df.rename(columns={'Diff':'Reg_Post_Updated >10Days'},inplace=True)


# In[33]:


ageing_df_summary=ageing_df.pivot_table(index=['CurrentLocationDepot','Remarks'],values=['Reg_Post_Updated >10Days'],aggfunc={'Reg_Post_Updated >10Days':len})


# In[34]:


ageing_df_summary


# In[35]:


df1_summary=df1.pivot_table(index=['Remarks'],values=['ConNumber'],aggfunc={'ConNumber':len})


# In[36]:


#df1.to_csv(r'UCG_Final_Data.csv')
df1.to_csv(r'D:\Data\UCG\UCG_Final_Data.csv')

#ageing_df.to_csv(r'UCG_Final_Ageing_Data.csv')
ageing_df.to_csv(r'D:\Data\UCG\UCG_Final_Ageing_Data.csv')


#df1.to_csv(r'UCG_Final_Data'+str(querydate)+'.csv')

#ageing_df.to_csv(r'UCG_Final_Ageing_Data'+str(querydate)+'.csv')

df1.to_csv(r'D:\Data\UCG\UCG_Final_Data'+str(querydate)+'.csv')
ageing_df.to_csv(r'D:\Data\UCG\UCG_Final_Ageing_Data'+str(querydate)+'.csv')


# In[37]:


filepath1=r'D:\Data\UCG\UCG_Final_Data.csv'
filepath2=r'D:\Data\UCG\UCG_Final_Ageing_Data.csv'
#filepath1=r'UCG_Final_Data.csv'
#filepath2=r'UCG_Final_Ageing_Data.csv'


# In[38]:


import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback
for i in [filepath1,filepath2]:
    oppath1=i
    #FTP Upload starts
    print ('Logging in...')
    ftp = ftplib.FTP()  
    ftp.connect('10.109.230.50')  
    print (ftp.getwelcome())
    try:  
        try:  
            ftp.login('HOSQTeam', 'Te@mH0$q')
            print ('login done')
            ftp.cwd('Auto_reports')  
            #ftp.cwd('FIFO')
            # move to the desired upload directory  
            print ("Currently in:", ftp.pwd()) 
            print ('Uploading...')  
            fullname = oppath1
            name = os.path.split(fullname)[1]  
            f = open(fullname, "rb")  
            ftp.storbinary('STOR ' + name, f)  
            f.close()  
            print ("OK"  )
            print ("Files:")  
            print (ftp.retrlines('LIST'))
        finally:  
            print ("Quitting...")
            ftp.quit()  
    except:  
        traceback.print_exc()


# In[39]:


from_addr = 'mis.ho@spoton.co.in'
# bcc_addr = ['anitha.thyagarajan@spoton.co.in','mahesh.reddy@spoton.co.in']
# cc_addr = ['anitha.thyagarajan@spoton.co.in','sq_spot@spoton.co.in']
# bcc_addr = ['mahesh.reddy@spoton.co.in','baskar.t@spoton.co.in']
bcc_addr = ['mis.ho@spoton.co.in','sq_spot@spoton.co.in','rom_spot@spoto.co.in','dom_spot@spoton.co.in','aom_spot@spoton.co.in','scincharge_spot@spoton.co.in','anitha.thyagarajan@spoton.co.in','mahesh.reddy@spoton.co.in','shravani.g@spoton.co.in']

username = 'mis.ho@spoton.co.in'
password = 'Spot@123'

msg = MIMEMultipart()

msg['From'] = from_addr
# msg['To'] = ', '.join(to_addr)
#msg['cc'] = ', '.join(cc_addr)
msg['bcc'] = ', '.join(bcc_addr)
msg['Subject'] = 'UCG - Final Notice Pending details'
html='''<html>
<h4>Dear All</h4>
<p>Please find the attached report for Depot wise UCG Final notice Pending / Invoice Uploaded / Sender register post Updated in the system.</p>
</html>'''
html3='''
<h5> Note : For data please open below link.</h5>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/UCG_Final_Data.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/UCG_Final_Data.csv</p></b>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/UCG_Final_Ageing_Data.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/UCG_Final_Ageing_Data.csv</p></b>

'''
html1='''<h5>Thanks & Regards</h5></b>
<h5>HO-SQ</h5>'''

#  msg.attach(part10)

report=""
report+=html
report+='<br>'
report+='Pending  - Branch yet to upload the Scan Customer Invoice copy into the UCG portal.'
report+='<br>'
report+='Invoice Uploaded - Branch already uploaded Customer Invoice copy.'
report+='<br>'
report+='Sender register post Updated - HO Uploaded the acknowledgment (Sender address) of register post in the system. (Receiver Address Not Clear).'
report+='<br>'
report+='<br>'+summary1.to_html()+'<br>'
report+='<br>'
report+='The below cons completed UCG final notice process and are ready to move to UCG location.   Kindly move the cons to respective UCG location.. '
report+='<br>'
report+='<br>'+ageing_df_summary.to_html()+'<br>'
report+='<br>'
report+=html3
report+='<br>'
report+=html1
abc=MIMEText(report,'html')
msg.attach(abc)

part=MIMEBase('application','octet-stream')
# part1=MIMEBase('application','octet-stream')
#part.set_payload(open(filepath,'rb').read())
# part1.set_payload(open(filepath1,'rb').read())
#encoders.encode_base64(part)
# Encoders.encode_base64(part1)
#part.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath))
# part1.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath1))
#msg.attach(part)
# msg.attach(part1)


# server = smtplib.SMTP('smtp.spoton.co.in',587)
# server.ehlo()
# server.starttls()
# server.ehlo()
# server.login('mis.ho@spoton.co.in','Mis@2019')
# server.sendmail(from_addr,bcc_addr,msg.as_string())
# print ('mail sent succesfully')
# server.quit()

server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(from_addr,bcc_addr, msg.as_string())
server.quit()