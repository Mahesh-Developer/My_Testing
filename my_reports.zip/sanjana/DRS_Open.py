
# coding: utf-8

# In[ ]:


import numpy as np
import pandas as pd
from IPython import display
from datetime import datetime
from datetime import datetime,timedelta
from datetime import datetime, timedelta
import smtplib
import ftplib
import traceback
import calendar
import os
import pyodbc
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import Utilities

# In[ ]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")


# In[ ]:


query=("EXEC dbo.USP_DRS_OPEN_SQ")


# In[ ]:


df=pd.read_sql(query,Utilities.cnxn)
len(df)


# In[ ]:


df['PDCDate']=df['PDCDT'].apply(lambda x: datetime.strptime(str(x).split(' ')[0],'%Y-%m-%d'))


# In[ ]:


date=datetime.strftime(datetime.now(),'%Y-%m-%d')
date


# In[ ]:

print (len(df))
df['CurrentDate']=pd.to_datetime(datetime.strftime(datetime.now(),'%Y-%m-%d'))
df=df[df['PDCDate']!=date]

# In[ ]:


df['Ageing']=df['CurrentDate']-df['PDCDate']


# In[ ]:


df['Ageing']=df['Ageing'].apply(lambda x: int(str(x).split(' ')[0]))


# In[ ]:


# df['Ageing'].unique()

# df['Type']='Count of DOCKNO'
# In[ ]:


std_df=df[df['PINCODE_TYPE']=='STD']
len(std_df)


# In[ ]:


def stdBucket(x):
    if x==1:
        return '1 days'
    elif x ==2:
        return '2 days'
    elif x ==3:
        return '3 days'
    elif x ==4:
        return '4 days'
    else:
        return '>4 days'


# In[ ]:


std_df['Bucket']=std_df.apply(lambda x:stdBucket(x['Ageing']),axis=1)


# In[ ]:




std_summary=std_df.pivot_table(index=['ControlArea'],columns=['Bucket'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').fillna(0)


# In[ ]:


std_summary['DOCKNO']=std_summary['DOCKNO'].astype(int)


# In[ ]:


std_summary


# In[ ]:


oda_df=df[df['PINCODE_TYPE']=='ODA']
len(oda_df)


# In[ ]:


def odaBucket(x):
    if x ==1:
        return '1 days'
    elif x ==2:
        return "2 days"
    elif x ==3:
        return '3 days'
    elif x==4:
        return '4 days'
    elif x==5:
        return '5 days'
    elif x==6:
        return '6 days'
    elif x==7:
        return '7 days'
    elif x==8:
        return '8 days'
    elif x==9:
        return '9 days'
    elif x==10:
        return '10 days'
    else:
        return '>10 days'
        


# In[ ]:


oda_df['Bucket']=oda_df.apply(lambda x:odaBucket(x['Ageing']),axis=1)


# In[ ]:


oda_summary=oda_df.pivot_table(index=['ControlArea'],columns=['Bucket'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').fillna(0)


# In[ ]:


oda_summary['DOCKNO']=oda_summary['DOCKNO'].astype(int)


# In[ ]:


##NSL


# In[ ]:


nsl_df=df[df['PINCODE_TYPE']=='NSL']
len(nsl_df)


# In[ ]:


def nslBucket(x):
    if x in range(0,8):
        return '1-7 days'
    else:
        return '>7 days'


# In[ ]:


nsl_df['Bucket']=nsl_df.apply(lambda x:nslBucket(x['Ageing']),axis=1)


# In[ ]:


nsl_summary=nsl_df.pivot_table(index=['ControlArea'],columns=['Bucket'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').fillna(0)


# In[ ]:


nsl_summary['DOCKNO']=nsl_summary['DOCKNO'].astype(int)


# In[ ]:


nsl_summary


# In[ ]:


date


# In[ ]:


df.to_csv(r'D:\Data\DRS Reports\DRS_Open_Report\DRS_Open_Data_'+str(date)+'.csv')
df.to_csv(r'D:\Data\DRS Reports\DRS_Open_Report\DRS_Open_Data.csv')


# In[ ]:


filepath=r'D:\Data\DRS Reports\DRS_Open_Report\DRS_Open_Data.csv'


# In[ ]:


# TO=['mahesh.reddy@spoton.co.in']
TO=['aom_spot@spoton.co.in','dom_spot@spoton.co.in','rom_spot@spoton.co.in','scincharge_spot@spoton.co.in','banusanketh.dc@spoton.co.in']
# CC=["mahesh.reddy@spoton.co.in"]
CC=['sq_spot@spoton.co.in','sqtf@spoton.co.in','mahesh.reddy@spoton.co.in']
FROM="mis.ho@spoton.co.in"
# FROM="mahesh.reddy@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "DRS Open Report" + " - " + str(date)
report=""
report+="Dear All"
report+='<br>'
report+='<br>'
report+='Please find DRS Open Report Summaries'
report+='<br>'
report+='<br>'
report+='PFB DRS Open Summary for STD'
report+='<br>'+std_summary.to_html()+'<br>'
report+='<br>'
report+='PFB DRS Open Summary for ODA'
report+='<br>'
report+='<br>'+oda_summary.to_html()+'<br>'
report+='<br>'
report+='PFB DRS Open Summary for NSL'
report+='<br>'
report+='<br>'+nsl_summary.to_html()+'<br>'


abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

# part1 = MIMEBase('application', "octet-stream")
# part1.set_payload( open(filepath1,"rb").read() )
# encoders.encode_base64(part1)
# part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
# msg.attach(part1)


# server=smtplib.SMTP('smtp.sendgrid.net', 587)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("mahesh.reddy@spoton.co.in", "Nov@2018")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()

