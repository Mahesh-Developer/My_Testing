
# coding: utf-8

# In[1]:

import pandas as pd
import numpy as np
import pyodbc
from datetime import datetime,timedelta


# In[2]:

yest=datetime.strftime(datetime.now()-timedelta(days=1),"%Y-%m-%d")
yest


# In[3]:

query=("""SELECT  DT.DOCKNO ,
        CONVERT(VARCHAR(10), DT.DOCKDT, 103) BookingDate ,
        DT.ORGNCD ,
        DT.DESTCD ,
        DT.PKGSNO ,
        PC.PcsNo ,
        PH.SheetType ,
        PH.SheetNo ,
        PH.SCCode ,
        PC.scanTime ,
        PH.RequestDate ,
        PH.FinalSubmitDate ,
        CONVERT(VARCHAR(10), DD.DELY_DT, 103) DeliveryDate ,
        ISNULL(PC.excepType, '-') excepType,TNK.TravelPath
FROM    dbo.DKT_DELY DD WITH ( NOLOCK )
        INNER JOIN dbo.DOCKET DT WITH ( NOLOCK ) ON DT.DOCKNO = DD.DOCKNO
        INNER JOIN dbo.tblPLTAPICONDtls TC WITH ( NOLOCK ) ON TC.ConNo =
DT.DOCKNO
        INNER JOIN dbo.tblPLTAPIPcsDtls PC WITH ( NOLOCK ) ON PC.ConNo =
TC.ConNo
                                                              AND
PC.PLTHDRID = TC.PLTHDRID
        INNER JOIN dbo.tblPLTAPIHDR PH WITH ( NOLOCK ) ON PH.AutoID =
TC.PLTHDRID
                                                          
        LEFT OUTER JOIN dbo.tblPLTAPIHDR PHH WITH ( NOLOCK ) ON PHH.AutoID =
PH.AutoID
                                                              AND PHH.SCCode
= PH.SCCode
                                                              AND
PHH.SheetType = 'PT'
                                                              AND PHH.SCCode
= DT.REASSIGN_DESTCD
        LEFT OUTER JOIN dbo.tblDocketNextNode TNK WITH ( NOLOCK ) ON
TNK.Orgncd = DT.ORGNCD
                                                              AND TNK.Destcd
= DT.REASSIGN_DESTCD
                                                              AND
TNK.IsActive = 1
                                                              AND TNK.PType
= CASE
                                                              WHEN
SUBSTRING(DT.DOCKNO,
                                                              1, 1) = '6'
                                                              THEN 'AR'
                                                              ELSE 'SR'
                                                              END
WHERE   DD.DELY_DT IS NOT NULL
        AND DD.DELY_DT BETWEEN '{0}'
                       AND     '{1}' AND PHH.AutoID IS NULL
              """).format(yest+' 00:00:00',yest+' 23:59:00')


# In[4]:

cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()


# In[5]:

df=pd.read_sql(query,cnxn)


# In[6]:

len(df)


# In[7]:

df1=df[df['excepType']=='PPS']
len(df1)


# In[8]:

conslist=df1['DOCKNO'].unique().tolist()
shortdf=df[df['DOCKNO'].isin(conslist)]
len(shortdf)


# In[9]:

shortdf['PathList']=shortdf['TravelPath'].apply(lambda x:x.split('-'))


# In[10]:

def getIndex(x,y):
    try:
        a=x.index(y)
        return a
    except:
        return y


# In[11]:

shortdf['Index']=shortdf.apply(lambda x: getIndex(x['PathList'],x['SCCode']),axis=1)


# In[12]:

shortdf['Concat']=shortdf['Index'].astype(str)+'.'+df1['SCCode']


# In[13]:

shortdf['scanTime']=shortdf['scanTime'].fillna('-')


# In[14]:

shortdf['Pcs']=shortdf.apply(lambda x: 0 if x['scanTime']=='-' else 1,axis=1)


# In[15]:

shortdf['Short_Location']=shortdf['SCCode']+'/'+shortdf['Pcs'].astype(str)


# In[16]:

shortdf['Dummy']=shortdf['PcsNo'].astype(str)+shortdf['SheetType']+shortdf['SCCode']


# In[17]:

shortdf.drop_duplicates('Dummy',keep='first',inplace=True)
len(shortdf)


# In[18]:

shortdf['Type']=shortdf['Index'].astype(str)+'.'+shortdf['SheetType']


# In[19]:

f1=shortdf.pivot_table(index=['DOCKNO','SCCode','Type','PKGSNO','Index'],values=['PcsNo','Pcs'],aggfunc={'PcsNo':len,'Pcs':sum}).reset_index()


# In[20]:

# f1['List']=f1.apply(lambda x:(x['SCCode'],x['PcsNo']),axis=1)
f1['List']=f1.apply(lambda x:(x['SCCode'],x['Pcs']),axis=1)


# In[21]:

f1=f1[~f1['DOCKNO'].isin(['520231409 ','520264310 ','711109782 '])]
len(df1)


# In[22]:

summaey=f1.pivot_table(index=['DOCKNO'],columns=['Index','Type'],values=['List','PKGSNO','Pcs'],aggfunc={'List':lambda x:x,'PKGSNO':sum,'Pcs':sum}).fillna(0)


# In[23]:

summaey['Total_Scanns_Required']=summaey['PKGSNO'].sum(axis=1)


# In[24]:

del summaey['PKGSNO']


# In[25]:

summaey['Scanned']=summaey['Pcs'].sum(axis=1)


# In[26]:

del summaey['Pcs']


# In[27]:

summaey2=summaey[['Scanned','Total_Scanns_Required']]


# In[28]:

special_cust_summary1=pd.DataFrame()
for i in ['0.PT', '0.LT', '1.UT', '1.LT', '2.UT', '2.LT','2.DT', '3.UT', '3.LT','3.DT','4.UT','4.LT','4.DT','5.UT','5.LT','5.DT']:
    try:
        special_cust_summary1[i]=summaey[('List',int(i.split('.')[0]),i)]
    except:
        special_cust_summary1[i]=0.0



# In[29]:

final_summary=pd.merge(special_cust_summary1,summaey2,left_index=True,right_index=True)


# In[30]:

final_summary['Diff']=final_summary[(u'Total_Scanns_Required', u'', u'')]-final_summary[(u'Scanned', u'', u'')]


# In[31]:

final_summary.sort_values('Diff',ascending=False,inplace=True)


# In[32]:

final_summary=final_summary.reset_index()


# In[33]:

final_summary


# In[34]:

# def find_missing_details(row):
#     missing_location = []
#     extra_load = []
#     start_load = 0
#     start_index =1 
#     for i in range(1,13):
#         if type(row[i]) == tuple:
#             start_load = row[i][1]
#             start_index = i
#             break
#     if start_load != 0:
#         end_index = 12
#         for i in range(12,0,-1):
#             if type(row[i]) == tuple:
#                 end_index = i
#                 break
                
#         for c in range(start_index,end_index + 1):
#             if type(row[c]) == tuple:
#                 point_load = row[c][1]           
#                 if point_load < start_load:
#                     missing_location.append(row[c][0])
#                 if point_load > start_load:
#                     extra_load.append(row[c][0])
                    
#     row['short_location'] = missing_location
#     row['extra_location'] = extra_load
#     return row

def find_missing_details(row):
    short_location = []
    extra_load = []
    missing_load = []
    no_scan = []
    start_load = 0
    start_index =1 
    for i in range(1,13):
        if type(row[i]) == tuple:
            start_load = row[i][1]
            start_index = i
            break
    if start_load != 0:
        end_index = 12
        for i in range(12,0,-1):
            if type(row[i]) == tuple:
                end_index = i
                break
                
        for c in range(start_index,end_index + 1):
            if type(row[c]) == tuple:
                for e in range(c+1,end_index + 1):
                    if type(row[e]) == tuple:
                        if row[c][1] > row[e][1]:
                            if row[c][0] == row[e][0]:
                                missing_load.append(row[c][0])
                            else:
                                short_location.append(row[c][0])
                                
                        if row[c][1] < row[e][1]:
                            if row[c][0] == row[e][0]:
                                no_scan.append(row[c][0])
                            else:
                                extra_load.append(row[e][0])
                        break
                    
                
    row['short_location'] = short_location
    row['movement_without_location'] = extra_load
    row['missing_location'] = missing_load
    row['without_Scan']=no_scan
    return row


# In[35]:

final_summary = final_summary.apply(lambda x : find_missing_details(x),axis = 1)


# In[36]:

short_location_df=final_summary[['DOCKNO','short_location']]
len(short_location_df)


# In[37]:

import pandas as pd
import numpy as np

z = []
for k,row in short_location_df.iterrows():
    for j in list(np.array(row['short_location']).flat):
        z.append({'DOCKNO':row['DOCKNO'], 'short_location':j,'Type':'Shortage'})
short_location_df1 = pd.DataFrame(z)

 


# In[38]:

shortage_summary=short_location_df1.pivot_table(index=['Type','short_location'],aggfunc={'DOCKNO':len}).reset_index().sort_values('DOCKNO',ascending=False)


# In[39]:


shortage_summary_top3=shortage_summary.head(3)
shortage_summary_top3['Top_3_locations']=shortage_summary_top3.apply(lambda x:{x['short_location']:x['DOCKNO']},axis=1)


# In[40]:


shortage_summary_top3grp = shortage_summary_top3.groupby('Type')['Top_3_locations'].apply(lambda x: x.values).reset_index() 
shortage_summary_top3grp


# In[41]:

missing_location_df=final_summary[['DOCKNO','missing_location']]
len(missing_location_df)


# In[42]:

import pandas as pd
import numpy as np

z = []
for k,row in missing_location_df.iterrows():
    for j in list(np.array(row['missing_location']).flat):
        z.append({'DOCKNO':row['DOCKNO'], 'missing_location':j,'Type':'Missing'})
missing_location_df1 = pd.DataFrame(z)

 


# In[43]:

missing_summary=missing_location_df1.pivot_table(index=['Type','missing_location'],aggfunc={'DOCKNO':len}).reset_index().sort_values('DOCKNO',ascending=False)


# In[44]:

missing_summary_top3=missing_summary.head(3)
missing_summary_top3['Top_3_locations']=missing_summary_top3.apply(lambda x:{x['missing_location']:x['DOCKNO']},axis=1)


# In[45]:


missing_summary_top3grp = missing_summary_top3.groupby('Type')['Top_3_locations'].apply(lambda x: x.values).reset_index() 
missing_summary_top3grp


# In[46]:

extra_location_df=final_summary[['DOCKNO','movement_without_location']]
len(extra_location_df)


# In[47]:

import pandas as pd
import numpy as np

z = []
for k,row in extra_location_df.iterrows():
    for j in list(np.array(row['movement_without_location']).flat):
        z.append({'DOCKNO':row['DOCKNO'], 'movement_without_location':j,'Type':'Movement Without Scan'})
extra_location_df1 = pd.DataFrame(z)

 


# In[48]:

extra_summary=extra_location_df1.pivot_table(index=['Type','movement_without_location'],aggfunc={'DOCKNO':len}).reset_index().sort_values('DOCKNO',ascending=False)


# In[49]:

extra_summary_top3=extra_summary.head(3)


# In[50]:

extra_summary_top3['Top_3_locations']=extra_summary_top3.apply(lambda x:{x['movement_without_location']:x['DOCKNO']},axis=1)


# In[51]:


extra_summary_top3grp = extra_summary_top3.groupby('Type')['Top_3_locations'].apply(lambda x: x.values).reset_index() 


# In[52]:

extra_summary_top3grp


# In[53]:

without_scan_location_df=final_summary[['DOCKNO','without_Scan']]
len(without_scan_location_df)


# In[54]:

import pandas as pd
import numpy as np

z = []
for k,row in without_scan_location_df.iterrows():
    for j in list(np.array(row['without_Scan']).flat):
        z.append({'DOCKNO':row['DOCKNO'], 'without_Scan':j,'Type':'Without Scan'})
without_scan_location_df1 = pd.DataFrame(z)

 


# In[55]:

withouscan_summary=without_scan_location_df1.pivot_table(index=['Type','without_Scan'],aggfunc={'DOCKNO':len}).reset_index().sort_values('DOCKNO',ascending=False)
withouscan_summary_top3=withouscan_summary.head(3)
withouscan_summary_top3['Top_3_locations']=withouscan_summary_top3.apply(lambda x:{x['without_Scan']:x['DOCKNO']},axis=1)


# In[56]:



withouscan_summary_top3grp = withouscan_summary_top3.groupby('Type')['Top_3_locations'].apply(lambda x: x.values).reset_index() 
withouscan_summary_top3grp


# In[57]:

final_summary.to_csv(r'D:\Data\Daily_Alok_PLT_Report\Final_Report\PLT_Summary_v3.csv')


# In[58]:

shortdf.to_csv(r'D:\Data\Daily_Alok_PLT_Report\Final_Report\Daily_Short_Data.csv')


# In[59]:

filepath=r'D:\Data\Daily_Alok_PLT_Report\Final_Report\PLT_Summary_v3.csv'
filepath1=r'D:\Data\Daily_Alok_PLT_Report\Final_Report\Daily_Short_Data.csv'


# In[60]:


from datetime import datetime,timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
import ftplib
# import Utilities
from calendar import monthrange
import smtplib


# In[61]:

todate=datetime.strftime(datetime.now(),"%Y-%m-%d")
todate


# In[62]:
TO=['mahesh.reddy@spoton.co.in',"alok.b@spoton.co.in"]
CC=['satya.pal@spoton.co.in','abhik.mitra@spoton.co.in','shivananda.p@spoton.co.in']


# TO=['mahesh.reddy@spoton.co.in']
# CC=['mahesh.reddy@spoton.co.in']
FROM="reports.ie@spoton.co.in"
# FROM="mahesh.reddy@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "PLT Con Shortage Life Cycle " + " - " + str(todate)

report=""
report+="Dear All,"
report+='<br>'
report+='Please find the PLT Con Shortage Life Cycle'
report+='<br>'
report+='Missing Top 3 Locations :'
report+='<br>'+missing_summary_top3grp.to_html()+'<br>'
report+='<br>'
report+='Movement Without Scan Top 3 Locations :'
report+='<br>'+extra_summary_top3grp.to_html()+'<br>'
report+='<br>'
report+='Shortage Top 3 Locations :'
report+='<br>'+shortage_summary_top3grp.to_html()+'<br>'
report+='<br>'

report+='<br>'
report+='Without Scan Top 3 Locations :'
report+='<br>'+withouscan_summary_top3grp.to_html()+'<br>'
report+='<br>'

abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(filepath1,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
msg.attach(part1)


# server=smtplib.SMTP('smtp.sendgrid.net', 587)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("mahesh.reddy@spoton.co.in", "Nov@2018")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()


# In[ ]:



