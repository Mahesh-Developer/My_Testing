
# coding: utf-8

# In[1]:

import pandas as pd
# from sframe import SFrame
# import sframe as gl
from sframe import SFrame,aggregate
import sframe
# import graphlab as gl
import datetime
from datetime import timedelta

import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import os
import ftplib
import traceback
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import Utilities
# In[2]:

conthc = pd.read_csv(r'http://spoton.co.in/downloads/IEP_CON_THC_DATA_DAILY/IEP_CON_THC_DATA_DAILY.csv')
#conthc = pd.read_csv('IEP_CON_THC_DATA_DAILY_27Jan.csv')
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.87;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()


query = ("""EXEC USP_CON_THC_DAILY_DATA """)
print (query)
conthc = pd.read_sql(query, Utilities.cnxn)
conthc.rename(columns={'Con No':'Con_No','TC Dest':'TC_Dest','TC Source':'TC_Source','THC Transaction Date':'THC_Transaction_Date','THC Date':'THC_Date','TC Date':'TC_Date'},inplace=True)
# In[3]:

pmdlh = pd.io.excel.read_excel(r'http://spoton.co.in/downloads/PMDLH/PMDLH.xls','PMD_LINEHAUL_DATA')

#pmdlh = pd.io.excel.read_excel(r'C:/Users/s1738raj/Desktop/network_code/Routing_Check/PMDLH.xls','PMD_LINEHAUL_DATA')


try:
    pmdlh['Util%'] = pmdlh.apply(lambda x: int(x['TOTAL ACTUAL LOAD']*100/x['VEHICLE PAYLOAD']), axis=1)
except:
    pmdlh['Util%']=0


# In[5]:

brsfsf = sframe.SFrame.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\brsf_gua.csv') #accessing in sframe to use stack function available in graphlab
brsfsf1 = brsfsf.stack('arealist', 'SC')
brsfsf1.save(r'D:\Python\Scripts and Files\Path and Graph Files\brsfsf1.csv')
brsf_tbl = pd.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\brsfsf1.csv')


# In[6]:

rule = pd.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\instruction_v24input_rules.csv')


# In[7]:

fullrule_all = pd.merge(rule, brsf_tbl, left_on = ['Destination'], right_on=['areakey'], how='inner')
fullrule = fullrule_all.drop_duplicates(['Rule_Cur_Loc','Rule_Nxt_Loc','SC'])

# In[8]:

con_eval_df = pd.merge(conthc, fullrule, left_on = ['TC_Source','Destn'], right_on = ['Rule_Cur_Loc','SC'], how = 'inner')


# In[9]:

#con_eval_df.to_csv('con_eval.csv')


# In[10]:

def routingerror(idealnxtloc, actnxtloc):
    if actnxtloc == idealnxtloc:
        return 'correct'
    else:
        return 'error'


# In[11]:

con_eval_df['Routing'] = con_eval_df.apply( lambda x: routingerror(x['Rule_Nxt_Loc'],x['TC_Dest']), axis=1)


# In[12]:

errordf = con_eval_df[con_eval_df['Routing']=='error']


# In[13]:

errordf['DOCKNO'] = errordf.apply(lambda x : x[0], axis=1)


# In[14]:

errorgpby = errordf.groupby(['TC_Source','Rule_Nxt_Loc','TC_Dest']).agg({'DOCKNO':'count','Act_Wt':'sum' }).reset_index()
errorgpby['Act_Wt'] = errorgpby.apply( lambda x: int(x['Act_Wt']), axis=1)
#openinggroupby=openingstock.groupby(['DEST BRCD']).agg({'DOCKNO': 'count'}).reset_index()


# In[15]:

#errorgpby.to_csv('errorgpby.csv')
#errorgpby.head()


# In[16]:

rulecol = rule[['Rule_Cur_Loc','Rule_Nxt_Loc','Overflow Allowed']]
rule_spill = rulecol[rulecol['Overflow Allowed']=='Yes']
rule_spill_unq = rule_spill.drop_duplicates(subset=['Rule_Cur_Loc','Rule_Nxt_Loc',])
rule_spill_unq


# In[17]:

errorgpby_spill = pd.merge(errorgpby, rule_spill_unq, left_on=['TC_Source','Rule_Nxt_Loc'], right_on=['Rule_Cur_Loc','Rule_Nxt_Loc'], how = 'left')
errorgpby_spill = errorgpby_spill[['TC_Source', 'Rule_Nxt_Loc', 'TC_Dest','DOCKNO','Act_Wt','Overflow Allowed']]


# In[18]:


datefilter=(datetime.datetime.today()-timedelta(hours=24)).date()
datefilter = datetime.datetime.combine(datefilter, datetime.time(9,0))
pmdlh_yst= pmdlh[pmdlh['THC DATE']>=datefilter]
print datefilter


def getthc(source, nxtloc):
    #if spill == 'Yes':
    try:
        checklh = pmdlh_yst[(pmdlh_yst['ORIGIN']==source) & (pmdlh_yst['DESTINATION']==nxtloc)].sort_values('THC DATE', ascending = False)
        if len(checklh)>0:
            #return 'Spill Over'
            return checklh['THC NUMBER'].values[0]
        else:
            return 'Non Ops'
    except:
        return 'Non Ops'
    

def get_utilization(thcno):
    if thcno != 'Non Ops':
        try:
            checklh_utl = pmdlh_yst[(pmdlh_yst['THC NUMBER']==thcno)]
            if len(checklh_utl)>0:
                #return 'Spill Over'
                return checklh_utl['Util%'].values[0]

        except:
            return 'remove Later with pass'


# In[19]:

errorgpby_spill['Remark/THCNo'] = errorgpby_spill.apply(lambda x : getthc(x['TC_Source'],x['Rule_Nxt_Loc']), axis=1)


# In[22]:

errorgpby_spill['Utli%'] = errorgpby_spill.apply(lambda x : get_utilization(x['Remark/THCNo']), axis=1)


# In[23]:

#due to regex search the column 'Remark/THCNo' and 'Utli%' are incomplete. Need to fix
#errorgpby_spill= errorgpby_spill[['TC_Source', 'Rule_Nxt_Loc', 'TC_Dest','DOCKNO','Act_Wt','Remark/THCNo','Utli%']].sort_values('Act_Wt', ascending =False)
errorgpby_spill= errorgpby_spill[['TC_Source', 'Rule_Nxt_Loc', 'TC_Dest','DOCKNO','Act_Wt']].sort_values('Act_Wt', ascending =False)


# In[24]:

errorgpby_spill = errorgpby_spill.rename(columns={'TC_Source':'Source','Rule_Nxt_Loc':'Ideal_NxtLoc', 'TC_Dest':'Actual_NxtLoc'})


ts= datetime.datetime.now()
opfilevar=ts.date()
opfilevar1=ts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=pd.np.round(float(currhrs)/60)

# In[25]:
errorgpby_spill.to_csv(r'D:\Data\Routing_monitoring\Error_spillover\Routing_monitoring_summary_'+str(opfilevar)+'.csv') #attachment; output required
errorgpby_spill.to_csv(r'D:\Data\Routing_monitoring\Routing_monitoring_summary.csv') #attachment; output required

oppathspill = r'D:\Data\Routing_monitoring\Routing_monitoring_summary.csv'

# In[26]:
errordf.rename(columns={'\xef\xbb\xbfCon_No':'Con_No'}, inplace=True)
errordf.to_csv(r'D:\Data\Routing_monitoring\Error_data\Routing_monitoring_condata_'+str(opfilevar)+'.csv') #mailbody; output required
errordf.to_csv(r'D:\Data\Routing_monitoring\Routing_monitoring_condata.csv') #mailbody; output required
oppatherrordata = r'D:\Data\Routing_monitoring\Routing_monitoring_condata.csv'

print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppatherrordata
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()

#oppathspill = r'D:\Data\Routing_monitoring\errordata.csv'
errorgpby_spill = errorgpby_spill.to_string(index=False)

# In[ ]:
filePath = oppathspill
def sendEmail(#TO = ["supratim@iepfunds.com","rajeesh.vr@spoton.co.in"],
            #TO = ["mahesh.reddy@spoton.co.in"],
            TO = ["hubmgr_spot@spoton.co.in"],
            CC = ["sqtf@spoton.co.in","rajeesh.vr@spoton.co.in","ankit@iepfunds.com","prasanna.hegde@spoton.co.in"],
            #CC =["mahesh.reddy@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "Routing Monitoring " + '- ' + str(opfilevar)
    body_text = """
    Dear All,
    
    PFB the Routing monitoring report for """+str(opfilevar)+"""
    
"""+str(errorgpby_spill)+"""

    PS:
    Source : Location from where the con departed
    Ideal_NxtLoc: Ideal location to which the con should have been sent to
    Actual_NxtLoc: Actual location to where the con was sent to
    DOCKNO: Total No of cons
    Act_Wt: Sum of weights of these cons
    Remark/THCNo: If a vehicle departed from the current location to the ideal location, then it's THC No else the remark as 'Non Ops'
    Utli%: Utilization of the above mentioned THC
    
    For the con level data, please use the link below
    
    http://spoton.co.in/downloads/IEProjects/ETA/Routing_monitoring_condata.csv

    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
#print('Email sent')
#Sending output file via mail ends



