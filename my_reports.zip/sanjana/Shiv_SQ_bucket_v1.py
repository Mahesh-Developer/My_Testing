
# coding: utf-8

# In[1]:

import pandas as pd
from pandas import ExcelWriter
import os
import traceback
import math
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
import sys

#sys.setdefaultencoding("Windows-1252")
reload(sys).setdefaultencoding("ISO-8859-1")

# In[2]:

#stockdata = pd.read_csv(r'C:\Data\Shiv_ops\CLSSTKSUM_25042016.csv')
try:
    stockdata = pd.read_csv(r'http://spoton.co.in/downloads/IEPROJECTS/CLSSTKSUM/CLSSTKSUM.csv')


    # In[3]:

    stockdata.columns.tolist()


    # In[4]:

    stockdata=stockdata.rename(columns={'\xef\xbb\xbfPARENTCODE1':'PARENTCODE1'})


    # In[5]:

    sqbucketlist = ['8_UCG','A1_DEAD STOCK','9_DEPS-SQ','A2_CCF without Tickets','2_CS Dem_Pin Drs Block','1_CS Bucket']
    stockdatasq = stockdata[stockdata['STATUS1'].isin(sqbucketlist)]
    #stockdatasq = stockdatasq.drop(['STATUS1','LATEST_CON_REC_COMM1','CSGENM2'],axis=1)
    stockdatasq = stockdatasq.drop(['LATEST_CON_REC_COMM1','CSGENM2'],axis=1)
    print (len(stockdatasq))
    # exit(0)

    # In[6]:

    datetoday=datetime.today()
    datefilter = datetoday-timedelta(hours=24)
    datefilter=datefilter.date()
    datefilter


    # In[7]:

    stockdatasq['PARENTNAME1'] = stockdatasq['PARENTNAME1'].str.decode('utf-8').replace(u'\0x96', '-')
    #stockdatasq['RECEIVER NAME'] = stockdatasq['RECEIVER NAME'].str.decode('utf-8').replace(u'\0x96', '-')
    #stockdatasq['SENDER NAME'] = stockdatasq['SENDER NAME'].str.decode('utf-8').replace(u'\0x96', '-')
    stockdatasq['ConStatusReason2'] = stockdatasq['ConStatusReason2'].str.decode('utf-8').replace(u'\0x96', '-')


    # In[8]:

    stockdatasqlist = ['CDELDT1','ARRV_AT_DEST_SC2','ConStatusDate2']
    print stockdatasqlist


    print stockdatasq['ARRV_AT_DEST_SC2'].values[0]
    print pd.unique(stockdatasq['CDELDT1'])
    print pd.unique(stockdatasq['ARRV_AT_DEST_SC2'])
    print pd.unique(stockdatasq['ConStatusDate2'])

    timeformat1 = '%d/%m/%Y %H:%M:%S %p'
    dayzero1 = '30/12/2011 00:00:00 AM'
    dayzero = datetime.strptime(dayzero1,timeformat1)

    stockdatasq.ConStatusDate2.fillna(dayzero1, inplace=True)

    def datestring(x):
        x = str(x)
        try:
            fulldate = datetime.strptime(x,'%m/%d/%Y %H:%M:%S %p')
            return fulldate
        except:
            fulldate = datetime.strptime(x,'%d/%m/%Y %H:%M:%S %p')
            return fulldate

    print stockdatasq['ARRV_AT_DEST_SC2'].values[0]

    for cols in stockdatasqlist:
        stockdatasq[cols] = stockdatasq.apply(lambda x:datestring(x[cols]),axis=1)


    with ExcelWriter(r'D:\Data\Shiv_closingstock_automation\SQ_bucket\Closingstock_SQ_Bucket_'+str(datefilter)+'.xlsx') as writer:
        #stockdatasq.to_excel(writer, sheet_name='FULL',engine='xlsxwriter')
        stockdatasq.to_excel(writer, sheet_name='Closingstock_SQ_Bucket',engine='xlsxwriter')

    oppath1 = r'D:\Data\Shiv_closingstock_automation\SQ_bucket\Closingstock_SQ_Bucket_'+str(datefilter)+'.xlsx'


    # In[9]:

    filePath1 = oppath1
    def sendEmail(TO = ["sq_spot@spoton.co.in"],
                  #TO = ["vishwas.j@spoton.co.in"],
                  #TO = ["anitha.thyagarajan@spoton.co.in"],
                 BCC =  ["mahesh.reddy@spoton.co.in"],
                FROM="mis.ho@spoton.co.in"):
        HOST = "smtp.spoton.co.in"
    #smtplib.SMTP('smtp.spoton.co.in', 25)

        msg = MIMEMultipart()
        msg["From"] = FROM
        msg["To"] = ",".join(TO)
        msg["BCC"] = ",".join(BCC)
        msg["Subject"] = "Closing Stock- SQ Bucket "+ str(datefilter)
        body_text = """
        Dear All,
        
        PFA the cons which belong to the SQ Bucket for """+str(datefilter)+"""
        
        """
        if body_text:
            msg.attach( MIMEText(body_text) )
        part = MIMEBase('application', "octet-stream")
        part.set_payload( open(filePath1,"rb").read() )
        Encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath1))
        msg.attach(part)
        server=smtplib.SMTP('smtp.sendgrid.net', 587)
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login("spoton.net.in", "Star@123#")

        try:
            failed = server.sendmail(FROM, TO+BCC, msg.as_string())
            server.close()
        except Exception, e:
            errorMsg = "Unable to send email. Error: %s" % str(e)

    if __name__ == "__main__":
        sendEmail()
    print('Email sent')

except:

  TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in'] 
  CC=['mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "Closing Stock- SQ Bucket Error in Execution" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in Closing Stock- SQ Bucket'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO+CC, msg.as_string())
  server.quit()

#Sending output file via mail ends

