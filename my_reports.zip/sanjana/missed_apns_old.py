
# coding: utf-8

# In[1]:

import pandas as pd
from datetime import datetime, timedelta
import numpy as np
from sqlalchemy import *
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

pd.set_option("display.max_columns",100)
# from fuzzywuzzy import fuzz
# from fuzzywuzzy import process


#2. Yesterday 6am APT appointments ie. appoinments which were due yesterday

try:
    engine = create_engine("mysql+pymysql://spotonhr:spoton54321@104.199.198.197/hourlyinventory")
    startdate="'"+datetime.strftime((datetime.now()-timedelta(days=1)),"%Y-%m-%d")+"'"
    enddate = "'"+datetime.strftime(datetime.now(),"%Y-%m-%d")+"'"
    enddate2 = "'"+datetime.strftime(datetime.now()+timedelta(hours=24),"%Y-%m-%d")+"'"
    yestdf=pd.read_sql("SELECT * FROM destsc WHERE `Timestate Date` >= {0} AND `Timestate Date` < {1} AND `Con Status Code`='APT' AND `Appointment Date` LIKE {2}".format(startdate,enddate,"'"+eval(startdate)+"%%")+"'",engine)
    doclist=yestdf["DOCKNO"].tolist()
    doclist2=tuple(str(tup) for tup in doclist)
    len(doclist)


    # In[3]:

    #3. Getting status from today's file
    todaydf=pd.read_sql("SELECT * FROM destsc WHERE `Timestate Date` >= {0} AND `Timestate Date` < {1} AND `DOCKNO` IN {2}".format(enddate,enddate2,str(doclist2)),engine)
    today=datetime.today().replace(hour=0,minute=0,second=0,microsecond=0)
    todaydf["Remarks"]=todaydf.apply(lambda x: "Rescheduled" if pd.isnull(x["Appointment Date"])==True or x["Appointment Date"]>=today else "Missed",axis=1)


    # In[5]:

    todaydf


    # In[15]:

    #4. Getting Report
    yestdf=yestdf.merge(todaydf.loc[:,["DOCKNO","Remarks"]],on="DOCKNO",how="left")
    yestdf["Remarks"]=yestdf["Remarks"].fillna("Delivered")
    perfpivot=yestdf.loc[:,["DEST DEPOT","Remarks","DOCKNO"]].pivot_table(index=["DEST DEPOT"],columns=["Remarks"],aggfunc={"DOCKNO": len},margins=True)#.fillna(0.0)#.sort_values(("DOCKNO","All"),ascending=False)
    try:
        perfpivot["Delivery%"]=perfpivot.apply(lambda x: np.round(x[("DOCKNO","Delivered")]*100.0/(x[("DOCKNO","All")]),1),axis=1)
    except:
        pass


    # In[17]:

    try:
        perfpivot[("DOCKNO","Delivered")]=perfpivot[("DOCKNO","Delivered")].astype(int)
        perfpivot[("DOCKNO","All")]=perfpivot[("DOCKNO","All")].astype(int)
    except:
        pass
    try:
        perfpivot[("DOCKNO","Rescheduled")]=perfpivot[("DOCKNO","Rescheduled")].astype(int)
    except:
        pass
    try:
        perfpivot[("DOCKNO","Missed")]=perfpivot[("DOCKNO","Missed")].astype(int)
    except:
        pass


    # In[18]:

    filepath1=r'D:\Data\Appointment Reports\APT_Missed\undels.csv'
    filepath3=r'D:\Data\Appointment Reports\undels.csv'
    try:
        todaydf.to_csv(filepath1)
    except:
        todaydf.to_csv(filepath3)


    # In[19]:

    print (todaydf)
    #send_email(["ankit@iepfunds.com","supratim@iepfunds.com","pawan.sharma@spoton.co.in","krishna.chandrasekar@spoton.co.in","abhik.mitra@spoton.co.in","vishwas.j@spoton.co.in","nikhil.saxena@spoton.co.in", "jothi.menon@spoton.co.in","sharmistha.majumdar@spoton.co.in","sq_spot@spoton.co.in", "aom_spot@spoton.co.in", "dom_spot@spoton.co.in", "rom_spot@spoton.co.in","ganesh.m@spoton.co.in","vinit.tiwari@spoton.co.in"])

    perfpivot1=perfpivot.fillna(0)
    # In[ ]:


    from datetime import date,timedelta
    todate=date.today()-timedelta(1)
    today_date=datetime.strftime(todate,'%d-%m-%Y')
    today_date
    #vishwas.j@spoton.co.in


    #TO=['mahesh.reddy@spoton.co.in']
    TO=['pawan.sharma@spoton.co.in','krishna.chandrasekar@spoton.co.in','abhik.mitra@spoton.co.in','vishwas.j@spoton.co.in','jothi.menon@spoton.co.in','sharmistha.majumdar@spoton.co.in','sq_spot@spoton.co.in','aom_spot@spoton.co.in','dom_spot@spoton.co.in','rom_spot@spoton.co.in','ganesh.m@spoton.co.in','vinit.tiwari@spoton.co.in','mani.kumar@spoton.co.in']
    FROM="reports.ie@spoton.co.in"
    # CC=[]
    BCC=['mahesh.reddy@spoton.co.in']
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    # msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    msg["Subject"] = "APT Deliveries - Performance Report for yesterday" + " - " + str(today_date)


    #s = Template(html).safe_substitute(mktcostperc=mktcostperc,mktcpk=mktcpk,mktspend=mktspend,mktcpky=mktcpky,mktspendy=mktspendy,date=today_date)
    report=""
    #report+=s
    report+='<br>'
    report+='<br>'+perfpivot1.to_html()+'<br>'
    #report+=html3
    #depotpivot_std
    abc=MIMEText(report,'html')
    msg.attach(abc)
    # part = MIMEBase('application', "octet-stream")
    # part.set_payload( open(filepath1,"rb").read() )
    # encoders.encode_base64(part)
    # part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
    # msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO+BCC, msg.as_string())
    server.quit()

except:
  TO=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  #msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "ERROR Report" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in APT Deliveries - Performance Report for yesterday'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO, msg.as_string())
  server.quit()





