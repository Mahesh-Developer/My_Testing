
# coding: utf-8

# In[1]:

import pandas as pd
from datetime import datetime, timedelta, date
import glob
import os
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from pandas import ExcelWriter
import sys
from email import encoders


# In[2]:

path =r'D:\Data\Pickups_yesterday' # use your path
allFiles = glob.glob(path + "/*.csv")
frame = pd.DataFrame()
list_ = []
for file_ in allFiles:
    df = pd.read_csv(file_,index_col=None, header=0)
    list_.append(df)
frame = pd.concat(list_)
frame.to_csv(r'D:\Data\Pickups_CTP.csv')
print len(frame)


# In[3]:

pickupdataglob = pd.read_csv(r'D:\Data\Pickups_CTP.csv')
customerdiffmaster = pd.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\Customer_diff_master_allqs.csv')


# In[4]:

def datestring(x):
    try:    
        fulldate = datetime.strptime(x.split(' ')[0], '%Y-%m-%d').date()
        return fulldate
    except:
        fulldate = datetime.strptime(x.split(' ')[0], '%d/%m/%Y').date()
        return fulldate
        


# In[5]:

pickupdataglob['Date'] = pickupdataglob.apply(lambda x:datestring(x['Pickup_date']),axis=1)


# In[6]:

pickupdataglobgrp = pickupdataglob.groupby(['CUSTOMERCODE']).agg({'Date':max}).reset_index()


# In[7]:

now = datetime.now()
yestday = now-timedelta(hours=24)
yestdate = yestday.date()
pickupdataglobgrp.loc[pickupdataglobgrp.index,'Date_yesterday'] = yestdate


# In[8]:

def datediffcalc(yesterdate,pickupdate):
    datediff = (yesterdate-pickupdate).days
    if datediff==0:
        return 0
    else:
        return (datediff-1)


# In[9]:

pickupdataglobgrp['Date_diff'] = pickupdataglobgrp.apply(lambda x:datediffcalc(x['Date_yesterday'],x['Date']),axis=1)
len(pickupdataglobgrp)


# In[10]:

pickupdataglobgrpmerge = pd.merge(pickupdataglobgrp,customerdiffmaster,on=['CUSTOMERCODE'],how='inner')


# In[11]:

def triggerflag(diffdays,masteravg):
    if diffdays > masteravg:
        return 'YES'
    else:
        return 'NO'


# In[14]:

pickupdataglobgrpmerge['Trigger'] = pickupdataglobgrpmerge.apply(lambda x:triggerflag(x['Date_diff'],x['Avg_Diff']),axis=1)
pickupdataglobgrpmerge = pickupdataglobgrpmerge.sort_values('Avg_Wt_perday',ascending=False)
pickupdataglobgrpmerge =pickupdataglobgrpmerge.rename(columns={'Date':'Last_traded_date','AccountTypeNew':'AccountType'})
pickupdataglobgrpmergeyes = pickupdataglobgrpmerge[pickupdataglobgrpmerge['Trigger']=='YES']

columnsop = ['CUSTOMERCODE','CUSTOMERNAME','AccountType','Last_traded_date','Date_diff','Avg_Diff','Avg_Wt_perday']
pickupdataglobgrpmergeyes = pd.DataFrame(pickupdataglobgrpmergeyes,columns=columnsop)
pickupdataglobgrpmergeyes


# In[ ]:
yesterdate=date.today()-timedelta(hours=24)
pickupdataglobgrpmergeyes.to_csv(r'D:\Data\Customer_trading_frequency_trigger\Trading_pattern_trigger_'+str(yesterdate)+'.csv')

oppath1 = r'D:\Data\Customer_trading_frequency_trigger\Trading_pattern_trigger_'+str(yesterdate)+'.csv'

filePath = oppath1
def sendEmail(#TO = ["supratim@iepfunds.com","rajeesh.vr@spoton.co.in"],
            TO = ["vishwas.j@spoton.co.in"],
            #CC = ["vishwas.j@spoton.co.in"],
            CC = ["vishwas.j@spoton.co.in"],
            #BCC = ["vishwas.j@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "Sales Trigger Report" + '_' + str(yesterdate)
    body_text = """
    Dear All,
    
    PFA the Sales Trigger Report as of """+str(yesterdate)+"""
    
    The data attached has the list of customers whose trading days is greater than the average difference days in customer master
    

    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends
