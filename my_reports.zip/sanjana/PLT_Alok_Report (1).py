
# coding: utf-8

# In[ ]:

import pandas as pd
import numpy as np
import pyodbc
from datetime import datetime,timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
import ftplib
# import Utilities
from calendar import monthrange
import smtplib


# In[ ]:

cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()


# In[ ]:

yestdate=datetime.strftime(datetime.now()-timedelta(days=1),"%Y-%m-%d")
yestdate


# In[ ]:

query=("""SELECT  BR.RGALPH ,
        BR.DEPOT_CODE ,
        BR.BRCD ,
        BR.BRNM ,
        PH.SheetType ,
        PH.SheetNo ,
        tc.ConNo ,
        PC.PcsNo ,
        PC.excepType ,
        PC.excpDtls ,
        PC.scanTime ,
        PC.scannedby ,
        PC.scannedEmpCode ,
        PH.FinalSubmitDate
FROM    dbo.tblPLTAPIHDR PH WITH ( NOLOCK )
        INNER JOIN dbo.tblPLTAPICONDtls tc WITH ( NOLOCK ) ON tc.PLTHDRID = PH.AutoID
        INNER JOIN dbo.tblPLTAPIPcsDtls PC WITH ( NOLOCK ) ON PC.PLTHDRID = PH.AutoID AND PC.ConNo = TC.ConNo
        INNER JOIN dbo.brms BR WITH ( NOLOCK ) ON BR.BRCD = PH.SCCode
WHERE   PH.RequestDate BETWEEN '{0}'
                       AND     '{1}'
        --AND PC.excepType = 'PPS'

 """).format(yestdate+' 00:00:00',yestdate+' 23:59:00')


# In[ ]:

df=pd.read_sql(query,cnxn)


# In[ ]:

len(df)


# In[ ]:

df['Date']=yestdate


# In[ ]:

cons_summary=df.pivot_table(index=['Date','ConNo'],values=['PcsNo'],aggfunc={'PcsNo':len}).reset_index()


# In[ ]:

total_Cons_pcs=cons_summary.pivot_table(index=['Date'],values=['ConNo','PcsNo'],aggfunc={'ConNo':len,'PcsNo':sum}).reset_index()


# In[ ]:

total_Cons_pcs


# In[ ]:

shotarge_cons=df[(df['excepType']=='PPS')]


# In[ ]:

shotarge_cons


# In[ ]:

shotarge_cons_summary=shotarge_cons.pivot_table(index=['Date','ConNo'],values=['PcsNo'],aggfunc={'PcsNo':len}).reset_index()


# In[ ]:

total_shortage_summary=shotarge_cons_summary.pivot_table(index=['Date'],values=['ConNo','PcsNo'],aggfunc={'ConNo':len,'PcsNo':sum}).reset_index()


# In[ ]:

total_shortage_summary.rename(columns={'ConNo':'PLT_Short_Cons','PcsNo':'PLT_Short_Pcs'},inplace=True)


# In[ ]:

total_shortage_summary


# In[ ]:

final_summary=pd.merge(total_Cons_pcs,total_shortage_summary,on=['Date'],how='outer')


# In[ ]:

final_summary


# In[ ]:

df.columns


# In[ ]:

not_scanned_pcs=df[df['scanTime'].isnull()].pivot_table(index=['Date'],values=['PcsNo'],aggfunc={'PcsNo':len}).reset_index()


# In[ ]:

not_scanned_pcs.rename(columns={'PcsNo':'Not_Scanned'},inplace=True)


# In[ ]:

final_summary=pd.merge(final_summary,not_scanned_pcs,on=['Date'],how='outer')


# In[ ]:

final_summary


# In[ ]:

final_summary['Total_Scanned']=final_summary['PcsNo']-final_summary['Not_Scanned']


# In[ ]:

final_summary['Scanned_(%)']=pd.np.round(final_summary['Total_Scanned']*100.0/final_summary['PcsNo'],1)


# In[ ]:

final_summary


# In[ ]:

final_summary['TOT(%)_of_Piece_Shortage']=pd.np.round(final_summary['PLT_Short_Pcs']*100.0/final_summary['PcsNo'],3)


# In[ ]:

final_summary['TOT(%)_of_Con_Shortage']=pd.np.round(final_summary['PLT_Short_Cons']*100.0/final_summary['ConNo'],3)


# In[ ]:

final_summary


# In[ ]:

top_locations=shotarge_cons.pivot_table(index=['Date','BRCD'],aggfunc={'PcsNo':len}).reset_index().sort_values('PcsNo',ascending=False).head(6)


# In[ ]:

top_locations['TOP_5_SHORTAGE_CONTRIBUTOR']=top_locations.apply(lambda x:{x['BRCD']:x['PcsNo']},axis=1)


# In[ ]:

top_locations_summary=top_locations.pivot_table(index=['Date'],aggfunc={'TOP_5_SHORTAGE_CONTRIBUTOR':lambda x:x.to_dict()}).reset_index()


# In[ ]:

top_locations_summary


# In[ ]:

final_summary=pd.merge(final_summary,top_locations_summary,on=['Date'],how='outer')


# In[ ]:

final_summary.rename(columns={'ConNo':'Total_Cons','PcsNo':'Total_Pieces'},inplace=True)


# In[ ]:

final_summary.columns


# In[ ]:

final_summary


# In[ ]:

final_summary1=final_summary[['Date','Total_Cons','Total_Pieces','Total_Scanned','Scanned_(%)','PLT_Short_Cons','PLT_Short_Pcs','TOT(%)_of_Con_Shortage',
              'TOT(%)_of_Piece_Shortage','TOP_5_SHORTAGE_CONTRIBUTOR']]


# In[ ]:

final_summary_daily=pd.read_excel(r'D:\Data\Daily_Alok_PLT_Report\Daily_PLY_Summary.xlsx')


# In[ ]:

final_summary_daily=pd.concat([final_summary1,final_summary_daily],ignore_index=True)


# In[ ]:

final_summary_daily.to_excel(r'D:\Data\Daily_Alok_PLT_Report\Daily_PLY_Summary.xlsx')


# In[ ]:

final_summary_daily


# In[ ]:

final_summary2=final_summary_daily[['Date','Total_Cons','Total_Pieces','Total_Scanned','PLT_Short_Cons','PLT_Short_Pcs']]


# In[ ]:

final_summary4=pd.concat([final_summary3,final_summary2],ignore_index=True)


# In[ ]:

final_summary2


# In[ ]:

final_summary2.loc['Total']=final_summary2[['Total_Cons','Total_Pieces','Total_Scanned','PLT_Short_Cons','PLT_Short_Pcs']].sum(axis=0)


# In[ ]:

final_summary4.columns


# In[ ]:

final_summary2['TOT(%)_of_Piece_Shortage']=pd.np.round(final_summary2['PLT_Short_Pcs']*100.0/final_summary2['PLT_Short_Pcs'],3)
final_summary2['TOT(%)_of_Con_Shortage']=pd.np.round(final_summary2['PLT_Short_Cons']*100.0/final_summary2['PLT_Short_Cons'],3)


# In[ ]:

final_summary3=final_summary2[final_summary2.index=='Total']


# In[ ]:

final_summary_daily=pd.concat([final_summary_daily,final_summary3],ignore_index=True)


# In[ ]:

final_summary_daily=final_summary_daily.fillna(0)


# In[ ]:

final_summary_daily=final_summary_daily[['Date','Total_Cons','Total_Pieces','Total_Scanned','Scanned_(%)','PLT_Short_Cons','PLT_Short_Pcs','TOT(%)_of_Con_Shortage',
              'TOT(%)_of_Piece_Shortage','TOP_5_SHORTAGE_CONTRIBUTOR']]


# In[ ]:

final_summary_daily


# In[ ]:

final_summary_daily.sort_values('Total_Cons',ascending=False,inplace=True)


# In[ ]:

import sys
reload(sys)


# In[ ]:

sys.setdefaultencoding("utf8")


# In[ ]:

# final_summary1.to_csv(r'Summary.csv')


# In[ ]:

filepath=r'D:\Data\Daily_Alok_PLT_Report\Daily_PLY_Summary.xlsx'


# In[ ]:

TO=['mahesh.reddy@spoton.co.in',"alok.b@spoton.co.in"]
CC=['satya.pal@spoton.co.in','abhik.mitra@spoton.co.in','shivananda.p@spoton.co.in']
FROM="reports.ie@spoton.co.in"
# FROM="mahesh.reddy@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "PLT Short Count Trend 1st " + " - " + str(yestdate)

report=""
report+="Dear Team,"
report+='<br>'
report+='Please find the shortage trend count of '+str(yestdate)+' for your reference…..'
report+='<br>'
report+='<br>'
report+='<br>'+final_summary_daily.to_html()+'<br>'
report+='<br>'

abc=MIMEText(report.encode('utf-8'),'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)


# server=smtplib.SMTP('smtp.sendgrid.net', 587)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("mahesh.reddy@spoton.co.in", "Nov@2018")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()


# In[ ]:



