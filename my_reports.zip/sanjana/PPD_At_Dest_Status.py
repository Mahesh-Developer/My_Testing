
# coding: utf-8

# In[ ]:


import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
import Utilities

# In[ ]:

#cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")

try:
    query =("""EXEC USP_PART_PIECE_AT_DESTN_SQ""")


    # In[ ]:


    df=pd.read_sql(query,Utilities.cnxn)


    # In[ ]:


    #df=pd.read_csv(r'/home/mahesh/Documents/USP_PART_PIECE_AT_DESTN_SQ.csv')


    # In[ ]:


    df.rename(columns={'destareaname':'Dest Area'},inplace=True)


    # In[ ]:


    ppd_raised_df=df[df['PPD_REQUEST_RAISED']=='YES']
    len(ppd_raised_df)


    # In[ ]:


    pending_ppd_df=ppd_raised_df[ppd_raised_df['ApprovalStatus']=='P']
    len(pending_ppd_df)


    # In[ ]:


    area_pending_ppd_df=pending_ppd_df.pivot_table(index=['Dest Area'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').reset_index()


    # In[ ]:


    area_pending_ppd_df['DOCKNO']=area_pending_ppd_df['DOCKNO'].astype(int)


    # In[ ]:


    area_pending_ppd_df1=area_pending_ppd_df.sort_values('DOCKNO',ascending=False)


    # In[ ]:


    area_pending_ppd_df1.head()


    # In[ ]:


    branch_pending_ppd_df=pending_ppd_df.pivot_table(index=['REASSIGN_DESTCD'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').reset_index()


    # In[ ]:


    branch_pending_ppd_df['DOCKNO']=branch_pending_ppd_df['DOCKNO'].astype(int)


    # In[ ]:


    branch_pending_ppd_df1=branch_pending_ppd_df.sort_values('DOCKNO',ascending=False)


    # In[ ]:


    branch_pending_ppd_df1.head()


    # In[ ]:


    approved_ppd_df=ppd_raised_df[ppd_raised_df['ApprovalStatus']=='A']
    len(approved_ppd_df)


    # In[ ]:


    approved_ppd_df['ApprovalOn']=pd.to_datetime(approved_ppd_df['ApprovalOn'])
    approved_ppd_df['CreatedOn']=pd.to_datetime(approved_ppd_df['CreatedOn'])


    def getDate(aprhrs,crshrs):
        if pd.isnull(aprhrs):
            return crshrs
        else:
            return aprhrs

    approved_ppd_df['Changed_Time']=approved_ppd_df.apply(lambda x:getDate(x['ApprovalOn'],x['CreatedOn']),axis=1)


    approved_ppd_df['Timestamp']=datetime.now()


    # In[ ]:


    approved_ppd_df['Bucket']=(approved_ppd_df['Timestamp']-approved_ppd_df['Changed_Time']).astype('timedelta64[h]')


    # In[ ]:


    #approved_ppd_df=approved_ppd_df.fillna('-')


    # In[ ]:


    def getRange(hrs):
        
        if hrs<24:
            return '<24 Hrs'
        elif ((hrs>24) & (hrs<48)):
            return '>24-<48 Hrs'
        elif ((hrs>48) & (hrs<72)):
            return '>48-<72 Hrs'
        else:
            return '>72 Hrs'


    # In[ ]:


    approved_ppd_df['Bucket Hours']=approved_ppd_df.apply(lambda x: getRange(x['Bucket']),axis=1)


    # In[ ]:


    #approved_ppd_df['Bucket']=approved_ppd_df['Bucket'].astype(str)


    # In[ ]:


    area_approved_ppd_df=approved_ppd_df.pivot_table(index=['Dest Area'],columns=['Bucket Hours'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').reset_index()


    # In[ ]:


    area_approved_ppd_df=area_approved_ppd_df.fillna(0)


    # In[ ]:


    area_approved_ppd_df['DOCKNO']=area_approved_ppd_df['DOCKNO'].astype(int)


    # In[ ]:


    area_approved_ppd_df.head()


    # In[ ]:


    branch_approved_ppd_df=approved_ppd_df.pivot_table(index=['REASSIGN_DESTCD'],columns=['Bucket Hours'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').reset_index()


    # In[ ]:


    branch_approved_ppd_df=branch_approved_ppd_df.fillna(0)


    # In[ ]:


    branch_approved_ppd_df['DOCKNO']=branch_approved_ppd_df['DOCKNO'].astype(int)


    # In[ ]:


    branch_approved_ppd_df.head()


    # In[ ]:


    today=datetime.strftime(datetime.now(),'%Y-%m-%d')
    today


    # In[ ]:


    with ExcelWriter(r'D:\Data\PPD Approve_Pending\PPD_At_Dest_Pending'+str(today)+'.xlsx') as writer:
        area_pending_ppd_df.to_excel(writer, sheet_name='Area Wise Summary',engine='xlsxwriter')
        branch_pending_ppd_df.to_excel(writer, sheet_name='Branch Wise Summary',engine='xlsxwriter')
        pending_ppd_df.to_excel(writer,sheet_name='PPD Status Pending Con Data',engine='xlsxwriter')   


    # In[ ]:


    with ExcelWriter(r'D:\Data\PPD Approve_Pending\PPD_At_Dest_Approved'+str(today)+'.xlsx') as writer:
        area_approved_ppd_df.to_excel(writer, sheet_name='Area Wise Summary',engine='xlsxwriter')
        branch_approved_ppd_df.to_excel(writer, sheet_name='Branch Wise Summary',engine='xlsxwriter')
        approved_ppd_df.to_excel(writer,sheet_name='PPD Status Approved Con Data',engine='xlsxwriter')   


    # In[ ]:


    with ExcelWriter(r'D:\Data\PPD Approve_Pending\PPD_At_Dest_Pending.xlsx') as writer:
        area_pending_ppd_df.to_excel(writer, sheet_name='Area Wise Summary',engine='xlsxwriter')
        branch_pending_ppd_df.to_excel(writer, sheet_name='Branch Wise Summary',engine='xlsxwriter')
        pending_ppd_df.to_excel(writer,sheet_name='PPD Status Pending Con Data',engine='xlsxwriter')   


    # In[ ]:


    with ExcelWriter(r'D:\Data\PPD Approve_Pending\PPD_At_Dest_Approved.xlsx') as writer:
        area_approved_ppd_df.to_excel(writer, sheet_name='Area Wise Summary',engine='xlsxwriter')
        branch_approved_ppd_df.to_excel(writer, sheet_name='Branch Wise Summary',engine='xlsxwriter')
        approved_ppd_df.to_excel(writer,sheet_name='PPD Status Approved Con Data',engine='xlsxwriter')   


    # In[ ]:


    filepath=r'D:\Data\PPD Approve_Pending\PPD_At_Dest_Approved.xlsx'
    filepath1=r'D:\Data\PPD Approve_Pending\PPD_At_Dest_Pending.xlsx'


    # In[ ]:


    FROM='mis.ho@spoton.co.in'

    TO=["dom_spot@spoton.co.in","rom_spot@spoton.co.in","aom_spot@spoton.co.in",'scincharge_spot@spoton.co.in',"SQ_SPOT@spoton.co.in"]
    CC=['sqtf@spoton.co.in','rajesh.kumar@spoton.co.in','abhik.mitra@spoton.co.in','jothi.menon@spoton.co.in','shivananda.p@spoton.co.in']
    BCC=['mahesh.reddy@spoton.co.in']
    #TO=['mahesh.reddy@spoton.co.in']
    #CC=['mahesh.reddy@spoton.co.in']
    #BCC=['mahesh.reddy@spoton.co.in']

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "Approved & Pending PPD Cons Lying At Destination -" + str(today)

    report=""
    report+='Dear All,'
    report+='<br>'
    report+='<br>'
    report+='PFA Approved & Pending PPD Cons Lying At Destination'
    report+='<br>'
    report+='<br>'
    #report+='Total PPD Request Raised Cons :'+str(len(ppd_raised_df))
    #report+='<br>'
    #report+='<br>'
    report+='Approval Pending PPD Cons AreaWise Summary'
    report+='<br>'
    report+='<br>'+area_pending_ppd_df1.to_html()+'<br>'
    report+='<br>'
    report+='<br>'
    report+='Approved PPD Cons AreaWise Summary'
    report+='<br>'
    report+='<br>'+area_approved_ppd_df.to_html()+'<br>'



    #report+=html3
    abc=MIMEText(report,'html')
    msg.attach(abc)

    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filepath,"rb").read() )
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
    msg.attach(part)

    part1 = MIMEBase('application', "octet-stream")
    part1.set_payload( open(filepath1,"rb").read() )
    encoders.encode_base64(part1)
    part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
    msg.attach(part1)


    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
    server.quit()

except:

  TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in'] 
  CC=['mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "Approved & Pending PPD Cons Lying At Destination Error in Execution" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in Approved & Pending PPD Cons Lying At Destination'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO+CC, msg.as_string())
  server.quit()


