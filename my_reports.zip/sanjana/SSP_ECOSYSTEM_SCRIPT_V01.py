
# coding: utf-8

# In[2]:


import numpy as np
import pandas as pd
# import matplotlib.pyplot as plt
# import seaborn
from glob import glob
from IPython import display
from datetime import datetime,timedelta, date
import pyodbc
# import geopy
import pandas as pd
import Utilities


# In[3]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


# In[4]:


yest=datetime.now()-timedelta(1)
enddate=yest.date()
enddate=str(enddate)+' 23:59:00'
enddate

startdate=datetime.strftime((datetime.today().replace(day=1,month=1,year=2019)),'%Y-%m-%d')
# startdate


# In[5]:


enddate,startdate


# In[9]:


T1_short= '''
DECLARE @date AS SMALLDATETIME
DECLARE @todate AS SMALLDATETIME
SET @date ='{0}'
SET @todate = '{1}'   


--Short Creation
SELECT CONVERT(DATE,CONStatusDate) SHORT_DATE, COUNT(*) SHORT_CONS, SUM(DEPSPcs) SHORT_PCS  
FROM dbo.tblCONStatusCodes WHERE CONStatusDate >= @date AND CONStatusDate < @todate AND CONStatusCode ='SRS'
GROUP BY CONVERT(DATE,CONStatusDate)
ORDER BY 1'''.format(startdate,enddate)
TABLE1=pd.read_sql(T1_short,Utilities.cnxn)

############## adding days to date ##############
TABLE1['SHORT_DATE']=pd.to_datetime(TABLE1['SHORT_DATE'])

TABLE1['SHORT_DATE1']=TABLE1['SHORT_DATE'].apply(lambda x:(datetime.strftime(x,'%A')[:3]))

TABLE1['SHORT_DATE']=TABLE1['SHORT_DATE'].astype(str)+' '+TABLE1['SHORT_DATE1']

# TABLE1

###############  E n d ####################
TABLE1.rename(columns={'SHORT_DATE':'DATE'}, inplace=True)
# TABLE1

T1=TABLE1[['DATE','SHORT_CONS']]
# T1


# In[25]:


T2_ppm= '''
DECLARE @date AS SMALLDATETIME
DECLARE @todate AS SMALLDATETIME
SET @date ='{0}'
SET @todate ='{1}' 
-- PPM Movement
SELECT CONVERT(DATE,CONStatusDate) PPM_DATE, COUNT(*) PPM_CONS 
FROM dbo.tblCONStatusCodes 
WHERE CONStatusDate >= @date AND  CONStatusDate < @todate  AND CONStatusCode ='PPM'
GROUP BY CONVERT(DATE,CONStatusDate)
ORDER BY 1
'''.format(startdate,enddate)
TABLE2=pd.read_sql(T2_ppm,Utilities.cnxn)

############## adding days to date ##############
TABLE2['PPM_DATE']=pd.to_datetime(TABLE2['PPM_DATE'])
TABLE2['PPM_DATE1']=TABLE2['PPM_DATE'].apply(lambda x:(datetime.strftime(x,'%A')[:3]))
TABLE2['PPM_DATE']=TABLE2['PPM_DATE'].astype(str)+' '+TABLE2['PPM_DATE1']

###############  E n d ####################




TABLE2.rename(columns={'PPM_DATE':'DATE'}, inplace=True)
# TABLE2
T2=TABLE2[['DATE','PPM_CONS']]
# T2


# In[26]:


T3_ppA= '''
DECLARE @date AS SMALLDATETIME
DECLARE @todate AS SMALLDATETIME
SET @date ='{0}'
SET @todate ='{1}' 

-- PPA 
SELECT CONVERT(DATE,CreatedOn) CREATED_DATE,  COUNT(*) Total_Rqst,

COUNT(CASE WHEN (ApprStatus = 'A') THEN Dockno END ) 'Approved',

COUNT(CASE WHEN (ApprStatus = 'R') THEN Dockno END ) 'Rejected',

COUNT(CASE WHEN (ApprStatus IN ('P','N')) THEN Dockno END ) 'Pending'

FROM dbo.tblHubPartPcsAppRequest WHERE CreatedOn >= @date AND CreatedOn < @todate

GROUP BY CONVERT(DATE,CreatedOn)

ORDER BY 1
'''.format(startdate,enddate)
TABLE3=pd.read_sql(T3_ppA,Utilities.cnxn)


############## adding days to date ##############
TABLE3['CREATED_DATE']=pd.to_datetime(TABLE3['CREATED_DATE'])
TABLE3['CREATED_DATE1']=TABLE3['CREATED_DATE'].apply(lambda x:(datetime.strftime(x,'%A')[:3]))
TABLE3['CREATED_DATE']=TABLE3['CREATED_DATE'].astype(str)+' '+TABLE3['CREATED_DATE1']

###############  E n d ####################


TABLE3.rename(columns={'CREATED_DATE':'DATE','Approved':'PPA CONS'}, inplace=True)
# TABLE3
T3=TABLE3[['DATE','PPA CONS']]
# T3


# In[39]:


T4_netwrk= '''
DECLARE @date AS SMALLDATETIME
DECLARE @todate AS SMALLDATETIME
SET @date ='{0}' 
SET @todate ='{1}' 
--- Network & Destn Part Pieces Stock
SELECT  DATE, COUNT(CASE WHEN (aa.Location ='At Network') THEN 1 END )'At Network' ,
COUNT(CASE WHEN (aa.Location ='At Destn') THEN 1 END )'At Destn' --,AA.Location, 
--COUNT(*) CONS 
FROM ( 
SELECT  DISTINCT
        A.DOCKNO ,
        CONVERT(DATE,GETDATE())DATE ,
        --CONVERT(DATE,CONStatusDate) A.DOCKDT,
        CASE WHEN ( A.DOC_CURLOC = A.REASSIGN_DESTCD ) THEN 'At Destn'
             ELSE 'At Network'
        END 'Location'
        --INTO    #TMPUNDELCONS    
FROM    dbo.DOCKET A WITH ( NOLOCK )
        LEFT OUTER JOIN dbo.DKT_DELY D WITH ( NOLOCK ) ON A.DOCKNO = D.DOCKNO
        LEFT OUTER JOIN dbo.tblDocketFinalStatus C WITH ( NOLOCK ) ON A.DOCKNO = C.DOCKNO
        LEFT OUTER JOIN dbo.CO_Mail_Account COM WITH ( NOLOCK ) ON A.CSGNCD = COM.PTMSPTCD
        INNER JOIN dbo.PCR_PIECES_Detail PC WITH ( NOLOCK ) ON PC.Dockno = A.DOCKNO AND    PC.isActive = 1
WHERE   A.DOCKDT >= '2018-01-01'
        AND A.PAYBAS NOT IN ( '6' )
        AND D.DELY_DT IS NULL
        AND C.DOCKNO IS NULL
        AND COM.PTMSPTCD IS NULL
        AND PC.pcs_curloc <> A.DOC_CURLOC 
) AA
GROUP BY DATE


'''.format(startdate,enddate)
TABLE4=pd.read_sql(T4_netwrk,Utilities.cnxn)
TABLE4.rename(columns={'At Network':'NETWORK','At Destn':'DESTINATION'}, inplace=True)
# TABLE4
T4=TABLE4
T4['DATE']=datetime.strftime(datetime.now()-timedelta(1),"%Y-%m-%d")

T4


# In[40]:


# A='2018-11-02 00:00:00'
# A.split(' ')[0]


# In[42]:


###### since only today's data appears for table 4, past data is exported from an excel sheet,   ####
########### the two dataframes are then concatenated #########

T4_netwrk_excel=r'D:\Python\Scripts and Files\Python Scripts\Netwrk_Data_till5.xlsx'


# In[43]:


T4_ex=pd.read_excel(T4_netwrk_excel)
T4_ex


# In[47]:


T4_ex['DATE'] = T4_ex['DATE'].dt.date
T4_ex


# In[48]:


# T4


# In[49]:


# T4_con1= pd.concat([T4_ex,T4])
# T4_con1

T4_con1= T4_ex.append(T4)
T4_con1


# In[51]:


from pandas import ExcelWriter
with ExcelWriter(r"D:\Python\Scripts and Files\Python Scripts\Netwrk_Data_till5.xlsx") as writer:
    T4_con1.to_excel(writer, sheet_name='Data',engine='xlsxwriter')
print('file created')

T4_concat_excel=r'D:\Python\Scripts and Files\Python Scripts\Netwrk_Data_till5.xlsx'
T4_concat=pd.read_excel(T4_concat_excel)
# T4_con['DATE'] = T4_con['DATE'].dt.date


# In[52]:


############## adding days to date ##############
T4_concat['DATE']=pd.to_datetime(T4_concat['DATE'])
T4_concat['DATE1']=T4_concat['DATE'].apply(lambda x:(datetime.strftime(x,'%A')[:3]))
T4_concat['DATE']=T4_concat['DATE'].astype(str)+' '+T4_concat['DATE1']
T4_concat

###############  E n d ####################


# In[53]:


T4_con=T4_concat[["DATE","NETWORK","DESTINATION"]]

T4_con


# In[55]:


T5_ppD= '''
DECLARE @date AS SMALLDATETIME
DECLARE @todate AS SMALLDATETIME
SET @date ='{0}' 
SET @todate ='{1}' 

-- PPD Deliveries 
SELECT CONVERT(DATE,dely_dt) DELDATE, COUNT(*) 
FROM dbo.dkt_dely_extra 
WHERE dely_dt >= @date AND dely_dt < @todate
GROUP BY CONVERT(DATE,dely_dt)
ORDER BY 1

'''.format(startdate,enddate)
TABLE5=pd.read_sql(T5_ppD,Utilities.cnxn)
TABLE5.rename(columns={'DELDATE':'DATE','':'PPD - DRS'}, inplace=True)


# In[56]:


############## adding days to date ##############
TABLE5['DATE']=pd.to_datetime(TABLE5['DATE'])
TABLE5['DATE1']=TABLE5['DATE'].apply(lambda x:(datetime.strftime(x,'%A')[:3]))
TABLE5['DATE']=TABLE5['DATE'].astype(str)+' '+TABLE5['DATE1']
TABLE5
###############  E n d ####################


# In[57]:


# TABLE5
T5=TABLE5[['DATE','PPD - DRS']]
T5


# In[58]:


T6_pod= '''
DECLARE @date AS SMALLDATETIME
DECLARE @todate AS SMALLDATETIME
SET @date ='{0}'
SET @todate ='{1}' 
-- BAD POD Shortage & Theft
SELECT  AA.BADPOD_DATE ,
        COUNT(CASE WHEN ( AA.CAT_TYPE = 'SHORTAGE' ) THEN 1
              END) 'SHORTAGE' ,
        COUNT(CASE WHEN ( AA.CAT_TYPE = 'THEFT' ) THEN 1
              END) 'THEFT'
FROM    ( SELECT    CONVERT(DATE, PVL.ViewDate) BADPOD_DATE ,
                    B.dockno CON_NUMBER ,
        --SV.StatusCategory [DOUBT_POD_CATEGORY] ,
                    CASE WHEN ( SV.StatusCategory IN ( 'Damge and Theft',
                                                       'Pilferage' ) )
                         THEN 'THEFT'
                         WHEN ( SV.StatusCategory IN ( 'Shortage' ) )
                         THEN 'SHORTAGE'
                    END 'CAT_TYPE' ,
                    SV.NoOfPcs DAMAGE_PCS ,
                    DKT.PKGSNO AS PIECES
          FROM      espeedage.dbo.SCAN_DOCKET B WITH ( NOLOCK )
                    INNER JOIN ESTL_CRP2.dbo.DKT_DELY DELY WITH ( NOLOCK ) ON B.dockno = DELY.DOCKNO
                    LEFT OUTER JOIN espeedage.dbo.tblPODValidatorLog PVL WITH ( NOLOCK ) ON PVL.DOCKNO = B.dockno
                    LEFT OUTER JOIN espeedage.dbo.Scan_Validator SV WITH ( NOLOCK ) ON SV.ConNo = B.dockno
                    INNER JOIN ESTL_CRP2.dbo.DOCKET DKT WITH ( NOLOCK ) ON DKT.DOCKNO = B.dockno
                    INNER JOIN dbo.brms DBR WITH ( NOLOCK ) ON DKT.DESTCD = DBR.BRCD
                    INNER JOIN dbo.brms ORG WITH ( NOLOCK ) ON DKT.ORGNCD = ORG.BRCD
          WHERE     PVL.ViewDate >= @date AND  PVL.ViewDate < @todate
                    AND StatusCategory IN ( 'Damge and Theft', 'Pilferage',
                                            'Shortage' )
        ) AA
GROUP BY AA.BADPOD_DATE
ORDER BY 1

'''.format(startdate,enddate)
TABLE6=pd.read_sql(T6_pod,Utilities.cnxn)
TABLE6.rename(columns={'BADPOD_DATE':'DATE','SHORTAGE':'BAD POD Short','THEFT':'BAD POD Theft'}, inplace=True)
# TABLE6


# In[59]:


############## adding days to date ##############
TABLE6['DATE']=pd.to_datetime(TABLE6['DATE'])
TABLE6['DATE1']=TABLE6['DATE'].apply(lambda x:(datetime.strftime(x,'%A')[:3]))
TABLE6['DATE']=TABLE6['DATE'].astype(str)+' '+TABLE6['DATE1']
TABLE6
###############  E n d ####################


# In[61]:


T6=TABLE6[['DATE','BAD POD Short','BAD POD Theft']]
T6a=TABLE6[['DATE','BAD POD Short']]
T6b=TABLE6[['DATE','BAD POD Theft']]
T6


# In[81]:


###################### MERGING DATA FRAMES AND MAKING PIVOTS ####################

################# CAUSE- MOVIE IN NETWORK ###########################################


# In[82]:


T123=pd.merge(T1,T2, how="outer", on="DATE")
T123=pd.merge(T123,T3, how="outer", on="DATE")
T123['']='Moved In Network'
T123[' ']='CAUSE'

# T123


# In[83]:


#######              DF1                  ######


# In[84]:


df1=T123.pivot_table(index=['DATE'],columns=['',' '],values = ['SHORT_CONS','PPM_CONS','PPA CONS'],
                     aggfunc={'SHORT_CONS':sum,'PPM_CONS':sum,'PPA CONS':sum})
df1.head()


# In[85]:


# df1.reset_index( inplace=True)

###################### CONVERTING DATE FROM STING TO 'DATE' TYPE ############

#df1['DATE'] = pd.to_datetime(df1['DATE']).dt.date
################# SWAPPING AXIS #################

DF1=df1.swaplevel(i=-3,j=-1,axis=1)

# DF1


# In[86]:


# DF1


# In[87]:


################### EFFECT- HIGH INVENTORY SHORT PCS ###########################


# In[88]:


T4M=T4_con
T4M['']='High Inventory Short Pcs'
T4M[' ']='EFFECT'
# T4M


# In[89]:


#######              DF2                  ######


# In[90]:


df2=T4M.pivot_table(index=['DATE'],columns=['',' '],values= ['NETWORK','DESTINATION'],
                     aggfunc={'NETWORK':sum,'DESTINATION':sum})
# df2.reset_index( inplace=True)

###################### CONVERTING DATE FROM STING TO 'DATE' TYPE ############

# df2.head()


# In[91]:


#df2['DATE'] = pd.to_datetime(df2['DATE']).dt.date

################# SWAPPING AXIS #################


DF2=df2.swaplevel(i=-3,j=-1,axis=1)
# DF2


# In[92]:


################### EFFECT- SHORT PCS DELVD TO CUSTOMER ###########################


# In[93]:


# T5.head(),T6a.head()


# In[94]:


T56a=pd.merge(T5,T6a, how="outer", on="DATE")

T56a['']='Short Pcs Delvd To Customer'
T56a[' ']='EFFECT'
# T56a


# In[95]:


#######              DF3                  ######


# In[96]:


df3=T56a.pivot_table(index=['DATE'],
                     columns=['',' '],
                     values=['PPD - DRS','BAD POD Short'],
                     aggfunc={'PPD - DRS':sum,'BAD POD Short':sum})
#df3.reset_index( inplace=True)

###################### CONVERTING DATE FROM STING TO 'DATE' TYPE ############

#df3['DATE'] = pd.to_datetime(df3['DATE']).dt.date
#type(df3['DATE'].values[0])

################# SWAPPING AXIS #################

DF3=df3.swaplevel(i=-3,j=-1,axis=1)
# DF3.head()


# In[97]:


################### EFFECT- Increased Theft in N/W###########################


# In[98]:


T6BM=T6b
T6BM['']='Increased Theft in N/W'
T6BM[' ']='EFFECT'
# T6BM


# In[99]:


#######              DF4                  ######


# In[100]:


df4=T6BM.pivot_table(index=['DATE'],
                     columns=['',' '],
                     values=['BAD POD Theft'],
                     aggfunc={'BAD POD Theft':sum})
#df4.reset_index( inplace=True)
# df4['BAD POD Theft']=pd.np.round(df4['BAD POD Theft'],0)

###################### CONVERTING DATE FROM STING TO 'DATE' TYPE ############

#df4['DATE'] = pd.to_datetime(df4['DATE']).dt.date
#type(df4['DATE'].values[0])

################# SWAPPING AXIS #################

DF4=df4.swaplevel(i=-3,j=-1,axis=1)
# DF4.head()


# In[101]:


############### PIVOT MERGING ##################


# In[102]:


# df1.index.dtype


# In[103]:


df2.index=df2.index.astype(str)


# In[104]:


df2.index


# In[105]:


# df1['DATE']=df1['DATE'].astype(str)
# df2['DATE']=df2['DATE'].astype(str)


# In[106]:


#PIVOT=pd.merge(df1,df2, on='DATE', how='outer', suffixes=('_I','_II')).fillna(0)
PIVOT=pd.merge(df1,df2, left_index=True,right_index=True, how='outer', suffixes=('_I','_II')).fillna(0)
# PIVOT



# In[107]:


# df4.head()


# In[108]:


P2=pd.merge(df3,df4, left_index=True,right_index=True, how='outer', suffixes=('_I','_II')).fillna(0)


# In[109]:


# P2


# In[110]:


PIVOT3=pd.merge(PIVOT,P2, left_index=True,right_index=True, how='outer').fillna(0)
# PIVOT3


# In[111]:


################## full data from 1st JAN 2019 to Yesterday's date #############################


# In[112]:


DF=PIVOT3.swaplevel(i=-3,j=-1,axis=1)
DF
DF[('EFFECT','Short Pcs Delvd To Customer','PPD - DRS')]=DF[
    ('EFFECT','Short Pcs Delvd To Customer','PPD - DRS')].astype(int)
DF[('EFFECT','Short Pcs Delvd To Customer','BAD POD Short')]=DF[
    ('EFFECT','Short Pcs Delvd To Customer','BAD POD Short')].astype(int)
DF[('EFFECT','Increased Theft in N/W','BAD POD Theft')]=DF[ 
    ('EFFECT','Increased Theft in N/W','BAD POD Theft')].astype(int)
# DF


# In[113]:


Tab_ExlData=DF[[('CAUSE','Moved In Network','SHORT_CONS'),
    ('CAUSE','Moved In Network','PPM_CONS'),
    ('CAUSE','Moved In Network','PPA CONS'),
   ('EFFECT','High Inventory Short Pcs','NETWORK'), 
    ('EFFECT','High Inventory Short Pcs','DESTINATION'),
  ('EFFECT','Short Pcs Delvd To Customer','PPD - DRS'),
    ('EFFECT','Short Pcs Delvd To Customer','BAD POD Short'),
     ('EFFECT','Increased Theft in N/W','BAD POD Theft')]]
# Tab_ExlData


# In[114]:


# DF.index.get_level_values('DATE')>'2019-02-10'


# In[115]:


# '2019-02-10'<'2019-02-09'

yest1=datetime.now()-timedelta(11)
startdate1=yest1.date()
startdate1=str(startdate1)
startdate1


# In[116]:


FullPiv=DF.iloc[DF.index.get_level_values('DATE')>= startdate1,:]
FullPiv


# In[117]:


Tab_Email=FullPiv[[('CAUSE','Moved In Network','SHORT_CONS'),
    ('CAUSE','Moved In Network','PPM_CONS'),
    ('CAUSE','Moved In Network','PPA CONS'),
   ('EFFECT','High Inventory Short Pcs','NETWORK'), 
    ('EFFECT','High Inventory Short Pcs','DESTINATION'),
  ('EFFECT','Short Pcs Delvd To Customer','PPD - DRS'),
    ('EFFECT','Short Pcs Delvd To Customer','BAD POD Short'),
     ('EFFECT','Increased Theft in N/W','BAD POD Theft')]]
Tab_Email


# In[118]:


from pandas import ExcelWriter
with ExcelWriter(r"D:\Python\Scripts and Files\Python Scripts\SHORTAGEPARTPIECEECOSYSTEM.xlsx") as writer:
    Tab_ExlData.to_excel(writer, sheet_name='Data',engine='xlsxwriter')
print('file created')


# In[119]:


####################### email  ############################## 


# In[120]:


import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback
from glob import glob
from IPython import display
from datetime import datetime,timedelta
import pyodbc

date=datetime.strftime(datetime.now(),'%Y-%m-%d-%H')


# In[121]:


filepath=r'D:\Python\Scripts and Files\Python Scripts\SHORTAGEPARTPIECEECOSYSTEM.xlsx'


# In[122]:


oppath1=filepath
#FTP Upload starts
print ('Logging in...')
ftp = ftplib.FTP()  
ftp.connect('10.109.230.50')  
print (ftp.getwelcome())

try:
 try:
     ftp.login('HOSQTeam', 'Te@mH0$q')
     print ('login done')
     ftp.cwd('Auto_reports')
     #ftp.cwd('FIFO')
     # move to the desired upload directory
     print ("Currently in:", ftp.pwd())
     print ('Uploading...')
     fullname = oppath1
     name = os.path.split(fullname)[1]
     f = open(fullname, "rb")
     ftp.storbinary('STOR ' + name, f)
     f.close()
     print ("OK"  )
     print ("Files:")
     print (ftp.retrlines('LIST'))
 finally:
     print ("Quitting...")
     ftp.quit()
except:
    traceback.print_exc()
    
#date=datetime.strftime(datetime.now(),'%Y-%m-%d %H:%M:%S')


# ----------- E M A I L --------------------------    
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template                    


# TO=['abhik.mitra@spoton.co.in']
TO=['sanjana.narayana@spoton.co.in']
FROM="mis.ho@spoton.co.in"
CC = ['sanjana.narayana@spoton.co.in']

# CC = ['shivananda.p@spoton.co.in','rajesh.kumar@spoton.co.in','pawan.sharma@spoton.co.in','jothi.menon@spoton.co.in',
# 'rajesh.kapase@spoton.co.in','sharmistha.majumdar@spoton.co.in','alok.b@spoton.co.in',
#       'anitha.thyagarajan@spoton.co.in']

BCC = ['sanjana.narayana@spoton.co.in']


msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = " Shortage & Part Piece Eco System - Trend " + " - " + str(date)
html='''<html>
<style>        
p
 {
   margin:0;
   margin-top: 5px;
   padding:0;
   font-size:15px;
   line-height:20px;
 }
</style>                


'''
html3='''
<h5> To download File, Please click the link below </h5>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/SHORTAGEPARTPIECEECOSYSTEM.xlsx"</a>
"http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/SHORTAGEPARTPIECEECOSYSTEM.xlsx</p>
'''
report=""
report+='<br>'
report+='Dear Sir,'
report+='<br>'
report+='<br>'
report+=' Please find attached below report till date.'
report+='<br>'
report+='<br>'+Tab_Email.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(oppath1,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
print ('mail sent')
server.quit()

