
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
# from pymongo import MongoClient
from string import Template
import smtplib
import os
from datetime import datetime, timedelta
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import smtplib
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
import Utilities

# In[2]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()
start_date=datetime.strftime(datetime.now()-timedelta(days=1),'%Y-%m-%d')+' 00:00:00'
enddate=datetime.strftime(datetime.now()-timedelta(days=1),'%Y-%m-%d')+' 23:59:00'
start_date,enddate

# In[3]:


query=("""SELECT THCNO,routename,sourcehb,tobh_code,thcdt,min(thcdt) as thc_startdate,max(thcdt)as thc_enddate,case when sealno_in is null then '-' else sealno_in end sealno_in ,case when sealno_out is null then '-' else sealno_out end sealno_out,
vehno,vehtons,vehtype,VENDOR_CODE,VENDOR_NAME,ld_pkgs,ld_actuwt FROM THCHDR with(nolock)  WHERE thcdt  between '{0}' and '{1}'  
group by THCNO,routename,thcdt,sourcehb,tobh_code,case when sealno_out is null then '-' else sealno_out end,case when sealno_in is null then '-' else sealno_in end,vehno,vehtons,vehtype,VENDOR_CODE,VENDOR_NAME,ld_pkgs,ld_actuwt
order by thcno,thcdt""").format(start_date,enddate)


# In[4]:


df=pd.read_sql(query,Utilities.cnxn)


# In[5]:


len(df)


# In[6]:


df=df[df['vehtype']!='D']


# In[7]:


len(df)


# In[8]:


new_df=pd.DataFrame()
for i in df['THCNO'].unique().tolist():
    res_df=df[df['THCNO']==i]
    res_df['sin']=res_df['sealno_in'].shift(-1)
    new_df=pd.concat([new_df,res_df],ignore_index=True)


# In[9]:


len(new_df)


# In[10]:


new_df1=new_df


# In[11]:


new_df=new_df[new_df['tobh_code']!='Null']
len(new_df)


# In[14]:


def getExceptions(sout,sin):
    if str(sout).lower()==str(sin).lower():
        return True
    else:
        return False


# In[15]:


new_df['Exceptions']=new_df.apply(lambda x:getExceptions(x['sealno_out'],x['sin']),axis=1)

new_df['Leg']=new_df['sourcehb']+'-'+new_df['tobh_code']

# In[16]:


exceptions_df=new_df[new_df['Exceptions']==False]


# In[17]:


len(exceptions_df)


# In[18]:




# In[20]:
mail_summary=pd.pivot_table(new_df,index=['Leg'],columns=['Exceptions'],aggfunc={'Exceptions':len}).fillna(0)
mail_summary.sort_values(('Exceptions',False),ascending=False,inplace=True)

summary=exceptions_df.pivot_table(index=['Leg','THCNO','sealno_out','sin','vehno','VENDOR_NAME'])


# In[21]:


summary.rename(columns={'sin':'seal_in'},inplace=True)


# In[22]:


len(summary)


# In[23]:


summary


# In[24]:


todate=datetime.strftime(datetime.now(),'%Y-%m-%d')
todate


# In[26]:


summary.to_csv(r'D:\Data\seal_exception_report\Seal_Exception_Summary'+str(todate)+'.csv')
summary.to_csv(r'D:\Data\seal_exception_report\Seal_Exception_Summary.csv')
df.to_csv(r'D:\Data\seal_exception_report\Seal_Exception_Data'+str(todate)+'.csv')
df.to_csv(r'D:\Data\seal_exception_report\Seal_Exception_Data.csv')
mail_summary.to_csv(r'D:\Data\seal_exception_report\Exceptions_Summary_'+str(todate)+'.csv')
mail_summary.to_csv(r'D:\Data\seal_exception_report\Exceptions_Summary.csv')

# In[27]:


filepath1=r'D:\Data\seal_exception_report\Seal_Exception_Summary.csv'
filepath2=r'D:\Data\seal_exception_report\Seal_Exception_Data.csv'
filepath3=r'D:\Data\seal_exception_report\Exceptions_Summary.csv'


# In[28]:


TO=['mahender.singh@spoton.co.in','scincharge_spot@spoton.co.in','hubmgr_spot@spoton.co.in','aom_spot@spoton.co.in','dom_spot@spoton.co.in','rom_spot@spoton.co.in','umesh.sharma@spoton.co.in','bhupinder.singh@spoton.co.in','shubhanker.sr@spoton.co.in','ashwani.gangwar@spoton.co.in','dilip.singh@spoton.co.in','venkata.kameswara@spoton.co.in']
CC=['abhik.mitra@spoton.co.in','pawan.sharma@spoton.co.in','jothi.menon@spoton.co.in','shivananda.p@spoton.co.in','rajesh.kumar@spoton.co.in','mahesh.reddy@spoton.co.in','abhishek.cv@spoton.co.in','satya.pal@spoton.co.in','saptarshi.pathak@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in']
FROM="reports.ie@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "Seal Exception Report " + '- ' +todate
html3='''
<h5> To download the data , Please click the link below </h5>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Hub_Perfor_Data.csv"</a>http://spoton.co.in/downloads/IEProjects/ETA/Hub_Perfor_Data.csv</p></b>

<h5> To download the condata of DEPS/excluded cons , Please click the link below </h5>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Hub_Perfor_DEPS_condata.csv"</a>http://spoton.co.in/downloads/IEProjects/ETA/Hub_Perfor_DEPS_condata.csv</p></b>

'''
report=""
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='PFA Seal Exception Report '+todate
report+='<br>'
report+='PFA Exceptions Summary :'
report+='<br>'
report+='<br>'

report+='<br>'+mail_summary.head(20).to_html()+'<br>'
report+='<br>'
report+='For Data and Summary use attached files.'
#report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)

part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath1,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
msg.attach(part)

part2 = MIMEBase('application', "octet-stream")
part2.set_payload( open(filepath2,"rb").read() )
encoders.encode_base64(part2)
part2.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath2))
msg.attach(part2)

part3 = MIMEBase('application', "octet-stream")
part3.set_payload( open(filepath3,"rb").read() )
encoders.encode_base64(part3)
part3.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath3))
msg.attach(part3)



server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("spoton.net.in", "Star@123#")
server.login('spoton.net.in', 'Star@123#')
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()

