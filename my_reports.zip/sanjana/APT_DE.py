
# coding: utf-8

# In[51]:


import numpy as np
import pandas as pd
# import matplotlib.pyplot as plt
# import seaborn
from glob import glob
from IPython import display
from datetime import datetime,timedelta
import pyodbc
# import geopy
import pandas as pd
import Utilities


# In[54]:


yest=datetime.now()-timedelta(1)
enddate=yest.date()
enddate=str(enddate)

yest=datetime.now()-timedelta(32)
startdate=yest.date()
startdate=str(startdate)
[[enddate,startdate]]


# In[55]:


#EXEC dbo.USP_APT_DELV_PERFRMC_DAILY_SQ '2019-03-05','2019-03-07' 


# In[56]:


query= """ EXEC dbo.USP_APT_DELV_PERFRMC_DAILY_SQ '{0}','{1}'   """ .format(startdate,enddate)
# query= """ EXEC dbo.USP_APT_DELV_PERFRMC_DAILY_SQ '{0}','{1}'   """ .format('2019-03-05','2019-03-07')
print (query)


# In[57]:


rawDATA=pd.read_sql(query,Utilities.cnxn)


# In[58]:


Q1=pd.read_sql(query,Utilities.cnxn)


# In[59]:


Q1.rename(columns={'PERFORMANCE':'Perf_Y_N'}, inplace=True)


# In[60]:


len(Q1)


# In[61]:


Q1.columns


# In[62]:


Q1=Q1[Q1.Con_Category == 'e-Commerce']


# In[63]:


len(Q1)


# In[64]:


Q1.dtypes


# In[65]:


def tag (APORD1):     
#### tag is the name of the function, z is the variable which inherits the values in 'APORDER' column, 
###  then it goes on to test the condition
    if APORD1== 1:
        return '1'
    elif APORD1== 2:
        return '2' 
    else:
        return '3+ Days'


# In[66]:


Q1.head()


# In[67]:


Q1['APORDER1'] = Q1.apply(lambda x:tag(x['APORDER']), axis=1)
#PenByPOD['EMPNM'] = PenByPOD.apply(lambda x:sanjana(x['DELIVERY_DEPOT']),axis=1)


# In[68]:


def tagPERF (PERF):     
#### tag is the name of the function, z is the variable which inherits the values in 'APORDER' column, 
###  then it goes on to test the condition
    if PERF== 'YES' :
        return 'SUCCESS'
    else:
        return 'FAILURE'


# In[69]:


Q1['PERFORMANCE'] = Q1.apply(lambda x:tagPERF(x['Perf_Y_N']), axis=1)


# In[70]:


Q1.head()


# In[71]:


# Q1['DOCKNO']= Q1['DOCKNO'].astype(int)


# In[72]:


df=pd.pivot_table(Q1,index=["APT_DATE"], 
                  columns=["PERFORMANCE","APORDER1"], 
                  values= ['DOCKNO'],
                  aggfunc={'DOCKNO':len}).fillna(0)
df['DOCKNO']=df['DOCKNO'].astype(int)


# In[73]:


df.rename(columns={'DOCKNO':'E Commerce - Cons','APT_DATE':'DATE'}, inplace=True)


# In[74]:


df['Total Cons']=df.sum(axis=1)
df


# In[75]:


df['E Commerce - Cons','SUCCESS Total','']=df['E Commerce - Cons','SUCCESS'].sum(axis=1)
df['E Commerce - Cons','FAILURE Total','']=df['E Commerce - Cons','FAILURE'].sum(axis=1)
df


# In[76]:


df['E Commerce - %','FAILURE%','1']=pd.np.round((df['E Commerce - Cons','FAILURE','1']/df['Total Cons'])*100,0).astype(int)
df['E Commerce - %','FAILURE%','2']=pd.np.round((df['E Commerce - Cons','FAILURE','2']/df['Total Cons'])*100,0).astype(int)
df['E Commerce - %','FAILURE%','3+ Days']=pd.np.round((df['E Commerce - Cons','FAILURE','3+ Days']/df['Total Cons'])*100,0).astype(int)
df['E Commerce - %','FAILURE% Total','']=df['E Commerce - %','FAILURE%'].sum(axis=1)
df


# In[77]:


df['E Commerce - %','SUCCESS%','1']=pd.np.round((df['E Commerce - Cons','SUCCESS','1']/df['Total Cons'])*100,0).astype(int)
df


# In[78]:


df['E Commerce - %','SUCCESS%','2']=pd.np.round((df['E Commerce - Cons','SUCCESS','2']/df['Total Cons'])*100,0).astype(int)


# In[79]:


df['E Commerce - %','SUCCESS%','3+ Days']=pd.np.round((df['E Commerce - Cons','SUCCESS','3+ Days']/df['Total Cons'])*100,0).astype(int)


# In[80]:


df['E Commerce - %','SUCCESS% Total','']=df['E Commerce - %','SUCCESS%'].sum(axis=1).astype(int)


# In[81]:


df.head(1)


# In[82]:


# df.columns


# In[83]:


df[[('E Commerce - Cons','SUCCESS','1'),('E Commerce - Cons','SUCCESS','2'),('E Commerce - Cons','SUCCESS','3+ Days'),('E Commerce - Cons','SUCCESS Total',''),
   ('E Commerce - Cons','FAILURE','1'),('E Commerce - Cons','FAILURE','2'),('E Commerce - Cons','FAILURE','3+ Days'),('E Commerce - Cons','FAILURE Total',''),
   ('E Commerce - %','SUCCESS%','1'),('E Commerce - %','SUCCESS%','2'),('E Commerce - %','SUCCESS%','3+ Days'),('E Commerce - %','SUCCESS% Total',''),
   ('E Commerce - %','FAILURE%','1'),('E Commerce - %','FAILURE%','2'),('E Commerce - %','FAILURE%','3+ Days'),('E Commerce - %','FAILURE% Total',''),
   ('Total Cons','','')]]


# In[84]:


df['E Commerce - %','SUCCESS%','1']=df['E Commerce - %','SUCCESS%','1'].astype(str)+'%'
df


# In[85]:


df['E Commerce - %','SUCCESS%','2']=df['E Commerce - %','SUCCESS%','2'].astype(str)+'%'
df


# In[86]:


df['E Commerce - %','SUCCESS%','3+ Days']=df['E Commerce - %','SUCCESS%','3+ Days'].astype(str)+'%'
df['E Commerce - %','SUCCESS% Total','']=df['E Commerce - %','SUCCESS% Total',''].astype(str)+'%'
df


# In[87]:


df['E Commerce - %','FAILURE%','1']=df['E Commerce - %','FAILURE%','1'].astype(str)+'%'
df


# In[88]:


df['E Commerce - %','FAILURE%','2']=df['E Commerce - %','FAILURE%','2'].astype(str)+'%'
df


# In[89]:


df['E Commerce - %','FAILURE%','3+ Days']=df['E Commerce - %','FAILURE%','3+ Days'].astype(str)+'%'
df['E Commerce - %','FAILURE% Total','']=df['E Commerce - %','FAILURE% Total',''].astype(str)+'%'
df


# In[90]:


df_ordered=df[[('E Commerce - Cons','SUCCESS','1'),('E Commerce - Cons','SUCCESS','2'),('E Commerce - Cons','SUCCESS','3+ Days'),('E Commerce - Cons','SUCCESS Total',''),
   ('E Commerce - Cons','FAILURE','1'),('E Commerce - Cons','FAILURE','2'),('E Commerce - Cons','FAILURE','3+ Days'),('E Commerce - Cons','FAILURE Total',''),
   ('E Commerce - %','SUCCESS%','1'),('E Commerce - %','SUCCESS%','2'),('E Commerce - %','SUCCESS%','3+ Days'),('E Commerce - %','SUCCESS% Total',''),
   ('E Commerce - %','FAILURE%','1'),('E Commerce - %','FAILURE%','2'),('E Commerce - %','FAILURE%','3+ Days'),('E Commerce - %','FAILURE% Total',''),
   ('Total Cons','','')]]


# In[91]:


yest1=datetime.now()-timedelta(7)
startdate1=yest1.date()
startdate1=str(startdate1)
startdate1


# In[92]:


FullPiv=df_ordered.iloc[df_ordered.index.get_level_values('APT_DATE')>= startdate1,:]
df_email=FullPiv


# In[93]:


df_email


# In[94]:


today=datetime.strftime(datetime.now(),'%Y-%m-%d')
today


# In[95]:


# from pandas import ExcelWriter
# with ExcelWriter(r"D:\Data\Appointment Reports\APT_DE\APT_DE_"+str(today)+".xlsx") as writer:
#     rawDATA.to_excel(writer, sheet_name='Data',engine='xlsxwriter')
# print('file created')


# In[96]:


rawDATA.to_csv(r"D:\Data\Appointment Reports\APT_DE\APT_DE_"+str(today)+".csv")
# print('csv file created')


# In[97]:


####################### email  ############################## 


# In[98]:


import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback
from glob import glob
from IPython import display
from datetime import datetime,timedelta
import pyodbc

date=datetime.strftime(datetime.now(),'%Y-%m-%d-%H')


# In[99]:


filepath=r"D:\Data\Appointment Reports\APT_DE\APT_DE_"+str(today)+".csv"
# filepath=r"E:\PYTHON_SCRIPTS\APT_DE_"+str(today)+".xlsx"


# In[100]:


oppath1=filepath
#FTP Upload starts
print ('Logging in...')
ftp = ftplib.FTP()  
ftp.connect('10.109.230.50')  
print (ftp.getwelcome())

try:
 try:
     ftp.login('HOSQTeam', 'Te@mH0$q')
     print ('login done')
     ftp.cwd('Auto_reports')
     #ftp.cwd('FIFO')
     # move to the desired upload directory
     print ("Currently in:", ftp.pwd())
     print ('Uploading...')
     fullname = oppath1
     name = os.path.split(fullname)[1]
     f = open(fullname, "rb")
     ftp.storbinary('STOR ' + name, f)
     f.close()
     print ("OK"  )
     print ("Files:")
     print (ftp.retrlines('LIST'))
 finally:
     print ("Quitting...")
     ftp.quit()
except:
    traceback.print_exc()
    
#date=datetime.strftime(datetime.now(),'%Y-%m-%d %H:%M:%S')


# ----------- E M A I L --------------------------    
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template                    


TO=['abhik.mitra@spoton.co.in','jothi.menon@spoton.co.in']
# TO=['sanjana.narayana@spoton.co.in']
FROM="mis.ho@spoton.co.in"
# CC = ['sanjana.narayana@spoton.co.in']

CC = ['shivananda.p@spoton.co.in',
'satya.pal@spoton.co.in','saptarshi.pathak@spoton.co.in',
'uday.sharma@spoton.co.in',
'reena.singhania@spoton.co.in','sharmistha.majumdar@spoton.co.in',
'raghavendra.rao@spoton.co.in','sharanagouda.biradar@spoton.co.in',
      'anitha.thyagarajan@spoton.co.in']

BCC = ['sanjana.narayana@spoton.co.in','ganesh.m@spoton.co.in','vinit.tiwari@spoton.co.in']
# BCC = ['sanjana.narayana@spoton.co.in']


msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = " Appointment Delivery Performance - Trend " + " - " + str(date)
html='''<html>
<style>        
p
 {
   margin:0;
   margin-top: 5px;
   padding:0;
   font-size:15px;
   line-height:20px;
 }
</style>                


'''
html3='''
<h5> To download File, Please click the link below </h5>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/APT_DE_"+str(today)+".xlsx"</a>
"http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/APT_DE.xlsx"</p>
'''
report=""
report+='<br>'
report+='Dear Sir,'
report+='<br>'
report+='<br>'
report+=' Please find below Appt Delv Performance Trend.'
report+='<br>'
report+='<br>'+df_email.to_html()+'<br>'
report+='<br>'
report+='<br>'
# report+=html
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(oppath1,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
print ('mail sent')
server.quit()

