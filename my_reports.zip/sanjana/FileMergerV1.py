# -*- coding: utf-8 -*-
"""
Created on Mon Sep 28 13:11:01 2015

@author: rajeeshv
"""
import pandas as pd
import glob

path =r'D:\Data\eta_rank\eta_folder_rankfiles' # use your path
allFiles = glob.glob(path + "/*.csv")
frame = pd.DataFrame()
list_ = []
for file_ in allFiles:
    df = pd.read_csv(file_,index_col=None, header=0)
    list_.append(df)
frame = pd.concat(list_)
frame.to_csv(r'D:\Data\eta_rank\Combined.csv')
