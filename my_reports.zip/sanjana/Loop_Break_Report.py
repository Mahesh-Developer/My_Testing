
# coding: utf-8

# In[1]:

frontlist = ["BOMH-DELH","BOMH-BLRH","PNQH-DELH","DELH-BLRH","DELH-HYDH","DELH-MAAH","BOMH-AMCH","AMCH-BLRH","PNQH-BLRH","PNQH-MAAH","BOMH-MAAH","BOMH-HYDH","PNQH-HYDH","BOMH-CCUH","DELH-CCUH","DELH-BRGH","BLRH-CCUH","PNQH-CCUH","BLRH-AMDH","HYDH-BRGH","PNQH-AMCH","BOMH-LKOH","BOMH-PATH","BOMH-RPRH","BOMH-JAIH","KNPH-BLRH","AMCH-MAAH"]
import pandas as pd
from datetime import datetime, timedelta
from itertools import permutations
import numpy as np
from sqlalchemy import *
import Utilities
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

try:

    engine = create_engine("mysql+pymysql://spotonhr:spoton54321@104.199.198.197/LH30days")
    startdate=datetime.strftime(datetime.now()-timedelta(days=30),"%Y-%m-%d")
    df = pd.read_sql("SELECT * FROM LH30days WHERE `THC DATE` >='{}'".format(startdate),engine)

    df=df[~(df["Vech Type"].isin(['DATAVECHILE','VIRTUALHUB']))]
    df["VEHICLE PAYLOAD"]=df["VEHICLE PAYLOAD"].replace(0,13500)
    df["Util%"] = df.apply(lambda x: round(x["TOTAL ACTUAL LOAD"]*100.0/x["VEHICLE PAYLOAD"],1),axis=1)
    df["Vol Util%"] = df.apply(lambda x: round(x["TOTAL VOL WEIGHT"]*100.0/x["VEHICLE PAYLOAD"],1),axis=1)
    df = df.rename_axis({'Image Process Result':'Img'},axis=1)
    dfyest=df[(df["THC DATE"]>=(datetime.today().replace(hour=10,minute=0,second=0,microsecond=0)-timedelta(days=1,hours=9)))&(df["THC DATE"]<=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)))].loc[:,["NEW PATH","ROUTE CODE","ROUTE NAME","THC NUMBER","THC DATE","Util%","Vol Util%","Img"]]
    dfyest=dfyest.rename_axis({"ROUTE CODE":"Route Code", "ROUTE NAME":"Route Details","THC DATE":"Depart Time"},axis=1)
    dfyest["Route Details"]=dfyest["Route Details"].str.replace(" ","")#.str.split("-")
    dfschedule = pd.read_sql("SELECT * FROM schedule",con=create_engine("mysql+pymysql://spotonhr:spoton54321@104.199.198.197/schedule"))
    dfschedule["Route Details"]=dfschedule["Route Details"].str.replace(" ","")#.str.split("-")
    dfschedule=dfschedule[dfschedule["Origin"]==dfschedule["Route Details"].str[0:4]]
    dfschedule["NEW PATH"]=dfschedule["Origin"]+"-"+dfschedule["Route Details"].str[-4:]
    dfschedule["Departure Sch"]=dfschedule.apply(lambda x: datetime.combine(datetime.today().date(),datetime.min.time())+timedelta(hours=int(x["Departure time"].split(":")[0]),minutes=int(x["Departure time"].split(":")[1])),axis=1)
    dfschedule["Departure Sch"]=dfschedule.apply(lambda x: x["Departure Sch"] if x["Departure Sch"]<datetime.today().replace(hour=9,minute=0) else (x["Departure Sch"]-timedelta(days=1)),axis=1)

    masterdf=dfyest.merge(dfschedule.loc[:,["NEW PATH","Route Code","Route Details","Departure Sch","Payload"]],how="outer",on=["NEW PATH","Route Code","Route Details"])
    masterdf["Late Hours"]=masterdf.apply(lambda x: round((x["Depart Time"]-x["Departure Sch"]).total_seconds()/3600,1),axis=1)
    masterdf.loc[(masterdf["Late Hours"]>12)|(masterdf["Late Hours"]<-12),["Depart Time","THC NUMBER","Util%","Vol Util%"]]=None
    masterdf = masterdf.sort_values("Util%",na_position='last')
    masterdf.loc[~(masterdf["Route Code"]=='9888')]=masterdf.loc[~(masterdf["Route Code"]=='9888')].drop_duplicates("Route Code",keep='first') #removes na if others present
    masterdf=masterdf[masterdf["NEW PATH"].isin(["BOMH-DELH","DELH-BOMH","BOMH-BLRH","BLRH-BOMH","PNQH-DELH","DELH-PNQH","BLRH-DELH","DELH-BLRH","DELH-HYDH","HYDH-DELH","DELH-MAAH","MAAH-DELH","BOMH-AMCH","AMCH-BOMH","BLRH-AMCH","AMCH-BLRH","AMCH-PNQH","PNQH-AMCH","BOMH-LKOH","LKOH-BOMH","BLRH-KNPH","KNPH-BLRH","AMCH-MAAH","MAAH-AMCH","BOMH-PATH","PATH-BOMH","BOMH-JAIH","BOMH-RPRH","RPRH-BOMH","PNQH-BLRH","BLRH-PNQH","PNQH-MAAH","MAAH-PNQH","BOMH-MAAH","MAAH-BOMH","BOMH-HYDH","HYDH-BOMH","PNQH-HYDH","HYDH-PNQH", "BOMH-CCUH","CCUH-BOMH","DELH-CCUH","CCUH-DELH","DELH-BRGH","BRGH-DELH","BLRH-CCUH","CCUH-BLRH","PNQH-CCUH","CCUH-PNQH","BLRH-AMDH","AMDH-BLRH","AMDH-MAAH","MAAH-AMDH","HYDH-BRGH","BRGH-HYDH","AGRB-IDRH","IDRH-AGRB","BLRH-IDRH","IDRH-BLRH","IDRH-NAGH","NAGH-IDRH","BLRH-COKB","COKB-BLRH","DELH-PATH","PATH-DELH","NAGH-HYDH","HYDH-NAGH"])]
    masterdf['NEW PATH'] = pd.Categorical(masterdf['NEW PATH'],categories=["BOMH-DELH","DELH-BOMH","BOMH-BLRH","BLRH-BOMH","PNQH-DELH","DELH-PNQH","BLRH-DELH","DELH-BLRH","DELH-HYDH","HYDH-DELH","DELH-MAAH","MAAH-DELH","BOMH-AMCH","AMCH-BOMH","BLRH-AMCH","AMCH-BLRH","AMCH-PNQH","PNQH-AMCH","BOMH-LKOH","LKOH-BOMH","BLRH-KNPH","KNPH-BLRH","AMCH-MAAH","MAAH-AMCH","BOMH-PATH","PATH-BOMH","BOMH-JAIH","BOMH-RPRH","RPRH-BOMH","PNQH-BLRH","BLRH-PNQH","PNQH-MAAH","MAAH-PNQH","BOMH-MAAH","MAAH-BOMH","BOMH-HYDH","HYDH-BOMH","PNQH-HYDH","HYDH-PNQH", "BOMH-CCUH","CCUH-BOMH","DELH-CCUH","CCUH-DELH","DELH-BRGH","BRGH-DELH","BLRH-CCUH","CCUH-BLRH","PNQH-CCUH","CCUH-PNQH","BLRH-AMDH","AMDH-BLRH","AMDH-MAAH","MAAH-AMDH","HYDH-BRGH","BRGH-HYDH","AGRB-IDRH","IDRH-AGRB","BLRH-IDRH","IDRH-BLRH","IDRH-NAGH","NAGH-IDRH","BLRH-COKB","COKB-BLRH","DELH-PATH","PATH-DELH","NAGH-HYDH","HYDH-NAGH"],ordered=True)
    masterdf = masterdf.sort_values('NEW PATH')
    masterdf["Route Details"]=masterdf["Route Details"].str.split("-")
    from sqlalchemy import create_engine, MetaData, Table, select
    import pyodbc
    # cnxn1 = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.87;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
    # cursor1 = cnxn1.cursor()

    query=("""USP_LOADAVAILABLE_REPORT""")
    invdf=pd.read_sql(query,Utilities.cnxn)
    print (invdf.columns)
    #invdf = pd.read_csv('http://spoton.co.in/downloads/IEP_LOADAVAILABLE_DATA/IEP_LOADAVAILABLE_DATA.csv')
    #invdf["TimeStamp"] = invdf.apply(lambda x: datetime.strptime(x["TimeStamp"],"%m/%d/%Y %I:%M:%S %p")+timedelta(minutes=5),axis=1)
    inventorydict={}
    for i in zip(invdf["Current_Location"],invdf["Next_Location"],invdf["TimeStamp"],invdf["Total_Weight"]):
        inventorydict.update({(i[0],i[1],i[2]):i[3]})
    def inventory(routedet,depsch,deptime):
        retval=[]
        a=int(depsch.hour) if pd.notnull(depsch) else int(deptime.hour)
        for j in range(0,min(a-9,4)) if a>=10 else range(0,4):
            if pd.notnull(depsch):
                retval.append(round(np.sum(max(inventorydict.get((routedet[0],routedet[i],depsch.replace(minute=0,second=0)-timedelta(hours=j))),0) for i in range(1,len(routedet))),1))
            else:
                retval.append(round(np.sum(max(inventorydict.get((routedet[0],routedet[i],deptime.replace(minute=0,second=0)-timedelta(hours=j))),0) for i in range(1,len(routedet))),1))
        return str(retval)

    masterdf["Inv Trend"]=masterdf.apply(lambda x: inventory(x["Route Details"],x['Departure Sch'],x['Depart Time']),axis=1)
    masterdf["Inv@SchTime"]=masterdf["Inv Trend"].str.replace('[','').str.replace(']','').str.split(",").str[0].astype(float)
    masterdf["Inv@SchTime+2"]=masterdf.apply(lambda x: round(np.sum(max(inventorydict.get((x["Route Details"][0],x["Route Details"][i],x["Departure Sch"].replace(minute=0,second=0)+timedelta(hours=2))),0) for i in range(1,len(x["Route Details"]))),1),axis=1)
    cpkpivot=df.pivot_table(index=["NEW PATH","ROUTE CODE","VENDOR TYPE"],aggfunc={"COST":np.sum,'VEHICLE PAYLOAD':np.sum}).reset_index()
    cpkpivot["CPK"]=cpkpivot["COST"]/cpkpivot["VEHICLE PAYLOAD"]
    cpkpivot=cpkpivot.drop("COST",axis=1).rename_axis({"CPK":"COST"},axis=1)
    threshdf = cpkpivot.pivot_table(index="NEW PATH",columns=["VENDOR TYPE"],aggfunc={"COST":lambda x: min(x)})
    threshdf["Premium"]=threshdf.apply(lambda x: round(x["COST","MARKET"]*100.0/x["COST","VENDOR"]-100,1) if x["COST","MARKET"]>0 and x["COST","VENDOR"]>0 else 0,axis=1)

    premiumdict = threshdf["Premium"].to_dict()
    thresholddict = {}
    for i in premiumdict.keys():
        thresholddict.update({(i.split("-")[1]+"-"+i.split("-")[0]):round(min(90,(100-min(99,premiumdict.get(i)))),2)})

    for i in ["DELH-BOMH","DELH-PNQH"]:
        if thresholddict.get(i)!=None:
            thresholddict.update({i:(thresholddict.get(i)+20)})
        else:
            pass
        
    masterdf["Threshold%"]=masterdf.apply(lambda x: thresholddict.get(x["NEW PATH"]) if thresholddict.get(x["NEW PATH"])!=None else 90,axis=1)
    nonopsdf=df.pivot_table(index="ROUTE CODE",values=["TOTAL ACTUAL LOAD"],aggfunc={"TOTAL ACTUAL LOAD":lambda x: 30-len(x)}).reset_index().rename_axis({'TOTAL ACTUAL LOAD':'Non-ops',"ROUTE CODE":"Route Code"},axis=1)
    nonopsdf.loc[nonopsdf["Route Code"]=="9888",["Non-ops"]]=0
    lastnonops= df.loc[:,["THC DATE","ROUTE CODE"]]
    lastnonops["THC DATE"]=lastnonops["THC DATE"].dt.date
    setofdates = set([datetime.today().date()-timedelta(days=x) for x in range(2, 30)])
    lastnonops=lastnonops.pivot_table(index="ROUTE CODE",values="THC DATE",aggfunc={"THC DATE":lambda x: max(list(setofdates-set(x)) or [None])}).reset_index()
    lastnonops=lastnonops.replace("D","E",regex=True).replace("U","D",regex=True).replace("E","U",regex=True).rename_axis({'THC DATE':'Loop Brk',"ROUTE CODE":"Route Code"},axis=1)#converting to loop break
    marketframe = masterdf[masterdf["Route Code"]=='9888']
    marketframe = marketframe.sort_values("Depart Time",ascending=True)
    marketframedict = {}
    for i in zip(marketframe["NEW PATH"],marketframe["Depart Time"]):
        marketframedict.update({i[0]:i[1]})
    def remarks(acttime,schtime,invsch,threshold,util,newpath,volutil,img,payload,inv_2):
        print (threshold,payload,inv_2)
        if float(inv_2)==0.0:
            inv_2=invsch
        if pd.isnull(payload):
            payload = 13500
        if pd.isnull(schtime):
            if util<85.0 and volutil<85.0 and img!="high":
                remark = "low util market"
            else:
                remark = None
        elif pd.isnull(acttime) and pd.notnull(marketframedict.get(newpath)) and marketframedict.get(newpath)>(schtime-timedelta(hours=12)) and marketframedict.get(newpath)<(schtime+timedelta(hours=6)):
            remark = 'why non-ops & market!'
        elif pd.isnull(acttime) and invsch>(threshold*float(payload)*1.0/100000) and float(inv_2)>(threshold*float(payload)*1.0/100000):           
            remark = 'why non-ops'
        elif pd.isnull(acttime):
            remark = None
        elif acttime<(schtime-timedelta(hours=2)) and util<85 and volutil<85 and img!="high" and acttime>(schtime-timedelta(hours=14)) and invsch>2.0 and float(inv_2)>2.0:
            remark = 'early-dep with less load'
        elif acttime>schtime+timedelta(hours=2) and invsch>(threshold*payload/100*1/1000) and acttime<(schtime+timedelta(hours=14)):
            remark = 'late-dep despite load'
        elif pd.notnull(acttime) and util<85 and volutil<85 and util<threshold and img!="high" and newpath in frontlist:
            remark = 'low util on frontleg'
        else:
            remark = ''
        return remark

    finaltable = masterdf.loc[:,["NEW PATH","Route Code","Route Details","Departure Sch","Inv@SchTime","Inv Trend",'Threshold%',"Payload","Depart Time","THC NUMBER","Util%","Vol Util%","Img","Inv@SchTime+2"]]
    finaltable=finaltable.merge(nonopsdf,how="left",on=["Route Code"])
    finaltable=finaltable.merge(lastnonops,how="left",on=["Route Code"])
    finaltable["Remarks"]=finaltable.apply(lambda x: remarks(x["Depart Time"],x["Departure Sch"],x["Inv@SchTime"],x["Threshold%"],x["Util%"],x["NEW PATH"],x["Vol Util%"],x["Img"],x["Payload"],x["Inv@SchTime+2"]),axis=1)
    finaltable["Departure Sch"] = finaltable.apply(lambda x: str(x["Departure Sch"]),axis=1)
    finaltable["Depart Time"] = finaltable.apply(lambda x: str(x["Depart Time"]),axis=1)
    finaltable = finaltable[(finaltable["Route Code"]!="D1622")&(finaltable["Route Code"]!="U1622")&(finaltable["Route Code"]!="D1782")&(finaltable["Route Code"]!="D1783")]
    htmldf = finaltable[(finaltable["Remarks"].notnull())&(finaltable["Remarks"]!='')].loc[:,["Route Code","Route Details","Departure Sch","Inv@SchTime","Depart Time","Threshold%","Util%","Vol Util%","Loop Brk","Remarks"]]
    htmldf = htmldf.fillna('-')
    pd.set_option('max_colwidth', 10000)
    from datetime import date,timedelta
    todate=date.today()
    today_date=datetime.strftime(todate,'%d-%m-%Y')
    today_date
    filePath=r'D:\Data\Appointment Reports\LoopBreak\Detailed_Report'+str(today_date)+'.csv'
    finaltable.to_csv(filePath)
    print (htmldf)
    finaltable1=finaltable[['Route Code','Route Details','Departure Sch','Inv@SchTime','Depart Time','Threshold%','Util%','Vol Util%','Loop Brk','Remarks']]
    #vishwas.j@spoton.co.in



    TO=['saptarshi.pathak@spoton.co.in']
    #TO=['mahesh.reddy@spoton.co.in']
    FROM="reports.ie@spoton.co.in"
    CC=['mahesh.reddy@spoton.co.in']
    BCC=['mahesh.reddy@spoton.co.in']
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    msg["Subject"] = "Loop Break Report on Key Lanes 2.0" + " - " + str(today_date)
    html='''<html>
    <style>
    p
    {
      margin:0;
      margin-top: 5px;
      padding:0;
      font-size:17px;
        line-height:20px;
    }
    </style>

    </html>'''

    # html3='''
    # <h5> For the base data, please refer the link </h5>
    # <p><a href= "http://spoton.co.in/downloads/OCID/OCID.xls"</a>http://spoton.co.in/downloads/OCID/OCID.xls</p></b>
    # '''
    s = Template(html).safe_substitute(date=today_date)
    report=""
    report+=s
    report+='<br>'
    report+='<br>'+htmldf.head(27).to_html()+'<br>'
    #report+=html3
    abc=MIMEText(report,'html')
    msg.attach(abc)
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
    server.quit()

except:
  TO=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  #msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "Loop Break Report on Key Lanes 2.0 Error in Execution" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in Loop Break Report on Key Lanes 2.0.'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO, msg.as_string())
  server.quit()

