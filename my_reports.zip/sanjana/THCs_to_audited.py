
# coding: utf-8

# In[ ]:

import pandas as pd
from datetime import datetime, timedelta, date, time

from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
import os
import smtplib


# In[ ]:
#todaydatetime = datetime.now().date()
todaydatetime = datetime.now()

yesterday = todaydatetime - timedelta (hours=24)

opfilevar=yesterday.date()
opfilevar1=yesterday.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=pd.np.round(float(currhrs)/60)
#yesterday = todaydatetime + timedelta (days=1)


thcstobeaudited = pd.read_csv(r'http://www.spoton.co.in/downloads/DelhThc/DELH_THCS_TOBEAUDITED.csv')
thcstobeaudited.to_csv(r'D:\Data\THCs_Falcon_audit\To_be_audted_THCs\Raw_file\THCs_to_be_audited_'+str(opfilevar)+str('_')+str(opfilevar2)+'.csv')

print thcstobeaudited.columns.tolist()

thcstobeaudited = thcstobeaudited.rename(columns={'\xef\xbb\xbfTHC_Number':'THC_Number'})

# In[ ]:

thcstobeaudited['THC_Recieve_time'].unique()


# In[ ]:

def datestring(x):
    fulldate = datetime.strptime(x,'%d-%m-%Y %H:%M:%S')
    return fulldate

thcstobeaudited['THC_Recieve_time'] = thcstobeaudited.apply (lambda x:datestring (x['THC_Recieve_time']),axis=1)

# In[ ]:

thcsnotaudited = thcstobeaudited[(thcstobeaudited['THC_Recieve_time'] >= yesterday) & (thcstobeaudited['Actually_audited']== 'N')]
print thcsnotaudited.head()
print thcsnotaudited.columns.tolist()
thcsnotauditedlist = thcsnotaudited['THC_Number'].tolist()
print 'thcsnotauditedlist', thcsnotauditedlist

# In[ ]:

noofthcsnotaudited = len(thcsnotaudited)


# In[ ]:
thcsnotaudited.to_csv(r'D:\Data\THCs_Falcon_audit\To_be_audted_THCs\Report_to_be_sent\THCs_not_audited_'+str(opfilevar)+str('_')+str(opfilevar2)+'.csv')

oppathatchmt = r'D:\Data\THCs_Falcon_audit\To_be_audted_THCs\Report_to_be_sent\THCs_not_audited_'+str(opfilevar)+str('_')+str(opfilevar2)+'.csv'
## For email body and attachment


filePath = oppathatchmt
def sendEmail(#TO = ["ops.hub.deLH.1@spoton.co.in","krishna.kumar.bhardwaj@spoton.co.in","jaivir.singh@spoton.co.in","jaisingh.chauhan@spoton.co.in"],
            TO = ["vishwas.j@spoton.co.in"],
            CC = ["vishwas.j@spoton.co.in"],
            #CC = ["pawan.sharma@spoton.co.in","Sukumar.Sakthivel@Spoton.Co.In","Rajeesh.Vr@Spoton.Co.In","vishwas.j@spoton.co.in"],
            BCC = ["vishwas.j@spoton.co.in"] ,
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "Load Available for movement @ "+ str(opfilevar)+"-"+str(opfilevar2)
    msg["Subject"] = "THCs Not Audited "+ str(opfilevar)
    body_text = """
    Dear All,
    
    PFB the THCs not audited Report for """ +str(yesterday)+"""
    
    This report considers the THCs recieved at DELH in the last 24 hours which had to be audited and shows whether it was audited or not

    The THCs which was flagged to be audited and not audited = """+str(thcsnotauditedlist)+""" 

    The attachment has the THC details. 
    """
    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends


