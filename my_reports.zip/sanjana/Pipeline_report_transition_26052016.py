
# coding: utf-8

# In[1]:

import pandas as pd
import numpy as np
import datetime
from datetime import timedelta, date
from pandas import ExcelWriter
import smtplib
import os
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText


# In[2]:

todaydate = datetime.date.today()
print todaydate
yesterdate = todaydate-timedelta(days = 4)
aweekbefore = todaydate-timedelta(days = 8) ## 8 used for getting file which is 1 week from yesterday
start_date = datetime.date(todaydate.year, todaydate.month, 1)
previousmonthlast = start_date-timedelta(days=1)
#previousmonthlast = start_date-timedelta(days=32)
print previousmonthlast,yesterdate,aweekbefore



# In[3]:

pipelinedata = pd.read_csv(r'D:\Data\Sales_lead_management\Pipeline_raw\Pipeline_raw_'+str(yesterdate)+'.csv')
#pipelinedata = pd.read_csv(r'http://10.109.230.50/downloads/PIPELINE_LEAD_REPORT/PIPELINE_LEAD_REPORT.csv')
pipelinedataold = pd.read_csv(r'D:\Data\Sales_lead_management\Pipeline_raw\Pipeline_raw_'+str(previousmonthlast)+'.csv')
pipelinedataweekold = pd.read_csv(r'D:\Data\Sales_lead_management\Pipeline_raw\Pipeline_raw_'+str(aweekbefore)+'.csv')
len(pipelinedataweekold)


# In[4]:

pipelinedata = pipelinedata.rename(columns={'\xef\xbb\xbfLeadid':'Leadid'})
pipelinedataold = pipelinedataold.rename(columns={'\xef\xbb\xbfLeadid':'Leadid'})
pipelinedataweekold = pipelinedataweekold.rename(columns={'\xef\xbb\xbfLeadid':'Leadid'})


# In[5]:

pipelinedataold = pipelinedataold.drop_duplicates(subset = 'Leadid')
pipelinedata = pipelinedata.drop_duplicates(subset = 'Leadid')
pipelinedataweekold = pipelinedataweekold.drop_duplicates(subset = 'Leadid')


# In[6]:
pipelinedata_1 = pipelinedata ## For Last 6 months Lead and potential revenue summary
pipelinedata_1 = pipelinedata_1[pipelinedata_1['LeadStatus']=='Active']
len(pipelinedata_1)


pipelinedataold_1 = pipelinedataold  ## For leads and potential revenue comparison with yesterday file 


# In[7]:

columnsforold = ['Leadid','LastStatusCode','LastStatusDate','LeadStatus']
pipelinedataold = pd.DataFrame(pipelinedataold,columns=columnsforold)

pipelinedataweekold = pd.DataFrame(pipelinedataweekold,columns=columnsforold)
pipelinedataweekold.columns.tolist()


# In[8]:

pipelinedatamerge = pd.merge(pipelinedata,pipelinedataold,on=['Leadid'],suffixes=['_New','_Old'],how='left')
pipelinedatamerge_lw = pd.merge(pipelinedata,pipelinedataweekold,on=['Leadid'],suffixes=['_New','_LW'],how='left')


# In[9]:

pipelinedatamerge.LastStatusCode_Old.fillna('New',inplace=True)
pipelinedatamerge.LeadStatus_Old.fillna('New',inplace=True)
pipelinedatamerge_lw.LastStatusCode_LW.fillna('New',inplace=True)
pipelinedatamerge_lw.LeadStatus_LW.fillna('New',inplace=True)


# In[12]:

def finalstatus(oldleadstatus,newleadstatus):
    if oldleadstatus=='Inactive' and newleadstatus=='Inactive':
        return 'Remove'
    elif oldleadstatus=='New' and newleadstatus=='Inactive':
        return 'New_Inactive'
    elif oldleadstatus=='Active' and newleadstatus=='Inactive':
        return 'Inactive'
    elif oldleadstatus=='Active' and newleadstatus=='Active':
        return 'Active'
    elif oldleadstatus=='New' and newleadstatus=='Active':
        return 'New'
    else:
        return 'Check'
    
    
def final_leadstatus(statusoflead,laststatuscode_new,laststatuscode_old):
    if statusoflead=='Active':
        return laststatuscode_new
    elif statusoflead=='New':
        return laststatuscode_new
    elif statusoflead=='Inactive':
        return 'Inactive'
    elif statusoflead=='New_Inactive':
        return 'New_Inactive'
    else:
        return 'Check'
    
    
def transition(laststatuscode_new,laststatuscode_old):
    if laststatuscode_new != laststatuscode_old:
        return 1
    else:
        return 0
        
        
def tradingcustexclusion(laststatuscode_old,finalstatusoflead):
    if laststatuscode_old == 'S5' and finalstatusoflead == 'S5':
        return 1
    else:
        return 0

# ### Month Comparison

# In[13]:

pipelinedatamerge['Status_of_lead'] = pipelinedatamerge.apply(lambda x:finalstatus(x['LeadStatus_Old'],x['LeadStatus_New']),axis=1)
pipelinedatamerge = pipelinedatamerge[pipelinedatamerge['Status_of_lead']!='Remove']
pipelinedatamerge['Final_last_status_code'] = pipelinedatamerge.apply(lambda x:final_leadstatus(x['Status_of_lead'],x['LastStatusCode_New'],x['LastStatusCode_Old']),axis=1)
#pipelinedatamerge['Trading_customers'] = pipelinedatamerge.apply(lambda x:tradingcustexclusion(x['LeadStatus_Old'],x['Final_last_status_code']),axis=1)

##pipelinedatamerge = pipelinedatamerge[(pipelinedatamerge['LastStatusCode_Old']!='S5') & (pipelinedatamerge['LastStatusCode_New']!='S5')] # To exclude already trading customers
pipelinedatamerge['Transition'] = pipelinedatamerge.apply(lambda x:transition (x['Final_last_status_code'],x['LastStatusCode_Old']),axis=1)

pipelinedatamergepivot = pd.pivot_table(pipelinedatamerge,index=['SalesPersonName','LastStatusCode_Old','Final_last_status_code'],values=['Leadid','Transition'],aggfunc={'Leadid':len,'Transition':sum},fill_value=0).reset_index()
pipelinedatamergepivot_summary = pd.pivot_table(pipelinedatamerge,index=['SalesPersonName'],values=['Leadid','Transition'],aggfunc={'Leadid':len,'Transition':sum},fill_value=0).reset_index()


# ### Week comparison

# In[14]:

pipelinedatamerge_lw['Status_of_lead'] = pipelinedatamerge_lw.apply(lambda x:finalstatus(x['LeadStatus_LW'],x['LeadStatus_New']),axis=1)
pipelinedatamerge_lw = pipelinedatamerge_lw[pipelinedatamerge_lw['Status_of_lead']!='Remove']
pipelinedatamerge_lw['Final_last_status_code'] = pipelinedatamerge_lw.apply(lambda x:final_leadstatus(x['Status_of_lead'],x['LastStatusCode_New'],x['LastStatusCode_LW']),axis=1)

##pipelinedatamerge_lw = pipelinedatamerge_lw[(pipelinedatamerge_lw['LastStatusCode_LW']!='S5') & (pipelinedatamerge_lw['LastStatusCode_New']!='S5')] # To exclude already trading customers
pipelinedatamerge_lw['Transition'] = pipelinedatamerge_lw.apply(lambda x:transition (x['Final_last_status_code'],x['LastStatusCode_LW']),axis=1)

pipelinedatamerge_lwpivot = pd.pivot_table(pipelinedatamerge_lw,index=['SalesPersonName','LastStatusCode_LW','Final_last_status_code'],values=['Leadid','Transition'],aggfunc={'Leadid':len,'Transition':sum},fill_value=0).reset_index()
pipelinedatamerge_lwpivot_summary = pd.pivot_table(pipelinedatamerge_lw,index=['SalesPersonName'],values=['Leadid','Transition'],aggfunc={'Leadid':len,'Transition':sum},fill_value=0).reset_index()

# In[15]:

#pipelinedatamerge = pipelinedatamerge.drop('CustName',axis=1)
pipelinedatamerge['CustName'] = pipelinedatamerge['CustName'].str.decode('utf-8').replace(u'\0xe2', '-')
pipelinedatamerge_lw['CustName'] = pipelinedatamerge_lw['CustName'].str.decode('utf-8').replace(u'\0xe2', '-')


# In[16]:

# pipelinedatamerge.to_csv(r'C:\Data\Customer_lead_management\Pipeline_transition_18052016\Pipeline_oldnew_merge_2405.csv')
# pipelinedatamergepivot.to_csv(r'C:\Data\Customer_lead_management\Pipeline_transition_18052016\Pipeline_oldnew_merge_pivot_2405.csv')
# pipelinedatamergepivot_summary.to_csv(r'C:\Data\Customer_lead_management\Pipeline_transition_18052016\pipelinedatamergepivot_summary.csv')

# pipelinedatamerge_lw.to_csv(r'C:\Data\Customer_lead_management\Pipeline_transition_18052016\Pipeline_oldnew_merge_2405_LW.csv')
# pipelinedatamerge_lwpivot.to_csv(r'C:\Data\Customer_lead_management\Pipeline_transition_18052016\Pipeline_oldnew_merge_pivot_2405_LW.csv')
# pipelinedatamerge_lwpivot_summary.to_csv(r'C:\Data\Customer_lead_management\Pipeline_transition_18052016\pipelinedatamergepivot_summary_LW.csv')


# In[17]:

pipelineactivedata = pipelinedata[pipelinedata['LeadStatus']=='Active']

pipelineactivedatalastmonth = pipelinedataold_1[pipelinedataold_1['LeadStatus']=='Active']

pipelineactivedatapivot = pd.pivot_table(pipelineactivedata,index=['SaleRegion','saleDepot','Channel','SalesPersonName','LastStatusCode'],values=['Leadid','PotentialRevenueInLakhs'],aggfunc={'Leadid':len,'PotentialRevenueInLakhs':pd.np.sum},fill_value=0).reset_index()
pipelineactivedatalastmonthpivot = pd.pivot_table(pipelineactivedatalastmonth,index=['SaleRegion','saleDepot','Channel','SalesPersonName','LastStatusCode'],values=['Leadid','PotentialRevenueInLakhs'],aggfunc={'Leadid':len,'PotentialRevenueInLakhs':pd.np.sum},fill_value=0).reset_index()

leadstatusnowtolastmonthend = pd.merge(pipelineactivedatapivot,pipelineactivedatalastmonthpivot,on=['SaleRegion','saleDepot','Channel','SalesPersonName','LastStatusCode'],suffixes=['_Yest','_Lastmonth'],how='outer')


### 6 Month Lead summary start

leaddataactiveactivesum_pivot = pd.pivot_table(pipelinedata_1,index=['SaleRegion','LastStatusCode','LastStatusDesc'],values=['Leadid','PotentialRevenueInLakhs'],aggfunc={'Leadid':len,'PotentialRevenueInLakhs':np.sum}).reset_index()
leaddataactiveactivesum_pivot_all = pd.pivot_table(pipelinedata_1,index=['LastStatusCode','LastStatusDesc'],values=['Leadid','PotentialRevenueInLakhs'],aggfunc={'Leadid':len,'PotentialRevenueInLakhs':np.sum}).reset_index()
leaddataactiveactivesum = leaddataactiveactivesum_pivot.append(leaddataactiveactivesum_pivot_all,ignore_index=True)
leaddataactiveactivesum.SaleRegion.fillna('PAN_INDIA',inplace=True)

columnsmtdsum = ['SaleRegion','LastStatusCode','LastStatusDesc','Leadid','PotentialRevenueInLakhs']
leaddataactiveactivesum = pd.DataFrame(leaddataactiveactivesum,columns=columnsmtdsum)

leaddataactiveactivesum = leaddataactiveactivesum.rename(columns={'PotentialRevenueInLakhs':'Revenue(L)',})

leaddataactiveactivesumeast = leaddataactiveactivesum[leaddataactiveactivesum['SaleRegion']=='East']
eastleads = leaddataactiveactivesumeast['Leadid'].sum()
eastrev = leaddataactiveactivesumeast['Revenue(L)'].sum()
eastsumlist = ['East_Total','-','-',eastleads,eastrev]
eastcol_list = ['SaleRegion','LastStatusCode','LastStatusDesc','Leadid','Revenue(L)']
easttotals = pd.DataFrame(data=[eastsumlist], columns = eastcol_list)
leaddataactiveactivesumeast = leaddataactiveactivesumeast.append(easttotals,ignore_index=True)

leaddataactiveactivesumnorth = leaddataactiveactivesum[leaddataactiveactivesum['SaleRegion']=='North']
northleads = leaddataactiveactivesumnorth['Leadid'].sum()
northrev = leaddataactiveactivesumnorth['Revenue(L)'].sum()
northsumlist = ['North_Total','-','-',northleads,northrev]
northcol_list = ['SaleRegion','LastStatusCode','LastStatusDesc','Leadid','Revenue(L)']
northtotals = pd.DataFrame(data=[northsumlist], columns = northcol_list)
leaddataactiveactivesumnorth = leaddataactiveactivesumnorth.append(northtotals,ignore_index=True)

leaddataactiveactivesumsouth = leaddataactiveactivesum[leaddataactiveactivesum['SaleRegion']=='South']
southleads = leaddataactiveactivesumsouth['Leadid'].sum()
southrev = leaddataactiveactivesumsouth['Revenue(L)'].sum()
southsumlist = ['South_Total','-','-',southleads,southrev]
southcol_list = ['SaleRegion','LastStatusCode','LastStatusDesc','Leadid','Revenue(L)']
southtotals = pd.DataFrame(data=[southsumlist], columns = southcol_list)
leaddataactiveactivesumsouth = leaddataactiveactivesumsouth.append(southtotals,ignore_index=True)

leaddataactiveactivesumwest = leaddataactiveactivesum[leaddataactiveactivesum['SaleRegion']=='West']
westleads = leaddataactiveactivesumwest['Leadid'].sum()
westrev = leaddataactiveactivesumwest['Revenue(L)'].sum()
westsumlist = ['West_Total','-','-',westleads,westrev]
westcol_list = ['SaleRegion','LastStatusCode','LastStatusDesc','Leadid','Revenue(L)']
westtotals = pd.DataFrame(data=[westsumlist], columns = westcol_list)
leaddataactiveactivesumwest = leaddataactiveactivesumwest.append(westtotals,ignore_index=True)

leaddataactiveactivesumpanindia = leaddataactiveactivesum[leaddataactiveactivesum['SaleRegion']=='PAN_INDIA']
panindialeads = leaddataactiveactivesumpanindia['Leadid'].sum()
panindiarev = leaddataactiveactivesumpanindia['Revenue(L)'].sum()
panindiasumlist = ['PAN_INDIA_Total','-','-',panindialeads,panindiarev]
panindiacol_list = ['SaleRegion','LastStatusCode','LastStatusDesc','Leadid','Revenue(L)']
panindiatotals = pd.DataFrame(data=[panindiasumlist], columns = panindiacol_list)
leaddataactiveactivesumpanindia = leaddataactiveactivesumpanindia.append(panindiatotals,ignore_index=True)


leaddataactiveactivesumpanindia_e = leaddataactiveactivesumpanindia.append(leaddataactiveactivesumeast,ignore_index=True)
leaddataactiveactivesumpanindia_en = leaddataactiveactivesumpanindia_e.append(leaddataactiveactivesumnorth,ignore_index=True)
leaddataactiveactivesumpanindia_ens = leaddataactiveactivesumpanindia_en.append(leaddataactiveactivesumsouth,ignore_index=True)
leaddataactiveactivesumpanindia_ensw = leaddataactiveactivesumpanindia_ens.append(leaddataactiveactivesumwest,ignore_index=True)

### 6 Month Lead summary end
# In[18]:

with ExcelWriter(r'D:\Data\Sales_lead_management\Pipeline_report\Sales_pipeline_report_'+str(yesterdate)+'.xlsx') as writer:
    leaddataactiveactivesumpanindia_ensw.to_excel(writer, sheet_name='6M_Lead_Summary',engine='xlsxwriter')
    pipelinedatamergepivot.to_excel(writer, sheet_name='LM_Sales_person_wise',engine='xlsxwriter')
    pipelinedatamergepivot_summary.to_excel(writer, sheet_name='LM_Sales_person_wise_Summary',engine='xlsxwriter')
    pipelinedatamerge_lwpivot.to_excel(writer, sheet_name='LW_Sales_person_wise',engine='xlsxwriter')
    pipelinedatamerge_lwpivot_summary.to_excel(writer, sheet_name='LW_Sales_person_wise_Summary',engine='xlsxwriter')
    leadstatusnowtolastmonthend.to_excel(writer, sheet_name='Lead_status_summary',engine='xlsxwriter')
    pipelinedatamerge.to_excel(writer, sheet_name='LM_Comparison_data',engine='xlsxwriter')
    pipelinedatamerge_lw.to_excel(writer, sheet_name='LW_Comparison_data',engine='xlsxwriter')


oppath2 = r'D:\Data\Sales_lead_management\Pipeline_report\Sales_pipeline_report_'+str(yesterdate)+'.xlsx'
# In[19]:

filePath1 = oppath2
def sendEmail(#TO = ["Ankit@iepfunds.com"],
              TO = ["vishwas.j@spoton.co.in"],
             #TO = ["rajeesh.vr@spoton.co.in"],
             #CC = ["supratim@iepfunds.com","abhik.mitra@spoton.co.in","rajeesh.vr@spoton.co.in","vishwas.j@spoton.co.in"],
            CC = ["vishwas.j@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "Sales_Pipeline_report"
    msg["Subject"] = "Sales_Pipeline_report"
    body_text = """
    Dear All,
    
    PFA the Sales pipeline report
    
    
    """
    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath1,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath1))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends

