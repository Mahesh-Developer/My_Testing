# -*- coding: utf-8 -*-
"""
Created on Fri Apr 14 19:37:03 2017

@author: rajeeshv
"""
import pandas as pd
from datetime import datetime, timedelta
from pandas import ExcelWriter

thcinscan = pd.io.excel.read_excel('http://spoton.co.in/downloads/IEP_THC_INCOMING_OUTGOING_SCAN/IEP_THC_INCOMING_OUTGOING_SCAN.xls','THC Incoming Scan Report')
thcoutscan = pd.io.excel.read_excel('http://spoton.co.in/downloads/IEP_THC_INCOMING_OUTGOING_SCAN/IEP_THC_INCOMING_OUTGOING_SCAN.xls','THC Outgoing Scan Report')

datetoday = datetime.today()
datefilter = datetoday-timedelta(hours=24)
datefilter=datefilter.date()
datefilter

with ExcelWriter(r'D:\Data\THC_Inscan_Outscan_Tally\Basedata\THC_Inscan_Outscan_Tally_'+str(datefilter)+'.xlsx') as writer:
    thcinscan.to_excel(writer, sheet_name='THC Incoming Scan Report',engine='xlsxwriter')
    thcoutscan.to_excel(writer, sheet_name='THC Outgoing Scan Report',engine='xlsxwriter')