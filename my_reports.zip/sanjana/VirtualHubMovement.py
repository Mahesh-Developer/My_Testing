
# coding: utf-8

# In[ ]:
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from sqlalchemy import *
import smtplib
import os
import traceback
import ftplib
import Utilities
#cnxn1 = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.87;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
#cursor1 = cnxn1.cursor()
# cnxn1 = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor1 = cnxn1.cursor()
try:
	cnxn1 = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
	cursor1 = cnxn1.cursor()

	pd.set_option("display.max_columns",120)
	pd.set_option("display.max_colwidth",1000)
	import simplejson
	import urllib
	import sys;
	reload(sys);
	sys.setdefaultencoding("utf8")
	#intransitdf=pd.read_excel(r'http://spoton.co.in/downloads/TCR_UND_2HRS/TCR_UND_ISDEPART_YES_2HRS.xls')
	#invdf=pd.read_excel(r'http://spoton.co.in/downloads/HTR_1HR/HTR_1HR.xls')
	stockquery1 = ("""SELECT     *
	 
	 
	  FROM tblTimeConnectionReport_Undelivered_2HRS   
	    WHERE ISDEPARTED_FRM_CURRLOC='YES'""")
	print (stockquery1)

	intransitdf=pd.read_sql(stockquery1,Utilities.cnxn)
	intransitdf.rename(columns={'CDELDT':'DUE DATE','ORIGIN_BRCODE':'ORIGIN BRCODE','CURR_BRANCHCODE':'CURR BRANCHCODE','ISDEPARTED_FRM_CURRLOC':'IS DEPARTED FRM CURRLOC','DEPARTURE_TIME_FRM_CURLOC':'DEPARTURE TIME FRM CURLOC','DEPARTURE_TO_LOC_FRM_CURLOC':'DEPARTURE TO LOC FRM CURLOC','DEPARTED_FRM_CURRLOC_THCNO':'DEPARTED FRM CURRLOC THCNO','DEPARTED_FRM_CURRLOC_ROUTECD':'DEPARTED FRM CURRLOC ROUTECD','DEPARTED_FRM_CURRLOC_VEHNO':'DEPARTED FRM CURRLOC VEHNO','DOCKDT':'PICKUP DATE','LatestConStatusCode':'Latest Con Status Code','TCNO_FROM_HUB':'TCNO FROM HUB','THC_VENDOR_TYPE':'THC VENDOR TYPE','THC_SOURC':'THC SOURC','THC_DEST':'THC DEST','THC_ETA':'THC ETA','THC_ARRI_ENTRY':'THC ARRI ENTRY','THC_LAST_UPDATE_HR':'THC LAST UPDATE HR','THC_ROUTE_NAME':'THC ROUTE NAME','THC_LAST_TIME':'THC LAST TIME','ApptmntDelDate':'Apptmnt Del Date','TIME_STAMP':'TIMESTAMP'},inplace=True)
	# 
	htrquery = ("""EXEC USP_HUB_THROUGHPUT_DETAILS_SALES_ONEHOUR""")
	print (htrquery)
	invdf = pd.read_sql(htrquery, Utilities.cnxn)
	invdf.rename(columns={'Hub/SC Location':"Hub SC Location",'Arrival Date @ Hub':"Arrival Date Hub",'DestnBranch':"Destn Branch",'Act.WtInTonnes':"Act Wt In Tonnes",'LatestStatusCode':"Latest Status Code",'OriginArea':"Origin Area",'DestnArea':'Destn Area'},inplace=True)

	invdf['OD']=zip(invdf['Hub SC Location'],invdf['Destn Branch'])
	import pickle
	try:
	    pkl_file = open(r'D:\Path Dict\path_dict.pkl', 'rb')
	except:
	    pkl_file = open(r'C:\Users\ankit\Dropbox\Python\testrest\Async2\Async2\path_dict.pkl', 'rb')
	path_dict = pickle.load(pkl_file)
	pkl_file.close()
	invdf["Resid_Path"]=invdf['OD'].map(lambda x: path_dict.get((x[0],x[1]))[0] if path_dict.get((x[0],x[1]))!=None else [0,0])

	def getNextLoc(pth,con):
	    try:
	        nxtloc=pth[1]
	        return nxtloc
	    except:
	        return '-'

	invdf['NextLoc']=invdf.apply(lambda x: getNextLoc(x['Resid_Path'],x['Con Number']),axis=1)


	#invdf['NextLoc']=invdf['Resid_Path'].map(lambda x: x[1])
	mergedf = pd.merge(invdf,intransitdf,left_on=['Con Number'], right_on=['DOCKNO'], how='inner')
	invdf_correct=invdf[~invdf['Con Number'].isin(mergedf['Con Number'])]
	# invdf_correct.to_csv(r'virtualhub_data_2018-08-30.csv')
	# exit(0)
	invdf_correct['cooling']=(invdf_correct['TIMESTAMP']-invdf_correct['Arrival Date Hub'])/np.timedelta64(1,'h')
	depspaperworkcodelist = ['SRE','SRD','SRS','SRP','DLP','SWP','PWS','HCM','HPM','MOP','SRH','HOC','ONR','SPH','SPO','DBO','DIP','SHS','SSC','HIP','RNX','APT','APN','SHD','SMT','SPL','MSH','UCG','RRA','HPE','WIA','UG1','UG2','UG3','HMP','HWC','NPE','HIM']
	virtualhub=pd.read_excel(r'C:\Users\rajeeshv\Downloads\Virtual Hub.xlsx')
	invdf_correct['OD']=invdf_correct.apply(lambda x:str(x['Hub SC Location'])+'-'+str(x['NextLoc']),axis=1)
	virtualcon=invdf_correct[~invdf_correct['Latest Status Code'].isin(depspaperworkcodelist)]
	virtualcon=virtualcon[virtualcon['OD'].isin(virtualhub['VIrtual Hub'].tolist())]
	virtualcon['OLDCONS']=virtualcon.apply(lambda x: 0 if x['Arrival Date Hub']>datetime.strptime('2017-12-01','%Y-%m-%d' )else 1,axis=1)
	virtualcon=virtualcon[virtualcon['OLDCONS']==0]
	virtualdf=virtualcon.pivot_table(index=['Hub SC Location','NextLoc'],aggfunc={'Act Wt In Tonnes':np.sum,'Con Number':len,'cooling':np.mean}).reset_index().sort_values('Act Wt In Tonnes',ascending=False)
	virtualdf=virtualdf[(virtualdf['cooling']>3)]
	virtualdf.rename(columns={'Act Wt In Tonnes':'ACTWT','Con Number':'CONS','cooling':'Cooling'},inplace=True)
	virtualdf=virtualdf[['Hub SC Location','NextLoc','ACTWT','CONS','Cooling']]
	virtualdf['ACTWT']=pd.np.round(virtualdf['ACTWT'],1)
	virtualdf['Cooling']=pd.np.round(virtualdf['Cooling'],1)
	maildf=virtualdf.head(10)
	reportts = datetime.now()
	opfilevar=reportts.date()
	opfilevar1=reportts.time()
	ct2= str (opfilevar1)
	currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

	opfilevar2=np.round((float(currhrs)/60),0)
	virtualcon.to_csv(r'D:\Data\Virtual load movement\virtualcon-'+str(opfilevar)+"-"+str(opfilevar2)+'.csv')
	virtualcon.to_csv(r'D:\Data\Virtual load movement\virtualcon.csv')
	filepath = r'D:\Data\Virtual load movement\virtualcon.csv'
	# TO=["hubmgr_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in","cnm@spoton.co.in","sq_spot@spoton.co.in"]
	#TO=['sqtf@spoton.co.in','supratim@iepfunds.com','ankit@iepfunds.com','vishwas.j@spoton.co.in','pawan.sharma@spoton.co.in','krishna.chandrasekar@spoton.co.in','prasanna.hegde@spoton.co.in']
	TO=['pawan.sharma@spoton.co.in','abhik.mitra@spoton.co.in','Rajesh.Kumar@spoton.co.in','Jothi.Menon@spoton.co.in','shivananda.p@spoton.co.in','satya.pal@spoton.co.in','anitha.thyagarajan@spoton.co.in','shashvat.suhane@spoton.co.in']
	FROM='reports.ie@spoton.co.in'
	# CC=['sqtf@spoton.co.in','rajesh.kapase@spoton.co.in','Manjunath.Swamy@Spoton.Co.In','mahesh.reddy@spoton.co.in','shashvat.suhane@spoton.co.in','supratim@iepfunds.com','ankit@iepfunds.com','vishwas.j@spoton.co.in']
	# BCC = ['yogesh.singh@spoton.co.in','prabhakar.mahajan@spoton.co.in','nitin.tatyarao@spoton.co.in','vinodkumar.mishra@spoton.co.in','jai.prakash@spoton.co.in','nomesh.ganvir@spoton.co.in','sanjay.panse@spoton.co.in','sunil.khare@spoton.co.in']
	CC=['mahesh.reddy@spoton.co.in']
	msg = MIMEMultipart()
	msg["From"] = FROM
	msg["To"] = ",".join(TO)
	msg["CC"] = ",".join(CC)
	# msg["BCC"] = ",".join(BCC)
	#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
	msg["Subject"] = "Virtual location load available -"+ str(opfilevar)+"-"+str(opfilevar2)
	html='''<html>
	<h4>Dear All,</h4>
	PFB the loads available for the Hub-Virtual SC and vice versa<br> </br>'''+maildf.to_html()+'''</html>'''
	# report=""
	# # report+='<br>'
	# report+='PFB the weight which are available in stock where distance between two location less than 500'
	# # report+='<br>'
	# report+=''
	# report+='<br>'+senddf2.to_html()+'<br>'
	klm=MIMEText(html,'html')
	msg.attach(klm)
	# bcd=MIMEText(senddf1.to_html(),'html')
	# msg.attach(bcd)
	# abc=MIMEText(report,'html')
	# msg.attach(abc)
	part = MIMEBase('application', "octet-stream")
	part.set_payload( open(filepath,"rb").read() )
	encoders.encode_base64(part)
	part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
	msg.attach(part)
	server=smtplib.SMTP('smtp.sendgrid.net', 587)
	server.ehlo()
	server.starttls()
	server.ehlo()
	server.login("spoton.net.in", "Star@123#")
	failed = server.sendmail(FROM, TO+CC, msg.as_string())
	server.quit()
	# import win32com.client as win32
	# outlook = win32.Dispatch('outlook.application')
	# mail = outlook.CreateItem(0)
	# mail.To = 'my email address'
	# mail.Subject = 'My subject'

	# html1 = '<br></br>'+html+senddf1.to_html()+"<br></br>"+report
	# mail.Body = hmtl
	# mail.Send()

except:
  TO=['mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  #msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "ERROR Report" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in Virtual location load available '
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO, msg.as_string())
  server.quit()

