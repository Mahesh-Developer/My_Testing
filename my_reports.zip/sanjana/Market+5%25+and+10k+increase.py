
# coding: utf-8

# In[1]:

import pandas as pd
from datetime import datetime, timedelta

from pandas import pivot_table
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import os
import traceback
import ftplib

#datetoday=datetime.today()
#datefilter = datetoday-timedelta(hours=24)
#datefilter=datefilter.date()
#datefilter


# In[22]:

dieselvar = -2.01  #Update from variance from Prasanna -indicates net impact diesel price dropped


# In[2]:

pmdlh30 = pd.read_excel('http://spoton.co.in/downloads/PMDLH/PMDLH_30DAYS.xls')


# In[3]:

pmdlh = pd.read_excel('http://spoton.co.in/downloads/PMDLH/PMDLH.xls')


# In[4]:

kms = pd.read_excel(r'D:\Python\Scripts and Files\Python Scripts\km_mileage.xlsx', 'Kms')
mileage = pd.read_excel(r'D:\Python\Scripts and Files\Python Scripts\km_mileage.xlsx', 'Mileage')


# In[5]:

pmdlh30mkt = pmdlh30[pmdlh30['ROUTE CODE']=='9888']


# In[6]:

len(pmdlh30mkt), len(pmdlh30)


# In[7]:

pmdlh30grp = pmdlh30mkt.groupby(['ROUTE NAME','VEHICLE PAYLOAD']).agg({'THC NUMBER':len,'COST':sum}).reset_index()


# In[8]:

pmdlh30grp['AvgCost'] = pmdlh30grp.apply(lambda x: x['COST']/x['THC NUMBER'], axis=1)


# In[9]:

pmdlh30grp.head(2)


# In[10]:

len(pmdlh30grp)


# In[11]:

pmdlh30grp = pd.merge(pmdlh30grp, kms, on=['ROUTE NAME'], how='left')
pmdlh30grp = pd.merge(pmdlh30grp, mileage, on=['VEHICLE PAYLOAD'], how='left')


# In[12]:

pmdlh30grp.head(5)


# In[14]:

pmdlh30grp['Kms'].fillna(0, inplace=True)
pmdlh30grp.head(5)


# In[15]:

pmdlh30grp =pmdlh30grp.rename(columns={'THC NUMBER':'THCCount', 'COST':'COST30days'}) 


# In[23]:

pmdlh30grp['AdjCost'] = pmdlh30grp.apply(lambda x: pd.np.round(x['AvgCost']+(x['Kms']/x['Mileage'])*dieselvar, 0), axis=1)


# In[24]:

pmdlh30grp.head(2)


# In[25]:

import datetime
datefilter=(datetime.datetime.today()-timedelta(hours=24)).date()
date_ll = datetime.datetime.combine(datefilter, datetime.time(9,1))


# In[26]:

pmdlhmkt = pmdlh[(pmdlh['THC DATE']>=date_ll) & (pmdlh['ROUTE CODE']=='9888')]


# In[27]:

df = pd.merge(pmdlh30grp, pmdlhmkt, on=['ROUTE NAME','VEHICLE PAYLOAD'], how='inner')


# In[29]:

df['CostDiff%'] = df.apply(lambda x: pd.np.round((x['COST']*1.0/x['AdjCost']-1)*100,0) , axis=1)


# In[30]:

df['ActDiff'] = df.apply(lambda x: x['COST']-x['AdjCost'] , axis=1)
df['Util%'] = df.apply(lambda x: pd.np.round((x['TOTAL ACTUAL LOAD']*1.0/x['VEHICLE PAYLOAD'])*100,0) , axis=1)


# In[31]:

def getremarks(diff, amt, utl, img):
    if diff >=5 and amt>=10000:
        if utl <85 and img!='high':
            return 'Cost Alert and Low Util%'
        else:
            return 'Cost Alert'
    elif utl <85 and img!='high':
        return 'Low Util%'
    else:
        return 'Normal'

#df['Remarks'] = df.apply(lambda x: 'Exception' if (x['%diff']>=5 and x['ActDiff']>=10000) else 'Normal', axis=1)
df['Remarks'] = df.apply(lambda x: getremarks(x['CostDiff%'],x['ActDiff'],x['Util%'], x['Image Process Result']), axis=1)


# In[17]:

df.to_csv(r'D:\Data\Market_cost_exception\Basedata\Alldata_'+str(datefilter)+'.csv') #alldf save a link
df = df[['ROUTE NAME', 'VEHICLE PAYLOAD', 'AdjCost', 'THC NUMBER', 'COST','ActDiff','CostDiff%','TOTAL ACTUAL LOAD','Util%', 'Remarks']] #uploading with limited columns as per Pawan Sirs requirement
df.to_csv(r'D:\Data\Market_cost_exception\Alldata.csv')
oppath_data = r'D:\Data\Market_cost_exception\Alldata.csv'


# For link in the email 

print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppath_data
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()

# For link in the email 

# In[23]:

exc_df = df[df['Remarks']!='Normal']
exc_df.to_csv(r'D:\Data\Market_cost_exception\Summary\Market_Exception_'+str(datefilter)+'.csv') #attachment
exc_df = exc_df[['ROUTE NAME', 'VEHICLE PAYLOAD', 'AdjCost', 'THC NUMBER', 'COST','CostDiff%','ActDiff','TOTAL ACTUAL LOAD','Util%', 'Remarks']] #uploading with limited columns as per Pawan Sirs requirement
exc_df.to_csv(r'D:\Data\Market_cost_exception\Market_Exception.csv')
oppath_summary = r'D:\Data\Market_cost_exception\Market_Exception.csv'


# In[21]:

if len(exc_df)>0:
    maildf = exc_df[['ROUTE NAME', 'VEHICLE PAYLOAD', 'AdjCost', 'COST','ActDiff','TOTAL ACTUAL LOAD','Util%', 'Remarks']]
    maildf = maildf.rename(columns={'VEHICLE PAYLOAD':'Payload', 'TOTAL ACTUAL LOAD': 'TotalWt', 'AdjCost':'AvgCost'}) 
    maildf = maildf[maildf['Payload']==13500]    
    maildf = maildf.to_string(index=False)
else:
    maildf = 'There is no market vehicle used with 5% increase in cost and more than Rs 10000 and low util%'


# In[ ]:

maildf #mailbody

filePath = oppath_summary
def sendEmail(TO = ["pawan.sharma@spoton.co.in","prasanna.hegde@spoton.co.in"],
            #TO = ["rajeesh.vr@spoton.co.in"],
            #CC = ["vishwas.j@spoton.co.in"],
            CC = ["krishna.chandrasekar@spoton.co.in"],
            BCC = ["mahesh.reddy@spoton.co.in"] ,
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "Load Available for movement @ "+ str(opfilevar)+"-"+str(opfilevar2)
    msg["Subject"] = "Market Cost Exception Report"+"-"+str(datefilter)
    body_text = """
    Dear All,
    
    PFA the Market Cost Exception report for """ +str(datefilter)+"""

"""+str(maildf)+"""
    
    For basedata, please use the link below
    
    http://spoton.co.in/downloads/IEProjects/ETA/Alldata.csv
    """
    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')