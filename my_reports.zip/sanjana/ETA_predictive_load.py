
# coding: utf-8

# In[1]:

import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta, date
import os
import ftplib
import traceback
import Utilities

# In[2]:

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()

#cursor.execute("select TOP 10 DOCKNO from docket")
#rows = cursor.fetchall()
#for row in rows:
#    print row.DOCKNO
# try:

query = ("""
        EXEC USP_ETA_PREDICTION_SQ
        """)


# In[3]:

predictivelddf = pd.read_sql(query, Utilities.cnxn)


# In[4]:

len(predictivelddf)


# In[5]:

def wtbucket(contype):
    if contype<=1.0:
        return '1_<=1'
    elif contype>1.0 and contype<=2.0:
        return '2_1T-2T'
    elif contype>2.0 and contype<=3.0:
        return '3_2T-3T'
    else:
        return '4_>3T'


# In[6]:

predictivelddf['CON TYPE'] = predictivelddf.apply(lambda x:wtbucket(x['Weight IN TONS']),axis=1)


# In[10]:

predareasum = pd.pivot_table(predictivelddf,index=["ControlArea"],columns=["ETADATE"],values=["DOCKNO","Weight IN TONS"],
               aggfunc={"DOCKNO":len,"Weight IN TONS":pd.np.sum},fill_value=0).reset_index()



# In[11]:

predareacontype = pd.pivot_table(predictivelddf,index=["ControlArea"],columns=["ETADATE",'CON TYPE'],values=["DOCKNO"],
               aggfunc={"DOCKNO":len},fill_value=0).reset_index()


# In[12]:

predareacontype_sc = pd.pivot_table(predictivelddf,index=["ControlArea","brnm"],columns=["ETADATE",'CON TYPE'],values=["DOCKNO"],
               aggfunc={"DOCKNO":len},fill_value=0).reset_index()


# In[13]:

predareasum = predareasum.rename(columns={'DOCKNO':'No of Cons'})
predareacontype = predareacontype.rename(columns={'DOCKNO':'No of Cons'})
predareacontype_sc = predareacontype_sc.rename(columns={'DOCKNO':'No of Cons'})

datetoday=datetime.today()
opfilevarhours =datetoday.date()
# In[15]:

with ExcelWriter(r'D:\Data\ETA_Predictive_Load\Summary\ETA_Report'+str(opfilevarhours)+'.xlsx') as writer:
    predareasum.to_excel(writer, sheet_name='Summary',engine='xlsxwriter')
    predareacontype.to_excel(writer, sheet_name='Summary_for_Ton_wise',engine='xlsxwriter')
    predareacontype_sc.to_excel(writer, sheet_name='Branch_Wise',engine='xlsxwriter')

with ExcelWriter(r'D:\Data\ETA_Predictive_Load\ETA_Report.xlsx') as writer:
    predareasum.to_excel(writer, sheet_name='Summary',engine='xlsxwriter')
    predareacontype.to_excel(writer, sheet_name='Summary_for_Ton_wise',engine='xlsxwriter')
    predareacontype_sc.to_excel(writer, sheet_name='Branch_Wise',engine='xlsxwriter')
    
oppath2=r'D:\Data\ETA_Predictive_Load\ETA_Report.xlsx'
filepath = oppath2
# In[16]:

#Expected Loads Code Starts from here

pmd_sep = pd.read_csv(r'D:\Data\PMD_Save\PMD_2019-07-31.csv')
pmdsep1 = pmd_sep[['BRANCH_CODE2','PINCODE2','CUSTOMERCODE','CUSTOMERNAME','PUD_CODE2','PUD_NAME2','PUDTYPE2','ACT_WT2','TYP2']]
pmd_aug = pd.read_csv(r'D:\Data\PMD_Save\PMD_2019-08-24.csv')
pmdaug1 = pmd_aug[['BRANCH_CODE2','PINCODE2','CUSTOMERCODE','CUSTOMERNAME','PUD_CODE2','PUD_NAME2','PUDTYPE2','ACT_WT2','TYP2']]
pmd_july = pd.read_csv(r'D:\Data\PMD_Save\PMD_2019-09-17.csv')
pmdjuly1 = pmd_july[['BRANCH_CODE2','PINCODE2','CUSTOMERCODE','CUSTOMERNAME','PUD_CODE2','PUD_NAME2','PUDTYPE2','ACT_WT2','TYP2']]
len(pmdsep1), len(pmdaug1), len(pmdjuly1)

pmdappend = pmdsep1.append(pmdaug1)
pmd0 = pmdappend.append(pmdjuly1)
len(pmd0)

pmd0=pmd0[pmd0['TYP2']=='DLV']
pivot=pmd0.pivot_table(index=['BRANCH_CODE2','PINCODE2','CUSTOMERCODE','PUD_NAME2'],values=['ACT_WT2'],aggfunc={'ACT_WT2':sum}).reset_index()
pivot1=pivot.sort_values('ACT_WT2',ascending=False)
pivot1['primary_key'] = pivot1.apply(lambda x:x['BRANCH_CODE2']+'-'+str(x['PINCODE2'])+str('-')+str(x['CUSTOMERCODE']),axis=1)
pivot2=pivot1.drop_duplicates(subset='primary_key', keep='first')

predictivelddf['Customer Code']=predictivelddf['Customer Code'].apply(lambda x:x if x==None else x[3:])
predictivelddf=predictivelddf.fillna(0)
predictivelddf['Customer Code']=predictivelddf['Customer Code'].astype(int)
predictivelddf.rename(columns={'PinCode':'PINCODE2','Customer Code':'CUSTOMERCODE','REASSIGN_DESTCD':'BRANCH_CODE2'},inplace=True)
predictivelddf=pd.merge(predictivelddf,pivot2,on=['BRANCH_CODE2','PINCODE2','CUSTOMERCODE'],how='left')

import math
def getPincode(pudname,pincode):
    if pd.isnull(pudname):
        return pincode
    else:
        return pudname

predictivelddf['PUD_NAME']=predictivelddf.apply(lambda x: getPincode(x['PUD_NAME2'],x['PINCODE2']),axis=1)
predictivelddf_pivot=predictivelddf.pivot_table(index=['ControlArea','BRANCH_CODE2','PINCODE2','CUSTOMERCODE','PUD_NAME'],
                                            values=['DOCKNO','ACTUWT'],
                                           aggfunc={'DOCKNO':len,'ACTUWT':sum}).reset_index()


grp_pivot=predictivelddf_pivot.pivot_table(index=['BRANCH_CODE2','PUD_NAME'],values=['DOCKNO','ACTUWT'],
                                        aggfunc={'DOCKNO':len,'ACTUWT':sum}).reset_index()

grp_pivot['Wt(T)']=pd.np.round(grp_pivot['ACTUWT']/1000,1)
grp_pivot=grp_pivot.drop('ACTUWT',axis=1)

grp_pivot=grp_pivot.sort_values(['BRANCH_CODE2','Wt(T)'],ascending=[True,False])
grp_pivot = grp_pivot[grp_pivot['PUD_NAME']!='MARKET']
grp_pivot = grp_pivot[grp_pivot['PUD_NAME']!='COUNTER']

##ends here

predictivelddf.to_csv(r'D:\Data\ETA_Predictive_Load\Data\Predictive_load_data_'+str(opfilevarhours)+'.csv')
predictivelddf.to_csv(r'D:\Data\ETA_Predictive_Load\Predictive_load_data.csv')
oppath1 = r'D:\Data\ETA_Predictive_Load\Predictive_load_data.csv'
filepath1 = oppath1


print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppath1
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()

# In[25]:

def send_email(to=['AOM_SPOT@spoton.co.in','DOM_SPOT@spoton.co.in','ROM_SPOT@spoton.co.in','scincharge_spot@spoton.co.in'],
                 cc=["SQ_spot@spoton.co.in","sqtf@spoton.co.in","mahesh.reddy@spoton.co.in"],
                # to=["vishwas.j@spoton.co.in"],
               user="mis.ho@spoton.co.in"):
    msgRoot = MIMEMultipart('related')
    msgRoot['Subject'] = "Predicted Load arrivals at Destination"
    msgRoot['From'] = user
    msgRoot['To'] = ", ".join(to)
    msgRoot['Cc'] = ", ".join(cc)
     
    msgRoot.preamble = 'This is a multi-part message in MIME format.'
    msgAlternative = MIMEMultipart('alternative')
    msgRoot.attach(msgAlternative)
    msgText = MIMEText('This is the alternative plain text message.')
    msgAlternative.attach(msgText)
    msgText = MIMEText('Dear All,'+'<br><br>'+'Please find the Predicted Load arrivals at Destination for next 4 days. The attachment has Branchwise summary'+'<br><br>'+'For data with Customer details, please download from the link below'+'<br><br>'+'http://spoton.co.in/downloads/IEProjects/ETA/Predictive_load_data.csv'+'<br><br>'+predareasum.to_html(), 'html')
    msgAlternative.attach(msgText)
    
    
    
    part = MIMEBase('application', "octet-stream")
    part.set_payload(open(filepath,"rb").read())
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' %os.path.basename(filepath))
    msgRoot.attach(part)
    server = smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    server.sendmail(user,to+cc,msgRoot.as_string())
    server.close()
    print 'successfully sent the mail'
    
    # try:
    #     server = smtplib.SMTP('smtp.spoton.co.in', 587)
    #     server.ehlo()
    #     server.starttls()
    #     server.ehlo()
    #     server.login("spoton.net.in", "Star@123#")
    #     server.sendmail(user,to+cc,msgRoot.as_string())
    #     server.close()
    #     print 'successfully sent the mail'
    # except:
    #     print "failed to send mail"


# In[26]:

if __name__ == "__main__":
    send_email()
print('Email sent')

# except:

#   TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in']  
#   CC=['mahesh.reddy@spoton.co.in']
#   FROM="mahesh.reddy@spoton.co.in"
#   msg = MIMEMultipart()
#   msg["From"] = FROM
#   msg["To"] = ",".join(TO)
#   msg["CC"] = ",".join(CC)
#   #msg["BCC"] = ",".join(BCC)
#   #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
#   msg["Subject"] = "ERROR Report" 
#   report=""
#   report+='Hi,'

#   report+='<br>'
#   report+='There was some error in Predicted Load arrivals at Destination'
#   report+='<br>'
  
#   abc=MIMEText(report.encode('utf-8'),'html')
#   msg.attach(abc)
#   server=smtplib.SMTP('smtp.sendgrid.net', 587)
#   server.ehlo()
#   server.starttls()
#   server.ehlo()
#   server.login("spoton.net.in", "Star@123#")
#   failed = server.sendmail(FROM, TO+CC, msg.as_string())
#   server.quit()


# In[ ]:



