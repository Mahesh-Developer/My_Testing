
# coding: utf-8

# In[1]:

import pandas as pd
import datetime
from datetime import datetime, timedelta
import calendar
import copy
import graphlab as gl
import graphlab.aggregate as agg
from itertools import izip

import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import os
# In[2]:

timeformatstring = '%m/%d/%Y %H:%M:%S %p'
timeformatstring2 = '%Y-%m-%d %H:%M:%S'
conprocessing = 1
dayzero = datetime.strptime('2015-1-1 00:00:00', timeformatstring2)
dayminu = datetime.strptime('2014-1-1 00:00:00', timeformatstring2)
link = 'http://spoton.co.in/downloads/HTR_1HR/HTR_1HR.xls'
#link2 = r'D:\Data\Routing_logic_sector_buildup\HTR_1HR(3).xls'
csvfilename = 'dfbase.csv'


# In[3]:

dfbase = pd.read_excel(link)
print len(dfbase)

#debug done confirm
# In[4]:

dfdroplist = ['Latest Status','Latest Status Date','Latest Status Reason','Latest Status Branch','Latest Status Category','Account Name']
dfkeeplist = [i for i in dfbase.columns.tolist() if i not in dfdroplist]
dfbase = dfbase[dfkeeplist]
#dfbase.to_csv(csvfilename)
dfbase.to_csv(r'D:\Python\Scripts and Files\Path and Graph Files\dfbase.csv')
#print len(dfbase)

#dfbase.to_csv(r'D:\Data\Routing_logic_sector_buildup\debug.csv')
# In[5]:

#csvfilename = 'debug_ip.csv'
#invsf = gl.SFrame.read_csv(csvfilename)
invsf = gl.SFrame.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\dfbase.csv')
#print len(invsf)
#Tagged#statuscodes = gl.load_sframe('StatusCodes.csv')
loclist = ['Destn Branch','Hub SC Location','Origin Branch']
maplist = dict({'MAAG': 'MAAC','NEIR': 'GAUB','RJPR': 'PTLF','SIKM': 'SILB','KLMF':'COKB','AMDE':'AMDO'})
def convloc(location):
    get_dict = maplist.get(location)
    if get_dict is None:
        return location
    else:
        return get_dict
    
for locnames in loclist:
    invsf[locnames] = invsf.apply(lambda x: convloc(x[locnames]))
print len(invsf)


# In[6]:

print len(invsf)
invsf = invsf[invsf['Destn Depot']!='UCGD']
print len(invsf)
invsf = invsf[invsf['Hub SC Location']!=invsf['Destn Branch']]
print len(invsf)


# In[7]:

#paperwork-deps-exclusion
depspaperworkcodelist = ['SRE','SRD','SRS','SRP','DLP','SWP','PWS','HCM','HPM','MOP','SRH','HOC','ONR','SPH','SPO','DBO','DIP','SHS','SSC','HIP','RNX']
invsf = invsf.filter_by(depspaperworkcodelist, 'Latest Status Code', exclude=True)
#paperwork-deps-exclusion


# In[8]:

pathsf = gl.SFrame.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\final_pathv3.csv')
lhscheduledf = gl.SFrame.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\Timegraph.csv')


# In[9]:

lhscheduledf_dict = {}
for org, dest, deptime, transithrs,vbtype in izip(lhscheduledf['Origin'], lhscheduledf['Destination'],
                                     lhscheduledf['Departure Time'], lhscheduledf['Total leg TT'], lhscheduledf['Type']):
    lhscheduledf_dict[(org, dest)] = [deptime, transithrs,vbtype]


# In[10]:

#debug no file generated


# In[11]:

path_dict = {}
for org, dest, paths in izip(pathsf['Origin'], pathsf['Destination'],pathsf['pathlist']):
    path_dict[(org, dest)] = paths


# In[12]:

path_dict.get(('BGPF', 'MNSB'))


# In[13]:

def getconpath(origin,location,destination):
    #print origin, location, destination
    try:
        conpathall1 = path_dict.get((origin,destination))
        if conpathall1 is None:
            conpathall = None
        else:
            conpathall = [i for i in conpathall1 if location in i]
        auxpathall = path_dict.get((location,destination))
        if conpathall is None:
            conpathall = []
        if auxpathall is None:
            auxpathall = []
        if (len(conpathall)==0) and (len(auxpathall)==0):
            return ['error']
        elif (len(conpathall)==0):
            lenlist = [len(i) for i in auxpathall]
            return auxpathall[lenlist.index(min(lenlist))]
        else:
            lenlist = [len(i) for i in conpathall]
            minconpath = conpathall[lenlist.index(min(lenlist))]
            #print minconpath[minconpath.index(location):]
            return minconpath[minconpath.index(location):]
    except:
        ['checkerror']


# In[14]:

getconpath('BGPF','DELH','MNSB')


# In[15]:

def getdeparturetime(org, dest, currtime):
    try:
        currtimedt = str(currtime).split(' ')[0]+' 00:00:00'
        currtimedt = datetime.strptime(currtimedt,'%Y-%m-%d %H:%M:%S')
        
        deptime_total = lhscheduledf_dict.get((org, dest))
        if deptime_total is None:
            return dayzero, dayzero
        deptime, transithrs, vbtype = deptime_total
        
        if vbtype == 'Normal':
            deptime1 = timedelta(hours=deptime)+(currtimedt)
            deptime2 = timedelta(hours=(deptime+24.0))+(currtimedt)
            arrtime1 = deptime1 + timedelta(hours=transithrs)
            arrtime2 = deptime2 + timedelta(hours=transithrs)
            if deptime1<=currtime:
                return deptime2,arrtime2
            else:
                return deptime1,arrtime1
            
        elif vbtype == 'VB':
            deptime = timedelta(hours=3.0)+(currtime)
            return deptime,deptime
    except:
        return dayzero,dayzero


# In[16]:

def getidealtimes(con,conpath,pickuptime,arratcurrloc):
    ### pickuptime is current time
    try:
        idealtimelist = []
        hrsatcurrloc = (pickuptime-arratcurrloc).total_seconds()*1.0/3600
        if hrsatcurrloc<=conprocessing:
            adjtimeatloc = conprocessing-hrsatcurrloc
        else:
            adjtimeatloc = 0
        currtime = pickuptime+timedelta(hours=adjtimeatloc)
        idealtimelist.append(pickuptime)
        for i in range (1,len(conpath)):
            org = conpath[i-1]
            dest = conpath[i]
            departuretime,arrivaltime = getdeparturetime(org,dest,currtime)
            if (departuretime==dayzero)or(arrivaltime==dayzero):
                idealtimelist=[dayzero]
                break    
            else:
                if (dest == conpath[-1]) and (departuretime.weekday()==arrivaltime.weekday()==6) and (arrivaltime.hour<=12):
                    departuretime = departuretime+timedelta(hours=24)
                    arrivaltime = arrivaltime+timedelta(hours=24)
                idealtimelist.append(departuretime)
                idealtimelist.append(arrivaltime)
                currtime = arrivaltime

        return idealtimelist
    except:
        return [dayzero]


# In[17]:

def geteta(x):
    try:
        return x[-1]
    except:
        return dayminu


# In[18]:

invsf['conpath'] = invsf.apply(lambda x: getconpath(x['Origin Branch'],x['Hub SC Location'],x['Destn Branch']))


# In[19]:

invsf['Origin Branch'] = invsf.apply(lambda x: x['Origin Branch'].upper())
invsf['Destn Branch'] = invsf.apply(lambda x: x['Destn Branch'].upper())
invsf['Hub SC Location'] = invsf.apply(lambda x: x['Hub SC Location'].upper())
invsf['arratcurrloc'] = invsf.apply(lambda x: datetime.strptime(x['Arrival Date Hub'].split('.')[0],timeformatstring2))
invsf['currtime'] = invsf.apply(lambda x: datetime.strptime(x['TIMESTAMP'].split('.')[0],timeformatstring2))
invsf['Duedt'] = invsf.apply(lambda x: datetime.strptime(x['Due Date'].split('.')[0],timeformatstring2))
 
invsf['idealtimelist'] = invsf.apply(lambda x: getidealtimes(x['Con Number'],x['conpath'],x['currtime'],x['arratcurrloc']))
#print len(invsf)
errortimelist =  invsf[invsf['idealtimelist']==[dayzero]]
#errortimelist.save('errortimelist.csv')
invsf = invsf[invsf['idealtimelist']!=[dayzero]]
print len(invsf)
invsf['eta'] = invsf.apply(lambda x: geteta(x['idealtimelist']))
#invsf.save('debug.csv')
invsf = invsf[invsf['eta']!=dayminu]
print len(invsf)
errordate = invsf[(invsf['eta']==dayzero)]


# In[20]:

check1 = (invsf[invsf['conpath']==['error']])
print len(check1)
#print 'error: '+str((check1['Act Wt In Tonnes'].sum()))+ ' : '+str(len(check1))
invsfinal = invsf[(invsf['eta']!=dayminu)]
#print 'correct: '+ str((invsfinal['Act Wt In Tonnes'].sum()))+ ' : '+str(len(invsfinal))


# In[21]:

#invsf1 = invsf[(invsf['eta']==dayzero) | (invsf['eta']==dayminu)]
invsf1 = invsf[(invsf['conpath']==['error'])]
#print len(invsf1)
grperror = invsf1.groupby(['Origin Branch','Destn Branch','Hub SC Location','conpath'],{'wt': agg.SUM('Act Wt In Tonnes')})
grperror.sort_values('wt', ascending=False)


# In[22]:

def getreach(eta,duedt):
    duedtadj = duedt+timedelta(hours=14)
    if eta>duedtadj:
        return 0
    else:
        return 1


# In[23]:

invsf['reached'] = invsf.apply(lambda x: getreach(x['eta'],x['Duedt']))
#print pd.np.ceil(invsf[invsf['reached']==1]['reached'].sum()*100.0/len(invsf['reached'])), len(invsf)


# In[24]:

def getdelayhrs(duedt,eta,pred):
    if pred==0:
        return -1.0*pd.np.ceil(((duedt+timedelta(hours=14))-eta).total_seconds()*1.0/3600)
    else:
        return 0
invsf['delayhours'] = invsf.apply(lambda x:getdelayhrs(x['Duedt'],x['eta'],x['reached']))


# In[25]:

def getnextloc(conpath,currloc):
    try:
        ix = conpath.index(currloc)
        return conpath[ix+1]
            
    except:
        return 'error'

quant = 0.4  
invsf['Nextloc'] = invsf.apply(lambda x: getnextloc(x['conpath'],x['Hub SC Location']))   
invsf.save(r'D:\Data\Routing_logic_sector_buildup\invsf.csv') 
grpcon = invsf.groupby(['Hub SC Location','Nextloc'],{'wt': agg.SUM('Act Wt In Tonnes'),'reached':agg.SUM('reached'),'concount':agg.COUNT_DISTINCT('Con Number'),'delayhrs': agg.QUANTILE('delayhours',quant)})
grpcon['delayhrs'] = grpcon.apply(lambda x: x['delayhrs'][0])

grpcon['wt'] = pd.np.ceil(grpcon['wt'])
grpcon['reachedperc'] = pd.np.ceil(grpcon['reached']*100.0/grpcon['concount'])
#grpcon.save('grpcons.csv')
grpcon.sort_values('wt', ascending=False)
grpcritical = grpcon[grpcon['wt']>=11].sort_values('wt', ascending=False)
grpcritical


# In[26]:

columnlist = ['Hub SC Location', 'Nextloc', 'wt','concount', 'reached', 'reachedperc']
grpcritical_final = grpcritical[columnlist]
grpcritical_final = grpcritical_final.rename({'Hub SC Location':'CurrLoc','Nextloc':'NextLoc','concount':'con', 'reached':'Reach','reachedperc':'Reach%'})

grpcritical_finaldf = grpcritical_final.to_dataframe()
grpcritical_finaldf.to_csv(r'D:\Python\Scripts and Files\Path and Graph Files\Sector_buildup.csv')
##grpcritical_final.save(r'D:\Python\Scripts and Files\Path and Graph Files\Sector_buildup.csv')
#invsf.save('data.csv')


## For saving explicitly
ts= datetime.now()
opfilevar=ts.date()
opfilevar1=ts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=pd.np.round(float(currhrs)/60)

#print 'opfilevar,opfilevar2',opfilevar,opfilevar2

grpcritical_finaldf.save(r'D:\Data\Routing_logic_sector_buildup\Sector_buildup_'+str(opfilevar)+str('_')+str(opfilevar2)+'.csv')
## For saving explicitly

# In[ ]:
oppath = r'D:\Python\Scripts and Files\Path and Graph Files\Sector_buildup.csv'
# In[ ]:
filePath = oppath
def sendEmail(TO = ["pawan.sharma@spoton.co.in"],
            #TO = ["rajeesh.vr@spoton.co.in"],
            #TO = ["vishwas.j@spoton.co.in"],
            #CC = ["vishwas.j@spoton.co.in"],
            CC = ["sqtf@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "Sector Load Buildup " + '- ' + str(opfilevar)+str('-')+ str(opfilevar2)
    body_text = """
    Dear All,
    
    PFA the Sector Load Buildup for """+str(opfilevar)+str('-')+str(opfilevar2)+ """
    
"""+str(grpcritical_finaldf)+"""
    
    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends


