
# coding: utf-8

# In[1]:

import pandas as pd
import numpy as np
import datetime
from datetime import datetime,timedelta
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os


# In[16]:
#try:
date=datetime.now().date()-timedelta(7)


# In[17]:

date


# In[18]:

data=[]
for i in range(0,6):
    path=r'D:\Data\Hub Performance'
    dt=date+timedelta(i)
    path+='\Hub_Perfor_Data_'+str(dt)+'-11.0.csv'
    print (path)
    try:
        df=pd.read_csv(path)
    except:
        print ("File Not Found",path)
    print (len(df))
    data.append(df)
    frame=pd.concat(data)


# In[19]:

len(frame)


# In[6]:

frame.to_csv(r'D:\Data\Hub Performance\Consolidated Data\HUB_PERF_CONSOLIDATED_DATA_'+str(date)+'.csv')
frame.to_csv(r'D:\Data\Hub Performance\Consolidated Data\HUB_PERF_CONSOLIDATED_DATA.csv')


# In[7]:

summary_data=[]
for i in range(0,6):
    path=r'D:\Data\Hub Performance'
    dt=date+timedelta(i)
    path+='\Summary_Without_Deps'+str(dt)+'-11.0.csv'
    print (path)
    try:
        df=pd.read_csv(path)
    except:
        print ("File Not Found",path)
    print (len(df))
    summary_data.append(df)
    frame1=pd.concat(summary_data)


# In[8]:

frame1.to_csv(r'D:\Data\Hub Performance\Without Deps\Without-Deps_Summary'+str(date)+'.csv')
frame1.to_csv(r'D:\Data\Hub Performance\Without Deps\Without-Deps_Summary.csv')


# In[9]:

filepath=r'D:\Data\Hub Performance\Consolidated Data\HUB_PERF_CONSOLIDATED_DATA.csv'
filepath1=r'D:\Data\Hub Performance\Without Deps\Without-Deps_Summary.csv'


# In[10]:

import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback
for i in [filepath,filepath1]:
    oppath1=i
    #FTP Upload starts
    print ('Logging in...')
    ftp = ftplib.FTP()  
    ftp.connect('10.109.230.50')  
    print (ftp.getwelcome())
    try:  
        try:  
            ftp.login('HOSQTeam', 'Te@mH0$q')
            print ('login done')
            ftp.cwd('Auto_reports')  
            #ftp.cwd('FIFO')
            # move to the desired upload directory  
            print ("Currently in:", ftp.pwd()) 
            print ('Uploading...')  
            fullname = oppath1
            name = os.path.split(fullname)[1]  
            f = open(fullname, "rb")  
            ftp.storbinary('STOR ' + name, f)  
            f.close()  
            print ("OK"  )
            print ("Files:")  
            print (ftp.retrlines('LIST'))
        finally:  
            print ("Quitting...")
            ftp.quit()  
    except:  
        traceback.print_exc()


# In[11]:


from_addr = 'mis.ho@spoton.co.in'
#to_addr = ['mahesh.reddy@spoton.co.in']
to_addr = ['sharanagouda.biradar@spoton.co.in',"anitha.thyagarajan@spoton.co.in","sanjana.narayana@spoton.co.in"]
cc_addr = ['sharanagouda.biradar@spoton.co.in',"anitha.thyagarajan@spoton.co.in",'mahesh.reddy@spoton.co.in',"sanjana.narayana@spoton.co.in"]
bcc_addr = ['rajesh.mp@spoton.co.in']

username = 'mis.ho@spoton.co.in'
password = 'Spot@123'

msg = MIMEMultipart()

msg['From'] = from_addr
# msg['To'] = ', '.join(to_addr)
msg['cc'] = ', '.join(cc_addr)
msg['bcc'] = ', '.join(bcc_addr)
msg['Subject'] = 'Hub Performance Consolidated Report : '+str(date)
html='''<html>
<h4>Dear All,</h4>
<p>Pls find the attached Hub Performance Consolidated Report</p>
</html>'''
html3='''
<h5> Note : For data please open below link.</h5>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/HUB_PERF_CONSOLIDATED_DATA.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/HUB_PERF_CONSOLIDATED_DATA.csv</p></b>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Without-Deps_Summary.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Without-Deps_Summary.csv</p></b>
'''
html1='''<h5>Thanks & Regards</h5></b>
<h5>HO-SQ</h5>'''
    
#  msg.attach(part10)
report=""
report+='<br>'
# report+='<br>'
report+=html3
report+='<br>'
report+=html1
abc=MIMEText(report,'html')
msg.attach(abc)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
part=MIMEBase('application','octet-stream')
# part1=MIMEBase('application','octet-stream')
part.set_payload(open(filepath,'rb').read())
# part1.set_payload(open(filepath1,'rb').read())
encoders.encode_base64(part)
# Encoders.encode_base64(part1)
part.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath))
# part1.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath1))
#msg.attach(part)
# msg.attach(part1)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
server.sendmail(from_addr,cc_addr+bcc_addr,msg.as_string())
print ('mail sent succesfully')
server.quit()

# except:
#   TO=['sharanagouda.biradar@spoton.co.in',"anitha.thyagarajan@spoton.co.in",'vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
#   FROM="mahesh.reddy@spoton.co.in"
#   msg = MIMEMultipart()
#   msg["From"] = FROM
#   msg["To"] = ",".join(TO)
#   #msg["CC"] = ",".join(CC)
#   #msg["BCC"] = ",".join(BCC)
#   #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
#   msg["Subject"] = "ERROR Report" 
#   report=""
#   report+='Hi,'

#   report+='<br>'
#   report+='There was some error in Hub Peformance Consolidated Report'
#   report+='<br>'

#   abc=MIMEText(report.encode('utf-8'),'html')
#   msg.attach(abc)
#   server=smtplib.SMTP('smtp.sendgrid.net', 587)
#   server.ehlo()
#   server.starttls()
#   server.ehlo()
#   server.login("spoton.net.in", "Star@123#")
#   failed = server.sendmail(FROM, TO, msg.as_string())
#   server.quit()

# # In[ ]:



