
# coding: utf-8

# In[1]:

import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
import calendar
import datetime
from pandas import ExcelWriter
import pyodbc
import sys
import Utilities
reload(sys).setdefaultencoding("ISO-8859-1")
# In[7]:

datetimenow = datetime.datetime.now()

opfilevar=datetimenow.date()
opfilevar1=datetimenow.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=np.round((float(currhrs)/60),0)
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
#cursor = cnxn.cursor()

query = ("""
        EXEC USP_CLOSINGSTOCK_REPORT_1HR_IE
        """)
closingstock1hr = pd.read_sql(query, Utilities.cnxn) 
#print (closingstock1hr.columns)
#closingstock1hr.rename(columns={})
# In[3]:

#closingstock1hr = pd.io.excel.read_excel('http://10.109.230.50/downloads/OCID_CLOSINGSTOCK_1HR/OCID_CLOSINGSTOCK_1HR.xls','IEP_Closing_Stock_1HR')
closingstock1hr.rename(columns={ 'CS_TemaLeaderName':'CS Team Leader Name','CS_TemaLeader':'CS Team Leader','CS_AgentName':'CS Agent Name','Sector/Route':'Sector Route','CustomerCode':'Customer Code','DeliveryAdd3':'Delivery Add3','DeliveryAdd2':'Delivery Add2','DeliveryAdd1':'Delivery Add1','LASTDRS_PREPAREDDATE':'LASTDRS PREPAREDDATE','ApptmntDelDate': 'Apptmnt Del Date','IsApptmntDel': 'Is Apptmnt Del','IS_FREE_CON_NEW': 'IS FREE CON NEW','ConStatusDate': 'Con Status Date','ConStatusReason': 'Con Status Reason','ConStatusDesc': 'Con Status Desc','ConStatusCode': 'Con Status Code','ConStatusCategory': 'Con Status Category','DEST_PINCODE': 'DEST PINCODE','ORG_PINCODE': 'ORG PINCODE','ORG_DEPOT': 'ORG DEPOT','ORG_AREA':'ORG AREA','ORG_BRNM': 'ORG BRNM','ORG_BRCD': 'ORG BRCD','DEST_AREA': 'DEST AREA','DEST_REGION':'DEST REGION','DEST_BRNM':'DEST BRNM','DEL_LOCATION_TYPE':'DEL LOCATION TYPE','DRS_STATUS':'DRS CLOSING STATUS','Is_ADC':'Is ADC','CustomerName':'Customer Name','DEST_BRCD':'DEST BRCD','DRS_PREPARED':'DRS PREPARED','DEST_DEPOT':'DEST DEPOT',"TimestateDate":'Timestate Date',"ARRV_AT_DEST_SC":'ARRV AT DEST SC',"ConStatusCode":'Con Status Code',"CON_BLOCKED_FOR_ODA_PIN_ISSUES":'CON BLOCKED FOR ODA PIN ISSUES',"CON_BLOCKED_FOR_PAY_ISSUES":'CON BLOCKED FOR PAY ISSUES',"CON_BLOCKED_FOR_DEMURRAGE":'CON BLOCKED FOR DEMURRAGE'},inplace=True)


# In[12]:

closingstock1hr.to_csv(r'D:\Data\Closing_Stock_1HR\Closing_Stock_'+str(opfilevar)+'_'+str(opfilevar2)+'.csv')


# In[ ]:



