
# coding: utf-8

# In[1]:


import pandas as pd
from datetime import datetime, timedelta
import numpy as np
from sqlalchemy import *
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os

import pyodbc
# In[2]:



cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=PYTHON_DB;UID=PythonOnline;PWD=P@ssw0rd123$")

# In[3]:


startdate="'"+datetime.strftime(datetime.now()-timedelta(1),"%Y-%m-%d")+"'"
enddate="'"+datetime.strftime(datetime.now(),"%Y-%m-%d")+"'"


# In[4]:


print (startdate,enddate)


# In[ ]:


# startdate="'2018-07-23'"
# enddate="'2018-07-24'"


# In[5]:


thcdatapd = pd.read_sql("SELECT * FROM LH30days WHERE [THC DATE] >= '{0}' AND [THC DATE] <= '{1}'".format(eval(startdate)+" 09:00:00",eval(enddate)+" 09:00:00"),cnxn)    


# In[6]:


len(thcdatapd)


# In[7]:


market_df=thcdatapd[thcdatapd['ROUTE CODE']=='9888']


# In[8]:


len(market_df)


# In[9]:


target_df=pd.read_excel(r'D:\Data\Market_Vehicle_Target&Payment\Market Target.xlsx')


# In[10]:


market_df.rename(columns={'NEW PATH':'Route Path','VEHICLE PAYLOAD':'Vehicle Payload'},inplace=True)


# In[11]:


market_df=pd.merge(market_df,target_df,on=['Route Path','Vehicle Payload'],how='inner')


# In[12]:


market_df['Savings']=market_df['COST']-market_df['Target.1']


# In[13]:


market_df1=market_df[['THC NUMBER', 'THC DATE','Origin','Route Path','Vehicle Payload','TOTAL ACTUAL LOAD','VEHICLE NUMBER','COST','Target.1','Average Cost','Savings','VENDOR NAME','VENDOR CODE','Responsibility']]


# In[14]:


market_df1.rename(columns={'THC NUMBER':'THC NO','THC DATE':'THC Date','TOTAL ACTUAL LOAD':'Actual Load','VEHICLE NUMBER':'Vehicle No.','COST':'Cost','Target.1':'Target','VENDOR NAME':'Vendor Name','VENDOR CODE':'Vendor Code','Responsibility':'Indicator'},inplace=True)


# In[15]:


market_df1['Target']=pd.np.round(market_df1['Target'],0)
market_df1['Average Cost']=pd.np.round(market_df1['Average Cost'],0)
market_df1['Savings']=pd.np.round(market_df1['Savings'],0)


# In[16]:


market_df2=market_df1.sort_values('Origin',ascending=True)


# In[17]:


market_df2


# In[ ]:


reportts = datetime.now()
opfilevar=reportts.date()
opfilevar1=reportts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=pd.np.round((float(currhrs)/60),0)


# In[ ]:


market_df2.to_csv(r'D:\Data\Market_Vehicle_Target&Payment\Market_Vehicle_Target&Payment-HUB_Summary'+str(opfilevar)+'.csv')


# In[ ]:


market_df2.Indicator


# In[ ]:


FROM='reports.ie@spoton.co.in'

TO=['Prasanna.Hegde@Spoton.Co.In']
# TO=['HUBMGR_SPOT@spoton.co.in','sopanrao.bhoite@spoton.co.in','narendra.londhe@spoton.co.in','samarjeet.dubey@spoton.co.in','vijay.dubey@spoton.co.in']
CC=['mahesh.reddy@spoton.co.in']
# CC=['pawan.sharma@spoton.co.in','Prasanna.Hegde@Spoton.Co.In']
#BCC=['mahesh.reddy@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in']


msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)

msg["Subject"] = "Market Vehicle Target & Payment - HUB " + str(opfilevar)

report=""
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='Below are the lanes operated yesterday and the prices are not reduced as per the target.'
report+='<br>'
report+='<br>'
report+='<br>'+market_df2.to_html()+'<br>'

abc=MIMEText(report,'html')
msg.attach(abc)



server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login('reports.ie@spoton.co.in', 'Reports@2019')
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()

