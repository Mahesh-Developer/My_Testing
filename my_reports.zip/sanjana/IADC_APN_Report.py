
# coding: utf-8

# In[47]:


import pandas as pd
from datetime import datetime, timedelta,date
import numpy as np
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import Utilities
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

reload(sys).setdefaultencoding("ISO-8859-1")
tod=datetime.strftime(date.today(),'%Y-%m-%d')
# In[48]:

# cnxn1 = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor1 = cnxn1.cursor()


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()

try:
    pmdquery = ("""EXEC USP_IADC_CONSTATUS_DATA_MTD  """)
    print (pmdquery)
    df=pd.read_sql(pmdquery,Utilities.cnxn)
    # df=pd.read_csv(r'http://spoton.co.in/downloads/ADC/ADC_CON_DATA_MTD.csv')
    print ('ss')
    df.rename(columns={'Current Location':'Current_Location','CONStatusReason':'CONStatusReason1','Appointment Date':'Appointment_Date','Delivery Date':'Delivery_Date'},inplace=True)
    # In[49]:


    len(df)


    # In[50]:


    df.columns


    # In[51]:


    def getCombination(curloc,dest):
        if (curloc==dest):
            return True
        else:
            return False


    # In[52]:


    df['Reached_Dest']=df.apply(lambda x:getCombination(x['Current_Location'],x['Destination']),axis=1)


    # In[53]:


    def dateConvert(date):
        # d=date.split('/')
        # date1=d[2].split(' ')[0]+'-'+d[0]+'-'+d[1]
        return date


    # In[54]:


    #filtering cons at already dest
    destn_df=df[df['Reached_Dest']==True]
    len(destn_df)


    # In[55]:


    destn_df['ConStatusDate']=destn_df.apply(lambda x: dateConvert(x['CONStatusDate']),axis=1)
    #destn_df['ConStatusDate']=pd.to_datetime(destn_df['ConStatusDate'],format='%Y-%m-%d')
    destn_df['ConStatusDate']=destn_df['ConStatusDate'].apply(lambda x: datetime.strptime(x,"%Y-%m-%d").date())

    # In[56]:


    def getTest(aptdate):
        if pd.isnull(aptdate):
            return aptdate
        elif aptdate>=tod:
            return aptdate
        else:
            return 'Check'


    # In[57]:


    destn_df['Test']=destn_df.apply(lambda x: getTest(x['Appointment_Date']),axis=1)


    # In[58]:


    destn_df1=destn_df[destn_df['Test']!='Check']
    destn_apt_crossed_df=destn_df[destn_df['Test']=='Check']
    len(destn_apt_crossed_df)


    # In[59]:


    len(destn_df1)


    # In[60]:


    destn_df1['Appointment_Status']=destn_df1['Appointment_Date'].apply(lambda x: "No Appointment" if (x=='NA') else "Appointment")


    # In[61]:


    #appointment date already crossed con at dest
    appnt_dest_df=destn_df1[destn_df1['Appointment_Date']>(datetime.strftime(date.today(),'%Y-%m-%d'))]
    len(appnt_dest_df)


    # In[62]:


    appnt_crossed_dest_df=destn_df1[destn_df1['Appointment_Date']<(datetime.strftime(date.today(),'%Y-%m-%d'))]
    len(appnt_crossed_dest_df)


    # In[63]:


    pivot_app_dest=pd.pivot_table(destn_df1,index=['ConStatusDate'],columns=['Appointment_Status'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total')


    # In[64]:


    pivot_app_dest1=pivot_app_dest.fillna(0)


    # In[65]:



    try:
        pivot_app_dest1[("DOCKNO","Appointment")]=pivot_app_dest1[("DOCKNO","Appointment")].astype(int)
        pivot_app_dest1[("DOCKNO","No Appointment")]=pivot_app_dest1[("DOCKNO","No Appointment")].astype(int)
        pivot_app_dest1[("DOCKNO","Total")]=pivot_app_dest1[("DOCKNO","Total")].astype(int)
    except:
        pass


    # In[66]:


    pivot_app_dest_cs_name=pd.pivot_table(destn_df1,index=['CS_TeamLeaderName'],columns=['Appointment_Status'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total')


    # In[67]:


    #after reached destination

    try:
        pivot_app_dest_cs_name[("DOCKNO","Appointment")]=pivot_app_dest_cs_name[("DOCKNO","Appointment")].astype(int)
        pivot_app_dest_cs_name[("DOCKNO","No Appointment")]=pivot_app_dest_cs_name[("DOCKNO","No Appointment")].astype(int)
        pivot_app_dest_cs_name[("DOCKNO","Total")]=pivot_app_dest_cs_name[("DOCKNO","Total")].astype(int)
    except:
        pass


    # In[68]:


    #filtering cons at intransit
    currloc_df=df[df['Reached_Dest']==False]
    len(currloc_df)


    # In[69]:


    currloc_df['ConStatusDate']=currloc_df.apply(lambda x: dateConvert(x['CONStatusDate']),axis=1)
    #currloc_df['ConStatusDate']=pd.to_datetime(currloc_df['ConStatusDate'],format='%Y-%m-%d')
    currloc_df['ConStatusDate']=currloc_df['ConStatusDate'].apply(lambda x: datetime.strptime(x,"%Y-%m-%d").date())
    # In[70]:


    currloc_df['Test']=currloc_df.apply(lambda x: getTest(x['Appointment_Date']),axis=1)


    # In[71]:


    currloc_df1=currloc_df[currloc_df['Test']!='Check']
    currloc_apt_crossed_df=currloc_df[currloc_df['Test']=='Check']
    len(currloc_apt_crossed_df)


    # In[72]:


    len(currloc_df1)


    # In[73]:


    currloc_df1['Appointment_Status']=currloc_df1['Appointment_Date'].apply(lambda x: "No Appointment" if (x=='NA') else "Appointment")


    # In[74]:


    #appointment date already crossed con at intransit
    appnt_curloc_df=currloc_df1[currloc_df1['Appointment_Date']>(datetime.strftime(date.today(),'%Y-%m-%d'))]
    appnt_crossed_curloc_df=currloc_df1[currloc_df1['Appointment_Date']<(datetime.strftime(date.today(),'%Y-%m-%d'))]
    len(appnt_crossed_curloc_df)


    # In[75]:


    len(appnt_curloc_df)


    # In[76]:


    pivot_app_curloc=pd.pivot_table(currloc_df1,index=['ConStatusDate'],columns=['Appointment_Status'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total')


    # In[77]:


    pivot_app_curloc1=pivot_app_curloc.fillna(0)


    # In[78]:


    pivot_app_curloc1


    # In[79]:


    try:
        pivot_app_curloc1[("DOCKNO","Appointment")]=pivot_app_curloc1[("DOCKNO","Appointment")].astype(int)
        pivot_app_curloc1[("DOCKNO","No Appointment")]=pivot_app_curloc1[("DOCKNO","No Appointment")].astype(int)
        pivot_app_curloc1[("DOCKNO","Total")]=pivot_app_curloc1[("DOCKNO","Total")].astype(int)
    except:
        pass


    # In[80]:


    pivot_app_curloc1


    # In[81]:


    pivot_app_curloc_cs_name=pd.pivot_table(currloc_df1,index=['CS_TeamLeaderName'],columns=['Appointment_Status'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total')


    # In[82]:


    pivot_app_curloc_cs_name=pivot_app_curloc_cs_name.fillna(0)


    # In[83]:


    try:
        pivot_app_curloc_cs_name[("DOCKNO","Appointment")]=pivot_app_curloc_cs_name[("DOCKNO","Appointment")].astype(int)
        pivot_app_curloc_cs_name[("DOCKNO","No Appointment")]=pivot_app_curloc_cs_name[("DOCKNO","No Appointment")].astype(int)
        pivot_app_curloc_cs_name[("DOCKNO","Total")]=pivot_app_curloc_cs_name[("DOCKNO","Total")].astype(int)
    except:
        pass


    # In[84]:


    pivot_app_curloc_cs_name


    # In[85]:


    yes=datetime.strftime(date.today()-timedelta(1),'%Y-%m-%d')


    # In[86]:


    yes
    #exit(0)

    # In[87]:


    from pandas import ExcelWriter
    with ExcelWriter(r'D:\Data\IADC Reports\ADC_Destination_Summary'+str(yes)+'.xlsx') as writer:
        destn_df.to_excel(writer,engine='xlsxwriter',sheet_name='Data')
        pivot_app_dest1.to_excel(writer,engine='xlsxwriter',sheet_name='Summary')
        pivot_app_dest_cs_name.to_excel(writer,engine='xlsxwriter',sheet_name='TeamLeader Summary')
        destn_apt_crossed_df.to_excel(writer,engine='xlsxwriter',sheet_name='APT Crossed Cons')
        


    # In[88]:


    filePath1=r'D:\Data\IADC Reports\ADC_Destination_Summary'+str(yes)+'.xlsx'


    # In[89]:


    with ExcelWriter(r'D:\Data\IADC Reports\ADC_Intransit_Summary'+str(yes)+'.xlsx') as writer:
        currloc_df.to_excel(writer,engine='xlsxwriter',sheet_name='Data')
        pivot_app_curloc1.to_excel(writer,engine='xlsxwriter',sheet_name='Summary')
        pivot_app_curloc_cs_name.to_excel(writer,engine='xlsxwriter',sheet_name='TeamLeader Summary')
        currloc_apt_crossed_df.to_excel(writer,engine='xlsxwriter',sheet_name='APT Crossed Cons')


    # In[90]:


    filePath2=r'D:\Data\IADC Reports\ADC_Intransit_Summary'+str(yes)+'.xlsx'


    # In[91]:



    #'shivananda.p@spoton.co.in',
    TO=['spot_cstl@spoton.co.in']
    #TO=['mahesh.reddy@spoton.co.in']
    CC=['abhik.mitra@spoton.co.in','shivananda.p@spoton.co.in','rajesh.kumar@spoton.co.in','jothi.menon@spoton.co.in','sharmistha.majumdar@spoton.co.in','satya.pal@spoton.co.in','mahesh.reddy@spoton.co.in']
    FROM='reports.ie@spoton.co.in'
    #TO=['vishwas.j@spoton.co.in']
    #CC=['mahesh.reddy@spoton.co.in']
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "IADC Summary Cons at Destination" + " - " + str(yes)
    html='''<html>
    <h4>Dear All,</h4>
    <h3>IADC Summary for Cons at Destination - TeamLeader Wise</h3>
    </html>'''
    html3='''
    <h3>IADC Summary for Cons at Destination - Date Wise </h3>

    '''
    s = Template(html).safe_substitute(date=yes)
    report=""
    report+=s
    report+='<br>'+pivot_app_dest_cs_name.to_html()+'<br>'
    report+='<br>'
    report+=html3
    report+='<br>'+pivot_app_dest1.to_html()+'<br>'
    abc=MIMEText(report,'html')
    msg.attach(abc)
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath1,"rb").read() )
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath1))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO+CC, msg.as_string())
    server.quit()


    # In[92]:




    TO=['spot_cstl@spoton.co.in']
    CC=['abhik.mitra@spoton.co.in','shivananda.p@spoton.co.in','rajesh.kumar@spoton.co.in','jothi.menon@spoton.co.in','sharmistha.majumdar@spoton.co.in','satya.pal@spoton.co.in','vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
    # TO=['mahesh.reddy@spoton.co.in']
    # CC=['mahesh.reddy@spoton.co.in']
    FROM='reports.ie@spoton.co.in'
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "IADC Summary Cons in Intransit" + " - " + str(yes)
    html='''<html>
    <h4>Dear All,</h4>
    <h3>IADC Summary for Cons in Intransit - TeamLeader Wise</h3>
    </html>'''
    html4='''
    <h3>IADC Summary for Cons in Intransit - Date Wise</h3>

    '''
    s = Template(html).safe_substitute(date=yes)
    report=""
    report+=s
    report+='<br>'+pivot_app_curloc_cs_name.to_html()+'<br>'
    report+='<br>'
    report+=html4
    report+='<br>'+pivot_app_curloc1.to_html()+'<br>'
    abc=MIMEText(report,'html')
    msg.attach(abc)
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath2,"rb").read() )
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath2))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO+CC, msg.as_string())
    server.quit()

except:
  TO=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  #msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "ERROR Report" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in IADC Summary Cons in Intransit and Destination'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO, msg.as_string())
  server.quit()

