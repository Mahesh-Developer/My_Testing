
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
from IPython import display
from datetime import datetime
from datetime import datetime,timedelta
from datetime import datetime, timedelta
import smtplib
import ftplib
import traceback
import calendar
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template
import pyodbc
import Utilities

# In[2]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")


# In[3]:


query=("USP_PUD_YEST_MTD_DATA 'M'")


# In[4]:


df=pd.read_sql(query,Utilities.cnxn)


# In[5]:


len(df)


# In[6]:


df['Type']='MTD'


# In[7]:


air_df=df[df['PTYPE']=='AR']
len(air_df)


# In[8]:


mtd_pud_cost=pd.np.round(air_df['COST'].sum(),1)
mtd_pud_cost


# In[9]:


m = {'Jan': '01','Feb': '02','Mar': '03','Apr':'04','May':'05','Jun':'06','Jul':'07','Aug':'08','Sep':'09','Oct':'10','Nov':'11','Dec':'12'}
def dateconv(date):
    dt = date.split(' ')[2]+'-'+str(m.get(date.split(' ')[1]))+'-'+date.split(' ')[0]
    #print (dt)
    return dt
air_df["DateOnly"]=air_df.apply(lambda x: dateconv(x["DATE"]),axis=1)


# In[10]:


yesterday=datetime.strftime(datetime.now()-timedelta(1),'%Y-%m-%d')
yesterday


# In[11]:


yest_df=air_df[air_df['DateOnly']==yesterday]
len(yest_df)


# In[12]:


yest_pud_cost=pd.np.round(yest_df['COST'].sum(),1)
yest_pud_cost


# In[13]:


del yest_df['Type']


# In[14]:


yest_df['Type']='YST'


# In[15]:


air_df=pd.concat([air_df,yest_df],ignore_index=True)


# In[16]:


air_df.rename(columns={'ACT_WT':'Wt','COST':'Cost','con_id':'Cons'},inplace=True)


# In[17]:


summary=air_df.pivot_table(index=['TYP'],columns=['Type'],values=['Wt','Cons','Cost'],aggfunc={'Wt':sum,'Cons':len,'Cost':sum},margins=True).fillna(0)


# In[18]:


del summary['Cons','All']
del summary['Cost','All']
del summary['Wt','All']


# In[19]:


summary


# In[20]:


summary[('CPK','MTD')]=summary[('Cost','MTD')]/summary[('Wt','MTD')]


# In[21]:


try:
    summary[('CPK','YST')]=summary[('Cost','YST')]/summary[('Wt','YST')]
except:
    summary[('CPK','YST')]=0

# In[22]:


summary=summary.fillna(0)


# In[23]:


summary['CPK']=pd.np.round(summary['CPK'],1)


# In[24]:


# summary
summary=summary.swaplevel(0, 1, 1).sort_index(1)


# In[27]:


try:
    summary=summary[[('YST','Cons'),('YST','Wt'),('YST','Cost'),('YST','CPK'),('MTD','Cons'),('MTD','Wt'),('MTD','Cost'),('MTD','CPK')]]
except:
    summary=summary[[('MTD','Cons'),('MTD','Wt'),('MTD','Cost'),('MTD','CPK')]]

# In[28]:


summary


# In[29]:


query1=("exec USP_PMD_LINEHAUL_DATA_30DAYS")


# In[30]:


linehal_df=pd.read_sql(query1,Utilities.cnxn)


# In[31]:


len(linehal_df)


# In[32]:


air_linehal_df=linehal_df[linehal_df['THCTYPE']=='AR']
len(air_linehal_df)


# In[33]:


mtd_feeder_cost=pd.np.round(air_linehal_df['COST'].sum(),1)
mtd_feeder_cost


# In[34]:


air_linehal_df['Type']='MTD'


# In[35]:


air_linehal_df['DATE']=air_linehal_df['THC DATE'].dt.date


# In[36]:


air_linehal_df['DATE']=air_linehal_df['DATE'].astype(str)


# In[37]:


yestair_linehal_df=air_linehal_df[air_linehal_df['DATE']==yesterday]
len(yestair_linehal_df)


# In[38]:


yest_feeder_cost=pd.np.round(yestair_linehal_df['COST'].sum(),1)
yest_feeder_cost


# In[ ]:


# if len(yestair_linehal_df)==0:
#     yestair_linehal_df=pd.DataFrame({})


# In[39]:


del yestair_linehal_df['Type']


# In[40]:


yestair_linehal_df['Type']='YST'


# In[41]:


air_linehal_df=pd.concat([air_linehal_df,yestair_linehal_df],ignore_index=True)


# In[42]:


air_linehal_df.rename(columns={'THC NUMBER':"THCs",'COST':'Cost','TOTAL ACTUAL LOAD':'Actual_Wt'},inplace=True)


# In[43]:


lh_summary=air_linehal_df.pivot_table(index=['Type'],aggfunc={"THCs":len,'Cost':sum,'Actual_Wt':sum})


# In[44]:


lh_summary['CPK']=pd.np.round(lh_summary['Cost']/lh_summary['Actual_Wt'],1)


# In[46]:


lh_summary=lh_summary[['THCs','Actual_Wt','Cost','CPK']]


# In[47]:


air_df.to_csv(r'D:\Data\Demostic Air Cost Report\AirPMD.csv')
air_linehal_df.to_csv(r'D:\Data\Demostic Air Cost Report\LHAir.csv')


# In[48]:


filepath=r'D:\Data\Demostic Air Cost Report\AirPMD.csv'
filepath1=r'D:\Data\Demostic Air Cost Report\LHAir.csv'


# In[49]:


todate=datetime.strftime(datetime.now(),"%Y-%m-%d")
todate

query3=("""SELECT  BA.bacd ,

        BA.banm ,

        CONVERT(VARCHAR(10), TC.CDDate, 103) CDDate ,

        TC.FlightNo ,

        TC.AirMode ,

        TC.TotalWeight ,

        TC.TotalWeightSlabMovement ,

        TC.AwbCharges ,

        TC.DOFees ,

        TC.TotalMiscCharges ,

        TC.TotalInboundCharges ,

        TC.TotalOutboundCharges ,

        TC.AdditionalCharges ,

        TC.TotChrgSlabwise ,

        TC.TotChrgMovementSlabwise ,

        TC.TotalBasedOnHeavyCharges ,

        TC.TotalBasedOnDGCharges ,

        TC.TotalBasedOnOthersCharges ,

        TC.TotalBasedOnDiscountCharges ,

        TC.TotalBasedOnPerKGCharges ,

        TC.GrandTotal

FROM    dbo.tblColoaderRateCalculationDetails TC WITH ( NOLOCK )

        INNER JOIN dbo.BAMS BA WITH ( NOLOCK ) ON BA.bacd = TC.ColoaderId""")

try:
    coloader_df=pd.read_sql(query3,cnxn)
    len(coloader_df)

except:
    coloader_df=pd.DataFrame()
# In[50]:
coloader_df.to_csv(r'D:\Data\Demostic Air Cost Report\coloader_df.csv')
filepath2=r'D:\Data\Demostic Air Cost Report\coloader_df.csv'

startdate="'"+datetime.strftime((datetime.now()-timedelta(days=1)).replace(day=1),"%Y-%m-%d")+"'"
enddate="'"+datetime.strftime(datetime.now(),"%Y-%m-%d")+"'"
cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=PYTHON_DB;UID=PythonOnline;PWD=P@ssw0rd123$")

df = pd.read_sql("SELECT * FROM revenuebkg WHERE PICKUP_DATE >= {0} AND PICKUP_DATE < {1}".format(startdate,enddate),cnxn) 
df.columns


# In[51]:


len(df)


# In[52]:


df=df[df['Product Type']=='AR']
len(df)


# In[53]:


yeststart = datetime.combine((datetime.now()-timedelta(days=1)).date(), datetime.min.time())
mtdrevenue = round(df["NetRev"].sum(),1)
yestrevenue=round(df[df["PICKUP_DATE"]>=yeststart]["NetRev"].sum(),1)


# In[54]:


mtdrevenue,yestrevenue


# In[55]:


percent_df=pd.DataFrame({'Cost':[mtd_pud_cost+mtd_feeder_cost,yest_pud_cost+yest_feeder_cost],'Revenue':[mtdrevenue,yestrevenue]},index=['MTD','YST'])


# In[56]:


percent_df['Perc%']=pd.np.round(percent_df['Cost']*100.0/percent_df['Revenue'],1)


# In[57]:


percent_df


# In[ ]:


TO=["vishwas.j@spoton.co.in"]
CC= ["mahesh.reddy@spoton.co.in"]
# CC=["mahesh.reddy@spoton.co.in"]
FROM="reports.ie@spoton.co.in"

msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "Domestic - Air Cost Reporting" + " - " + str(todate)
html='''<html>
<h4>Dear All,</h4>
<p>PFA the Domestic Air Cost Report for $date</p>
</html>'''
#s = Template(html).safe_substitute(date=yest_date)
report=""
report+="Dear All"
report+='<br>'
report+='PFA the Domestic Air Cost Report '
report+='<br>'
report+='PFB PMD Summary'
report+='<br>'+summary.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='PFB  Feeder summary'
report+='<br>'+lh_summary.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='PFB  Coloader summary'
report+='<br>'
report+='<br>'+coloader_df.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='Percentage summary'
report+='<br>'+percent_df.to_html()+'<br>'

abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(filepath1,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
msg.attach(part1)

part2 = MIMEBase('application', "octet-stream")
part2.set_payload( open(filepath2,"rb").read() )
encoders.encode_base64(part2)
part2.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath2))
msg.attach(part2)


# server=smtplib.SMTP('smtp.sendgrid.net', 587)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("spoton.net.in", "Star@123#")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()




# In[ ]:


exit(0)


# In[ ]:


ff=pd.read_csv(r'NO_sch_legs.csv')
len(ff)


# In[ ]:


ff1=ff.head(100)


# In[ ]:


import ast


# In[ ]:


ff['Check']=ff['Check'].apply(lambda x:ast.literal_eval(x))


# In[ ]:


len(ff[ff['Check']=={}])


# In[ ]:


dff1=pd.DataFrame()
from cytoolz.dicttoolz import merge
for i in ff['Check']:
    dff=pd.DataFrame(
        [merge(
            {'Query': k},
            {'Value{}':v}
         ) for k, v in i.items()]
    )
    dff1=pd.concat([dff1,dff],ignore_index=True)
dff1


# In[ ]:


dff1

