
# coding: utf-8

# In[1]:

# import ctypes, inspect, os, sframe
# from ctypes import wintypes
# kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
# kernel32.SetDllDirectoryW.argtypes = (wintypes.LPCWSTR,)
# src_dir = os.path.split(inspect.getfile(sframe))[0]
# kernel32.SetDllDirectoryW(src_dir)


# In[2]:

import pandas as pd
#import graphlab as gl
from datetime import datetime, timedelta
#import graphlab.aggregate as agg
import sframe as gl
import sframe.aggregate as agg
from pandas import ExcelWriter
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
import datetime
import os
import smtplib


# In[3]:

link = 'http://spoton.co.in/downloads/IEProjects/THCLOADUNLOAD/THCLOADUNLOAD.csv'


# In[4]:

def datetimeformatconvert(dep_load_unload_times):
    try:
        fulldate = datetime.strptime(dep_load_unload_times,'%d-%m-%Y %H:%M')
    except:
        fulldate = datetime.strptime(dep_load_unload_times,'%Y-%m-%d %H:%M:%S')
    return fulldate


# In[5]:

#thcload_unloadtime = gl.SFrame.read_csv(r'C:\Data\THC_load_unload\THC_LOAD_UNLOAD_COMBINED_PERFORMANCE_23Jul2016_New_sample_1.csv')
thcload_unloadtime = gl.SFrame.read_csv(link,quote_char='"')


# In[6]:

thcload_unloadtime.rename({'\xef\xbb\xbfHub_Location':'Hub_Location'})


# In[7]:

thcload_unloadtime = thcload_unloadtime.fillna('Vehicle_payload', 0)


# In[8]:



# In[9]:

thcload_unloadtime['DEP_ARRIVAL_DATE'] = thcload_unloadtime.apply(lambda x: datetimeformatconvert(x['Departure_Or_Arrival_Date']))
thcload_unloadtime['LOAD_UNLOAD_START'] = thcload_unloadtime.apply(lambda x: datetimeformatconvert(x['Load_unload_starttime']))
thcload_unloadtime['LOAD_UNLOAD_END'] = thcload_unloadtime.apply(lambda x: datetimeformatconvert(x['Load_unload_endtime']))

thcload_unloadtime['Starthr'] = thcload_unloadtime.apply(lambda x: x['LOAD_UNLOAD_START'].hour)
thcload_unloadtime['Endhr'] = thcload_unloadtime.apply(lambda x: x['LOAD_UNLOAD_END'].hour)


# In[10]:

##thcload_unloadtime.save('thcload_unloadtime.csv')


# In[11]:

print thcload_unloadtime['LOAD_UNLOAD_END'][0],type(thcload_unloadtime['LOAD_UNLOAD_END'][0])
print thcload_unloadtime['LOAD_UNLOAD_START'][0],type(thcload_unloadtime['LOAD_UNLOAD_START'][0])
print thcload_unloadtime['DEP_ARRIVAL_DATE'][0],type(thcload_unloadtime['DEP_ARRIVAL_DATE'][0])


# In[12]:

def turnarndtimecalc(loadunloadtype,deparrvltime,loadunloadstart,loadunloadend):
    if loadunloadtype == 'U':
        tat = (loadunloadend-deparrvltime)
        #tat = pd.np.round(tat,2)
    elif loadunloadtype == 'L':
        tat = (deparrvltime-loadunloadstart)
        #tat = pd.np.round(tat,2)
    else:
        tat = 'check'
    #return tat
    return round((tat.total_seconds()*1.0)/3600,2)

    


# In[13]:

##thcload_unloadtime['TAT'] = thcload_unloadtime.apply(lambda x: turnarndtimecalc(x['Load_unload'],x['DEP_ARRIVAL_DATE'],x['LOAD_UNLOAD_START'],x['LOAD_UNLOAD_END']))
thcload_unloadtime['Turn_around_time'] = thcload_unloadtime.apply(lambda x: abs(turnarndtimecalc(x['Load_or_unload'],x['DEP_ARRIVAL_DATE'],x['LOAD_UNLOAD_START'],x['LOAD_UNLOAD_END'])))


# In[14]:

def efficiencycal(tatperhr):
    idealtat = 3.0
    efficiency = round(((tatperhr*idealtat)/13500.0)*100,2)
    return efficiency

def efficiencycal_thc(tatperhr_thc):
    idealtat_thc = 3.0
    thcefficiency = round(((tatperhr_thc*idealtat_thc)/13500.0)*100,2)
    return thcefficiency

def efficiencycal_thc_buckets(thceffy):
    if thceffy<=50:
        return 'LOW'
    elif thceffy>50 and thceffy<=70:
        return 'MEDIUM'
    elif thceffy>70:
        return 'HIGH'
    else:
        return 'CHECK'


# In[15]:

thcload_unloadtime['Load_unload_TAT_per_hr'] = thcload_unloadtime.apply(lambda x: round((x['Actual_load_unload_wt'])/(x['Turn_around_time']),2))
thcload_unloadtime['THC_Efficiency'] = thcload_unloadtime.apply(lambda x: efficiencycal_thc(x['Load_unload_TAT_per_hr']))

thcload_unloadtime['THC_Efficiency_Bucket'] = thcload_unloadtime.apply(lambda x: efficiencycal_thc_buckets(x['THC_Efficiency']))


# In[ ]:




# In[16]:

##thcload_unloadtime['Turn_around_time'] = thcload_unloadtime.apply(lambda x: round(x['TAT'],2))


# In[17]:

thcload_unloadtime_load = thcload_unloadtime[thcload_unloadtime['Load_or_unload']=='L']
thcload_unloadtime_unload = thcload_unloadtime[thcload_unloadtime['Load_or_unload']=='U']
len(thcload_unloadtime_load),len(thcload_unloadtime_unload)


# In[18]:

thc_load_grpby = thcload_unloadtime_load.groupby(['Hub_Location'],{'TAT':agg.SUM('Turn_around_time'),'Actual_Load_or_Unload_Wt': agg.SUM('Actual_load_unload_wt'),'THC_L_Count': agg.COUNT('THC_Number')})
thc_unload_grpby = thcload_unloadtime_unload.groupby(['Hub_Location'],{'TAT':agg.SUM('Turn_around_time'),'Actual_Load_or_Unload_Wt': agg.SUM('Actual_load_unload_wt'),'THC_U_Count': agg.COUNT('THC_Number')})


# In[19]:

thc_load_grpby['Load_wt_TAT_perhr'] = thc_load_grpby.apply(lambda x: round((x['Actual_Load_or_Unload_Wt'])/(x['TAT']),2))
thc_unload_grpby['Unload_wt_TAT_perhr'] = thc_unload_grpby.apply(lambda x:round((x['Actual_Load_or_Unload_Wt'])/(x['TAT']),2))


# In[20]:

thc_load_grpby['Loading_Efficiency'] = thc_load_grpby.apply(lambda x: efficiencycal(x['Load_wt_TAT_perhr']))
thc_unload_grpby['Unloading_Efficiency'] = thc_unload_grpby.apply(lambda x: efficiencycal(x['Unload_wt_TAT_perhr']))


# In[21]:

thc_load_grpby


# In[22]:

thc_unload_grpby


# In[23]:

thcsummary = thc_load_grpby.join(thc_unload_grpby,on='Hub_Location',how = 'outer')


# In[24]:

thcsummary


# In[25]:

thcsummary = thcsummary.rename({'TAT':'TAT_Load','TAT.1':'TAT_Unload','Actual_Load_or_Unload_Wt':'Actual_Load_or_Unload_Wt_Load','Actual_Load_or_Unload_Wt.1':'Actual_Load_or_Unload_Wt_Unload'})


# In[26]:

columnslist = ['TAT_Load','THC_L_Count','Actual_Load_or_Unload_Wt_Load','Load_wt_TAT_perhr','Loading_Efficiency','TAT_Unload','THC_U_Count','Actual_Load_or_Unload_Wt_Unload','Unload_wt_TAT_perhr','Unloading_Efficiency']


# In[27]:

thcsummary = thcsummary.fillna('TAT_Load',0)
thcsummary = thcsummary.fillna('THC_L_Count', 0)
thcsummary = thcsummary.fillna('Actual_Load_or_Unload_Wt_Load', 0)
thcsummary = thcsummary.fillna('Load_wt_TAT_perhr', 0)
thcsummary = thcsummary.fillna('Loading_Efficiency', 0)
thcsummary = thcsummary.fillna('TAT_Unload', 0)
thcsummary = thcsummary.fillna('THC_U_Count', 0)
thcsummary = thcsummary.fillna('Actual_Load_or_Unload_Wt_Unload', 0)
thcsummary = thcsummary.fillna('Unload_wt_TAT_perhr', 0)
thcsummary = thcsummary.fillna('Unloading_Efficiency', 0)



# In[28]:

thcsummary['TOTAL_THCs'] = thcsummary.apply(lambda x:x['THC_L_Count']+x['THC_U_Count'])
thcsummary['TOTAL_ACT_WT'] = thcsummary.apply(lambda x:x['Actual_Load_or_Unload_Wt_Load']+x['Actual_Load_or_Unload_Wt_Unload'])
thcsummary['TOTAL_TAT'] = thcsummary.apply(lambda x:x['TAT_Load']+x['TAT_Unload'])


# In[29]:

thcsummary.head()


# In[30]:

thcsummary['TOTAL_TAT_PER_HR'] = thcsummary.apply(lambda x: round((x['TOTAL_ACT_WT'])/(x['TOTAL_TAT']),2))
thcsummary['TOTAL_EFFICIENCY'] = thcsummary.apply(lambda x: efficiencycal(x['TOTAL_TAT_PER_HR']))


# In[31]:

#thc_final_summary = thcsummary


# In[32]:



# In[33]:

thc_final_summary = thcsummary['Hub_Location','TOTAL_THCs','TOTAL_ACT_WT','THC_L_Count','Loading_Efficiency','THC_U_Count','Unloading_Efficiency','TOTAL_EFFICIENCY']


# In[34]:

thc_final_summary


# In[35]:

#thc_final_summary.remove_columns(['TAT_Load','TAT_Unload','Actual_Load_or_Unload_Wt_Unload','Actual_Load_or_Unload_Wt_Load','Load_wt_TAT_perhr','Unload_wt_TAT_perhr'])


# In[36]:

hublist = thc_final_summary['Hub_Location'].unique()
itemlist = []
for hubs in hublist:
    for i in range(0,24):
        thchub = thcload_unloadtime[thcload_unloadtime['Hub_Location']==hubs]
        thcrel = thchub[(thchub['Starthr']<=i) &(thchub['Endhr']>i)]
        count = len(thcrel)
        lcount = len(thcrel[thcrel['Load_or_unload']=='L'])
        ucount = count-lcount
        item = [hubs,i,count,lcount,ucount]
        itemlist.append(item)
itemdf = pd.DataFrame(itemlist)
itemdf.columns = ['Hub_Location','TimeofDay','THCCount','LCount','UCount']
itemsf = gl.SFrame(itemdf)


# In[37]:

hubgrp = itemsf.groupby(['Hub_Location'],{('Max_simultaneous_load_unload'): agg.MAX(('THCCount'))})


# In[38]:

hubgrp


# In[39]:

thc_final_summary = thc_final_summary.join(hubgrp,on='Hub_Location',how = 'outer')


# In[40]:

thc_final_summary_df = thc_final_summary.to_dataframe()
thc_final_summary_df = thc_final_summary_df.sort_values('TOTAL_ACT_WT',ascending=False)
thcload_unloadtime_df = thcload_unloadtime.to_dataframe()


# In[41]:

thc_final_summary_df


# In[42]:

thc_final_summary_df.to_csv('D:\Data\THC_Load_Unload_Efficiency\THC_Summary_Data\THC_LU_Efficiency_Summary.csv')
thcload_unloadtime_df.to_csv('D:\Data\THC_Load_Unload_Efficiency\THC_Data\THC_LU_Data.csv')


# In[ ]:
datetoday=datetime.datetime.today()
datefilter = datetoday-timedelta(hours=24)
datefilter=datefilter.date()
datefilter

oppath1 = r'D:\Data\THC_Load_Unload_Efficiency\THC_LU_Consolidated\THC_LU_Efficiency_'+str(datefilter)+'.xlsx'
with ExcelWriter(r'D:\Data\THC_Load_Unload_Efficiency\THC_LU_Consolidated\THC_LU_Efficiency_'+str(datefilter)+'.xlsx') as writer:
    thc_final_summary_df.to_excel(writer, sheet_name='SUMMARY',engine='xlsxwriter')
    thcload_unloadtime_df.to_excel(writer, sheet_name='THC_DATA',engine='xlsxwriter')


# In[ ]:
filePath = oppath1
def sendEmail(#TO = ["prasanna.hegde@spoton.co.in","hubmgr_spot@spoton.co.in"],
            #TO = ["rajeesh.vr@spoton.co.in"],
            TO = ["vishwas.j@spoton.co.in"],
            CC = ["vishwas.j@spoton.co.in"],
            #CC = ["supratim@iepfunds.com","pawan.sharma@spoton.co.in","Ankit@iepfunds.com","abhik.mitra@spoton.co.in","vishwas.j@spoton.co.in","rajeesh.vr@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "Linehaul_Vehicle_Load_Unload_Efficiency" + '- ' + str(datefilter)
    body_text = """
    Dear All,
    
    PFA the Linehaul_Vehicle_Load_Unload_Efficiency for """+str(datefilter)+ """
    
    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends



