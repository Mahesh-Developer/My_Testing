
# coding: utf-8

# In[1]:

import pandas as pd
from datetime import datetime,date,timedelta
import glob
import os
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import numpy as np
import Utilities
# In[2]:

today=date.today()


# In[3]:

last30days=today-timedelta(days=30)
last30days


# In[4]:

delta=today-last30days
delta


# In[5]:

# frame=pd.DataFrame()
list_=[]
for i in range(delta.days):
    a=datetime.strftime(datetime.now()-timedelta(days=i),"%Y-%m-%d-%H")
    destdir = r'D:\Data\Load Available\data'
    files = [ f for f in os.listdir(destdir) if os.path.isfile(os.path.join(destdir,f)) ]
    if (datetime.now().hour) in range(0,10):
        try:
            a1=a.split('-')
            a2=a1[3].split('0')[1]
            a3=a1[0]+'-'+a1[1]+'-'+a1[2]+'-'+a2
            b='inventory'+str(a3)+'.0'+'.csv'
            df=pd.read_csv(destdir+os.sep+b)
            list_.append(df)
        except:
            pass
    else:
        try:
            b='inventory'+str(a)+'.0'+'.csv'
            df=pd.read_csv(destdir+os.sep+b)
            list_.append(df)
        except:
            print ('file not found',b)
        
frame = pd.concat(list_)

# In[6]:

len(frame)


# In[7]:

frame['TimeStamp']=frame['TIMESTAMP'].apply(lambda x: datetime.strptime(x.split(' ')[0],'%Y-%m-%d'))


# In[8]:

pivot_df=frame.pivot_table(index=['Hub SC Location','TimeStamp'],aggfunc={'Act Wt In Tonnes':sum})


# In[9]:

pivot_df1=pivot_df.reset_index()


# In[10]:

pivot_df1


# In[11]:

#pivot_df1[pivot_df1['Hub SC Location']=='DELH']['Act Wt In Tonnes'].sum()/len(pivot_df1[pivot_df1['Hub SC Location']=='DELH'])


# In[12]:

stockdf = pd.read_excel(r'http://spoton.co.in/downloads/HTR_1HR/HTR_1HR.xls','HUB_THROUGHPUT_ONEHOUR')


# In[13]:

stockdfgrp = stockdf.groupby(['Hub SC Location']).agg({'Act Wt In Tonnes':sum}).reset_index().sort_values('Act Wt In Tonnes',ascending=False)


# In[14]:

stockdfgrp


# In[15]:

query = ("""
        ( SELECT    TC.thcno AS ThcNo ,
           CASE WHEN ISNULL(vs.SourceCode,'') = ''
		   THEN TC.sourcehb 
		   ELSE
           vs.SourceCode
		   END sourcehb, 

		    CASE WHEN ISNULL(vs.DestinationCode,'') = ''
		   THEN TC.tobh_code 
		   ELSE
           vs.DestinationCode
		   END tobh_code, 
          
            TC.routety ,
            CASE WHEN TC.routety = 'D' THEN GETDATE()
                 ELSE dbo.UFN_GET_THC_ARRCTIME_ASPER_GPS_CNM_NEW(TC.thcno,
                                                              NULL)
            END AS ArrivalTime_ASPER_GPS_CNM ,
            CAST(CONVERT(VARCHAR, hd2.actarrv_dt, 112) + ' ' + hd2.actarrv_tm AS SMALLDATETIME) Arrivaltime ,
            TR.TCHDRFLAG ,
            CASE WHEN hd2.tobh_code IS NULL THEN 'Y'
                 WHEN hd2.tobh_code = 'Null' THEN 'Y'
                 ELSE 'N'
            END AlreadyArrived ,
            SUM(d.ACTUWT) AS ld_actuwt
  FROM       THCHDR TC WITH ( NOLOCK )
  
            LEFT OUTER JOIN tbl_VehicleRunningStatus_New vs WITH ( NOLOCK ) ON vs.ThcNo = TC.thcno
                                                             
            LEFT OUTER JOIN THCHDR hd2 WITH ( NOLOCK ) ON TC.thcno = hd2.thcno
                                                          AND TC.tobh_code = hd2.sourcehb
            LEFT OUTER JOIN dbo.TCHDR TR WITH ( NOLOCK ) ON TR.THCNO = TC.thcno
                                                            AND TR.ToBH_CODE = TC.tobh_code
            LEFT OUTER  JOIN dbo.TCTRN d WITH ( NOLOCK ) ON d.TCNO = TR.TCNO
  WHERE     TC.actarrv_dt >= CONVERT(DATE, GETDATE() - 15)
          --  AND TC.tobh_code = 'BLRH'
            AND TC.tobh_code <> 'Null'
            AND ( hd2.thcno IS  NULL
                  OR TR.TCHDRFLAG = 'Y'
                )--INCLUDE THE CONS WHICH ARE NOT INSCANNED YET   
            AND hd2.sourcehb IS NOT NULL -- TO GET ONLY ARRIVED THC's
		--	AND tc.thcno = 'NTDELHX0073861'
  GROUP BY  TC.thcno ,
           
            TC.sourcehb ,
            TC.tobh_code ,
            TC.routety ,
            hd2.actarrv_dt ,
            hd2.actarrv_tm ,
            TR.TCHDRFLAG ,
            hd2.tobh_code,vs.SourceCode, vs.DestinationCode
 )
        """)


# In[16]:

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()


# In[17]:

veh_pileup_df = pd.read_sql(query, Utilities.cnxn)


# In[18]:

veh_pileup_df = veh_pileup_df[veh_pileup_df['routety']!='D']
len(veh_pileup_df)


# In[19]:

veh_pileup_df = veh_pileup_df[veh_pileup_df['AlreadyArrived']=='Y']
len(veh_pileup_df)


# In[20]:

#pivot_veh_pileup_df=veh_pileup_df.pivot_table(index=['tobh_code'],aggfunc=)
pivot_veh_pileup_df = veh_pileup_df.groupby(['tobh_code']).agg({'ld_actuwt':sum}).reset_index().sort_values('ld_actuwt',ascending=False)


# In[21]:

pivot_veh_pileup_df['Act Wt In Tonnes1']=pd.np.round(pivot_veh_pileup_df['ld_actuwt']/1000,1)


# In[22]:

pivot_veh_pileup_df.rename(columns={'tobh_code':'Hub SC Location'},inplace=True)


# In[23]:

result_df=pd.merge(stockdfgrp,pivot_veh_pileup_df,on='Hub SC Location',how='outer',suffixes=('_C','_P'))


# In[24]:

result_df=result_df.fillna(0)


# In[25]:

result_df['Result_Wt_In_Tonnes']=result_df['Act Wt In Tonnes']+result_df['Act Wt In Tonnes1']
#result_df[result_df['Hub SC Location']=='BBIH']

todate=datetime.strftime(datetime.now(),'%Y-%m-%d.%H')
todate
# In[26]:

dff1=pd.DataFrame()
for i in result_df['Hub SC Location'].tolist():
    avg=pivot_df1[pivot_df1['Hub SC Location']==i]['Act Wt In Tonnes'].sum()/len(pivot_df1[pivot_df1['Hub SC Location']==i])
    avg_res=result_df[result_df['Hub SC Location']==i]['Result_Wt_In_Tonnes']/avg
    quan90=pivot_df1[pivot_df1['Hub SC Location']==i]['Act Wt In Tonnes'].quantile(0.9)
    # dff=pd.DataFrame({'Hub SC Location':i,'Current_Wt':(result_df[result_df['Hub SC Location']==i]['Result_Wt_In_Tonnes']),'Avg_Mnth':avg,'Avg_Res':avg_res})
    dff=pd.DataFrame({'Hub SC Location':i,'Current_Wt':(result_df[result_df['Hub SC Location']==i]['Result_Wt_In_Tonnes']),'Perc_90':quan90,'Avg_Res':avg_res,'Avg_Mnth':avg})
    dff1=pd.concat([dff1,dff],ignore_index=True)
print (dff1)
#exit(0)

# In[27]:

dff1['Current_Wt']=pd.np.round(dff1['Current_Wt'],1)
dff1['Avg_Res']=pd.np.round(dff1['Avg_Res'],1)
dff1['Avg_Mnth']=pd.np.round(dff1['Avg_Mnth'],1)
dff1['Perc_90']=pd.np.round(dff1['Perc_90'],1)
dff1['Per_Increased']=(pd.np.round(dff1['Current_Wt']/dff1['Perc_90'],1))*100

dff1=dff1.replace([np.inf, -np.inf], np.nan)
dff1=dff1.fillna(0)
dff1['Per_Increased']=dff1['Per_Increased'].astype(int)

dff1.rename(columns={'Avg_Res':'%Increase','Avg_Mnth':'Monthly_Avg_Load'},inplace=True)
dff1['TimeStamp']=todate
dff1['%Increase']=(dff1['%Increase']*100.0).astype(int)
cutoff_df= dff1[dff1['Per_Increased']>130]


# In[28]:




# In[29]:

# cutoff_df=cutoff_df.sort_values('Avg_Res',ascending=False)


# # In[30]:

# cutoff_df.rename(columns={'Avg_Mnth':'Monthly_Avg_Load','Current_Wt':'Current_Load','Avg_Res':'%Increase'},inplace=True)


# In[31]:



# cutoff_df=cutoff_df[['Hub SC Location','Current_Load','Monthly_Avg_Load','%Increase']]
cutoff_df.rename(columns={'Hub SC Location':'LOC','Current_Wt':'Curr_Wt','Perc_90':'90_Perc','%Increase':'Avg_%Inc','Monthly_Avg_Load':'Avg_Load_30D','Per_Increased':'Per_Inc'},inplace=True)
dff1.rename(columns={'Hub SC Location':'LOC','Current_Wt':'Curr_Wt','Perc_90':'90_Perc','%Increase':'Avg_%Inc','Monthly_Avg_Load':'Avg_Load_30D','Per_Increased':'Per_Inc'},inplace=True)
# cutoff_df['%Increase']=cutoff_df['%Increase']*100.0
cutoff_df=cutoff_df[['LOC','Curr_Wt','Avg_%Inc','Avg_Load_30D','90_Perc','Per_Inc']]

dff1=dff1[['LOC','Curr_Wt','Avg_%Inc','Avg_Load_30D','90_Perc','Per_Inc']]
# exit(0)
mail_cutoff_df=cutoff_df.head(14)


# In[32]:



# In[33]:

with ExcelWriter(r'D:\Data\Load Criticality\Load_Criticality'+str(todate)+'.xlsx') as writer:
    dff1.to_excel(writer, sheet_name='Summary',engine='xlsxwriter')
    
# with ExcelWriter(r'D:\Data\Load Criticality\Load_Criticality_qu'+str(todate)+'.xlsx') as writer:
#     cutoff_df.to_excel(writer, sheet_name='Summary',engine='xlsxwriter')

# In[34]:
#exit(0)
filePath=r'D:\Data\Load Criticality\Load_Criticality'+str(todate)+'.xlsx'


# In[35]:

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

TO=['vishwas.j@spoton.co.in']
#TO=['mahesh.reddy@spoton.co.in']
FROM="reports.ie@spoton.co.in"
#CC=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
#msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = "Location Criticality " + " : " + str(todate)
html='''<html>
<style>
p
{
  margin:0;
  margin-top: 5px;
  padding:0;
  font-size:17px;
    line-height:20px;
}
</style>
<h3>Dear All,</h3>
<p>Please Find the Location Criticality.</p>
</html>'''


s = Template(html).safe_substitute()
report=""
report+=s
report+='<br>'
report+='<br>'+mail_cutoff_df.to_html()+'<br>'
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filePath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+BCC, msg.as_string())
server.quit()


