
# coding: utf-8

# In[11]:


import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select 
import pyodbc 
from pandas import ExcelWriter 
from datetime import datetime, timedelta
#import unidecode
import string
import smtplib
import ftplib
import traceback
import calendar
import os
import pyodbc
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

# In[2]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()


# In[6]:


# OFFC
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=PYTHON_DB;UID=PythonOnline;PWD=P@ssw0rd123$;")
# cursor = cnxn.cursor()


# # In[7]:


# # HME
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=PYTHON_DB;UID=PythonOnline;PWD=P@ssw0rd123$;")
# cursor = cnxn.cursor()


# In[3]:


startdate2='2019-08-01'
enddate2=datetime.strftime(datetime.now(),"%Y-%m-%d %H:%M:%S")


# In[53]:


enddate2


# In[ ]:


# startdate=datetime.strftime((datetime.now()-timedelta(days=1)).replace(day=1),"%Y-%m-%d")
# enddate=datetime.strftime(datetime.now(),"%Y-%m-%d")


# In[4]:


query=("""
SELECT  C.PermCaseID ,
        b.CreatedOn ,
        C.Status ,
        a.DockNo ,
        D.CSGNCD ,
        D.CSGNNM ,
        a.Dest_Path ,
        b.SecurityType ,
        b.IncidentLoc,
        D. DECLVAL
FROM    dbo.tblHRCCustDocketDtls a WITH ( NOLOCK )
        INNER JOIN dbo.tblSecIncidentReporting b WITH ( NOLOCK ) ON a.DockNo = b.ConNo
        INNER JOIN dbo.tblSecApprovedIncidents C WITH ( NOLOCK ) ON C.IncidentID = b.Id
        INNER JOIN dbo.DOCKET D WITH ( NOLOCK ) ON D.DOCKNO = a.DockNo
WHERE   b.SecurityType IN ( 'B', 'D' )
        AND
        b.CreatedOn BETWEEN '{0}'
                     AND    '{1}'
 

""").format (startdate2, enddate2) 


# In[26]:


# a=("""
# SELECT  top 10 *
# FROM    dbo.tblHRCCustDocketDtls a WITH ( NOLOCK )
#         INNER JOIN dbo.tblSecIncidentReporting b WITH ( NOLOCK ) ON a.DockNo = b.ConNo
#         INNER JOIN dbo.tblSecApprovedIncidents C WITH ( NOLOCK ) ON C.IncidentID = b.Id
#         INNER JOIN dbo.DOCKET D WITH ( NOLOCK ) ON D.DOCKNO = a.DockNo
# WHERE   b.SecurityType IN ( 'B', 'D' )


# """)


# In[5]:


v1=pd.read_sql(query,cnxn)




# In[12]:


# In[7]:


v2=v1['DockNo'].astype(int)


# In[8]:


v2=v1.drop_duplicates(subset='DockNo')


# In[9]:


v2=v2[~v2['Status'].isin(['C'])]


# In[10]:


v3B=v2[v2['SecurityType'].isin(['B'])]


# In[11]:


v3D=v2[v2['SecurityType'].isin(['D'])]


# In[36]:


v3B['Resolving hrs']=pd.to_datetime(enddate2)-v3B.apply(lambda x:x['CreatedOn'],axis=1)


# In[40]:


import numpy as np


# In[41]:


v3B['Resolving hrs']=v3B['Resolving hrs']/ np.timedelta64(1, 'h')


# In[43]:


def a(hrs):
    if hrs>=48:
        return 'Crossed timelimit'
    else:
        return 'Ok'


# In[45]:


v3B['Deadline']=v3B.apply(lambda x:a(x['Resolving hrs']),axis=1)


# In[50]:


v4B=v3B[v3B['Deadline']!='Ok']


# In[51]:


v4B


# In[76]:


def d(rh):
    if rh<=60:
        return '48-60 Hrs'
    if rh<=72:
        return '61-72 Hrs'
    else:
        return '> 72 Hrs'   


# In[77]:


v4B['time bracket']=v4B.apply(lambda x: d(x['Resolving hrs']),axis=1)


# In[78]:


v5B=v4B.pivot_table(index=['time bracket'],values=['DockNo'],aggfunc={'DockNo':len}).reset_index()


# In[79]:


v3D['Resolving hrs']=pd.to_datetime(enddate2)-v3D.apply(lambda x:x['CreatedOn'],axis=1)


# In[80]:


v3D['Resolving hrs']=v3D['Resolving hrs']/ np.timedelta64(1, 'h')


# In[81]:


def b(hrs):
    if hrs>=2:
        return 'Crossed timelimit'
    else:
        return 'Ok'


# In[82]:


v3D['Deadline']=v3D.apply(lambda x:b(x['Resolving hrs']),axis=1)


# In[83]:


v4D=v3D[v3D['Deadline']!='Ok']


# In[84]:


def c(rh):
    if rh<=5:
        return '3-5 Hrs'
    if rh<=10:
        return '6-10 Hrs'
    else:
        return '> 10 Hrs'   


# In[85]:


v4D['time bracket']=v4D.apply(lambda x: c(x['Resolving hrs']),axis=1)


# In[86]:


v5D=v4D.pivot_table(index=['time bracket'],values=['DockNo'],aggfunc={'DockNo':len}).reset_index()



# In[14]:


v4B.to_csv(r"D:\Data\HRC\Bad_POD.csv")


# In[15]:


v4D.to_csv(r'D:\Data\HRC\DEPS.csv')


# In[16]:


filepath=r"D:\Data\HRC\Bad_POD.csv"
filepath1=r'D:\Data\HRC\DEPS.csv'


# In[17]:


todate=datetime.strftime(datetime.now(),"%Y-%m-%d %H")
todate


# In[18]:


TO=['mahesh.reddy@spoton.co.in','saptarshi.pathak@spoton.co.in']
CC=['mahesh.reddy@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in']


FROM='reports.ie@spoton.co.in'
msg = MIMEMultipart()
msg["From"] = FROM
msg["TO"] = ",".join(TO)
msg["CC"] = ",".join(CC)

msg["Subject"] = "Exceptions Report on Security Tickets Not Closed On BAD POD & Deps " + str(todate)

report=""
report+='Dear All,'

report+='<br>'
report+='<br>'
report+='PFA Exceptions Report on Security Tickets Not Closed On BAD POD & Deps'
report+='<br>'
report+='<br>'
report+='Exceptions On BAD POD Summary Ticket Not Closed> 48hrs'
report+='<br>'
report+='<br>'
report+='<br>'+v5B.to_html()+'<br>'

report+='Exceptions On Live DEPS Summary Ticket Not Closed >2 hrs'
report+='<br>'
report+='<br>'
report+='<br>'+v5D.to_html()+'<br>'


abc=MIMEText(report,'html')
msg.attach(abc)
part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part1)

part2 = MIMEBase('application', "octet-stream")
part2.set_payload( open(filepath1,"rb").read() )
encoders.encode_base64(part2)
part2.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
msg.attach(part2)



#msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, CC+TO, msg.as_string())
server.quit()


