
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
import calendar
import datetime
from pandas import ExcelWriter
import os
import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import Utilities
from pandas import ExcelWriter


# In[2]:


pfilevar =date.today() - timedelta(hours=24)
opfilevarhours =datetime.datetime.now() - timedelta(hours=24)
#yesterday = datetime.datetime.today() - datetime.timedelta (days=1) 
new_period=opfilevarhours.replace(hour=12, minute=0).strftime ('%Y-%m-%d %H:%M:%S')
print (new_period)


# In[3]:


# openingstock = pd.io.excel.read_excel(r'C:\Users\S2769MAH\Downloads\OCID.xls','OPENING STOCK')
# print (len(openingstock))


# # In[4]:


# fullincomingstock = pd.io.excel.read_excel(r'C:\Users\S2769MAH\Downloads\OCID.xls','INCOMING')
# print (len(fullincomingstock))


# # In[5]:


# deliveredstock = pd.io.excel.read_excel(r'C:\Users\S2769MAH\Downloads\OCID.xls','DELIVERED')
# print (len(deliveredstock))


# # In[6]:


# closingstockfull = pd.io.excel.read_excel(r'C:\Users\S2769MAH\Downloads\OCID.xls','CLOSING STOCK')
# print (len(closingstockfull))


# In[7]:
openingstock = pd.io.excel.read_excel(r'http://10.109.230.50/downloads/OCID/OCID.xls','OPENING STOCK')
fullincomingstock = pd.io.excel.read_excel(r'http://10.109.230.50/downloads/OCID/OCID.xls','INCOMING')
deliveredstock = pd.io.excel.read_excel(r'http://10.109.230.50/downloads/OCID/OCID.xls','DELIVERED')
closingstockfull = pd.io.excel.read_excel(r'http://10.109.230.50/downloads/OCID/OCID.xls','CLOSING STOCK')


liblist = [000119721.0]
openingstock = openingstock[~(openingstock['CSGNCD'].isin(liblist))&~(openingstock['CSGECD'].isin(liblist))]
#openingstock = openingstock[~(openingstock['CSGECD'].isin(liblist))]
len(openingstock)


# In[8]:


deliveredstock = deliveredstock[~(deliveredstock['CSGNCD'].isin(liblist))&~(deliveredstock['CSGECD'].isin(liblist))]
#deliveredstock = deliveredstock[~(deliveredstock['CSGECD'].isin(liblist))]
len(deliveredstock)


# In[9]:


fullincomingstock = fullincomingstock[~(fullincomingstock['CSGNCD'].isin(liblist))&~(fullincomingstock['CSGECD'].isin(liblist))]
#fullincomingstock = fullincomingstock[~(fullincomingstock['CSGECD'].isin(liblist))]


# In[10]:


len(fullincomingstock)


# In[11]:


projectparentcodesexclist = [000117991.0,000118040.0,000118041.0,000118042.0,000118043.0,000118075.0,000111007.0,000114381.0]
openingstock = openingstock[~(openingstock['PARENTCODE'].isin(projectparentcodesexclist))]
fullincomingstock = fullincomingstock[~(fullincomingstock['PARENTCODE'].isin(projectparentcodesexclist))]
deliveredstock = deliveredstock[~(deliveredstock['PARENTCODE'].isin(projectparentcodesexclist))]


# In[12]:


projectconsgcd = [000117991.0,000118040.0,000118041.0,000118043.0,000111007.0,000118042.0,000118075.0,000114381.0]


# In[13]:


openingstock = openingstock[~(openingstock['CSGNCD'].isin(projectconsgcd))&~(openingstock['CSGECD'].isin(projectconsgcd))]
len(openingstock)


# In[14]:


fullincomingstock = fullincomingstock[~(fullincomingstock['CSGNCD'].isin(projectconsgcd))&~(fullincomingstock['CSGECD'].isin(projectconsgcd))]
len(fullincomingstock)


# In[15]:


deliveredstock = deliveredstock[~(deliveredstock['CSGNCD'].isin(projectconsgcd))&~(deliveredstock['CSGECD'].isin(projectconsgcd))]
len(deliveredstock)


# In[16]:


parentcodesexclist = [000116867.0,000118067.0,000118068.0,000108751.0,000118554.0]
destareaexcludelist = ['BOMA','HYDA'] ## Added HYDA on 27-10-2017
openingstock = openingstock[~((openingstock['PARENTCODE'].isin(parentcodesexclist)) & (openingstock['DEST AREA'].isin(destareaexcludelist)))]
fullincomingstock = fullincomingstock[~((fullincomingstock['PARENTCODE'].isin(parentcodesexclist))& (fullincomingstock['DEST AREA'].isin(destareaexcludelist)))]
deliveredstock = deliveredstock[~((deliveredstock['PARENTCODE'].isin(parentcodesexclist)) & (deliveredstock['DEST AREA'].isin(destareaexcludelist)))]


# In[17]:


delbranchdf=deliveredstock[['DEST BRCD','DEST AREA']]
opbranchdf=openingstock[['DEST BRCD','DEST AREA']]


# In[18]:


branchdf = pd.merge(delbranchdf,opbranchdf,on=['DEST BRCD','DEST AREA'],how='outer')
branchdf.rename(columns={'DEST BRCD':'BRANCH CODE','DEST AREA':'Area'}, inplace=True)
branchdf = branchdf.drop_duplicates(['BRANCH CODE'])


# In[19]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


# In[20]:


holidayquery = ("""
        select * from tblYearlyHolidayMst with (nolock) where HDAY_DATE>'2016-01-01'
        """)


# In[21]:


holidaymaster = pd.read_sql(holidayquery, Utilities.cnxn)
print (len(holidaymaster))


# In[24]:


def datestring(x):
    try:
        x = str(x)
        fulldate = datetime.datetime.strptime(x,'%Y-%m-%d %H:%M:%S')
        return fulldate
    except:
        x = str(x)
        fulldate = datetime.datetime.strptime(x,'%d-%m-%Y %H:%M')
        return fulldate


# In[25]:


holidaymaster['HDAY_DATE'] = holidaymaster.apply(lambda x : datestring(x['HDAY_DATE']),axis=1)


# In[31]:


now = datetime.datetime.now()
selectdate = now-timedelta(days=1)
selectdate = selectdate.replace(hour=0, minute=0, second=0).strftime('%Y-%m-%d %H:%M:%S')
selectdate = datetime.datetime.strptime(selectdate,'%Y-%m-%d %H:%M:%S')
print (selectdate,type(selectdate))


# In[32]:


holidaylist = list(set(holidaymaster['HDAY_DATE'].tolist()))
# holidaylist = list(set(holidaylist))


# In[34]:


if selectdate in holidaylist:
    print ('Yesterday in holiday list')
    selectdf = holidaymaster[holidaymaster['HDAY_DATE']==selectdate]
    selectdfbrcdlist = selectdf['BRCD'].tolist()
    selectdfbrcdlist = list(set(selectdfbrcdlist))
    selectdfarealist = selectdf['ControlArea'].tolist()
    selectdfarealist = list(set(selectdfarealist))
    print (selectdfbrcdlist)
    print (selectdfarealist)
    
    openingstock = openingstock[~(openingstock['DEST BRCD'].isin(selectdfbrcdlist))]
    openingstock = openingstock[~(openingstock['DEST AREA'].isin(selectdfarealist))]
    
    fullincomingstock = fullincomingstock[~(fullincomingstock['DEST BRCD'].isin(selectdfbrcdlist))]
    fullincomingstock = fullincomingstock[~(fullincomingstock['DEST AREA'].isin(selectdfarealist))]
    
    deliveredstock = deliveredstock[~(deliveredstock['DEST BRCD'].isin(selectdfbrcdlist))]
    deliveredstock = deliveredstock[~(deliveredstock['DEST AREA'].isin(selectdfarealist))]
else:
    selectdfbrcdlist = []
    selectdfarealist = []
    print ('Yesterday not in holiday list')


# In[35]:


openingstock = openingstock[openingstock['DEL LOCATION TYPE']=='STD']
fullincomingstock = fullincomingstock[fullincomingstock['DEL LOCATION TYPE']=='STD']
deliveredstock = deliveredstock[deliveredstock['DEL LOCATION TYPE']=='STD']
closingstockfull = closingstockfull[closingstockfull['DEL LOCATION TYPE']=='STD']


# In[36]:


ignorestatuscodelist = ['UCG','SSC','UG1','UG2','UG3','SHS']
#ignorestatuscodelist = ['UCG','SSC','UG1','UG2','UG3']
#ignorestatusdesclist = ['Awaiting for NSL Delivery Confirmation', 'Awaiting for ODA Delivery Confirmation', 'Change of Pincode from STD to ODA - Pending Approval', 'Non Serviceable Location', 'ODA DRS PREPARED', 'Shipment Held for ODA Delivery', 'Shipment held for Sales Tax inspection', 'Shipment Seized By Check Post / Sales Tax','STD to ODA Pincode Change Request - Awaiting CS Confirmation','Tagged For UCG']
openingstock=openingstock[~openingstock['Con Status Code'].isin(ignorestatuscodelist)]
closingstockfull=closingstockfull[~closingstockfull['Con Status Code'].isin(ignorestatuscodelist)]


# In[37]:


incoming12stock = fullincomingstock[(fullincomingstock['INC ARRV CATEGORY']=='<12PM')]
openinggroupby=openingstock.groupby(['DEST BRCD']).agg({'DOCKNO': 'count'}).reset_index()
incoming12groupby=incoming12stock.groupby(['DEST BRCD']).agg({'DOCKNO': 'count'}).reset_index()
deliveredgroupby=deliveredstock.groupby(['DEST BRCD']).agg({'DOCKNO': 'count'}).reset_index()


# In[39]:


merge_effeciency = pd.merge(openinggroupby,incoming12groupby,on=['DEST BRCD'], suffixes=['_op','_in'],how='outer')
merge_effeciency = pd.merge(merge_effeciency,deliveredgroupby, on=['DEST BRCD'], how='outer')
merge_effeciency = merge_effeciency.fillna(0)


# In[40]:


merge_effeciency.head(10)


# In[41]:


merge_effeciency['Delivery_Efficiency']=pd.np.round((merge_effeciency['DOCKNO']*100.0/(merge_effeciency['DOCKNO_op']+merge_effeciency['DOCKNO_in'])).replace([np.inf,-np.inf],np.nan).fillna(0),2)


# In[42]:


merge_effeciency


# In[43]:


merge_effeciency.rename(columns={'DOCKNO':'DOCKNO_Delivered'}, inplace=True)
merge_effeciency=pd.merge(merge_effeciency,branchdf,left_on=['DEST BRCD'],right_on=['BRANCH CODE'], how = 'inner')
merge_effeciency = merge_effeciency.drop(['BRANCH CODE'], axis=1)


# In[44]:


merge_effeciency.head()


# In[45]:


openingcons = merge_effeciency['DOCKNO_op'].sum() 
incomingcons = merge_effeciency['DOCKNO_in'].sum()
deliveredcons = merge_effeciency['DOCKNO_Delivered'].sum()
deliveryefficiency = pd.np.round(deliveredcons*100.0/(incomingcons+openingcons),2)
print (openingcons, incomingcons, deliveredcons)


# In[46]:


merge_effeciency_area=merge_effeciency.groupby(['Area']).agg({'DOCKNO_op': 'sum','DOCKNO_in': 'sum','DOCKNO_Delivered': 'sum'}).reset_index()


# In[47]:


merge_effeciency_area['Delivery_Efficiency']=pd.np.round((merge_effeciency_area['DOCKNO_Delivered']*100.0/(merge_effeciency_area['DOCKNO_op']+merge_effeciency_area['DOCKNO_in'])).replace([np.inf,-np.inf],np.nan).fillna(0),2)


# In[48]:


merge_effeciency_area


# In[49]:


ccfsrlist = ['SENDER FAILURE', 'RECEIVER FAILURE']
ccfsrdf=closingstockfull[closingstockfull['Con Status Category'].isin(ccfsrlist)]
ccfsrdfgroupby = ccfsrdf.groupby(['DEST AREA']).agg({'DOCKNO': 'count'}).reset_index()


# In[50]:


nonccfsrdf=closingstockfull[~closingstockfull['Con Status Category'].isin(ccfsrlist)]
nonccfsrdfgroupby = nonccfsrdf.groupby(['DEST AREA']).agg({'DOCKNO': 'count'}).reset_index()
nonccfcons = nonccfsrdfgroupby['DOCKNO'].sum()


# In[51]:


def datetimesplit(x):
    fulldate = datetime.strptime(x.split(' '),'%d-%m-%Y %H:%M:S')
    return fulldate


# In[54]:


opfilevar =date.today() - timedelta(hours=24)

print ('opfilevar',opfilevar)


# In[55]:


closingstockduecons = closingstockfull[closingstockfull['DUE DATE']==opfilevar]
closingstockduecons['ARRV_AT_DEST_SC'] = closingstockduecons.apply(lambda x:x['ARRV AT DEST SC'],axis=1)
closingarriv12 = closingstockduecons[closingstockduecons['ARRV_AT_DEST_SC']<=new_period]
print (len(closingarriv12))
print (type(closingstockduecons['ARRV AT DEST SC'].values[0]))
closingarriv12free = closingarriv12[closingarriv12['Is Free Con']=='YES']


# In[56]:


len(closingarriv12free)


# In[57]:


closingarriv12grp = closingarriv12.groupby(['DEST AREA']).agg({'DOCKNO':len}).reset_index()
totalduecons = closingarriv12grp['DOCKNO'].sum()
closingarriv12freegrp = closingarriv12free.groupby(['DEST AREA']).agg({'DOCKNO':len}).reset_index()
totaldueconsfree = closingarriv12freegrp['DOCKNO'].sum()
print ('totaldueconsfree',totaldueconsfree)


# In[58]:


cutoffformorefreecons = 0.1*totaldueconsfree
cutoffformorefreecons


# In[96]:


morefreeconsdestarealist = closingarriv12freegrp[closingarriv12freegrp['DOCKNO']>=cutoffformorefreecons]['DEST AREA'].tolist()
morefreeconsdestarealist = [str(x) for x in morefreeconsdestarealist]
morefreeconslist = closingarriv12freegrp[closingarriv12freegrp['DOCKNO']>=cutoffformorefreecons]['DOCKNO'].tolist()
morefreeconslist = [str(x) for x in morefreeconslist]
combinedfreeconlist = zip(morefreeconsdestarealist,morefreeconslist)
combinedfreeconlist


# In[61]:


closingnotdel = pd.merge(closingarriv12grp,closingarriv12freegrp,left_on=['DEST AREA'],right_on=['DEST AREA'],suffixes=['_MissedDD','_Missed_FreeDD'],how='outer')


# In[62]:


closingstockfullpivot = closingstockfull.groupby(['DEST AREA']).agg({'DOCKNO': 'count'}).reset_index()
closingstockcons = closingstockfullpivot['DOCKNO'].sum()
efficiencyclstock = pd.merge(merge_effeciency_area,closingstockfullpivot,left_on=['Area'],right_on=['DEST AREA'], how = 'inner')


# In[63]:


closingstoctl24 = closingstockfull[closingstockfull['REPORTDATE MIN ARRVDT']>=39]
closingstoctl24cons = len(closingstoctl24)
closingstoctl24aging = np.ceil(closingstoctl24['REPORTDATE MIN ARRVDT'].sum()/closingstoctl24cons)


# In[64]:


closingstoctl24groupby=closingstoctl24.groupby(['DEST AREA']).agg({'DOCKNO': 'count', 'REPORTDATE MIN ARRVDT':'sum'}).reset_index()


# In[65]:


#closingstoctl24groupby['Avg_Cooling_Hrs']=closingstoctl24groupby.apply (lambda x : getavg(x['DOCKNO'],x['REPORTDATE MIN ARRVDT']),axis=1)
closingstoctl24groupby['Avg_Cooling_Hrs']=closingstoctl24groupby['REPORTDATE MIN ARRVDT']/closingstoctl24groupby['DOCKNO']


# In[66]:


closingstoctl24groupby


# In[67]:


closingstoctl24gb = closingstoctl24groupby.groupby(['DEST AREA']).agg({'DOCKNO':'sum','Avg_Cooling_Hrs':np.mean}).reset_index()


# In[68]:


efficiencyclstockfull = pd.merge(efficiencyclstock,closingstoctl24gb,left_on=['Area'],right_on=['DEST AREA'], how = 'inner')
efficiencyclstockfull = efficiencyclstockfull.drop(['DEST AREA_x'], axis=1)
efficiencyclstockfull = efficiencyclstockfull.drop(['DEST AREA_y'], axis=1)


# In[69]:


efficiencyclstockfull.rename(columns={'DOCKNO_x':'Closing_Stock','DOCKNO_y':'Closing_Stock>24hrs','Avg_Cooling_Hrs':'Avg_Cooling_Hrs>24hrs'},inplace=True)


# In[70]:


def ccfperc(x,y):
    return np.ceil((x*100.0)/(y))


# In[71]:


efficiencyclstockfullccf = pd.merge(efficiencyclstockfull,ccfsrdfgroupby,left_on=['Area'],right_on=['DEST AREA'], how = 'outer')
efficiencyclstockfullccf['%CCF_Cons'] = efficiencyclstockfullccf.apply (lambda x : ccfperc(x['DOCKNO'],x['Closing_Stock']),axis=1)
efficiencyclstockfullccf = efficiencyclstockfullccf.rename(columns={'DOCKNO':'CCF_Cons'})


# In[72]:


ccfconsno = efficiencyclstockfullccf['CCF_Cons'].sum()
ccfpercentagecons = pd.np.round((ccfconsno*100.0)/closingstockcons,2)


# In[73]:


def effcheck(x,y):
    if x<65 and y<65:
        return 'Check'
    else:
        return '-'


# In[74]:


def setceil(x):
    return pd.np.round(x,0)


# In[75]:


efficiencyclstockfullccf = pd.merge(efficiencyclstockfullccf,nonccfsrdfgroupby,left_on=['Area'],right_on=['DEST AREA'], how = 'outer') 
efficiencyclstockfullccf = pd.merge(efficiencyclstockfullccf,closingnotdel,left_on=['Area'],right_on=['DEST AREA'], how = 'outer') 
efficiencyclstockfullccf['REMARKS'] = efficiencyclstockfullccf.apply(lambda x :effcheck(x['Delivery_Efficiency'],x['%CCF_Cons']),axis =1)


# In[76]:


efficiencyclstockfullccf.rename(columns={'DOCKNO':'NON_CCF_Cons','DOCKNO_MissedDD':'Due_Undel','DOCKNO_Missed_FreeDD':'Due_Undel_Free'},inplace=True)


# In[77]:


columnsopreqcols=['Area','DOCKNO_Delivered','Delivery_Efficiency','%CCF_Cons','NON_CCF_Cons','REMARKS','Due_Undel','Due_Undel_Free']
efficiencyreqcols = pd.DataFrame(efficiencyclstockfullccf,columns=columnsopreqcols)


# In[78]:


efficiencyreqcols.rename(columns={'DOCKNO_Delivered':'DELIVERED','Delivery_Efficiency':'DELIVERY_EFFY'},inplace=True)


# In[79]:


efficiencyreqcols['DELIVERY_EFFY'] = efficiencyreqcols.apply(lambda x :setceil(x['DELIVERY_EFFY']),axis =1)


# In[80]:


sumlist = ['TOTAL',deliveredcons,deliveryefficiency,ccfpercentagecons,nonccfcons,'-',totalduecons,totaldueconsfree]
col_list = ['Area','DELIVERED','DELIVERY_EFFY','%CCF_Cons','NON_CCF_Cons','REMARKS','Due_Undel','Due_Undel_Free']
totalsdf = pd.DataFrame(data=[sumlist], columns = col_list)
efficiencyreqcols = efficiencyreqcols.append(totalsdf,ignore_index=True)


# In[81]:


efficiencyclstockfullccf = efficiencyclstockfullccf.drop(['DEST AREA_x','DEST AREA_y','REMARKS'], axis=1)


# In[82]:


merge_effeciency =merge_effeciency[~(merge_effeciency['DEST BRCD'].isin(selectdfbrcdlist))]
efficiencyclstockfullccf =efficiencyclstockfullccf[~(efficiencyclstockfullccf['Area'].isin(selectdfarealist))]
efficiencyreqcols=efficiencyreqcols[~(efficiencyreqcols['Area'].isin(selectdfarealist))]


# In[83]:


#oppath2=r'C:\Users\S2769MAH\Downloads\PMD_data\13-02-2018_PMD-Data\downloads\PMD\Delivery_Efficiency_'+str(opfilevar)+'.xlsx'
oppath2=r'D:\Data\eta_rank\Delivery_Efficiency\Delivery_Efficiency_'+str(opfilevar)+'.xlsx'

# In[85]:


with ExcelWriter(r'D:\Data\eta_rank\Delivery_Efficiency\Delivery_Efficiency_'+str(opfilevar)+'.xlsx') as writer:
    ###orginal_cancel_basedata.to_excel(writer, sheet_name='Sheet1',engine='xlsxwriter')
    merge_effeciency.to_excel(writer, sheet_name='SC_WISE',engine='xlsxwriter')
    efficiencyclstockfullccf.to_excel(writer, sheet_name='AREA_WISE',engine='xlsxwriter')


# In[89]:
merge_effeciency.to_csv(r'D:\Data\eta_rank\STD_DE_SC.csv', encoding='utf-8')
efficiencyclstockfull.to_csv(r'D:\Data\eta_rank\STD_DE.csv', encoding='utf-8')


def datestring2(tsp):
    tsp = str(tsp)
    try:
        return datetime.datetime.strptime(tsp.split(' ')[0], '%d-%m-%Y')
    except:
        return datetime.datetime.strptime(tsp.split(' ')[0], '%Y-%m-%d')


# In[90]:


def datestring(x):
    try:
        fulldate = datetime.datetime.strptime(x,'%Y-%m-%d')
        return fulldate
    except:
        fulldate = datetime.datetime.strptime(x,'%d-%m-%Y')
        return fulldate


# In[91]:


deliveredstock['Delivery_Date']= deliveredstock.apply(lambda x: datestring2(x['DELY DT']), axis=1)
deliveredstock['Due_date'] = deliveredstock.apply(lambda x: datestring2(x['DUE DATE']), axis=1)
deliveredstock['DD_DelyDt'] = deliveredstock.apply(lambda x: (x['Delivery_Date']-x['Due_date']).days,axis=1)


# In[92]:


sumofdiffdays = deliveredstock['DD_DelyDt'].sum()
avrghoursofdelcons = pd.np.round((sumofdiffdays*24.0)/deliveredcons,2)


# In[93]:


filePath = oppath2


# In[97]:

# efficiencyreqcols=efficiencyreqcols.dropna()
efficiencyreqcols=efficiencyreqcols.fillna(0)

print (efficiencyreqcols)
# In[98]:




import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template
#vishwas.j@spoton.co.in
# TO=['vishwas.j@spoton.co.in']
TO = ["aom_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in","rajesh.mishra@spoton.co.in","raghavendra.rao@spoton.co.in","ashwani.gangwar@spoton.co.in","pramod.pandey@spoton.co.in","trilochan.panda@spoton.co.in","sunil.nakte@spoton.co.in","chandrima.banerjee@spoton.co.in", "suresh.d@spoton.co.in", "pankaj.jha@spoton.co.in"]
FROM='vishwas.j@spoton.co.in'
# CC=['vishwas.j@spoton.co.in']
CC = ["sqtf@spoton.co.in","SQ_spot@spoton.co.in"]
# BCC=['vishwas.j@spoton.co.in']
BCC = ["shashvat.suhane@spoton.co.in","mahesh.reddy@spoton.co.in","sachidanand.pandey@spoton.co.in","renugopal.l@spoton.co.in","sathya.chander@spoton.co.in","alagu.mahendran@spoton.co.in","awadhesh.kumar.mishra@spoton.co.in","sanjay.parab@spoton.co.in","ramesh.s@spoton.co.in","md.zaya@spoton.co.in","Pradyumna.Kumar@Spoton.Co.In"]
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
html='''<html>
<style>
p
{
  margin:0;
  margin-top: 5px;
  padding:0;
  font-size:15px;
    line-height:20px;
}
</style>
<h4>Dear All,</h4>
<p>Delivered = $deliveredcons</p>
<p>Opening Stock = $openingcons</p>
<p>Incoming Stock = $incomingcons</p>
<p>Closing Stock = $closingstockcons</p>
<p>Closing Stock > 24hrs =$closingstoctl24cons</p>
<p>Average Ageing of Closing Stock >24hrs = $closingstoctl24aging hrs</p>
<p>Cons of Duedate $opfilevar not delivered = $totalduecons</p>
<p>Due Date cons of $opfilevar not delivered and free for today = $totaldueconsfree</p> 
<p>Areas with high duedate free cons not delivered = $combinedfreeconlist</p>
<p>CCF Cons % of Closing Stock = $ccfpercentagecons %</p>
<p>Average Delay Hours of Delivered Cons = $avrghoursofdelcons Hrs</p>
<p>The Overall Delivery efficiency of STD cons is $deliveryefficiency %</p>
<p>PFB the Delivery Efficiency Area wise as of $opfilevar</p>
</html>'''

html3='''
<h5>The AREA-WISE and SC-WISE summary has been attached in the mail.</h5>
<h5> For the base data, please refer the link </h5>
<p><a href= "http://10.109.230.50/downloads/OCID/OCID.xls"</a>http://10.109.230.50/downloads/OCID/OCID.xls</p></b>
'''
s = Template(html).safe_substitute(deliveryefficiency=deliveryefficiency,avrghoursofdelcons=avrghoursofdelcons,ccfpercentagecons=ccfpercentagecons,combinedfreeconlist=combinedfreeconlist,totaldueconsfree=totaldueconsfree,totalduecons=totalduecons,opfilevar=opfilevar,closingstoctl24aging=closingstoctl24aging,closingstoctl24cons=closingstoctl24cons,closingstockcons=closingstockcons,incomingcons=incomingcons,openingcons=openingcons,deliveredcons=deliveredcons)
report=""
report+=s
report+='<br>'
report+='<br>'+efficiencyreqcols.to_html()+'<br>'
report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filePath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()

with ExcelWriter(r'D:\Data\DE_Conwise_Stock\DE_STD\Delivery_Efficiency_STD_'+str(opfilevar)+'.xlsx') as writer:
    openingstock.to_excel(writer, sheet_name='OPENING_STOCK',engine='xlsxwriter')
    incoming12stock.to_excel(writer, sheet_name='INCOMING_STOCK',engine='xlsxwriter')
    deliveredstock.to_excel(writer, sheet_name='DELIVERED',engine='xlsxwriter')
    closingstockfull.to_excel(writer, sheet_name='CLOSING_STOCK',engine='xlsxwriter')