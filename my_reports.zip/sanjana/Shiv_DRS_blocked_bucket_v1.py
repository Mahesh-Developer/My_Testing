
# coding: utf-8

# In[1]:

import pandas as pd
from pandas import ExcelWriter
import os
import traceback
import math
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
#sys.setdefaultencoding("Windows-1252")


# In[2]:
try:
    #stockdata = pd.read_csv(r'C:\Data\Shiv_ops\CLSSTKSUM_25042016.csv')
    stockdata = pd.read_csv(r'http://spoton.co.in/downloads/IEPROJECTS/CLSSTKSUM/CLSSTKSUM.csv')


    # In[3]:

    stockdata.columns.tolist()


    # In[4]:

    stockdata=stockdata.rename(columns={'\xef\xbb\xbfPARENTCODE1':'PARENTCODE1'})


    # In[5]:

    drsblockedbucketlist = ['A3_PAYMENT_ISSUE']
    stockdatadrsblocked = stockdata[stockdata['STATUS1'].isin(drsblockedbucketlist)]
    stockdatadrsblocked = stockdatadrsblocked.drop(['STATUS1','LATEST_CON_REC_COMM1','CSGENM2'],axis=1)
    len(stockdatadrsblocked)


    # In[6]:

    datetoday= datetime.today()
    datefilter = datetoday-timedelta(hours=24)
    datefilter=datefilter.date()
    datefilter


    # In[7]:

    stockdatadrsblocked['PARENTNAME1'] = stockdatadrsblocked['PARENTNAME1'].str.decode('utf-8').replace(u'\0x96', '-')
    #stockdatadrsblocked['RECEIVER NAME'] = stockdatadrsblocked['RECEIVER NAME'].str.decode('utf-8').replace(u'\0x96', '-')
    #stockdatadrsblocked['SENDER NAME'] = stockdatadrsblocked['SENDER NAME'].str.decode('utf-8').replace(u'\0x96', '-')
    stockdatadrsblocked['ConStatusReason2'] = stockdatadrsblocked['ConStatusReason2'].str.decode('utf-8').replace(u'\0x96', '-')


    ##stockdatadrsblockedcols = [i for i in stockdatadrsblocked.columns if ('Date' in i) or ('DT' in i) or ('ARRV_AT_DEST' in i)]
    stockdatadrsblockedcols = ['CDELDT1','ARRV_AT_DEST_SC2','ConStatusDate2']
    print stockdatadrsblockedcols


    print stockdatadrsblocked['ARRV_AT_DEST_SC2'].values[0]
    print pd.unique(stockdatadrsblocked['CDELDT1'])
    print pd.unique(stockdatadrsblocked['ARRV_AT_DEST_SC2'])
    print pd.unique(stockdatadrsblocked['ConStatusDate2'])

    timeformat1 = '%d/%m/%Y %H:%M:%S %p'
    dayzero1 = '30/12/2011 00:00:00 AM'
    dayzero = datetime.strptime(dayzero1,timeformat1)

    stockdatadrsblocked.ConStatusDate2.fillna(dayzero1, inplace=True)

    def datestring(x):
        x = str(x)
        try:
            fulldate = datetime.strptime(x,'%m/%d/%Y %H:%M:%S %p')
            return fulldate
        except:
            fulldate = datetime.strptime(x,'%d/%m/%Y %H:%M:%S %p')
            return fulldate

    print stockdatadrsblocked['ARRV_AT_DEST_SC2'].values[0]

    for cols in stockdatadrsblockedcols:
        stockdatadrsblocked[cols] = stockdatadrsblocked.apply(lambda x:datestring(x[cols]),axis=1)

    # In[8]:

    with ExcelWriter(r'D:\Data\Shiv_closingstock_automation\DRS_blocked_payment_issues\Closingstock_DRS_Blocked_'+str(datefilter)+'.xlsx') as writer:
        #stockdatadrsblocked.to_excel(writer, sheet_name='FULL',engine='xlsxwriter')
        stockdatadrsblocked.to_excel(writer, sheet_name='DRS_Blocked_Payment_issues',engine='xlsxwriter')

    oppath1 = r'D:\Data\Shiv_closingstock_automation\DRS_blocked_payment_issues\Closingstock_DRS_Blocked_'+str(datefilter)+'.xlsx'


    # In[9]:

    filePath1 = oppath1
    def sendEmail(TO = ["manzil.bhattacharya@spoton.co.in","akhil.tyagi@spoton.co.in","arpita.mitra@spoton.co.in"],
                 #TO = ["vishwas.j@spoton.co.in"],
                 #TO = ["anitha.thyagarajan@spoton.co.in"],
                 #TO = ["rajeesh.vr@spoton.co.in"],
                 CC = ["shivananda.p@spoton.co.in","Rajesh.Kumar@Spoton.Co.In","anitha.thyagarajan@spoton.co.in"],
                 #CC = ["vishwas.j@spoton.co.in"],
                 BCC =  ["mahesh.reddy@spoton.co.in"],
                FROM="mis.ho@spoton.co.in"):
        HOST = "smtp.spoton.co.in"
    #smtplib.SMTP('smtp.spoton.co.in', 25)

        msg = MIMEMultipart()
        msg["From"] = FROM
        msg["To"] = ",".join(TO)
        msg["CC"] = ",".join(CC)
        msg["BCC"] = ",".join(BCC)
        msg["Subject"] = "DRS Blocked cases- Payment Issues - "+ str(datefilter)
        body_text = """
        Dear All,
        
        PFA the DRS Blocked cases- Payment Issues for """+str(datefilter)+"""
        
        """
        if body_text:
            msg.attach( MIMEText(body_text) )
        part = MIMEBase('application', "octet-stream")
        part.set_payload( open(filePath1,"rb").read() )
        Encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath1))
        msg.attach(part)
        server=smtplib.SMTP('smtp.sendgrid.net', 587)
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login("mis.ho@spoton.co.in", "Mis@2019")

        try:
            failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
            server.close()
        except Exception, e:
            errorMsg = "Unable to send email. Error: %s" % str(e)

    if __name__ == "__main__":
        sendEmail()
    print('Email sent')
    #Sending output file via mail ends

except:

  TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in'] 
  CC=['mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "DRS Blocked cases- Payment Issues Error in Execution" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in DRS Blocked cases- Payment Issues'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO+CC, msg.as_string())
  server.quit()


