
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta,datetime
import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
from pandas import ExcelWriter
import os
import smtplib
import ftplib
import traceback
import calendar
from time import strptime
import Utilities
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os


# In[2]:


#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
#cursor = cnxn.cursor()


# In[3]:
try:
    query=("""EXEC USP_PUD_YEST_MTD_DATA 'M' """)
    df=pd.read_sql(query,Utilities.cnxn)
    df=df[df['PTYPE']!='AR']

    # In[3]:


    len(df)


    # In[4]:


    m = {'Jan': '01','Feb': '02','Mar': '03','Apr':'04','May':'05','Jun':'06','Jul':'07','Aug':'08','Sep':'09','Oct':'10','Nov':'11','Dec':'12'}
    def dateconv(date):
        dt = date.split(' ')[2]+'-'+str(m.get(date.split(' ')[1]))+'-'+date.split(' ')[0]
        return dt


    # In[5]:


    df["DateOnly"]=df.apply(lambda x: dateconv(x["DATE"]),axis=1)


    # In[ ]:


    df.columns


    # In[6]:


    df1=df[df['DEPOT'].isin(['BLRD','MAAD'])]
    len(df1)


    # In[ ]:


    df1['DateOnly'].unique()


    # In[7]:


    # df1=df1[df1['DateOnly']>='2018-11-13']
    len(df1)


    # In[ ]:


    len(df)


    # In[8]:


    yest_date=datetime.strftime(datetime.now()-timedelta(1),'%Y-%m-%d')
    yest_date


    # In[9]:


    std_df=df1[df1['PUDTYPE']=='STD']
    len(std_df)
    yest_std_df=std_df[std_df['DateOnly']==yest_date]
    len(yest_std_df)
    yest_std_df['Type']='YST'
    std_df['Type']='MTD'
    #std_df['Type']=std_df.apply(lambda x:getType(x['DateOnly']),axis=1)
    final_std_df=pd.concat([std_df,yest_std_df],ignore_index=True)
    final_std_summary=final_std_df.pivot_table(index=['PINCODE','CUSTOMERCODE','DEPOT','BRANCH_CODE'],columns=['Type'],values=['ACT_WT','COST','con_id'],
                                            aggfunc={'ACT_WT':sum,'COST':sum,'con_id':len}).reset_index()
    final_std_summary1=final_std_summary.fillna(0)
    final_std_summary1.rename(columns={'con_id':'Cons'},inplace=True)
    final_std_summary1['Cons']=final_std_summary1['Cons'].astype(int)
    final_std_summary1['CPKG','YST']=pd.np.round(final_std_summary1['COST','YST']/final_std_summary1['ACT_WT','YST'],1)
    final_std_summary1['CPKG','MTD']=pd.np.round(final_std_summary1['COST','MTD']/final_std_summary1['ACT_WT','MTD'],1)
    final_std_summary1=final_std_summary1.fillna(0)


    # In[10]:


    final_std_summary_pudname=final_std_df.pivot_table(index=['PINCODE','CUSTOMERCODE','DEPOT','BRANCH_CODE','PUD_NAME'],columns=['Type'],values=['ACT_WT','COST','con_id'],
                                            aggfunc={'ACT_WT':sum,'COST':sum,'con_id':len}).reset_index()


    # In[188]:

    yest_std_pivot=yest_std_df.pivot_table(index=['PINCODE','CUSTOMERCODE','PUDTYPE','PUD_NAME','TYP'],values=['COST','ACT_WT','con_id'],
                               aggfunc={'COST':sum,'ACT_WT':sum,'con_id':len}
                              ).reset_index()


    # In[11]:


    df_adhoc=df1[df1['PUDTYPE']=='ADHOC']
    len(df_adhoc)
    yest_df_adhoc=df_adhoc[df_adhoc['DateOnly']==yest_date]
    yest_df_adhoc["Type"]='YST'
    df_adhoc['Type']='MTD'
    #df_adhoc['Type']=df_adhoc.apply(lambda x: getType(x['DateOnly']),axis=1)
    df_adhoc_final_df1=pd.concat([df_adhoc,yest_df_adhoc],ignore_index=True)
    final_adhoc_summary_pincode=df_adhoc_final_df1.pivot_table(index=['PINCODE','CUSTOMERCODE','DEPOT','BRANCH_CODE'],columns=['Type'],
                                                             values=['ACT_WT','COST','con_id'],
                                            aggfunc={'ACT_WT':sum,'con_id':len,'COST':sum}).reset_index()
    final_adhoc_summary_pincode=final_adhoc_summary_pincode.fillna(0)
    final_adhoc_summary_pincode['CPKG','MTD']=pd.np.round(final_adhoc_summary_pincode['COST','MTD']/final_adhoc_summary_pincode['ACT_WT','MTD'],1)
    final_adhoc_summary_pincode['CPKG','YST']=pd.np.round(final_adhoc_summary_pincode['COST','YST']/final_adhoc_summary_pincode['ACT_WT','YST'],1)
    final_adhoc_summary_pincode1=final_adhoc_summary_pincode.fillna(0)


    # In[12]:


    final_adhoc_summary_pincode=final_adhoc_summary_pincode.fillna(0)
    final_adhoc_summary_pincode.rename(columns={'con_id':'Cons'},inplace=True)

    final_adhoc_summary_pincode['Cons']=final_adhoc_summary_pincode['Cons'].astype(int)
    final_adhoc_summary_pincode.head()
    final_adhoc_summary_pincode_pudname=df_adhoc_final_df1.pivot_table(index=['PINCODE','CUSTOMERCODE','DEPOT','BRANCH_CODE','PUD_NAME'],columns=['Type'],
                                                             values=['ACT_WT','COST','con_id'],
                                            aggfunc={'ACT_WT':sum,'con_id':len,'COST':sum}).reset_index()
    final_std_summary_pudname=pd.merge(final_std_summary_pudname,final_adhoc_summary_pincode_pudname,
                              on=['PINCODE','CUSTOMERCODE','DEPOT','BRANCH_CODE'],how='inner',suffixes=('_STD','_ADHOC'))


    # In[13]:


    final_std_summary_pudname=final_std_summary_pudname.fillna(0)


    # In[205]:

    final_std_summary_pudname['CPK_STD','MTD']=pd.np.round(final_std_summary_pudname['COST_STD','MTD']/final_std_summary_pudname['ACT_WT_STD','MTD'],1)
    final_std_summary_pudname['CPK_STD','YST']=pd.np.round(final_std_summary_pudname['COST_STD','YST']/final_std_summary_pudname['ACT_WT_STD','YST'],1)


    # In[206]:

    final_std_summary_pudname['CPK_ADHOC','MTD']=pd.np.round(final_std_summary_pudname['COST_ADHOC','MTD']/final_std_summary_pudname['ACT_WT_ADHOC','MTD'],1)
    final_std_summary_pudname['CPK_ADHOC','YST']=pd.np.round(final_std_summary_pudname['COST_ADHOC','YST']/final_std_summary_pudname['ACT_WT_ADHOC','YST'],1)


    # In[207]:

    final_std_summary_pudname=final_std_summary_pudname.replace([np.inf,-np.inf],np.nan).fillna(0)


    # In[208]:

    final_std_summary1=pd.merge(final_std_summary1,final_adhoc_summary_pincode,on=['PINCODE','CUSTOMERCODE','DEPOT','BRANCH_CODE'],how='inner',suffixes=('_STD','_ADHOC'))


    # In[209]:

    final_std_summary1['CPK_STD','MTD']=pd.np.round(final_std_summary1['COST_STD','MTD']/final_std_summary1['ACT_WT_STD','MTD'],1)
    final_std_summary1['CPK_STD','YST']=pd.np.round(final_std_summary1['COST_STD','YST']/final_std_summary1['ACT_WT_STD','YST'],1)


    # In[210]:

    final_std_summary1['CPK_ADHOC','MTD']=pd.np.round(final_std_summary1['COST_ADHOC','MTD']/final_std_summary1['ACT_WT_ADHOC','MTD'],1)
    final_std_summary1['CPK_ADHOC','YST']=pd.np.round(final_std_summary1['COST_ADHOC','YST']/final_std_summary1['ACT_WT_ADHOC','YST'],1)


    # In[211]:

    final_std_summary1=final_std_summary1.replace([np.inf,-np.inf],np.nan).fillna(0)


    # In[212]:

    final_std_summary2=final_std_summary1.sort_values(('COST_ADHOC','MTD'),ascending=False)


    # In[14]:


    final_std_summary2


    # In[15]:



    final_std_summary2['CODE']=final_std_summary2['PINCODE'].astype(int).astype(str)+final_std_summary2['CUSTOMERCODE'].astype(int).astype(str)


    # In[215]:

    final_std_summary2.columns=[''.join(col).strip() for col in final_std_summary2.columns]


    # In[216]:

    final_std_summary2.head()


    # In[217]:
    pincode_cstmcode_list=final_std_summary2['CODE'].unique().tolist()
    final_std_summary3=final_std_summary2.pivot_table(index=['DEPOT','BRANCH_CODE'],values=['CODE','COST_STDMTD','COST_STDYST',
                                              'Cons_STDMTD','Cons_STDYST','COST_ADHOCMTD','COST_ADHOCYST','Cons_ADHOCMTD','Cons_ADHOCYST'],
                          aggfunc={'CODE':lambda x:len(x.unique()),'COST_STDMTD':sum,'COST_STDYST':sum,
                                              'Cons_STDMTD':sum,'Cons_STDYST':sum,'COST_ADHOCMTD':sum,'COST_ADHOCYST':sum,
                                   'Cons_ADHOCMTD':sum,'Cons_ADHOCYST':sum})


    # In[218]:

    final_std_summary4=final_std_summary3.reset_index()


    # In[219]:

    final_std_summary4['COST%']=pd.np.round(final_std_summary4['COST_ADHOCMTD']*100.0/final_std_summary4['COST_STDMTD'],1)


    # In[220]:

    final_std_summary4=final_std_summary4.replace([np.inf,-np.inf],np.nan).fillna(0)


    # In[221]:

    final_std_summary5=final_std_summary4[final_std_summary4['COST_STDMTD']>0.0]


    # In[222]:

    final_std_summary6=final_std_summary5.sort_values('COST_ADHOCMTD',ascending=False)
    final_std_summary6['COST_ADHOCMTD']=pd.np.round(final_std_summary6['COST_ADHOCMTD'],0)
    final_std_summary6['COST_ADHOCYST']=pd.np.round(final_std_summary6['COST_ADHOCYST'],0)
    final_std_summary6['COST_STDMTD']=pd.np.round(final_std_summary6['COST_STDMTD'],0)
    final_std_summary6['COST_STDYST']=pd.np.round(final_std_summary6['COST_STDYST'],0)

    # In[223]:

    final_std_summary6




    # In[16]:


    final_std_summary7=final_std_summary6[['DEPOT','BRANCH_CODE','CODE','COST_ADHOCMTD','Cons_ADHOCMTD',
                                         'COST_ADHOCYST','Cons_ADHOCYST','COST_STDMTD','Cons_STDMTD',
                                       'COST_STDYST','Cons_STDMTD','COST%']]


    # In[225]:
    df_adhoc=df_adhoc.replace([np.inf,-np.inf],np.nan).fillna(0)
    df_adhoc['PINCODE']=df_adhoc['PINCODE'].astype(int).astype(str)
    df_adhoc['CUSTOMERCODE']=df_adhoc['CUSTOMERCODE'].astype(int).astype(str)
    df_adhoc['CODE']=df_adhoc['PINCODE']+df_adhoc['CUSTOMERCODE']
    df_adhoc_excluding=df_adhoc[~df_adhoc['CODE'].isin(pincode_cstmcode_list)]
    len(df_adhoc_excluding)
    df_adhoc_excluding_pivot=df_adhoc_excluding.pivot_table(index=['DateOnly','DEPOT','BRANCH_CODE','MKT_PANNAME','BAVEHNO'],values=['ACT_WT','COST','con_id'],
                                                         aggfunc={'ACT_WT':sum,'COST':sum,'con_id':len})

    df_adhoc_excluding_pivot['COST']=pd.np.round(df_adhoc_excluding_pivot['COST'],0)


    # In[ ]:


    df_adhoc_excluding_pivot


    # In[17]:


    final_std_summary_pudname['Debit_AMt','YST']=(final_std_summary_pudname['CPK_ADHOC','YST']-final_std_summary_pudname['CPK_STD','YST'])*final_std_summary_pudname['ACT_WT_ADHOC','YST']


    # In[18]:


    final_std_summary_pudname['Debit_AMt','MTD']=(final_std_summary_pudname['CPK_ADHOC','MTD']-final_std_summary_pudname['CPK_STD','MTD'])*final_std_summary_pudname['ACT_WT_ADHOC','MTD']


    # In[19]:


    final_std_summary_pudname


    # In[20]:


    today1=datetime.strftime(datetime.now(),'%Y-%m-%d')
    today1




    # In[229]:

    ##Part3 summaries
    with ExcelWriter(r'D:\Data\BLRD_MAAD_Non_STD\Adhoc_Vehicle_STD_Routes.xlsx') as writer:
        final_std_summary1.to_excel(writer, sheet_name='STD_ADHOC_Summary',engine='xlsxwriter')
        final_std_summary_pudname.to_excel(writer, sheet_name='Pudname-Wise_Sumary',engine='xlsxwriter')



    with ExcelWriter(r'D:\Data\BLRD_MAAD_Non_STD\Adhoc_Vehicle_STD_Routes_'+today1+'.xlsx') as writer:
        final_std_summary1.to_excel(writer, sheet_name='STD_ADHOC_Summary',engine='xlsxwriter')
        final_std_summary_pudname.to_excel(writer, sheet_name='Pudname-Wise_Sumary',engine='xlsxwriter')


    # In[21]:


    df1.to_csv(r'D:\Data\BLRD_MAAD_Non_STD\ConWise_Data.csv')


    # In[22]:


    filepath1=r'D:\Data\BLRD_MAAD_Non_STD\ConWise_Data.csv'


    # In[23]:


    filepath=r'D:\Data\BLRD_MAAD_Non_STD\Adhoc_Vehicle_STD_Routes.xlsx'


    # In[24]:



    import numpy as np
    import pandas as pd
    import itertools
    import json
    from pandas import ExcelWriter
    from pandas import pivot_table
    from datetime import datetime
    import os
    import ftplib
    import traceback

    print ('Logging in...')
    ftp = ftplib.FTP()
    ftp.connect('10.109.230.50')
    print (ftp.getwelcome())
    try:
        try:
            ftp.login('IEPROJECTUSER', 'spotStar@123')
            ftp.cwd('ETA')
            # move to the desired upload directory
            print ("Currently in:", ftp.pwd())
            print ('Uploading...')
            fullname = filepath1
            name = os.path.split(fullname)[1]
            f = open(fullname, "rb")
            ftp.storbinary('STOR ' + name, f)
            f.close()
            print ("OK"  )
            print ("Files:")
            print (ftp.retrlines('LIST'))
        finally:
            print ("Quitting...")
            ftp.quit()
    except:
        traceback.print_exc()


    # In[25]:


    reportts = datetime.now()
    opfilevar=reportts.date()
    opfilevar1=reportts.time()
    ct2= str (opfilevar1)
    currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

    opfilevar2=pd.np.round((float(currhrs)/60),0)
    #<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/ConWise_Data_.xlsx"</a>http://spoton.co.in/downloads/IEProjects/ETA/ConWise_Data_.xlsx</p></b>

    #

    # In[233]:




    # In[234]:

    TO=['anto.paul@spoton.co.in','mahesh.reddy@spoton.co.in']
    # TO=['mahesh.reddy@spoton.co.in']
    CC=['mahesh.reddy@spoton.co.in']
    BCC=['mahesh.reddy@spoton.co.in']
    FROM="reports.ie@spoton.co.in"
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)

    msg["Subject"] = "BLRD&MAAD FIXED,ADHOC & MIXED -" + str(opfilevar)
    html3='''
    <p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/ConWise_Data.csv"</a>http://spoton.co.in/downloads/IEProjects/ETA/ConWise_Data.csv</p></b>

    '''
    report=""
    report+='Dear All,'

    report+='<br>'
    report+='<br>'
    report+='PFA BLRD and MAAD Mixed Data.'
    report+=html3

    abc=MIMEText(report,'html')
    msg.attach(abc)
    # msg.attach(abc)
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filepath,"rb").read() )
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
    msg.attach(part)




    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")
    failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
    server.quit()

except:
  TO=['mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  #msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "BLRD and MAAD NOn STD usage Report Error in Execution" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in BLRD and MAAD NOn STD usage Report.'
  report+='<br>'

  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO, msg.as_string())
  server.quit()


# In[ ]:


# exit(0)


# # In[ ]:


# len(df)


# # In[ ]:


# link_df=pd.read_csv(r'http://spoton.co.in/downloads/pmd/pmd.zip')
# len(link_df)


# # In[ ]:


# link_df['ACT_WT2'].sum()


# # In[ ]:


# df['ACT_WT'].sum()


# # In[ ]:


# df['COST'].sum()


# # In[ ]:


# link_df['COST2'].sum()


# # In[ ]:


# link_df.columns


# # In[ ]:


# link_df['DateOnly']=link_df.apply(lambda x: dateconv(x["DATE2"]),axis=1)


# # In[ ]:


# df.columns


# # In[ ]:


# df_pivot=df.pivot_table(index=['DateOnly'],aggfunc={'ACT_WT':sum,'COST':sum}).reset_index()


# # In[ ]:


# df_pivot


# # In[ ]:


# link_pivot=link_df.pivot_table(index=['DateOnly'],aggfunc={'ACT_WT2':sum,'COST2':sum}).reset_index()


# # In[ ]:


# link_pivot


# # In[ ]:


# df_pivot=pd.merge(df_pivot,link_pivot,on='DateOnly',how='outer')


# # In[ ]:


# df_pivot['WT_Df']=pd.np.round(df_pivot['ACT_WT']-df_pivot['ACT_WT2'],4)


# # In[ ]:


# df_pivot['COST_Df']=pd.np.round(df_pivot['COST']-df_pivot['COST2'],4)


# # In[ ]:


# df_pivot['CPK2']=pd.np.round(df_pivot['COST2']/df_pivot['ACT_WT2'],2)
# df_pivot['CPK']=pd.np.round(df_pivot['COST']/df_pivot['ACT_WT'],2)


# # In[ ]:


# df_yestsum = df_yest.groupby(['PUDTYPE']).agg({'ACT_WT':sum,'COST':sum}).reset_index()


# # In[ ]:


# df_yestsum


# # In[ ]:


# dfsum = pd.pi


# # In[ ]:


# df_pivot


# # In[ ]:


# df['PUDTYPE'].unique()


# # In[ ]:


# df_yest=df[df['DateOnly']=='2018-11-14']
# len(df_yest)


# # In[ ]:


# len(df_yest)


# # In[ ]:


# df_yest.to_csv(r'Yester_PMD_DATA_Procedur.csv')


# # In[ ]:


# dd=df_yest.pivot_table(index=['PUDTYPE'],values=['COST','ACT_WT'],aggfunc={'COST':sum,'ACT_WT':sum},margins=True)


# # In[ ]:


# dd['COST']/dd['ACT_WT']


# # In[ ]:


# dd=df.pivot_table(index=['PUDTYPE'],values=['COST','ACT_WT'],aggfunc={'COST':sum,'ACT_WT':sum},margins=True)


# # In[ ]:


# dd['COST']/dd['ACT_WT']


# # In[ ]:


# 3190824.36/2939437.3


# # In[ ]:


# cnxn1 = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor1 = cnxn1.cursor()



# # In[ ]:


# query=("""EXEC USP_PUD_YEST_MTD_DATA 'M' """)
# df_new_conn=pd.read_sql(query,cnxn1)


# # In[ ]:


# len(df_new_conn)


# # In[ ]:


# df[df['con_id']=='517565881']['ACT_WT']

