
# coding: utf-8

# In[25]:

import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
import calendar
import datetime
from pandas import ExcelWriter
from nltk import *
import glob
import gzip
import traceback
import ftplib
from datetime import datetime
import os
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from pandas import ExcelWriter
from email import encoders
# -- coding: utf-8 --

####### For saving the Closing Stock for each day

ocidclosingstockbase = pd.io.excel.read_excel('http://10.109.230.50/downloads/CLOSESTOCKFREECONS/CS_FREECON.xls','CLOSING STOCK')
datenow = date.today()
dateyest = datenow-timedelta(hours=24)
date15days = dateyest - timedelta(days=15)
print date15days
ocidclosingstockbase.loc[ocidclosingstockbase.index,'Timestamp'] = dateyest
ocidclosingstockbase.to_csv(r'D:\\Data\\eta_rank\Destination_sc_closingstock\\Closing_Stock_'+str(dateyest)+'.csv',encoding='utf-8')


# In[ ]:

# path =r'D:\Data\eta_rank\Destination_sc_closingstock' # use your path
# allFiles = glob.glob(path + "/*.csv")
# frame = pd.DataFrame()
# list_ = []
# for i in range(1,16):
#     date1=datetime.strftime((datetime.now()-timedelta(days=i)),'%Y-%m-%d')
#     file=r'D:\Data\eta_rank\Destination_sc_closingstock\Closing_Stock_'+str(date1)+'.csv'
#     try:
#         df = pd.read_csv(file,index_col=None, header=0)
#     except:
#         print ('file not found',file)
#     list_.append(df)
# frame = pd.concat(list_)
# frame.to_csv(r'D:\Data\eta_rank\Combined_closing_stock.csv')
# print len(frame)
ignorelist = ['Internal','NCF']

path =r'D:\Data\eta_rank\Destination_sc_closingstock' # use your path
allFiles = glob.glob(path + "/*.csv")
frame = pd.DataFrame()
list_ = []
for i in range(1,16):
    date1=datetime.strftime((datetime.now()-timedelta(days=i)),'%Y-%m-%d')
    file=r'D:\Data\eta_rank\Destination_sc_closingstock\Closing_Stock_'+str(date1)+'.csv'
    print (file)
    df = pd.read_csv(file,index_col=None, header=0)
    print (df['DOCKNO'].dtype)
    # df['DOCKNO']=df['DOCKNO'].astype(int)
    list_.append(df)
frame = pd.concat(list_)
frame.to_csv(r'D:\Data\eta_rank\Combined_closing_stock.csv')
print len(frame)

historicdf = frame.copy()
historicdf = historicdf[(historicdf['ACTUWT']!='NO')]
historicdf = historicdf[~(historicdf['ACTUWT'].isnull())]

print len(historicdf)

print (historicdf['DOCKNO'].dtype)

historicdf['DOCKNO']=historicdf['DOCKNO'].astype(int)

# exit(0)

# <b> Creating code validity lists </b>

# In[27]:

"""
ippath1 = r'D:\Data\eta_rank\OCIDtill15th.xls'
x1 = pd.ExcelFile(ippath1)
closingstock = x1.parse("CLOSING STOCK")
"""

closingstock = pd.io.excel.read_excel('http://10.109.230.50/downloads/CLOSESTOCKFREECONS/CS_FREECON.xls','CLOSING STOCK')

# print len(closingstock)

"""
ippath2 = r'D:\Python\Scripts and Files\Path and Graph Files\StatusCodes1.xlsx'
x2 = pd.ExcelFile(ippath2)
statusdf = x2.parse("Data")
transitionbasedf = x2.parse("Transition")
"""

statusdf = pd.io.excel.read_excel('D:\Python\Scripts and Files\Path and Graph Files\StatusCodes1.xlsx','Data')
transitionbasedf = pd.io.excel.read_excel('D:\Python\Scripts and Files\Path and Graph Files\StatusCodes1.xlsx','Transition')

#historicdf = pd.read_csv(r'D:\Data\eta_rank\Combined_closing_stock.csv')
####$$$$$historicdf = pd.read_csv(r'D:\Data\eta_rank\Combinedop_closing_oct26_nov15.csv')


### Historic df too much data. So taking 20 days data from yesterday. Modified on 04-10-2016
# historicdf = pd.read_csv(r'D:\Data\eta_rank\Combined_closing_stock.csv')

# historicdf['Dockcheck'] = historicdf.apply(lambda x: True if len(['DOCKNO'])==9 else False ,axis=1)

# historicdf['Dockcheck'] = historicdf[historicdf['Dockcheck']==True]

# print (len(historicdf))
# exit(0)

historicdf=historicdf.fillna(0)
historicdf=historicdf[~historicdf['Timestamp'].isnull()]
def dateconvert(timestamp):
    
    if timestamp==0:
        return timestamp
    else:
        try:
            dates = datetime.strptime(timestamp,'%Y-%m-%d')
        except:
            dates = datetime.strptime(timestamp,'%d-%m-%Y')
        return dates

historicdf['Timestamp'] = historicdf.apply(lambda x:dateconvert(x['Timestamp']),axis=1)

print len(historicdf)
print historicdf['Timestamp'].unique()

# historicdf = historicdf[historicdf['Timestamp']>=date15days]
print len(historicdf)
print historicdf['Timestamp'].unique()
### Historic df too much data. So taking 20 days data from yesterday. Modified on 04-10-2016

timeboundlist = statusdf[statusdf["Status Behavioral Category"]=='Time Bound']["OPCODE"].tolist()
codevaliditylist = statusdf[statusdf["Status Behavioral Category"]=='Code Validity']["OPCODE"].tolist()


# <b> Function to check for Timebound and Code Validity </b>

# In[28]:

checktime=datetime.now()
todaydate = date.today()
yestday = todaydate - timedelta(hours=24)
print yestday
checkday = checktime.strftime("%a")


# In[29]:

def validitycheck(x, y, z):
    #for sunday 24 to 48
    if checkday == 'Mon':
        atvtime = 48
        xtratimelimit = 24
    else:
        atvtime = 24
        xtratimelimit = 0
    if x in timeboundlist and y>atvtime:
        return 'Arrival Timebound Violation'
    elif x in codevaliditylist:
        timelimit = statusdf[statusdf["OPCODE"]==x]["Validity Hours"].values[0]
        #for sunday
        timelimit = timelimit + xtratimelimit
        if z > timelimit:
            return 'Code Validity Violation' 
        else:
            return 'NA'
    else:
        return 'NA'
        


# In[30]:

#transchecklist = closingstock[closingstock['Validity_Status']=='NA']['DOCKNO'].tolist()
#transhistoricdf=historicdf[historicdf['DOCKNO'].isin(transchecklist)]
#len (transhistoricdf)
closingstock.loc[closingstock.index,'Validity_Status']='NA'
closingstock.loc[closingstock.index,'FreeCon_Status']='NA'
historicdf['Con Status Code1'] = historicdf['Con Status Code'].apply(lambda x: x)
grp = historicdf.pivot_table(index = ['DOCKNO'], values=["Con Status Code",'Con Status Code1'], aggfunc = {"Con Status Code1": lambda x: list(x),"Con Status Code":lambda x: list(x)}).reset_index()


# In[31]:

def getlist (x):
    a = [i for i in x if i[0]!=i[1]]
    return a


# <b> To check Transition Validation </b>

# In[32]:

def transvalidity(x, y):
    #print y, x, type(x)
    #if len(x.iloc[0])==0:
    if len(x)==0:
        return 'NA'
    #lastfirst = x.iloc[0][-1][0]
    #lastsecond = x.iloc[0][-1][1]
    lastfirst = x[-1][0]
    lastsecond = x[-1][1]
    #print lastfirst, lastsecond
    fromlist_toany = transitionbasedf[transitionbasedf['To CODE']=='ANY']['From CODE'].tolist()
    tolist_fromany = transitionbasedf[transitionbasedf['From CODE']=='ANY']['To CODE'].tolist()
    #if np.isnan(lastsecond):
    ##$$if pd.isnull(lastsecond):
        ##$$return 'Transition Violation'
    if lastfirst in fromlist_toany:
        return 'Transition Violation'
    elif lastsecond in tolist_fromany:
        return 'Transition Violation'
    else:
        individualtolist = transitionbasedf[transitionbasedf['From CODE']==lastfirst]['To CODE'].tolist()
        if lastsecond in individualtolist:
            return 'Transition Violation'
        else:
            return 'NA'
        


# In[33]:

grp['ngrams'] = grp['Con Status Code1'].apply(lambda x: list(bigrams(x)))
grp['ngramschange'] = grp['ngrams'].apply(lambda x: (getlist(x)))
#abc = grp[grp['DOCKNO']==502277156]
#efg = abc['ngramschange']
#print type(efg)
##$$grp.to_csv(r'C:\Data\Dest_Statuscode\v\grp.csv', encoding='utf-8')
##$$grp.head()


# In[34]:

grp['Trans_Validity'] = grp.apply(lambda x: transvalidity(x['ngramschange'], x['DOCKNO']),axis = 1)
grpconlist = grp[grp['Trans_Validity']=='Transition Violation']['DOCKNO'].tolist()
print len(grpconlist)
#grp.head()


# In[35]:

def codevalidity(x, y, z):
    if len(x)==0 and len(y)!=0:
        #print y
        #print y[-1][0]
        statuswochange = y[-1][0]
        if statuswochange in codevaliditylist:
            timelimit = statusdf[statusdf["OPCODE"]==statuswochange]["Validity Hours"].values[0]
            #for sunday
            if checkday == 'Mon':
                xtratimelimit = 24
            else:
                xtratimelimit = 0
            timelimit = timelimit + xtratimelimit
            abc = historicdf[(historicdf['DOCKNO']==z) & (historicdf['Con Status Code']==statuswochange)]['Con Status Date'].values[0]
            try:
                historicconstatustime = datetime.strptime(abc, '%Y-%m-%d %H:%M:%S')
                bdc=datetime.now()
                #for sunday
                bdc=bdc-timedelta(hours=0.5)
                #print historicconstatustime, type(historicconstatustime), bdc, type(bdc)
                diff = bdc-historicconstatustime
                statusduration = (diff.total_seconds())*1.0/3600
                if statusduration > timelimit:
                    return '2Code Validity'
            except:
                pass
            


# In[36]:

grp['Code_Validity'] = grp.apply(lambda x: codevalidity(x['ngramschange'], x['ngrams'], x['DOCKNO']),axis = 1)


# In[37]:
print (grp['DOCKNO'].dtype)
print (closingstock['DOCKNO'].dtype)

# exit(0)

closingstock = closingstock.merge(grp[['DOCKNO', 'Trans_Validity', 'Code_Validity']], on=['DOCKNO'], how='left')
print len(closingstock)

iz = closingstock[closingstock['Trans_Validity']=='Transition Violation'].index
closingstock.loc[iz,'Validity_Status'] = 'Transition Violation'

iy = closingstock[closingstock['Code_Validity']=='2Code Validity'].index
closingstock.loc[iy,'Validity_Status'] = 'Code Validity Violation'


# In[38]:

closingstock.loc[closingstock.index,'ATB_CV1_Status']='NA'
closingstock['ATB_CV1_Status'] = closingstock.apply(lambda x: validitycheck(x['Con Status Code'], x['REPORTDATE MIN ARRVDT'], x['Report Gen Con Status Date']),axis = 1)
#neither trnasition under validity status (ignore 2Code Validity in here as tb should overwrite this)and those tb and cv under ATB_CV1_Status
ip = closingstock[(closingstock['Validity_Status']!='Transition Violation') & (closingstock['ATB_CV1_Status']=='Arrival Timebound Violation')].index
closingstock.loc[ip,'Validity_Status'] = 'Arrival Timebound Violation'

iq = closingstock[(closingstock['Validity_Status']=='NA') & (closingstock['ATB_CV1_Status']=='Code Validity Violation')].index
closingstock.loc[iq,'Validity_Status'] = 'Code Validity Violation'


# In[39]:

def lastchange(x):
    if len(x)==0:
        return 'NA1'
    else:
        lastshift = x[-1]
        return lastshift


# In[43]:

ccfsrlist = ['SENDER FAILURE', 'RECEIVER FAILURE']
spotonlist = ['DESTINATION FAILURE', 'ORIGIN FAILURE','LINEHAUL FAILURE','HUB FAILURE']
blanklist = ['DESTINATION FAILURE', 'ORIGIN FAILURE','LINEHAUL FAILURE','HUB FAILURE','NON CONTROLLABLE FAILURE','DEPS','SENDER FAILURE', 'RECEIVER FAILURE']
def otherstatus(x,y,z):
    if x != 'NA':
        if x == 'Arrival Timebound Violation':
            return 'Arrival Timebound Violation'
        elif x == 'Code Validity Violation':
            return 'Code Validity Violation'
        elif x == 'Transition Violation':
            return 'Transition Violation'
        else:
            return 'check for violation'
    else:
        if y in ccfsrlist and z == 'Yes':
            return 'CCF with TTS'
        elif y in ccfsrlist and z == 'No':
            return 'CCF without TTS'
        elif y in spotonlist:
            return 'Spoton'
        elif y == 'DEPS':
            return 'DEPS'
        elif y == 'NON CONTROLLABLE FAILURE':
            return 'NCF'
        elif y not in blanklist:
            return 'blanks'
        else:
            return 'check'
        
        


# In[44]:

closingstock['Final_Validity_Status'] = closingstock.apply(lambda x: otherstatus(x['Validity_Status'],x['Con Status Category'], x['TTSTicket Raised']),axis = 1)


# In[45]:

#####DRS Exclusions
ia = closingstock[closingstock['DRS Blocked Due to Payment Issues']=='YES'].index
closingstock.loc[ia,'Final_Validity_Status'] = 'DRS_blocked'

ib = closingstock[closingstock['DRS Blocked due to ODA Pincode Change']=='YES'].index
closingstock.loc[ib,'Final_Validity_Status'] = 'DRS_blocked'

ic = closingstock[closingstock['DRS Blocked due to Demurrage']=='YES'].index
closingstock.loc[ic,'Final_Validity_Status'] = 'DRS_blocked'

#####DRS Exclusions


# In[46]:

surelist = ['Transition Violation', 'Arrival Timebound Violation', 'blanks']
freeconcheckcategorylist = ['Code Validity Violation', 'Spoton', 'NCF','CCF without TTS','DEPS']
ttsauditlist = ['OK','Not OK','Undecided']
freestatuscodelist = statusdf[statusdf["Is Free"]=='Yes']["OPCODE"].tolist()

def freeconcheck(x, y, z, a):
    if x in surelist:
        return 'Free Con'
    elif x=='CCF without TTS' and a in ttsauditlist:
        return 'Free Con'
    elif x in freeconcheckcategorylist:
        #below 'if statement' to handle CV with common status over days but updated everyday
        if y in freestatuscodelist:
            if x=='Code Validity Violation':
                return 'Free Con'
            else:
                timelimit = statusdf[statusdf["OPCODE"]==y]["Freeconvalidityhrs"].values[0]
                if z > timelimit:
                    return 'Free Con' 
                else:
                    return 'Under Timelimit'
        else:
            return 'Code not in free'
    
    else:
        return 'Validity Status safe'


# In[47]:

closingstock['Con_Category'] = closingstock.apply(lambda x: freeconcheck(x['Final_Validity_Status'],x['Con Status Code'],x['Report Gen Con Status Date'],x['TTS Audit Status']),axis = 1)
closingstock = closingstock.drop(['Validity_Status', 'FreeCon_Status', 'Trans_Validity', 'Code_Validity', 'ATB_CV1_Status'], axis=1)

##$$$ For Sakthi Extra column

extlist = ['Code not in free','Under Timelimit','Validity Status safe']
def freecon(x):
    if x in extlist:
        return 'Others'
    else:
        return 'Free Con'

closingstock['Category_Freecon'] = closingstock.apply(lambda x: freecon(x['Con_Category']),axis = 1)
ic = closingstock[closingstock['Con Status Code']=='CFD'].index
closingstock.loc[ic,'Category_Freecon'] = 'Free Con'

##$$$ For Sakthi Extra column

closingstock.to_csv(r'D:\Data\eta_rank\DestSC_ClosingStock.csv', encoding='utf-8')
closingstock.to_csv(r'D:\Data\eta_rank\DestinationSC_StatusvalidationArchives\DestSC_ClosingStock_CodeValidation_'+str(yestday)+'.csv', encoding='utf-8')


# Open source file.
###$$$ For Ziping the file and sending to Shivanand

with open("D:\\Data\\eta_rank\\DestSC_ClosingStock.csv", "rb") as file_in:
    # Open output file.
    with gzip.open("D:\\Data\\eta_rank\\DestSC_ClosingStock.csv.gz", "wb") as file_out:
        # Write output.
        file_out.writelines(file_in)

oppath1 = r"D:\\Data\\eta_rank\\DestSC_ClosingStock.csv.gz"


####### FTP For giving back Free cons status for Main OCID 

closingstockfree = closingstock
columnsop=['DOCKNO','Category_Freecon']
closingstockftp=pd.DataFrame(closingstockfree,columns=columnsop)
closingstockftp.to_csv(r'D:\Data\eta_rank\DestSC_freecon.csv', encoding='utf-8')

oppath2 = r'D:\Data\eta_rank\DestSC_freecon.csv'


print ('Logging in...')
ftp = ftplib.FTP()
#ftp.connect('119.226.230.94')
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('CS_FREECONS')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppath2
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()

#FTP Upload ends


####### FTP For giving back Free cons status for Main OCID 



###$$$ For Ziping the file and sending to Shivanand
# In[ ]:
filePath = oppath1
def sendEmail(#TO = ["vijay.adhale@spoton.co.in"],
            #TO = ["rajeesh.vr@spoton.co.in"],
            TO = ["mahesh.reddy@spoton.co.in"],
            CC = ["mahesh.reddy@spoton.co.in"],
            #CC = ["shivananda.p@spoton.co.in","rajeesh.vr@spoton.co.in","vishwas.j@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "Free Con Report"+ " - " + str(yestday)
    msg["Subject"] = "Free Con Report"+ " - " + str(yestday)
    body_text = """
    Dear Vijay,
    
    PFA a report on Free Cons as of """+str(yestday)+""" 
    
    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')


