
# coding: utf-8

# In[ ]:


#from Networkmeeting_Reach import lhplanning
import numpy as np
import pandas as pd
import pyodbc
from IPython import display
from datetime import datetime
from datetime import datetime,timedelta
from datetime import datetime, timedelta
import smtplib
import ftplib
import traceback
import calendar
import os
import Utilities

# In[ ]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


# In[ ]:


query=("""USP_STOCK_ALL_SQ""")


# In[ ]:


df=pd.read_sql(query,Utilities.cnxn)


# In[ ]:

df.to_csv(r'C:\Users\rajeeshv\Downloads\Undel.csv')
print (len(df))


# In[ ]:


df.head()


# In[ ]:


df1=df


# In[ ]:


df1.columns


# In[ ]:


df1['CurLocConStatusCode'].unique()


# In[ ]:

df1=df1[df1['HUBCENTER']=='N']
df1=df1[~df1['CurLocConStatusCode'].isin(['ADC','APT','APN'])]

# In[ ]:
# print (df1[['DAYS_BUCKET','DAYS_BUCKET1']])

all_cust_summary=df1.pivot_table(index=['CURR_AREA'],columns=['DAYS_BUCKET'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').fillna(0)

all_cust_summary1=pd.DataFrame()
for i in ['<=7DAYS','7-15 DAYS','15-30 DAYS','30-45 DAYS','>45DAYS','Total' ]:
    try:
        all_cust_summary1[i]=all_cust_summary[('DOCKNO',i)].astype(int)
    except:
        all_cust_summary1[i]=0.0


# In[ ]:


special_df=df1[df1['CUSTOMER_TYPE']=='SPECIAL_CUSTOMER']
len(special_df)


# In[ ]:


special_cust_summary=special_df.pivot_table(index=['CURR_AREA'],columns=['DAYS_BUCKET'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').fillna(0)

special_cust_summary1=pd.DataFrame()
for i in ['<=7DAYS','7-15 DAYS','15-30 DAYS','30-45 DAYS','>45DAYS','Total' ]:
    try:
        special_cust_summary1[i]=special_cust_summary[('DOCKNO',i)].astype(int)
    except:
        special_cust_summary1[i]=0.0




# In[ ]:


other_df=df1[df1['CUSTOMER_TYPE']=='OTHER_CUSTOMER']
len(other_df)


# In[ ]:


other_cust_summary=other_df.pivot_table(index=['CURR_AREA'],columns=['DAYS_BUCKET'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').fillna(0)


other_cust_summary1=pd.DataFrame()
for i in ['<=7DAYS','7-15 DAYS','15-30 DAYS','30-45 DAYS','>45DAYS','Total' ]:
    try:
        other_cust_summary1[i]=other_cust_summary[('DOCKNO',i)].astype(int)
    except:
        other_cust_summary1[i]=0.0




todate=datetime.strftime(datetime.now(),'%Y-%m-%d')
todate


# In[ ]:


# from pandas import ExcelWriter
# with ExcelWriter(r'D:\Data\Undel_Managment\Undel_Management_'+str(todate)+'.xlsx') as writer:
#     df1.to_excel(writer,engine='xlsxwriter',sheet_name='Data')
#     all_cust_summary1.to_excel(writer,engine='xlsxwriter',sheet_name='Over_All_Summary')
#     special_cust_summary1.to_excel(writer,engine='xlsxwriter',sheet_name='Special_Cust_summary')
#     other_cust_summary1.to_excel(writer,engine='xlsxwriter',sheet_name='Other_cust_summary')


# In[ ]:
df1.to_csv(r'D:\Data\Undel_Managment\Undel_Management_Data_SC'+str(todate)+'.csv')
all_cust_summary1.to_csv(r'D:\Data\Undel_Managment\Over_All_Summary_SC'+str(todate)+'.csv')
special_cust_summary1.to_csv(r'D:\Data\Undel_Managment\Special_Cust_Summary_SC'+str(todate)+'.csv')
other_cust_summary1.to_csv(r'D:\Data\Undel_Managment\Other_Cust_Summary_SC'+str(todate)+'.csv')


df1.to_csv(r'D:\Data\Undel_Managment\Undel_Management_Data_SC.csv')
all_cust_summary1.to_csv(r'D:\Data\Undel_Managment\Over_All_Summary_SC.csv')
special_cust_summary1.to_csv(r'D:\Data\Undel_Managment\Special_Cust_Summary_SC.csv')
other_cust_summary1.to_csv(r'D:\Data\Undel_Managment\Other_Cust_Summary_SC.csv')



# from pandas import ExcelWriter
# with ExcelWriter(r'D:\Data\Undel_Managment\Undel_Management.xlsx') as writer:
#     df1.to_excel(writer,engine='xlsxwriter',sheet_name='Data')
#     all_cust_summary1.to_excel(writer,engine='xlsxwriter',sheet_name='Over_All_Summary')
#     special_cust_summary1.to_excel(writer,engine='xlsxwriter',sheet_name='Special_Cust_summary')
#     other_cust_summary1.to_excel(writer,engine='xlsxwriter',sheet_name='Other_cust_summary')


# In[ ]:


filepath=r'D:\Data\Undel_Managment\Undel_Management_Data_SC.csv'
filepath1=r'D:\Data\Undel_Managment\Over_All_Summary_SC.csv'
filepath2=r'D:\Data\Undel_Managment\Special_Cust_Summary_SC.csv'
filepath3=r'D:\Data\Undel_Managment\Other_Cust_Summary_SC.csv'


# In[ ]:


import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback
for i in [filepath,filepath1,filepath2,filepath3]:
    oppath1=i
    #FTP Upload starts
    print ('Logging in...')
    ftp = ftplib.FTP()  
    ftp.connect('10.109.230.50')  
    print (ftp.getwelcome())
    try:  
        try:  
            ftp.login('HOSQTeam', 'Te@mH0$q')
            print ('login done')
            ftp.cwd('Auto_reports')  
            #ftp.cwd('FIFO')
            # move to the desired upload directory  
            print ("Currently in:", ftp.pwd()) 
            print ('Uploading...')  
            fullname = oppath1
            name = os.path.split(fullname)[1]  
            f = open(fullname, "rb")  
            ftp.storbinary('STOR ' + name, f)  
            f.close()  
            print ("OK"  )
            print ("Files:")  
            print (ftp.retrlines('LIST'))
        finally:  
            print ("Quitting...")
            ftp.quit()  
    except:  
        traceback.print_exc()


# In[ ]:


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

# TO=['mahesh.reddy@spoton.co.in']
TO=['aom_spot@spoton.co.in','dom_spot@spoton.co.in','rom_spot@spoton.co.in','scincharge_spot@spoton.co.in','sq_spot@spoton.co.in','spot_cstl@spoton.co.in']
FROM="mis.ho@spoton.co.in"
CC=['abhik.mitra@spoton.co.in','jothi.menon@spoton.co.in','rajesh.kumar@spoton.co.in','pawan.sharma@spoton.co.in','sharmistha.majumdar@spoton.co.in','anitha.thyagarajan@spoton.co.in','shivananda.p@spoton.co.in','mahesh.reddy@spoton.co.in']
# CC=['mahesh.reddy@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
msg["Subject"] = "Undel Managment for - SC " + " : " + todate
html='''<html>
<style>
p
{
  margin:0;
  margin-top: 5px;
  padding:0;
  font-size:17px;
    line-height:20px;
}
</style>
<h3>Dear All,</h3>
<p>Please Find POD's Summary.</p>
</html>'''


s = Template(html).safe_substitute()
report=""
#report+=s
#report+='<br>'+final_dff5.to_html()+'<br>'
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='Please Find attached Undel Managment Summary for SC :'
report+='<br>'
report+='<br>'
report+='NOTE : The below data is excluding Appointment Cons'
report+='<br>'
report+='Over All Summary : '
report+='<br>'
report+='<br>'+all_cust_summary1.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='Special Customer Summary : '
report+='<br>'
report+='<br>'+special_cust_summary1.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='Other Customer Summary : '
report+='<br>'
report+='<br>'+other_cust_summary1.to_html()+'<br>'
report+='<br>'
report+='<br>'

html5='''
<h5> To download the data , Please click the link below </h5>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Undel_Management_Data_SC.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Undel_Management_Data_SC.csv</p></b>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Over_All_Summary_SC.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Over_All_Summary_SC.csv</p></b>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Special_Cust_Summary_SC.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Special_Cust_Summary_SC.csv</p></b>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Other_Cust_Summary_SC.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Other_Cust_Summary_SC.csv</p></b>

    '''
report+=html5
abc=MIMEText(report,'html')
msg.attach(abc)
# part = MIMEBase('application', "octet-stream")
# part.set_payload( open(filePath,"rb").read() )
# encoders.encode_base64(part)
# part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
# msg.attach(part)
# part1 = MIMEBase('application', "octet-stream")
# part1.set_payload( open(filePath1,"rb").read() )
# encoders.encode_base64(part1)
# part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath1))
# msg.attach(part1)

server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()

