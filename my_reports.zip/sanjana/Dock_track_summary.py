
# coding: utf-8

# In[1]:

import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
from datetime import datetime, timedelta
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template
from pandas import np
import Utilities
# from sqlalchemy import create_engine, MetaData, Table, select
# import pyodbc


# In[2]:

#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
#cursor = cnxn.cursor()


# In[2]:

# In[ ]:

dockquery = ("""
        SELECT * FROM dbo.dkt_track_extra WITH (NOLOCK)
        WHERE Entry_date >='2018-02-25 00:00:00'
        
        """)
dock_trackdf = pd.read_sql(dockquery, Utilities.cnxn)


# In[3]:

dock_trackdf=dock_trackdf[dock_trackdf['record_status']=='Y']


# In[4]:

dock_trackdf=dock_trackdf[dock_trackdf['draft_yn']=='Y']


# In[5]:

dock_trackdf['DATE']=dock_trackdf['Entry_date'].dt.date


# In[6]:

# summarydf=dock_trackdf.drop_duplicates(['dockno'])
summarydf=dock_trackdf.copy()


# In[7]:

summarypivot=summarydf.pivot_table(index='DATE',aggfunc={'dockno':len}).reset_index()


# In[8]:

summarypivot.rename_axis({'dockno':'Con Number'},axis=1,inplace=True)


# In[9]:

len(summarydf)


# In[10]:

summarypivot


# In[11]:
#cnxn1 = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.87;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
#cursor1 = cnxn1.cursor()

htrquery = ("""EXEC USP_HUB_THROUGHPUT_DETAILS_SALES_ONEHOUR""")
print (htrquery)
invdf = pd.read_sql(htrquery, Utilities.cnxn)
invdf.rename(columns={'Hub/SC Location':"Hub SC Location",'Arrival Date @ Hub':"Arrival Date Hub",'DestnBranch':"Destn Branch",'Act.WtInTonnes':"Act Wt In Tonnes",'LatestStatusCode':"Latest Status Code",'OriginArea':"Origin Area",'DestnArea':'Destn Area'},inplace=True)
#intransitdf=pd.read_excel(r'http://spoton.co.in/downloads/TCR_UND_2HRS/TCR_UND_ISDEPART_YES_2HRS.xls')
#invdf=pd.read_excel(r'http://spoton.co.in/downloads/HTR_1HR/HTR_1HR.xls')
stockquery1 = ("""SELECT     *
 
 
  FROM tblTimeConnectionReport_Undelivered_2HRS   
    WHERE ISDEPARTED_FRM_CURRLOC='YES'""")
print (stockquery1)

intransitdf=pd.read_sql(stockquery1,Utilities.cnxn)

intransitdf.rename(columns={'CDELDT':'DUE DATE','ORIGIN_BRCODE':'ORIGIN BRCODE','CURR_BRANCHCODE':'CURR BRANCHCODE','ISDEPARTED_FRM_CURRLOC':'IS DEPARTED FRM CURRLOC','DEPARTURE_TIME_FRM_CURLOC':'DEPARTURE TIME FRM CURLOC','DEPARTURE_TO_LOC_FRM_CURLOC':'DEPARTURE TO LOC FRM CURLOC','DEPARTED_FRM_CURRLOC_THCNO':'DEPARTED FRM CURRLOC THCNO','DEPARTED_FRM_CURRLOC_ROUTECD':'DEPARTED FRM CURRLOC ROUTECD','DEPARTED_FRM_CURRLOC_VEHNO':'DEPARTED FRM CURRLOC VEHNO','DOCKDT':'PICKUP DATE','LatestConStatusCode':'Latest Con Status Code','TCNO_FROM_HUB':'TCNO FROM HUB','THC_VENDOR_TYPE':'THC VENDOR TYPE','THC_SOURC':'THC SOURC','THC_DEST':'THC DEST','THC_ETA':'THC ETA','THC_ARRI_ENTRY':'THC ARRI ENTRY','THC_LAST_UPDATE_HR':'THC LAST UPDATE HR','THC_ROUTE_NAME':'THC ROUTE NAME','THC_LAST_TIME':'THC LAST TIME','ApptmntDelDate':'Apptmnt Del Date','TIME_STAMP':'TIMESTAMP'},inplace=True)
# In[12]:

mergedf = pd.merge(invdf,intransitdf,left_on=['Con Number'], right_on=['DOCKNO'], how='inner')


# In[13]:

dock_trackdf['dockno']=dock_trackdf['dockno'].astype(int)


# In[14]:

mergedf=mergedf.rename_axis({'Con Number':'dockno','Hub SC Location':'doc_curloc'},axis=1)


# In[15]:

df=pd.merge(dock_trackdf,mergedf,on=['dockno','doc_curloc'],how='inner')


# In[18]:

df=df.drop_duplicates(['dockno','doc_curloc'])


# In[19]:

len(df)


# In[ ]:

# df.to_csv('dfff.csv')


# In[20]:

reportts = datetime.now()
opfilevar=reportts.date()
opfilevar1=reportts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=np.round((float(currhrs)/60),0)


# In[22]:

# TO=["hubmgr_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in"]
TO=['abhik.mitra@spoton.co.in','shivananda.p@spoton.co.in','rajesh.kumar@spoton.co.in','rajesh.kapase@spoton.co.in']
FROM='reports.ie@spoton.co.in'
# CC=['sqtf@spoton.co.in','rajesh.kapase@spoton.co.in','Manjunath.Swamy@Spoton.Co.In','mahesh.reddy@spoton.co.in','shashvat.suhane@spoton.co.in','supratim@iepfunds.com','ankit@iepfunds.com','vishwas.j@spoton.co.in']
CC=['shashvat.suhane@spoton.co.in','mahesh.reddy@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["Subject"] = "DOC_Track_Extra_Summary " + str(opfilevar)+"-"+str(opfilevar2)
html='''<html>
<h4>Dear All,</h4>
<p>The no of cons in stock as well as intransit -'''+str(len(mergedf))+'''</p>
<p>The no of cons matching stock+intransit and doc_track_extra table (Based on a con's current location) -'''+str(len(df))+'''
<p>PFB the datewise summary of the number of cons getting inserted to DOC_TRACK_EXTRA table</p>'''+summarypivot.to_html()+'''
</html>'''
abc=MIMEText(html,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
# part.set_payload( open(filepath,"rb").read() )
# encoders.encode_base64(part)
# part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
# msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()


# In[ ]:



