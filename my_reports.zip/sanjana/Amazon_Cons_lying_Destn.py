
# coding: utf-8

# In[74]:


import numpy as np
import pandas as pd
import pyodbc
from IPython import display
from datetime import datetime
from datetime import datetime,timedelta
from datetime import datetime, timedelta
import smtplib
import ftplib
import traceback
import calendar
from fuzzywuzzy import fuzz,process
from fuzzywuzzy import fuzz
import os
import Utilities


# In[18]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=SQTeam;PWD=eSp0T@321$Sq")
# cursor = cnxn.cursor()


# In[19]:


query=("""USP_STOCK_ALL_SQ""")


# In[ ]:


df=pd.read_sql(query,Utilities.cnxn)


# In[39]:


dff3=df
dff3.columns


# In[40]:


# choices


# In[41]:


def fuzzyLogic(x):
    if (fuzz.partial_ratio('AMAZON'.lower(),x.lower()))>80:
#         v=fuzz.partial_ratio('Amazon'.lower(),x.lower())
        return "Amazon"
    elif (fuzz.partial_ratio('Cloudtail'.lower(),x.lower()))>80:
        return "CLOUDTAIL"
    else:
        return 0


# In[42]:


dff3['Test']=dff3.apply(lambda x:fuzzyLogic(x['CSGENM']),axis=1)
dff3


# In[77]:


off=['a','AM','A','ANIL','n','D','IBD AMAZING BUY','m',
     'SANTOSH HANAMAGOND','l','C']
off


# In[78]:


REMOVE= dff3[~dff3['Test'].isin(off)]
dff4=REMOVE[(REMOVE.Test== 'Amazon')|(REMOVE.Test== 'CLOUDTAIL') ]
dff4.columns


# In[79]:


table=pd.pivot_table(dff4,index=["CURR_AREA"], 
                  columns=["DAYS_BUCKET"], 
                  values= ['DOCKNO'],
                  aggfunc={'DOCKNO':len},margins= True, margins_name= 'Total Cons' ).fillna(0)
# df['DOCKNO']=df['DOCKNO'].astype(int)
table.head(1)


# In[80]:


other_summary1=pd.DataFrame()


# In[81]:


for i in ['<=7DAYS','7-15 DAYS','15-30 DAYS','30-45 DAYS','>45DAYS','Total Cons' ]:
    try:
        other_summary1[i]=table[('DOCKNO',i)].astype(int)
    except:
        other_summary1[i]=0.0


# In[82]:


other_summary1


# In[83]:


from pandas import ExcelWriter
with ExcelWriter(r'D:\Data\Amazon\Undel_cloudtail_Amazon.xlsx') as writer:
    other_summary1.to_excel(writer,engine='xlsxwriter',sheet_name='Summary')

dff4.to_csv(r'D:\Data\Amazon\Undel_cloudtail_Amazon_Data.csv')
    
    
   


# In[84]:



# matchdict={}
# choices = dff3['CSGENM'].tolist()
# knownlist=["Cloudtail","AMAZONE"]
# for i in knownlist:
#      for j in process.extract(i,choices,scorer=fuzz.partial_ratio():
#             print (choices)
#             print (j)
#             if j[1]>20:
#                  matchdict.update({j[0]:i})


# In[85]:


filepath=r"D:\Data\Amazon\Undel_cloudtail_Amazon.xlsx"
filepath1=r'D:\Data\Amazon\Undel_cloudtail_Amazon_Data.csv'
oppath1=filepath1
#FTP Upload starts
print ('Logging in...')
ftp = ftplib.FTP()  
ftp.connect('10.109.230.50')  
print (ftp.getwelcome())

try:
 try:
     ftp.login('HOSQTeam', 'Te@mH0$q')
     print ('login done')
     ftp.cwd('Auto_reports')
     #ftp.cwd('FIFO')
     # move to the desired upload directory
     print ("Currently in:", ftp.pwd())
     print ('Uploading...')
     fullname = oppath1
     name = os.path.split(fullname)[1]
     f = open(fullname, "rb")
     ftp.storbinary('STOR ' + name, f)
     f.close()
     print ("OK"  )
     print ("Files:")
     print (ftp.retrlines('LIST'))
 finally:
     print ("Quitting...")
     ftp.quit()
except:
    traceback.print_exc()
    
#date=datetime.strftime(datetime.now(),'%Y-%m-%d %H:%M:%S')


# In[91]:


from glob import glob
from IPython import display
from datetime import datetime,timedelta
import pyodbc

# date=datetime.strftime(datetime.now()-timedelta(2),'%Y-%m-%d-%H')
date=datetime.strftime(datetime.now(),'%Y-%m-%d-%H')
date

# ----------- E M A I L --------------------------    
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template                    

# TO=['mahesh.reddy@spoton.co.in']
# CC=['mahesh.reddy@spoton.co.in']

TO=['sharmistha.majumdar@spoton.co.in','reena.singhania@spoton.co.in','spot_cstl@spoton.co.in']
CC = ['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in']

FROM="mis.ho@spoton.co.in"
BCC = ['sanjana.narayana@spoton.co.in','mahesh.reddy@spoton.co.in']



msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = "Amazon Cons_lying @ Destn " + " - " + str(date)
html='''<html>
<style>        
p
 {
   margin:0;
   margin-top: 5px;
   padding:0;
   font-size:15px;
   line-height:20px;
 }
</style>                


'''
# html3='''
# <h5> To download File, Please click the link below </h5>
# <p><a href= http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/BA_TREND.xlsx </a>
# http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/BA_TREND.xlsx </p>
# '''
report=""
report+='<br>'
report+='Dear All,'
report+='<br>'
report+=' PFA, Stock report of Amazon/ Cloudtail Cons_lying @ Destn.'
report+='<br>'
report+='<br>'
report+='<br>'+other_summary1.to_html()+'<br>'
report+='<br>'
report+=html
# report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(filepath1,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
msg.attach(part1)

server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login('spoton.net.in', 'Star@123#')
failed = server.sendmail(FROM, CC+TO+BCC, msg.as_string())
print ('mail sent')
server.quit()



