
# coding: utf-8

# In[36]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta
import sys
import datetime
import sys
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
import Utilities

# In[37]:


# reload(sys)
# sys.setdefaultencoding("utf8")
querydate=date.today()
querydate


# In[38]:



# cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
query1=("""EXEC USP_UCG_GET_LETTERS_REPORT 'ALL','ALL','ALL','2018-01-01','{0}','3','ALL'  """.format(querydate))


# In[39]:


df=pd.read_sql(query1,Utilities.cnxn)
print (len(df))


# In[40]:


df1=df[df['FinalStatusDate']=='']
len(df1)
df1['Remarks']=''


# In[41]:


df1=df1[df1['FinalStatusDesc'].isin(['','DELIVERED'])]
len(df1)


# In[42]:


df2=df1[df1['ConsignorCourierName'].isin(['Registered Post', 'Speedpost'])]
len(df2)


# In[43]:


df3=df1[df1['ConsigneeCourierName'].isin(['Registered Post','Speedpost'])]
len(df3)


# In[44]:


df3['Remarks']='Sender & Receiver Register Post'
df1.loc[df3.index,'Remarks']=df3['Remarks']


# In[45]:


scan_df=df1[(df1['InvoiceScanFile_1']=='Y') & (df1['Remarks']=='')]
len(scan_df)


# In[46]:


scan_df['Remarks']='Invoice Uploaded'
df1.loc[scan_df.index,'Remarks']=scan_df['Remarks']


# In[47]:


peding_df=df1[df1['Remarks']=='']


# In[48]:


peding_df['Remarks']='Pending'
df1.loc[peding_df.index,'Remarks']=peding_df['Remarks']


# In[49]:


summary1=df1.pivot_table(index=['Depot','Remarks'],values=['ConNumber'],aggfunc={'ConNumber':len},margins=True)


# In[50]:


summary1


# In[51]:


ageing_dffff=df1[df1['Remarks'].isin(['Sender & Receiver Register Post'])]
len(ageing_dffff)


# In[52]:


len(ageing_dffff[ageing_dffff['ConsigneeCourierEntryDate']!='-'])


# In[53]:


ageing_dffff['Current Date']=datetime.datetime.now().date()


# In[54]:


ageing_dffff=ageing_dffff[ageing_dffff['ConsigneeCourierEntryDate']!='-']


# In[55]:


len(ageing_dffff)


# In[56]:


month_dict = {'Jan': '01','Feb': '02','Mar': '03','Apr':'04','May':'05','Jun':'06','Jul':'07','Aug':'08','Sep':'09','Oct':'10','Nov':'11','Dec':'12'}


# In[61]:


def getDate(x):
    if x=='-':
        return 0
    else:
        x1=x.split(' ')[2]+'-'+month_dict.get(x.split(' ')[1])+'-'+x.split(' ')[0]
        return x1


# In[63]:


ageing_dffff['ConsigneeEntryDate']=ageing_dffff.apply(lambda x:getDate(x['ConsigneeCourierEntryDate']),axis=1)


# In[64]:


ageing_dffff['ConsigneeEntryDate']=pd.to_datetime(ageing_dffff['ConsigneeEntryDate'])


# In[65]:


ageing_dffff['Current Date']=pd.to_datetime(ageing_dffff['Current Date'])


# In[66]:


ageing_dffff['Diff']=(ageing_dffff['Current Date']-ageing_dffff['ConsigneeEntryDate']).dt.days


# In[67]:


ageing_df=ageing_dffff[ageing_dffff['Diff']>10]
len(ageing_df)


# In[68]:


ageing_df.rename(columns={'Diff':'Reg_Post_Updated >10Days'},inplace=True)


# In[69]:


Adf=ageing_df[ageing_df.CurrentLocationDepot != 'UCGD']
ageing_df_summary=Adf.pivot_table(index=['CustomerName'],
                                        values=['ConNumber'],
                                        aggfunc={'ConNumber':len})
ageing_df_summary.sort_values('ConNumber', ascending=False, inplace=True)
ageing_df_summary.rename(columns={"ConNumber":"NumberOfCons"},inplace=True)
PIVOT1=ageing_df_summary.head(15)
PIVOT1


# In[72]:


import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback
from glob import glob
from IPython import display
from datetime import datetime,timedelta
import pyodbc

date=datetime.strftime(datetime.now(),'%Y-%m-%d-%H')


# In[71]:


with ExcelWriter(r"D:\Data\UCG_MoveToLocation.xlsx") as writer:
    PIVOT1.to_excel(writer, sheet_name='PIVOT',engine='xlsxwriter')
    



print("ExcelSheet Created!")
ageing_df.to_csv(r'D:\Data\UCG_Data.csv')

# In[74]:


filepath=r'D:\Data\UCG_MoveToLocation.xlsx'
filepath1=r'D:\Data\UCG_Data.csv'

# In[78]:


oppath1=filepath
#FTP Upload starts
print ('Logging in...')
ftp = ftplib.FTP()  
ftp.connect('10.109.230.50')  
print (ftp.getwelcome())

try:
 try:
     ftp.login('HOSQTeam', 'Te@mH0$q')
     print ('login done')
     ftp.cwd('Auto_reports')
     #ftp.cwd('FIFO')
     # move to the desired upload directory
     print ("Currently in:", ftp.pwd())
     print ('Uploading...')
     fullname = oppath1
     name = os.path.split(fullname)[1]
     f = open(fullname, "rb")
     ftp.storbinary('STOR ' + name, f)
     f.close()
     print ("OK"  )
     print ("Files:")
     print (ftp.retrlines('LIST'))
 finally:
     print ("Quitting...")
     ftp.quit()
except:
    traceback.print_exc()
    
#date=datetime.strftime(datetime.now(),'%Y-%m-%d %H:%M:%S')


# ----------- E M A I L --------------------------    
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template                    


TO=['spot_cstl@spoton.co.in','rsm_spot@spoton.co.in','dsm_spot@spoton.co.in','sharmistha.majumdar@spoton.co.in']

FROM="mis.ho@spoton.co.in"
CC = ['sq_spot@spoton.co.in','shivananda.p@spoton.co.in']
# TO = ['vishwas.j@spoton.co.in']
# CC = ['sanjana.narayana@spoton.co.in']
BCC = ['sanjana.narayana@spoton.co.in']


# TO=['sanjana.narayana@spoton.co.in']
# FROM="mis.ho@spoton.co.in"
# CC = ['anitha.thyagarajan@spoton.co.in']

# BCC = ['sanjana.narayana@spoton.co.in']


msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = " UCG Final notice cons, ready to move to respective UCG location. " + " - " + str(date)
html='''<html>
<style>        
p
 {
   margin:0;
   margin-top: 5px;
   padding:0;
   font-size:15px;
   line-height:20px;
 }
</style>                


'''
html3='''
<h5> To download File, Please click the link below </h5>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/UCG_MoveToLocation.xlsx"</a>
"http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/UCG_MoveToLocation.xlsx</p>
'''
report=""
report+='<br>'
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='Please find summary of all cons whose UCG final notice have been sent and are ready to be moved to UCG location.'
report+='<br>'
report+='<br>'+PIVOT1.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(oppath1,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))

part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(filepath1,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
#msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("spoton.net.in", "Star@123#")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
print ('mail sent')
server.quit()

