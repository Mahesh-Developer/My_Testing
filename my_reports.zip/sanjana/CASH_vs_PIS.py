
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
# import matplotlib.pyplot as plt
# import seaborn
from glob import glob
from IPython import display
from datetime import datetime,timedelta, date
import pyodbc
# import geopy
import pandas as pd


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=SQTeam;PWD=eSp0T@321$Sq")
cursor = cnxn.cursor()

QUERY= ''' EXEC USP_PIS_DETAILS_SQ  '''

Q1=pd.read_sql(QUERY,cnxn)
DATA=pd.read_sql(QUERY,cnxn)


# In[2]:


# Q1.columns
Q1['DOCKNO']=Q1['DOCKNO'].astype(int)


# In[3]:


Q1['AT_DESTINATION']= Q1['destareaname'] == Q1['CURR_AREA']
# Q1


# In[4]:


##############  Aging BUCKET - BOOKING DATE #############################


# In[5]:


Today = datetime.strftime(datetime.now(),'%Y-%m-%d %H:%M:%S')
Today
# Q1['BOOKINGDATE']


Q1['BOOKINGDATE']=pd.to_datetime(Q1['BOOKINGDATE'])
Q1['CurrentDate']=pd.to_datetime(Today)
# pd.np.round((DE_PIV['Delivered']/DE_PIV['Total'])*100,0)
Q1['DaySinceBooking']=(Q1['CurrentDate']-Q1['BOOKINGDATE'])/np.timedelta64(1,'h')
# Q1[['DaySinceBooking','BOOKINGDATE','CurrentDate']]

def tag (hrs):     
#### tag is the name of the function, z is the variable which inherits the values in 'APORDER' column, 
###  then it goes on to test the condition
    if hrs<= 24:
        return '1'
    elif hrs >24 and hrs<= 48:
        return '2'
    elif hrs >48 and hrs<= 72:
        return '3'
    elif hrs >72 and hrs<= 96:
        return '4'
    else:
        return '4+ Days'

Q1['BOOKINGDATE_Aging'] = Q1.apply(lambda x:tag(x['DaySinceBooking']), axis=1)
# Q1['BOOKINGDATE_Aging']


# In[6]:


##############  Aging BUCKET - ARRIVAL DATE #############################


# In[7]:


Q1['HOURS_LYING_AT_CURR_LOCATION']
def tag (hrs1):     
#### tag is the name of the function, z is the variable which inherits the values in 'APORDER' column, 
###  then it goes on to test the condition
    if hrs1<= 24:
        return '1'
    elif hrs1 >24 and hrs1<= 48:
        return '2'
    elif hrs1 >48 and hrs1<= 72:
        return '3'
    elif hrs1 >72 and hrs1<= 96:
        return '4'
    else:
        return '4+ Days'
    
Q1['ARRVDATE_Aging'] = Q1.apply(lambda x:tag(x['HOURS_LYING_AT_CURR_LOCATION']), axis=1)
# Q1['ARRVDATE_Aging']


# In[8]:


##############  PIVOT-1 :   CASH BOOKING  vs PIS NOT DONE  #############################


# In[9]:


## Filtering for PIS not Generated ##
A=Q1[Q1.CashPISDRSEnabled == 'NO']


# In[10]:


TABLE1=pd.pivot_table(A,index=["orgareaname"],
                      columns=["BOOKINGDATE_Aging"],
                      values=['DOCKNO'],
                      aggfunc={'DOCKNO':len},
                      margins=True, margins_name= 'Grand Total'
                     ).fillna(0)
TABLE1['DOCKNO']=TABLE1['DOCKNO'].astype(int)   


# In[11]:


TABLE1.sort_values(('DOCKNO','Grand Total'),ascending=False,inplace=True)     


# In[12]:


TABLE1                     


# In[13]:


# TABLE1['Total Cons']=TABLE1.sum(axis=1)


# In[14]:


# TABLE1.sort_values(('Total Cons'), ascending=False)  
# TABLE1


# In[15]:


##############  PIVOT-2: PIS DONE, AT DEST LOC, BUT NOT   #############################


# In[16]:


## Filtering for * AT_DESTINATION=TRUE *  For next two pivots   ##
X=Q1[Q1.AT_DESTINATION == True]


# In[17]:


X['destareaname'].unique()


# In[18]:


###  FILTER TO REMOVE BLANK(UCG)- i.e No destinaton area entered ###

X=X[X['destareaname']!='']
# X['destareaname']


# In[19]:


## Filtering for PIS HAS BEEN **Generated** ##
B=X[(X.CashPISDRSEnabled == 'YES')]


# In[20]:


TABLE2=pd.pivot_table(B, index="destareaname",
                      columns=["ARRVDATE_Aging"],
                      values=['DOCKNO'],
                      aggfunc={'DOCKNO':len},margins=True, margins_name= 'Grand Total').fillna(0)
# TABLE1.sort_values([('Total Cons')], ascending=False)  
TABLE2['DOCKNO']=TABLE2['DOCKNO'].astype(int)                      
TABLE2.sort_values(('DOCKNO','Grand Total'),ascending=False,inplace=True)             
TABLE2


# In[21]:


##############  PIVOT-3: PIS DONE, AT DEST LOC, BUT NOT   #############################


# In[22]:


## Filtering for PIS HAS BEEN **Generated** ##
C=X[X.CashPISDRSEnabled == 'NO']


# In[23]:


TABLE3=pd.pivot_table(C, index="destareaname",
                      columns=["ARRVDATE_Aging"],
                      values=['DOCKNO'],
                      aggfunc={'DOCKNO':len},margins=True, margins_name= 'Grand Total').fillna(0)
TABLE3['DOCKNO']=TABLE3['DOCKNO'].astype(int)    


# In[24]:


# TABLE3['DOCKNO']=TABLE3['DOCKNO'].astype(int)                      
TABLE3.sort_values(('DOCKNO','Grand Total'),ascending=False,inplace=True)             
TABLE3


# In[25]:


########## MAIL ##################################################################


# In[26]:


# from pandas import ExcelWriter
# with ExcelWriter(r"D:\Data\Cash_vs_PIS\CashBooking.xlsx") as writer:
#     DATA.to_excel(writer, sheet_name='Data',engine='xlsxwriter')
# print('file created')


DATA.to_csv(r"D:\Data\Cash_vs_PIS\CashBooking.csv")

# In[27]:


# DATA.to_csv(r"F:\CashBooking"+str(today)+".csv")
# print('csv file created')


# In[29]:


import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback
from glob import glob
from IPython import display
from datetime import datetime,timedelta
import pyodbc

date=datetime.strftime(datetime.now(),'%Y-%m-%d-%H')


filepath=r"D:\Data\Cash_vs_PIS\CashBooking.csv"

oppath1=filepath
#FTP Upload starts
print ('Logging in...')
ftp = ftplib.FTP()  
ftp.connect('10.109.230.50')  
print (ftp.getwelcome())

try:
 try:
     ftp.login('HOSQTeam', 'Te@mH0$q')
     print ('login done')
     ftp.cwd('Auto_reports')
     #ftp.cwd('FIFO')
     # move to the desired upload directory
     print ("Currently in:", ftp.pwd())
     print ('Uploading...')
     fullname = oppath1
     name = os.path.split(fullname)[1]
     f = open(fullname, "rb")
     ftp.storbinary('STOR ' + name, f)
     f.close()
     print ("OK"  )
     print ("Files:")
     print (ftp.retrlines('LIST'))
 finally:
     print ("Quitting...")
     ftp.quit()
except:
    traceback.print_exc()
    
#date=datetime.strftime(datetime.now(),'%Y-%m-%d %H:%M:%S')


# ----------- E M A I L --------------------------    
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template                    


# TO=['shivananda.p@spoton.co.in']
# TO=['sanjana.narayana@spoton.co.in']

FROM="mis.ho@spoton.co.in"
# BCC = ['sanjana.narayana@spoton.co.in']

BCC = ['AOM_SPOT@spoton.co.in','DOM_SPOT@spoton.co.in',
       'ROM_SPOT@spoton.co.in','SC_incharge@spoton.co.in',
       'sanjana.narayana@spoton.co.in','SQ_SPOT@spoton.co.in',
      'shivananda.p@spoton.co.in','shivananda.p@spoton.co.in']


msg = MIMEMultipart()
msg["From"] = FROM
# msg["To"] = ",".join(TO)
# msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = "Cash Booking vs PIS Pending vs Undel " + " - " + str(date)
html='''<html>
<style>        
p
 {
   margin:0;
   margin-top: 5px;
   padding:0;
   font-size:15px;
   line-height:20px;
 }
</style>                


'''
html3='''
<h5> To download File, Please click the link below </h5>
<p><a href= http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/CashBooking.xlsx </a>
http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/CashBooking.xlsx </p>
'''
report=""
report+='<br>'
report+='Dear Sir,'
report+='<br>'
report+='Please find the following Summaries below.'
report+='<br>'
report+='<br>'
report+=' Cash booking v/s PIS not done.'
report+='<br>'
report+='<br>'+TABLE1.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+=' Cash booking PIS generated and consignment reached at Delivery locations  but consignment not delivered.'
report+='<br>'
report+='<br>'+TABLE2.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+=' Consignment reached at the delivery locations but PIS not generated.'
report+='<br>'
report+='<br>'+TABLE3.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+=html
report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(oppath1,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login('spoton.net.in', 'Star@123#')
failed = server.sendmail(FROM, 
#                          TO+
#                          CC+
                         BCC, msg.as_string())
print ('mail sent')
server.quit()

