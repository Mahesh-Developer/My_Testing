
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
from datetime import datetime,timedelta
import pyodbc
from fuzzywuzzy import fuzz
import pandas as pd
import pyodbc
from datetime import datetime,timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
import ftplib
# import Utilities
from calendar import monthrange
import smtplib


# In[2]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")


# In[3]:


df=pd.read_sql("EXEC USP_STOCK_ODA_CONS_MAIN",cnxn)


# In[4]:


len(df)


# In[10]:




# In[8]:


def getBucket(x):
    if x==0:
        return "0 Days"
    elif x==1:
        return "1 Days"
    elif x==2:
        return "2 Days"
    elif x in range(3,5):
        return "3-5 Days"
    elif x in range(6,10):
        return "6-10 Days"
    else:
        return ">10 Days"


# In[11]:


df['Bucket']=df.apply(lambda x:getBucket(x['AGING']),axis=1)


# In[15]:


mail_summary=df.pivot_table(index=['DestnDepot', 'DestnArea'],columns=['Bucket'],values=['TotalActualWeight','ConNumber'],aggfunc={'ConNumber':len,'TotalActualWeight':sum},margins=True,margins_name='Total').fillna(0)


df2=df[~df['LatestStatusCategory'].isin(['SENDER FAILURE','RECEIVER FAILURE'])]
ccfmail_summary=df2.pivot_table(index=['DestnDepot', 'DestnArea'],columns=['Bucket'],values=['TotalActualWeight','ConNumber'],aggfunc={'ConNumber':len,'TotalActualWeight':sum},margins=True,margins_name='Total').fillna(0)






# In[18]:


excel_summary=df.pivot_table(index=['DestnDepot', 'DestnArea','DestnBranch','PinCode'],columns=['Bucket'],values=['TotalActualWeight','ConNumber'],aggfunc={'ConNumber':len,'TotalActualWeight':sum},margins=True,margins_name='Total').fillna(0)




df.to_csv(r'D:\Data\ODA_Report\ODA_Data.csv')
excel_summary.to_csv(r'D:\Data\ODA_Report\PinCode_Summary.csv')
# In[20]:


filepath=r'D:\Data\ODA_Report\ODA_Data.csv'
filepath1=r'D:\Data\ODA_Report\PinCode_Summary.csv'


# In[21]:


todate=datetime.strftime(datetime.now()-timedelta(days=1),"%Y-%m-%d")
todate


# In[22]:
# TO=['banusanketh.dc@spoton.co.in']
# CC=['mahesh.reddy@spoton.co.in']

TO=["aom_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in","scincharge_spot@spoton.co.in","baskar.t@spoton.co.in"]
CC=['abhik.mitra@spoton.co.in','pawan.sharma@spoton.co.in','rajesh.kumar@spoton.co.in','mahesh.reddy@spoton.co.in','banusanketh.dc@spoton.co.in','anitha.thyagarajan@spoton.co.in',"shivananda.p@spoton.co.in"]
FROM="reports.ie@spoton.co.in"

msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)

msg["Subject"] = "ODA Report " + " - " + str(todate)

report=""
report+="Dear All,"
report+='<br>'
report+='Please find ODA Report Depot wise'
report+='<br>'
report+='ODA NonCCF Summary :'
report+='<br>'+ccfmail_summary.to_html()+'<br>'
report+='<br>'

report+='<br>'
report+='All con Summary :'
report+='<br>'+mail_summary.to_html()+'<br>'
report+='<br>'


abc=MIMEText(report,'html')
msg.attach(abc)

part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(filepath1,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
msg.attach(part1)


server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()

server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()

