
# coding: utf-8

# In[1]:

import pandas as pd
from datetime import timedelta, date
import datetime

import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
import os
import math
import Utilities
# In[2]:

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()

routemast = ("""
        EXEC USP_RUTMAS_DUMP_SQ_IE
        """)

allschedules = pd.read_sql(routemast, Utilities.cnxn)

last7daysdeptsquery = ("""
        EXEC USP_THC_DETAILS_LAST7DAYS_SQ_IE
        """)

last7daysdepts = pd.read_sql(last7daysdeptsquery, Utilities.cnxn)


#allschedules = pd.read_csv(r'All_Routes_Schedules.csv')
#last7daysdepts = pd.read_csv(r'Last_7_days_departures.csv')


# In[3]:

def datestring(x):
    try:
        fulldate = datetime.datetime.strptime(x,'%Y-%m-%d %H:%M')
        return fulldate
    except:
        fulldate = datetime.datetime.strptime(x,'%d-%m-%Y %H:%M')
        return fulldate

print type(allschedules['DEPT_TIME'].values[0]),type(allschedules['ARRV_TIME'].values[0]),type(last7daysdepts['Sch_Dept'].values[0]),type(last7daysdepts['Act_Dept'].values[0])
# In[4]:

#allschedules['DEPT_TIME'] = allschedules.apply(lambda x:datestring(x['DEPT_TIME']),axis=1)
#allschedules['ARRV_TIME'] = allschedules.apply(lambda x:datestring(x['ARRV_TIME']),axis=1)
#last7daysdepts['Sch_Dept'] = last7daysdepts.apply(lambda x:datestring(x['Sch_Dept']),axis=1)
#last7daysdepts['Act_Dept'] = last7daysdepts.apply(lambda x:datestring(x['Act_Dept']),axis=1)


# In[5]:

datefilter_yest = (datetime.datetime.today()-timedelta(hours=24)).date()
datefilter_today = (datetime.datetime.today()).date()

yest_09 = datetime.datetime.combine(datefilter_yest, datetime.time(9))
today_09 = datetime.datetime.combine(datefilter_today, datetime.time(9))
print yest_09,today_09


# In[6]:

lastdaydepts = last7daysdepts[(last7daysdepts['Sch_Dept']>yest_09) & (last7daysdepts['Sch_Dept']<=today_09)]
len(lastdaydepts)


# In[7]:

delbom = allschedules[(allschedules['RUT_ORGN']=='DELH') &(allschedules['RUT_DESTN']=='BOMH')]
bomdel = allschedules[(allschedules['RUT_ORGN']=='BOMH') &(allschedules['RUT_DESTN']=='DELH')]
delbom_bomdel = delbom.append(bomdel)


# In[8]:

last7daysdepts = last7daysdepts[['thcno','sourcehb','tobh_code','routecd','vehno','Sch_Dept','Act_Dept']]


# In[9]:

delbom


# In[10]:

finaldf = pd.merge(delbom_bomdel,lastdaydepts,left_on=['RUTCD','RUT_ORGN'],right_on=['routecd','sourcehb'],how='left')


# In[11]:

def diffhr(act_dept_time,sch_time):
    try:
        diff = (act_dept_time - sch_time)
        return pd.np.round(diff.total_seconds()/3600,1)
    except:
        pass

#finaldf.to_csv(r'finaldf.csv')
# In[12]:

finaldf['Delay_Hrs'] = finaldf.apply(lambda x:diffhr(x['Act_Dept'],x['Sch_Dept']),axis=1)


# In[13]:

def timediffbucks(timediffval):
    if -1.0 <= timediffval <= 1.0:
        return 'Ontime departure'
    elif timediffval > 1.0:
        return 'Late departure'
    elif timediffval < -1.0:
        return 'Early Departure'
    else:
        return 'Not Operated Yet'
    
        


# In[15]:

finaldf['Remarks'] = finaldf.apply(lambda x:timediffbucks(x['Delay_Hrs']),axis=1)


# In[16]:

finaldf_reqcols = finaldf[['RUTCD','PATH','RUT_ORGN','RUT_DESTN','DEPT_TIME','Act_Dept','Delay_Hrs','Remarks']]

## For getting Scheduled departure of the lanes where it hasnt departed
finaldf_reqcols = finaldf_reqcols.rename(columns={'DEPT_TIME':'Scheduled_Dept'})
## For getting Scheduled departure of the lanes where it hasnt departed

todaydate = date.today() 
# In[17]:


## To Exclude  DELH-HYDH-BOMH Route
excludertcdlist = ['U1653','D1653','U1709','D1709']
finaldf_reqcols = finaldf_reqcols[~(finaldf_reqcols['RUTCD'].isin(excludertcdlist))]
## To Exclude  DELH-HYDH-BOMH Route


finaldf_reqcols.to_csv(r'D:\Data\BOMH_DELH_Lane_Departures\BOMH_DELH_Lan_Departures_'+str(todaydate)+'.csv', index=False)
oppath1 = r'D:\Data\BOMH_DELH_Lane_Departures\BOMH_DELH_Lan_Departures_'+str(todaydate)+'.csv'

okdepslist = ['Ontime departure','Early Departure']
finaldf_mail = finaldf_reqcols[~(finaldf_reqcols['Remarks'].isin(okdepslist))]
finaldf_mail = finaldf_mail[['RUTCD','PATH','Delay_Hrs','Remarks']]
finaldf_mail = finaldf_mail.to_string(index=False)

# In[ ]:
filePath = oppath1
def sendEmail(TO = ["cnm@spoton.co.in","raghavendra.rao@spoton.co.in","Krishna.Kumar.Bhardwaj@Spoton.Co.In","Sandesh.Patade@Spoton.Co.In","Ramachandran.P@Spoton.Co.In","Jaivir.Singh@Spoton.Co.In","Jaisingh.Chauhan@Spoton.Co.In"],
              #TO = ["vishwas.j@spoton.co.in"],
              #CC = ["vishwas.j@spoton.co.in"],
              CC = ["abhik.mitra@spoton.co.in","Pawan.Sharma@Spoton.Co.In","Prasanna.Hegde@Spoton.Co.In","Jothi.Menon@Spoton.Co.In","Rajesh.Kumar@Spoton.Co.In","Shivananda.P@Spoton.Co.In"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "BOMH-DELH Lane Departures" + ' - ' + str(todaydate)
    body_text = """
    Dear All,
    
    PFB the BOMH-DELH & DELH-BOMH lanes departure performance for """+str(todaydate)+"""
    
"""+str(finaldf_mail)+"""    
    
    """ 

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')


