
# coding: utf-8

# In[45]:


import numpy as np
import pandas as pd
# import matplotlib.pyplot as plt
# import seaborn
from glob import glob
from IPython import display
from datetime import datetime,timedelta
import pyodbc
# import geopy
import pandas as pd
import Utilities

# In[46]:

try:
    cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=SQTeam;PWD=eSp0T@321$Sq")
    cursor = cnxn.cursor()
    
    
    # In[47]:
    
    
    query= """ EXEC dbo.USP_WEIGHT_AUDIT_CONS_ATLOC_SQ   """
    print (query)
    
    
    # In[48]:
    
    
    WT_Q=pd.read_sql(query,Utilities.cnxn)
    
    
    # In[49]:
    
    
    WT_Q.columns
    
    
    # In[50]:
    
    
    HUBC=WT_Q[WT_Q.HUBCENTER == 'Y']
    # HUBC['HUBCENTER']
    
    
    # In[51]:
    
    
    SC=WT_Q[WT_Q.HUBCENTER == 'N']
    # SC['HUBCENTER']
    
    
    # In[52]:
    
    
    H_PIV=pd.pivot_table(HUBC, index=["CURR_REGION","CURR_BRANCHCODE"], 
                         columns=["LOC_TYPE"],
                         values=['DOCKNO'],
                        aggfunc={'DOCKNO':len}, margins= True, margins_name= 'Grand Total').fillna(0)
    H_PIV['DOCKNO']=H_PIV['DOCKNO'].astype(int)
    H_FIN=H_PIV[[('DOCKNO','ORIGIN_HUB'),('DOCKNO','DESTN_HUB'),('DOCKNO','DESTN_SC'),('DOCKNO','INTRANSIT_LOC'),('DOCKNO','Grand Total')]]
    H_FIN
    
    
    # In[53]:
    
    
    SC_mail=pd.pivot_table(SC, index=["CURR_REGION","CURR_AREA"], 
                         columns=["LOC_TYPE"],
                         values=['DOCKNO'],
                        aggfunc={'DOCKNO':len}, margins= True, margins_name= 'Grand Total').fillna(0)
    SC_mail['DOCKNO']=SC_mail['DOCKNO'].astype(int)
    SC_FIN_mail=SC_mail[[('DOCKNO','ORGIN_SC'),('DOCKNO','DESTN_SC'),('DOCKNO','INTRANSIT_LOC'),('DOCKNO','Grand Total')]]
    SC_FIN_mail
    
    
    # In[54]:
    
    
    SC_PIV=pd.pivot_table(SC, index=["CURR_REGION","CURR_AREA","CURR_BRANCHCODE"], 
                         columns=["LOC_TYPE"],
                         values=['DOCKNO'],
                        aggfunc={'DOCKNO':len}, margins= True, margins_name= 'Grand Total').fillna(0)
    SC_PIV['DOCKNO']=SC_PIV['DOCKNO'].astype(int)
    SC_FIN=SC_PIV[[('DOCKNO','ORGIN_SC'),('DOCKNO','DESTN_SC'),('DOCKNO','INTRANSIT_LOC'),('DOCKNO','Grand Total')]]
    SC_FIN
    
    
    # In[55]:
    
    
    WT_Q.to_csv(r'D:\Data\weight_audit_report\Data\DATA_WeightAuditCon_lying_Loc.csv')
    H_FIN.to_csv(r'D:\Data\weight_audit_report\Data\HUB_WeightAuditCon_lying_Loc.csv')
    SC_FIN.to_csv(r'D:\Data\weight_audit_report\Data\SC_WeightAuditCon_lying_Loc.csv')
    # from pandas import ExcelWriter
    # with ExcelWriter(r'F:\WeightAuditCon_lying_Location.xlsx') as writer:
    #     WT_Q.to_excel(writer,engine='xlsxwriter',sheet_name='Data')
    #     H_FIN.to_excel(writer,engine='xlsxwriter',sheet_name='HUB')
    #     SC_FIN.to_excel(writer,engine='xlsxwriter',sheet_name='SC')
    
    "done!"
    
    
    # In[56]:
    
    
    import numpy as np
    import pandas as pd
    import itertools
    import json
    from pandas import ExcelWriter
    from pandas import pivot_table
    from datetime import datetime
    import os
    import ftplib
    import traceback
    from glob import glob
    from IPython import display
    from datetime import datetime,timedelta
    import pyodbc
    
    date=datetime.strftime(datetime.now(),'%Y-%m-%d-%H')
    
    
    filePath1=r'D:\Data\weight_audit_report\Data\DATA_WeightAuditCon_lying_Loc.csv'
    filePath2=r'D:\Data\weight_audit_report\Data\HUB_WeightAuditCon_lying_Loc.csv'
    filePath3=r'D:\Data\weight_audit_report\Data\SC_WeightAuditCon_lying_Loc.csv'
    
    for i in [filePath1,filePath2,filePath3]:
        oppath1=i
        #FTP Upload starts
        print ('Logging in...')
        ftp = ftplib.FTP()  
        ftp.connect('10.109.230.50')  
        print (ftp.getwelcome())
        try:  
            try:  
                ftp.login('HOSQTeam', 'Te@mH0$q')
                print ('login done')
                ftp.cwd('Auto_reports')  
                #ftp.cwd('FIFO')
                # move to the desired upload directory  
                print ("Currently in:", ftp.pwd()) 
                print ('Uploading...')  
                fullname = oppath1
                name = os.path.split(fullname)[1]  
                f = open(fullname, "rb")  
                ftp.storbinary('STOR ' + name, f)  
                f.close()  
                print ("OK"  )
                print ("Files:")  
                print (ftp.retrlines('LIST'))
            finally:  
                print ("Quitting...")
                ftp.quit()  
        except:  
            traceback.print_exc()
    
        
    
    
    
    # ----------- E M A I L --------------------------    
    import smtplib
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    from email.mime.base import MIMEBase
    from email import encoders
    import os
    from string import Template                    
    
    
    TO=['rom_spot@spoton.co.in',
    'dom_spot@spoton.co.in',
    'aom_spot@spoton.co.in',
    'scincharge_spot@spoton.co.in'
    'hubmgr_spot@spoton.co.in','sc_incharge@spoton.co.in']
    
    #TO=['mahesh.reddy@spoton.co.in ']
    #CC=['mahesh.reddy@spoton.co.in ']
    
    FROM="mis.ho@spoton.co.in"
    
    CC = ['sqtf@spoton.co.in',
    'sq_spot@spoton.co.in']
    
    
    BCC = ['sanjana.narayana@spoton.co.in','mahesh.reddy@spoton.co.in']
    
    
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    msg["Subject"] = " Weight audit Cons lying at location " + " - " + str(date)
    html='''<html>
    <style>        
    p
     {
       margin:0;
       margin-top: 5px;
       padding:0;
       font-size:15px;
       line-height:20px;
     }
    </style>                
    
    
    '''
    # html3='''
    # <h5> To download File, Please click the link below </h5>
    # <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/APT_DE_"+str(today)+".xlsx"</a>
    # "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/APT_DE.xlsx"</p>
    # '''
    report=""
    report+='<br>'
    report+='Dear All,'
    report+='<br>'
    report+='<br>'
    report+='Please find attached, Report of Identified Customer Con Lying at location, where weight audit needs to be carried out.'
    report+='<br>'
    report+='Con Lying at Location: HUB'
    report+='<br>'
    report+='<br>'+H_FIN.to_html()+'<br>'
    report+='<br>'
    report+='Con Lying at Location: SC'
    report+='<br>'
    report+='<br>'+SC_FIN_mail.to_html()+'<br>'
    report+='<br>'
    
    # report+=html
    abc=MIMEText(report,'html')
    msg.attach(abc)
    
    part1 = MIMEBase('application', "octet-stream")
    part1.set_payload( open(filePath1,"rb").read() )
    encoders.encode_base64(part1)
    part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath1))
    msg.attach(part1)
    
    part2 = MIMEBase('application', "octet-stream")
    part2.set_payload( open(filePath2,"rb").read() )
    encoders.encode_base64(part2)
    part2.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath2))
    msg.attach(part2)
    
    part3 = MIMEBase('application', "octet-stream")
    part3.set_payload( open(filePath3,"rb").read() )
    encoders.encode_base64(part3)
    part3.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath3))
    msg.attach(part3)
    
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login('spoton.net.in', 'Star@123#')
    failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
    print ('mail sent')
    server.quit()
    
except:
    from glob import glob
    from IPython import display
    from datetime import datetime,timedelta
    import pyodbc
    
    date=datetime.strftime(datetime.now(),'%Y-%m-%d-%H')
    
    
    ##################### EMAIL ########################
    
    import smtplib
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    from email.mime.base import MIMEBase
    from email import encoders
    import os
    from string import Template                    
    
    
    
    TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in']
    T#O=['sanjana.narayana@spoton.co.in']
    FROM="mis.ho@spoton.co.in"
    # CC = ['sanjana.narayana@spoton.co.in']
    
    
    BCC = ['sanjana.narayana@spoton.co.in']
    
    
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    # msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    msg["Subject"] = " ***ERROR*** IN SENDING REPORT :Weight audit Cons lying at location" + " - " + str(date)
    html='''<html>
    <style>        
    p
     {
       margin:0;
       margin-top: 5px;
       padding:0;
       font-size:15px;
       line-height:20px;
     }
    </style>                
    
    
     '''
    # html3='''
    # <h5> To download File, Please click the link below </h5>
    # <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/APT_DE_"+str(today)+".xlsx"</a>
    # "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/APT_DE.xlsx"</p>
    # '''
    report=""
    report+='<br>'
    report+='Hello,'
    report+='<br>'
    report+='<br>'
    report+=' Please CHECK, ERROR IN SENDING EMAIL.'
    report+='<br>'
    report+='<br>'
    report+=' REPORT NAME: Weight audit Cons lying at location '
    report+='<br>'
    report+='<br>'
    report+='<br>'
    report+='<br>'
    report+='<br>'
    report+='<br>'
    
    # report+=html
    abc=MIMEText(report,'html')
    msg.attach(abc)
    part = MIMEBase('application', "octet-stream")
    # part.set_payload( open(oppath1,"rb").read() )
    # encoders.encode_base64(part)
    # part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
    # msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login('spoton.net.in', 'Star@123#')
    failed = server.sendmail(FROM, TO+BCC, msg.as_string())
    print ('ERROR ***** mail sent')
    server.quit()
    

