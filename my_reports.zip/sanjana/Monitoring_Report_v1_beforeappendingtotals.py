
# coding: utf-8

# In[36]:

import pandas as pd
from datetime import datetime, timedelta, date
from pandas import ExcelWriter

import os
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from pandas import ExcelWriter
from email import encoders
# In[2]:

pmddata = pd.read_csv(r'http://spoton.co.in/downloads/PMD/PMD.csv')


# In[3]:

len(pmddata)


# In[4]:

def adhocstdoda(pudtype,pintype):
    if pudtype == 'STD-ADHOC':
        return pudtype+str('-')+str(pintype)
    else:
        return pudtype


# In[5]:

pmddata['PUDTYPES'] = pmddata.apply(lambda x: adhocstdoda (x['PUDTYPE2'],x['PINTYPE']),axis=1)


# In[6]:

#pmddata.to_csv(r'C:\Data\OCID_PMD\Monitoring_report_automation\PMD_test.csv')


# In[7]:

pmddatagrp = pmddata.groupby(['REGION2','PUDTYPES']).agg({'ACT_WT2':sum,'COST2':sum}).reset_index()


# In[8]:

pmddatagrp['CPKG'] = pmddatagrp.apply(lambda x: round(x['COST2']/x['ACT_WT2'],2),axis=1)


# In[9]:

pmddatagrpfull = pmddata.groupby(['PUDTYPES']).agg({'ACT_WT2':sum,'COST2':sum}).reset_index()
pmddatagrpfull['CPKG'] = pmddatagrpfull.apply(lambda x: round(x['COST2']/x['ACT_WT2'],2),axis=1)


# In[10]:

pmddatagrpfull.loc[pmddatagrpfull.index,'REGION2'] = 'ALL_INDIA'
columnsop = ['REGION2','PUDTYPES','COST2','ACT_WT2','CPKG']
pmddatagrpfull = pd.DataFrame(pmddatagrpfull,columns=columnsop)


# In[11]:

totalpmd = pmddatagrpfull.append(pmddatagrp,ignore_index=True)


# In[12]:

totalpmdgrp = totalpmd.groupby(['REGION2']).agg({'COST2':sum,'ACT_WT2':sum}).reset_index()
totalpmdgrp['CPKG'] = totalpmdgrp.apply(lambda x: round(x['COST2']/x['ACT_WT2'],2),axis=1)


# In[13]:

totalpmdmtd = pd.merge(totalpmdgrp,totalpmd,on=['REGION2'],how='outer')


# In[14]:

totalpmdmtd['% ACT_WT'] = totalpmdmtd.apply(lambda x: round(x['ACT_WT2_y']*100.0/x['ACT_WT2_x'],2),axis=1)


# In[15]:

totalpmdmtd = totalpmdmtd.drop(['COST2_x', 'ACT_WT2_x', 'CPKG_x'], axis=1)
totalpmdmtd = totalpmdmtd.rename(columns={'COST2_y':'COST'})
totalpmdmtd = totalpmdmtd.rename(columns={'ACT_WT2_y':'ACT_WT'})
totalpmdmtd = totalpmdmtd.rename(columns={'CPKG_y':'CPKG'})


# ### FOR YESTERDAY

# In[17]:

def datestring(x):
    fulldate = datetime.strptime(x,'%d %b %Y %H:%M')
    return fulldate


# In[18]:

pmddata['DATE'] = pmddata.apply (lambda x:datestring (x['DATE2']),axis=1)


# In[19]:

pmddata['DATE'].values[0]


# In[20]:

yesterdate=date.today()-timedelta(hours=24)


# In[21]:

yesterdaydf = pmddata[(pmddata['DATE'] >= yesterdate)]
len(yesterdaydf)


# In[22]:

pmddatagrpyest = yesterdaydf.groupby(['REGION2','PUDTYPES']).agg({'ACT_WT2':sum,'COST2':sum}).reset_index()
pmddatagrpyest['CPKG'] = pmddatagrpyest.apply(lambda x: round(x['COST2']/x['ACT_WT2'],2),axis=1)


# In[23]:

pmddatagrpfullyest = yesterdaydf.groupby(['PUDTYPES']).agg({'ACT_WT2':sum,'COST2':sum}).reset_index()
pmddatagrpfullyest['CPKG'] = pmddatagrpfullyest.apply(lambda x: round(x['COST2']/x['ACT_WT2'],2),axis=1)


# In[24]:

pmddatagrpfullyest.loc[pmddatagrpfullyest.index,'REGION2'] = 'ALL_INDIA'
columnsop = ['REGION2','PUDTYPES','COST2','ACT_WT2','CPKG']
pmddatagrpfullyest = pd.DataFrame(pmddatagrpfullyest,columns=columnsop)


# In[25]:

totalpmdyest = pmddatagrpfullyest.append(pmddatagrpyest,ignore_index=True)


# In[26]:

totalpmdgrpyest = totalpmdyest.groupby(['REGION2']).agg({'COST2':sum,'ACT_WT2':sum}).reset_index()
totalpmdgrpyest['CPKG'] = totalpmdgrpyest.apply(lambda x: round(x['COST2']/x['ACT_WT2'],2),axis=1)


# In[27]:

totalpmdyest = pd.merge(totalpmdgrpyest,totalpmdyest,on=['REGION2'],how='outer')
totalpmdyest['% ACT_WT'] = totalpmdyest.apply(lambda x: round(x['ACT_WT2_y']*100.0/x['ACT_WT2_x'],2),axis=1)


# In[29]:

totalpmdyest = totalpmdyest.drop(['COST2_x', 'ACT_WT2_x', 'CPKG_x'], axis=1)
totalpmdyest = totalpmdyest.rename(columns={'COST2_y':'COST'})
totalpmdyest = totalpmdyest.rename(columns={'ACT_WT2_y':'ACT_WT'})
totalpmdyest = totalpmdyest.rename(columns={'CPKG_y':'CPKG'})


# In[31]:

totalpmdmerge = pd.merge(totalpmdyest,totalpmdmtd,on=['REGION2','PUDTYPES'],suffixes=['_YDAY','_MTD'],how='outer')
columnsoptotal = ['REGION2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST_MTD','CPKG_MTD']
totalpmdmerge = pd.DataFrame(totalpmdmerge,columns=columnsoptotal)


# In[37]:

with ExcelWriter(r'D:\Data\Monitoring_report\Monitoring_Report_'+str(yesterdate)+'.xlsx') as writer:
    totalpmdmerge.to_excel(writer, sheet_name='Monitoring_Report',engine='xlsxwriter')

oppath = r'D:\Data\Monitoring_report\Monitoring_Report_'+str(yesterdate)+'.xlsx'
# In[33]:

dfformail = totalpmdmerge[totalpmdmerge['REGION2']=='ALL_INDIA']


# In[34]:

peractwtyday = pd.np.round(dfformail['% ACT_WT_YDAY'].sum(),2)
actwtyday = dfformail['ACT_WT_YDAY'].sum()
costyday = dfformail['COST_YDAY'].sum()
cpkyday = pd.np.round((costyday/actwtyday),2)
peractwtmtd = dfformail['% ACT_WT_MTD'].sum()
actwtmtd = dfformail['ACT_WT_MTD'].sum()
costmtd = dfformail['COST_MTD'].sum()
cpkmtd = pd.np.round((costmtd/actwtmtd),2)


# In[35]:

sumlist = ['GRAND_TOTAL','-',peractwtyday,actwtyday,costyday,cpkyday,peractwtmtd,actwtmtd,costmtd,cpkmtd]
col_list = ['REGION2','PUDTYPES','% ACT_WT_YDAY','ACT_WT_YDAY','COST_YDAY','CPKG_YDAY','% ACT_WT_MTD','ACT_WT_MTD','COST_MTD','CPKG_MTD']
totalsdf = pd.DataFrame(data=[sumlist], columns = col_list)
dfformail = dfformail.append(totalsdf,ignore_index=True)
dfformail


# In[ ]:
filePath = oppath
def sendEmail(#TO = ["supratim@iepfunds.com","Ankit@iepfunds.com","sukumar.sakthivel@spoton.co.in"],
            TO = ["mahesh.reddy@spoton.co.in"],
            CC = ["mahesh.reddy@spoton.co.in"],
            #CC = ["vishwas.j@spoton.co.in","rajeesh.vr@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "Monitoring Report " + '- ' + str(yesterdate)
    body_text = """
    Dear All,
    
    PFB the Monitoring Report as of """+str(yesterdate)+ """
    
    """+str(dfformail)+"""

    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("vishwas.j@spoton.co.in", "Startrek#123")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends



