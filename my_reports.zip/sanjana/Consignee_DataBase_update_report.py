
# coding: utf-8

# In[ ]:


import pyodbc
import numpy as np
import pandas as pd
from IPython import display
from datetime import datetime
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
import sys
import Utilities
reload(sys).setdefaultencoding("ISO-8859-1")


# In[ ]:


query=( """SELECT DISTINCT
                                CD.AUTOID ,
                                CD.RecGSTTIN [ConsigneeGSTIN] ,
                                CD.RecPin [ConsigneePincode] ,
                                CD.[State Code] + '-' + CD.State [State] ,
                                BR.BRCD + '-' + BR.BRNM [Branch] ,
                                CD.[Receiver address] [ConsigneeAddress] ,
                                CD.RecCompanyName [ConsigneeName] ,
                                CD.[From Company] [ConsignorName] ,
                                CD.[Consignee Contact Person Name] ConsigneeContactPersonName ,
                                CD.[Consignee Contact Number] ConsigneeContactNumber ,
                                CD.[Consignee Email Address] ConsigneeEmailAddress ,
                                ISNULL(CD.Remarks, '-') Remarks ,
                                ( CD.UpdatedBy + '-' + EM.EMPNM ) UpdatedBy
                        FROM    TBL_CONSIGNEE_DATA CD WITH ( NOLOCK )
                                INNER JOIN dbo.tblLocationMst LO WITH ( NOLOCK ) ON LO.PinCode = CD.RecPin
                                                              AND LO.IsServiceable <> 'N'
                                INNER JOIN dbo.brms BR WITH ( NOLOCK ) ON BR.BRCD = LO.ControllingBRCD
                                LEFT OUTER JOIN dbo.EMPMST EM WITH ( NOLOCK ) ON CD.UpdatedBy = EM.EMPCD
                                """)


# In[ ]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


# In[ ]:


h1=pd.read_sql(query,Utilities.cnxn)


# In[ ]:


len(h1)


# In[ ]:


def branch(Brn):
    rt = Brn.split('-')[0]
    return rt


# In[ ]:


h1['Branch Code']=h1.apply(lambda x : branch(x['Branch']), axis=1)


# In[ ]:


def branc(Bran):
    rt = Bran.split('-')[1]
    return rt


# In[ ]:


h1['Branch Name']=h1.apply(lambda x : branc(x['Branch']), axis=1)


# In[ ]:


h1['Remarks1']=h1['ConsigneeContactPersonName'].apply(lambda x: 'Not Updated' if x=='' else 'Updated')


# In[ ]:


branch_df=pd.read_excel(r'D:\Data\Latest Branch Details Master.xlsx',sheet_name='Branch details')


# In[ ]:


branch_df_dict=dict(zip(branch_df['SC-Code'],branch_df['Controlling Depot']))


# In[ ]:


h1['DEPOT']=h1['Branch Code'].map(branch_df_dict)


# In[ ]:


pivot_df=h1.pivot_table(index=['DEPOT','Branch Code'],columns=['Remarks1'], values=['ConsigneeContactPersonName'],aggfunc={'ConsigneeContactPersonName':len})


# In[ ]:


pivot_df=pivot_df.fillna(0)


# In[ ]:


h1['Remarks2']=h1['ConsigneeContactNumber'].apply(lambda x: 'Not Updated' if x=='' else 'Updated')


# In[ ]:


pivot_df1=h1.pivot_table(index=['DEPOT','Branch Code'],columns=['Remarks2'], values=['ConsigneeContactNumber'],aggfunc={'ConsigneeContactNumber':len})


# In[ ]:


pivot_df1=pivot_df1.fillna(0)


# In[ ]:


pivot_df1.head()


# In[ ]:


h1['Remarks3']=h1['ConsigneeEmailAddress'].apply(lambda x: 'Not Updated' if x=='' else 'Updated')


# In[ ]:


pivot_df2=h1.pivot_table(index=['DEPOT','Branch Code'],columns=['Remarks3'], values=['ConsigneeEmailAddress'],aggfunc={'ConsigneeEmailAddress':len})


# In[ ]:


pivot_df2=pivot_df2.fillna(0)


# In[ ]:


pivot_df=pd.merge(pivot_df,pivot_df1,left_index=True,right_index=True)


# In[ ]:


pivot_df=pd.merge(pivot_df,pivot_df2,left_index=True,right_index=True)


# In[ ]:


pivot_df


# In[ ]:


pivot_df=pivot_df.sort_values(('ConsigneeContactNumber','Updated'),ascending=False)


# In[ ]:


pivot_df['ConsigneeContactPersonName']=pivot_df['ConsigneeContactPersonName'].astype(int)


# In[ ]:


pivot_df['ConsigneeContactNumber']=pivot_df['ConsigneeContactNumber'].astype(int)


# In[ ]:


pivot_df['ConsigneeEmailAddress']=pivot_df['ConsigneeEmailAddress'].astype(int)


# In[ ]:


pivot_df.to_csv(r'D:\Data\Consignee_Updation\Consignee_Update.csv')


# In[ ]:


filepath=r'D:\Data\Consignee_Updation\Consignee_Update.csv'


# In[ ]:



from datetime import date,timedelta
todate=date.today()-timedelta(1)
today_date=datetime.strftime(todate,'%d-%m-%Y')
today_date
#vishwas.j@spoton.co.in


TO=['scincharge_spot@spoton.co.in','pawan.sharma@spoton.co.in','HUBMGR_SPOT@spoton.co.in','ROM_SPOT@spoton.co.in','DOM_SPOT@spoton.co.in']
CC=['krishna.chandrasekar@spoton.co.in','abhik.mitra@spoton.co.in','shivananda.p@spoton.co.in','satya.pal@spoton.co.in','rajesh.kapase@spoton.co.in','jothi.menon@spoton.co.in','uday.sharma@spoton.co.in','mayank.dwivedi@spoton.co.in','sanjay.nalawade@spoton.co.in','suman.kumar@spoton.co.in','sharmistha.majumdar@spoton.co.in','rajesh.kumar@spoton.co.in','saptarshi.pathak@spoton.co.in']
FROM="reports.ie@spoton.co.in"
# CC=[]
BCC=['mahesh.reddy@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = "Consignee DataBase Updation" + " - " + str(today_date)


#s = Template(html).safe_substitute(mktcostperc=mktcostperc,mktcpk=mktcpk,mktspend=mktspend,mktcpky=mktcpky,mktspendy=mktspendy,date=today_date)
report=""
report+="Dear All,"
report+='<br>'
report+="Please find the current update on Consignee Data Base Updation."
report+='<br>'
report+='<br>'
#report+=html3
report+=pivot_df.to_html()
#depotpivot_std
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()

