
# coding: utf-8

# In[1]:

import pandas as pd
from datetime import datetime, timedelta
import numpy as np
pd.set_option('display.max_columns',40)
from sqlalchemy import *
import pyodbc
import os
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
import traceback
# engine = create_engine("mysql+pymysql://user:pwd@104.199.198.197/LH30days")

cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=PYTHON_DB;UID=PythonOnline;PWD=P@ssw0rd123$")
cnxn1 = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")

# In[2]:

# provrev=45
provrev=0.0

# In[3]:
try:
	startdate=datetime.strftime(datetime.now()-timedelta(days=31),"%Y-%m-%d")
	df = pd.read_sql("SELECT * FROM LH30days WHERE [THC DATE] >= '{0}'".format(startdate),cnxn)
	df=df[~(df["Vech Type"].isin(['DATAVECHILE','VIRTUALHUB']))]
	df["VEHICLE PAYLOAD"]=df["VEHICLE PAYLOAD"].replace(0,13500)
	df["Util%"] = df.apply(lambda x: round(x["TOTAL ACTUAL LOAD"]*100.0/x["VEHICLE PAYLOAD"],1),axis=1)
	df["Vol Util%"] = df.apply(lambda x: round(x["TOTAL VOL WEIGHT"]*100.0/x["VEHICLE PAYLOAD"],1),axis=1)
	dfyest=df[(df["THC DATE"]>=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)-timedelta(days=1)))&(df["THC DATE"]<=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)))]
	# dfyest=pd.DataFrame()
	if len(dfyest)!=0:
		pass
	else:
		df=pd.read_excel(r'http://spoton.co.in/downloads/PMDLH/PMDLH.xls')
		df=df[~(df["Vech Type"].isin(['DATAVECHILE','VIRTUALHUB']))]
		df["VEHICLE PAYLOAD"]=df["VEHICLE PAYLOAD"].replace(0,13500)
		df["Util%"] = df.apply(lambda x: round(x["TOTAL ACTUAL LOAD"]*100.0/x["VEHICLE PAYLOAD"],1),axis=1)
		df["Vol Util%"] = df.apply(lambda x: round(x["TOTAL VOL WEIGHT"]*100.0/x["VEHICLE PAYLOAD"],1),axis=1)
		dfyest=df[(df["THC DATE"]>=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)-timedelta(days=1)))&(df["THC DATE"]<=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)))]


	# In[4]:


	lhcost=round(dfyest["COST"].sum()/1e5,1)
	yestutil = round(dfyest["TOTAL ACTUAL LOAD"].sum()*100.0/dfyest["VEHICLE PAYLOAD"].sum(),1)
	mktusageyest=round(dfyest[dfyest['ROUTE CODE']=='9888']["COST"].sum()*100.0/(1e5*lhcost),1)


	# In[8]:

	dfmtd=df[(df["THC DATE"]>=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)-timedelta(days=1)).replace(day=1))&(df["THC DATE"]<=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)))]
	mtdlhcost=round(dfmtd["COST"].sum()/1e5,1)-provrev
	mtdutil = round(dfmtd["TOTAL ACTUAL LOAD"].sum()*100.0/dfmtd["VEHICLE PAYLOAD"].sum(),1)
	mktusagemtd=round(dfmtd[dfmtd['ROUTE CODE']=='9888']["COST"].sum()*100.0/(1e5*(mtdlhcost+provrev)),1)


	# In[ ]:

	# engine2 = create_engine("mysql+pymysql://user:pwd@104.199.198.197/revenuebkg")


	startdate="'"+datetime.strftime((datetime.now()-timedelta(days=1)).replace(day=1),"%Y-%m-%d")+"'"
	enddate="'"+datetime.strftime(datetime.now(),"%Y-%m-%d")+"'"
	df = pd.read_sql("SELECT * FROM revenuebkg WHERE PICKUP_DATE >= {0} AND PICKUP_DATE < {1}".format(startdate,enddate),cnxn) 
	df=df[df['Product Type']!='AR']
	yeststart = datetime.combine((datetime.now()-timedelta(days=1)).date(), datetime.min.time())
	mtdrevenue = round(df["NetRev"].sum()*0.9645/100000.0,1)
	print (df[df["PICKUP_DATE"]>=yeststart])
	yestrevenue=round(df[df["PICKUP_DATE"]>=yeststart]["NetRev"].sum()*0.9645/100000.0,1)
	# yestrevenue=0
	if yestrevenue!=0:
		pass
	else:
		startdate_1=datetime.strftime((datetime.now()-timedelta(days=1)),"%Y-%b-%d")
		enddate_1=datetime.strftime(datetime.now(),"%Y-%b-%d")
		df=pd.read_csv(r'http://spoton.co.in/downloads/PMD_PL_DL_RV/PMDPLDLRL.csv')
		df=df[df['Product_Type']!='AR']
		def getDate(dt):
		    dt1=(dt.split(' ')[2]+'-'+dt.split(' ')[1]+'-'+dt.split(' ')[0])
		    return dt1
		df['PICKUP DATE']=df.apply(lambda x:getDate(x['PICKUP_DATE']),axis=1)
		yestrevenue=round(df[df["PICKUP DATE"]>=startdate_1]["NetRev"].sum()*0.9645/100000.0,1)
		mtdrevenue = round(df["NetRev"].sum()*0.9645/100000.0,1)

	print (lhcost,yestrevenue)
	startdate="'"+datetime.strftime((datetime.now()-timedelta(days=1)).replace(day=1),"%Y-%m-%d")+"'"
	enddate="'"+datetime.strftime(datetime.now(),"%Y-%m-%d")+"'"
	cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=PYTHON_DB;UID=PythonOnline;PWD=P@ssw0rd123$")
	cnxn2 = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
	cursor = cnxn2.cursor()
	print (startdate)
	print (enddate)
	# query=("select cast( DATE2 as datetime) as date2,* from puddata where cast( DATE2 as datetime) between {0} and {1}").format(startdate,enddate)
	query = ("EXEC USP_PUD_YEST_MTD_DATA 'M' ")
	pud=pd.read_sql(query,cnxn2)
	pud=pud[pud['PTYPE']!='AR']
	# mtd_pud_cost=pd.np.round(pud['COST2'].sum()/100000,1)
	mtd_pud_cost=pd.np.round(pud['COST'].sum()/100000,1)
	print (mtd_pud_cost)
	# mtd_pud_cost=0
	if mtd_pud_cost!=0:
		pass
	else:
	    pud=pd.read_csv(r'http://spoton.co.in/downloads/PMD/PMD.zip')
	    mtd_pud_cost=pd.np.round(pud['COST2'].sum()/100000,1)
	pud_rev_mtd=pd.np.round((mtd_pud_cost*100.0)/mtdrevenue,1)

	# In[ ]:

	if yestrevenue==0:
	    yestrevenue = '--error--'
	    mtdrevenue = '--error--'
	    mtdprop = '--error--'

	if yestrevenue!=0:
	    prop = round((lhcost/yestrevenue)*100.0,1)
	    mtdprop=round((mtdlhcost/mtdrevenue)*100.0,1)
	else:
	    prop = 0
	    mtdprop=0


	# In[ ]:

	#report+='MTD LH cost is Rs.'+str(mtdlhcost)+' lakhs (after providing Rs.'+str(provrev)+' lakhs).'

	# In[ ]:
	TO=["krishna.chandrasekar@spoton.co.in","pawan.sharma@spoton.co.in","satya.pal@spoton.co.in",'prasanna.hegde@spoton.co.in',"abhik.mitra@spoton.co.in",'shashvat.suhane@spoton.co.in']
	# TO=['vishwas.j@spoton.co.in']
	# TO=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
	# TO=['mahesh.reddy@spoton.co.in']
	CC=['mahesh.reddy@spoton.co.in']
	FROM="reports.ie@spoton.co.in"
	msg = MIMEMultipart()
	msg["From"] = FROM
	msg["To"] = ",".join(TO)
	msg["CC"] = ",".join(CC)
	#msg["BCC"] = ",".join(BCC)

	msg["Subject"] = "LH cost RDB" + ' - ' +str(datetime.strftime(datetime.today()-timedelta(hours=24),"%d-%m"))

	report=""
	report+='Dear All,'

	report+='<br>'
	report+='<br>'
	report+='LH cost for yesterday is Rs.'+str(lhcost)+" lakhs."
	#report+='<br>'
	report+='<br>'
	report+='Approx. revenue for yesterday is Rs.'+str(yestrevenue)+' lakhs.'
	report+='<br>'
	report+='Approx. LH% : '+str(prop)+'%'
	report+='<br>'
	report+='<br>'
	report+='MTD LH cost is Rs.'+str(mtdlhcost)
	report+='<br>'
	report+='MTD revenue is Rs.'+str(mtdrevenue)+' lakhs.'
	report+='<br>'
	report+='LH% of Rev for the month is: '+str(mtdprop)+'%.'
	report+='<br>'
	report+='<br>'
	report+='MTD PUD Cost is Rs. '+str(mtd_pud_cost)+' lakhs'
	report+='<br>'
	report+='PUD% of Rev for the month is :'+str(pud_rev_mtd)+'%'
	report+='<br>'
	report+='<br>'
	report+='Yesterdays utilisation is '+str(yestutil)+'%'+ '(excl. touching mkt veh adjustment)'
	report+='<br>'
	report+='MTD utilisation is '+ str(mtdutil)+'%.'
	report+='<br>'
	report+='Yesterdays market % is '+ str(mktusageyest)+'%.'
	report+='<br>'
	report+='MTD market % (in terms of cost) is '+str(mktusagemtd)+'%.'

	abc=MIMEText(report,'html')
	msg.attach(abc)




	server=smtplib.SMTP('smtp.sendgrid.net', 587)
	# server=smtplib.SMTP('smtp.gmail.com', 587)

	server.ehlo()
	server.starttls()
	server.ehlo()
	server.login("spoton.net.in", "Star@123#")
	# server.login('vishwas.j@spoton.co.in', 'Nov@2018')
	failed = server.sendmail(FROM, TO+CC, msg.as_string())
	server.quit()

except Exception:
	TO=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
	  # log=open("D:\Data\Logs\LH_Cost-"+str(datetime.strftime(datetime.today(),format='%Y-%m-%d'))+".txt","w",errors='strict')
	  # traceback.print_exc(file=log)
	  # filepath=log
	  # print (filepath)
	  # log.close()
	  # #TO=['mahesh.reddy@spoton.co.in']
	FROM="mahesh.reddy@spoton.co.in"
	msg = MIMEMultipart()
	msg["From"] = FROM
	msg["To"] = ",".join(TO)
	#msg["CC"] = ",".join(CC)
	#msg["BCC"] = ",".join(BCC)
	#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
	msg["Subject"] = "ERROR Report" 
	report=""
	report+='Hi,'

	report+='<br>'
	report+='There was some error in LH cost RDB'
	report+='<br>'

	abc=MIMEText(report.encode('utf-8'),'html')
	msg.attach(abc)
	# part = MIMEBase('application', "octet-stream")
	# part.set_payload( open(filepath,"rb").read() )
	# encoders.encode_base64(part)
	# part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
	# msg.attach(part)
	  
	server=smtplib.SMTP('smtp.sendgrid.net', 587)
	server.ehlo()
	server.starttls()
	server.ehlo()
	server.login("spoton.net.in", "Star@123#")
	failed = server.sendmail(FROM, TO, msg.as_string())
	server.quit()

# # # #send_email(["ankit@iepfunds.com","supratim@iepfunds.com","krishna.chandrasekar@spoton.co.in","pawan.sharma@spoton.co.in","satya.pal@spoton.co.in","vishwas.j@spoton.co.in","abhik.mitra@spoton.co.in"])

