
# coding: utf-8

# In[ ]:

import pandas as pd
from datetime import datetime, timedelta
import glob
import numpy as np

import os
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from pandas import ExcelWriter
from email import encoders

import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
import ftplib
import traceback
import Utilities


# In[ ]:
try:

    etadataquery = ("""
           SELECT  RGALPH ,
                    REASSIGN_DESTCD ,
                    brnm ,
                    DEPOT_CODE ,
                    ControlArea ,
                    CASE ISNULL(DESTlo.ISODA, 0)
                      WHEN 1 THEN 'ODA'
                      ELSE 'STD'
                    END AS [DESTLOCTYPE] ,
                    DESTLO.PinCode ,
                    CASE ISNULL(APPLYVTC, 0)
                      WHEN 1 THEN 'YES'
                      ELSE 'NO'
                    END VTC ,
                    CASE WHEN PAYBAS = '4' THEN 'YES'
                         ELSE 'NO'
                    END FTC ,
                    CONVERT(DATE, ETADATE) ETADATE ,
                    DOCKNO ,
                    --PKGSNO ,
                    --ACTUWT ,
                    CSGNCD ,
                    CSGNNM ,
                    CSGECD ,
                    CSGENM ,
                    Cast(CBS.[Customer Code] as INT) AS [Customer Code],
                    CBS.[Customer Name] ,
                    DOCKDT ,
                    CONVERT(DATE, CDELDT) CDELDT ,
                    DOC_CURLOC CURR_BRANCHCODE ,
                    DATEDIFF(DAY, CDELDT, ETADate) DELAY_DAYS ,
                    B.ACTUWT , 
                    B.PKGSNO ,
                    ACTUWT / 1000 AS "Weight IN TONS"
            FROM    dbo.tblETAData A WITH ( NOLOCK )
                    INNER JOIN dbo.DOCKET B WITH ( NOLOCK ) ON a.ConNo = B.DOCKNO
                    INNER JOIN dbo.brms C ON B.REASSIGN_DESTCD = C.BRCD
                    LEFT JOIN TBLLOCATIONMST DESTLO WITH ( NOLOCK ) ON B.DESTNLOCID = DESTLO.locationid
                    LEFT OUTER JOIN dbo.Con_BalanceSheet_Sales CBS WITH (NOLOCK) ON A.ConNo = CBS.[Con Number]
            WHERE   DOCKDT >= '2015-04-01'
                    AND REASSIGN_DESTCD <> DOC_CURLOC
                    AND ETADate BETWEEN CAST(CONVERT(VARCHAR, DATEADD(DAY, 1,
                                                                  GETDATE()), 112) AS SMALLDATETIME)
                                AND     CAST(CONVERT(VARCHAR, DATEADD(DAY, 2,
                                                                  GETDATE()), 112) AS SMALLDATETIME)
           """)


    # In[ ]:

    etaallstock = pd.read_sql(etadataquery, Utilities.cnxn)


    # In[ ]:

    #etaallstock=etaallstock[etaallstock['REASSIGN_DESTCD']=='DELM']


    # In[ ]:

    def datestring(x):
        try:
            #x = str(x)
            fulldate = datetime.strptime(x,'%d/%m/%Y')
            return fulldate
        except:
            #x = str(x)
            fulldate = datetime.strptime(x,'%Y-%m-%d')
            return fulldate


    # In[ ]:

    etaallstock['CDELDT'] = etaallstock.apply(lambda x: datestring(x['CDELDT']), axis=1)
    etaallstock['PinCode'] = etaallstock.apply(lambda x: float(x['PinCode']), axis=1)


    # In[ ]:

    datetoday = datetime.today()
    datefilter = datetoday-timedelta(hours=72)
    datefilter=datefilter.date()
    print datefilter


    # In[ ]:

    etastock_SCs = etaallstock[etaallstock['CDELDT']>=datefilter]
    print len(etastock_SCs)


    # In[ ]:

    pmd_sep = pd.read_csv(r'D:\Data\PMD_Save\PMD_2018-04-28.csv')
    pmdsep1 = pmd_sep[['BRANCH_CODE2','PINCODE2','CUSTOMERCODE','CUSTOMERNAME','PUD_CODE2','PUD_NAME2','PUDTYPE2','ACT_WT2','TYP2']]
    pmd_aug = pd.read_csv(r'D:\Data\PMD_Save\PMD_2018-05-31.csv')
    pmdaug1 = pmd_aug[['BRANCH_CODE2','PINCODE2','CUSTOMERCODE','CUSTOMERNAME','PUD_CODE2','PUD_NAME2','PUDTYPE2','ACT_WT2','TYP2']]
    pmd_july = pd.read_csv(r'D:\Data\PMD_Save\PMD_2018-06-30.csv')
    pmdjuly1 = pmd_july[['BRANCH_CODE2','PINCODE2','CUSTOMERCODE','CUSTOMERNAME','PUD_CODE2','PUD_NAME2','PUDTYPE2','ACT_WT2','TYP2']]
    len(pmdsep1), len(pmdaug1), len(pmdjuly1)


    # In[ ]:

    pmdappend = pmdsep1.append(pmdaug1)
    pmd0 = pmdappend.append(pmdjuly1)
    len(pmd0)


    # In[ ]:

    pmd0=pmd0[pmd0['TYP2']=='DLV']


    # In[ ]:

    #pmd0[(pmd0['PINCODE2']==110064) & (pmd0['CUSTOMERCODE']==120149.0) & (pmd0['PUD_NAME2']=='MUKESH SHARMA  (STD)')]


    # In[ ]:

    len(pmd0)


    # In[ ]:

    pivot=pmd0.pivot_table(index=['BRANCH_CODE2','PINCODE2','CUSTOMERCODE','PUD_NAME2'],values=['ACT_WT2'],aggfunc={'ACT_WT2':sum}).reset_index()


    # In[ ]:

    pivot1=pivot.sort_values('ACT_WT2',ascending=False)


    # In[ ]:

    pivot1['primary_key'] = pivot1.apply(lambda x:x['BRANCH_CODE2']+'-'+str(x['PINCODE2'])+str('-')+str(x['CUSTOMERCODE']),axis=1)


    # In[ ]:

    pivot2=pivot1.drop_duplicates(subset='primary_key', keep='first')


    # In[ ]:

    etastock_SCs.rename(columns={'PinCode':'PINCODE2','Customer Code':'CUSTOMERCODE','REASSIGN_DESTCD':'BRANCH_CODE2'},inplace=True)


    # In[ ]:

    etastock_SCs=pd.merge(etastock_SCs,pivot2,on=['BRANCH_CODE2','PINCODE2','CUSTOMERCODE'],how='left')


    # In[ ]:

    import math
    def getPincode(pudname,pincode):
        if pd.isnull(pudname):
            return pincode
        else:
            return pudname


    # In[ ]:

    etastock_SCs['PUD_NAME']=etastock_SCs.apply(lambda x: getPincode(x['PUD_NAME2'],x['PINCODE2']),axis=1)


    # In[ ]:

    etastock_SCs_pivot=etastock_SCs.pivot_table(index=['ControlArea','BRANCH_CODE2','PINCODE2','CUSTOMERCODE','PUD_NAME'],values=['DOCKNO','ACTUWT'],
                                               aggfunc={'DOCKNO':len,'ACTUWT':sum}).reset_index()


    # In[ ]:

    datefilter = datetime.today()
    datefiltermonday = (datetime.today() + timedelta(hours=48)).date()
    datefilter=datefilter.date()
    datefilter


    # In[ ]:

    #etastock_SCs
    etastock_SCs.to_csv(r'D:\Data\Monday_planning\Data\Condata_'+str(datefilter)+'.csv')
    etastock_SCs.to_csv(r'D:\Data\Monday_planning\Condata.csv')


    # In[ ]:

    grp_pivot=etastock_SCs_pivot.pivot_table(index=['BRANCH_CODE2','PUD_NAME'],values=['DOCKNO','ACTUWT'],
                                            aggfunc={'DOCKNO':len,'ACTUWT':sum}).reset_index()


    # In[ ]:

    grp_pivot['Wt(T)']=pd.np.round(grp_pivot['ACTUWT']/1000,1)


    # In[ ]:

    grp_pivot=grp_pivot.drop('ACTUWT',axis=1)


    # In[ ]:

    grp_pivot=grp_pivot.sort_values(['BRANCH_CODE2','Wt(T)'],ascending=[True,False])


    # In[ ]:

    grp_pivot = grp_pivot[grp_pivot['PUD_NAME']!='MARKET']
    grp_pivot = grp_pivot[grp_pivot['PUD_NAME']!='COUNTER']


    # In[ ]:

    #grp_pivot
    grp_pivot.to_csv(r'D:\Data\Monday_planning\Summary\ETA_Cons_Summary_'+str(datefilter)+'.csv')
    grp_pivot.to_csv(r'D:\Data\Monday_planning\ETA_Cons_Summary.csv')


    # In[ ]:

    oppathsummary = r'D:\Data\Monday_planning\ETA_Cons_Summary.csv'


    # In[ ]:

    oppathdata = r'D:\Data\Monday_planning\Condata.csv'


    # In[ ]:

    print ('Logging in...')
    ftp = ftplib.FTP()
    ftp.connect('10.109.230.50')
    print (ftp.getwelcome())
    try:
        try:
            ftp.login('IEPROJECTUSER', 'spotStar@123')
            ftp.cwd('ETA')
            # move to the desired upload directory
            print ("Currently in:", ftp.pwd())
            print ('Uploading...')
            fullname = oppathdata
            name = os.path.split(fullname)[1]
            f = open(fullname, "rb")
            ftp.storbinary('STOR ' + name, f)
            f.close()
            print ("OK"  )
            print ("Files:")
            print (ftp.retrlines('LIST'))
        finally:
            print ("Quitting...")
            ftp.quit()
    except:
        traceback.print_exc()


    # In[ ]:

    filePath = oppathsummary
    def sendEmail(TO = ["aom_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in"],
                #TO = ["mahesh.reddy@spoton.co.in"],
                #CC = ["mahesh.reddy@spoton.co.in"],
                CC = ["Abhik.Mitra@Spoton.Co.In","Pawan.Sharma@Spoton.Co.In","Jothi.Menon@Spoton.Co.In","sq_spot@spoton.co.in"],
                BCC = ["mahesh.reddy@spoton.co.in"],
                FROM="reports.ie@spoton.co.in"):
        HOST = "smtp.spoton.co.in"
    #smtplib.SMTP('smtp.spoton.co.in', 25)

        msg = MIMEMultipart()
        msg["From"] = FROM
        msg["To"] = ",".join(TO)
        msg["CC"] = ",".join(CC)
        msg["BCC"] = ",".join(BCC)
        msg["Subject"] = "Expected Load for Monday Planning" + " - " + str(datefilter)
        body_text = """
        Dear All,

        PFA the Expected Load for Monday Planning report as on """ + str(datefilter) +"""
        
        This reports contains details of cons which is expected to reach Destinaton SC by """+str(datefiltermonday)+"""
        
        Routewise data is available in the attachment. This data to be used for Monday planning. 

        For the conwise data, Please use the link below
        
        http://spoton.co.in/downloads/IEProjects/ETA/Condata.csv
        
        """

        if body_text:
            msg.attach( MIMEText(body_text) )
        part = MIMEBase('application', "octet-stream")
        part.set_payload( open(filePath,"rb").read() )
        Encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
        msg.attach(part)
        #server=smtplib.SMTP('124.7.138.249', 587)
        server=smtplib.SMTP('smtp.sendgrid.net', 587)
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login("spoton.net.in", "Star@123#")

        try:
            failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
            server.close()
        except Exception, e:
            errorMsg = "Unable to send email. Error: %s" % str(e)

    if __name__ == "__main__":
        sendEmail()
    print('Email sent')

except:
  TO=['mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  #msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "ERROR Report" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in Expected Load for Monday Planning.'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO, msg.as_string())
  server.quit()



# In[ ]:



