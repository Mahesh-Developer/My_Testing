
# coding: utf-8

# In[ ]:

import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta
import sys
import datetime
import sys
import Utilities
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os


# In[ ]:

querydate=date.today()
querydate


# In[ ]:
# cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")

query2=("""EXEC USP_UCG_GET_LETTERS_REPORT 'ALL','ALL','ALL','2018-01-01','{0}','3','ALL'  """.format(querydate))

ucg_df=pd.read_sql(query2,Utilities.cnxn)
print (len(ucg_df))
query1=("""EXEC USP_UCG_GET_LETTERS_REPORT 'ALL','ALL','ALL','2018-01-01','{0}','ALL','ALL'  """.format(querydate))


df=pd.read_sql(query1,Utilities.cnxn)
    

# In[ ]:

ucg_df.to_csv(r'D:\Data\UCG\UCG_Data.csv')
df.to_csv(r'D:\Data\UCG\UCG_Final_Data.csv')
filepath3=r'D:\Data\UCG\UCG_Data.csv'
filepath4=r'D:\Data\UCG\UCG_Final_Data.csv'


# In[ ]:

import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback
for i in [filepath3,filepath4]:
    oppath1=i
    #FTP Upload starts
    print ('Logging in...')
    ftp = ftplib.FTP()  
    ftp.connect('10.109.230.50')  
    print (ftp.getwelcome())
    try:  
        try:  
            ftp.login('HOSQTeam', 'Te@mH0$q')
            print ('login done')
            ftp.cwd('Auto_reports')  
            #ftp.cwd('FIFO')
            # move to the desired upload directory  
            print ("Currently in:", ftp.pwd()) 
            print ('Uploading...')  
            fullname = oppath1
            name = os.path.split(fullname)[1]  
            f = open(fullname, "rb")  
            ftp.storbinary('STOR ' + name, f)  
            f.close()  
            print ("OK"  )
            print ("Files:")  
            print (ftp.retrlines('LIST'))
        finally:  
            print ("Quitting...")
            ftp.quit()  
    except:  
        traceback.print_exc()


# In[ ]:

from_addr = 'mis.ho@spoton.co.in'
#to_addr = ['anitha.thyagarajan@spoton.co.in']
#cc_addr = ['anitha.thyagarajan@spoton.co.in']
bcc_addr = ['mahesh.reddy@spoton.co.in','anitha.thyagarajan@spoton.co.in','shravani.g@spoton.co.in']

username = 'mis.ho@spoton.co.in'
password = 'Spot@123'

msg = MIMEMultipart()

msg['From'] = from_addr
# msg['To'] = ', '.join(to_addr)
#msg['cc'] = ', '.join(cc_addr)
msg['bcc'] = ', '.join(bcc_addr)
msg['Subject'] = 'UCG - Data'
html='''<html>
<h4>Dear All</h4>
<p>Please find the attached UCG Data .</p>
</html>'''
html3='''
<h5> Note : For data please open below link.</h5>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/UCG_Data.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/UCG_Data.csv</p></b>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/UCG_Final_Data.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/UCG_Final_Data.csv</p></b>

'''
html1='''<h5>Thanks & Regards</h5></b>
<h5>HO-SQ</h5>'''

#  msg.attach(part10)

report=""
report+=html
report+='<br>'
report+=html3
report+='<br>'
report+=html1
abc=MIMEText(report,'html')
msg.attach(abc)
server = smtplib.SMTP('smtp.spoton.co.in',587)
part=MIMEBase('application','octet-stream')
# part1=MIMEBase('application','octet-stream')
#part.set_payload(open(filepath,'rb').read())
# part1.set_payload(open(filepath1,'rb').read())
#encoders.encode_base64(part)
# Encoders.encode_base64(part1)
#part.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath))
# part1.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath1))
#msg.attach(part)
# msg.attach(part1)
server.ehlo()
server.starttls()
server.ehlo()
server.login('mis.ho@spoton.co.in','Mis@2019')
server.sendmail(from_addr,bcc_addr,msg.as_string())
print ('mail sent succesfully')
server.quit()


# In[ ]:



