
# coding: utf-8

# In[ ]:

import pandas as pd
import numpy as np
import pyodbc
from datetime import datetime,timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
import ftplib
# import Utilities
from calendar import monthrange
import smtplib


# In[ ]:

cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()


# In[ ]:

startdate=datetime.strftime((datetime.now()-timedelta(days=1)).replace(day=1),"%Y-%m-%d")
startdate
enddate=datetime.strftime(datetime.now()-timedelta(days=1),"%Y-%m-%d")
enddate1=datetime.strftime(datetime.now()-timedelta(days=1),"%d/%m/%Y")

enddate,enddate1


# In[ ]:

query=("""SELECT  DT.DOCKNO ,
        CONVERT(VARCHAR(10), DT.DOCKDT, 103) BookingDate ,
        DT.ORGNCD ,
        DT.DESTCD ,
        DT.PKGSNO ,
        PC.PcsNo ,
        PH.SheetType ,
        PH.SheetNo ,
        PH.SCCode ,
        PC.scanTime ,
        PH.RequestDate ,
        PH.FinalSubmitDate ,
        CONVERT(VARCHAR(10), DD.DELY_DT, 103) DeliveryDate ,
        ISNULL(PC.excepType, '-') excepType
FROM    dbo.DKT_DELY DD WITH ( NOLOCK )
        INNER JOIN dbo.DOCKET DT WITH ( NOLOCK ) ON DT.DOCKNO = DD.DOCKNO
        INNER JOIN dbo.tblPLTAPICONDtls TC WITH ( NOLOCK ) ON TC.ConNo = DT.DOCKNO
        INNER JOIN dbo.tblPLTAPIPcsDtls PC WITH ( NOLOCK ) ON PC.ConNo = TC.ConNo
                                                              AND PC.PLTHDRID = TC.PLTHDRID
        INNER JOIN dbo.tblPLTAPIHDR PH WITH ( NOLOCK ) ON PH.AutoID = TC.PLTHDRID
WHERE    DD.DELY_DT IS NOT NULL
        AND DD.DELY_DT BETWEEN '{0}'
                       AND     '{1}'
        AND PH.SheetType IN ( 'UT', 'DT' )
              --AND pc.excepType='PPS'
              """).format(startdate,enddate)


# In[ ]:

df=pd.read_sql(query,cnxn)


# In[ ]:

len(df)


# In[ ]:

mtdshortage_data=df[df['excepType']=='PPS']
len(mtdshortage_data)


# In[ ]:

mtdshortage_data.to_csv(r'D:\Data\Daily_Alok_PLT_Report\Shortage\Shortage.csv')


# In[ ]:

df['Type']='MTD'


# In[ ]:

##yester day summary


# In[ ]:

yestdf=df[df['DeliveryDate']==enddate1]
len(yestdf)


# In[ ]:

yestdfsummary=yestdf.pivot_table(index=['DESTCD','DOCKNO'],aggfunc={'PKGSNO':len}).reset_index()


# In[ ]:

yestdelsummary=yestdfsummary.pivot_table(index=['DESTCD'],aggfunc={'DOCKNO':len}).reset_index()


# In[ ]:

yestdfshort=yestdf[yestdf['excepType']=='PPS']


# In[ ]:

len(yestdfshort)


# In[ ]:

yestdfshortsummary=yestdfshort.pivot_table(index=['DESTCD','DOCKNO','SCCode'],aggfunc={'PKGSNO':len}).reset_index()


# In[ ]:

yestdfshortsummary


# In[ ]:

len(yestdfshortsummary)


# In[ ]:

if len(yestdfshortsummary)>0:   
    yestshortsummary=yestdfshortsummary.pivot_table(index=['DESTCD','SCCode'],aggfunc={'DOCKNO':len}).reset_index()
    yestshortsummary.rename(columns={'DOCKNO':'Shortage_Cons','SCCode':'Short_Location'},inplace=True)
else:
    yestshortsummary=pd.DataFrame({'DESTCD':[]})


# In[ ]:




# In[ ]:

yestdelsummary.rename(columns={'DOCKNO':'Delivered_Cons'},inplace=True)


# In[ ]:

yestsummary=pd.merge(yestdelsummary,yestshortsummary,on='DESTCD',how='outer')


# In[ ]:

yestsummary=yestsummary.fillna(0)


# In[ ]:

if 'Shortage_Cons' in yestsummary.columns.tolist():
    pass
else:
    yestsummary['Shortage_Cons']=0


# In[ ]:

yestsummary['Short_Locations']=yestsummary.apply(lambda x:{x['Short_Location']:x['Shortage_Cons']},axis=1)


# In[ ]:

yestsummary


# In[ ]:

yestsummary['Shortage(%)']=pd.np.round(yestsummary['Shortage_Cons']*100.0/yestsummary['Delivered_Cons'],0)


# In[ ]:

yestsummary.sort_values('Shortage(%)',ascending=False,inplace=True)


# In[ ]:

yestsummary=yestsummary[yestsummary['Shortage_Cons']>0]
yestsummary


# In[ ]:

##MTD summary


# In[ ]:

mtddfsummary=df.pivot_table(index=['DESTCD','DOCKNO'],aggfunc={'PKGSNO':len}).reset_index()


# In[ ]:

mtddelsummary=mtddfsummary.pivot_table(index=['DESTCD'],aggfunc={'DOCKNO':len}).reset_index()


# In[ ]:

mtddfshort=df[df['excepType']=='PPS']


# In[ ]:

len(mtddfshort)


# In[ ]:

mtddfshortsummary=mtddfshort.pivot_table(index=['DESTCD','DOCKNO','SCCode'],aggfunc={'PKGSNO':len}).reset_index()


# In[ ]:

mtdshortsummary=mtddfshortsummary.pivot_table(index=['DESTCD','SCCode'],
                                              aggfunc={'DOCKNO':len}).reset_index()


# In[ ]:

mtdshortsummary['Shortage_Locations']=mtdshortsummary.apply(lambda x:{x['SCCode']:x['DOCKNO']},axis=1)


# In[ ]:

finaccfdfgrp = mtdshortsummary.groupby('DESTCD')['Shortage_Locations'].apply(lambda x: x.values).reset_index() 


# In[ ]:

mtdshortsummary1=mtddfshortsummary.pivot_table(index=['DESTCD'],
                                              aggfunc={'DOCKNO':len}).reset_index()


# In[ ]:

mtdshortsummary1=pd.merge(mtdshortsummary1,finaccfdfgrp,how='outer',on='DESTCD')


# In[ ]:

mtdshortsummary.rename(columns={'DOCKNO':'Shortage_Cons'},inplace=True)


# In[ ]:

mtddelsummary.rename(columns={'DOCKNO':'Delivered_Cons'},inplace=True)


# In[ ]:

mtdsummary=pd.merge(mtddelsummary,mtdshortsummary,on='DESTCD',how='outer')


# In[ ]:

mtdsummary=mtdsummary.fillna(0)


# In[ ]:

mtdsummary['Shortage(%)']=pd.np.round(mtdsummary['Shortage_Cons']*100.0/mtdsummary['Delivered_Cons'],0)


# In[ ]:

mtdsummary=mtdsummary[mtdsummary['Shortage_Cons']>0]
mtdsummary


# In[ ]:

mtdsummary.sort_values('Shortage(%)',ascending=False,inplace=True)


# In[ ]:

del mtdsummary['SCCode']


# In[ ]:

mtdsummary


# In[ ]:

yestsummary.to_csv(r'D:\Data\Daily_Alok_PLT_Report\Shortage\Yst_Shortage_Summary.csv')
mtdsummary.to_csv(r'D:\Data\Daily_Alok_PLT_Report\Shortage\MTD_Shortage_Summary.csv')


# In[ ]:

filepath=r'D:\Data\Daily_Alok_PLT_Report\Shortage\Yst_Shortage_Summary.csv'
filepath1=r'D:\Data\Daily_Alok_PLT_Report\Shortage\MTD_Shortage_Summary.csv'
filepath2=r'D:\Data\Daily_Alok_PLT_Report\Shortage\Shortage.csv'


# In[ ]:

todate=datetime.strftime(datetime.now(),"%Y-%m-%d")
todate


# In[ ]:
TO=['mahesh.reddy@spoton.co.in']
CC=['mahesh.reddy@spoton.co.in']


# TO=['mahesh.reddy@spoton.co.in',"alok.b@spoton.co.in"]
# CC=['satya.pal@spoton.co.in','abhik.mitra@spoton.co.in','shivananda.p@spoton.co.in']

FROM="reports.ie@spoton.co.in"
# FROM="mahesh.reddy@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "Daily Cons Shortage Summary " + " - " + str(todate)

report=""
report+="Dear All,"
report+='<br>'
report+='Please find the Cons shortage for (YST & MTD)'
report+='<br>'
report+='In Mail body showing top 15 locations. '
report+='<br>'
report+='YST Summary'
report+='<br>'
report+='<br>'+yestsummary.head(15).to_html()+'<br>'
report+='<br>'
report+='MTD Summary'
report+='<br>'
report+='<br>'+mtdsummary.head(15).to_html()+'<br>'
report+='<br>'

abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(filepath1,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
msg.attach(part1)

part2 = MIMEBase('application', "octet-stream")
part2.set_payload( open(filepath2,"rb").read() )
encoders.encode_base64(part2)
part2.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath2))
msg.attach(part2)


# server=smtplib.SMTP('smtp.sendgrid.net', 587)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("mahesh.reddy@spoton.co.in", "Nov@2018")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()


# In[ ]:

exit(0)


# In[ ]:



