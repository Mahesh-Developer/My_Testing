
# coding: utf-8

# In[1]:

import pandas as pd
import numpy as np
import datetime
from datetime import date, timedelta
import glob
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import os
import sys
from email import encoders
reload(sys)
sys.setdefaultencoding("UTF8")

"""
def save_xls(list_dfs, name_dfs, xls_path):
   i = 0
   writer = ExcelWriter(xls_path)   
   for dataframe in list_dfs:
       sheetname = name_dfs[i]
       dataframe.to_excel(writer, sheetname, merge_cells = False)
       i = i+1
   writer.save()
"""

path =r'D:\Data\eta_rank\eta_folder_rankfiles' # use your path
allFiles = glob.glob(path + "/*.csv")
frame = pd.DataFrame()
list_ = []
for file_ in allFiles:
    df = pd.read_csv(file_,index_col=None, header=0)
    list_.append(df)
frame = pd.concat(list_)
frame.to_csv(r'D:\Data\eta_rank\HighRisk_Intransit\Combined_for_depsintransit.csv')

# In[2]:

#depsdf = pd.io.excel.read_excel('http://10.109.230.50/downloads/DOCKSCORE/DOCK_SCORE_REPORT.xls ','SalesScoreRpt')
depsdf = pd.read_csv('http://10.109.230.50/downloads/DOCKSCORE/DOCK_SCORE_REPORT.csv')
cons = pd.read_csv(r'D:\Data\eta_rank\HighRisk_Intransit\Combined_for_depsintransit.csv')


# In[3]:

#a=datetime.datetime.strptime('07/10/2015','%d/%m/%Y')
#b=datetime.datetime.strptime('09/10/2015','%d/%m/%Y')
a = datetime.datetime.now()
b = a - timedelta(hours=34)

# In[4]:

conspivot = pd.pivot_table(cons, index = ['Con Number_x','Hub SC Location','Delaydays','ActionHrs','TIMESTAMP','HrsAfterArr'], values = ['Rank'], aggfunc = 'count').reset_index()
conspivot.columns = ['Con_No','Location','Delaydays','AH','Ts','HrsAfterArr','Rank']


# In[5]:

conspivot['Ts2'] = conspivot['Ts'].apply(lambda x: datetime.datetime.strptime(x.split('.')[0],'%Y-%m-%d %H:%M:%S'))
conspivot = conspivot[conspivot['Ts2']<a]
conspivot = conspivot[conspivot['Ts2']>b]
conspivot


# In[6]:

ix2 = conspivot[conspivot['Delaydays']>0].index
condelayspivot = conspivot.loc[ix2]
condelays = pd.pivot_table(condelayspivot, index = ['Con_No','Delaydays'], values = 'Ts2', aggfunc = 'max').reset_index()
delaygraph = pd.merge(condelays,condelayspivot,left_on = ['Con_No','Delaydays','Ts2'], right_on = ['Con_No','Delaydays','Ts2'], how = 'inner')
delaygraph.loc[delaygraph.index,'Status'] = 'Inventory'
ix3 = delaygraph[delaygraph['HrsAfterArr']<=2].index
delaygraph.loc[ix3,'Status'] = 'Linehaul'


# In[7]:

mergedeps = pd.merge(delaygraph,depsdf,left_on=['Con_No'],right_on=['DOCKNO'], how = 'inner')



# In[23]:

#print mergedeps['ScoreValue'].describe()
###$$$probcutoff=mergedeps['ScoreValue'].quantile(0.75)
probcutoff = 0.8

# In[24]:

mergedeps=mergedeps[mergedeps['ScoreValue']>=probcutoff]


# In[25]:

depspivot=pd.pivot_table(mergedeps,index= ['DOCKNO','Location'],values=['Delaydays'],aggfunc='count').reset_index()



# In[26]:
depspivot=depspivot.rename(columns={'Delaydays':'Count of Slips'})
depspivotmt1 = depspivot[depspivot['Count of Slips']>1].sort_values('Count of Slips',ascending=False)
depspivotmt2 = depspivotmt1.sort_values(['Count of Slips','Location'],ascending=[False,True])
##rajeesh edit
con_tspivot = pd.pivot_table(cons, index = ['Con Number_x'], values = ['TIMESTAMP'], aggfunc = 'max').reset_index()
contsdepsscore = pd.merge(depspivotmt2,con_tspivot,left_on=['DOCKNO'],right_on=['Con Number_x'], how = 'inner')
basedata = pd.merge(cons,contsdepsscore,left_on=['Con Number_x', 'TIMESTAMP'],right_on=['DOCKNO','TIMESTAMP'], how = 'inner')
columnsop=['DOCKNO','Hub SC Location','HrsAfterArr','Account Code','Account Name','Act Wt In Tonnes','Arrival Date Hub','Booking Date','Del Location Type','Origin Branch','Destn Branch','Due Date','Latest Status','Latest Status Branch','Latest Status Category','Latest Status Code','Latest Status Date','Latest Status Reason','No Of Packages','Volume','Count of Slips','TIMESTAMP']
basedatareqcols=pd.DataFrame(basedata,columns=columnsop)


##rajeesh edit


#depslocpivot=pd.pivot_table(mergedeps,index= ['Location'],values=['Delaydays','DOCKNO'],aggfunc='count').reset_index()
#depslocpivot1=depslocpivot[depslocpivot['Delaydays']>1].sort_values('Delaydays',ascending=False)
depslocpivot1 = pd.pivot_table(depspivotmt1, index= ['Location'], values=['DOCKNO'], aggfunc='count').reset_index()
print depslocpivot1['DOCKNO'].values[0], type(depslocpivot1['DOCKNO'].values[0])
depslocpivot1 = depslocpivot1.sort_values('DOCKNO',ascending=False)
depslocpivotmail=depslocpivot1.head(15)
depslocpivotmail=depslocpivotmail.to_string(index=False)

ts= datetime.datetime.now()
opfilevar=ts.date()
opfilevar1=ts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=np.ceil(float(currhrs)/60)

print 'opfilevar,opfilevar2',opfilevar,opfilevar2

# In[28]:
oppath1=r'D:\Data\eta_rank\HighRisk_Intransit\High_risk_DEPS_Intransit'+'-'+str(opfilevar)+'-'+str(opfilevar2)+'.xlsx'
#mergepivot.to_csv(r'C:\Data\DEPS_Pred_061015\High_risk_DEPS_DESTSC_Pivot.csv',encoding='utf-8')
"""
printlist =  [depspivotmt2,depslocpivot1,basedatareqcols]
namelist = ['Data','Summary','BaseData']
save_xls (printlist, namelist, oppath1)
 """

with ExcelWriter(r'D:\Data\eta_rank\HighRisk_Intransit\High_risk_DEPS_Intransit'+'-'+str(opfilevar)+'-'+str(opfilevar2)+'.xlsx') as writer:
    ###orginal_cancel_basedata.to_excel(writer, sheet_name='Sheet1',engine='xlsxwriter')
    depspivotmt2.to_excel(writer, sheet_name='Data',engine='xlsxwriter')
    depslocpivot1.to_excel(writer, sheet_name='Summary',engine='xlsxwriter')
    basedatareqcols.to_excel(writer, sheet_name='BaseData',engine='xlsxwriter')
       
filePath = oppath1
def sendEmail(TO = ['sq_spot@spoton.co.in',"shivananda.p@spoton.co.in","trilochan.panda@spoton.co.in","ashwani.gangwar@spoton.co.in","HUBMGR_SPOT@spoton.co.in","krishna.kumar.bhardwaj@spoton.co.in","chandrima.banerjee@spoton.co.in"],
            #TO = ["rajeesh.vr@spoton.co.in"],
            #TO = ["vishwas.j@spoton.co.in"],
            #CC = ["vishwas.j@spoton.co.in"],
            CC = ["sqtf@spoton.co.in","mahesh.reddy@spoton.co.in","rajeesh.vr@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "High Risk DEPS Cons with Multiple Delays - In Network" + " - " + str(opfilevar)+ " - " +str(opfilevar2)
    body_text = """
    
    Dear All,

    This report shows the cons which got delayed multiple (ETA Slips) times at a given location and has a high probability of being DEPS. 
    The attachment contains the details of the cons and their respective locations which caused the delays

    PFB a summary of the report which shows no of cons that had multiple slips at a location. 

    
    """+ str(depslocpivotmail) +"""

    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')

#Sending output file via mail ends









# In[ ]:




# In[ ]:



