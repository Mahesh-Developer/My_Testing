
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd

from IPython import display
from datetime import datetime
from datetime import datetime,timedelta
from datetime import datetime, timedelta
import smtplib
import ftplib
import traceback
import calendar
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template
import pyodbc
import Utilities


# In[2]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.231.28;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")


# In[3]:


query=("USP_PUD_YEST_MTD_DATA 'M'")


# In[4]:


df=pd.read_sql(query,Utilities.cnxn)


# In[5]:


len(df)


# In[6]:


df['Type']='MTD'


# In[7]:


air_df=df[df['PTYPE']=='AR']
len(air_df)


# In[8]:


m = {'Jan': '01','Feb': '02','Mar': '03','Apr':'04','May':'05','Jun':'06','Jul':'07','Aug':'08','Sep':'09','Oct':'10','Nov':'11','Dec':'12'}
def dateconv(date):
    dt = date.split(' ')[2]+'-'+str(m.get(date.split(' ')[1]))+'-'+date.split(' ')[0]
    #print (dt)
    return dt
air_df["DateOnly"]=air_df.apply(lambda x: dateconv(x["DATE"]),axis=1)


# In[9]:


yesterday=datetime.strftime(datetime.now()-timedelta(1),'%Y-%m-%d')
yesterday


# In[10]:


yest_df=air_df[air_df['DateOnly']==yesterday]
len(yest_df)


# In[11]:


del yest_df['Type']


# In[12]:


yest_df['Type']='YST'


# In[13]:


air_df=pd.concat([air_df,yest_df],ignore_index=True)


# In[14]:


air_df.rename(columns={'ACT_WT':'Wt','COST':'Cost','con_id':'Con'},inplace=True)


# In[48]:


summary=air_df.pivot_table(index=['TYP'],columns=['Type'],values=['Wt','Con','Cost'],aggfunc={'Wt':sum,'Con':len,'Cost':sum},margins=True).fillna(0)


# In[49]:


del summary['Con','All']
del summary['Cost','All']
del summary['Wt','All']


# In[50]:


summary


# In[51]:


summary[('CPK','MTD')]=summary[('Cost','MTD')]/summary[('Wt','MTD')]


# In[52]:


summary[('CPK','YST')]=summary[('Cost','YST')]/summary[('Wt','YST')]


# In[53]:


summary=summary.fillna(0)


# In[54]:


summary['CPK']=pd.np.round(summary['CPK'],1)


# In[55]:


# summary
summary=summary.swaplevel(0, 1, 1).sort_index(1)


# In[56]:


summary


# In[57]:


query1=("exec USP_PMD_LINEHAUL_DATA_30DAYS")


# In[58]:


linehal_df=pd.read_sql(query1,Utilities.cnxn)


# In[59]:


len(linehal_df)


# In[60]:


air_linehal_df=linehal_df[linehal_df['THCTYPE']=='AR']
len(air_linehal_df)


# In[61]:


air_linehal_df['Type']='MTD'


# In[62]:


air_linehal_df['DATE']=air_linehal_df['THC DATE'].dt.date


# In[63]:


air_linehal_df['DATE']=air_linehal_df['DATE'].astype(str)


# In[64]:


yestair_linehal_df=air_linehal_df[air_linehal_df['DATE']==yesterday]
len(yestair_linehal_df)


# In[65]:


del yestair_linehal_df['Type']


# In[66]:


yestair_linehal_df['Type']='YST'


# In[67]:


air_linehal_df=pd.concat([air_linehal_df,yestair_linehal_df],ignore_index=True)


# In[68]:


air_linehal_df.rename(columns={'THC NUMBER':"THC'"+'s','COST':'Cost','TOTAL ACTUAL LOAD':'Actual_Wt'},inplace=True)


# In[69]:


air_linehal_df.columns


# In[70]:


lh_summary=air_linehal_df.pivot_table(index=['Type'],aggfunc={"THC'"+'s':len,'Cost':sum,'Actual_Wt':sum})


# In[73]:


lh_summary['CPK']=pd.np.round(lh_summary['Cost']/lh_summary['Actual_Wt'],1)


# In[74]:


lh_summary


# In[75]:


air_df.to_csv(r'AirPMD.csv')
air_linehal_df.to_csv(r'LHAir.csv')


# In[76]:


filepath=r'AirPMD.csv'
filepath1=r'LHAir.csv'


# In[77]:


todate=datetime.strftime(datetime.now(),"%Y-%m-%d")
todate


# In[78]:


TO=["vishwas.j@spoton.co.in"]
CC= ["mahesh.reddy@spoton.co.in"]
# CC=["mahesh.reddy@spoton.co.in"]
FROM="reports.ie@spoton.co.in"

msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "Air Monitoring Report" + " - " + str(todate)
html='''<html>
<h4>Dear All,</h4>
<p>PFA the Air Monitoring Report for $date</p>
</html>'''
#s = Template(html).safe_substitute(date=yest_date)
report=""
report+="Dear All"
report+='<br>'
report+='<br>'
report+='PFB PMD Summary'
report+='<br>'+summary.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='PFB  Feeder summary'
report+='<br>'+lh_summary.to_html()+'<br>'
report+='<br>'
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(filepath1,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
msg.attach(part1)


# server=smtplib.SMTP('smtp.sendgrid.net', 587)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("spoton.net.in", "Star@123#")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()



