
# coding: utf-8

# In[1]:

import pandas as pd
import datetime
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import smtplib
import requests as req
import json
import os


# In[2]:

data=pd.read_csv(r'http://spoton.co.in/downloads/PMD/PMD.csv')
# data=pd.read_csv('PMD.csv')


# In[ ]:

# data.to_csv('PMD.csv')


# In[3]:

format1=pd.read_excel('D:\Python\Scripts and Files\Path and Graph Files\Fixed_pud_vehicle\goutam.xlsx')


# In[4]:

len(format1)


# In[5]:

data['DATE2']=data.apply(lambda x:datetime.datetime.strptime(x['DATE2'], '%d %b %Y %H:%M').strftime('%d'),axis=1)


# In[6]:

data=data[data['PUDTYPE2']=='FIXED']


# In[7]:

data.columns


# In[29]:

pivot=data.pivot_table(index=['DEPOT2','AREA2','BRANCH_CODE2','PUD_CODE2','PUD_NAME2','BAVEHNO','DATE2'],aggfunc={'CHRG_WT2':sum}).reset_index()


# In[30]:

len(pivot)


# In[31]:

abc=data.drop_duplicates(['DATE2','BAVEHNO'])


# In[32]:

len(abc)


# In[33]:

grp1=abc.pivot_table(index='BAVEHNO',aggfunc={'DATE2':len}).reset_index()


# In[34]:

# grp1=grp1.rename_axis({'BAVEHNO':'VEH. NO'},axis=1)


# In[35]:

abd=pd.merge(format1,grp1,left_on='VEH. NO',right_on='BAVEHNO',how='left')


# In[36]:

abd['CAP AS ON DT']=abd.apply(lambda x:x['VEH. CAP']*x['DATE2'],axis=1)


# In[37]:

total=data.pivot_table(index=['DEPOT2','AREA2','BRANCH_CODE2','PUD_CODE2','PUD_NAME2','BAVEHNO'],aggfunc={'CHRG_WT2':sum}).reset_index()


# In[38]:

total=total[['BAVEHNO','CHRG_WT2']]


# In[39]:

abd=pd.merge(abd,total,on='BAVEHNO',how='left')


# In[40]:

abd['CAP UTI AS ON DT']=abd.apply(lambda x: round((x['CHRG_WT2']/x['CAP AS ON DT'])*100),axis=1)


# In[41]:

del abd['DATE2']
del abd['BAVEHNO']
del abd['CHRG_WT2']


# In[42]:

vehcap=abd[['VEH. NO','VEH. CAP']]


# In[43]:

pivot=pd.merge(pivot,vehcap,left_on='BAVEHNO',right_on='VEH. NO',how='left')


# In[44]:

pivot['Utility']=pivot.apply(lambda x: round((x['CHRG_WT2']/x['VEH. CAP'])*100),axis=1)


# In[45]:

pivot1=pivot.pivot_table(index=['DEPOT2','AREA2','BRANCH_CODE2','PUD_CODE2','VEH. NO'],columns='DATE2',values='Utility').reset_index()


# In[46]:

final=pd.merge(abd,pivot1,on=['DEPOT2','AREA2','BRANCH_CODE2','PUD_CODE2','VEH. NO'],how='left')


# In[50]:

final=final.drop_duplicates(['DEPOT2','AREA2','BRANCH_CODE2','PUD_CODE2','VEH. NO'])


# In[52]:

# final.to_excel(r'D:\Python\Scripts and Files\Path and Graph Files\Fixed_pud_vehicl\finalreport.xlsx')
# from pandas import ExcelWriter
# with ExcelWriter(r'D:\Python\Scripts and Files\Path and Graph Files\Fixed_pud_vehicl\finalreport.xlsx') as writer:
#     final.to_excel(writer,engine='xlsxwriter',sheet_name='FIxed Summary')
final.to_excel(r'D:\Python\Scripts and Files\Path and Graph Files\Fixed_pud_vehicl\finalreport.xlsx')
# In[51]:

len(final)
filePath=r'D:\Python\Scripts and Files\Path and Graph Files\Fixed_pud_vehicl\finalreport.xlsx'

# In[ ]:

def sendEmail(#TO = ["hubmgr_spot@spoton.co.in","raghavendra.rao@spoton.co.in","cnm@spoton.co.in"],
            TO = ["shashvat.suhane@spoton.co.in"],
#             TO = ['krishna.chandrasekar@spoton.co.in'],
            CC = ["shashvat.suhane@spoton.co.in"],
            #CC = ["supratim@iepfunds.com","pawan.sharma@spoton.co.in","sqtf@spoton.co.in"],
            #BCC = ["vinayak.kumbhar@spoton.co.in","vinodkumar.mishra@spoton.co.in","nitin.tatyarao@spoton.co.in","kiran.pawar@spoton.co.in","jai.prakash@spoton.co.in","rajesh.mishra@spoton.co.in","ops.hub.idrh.1@spoton.co.in"] ,
            #BCC = ["vishwas.j@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["BCC"] = ",".join(BCC)
    msg["Subject"] = "Fixed Pud Vehicle"+str(datetime.datetime.today().date())+" "
    msgtext="""Dear All ,"""
    msg.attach( MIMEText(msgtext) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()

