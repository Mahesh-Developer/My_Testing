# -*- coding: utf-8 -*-
"""
Created on Sat Apr 23 09:32:45 2016

@author: rajeeshv
"""

import pandas as pd
from datetime import date, timedelta
from pandas import ExcelWriter

thcutildetails = pd.io.excel.read_excel('http://10.109.230.50/downloads/THC_LINEHAUL_DAILY_IEP/THC_LINEHAUL_DAILY_IEP.xls','THC_UTILIZATION_DETAILS')
thcutilheader = pd.io.excel.read_excel('http://10.109.230.50/downloads/THC_LINEHAUL_DAILY_IEP/THC_LINEHAUL_DAILY_IEP.xls','THC UTILIZATION HEADER')

datenow = date.today()
dateyest = datenow-timedelta(hours=24)
thcutildetails.loc[thcutildetails.index,'Date'] = dateyest
thcutilheader.loc[thcutilheader.index,'Date'] = dateyest


with ExcelWriter(r'D:\Data\Daily_linehaul_utilization_raw\Daily_linehaul_utilization_'+str(dateyest)+'.xlsx') as writer:
    thcutildetails.to_excel(writer, sheet_name='THC_UTILIZATION_DETAILS',engine='xlsxwriter')
    thcutilheader.to_excel(writer, sheet_name='THC UTILIZATION HEADER',engine='xlsxwriter')

thcutildetails.to_csv(r'D:\Data\Daily_linehaul_utilization_raw\THC_UTILIZATION_DETAILS\THC_UTILIZATION_DETAILS_'+str(dateyest)+'.csv',encoding='utf-8')
print 'Done 1'

thcutilheader.to_csv(r'D:\Data\Daily_linehaul_utilization_raw\THC_UTILIZATION_HEADER\THC_UTILIZATION_HEADER_'+str(dateyest)+'.csv',encoding='utf-8')
print 'Done 2'