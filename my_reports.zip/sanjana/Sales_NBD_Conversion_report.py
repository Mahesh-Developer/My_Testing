
# coding: utf-8

# In[1]:

import pandas as pd
from datetime import datetime,timedelta
import calendar
from pandas import ExcelWriter

import sys
from email import encoders
import traceback
import ftplib
import os
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText


# In[2]:

now = datetime.now()
yestday = now-timedelta(hours=24)
yestdate = yestday.date()


# In[3]:

###conversionleaddata = pd.read_csv(r'C:\Data\Customer_lead_management\Conversion_report\Conversion_report.csv')

conversionleaddata = pd.read_csv(r'http://spoton.co.in/downloads/CONVERSION_LEAD_REPORT/CONVERSION_LEAD_REPORT.csv')


# In[4]:

conversionleaddatatrading = conversionleaddata[conversionleaddata['TradingCustomer']=='Yes']


# In[5]:

def monthyearcalc(x):
    try:
        y = datetime.strptime(x,'%d-%m-%Y')
        year = y.year
    except:
        y = datetime.strptime(x,'%d/%m/%Y')
        year = y.year
    return y.strftime("%b")+'-'+str(year)
        

def monthcalc(x):
    try:
        y = datetime.strptime(x,'%d-%m-%Y').month
    except:
        y = datetime.strptime(x,'%d/%m/%Y').month
    return y

def yearcalc(x):
    try:
        y = datetime.strptime(x,'%d-%m-%Y').year
    except:
        y = datetime.strptime(x,'%d/%m/%Y').year
    return y


# In[6]:

conversionleaddatatrading = conversionleaddatatrading.rename(columns={'\xef\xbb\xbfRegion':'Region','Account_Code':'Account Code','Channel_Type':'Channel Type','Signing_Date':'Signing Date','Sales_Executive':'Sales Executive'})


# In[7]:

conversionleaddatatrading['Month_year'] = conversionleaddatatrading.apply(lambda x :monthyearcalc( x['Signing Date']),axis=1)

conversionleaddatatrading['Month'] = conversionleaddatatrading.apply(lambda x :monthcalc( x['Signing Date']),axis=1)
conversionleaddatatrading['Year'] = conversionleaddatatrading.apply(lambda x :yearcalc( x['Signing Date']),axis=1)


# ### Conversion Rep Analysis

# In[8]:

def percmtdpotential(mtdrev,revpotential):
    try:
        percrev = pd.np.round((mtdrev/revpotential)*100,0)
    except:
        percrev = 0
    return percrev


# In[9]:

#conversionleaddatatradingpivot = pd.pivot_table(conversionleaddatatrading,index=['Region','Month_year'],values=['Account Code','RevenuePotential','CurrMTDRevenue','CurrMonthMinus1Revenue','CurrMonthMinus2Revenue'],aggfunc={"Account Code":len,"RevenuePotential":sum,"CurrMTDRevenue":sum,"CurrMonthMinus1Revenue":sum,"CurrMonthMinus2Revenue":sum}).reset_index()
conversionleaddatatradinggrp = conversionleaddatatrading.groupby(['Region','Month','Year','Month_year']).agg({'Account Code':len,'RevenuePotential':sum,'CurrMTDRevenue':sum,'CurrMonthMinus1Revenue':sum,'CurrMonthMinus2Revenue':sum}).reset_index()  
conversionleaddatatradinggrp = conversionleaddatatradinggrp.sort_values(['Region','Year','Month'],ascending =True)
#conversionleaddatatradinggrp['%RevPotential_CurrMTDRev'] = pd.np.round(conversionleaddatatradinggrp.apply(lambda x:(x['CurrMTDRevenue']/x['RevenuePotential'])*100,axis=1),2)
conversionleaddatatradinggrp['%RevPotential_CurrMTDRev'] = conversionleaddatatradinggrp.apply(lambda x:percmtdpotential(x['CurrMTDRevenue'],x['RevenuePotential']),axis=1)
columnsop = ['Region','Month_year','Account Code','RevenuePotential','CurrMTDRevenue','%RevPotential_CurrMTDRev','CurrMonthMinus1Revenue','CurrMonthMinus2Revenue']
conversionleaddatatradinggrp = pd.DataFrame(conversionleaddatatradinggrp,columns=columnsop)


# ### REGIONWISE SUBTOTALS 

# In[10]:

conversionleaddatatradinggrpE = conversionleaddatatradinggrp[conversionleaddatatradinggrp['Region']=='East']
eastcodes = conversionleaddatatradinggrpE['Account Code'].sum()
eastmtdrev = conversionleaddatatradinggrpE['CurrMTDRevenue'].sum()
eastrevpotential = conversionleaddatatradinggrpE['RevenuePotential'].sum()
eastminus1rev = conversionleaddatatradinggrpE['CurrMonthMinus1Revenue'].sum()
eastminus2rev = conversionleaddatatradinggrpE['CurrMonthMinus2Revenue'].sum()
eastpercrevpot = pd.np.round((eastmtdrev/eastrevpotential)*100,0)

eastsumlist = ['East_Total','-','-','-',eastcodes,eastmtdrev,eastrevpotential,eastminus1rev,eastminus2rev,eastpercrevpot]
eastcol_list = ['Region','Month','Year','Month_year','Account Code','CurrMTDRevenue','RevenuePotential','CurrMonthMinus1Revenue','CurrMonthMinus2Revenue','%RevPotential_CurrMTDRev']
easttotals = pd.DataFrame(data=[eastsumlist], columns = eastcol_list)
conversionleaddatatradinggrpE = conversionleaddatatradinggrpE.append(easttotals,ignore_index=True)


conversionleaddatatradinggrpN = conversionleaddatatradinggrp[conversionleaddatatradinggrp['Region']=='North']
northcodes = conversionleaddatatradinggrpN['Account Code'].sum()
northmtdrev = conversionleaddatatradinggrpN['CurrMTDRevenue'].sum()
northrevpotential = conversionleaddatatradinggrpN['RevenuePotential'].sum()
northminus1rev = conversionleaddatatradinggrpN['CurrMonthMinus1Revenue'].sum()
northminus2rev = conversionleaddatatradinggrpN['CurrMonthMinus2Revenue'].sum()
northpercrevpot = pd.np.round((northmtdrev/northrevpotential)*100,0)

northsumlist = ['North_Total','-','-','-',northcodes,northmtdrev,northrevpotential,northminus1rev,northminus2rev,northpercrevpot]
northcol_list = ['Region','Month','Year','Month_year','Account Code','CurrMTDRevenue','RevenuePotential','CurrMonthMinus1Revenue','CurrMonthMinus2Revenue','%RevPotential_CurrMTDRev']
northtotals = pd.DataFrame(data=[northsumlist], columns = northcol_list)
conversionleaddatatradinggrpN = conversionleaddatatradinggrpN.append(northtotals,ignore_index=True)


conversionleaddatatradinggrpS = conversionleaddatatradinggrp[conversionleaddatatradinggrp['Region']=='South']
southcodes = conversionleaddatatradinggrpS['Account Code'].sum()
southmtdrev = conversionleaddatatradinggrpS['CurrMTDRevenue'].sum()
southrevpotential = conversionleaddatatradinggrpS['RevenuePotential'].sum()
southminus1rev = conversionleaddatatradinggrpS['CurrMonthMinus1Revenue'].sum()
southminus2rev = conversionleaddatatradinggrpS['CurrMonthMinus2Revenue'].sum()
southpercrevpot = pd.np.round((southmtdrev/southrevpotential)*100,0)

southsumlist = ['South_Total','-','-','-',southcodes,southmtdrev,southrevpotential,southminus1rev,southminus2rev,southpercrevpot]
southcol_list = ['Region','Month','Year','Month_year','Account Code','CurrMTDRevenue','RevenuePotential','CurrMonthMinus1Revenue','CurrMonthMinus2Revenue','%RevPotential_CurrMTDRev']
southtotals = pd.DataFrame(data=[southsumlist], columns = southcol_list)
conversionleaddatatradinggrpS = conversionleaddatatradinggrpS.append(southtotals,ignore_index=True)


conversionleaddatatradinggrpW = conversionleaddatatradinggrp[conversionleaddatatradinggrp['Region']=='West']
westcodes = conversionleaddatatradinggrpW['Account Code'].sum()
westmtdrev = conversionleaddatatradinggrpW['CurrMTDRevenue'].sum()
westrevpotential = conversionleaddatatradinggrpW['RevenuePotential'].sum()
westminus1rev = conversionleaddatatradinggrpW['CurrMonthMinus1Revenue'].sum()
westminus2rev = conversionleaddatatradinggrpW['CurrMonthMinus2Revenue'].sum()
westpercrevpot = pd.np.round((westmtdrev/westrevpotential)*100,0)

westsumlist = ['West_Total','-','-','-',westcodes,westmtdrev,westrevpotential,westminus1rev,westminus2rev,westpercrevpot]
westcol_list = ['Region','Month','Year','Month_year','Account Code','CurrMTDRevenue','RevenuePotential','CurrMonthMinus1Revenue','CurrMonthMinus2Revenue','%RevPotential_CurrMTDRev']
westtotals = pd.DataFrame(data=[westsumlist], columns = westcol_list)
conversionleaddatatradinggrpW = conversionleaddatatradinggrpW.append(westtotals,ignore_index=True)


# ### PAN INDIA TOTALS

# In[11]:

conversionleaddatatradingPIgrp = conversionleaddatatrading.groupby(['Month','Year','Month_year']).agg({'Account Code':len,'RevenuePotential':sum,'CurrMTDRevenue':sum,'CurrMonthMinus1Revenue':sum,'CurrMonthMinus2Revenue':sum}).reset_index()  
conversionleaddatatradingPIgrp = conversionleaddatatradingPIgrp.sort_values(['Year','Month'],ascending =True)
#conversionleaddatatradinggrp['%RevPotential_CurrMTDRev'] = pd.np.round(conversionleaddatatradinggrp.apply(lambda x:(x['CurrMTDRevenue']/x['RevenuePotential'])*100,axis=1),2)
conversionleaddatatradingPIgrp['%RevPotential_CurrMTDRev'] = conversionleaddatatradingPIgrp.apply(lambda x:percmtdpotential(x['CurrMTDRevenue'],x['RevenuePotential']),axis=1)
conversionleaddatatradingPIgrp

panindiacodes = conversionleaddatatradingPIgrp['Account Code'].sum()
panindiamtdrev = conversionleaddatatradingPIgrp['CurrMTDRevenue'].sum()
panindiarevpotential = conversionleaddatatradingPIgrp['RevenuePotential'].sum()
panindaminus1rev = conversionleaddatatradingPIgrp['CurrMonthMinus1Revenue'].sum()
panindaminus2rev = conversionleaddatatradingPIgrp['CurrMonthMinus2Revenue'].sum()
panindiapercrevpot = pd.np.round((panindiamtdrev/panindiarevpotential)*100,0)

panindasumlist = ['PAN_INDIA_Total','','-','Grand_Total',panindiacodes,panindiamtdrev,panindiarevpotential,panindaminus1rev,panindaminus2rev,panindiapercrevpot]
panindacol_list = ['Region','Month','Year','Month_year','Account Code','CurrMTDRevenue','RevenuePotential','CurrMonthMinus1Revenue','CurrMonthMinus2Revenue','%RevPotential_CurrMTDRev']
panindatotals = pd.DataFrame(data=[panindasumlist], columns = panindacol_list)
conversionleaddatatradingPIgrp = conversionleaddatatradingPIgrp.append(panindatotals,ignore_index=True)


#### Regionwise Subtotals addition for regions dataframe
regionstotalsdfen = conversionleaddatatradinggrpE.append(conversionleaddatatradinggrpN,ignore_index=True)
regionstotalsdfens = regionstotalsdfen.append(conversionleaddatatradinggrpS,ignore_index=True)
regionstotalsdfensw = regionstotalsdfens.append(conversionleaddatatradinggrpW,ignore_index=True)
#### Regionwise Subtotals addition for regions dataframe


conversiondatawithtotals = regionstotalsdfensw.append(conversionleaddatatradingPIgrp,ignore_index=True)
conversiondatawithtotals.Region.fillna('PAN_INDIA',inplace=True)

columnsoppanindia = ['Region','Month_year','Account Code','RevenuePotential','CurrMTDRevenue','%RevPotential_CurrMTDRev','CurrMonthMinus1Revenue','CurrMonthMinus2Revenue']
conversiondatawithsubtotals = pd.DataFrame(conversiondatawithtotals,columns=columnsoppanindia)


# ### Channelwise

# In[12]:

conversionleaddatatradingchannelgrp = conversionleaddatatrading.groupby(['Region','Channel Type','Month','Year','Month_year']).agg({'Account Code':len,'RevenuePotential':sum,'CurrMTDRevenue':sum,'CurrMonthMinus1Revenue':sum,'CurrMonthMinus2Revenue':sum}).reset_index()  
conversionleaddatatradingchannelgrp = conversionleaddatatradingchannelgrp.sort_values(['Region','Year','Month'],ascending =True)
##conversionleaddatatradingchannelgrp['%RevPotential_CurrMTDRev'] = pd.np.round(conversionleaddatatradingchannelgrp.apply(lambda x:(x['CurrMTDRevenue']/x['RevenuePotential'])*100,axis=1),2)
conversionleaddatatradingchannelgrp['%RevPotential_CurrMTDRev'] = conversionleaddatatradingchannelgrp.apply(lambda x:percmtdpotential(x['CurrMTDRevenue'],x['RevenuePotential']),axis=1)
columnsopchannel = ['Region','Channel Type','Month_year','Account Code','RevenuePotential','CurrMTDRevenue','%RevPotential_CurrMTDRev','CurrMonthMinus1Revenue','CurrMonthMinus2Revenue']
conversionleaddatatradingchannelgrp = pd.DataFrame(conversionleaddatatradingchannelgrp,columns=columnsopchannel)


# ### Sales Personwise

# In[13]:

conversionleaddatatradingSPgrp = conversionleaddatatrading.groupby(['Region','Sales Executive','Month','Year','Month_year']).agg({'Account Code':len,'RevenuePotential':sum,'CurrMTDRevenue':sum,'CurrMonthMinus1Revenue':sum,'CurrMonthMinus2Revenue':sum}).reset_index()  
conversionleaddatatradingSPgrp = conversionleaddatatradingSPgrp.sort_values(['Region','Year','Month'],ascending =True)
##conversionleaddatatradingSPgrp['%RevPotential_CurrMTDRev'] = pd.np.round(conversionleaddatatradingSPgrp.apply(lambda x:(x['CurrMTDRevenue']/x['RevenuePotential'])*100,axis=1),2)
conversionleaddatatradingSPgrp['%RevPotential_CurrMTDRev'] = conversionleaddatatradingSPgrp.apply(lambda x:percmtdpotential(x['CurrMTDRevenue'],x['RevenuePotential']),axis=1)
columnsopsalesperson = ['Region','Sales Executive','Month_year','Account Code','RevenuePotential','CurrMTDRevenue','%RevPotential_CurrMTDRev','CurrMonthMinus1Revenue','CurrMonthMinus2Revenue']
conversionleaddatatradingSPgrp = pd.DataFrame(conversionleaddatatradingSPgrp,columns=columnsopsalesperson)


# In[14]:

now = datetime.now()
yestday = now-timedelta(hours=24)
yestdate = yestday.date()


# In[15]:

with ExcelWriter(r'D:\Data\Sales_lead_management\Conversion_report\Conversion_summary\Conversion_Report_'+str(yestdate)+'.xlsx') as writer:
    #conversionleaddata.to_excel(writer, sheet_name='DATA',engine='xlsxwriter')
    conversiondatawithsubtotals.to_excel(writer, sheet_name='Conversion_Rep_analysis',engine='xlsxwriter')
    conversionleaddatatradingchannelgrp.to_excel(writer, sheet_name='Channelwise',engine='xlsxwriter')
    conversionleaddatatradingSPgrp.to_excel(writer, sheet_name='Sales_personwise',engine='xlsxwriter')

oppath2 = r'D:\Data\Sales_lead_management\Conversion_report\Conversion_summary\Conversion_Report_'+str(yestdate)+'.xlsx'

conversionleaddata.to_csv(r'D:\Data\Sales_lead_management\Conversion_report\Conversion_basedata\Conversion_Report_Basedata_'+str(yestdate)+'.csv')
conversionleaddata.to_csv(r'D:\Data\Sales_lead_management\Conversion_report\Conversion_Report_Basedata.csv')
oppath1 = r'D:\Data\Sales_lead_management\Conversion_report\Conversion_Report_Basedata.csv'

# ### FTP Base DATA

# In[16]:

ftp = ftplib.FTP()
ftp.connect('10.109.250.50')
#print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        #print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppath1
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        #print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()


# ### SELECTIVE COLUMNS FOR EMAIL 

# In[17]:

conversionleaddatatradingPIgrp.Region.fillna('PAN_INDIA',inplace=True)
##columnsopemail = ['Region','Month_year','Account Code','RevenuePotential','CurrMTDRevenue','%RevPotential_CurrMTDRev']
columnsopemail = ['Month_year','Account Code','RevenuePotential','CurrMTDRevenue','%RevPotential_CurrMTDRev']
PI_email = pd.DataFrame(conversionleaddatatradingPIgrp,columns=columnsopemail)

### For Rounding off decimals for Revenue potential and MTD Revenue
##PI_email = PI_email.rename(columns={'RevenuePotential':'RevPot','CurrMTDRevenue':'MtdRev'})
PI_email['RevPot'] = pd.np.round(PI_email.apply(lambda x:x['RevenuePotential'],axis=1),0)
PI_email['MtdRev'] = pd.np.round(PI_email.apply(lambda x:x['CurrMTDRevenue'],axis=1),0)

### For Rounding off decimals for Revenue potential and MTD Revenue
PI_email = PI_email.rename(columns={'Month_year':'SignDate','Account Code':'#A/Cs','%RevPotential_CurrMTDRev':'%MtdRev'})

columnsopemail_final = ['SignDate','#A/Cs','RevPot','MtdRev','%MtdRev']
PI_email_final = pd.DataFrame(PI_email,columns=columnsopemail_final)
PI_email_final = PI_email_final.to_string(index=False)
# In[18]:

filePath = oppath2
def sendEmail(TO = ["rsm_spot@spoton.co.in","reena.singhania@spoton.co.in"],
            #TO = ["Ankit@iepfunds.com","rajeesh.vr@spoton.co.in"],
            #TO = ["vishwas.j@spoton.co.in"],
            #TO = ["rajeesh.vr@spoton.co.in"],
            CC = ["uday.sharma@spoton.co.in","abhik.mitra@spoton.co.in","narasimha.murthy@spoton.co.in","Yogesh@iepfunds.com","rajeesh.vr@spoton.co.in"],
            #CC = ["vishwas.j@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "Sales NBD - Conversion Report - "+ str(yestdate)
    body_text = """
    Dear All,
    
    PFA the Sales NBD Conversion Report for PAN-INDIA as of """+str(yestdate)+""" 
    
    PFB the Conversion Report summary as of """ +str(yestdate)+"""

    
"""+str(PI_email_final)+"""
    
    
    Note:
    All reports consider only the customers who have started trading. From the base data please apply a filter in 'Trading customer'= Yes
    
    Please refer the below link for the Conversion report base data 
    
    http://spoton.co.in/downloads/IEProjects/ETA/Conversion_Report_Basedata.csv
    
    """
    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends


# In[ ]:


# In[ ]:



