
# coding: utf-8

# In[1]:

import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
import pandas as pd
import sys
import pandas.io.sql
import pandas as pd
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
import os
import glob
from string import Template
import numpy as np
import zipfile
import Utilities

# In[2]:

reload(sys).setdefaultencoding("ISO-8859-1")


# In[3]:

datetoday = datetime.now().date()
todayminus = datetoday-timedelta(days=1)
todayminus1=datetime.strftime(todayminus,'%Y-%m-%d')
strtmnthdate=todayminus.replace(day=1)
strtmnthdate=datetime.strftime(strtmnthdate,'%Y-%m-%d')
strtmnthdate,todayminus1


# In[4]:

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()


# In[5]:

del_eff_query_month = ("""
        EXEC dbo.USP_DELV_EFF_SC_WISE_ALL 'S', '{0}','{1}'
       """.format(strtmnthdate,todayminus1))
del_eff_query_yesterday=("""
        EXEC dbo.USP_DELV_EFF_SC_WISE_ALL 'S', '{0}','{1}'
       """.format(todayminus1,todayminus1))


# In[6]:

del_eff_month_df = pd.read_sql_query(del_eff_query_month, Utilities.cnxn)
del_eff_yesterday_df= pd.read_sql_query(del_eff_query_yesterday, Utilities.cnxn)


# In[7]:

del_eff_df_month_data=del_eff_month_df[(del_eff_month_df['DEPOT_CODE']=='PNQD')&(del_eff_month_df['DEST_BRCD'].isin(['PHRB','PNQC','DPNQ']))]
del_eff_df_yesterday_data=del_eff_yesterday_df[(del_eff_yesterday_df['DEPOT_CODE']=='PNQD')&(del_eff_yesterday_df['DEST_BRCD'].isin(['PHRB','PNQC','DPNQ']))]


# In[8]:

del_eff_df_month_data


# In[9]:

de_month_df = del_eff_df_month_data.groupby('DEST_BRCD').agg({'TOTAL':sum,'Delivered':sum}).reset_index()
de_yesterday_df = del_eff_df_yesterday_data.groupby('DEST_BRCD').agg({'TOTAL':sum,'Delivered':sum}).reset_index()
de_month_pnqd_df = del_eff_df_month_data.groupby('DEPOT_CODE').agg({'TOTAL':sum,'Delivered':sum}).reset_index()
de_yesterday_pnqd_df = del_eff_df_yesterday_data.groupby('DEPOT_CODE').agg({'TOTAL':sum,'Delivered':sum}).reset_index()


# In[10]:

de_month_df['DE%']=de_month_df['Delivered'].divide(de_month_df['TOTAL'])*100
de_month_df=de_month_df.replace([np.inf, -np.inf], np.nan)
de_yesterday_df['DE%']=de_yesterday_df['Delivered'].divide(de_yesterday_df['TOTAL'])*100
de_yesterday_df=de_yesterday_df.replace([np.inf, -np.inf], np.nan)
de_month_pnqd_df['DE%']=de_month_pnqd_df['Delivered'].divide(de_month_pnqd_df['TOTAL'])*100
de_month_pnqd_df=de_month_pnqd_df.replace([np.inf, -np.inf], np.nan)
de_yesterday_pnqd_df['DE%']=de_yesterday_pnqd_df['Delivered'].divide(de_yesterday_pnqd_df['TOTAL'])*100
de_yesterday_pnqd_df=de_yesterday_pnqd_df.replace([np.inf, -np.inf], np.nan)


# In[11]:


de_yesterday_df


# In[12]:

de_month_df


# In[13]:

finaldf1=pd.merge(de_month_df,de_yesterday_df,on='DEST_BRCD',suffixes=['_MTD','_Yest'],how='outer')
finaldf01=pd.merge(de_month_pnqd_df,de_yesterday_pnqd_df,on='DEPOT_CODE',suffixes=['_MTD','_Yest'],how='outer')
finaldf01=finaldf01.rename_axis({'DEPOT_CODE':'BRCD'},axis=1)


# In[14]:

finaldf1=finaldf1.rename_axis({'DEST_BRCD':'BRCD'},axis=1)
finaldf1=pd.concat([finaldf1,finaldf01])
finaldf1=finaldf1[['BRCD','DE%_MTD','DE%_Yest']]


# In[15]:

finaldf1


# In[16]:

pickpquery_yesterday = ("""
        EXEC dbo.CRM_WEEKLY_PERFORMANCE_SCWISE_DATA_SHIVA_KPI  '{0}','{1}'
       """.format(todayminus1,todayminus1))
pickpquery_month = ("""
        EXEC dbo.CRM_WEEKLY_PERFORMANCE_SCWISE_DATA_SHIVA_KPI  '{0}','{1}'
       """.format(strtmnthdate,todayminus1))


# In[17]:

pickp_df_yesterday=pd.read_sql_query(pickpquery_yesterday,Utilities.cnxn)
pickp_df_yesterday_data=pickp_df_yesterday[(pickp_df_yesterday['DEPOT_CODE']=='PNQD')&(pickp_df_yesterday['BRCD'].isin(['PHRB','PNQC','DPNQ']))]
pkdf_yesterday = pickp_df_yesterday_data.groupby(['BRCD']).agg({'Total_Pickups':sum,'Total_Success':sum}).reset_index()
pkdf_yesterday_pnqd = pickp_df_yesterday_data.groupby(['DEPOT_CODE']).agg({'Total_Pickups':sum,'Total_Success':sum}).reset_index()
pkdf_yesterday['Pkp_Per%']=pkdf_yesterday.apply(lambda x:pd.np.round((x['Total_Success']*1.0/x['Total_Pickups'])*100.0,2),axis=1)
pkdf_yesterday_pnqd['Pkp_Per%']=pkdf_yesterday_pnqd.apply(lambda x:pd.np.round((x['Total_Success']*1.0/x['Total_Pickups'])*100.0,2),axis=1)


# In[ ]:




# In[18]:

pickp_df_month=pd.read_sql_query(pickpquery_month,Utilities.cnxn)
pickp_df_month_data=pickp_df_month[pickp_df_month['BRCD'].isin(['PHRB','PNQC','DPNQ'])]
pkdf_month = pickp_df_month_data.groupby(['BRCD']).agg({'Total_Pickups':sum,'Total_Success':sum}).reset_index()
pkdf_month_pnqd = pickp_df_month_data.groupby(['DEPOT_CODE']).agg({'Total_Pickups':sum,'Total_Success':sum}).reset_index()
pkdf_month['Pkp_Per%']=pkdf_month.apply(lambda x:pd.np.round((x['Total_Success']*1.0/x['Total_Pickups'])*100.0,2),axis=1)
pkdf_month_pnqd['Pkp_Per%']=pkdf_month_pnqd.apply(lambda x:pd.np.round((x['Total_Success']*1.0/x['Total_Pickups'])*100.0,2),axis=1)


# In[19]:

finaldf02=pd.merge(pkdf_month_pnqd,pkdf_yesterday_pnqd,on='DEPOT_CODE',suffixes=['_MTD','_Yest'],how='outer')
finaldf02=finaldf02.rename_axis({'DEPOT_CODE':'BRCD'},axis=1)


# In[20]:

finaldf2=pd.merge(pkdf_month,pkdf_yesterday,on='BRCD',suffixes=['_MTD','_Yest'],how='outer')
finaldf2=pd.concat([finaldf2,finaldf02])


# In[21]:

finaldf2=finaldf2[['BRCD','Pkp_Per%_MTD','Pkp_Per%_Yest']]
finaldf2=pd.np.round(finaldf2)

# In[22]:

final=pd.merge(finaldf1,finaldf2,on='BRCD',how='outer')


# In[23]:

final=final.fillna('-')


# In[24]:

final


# In[67]:

data=pd.read_csv(r'D:\Data\pmd aug-jan2018.csv')
# month=pd.read_csv(r'http://www.spoton.co.in/downloads/PMD/PMD.csv')

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()
query=("""SELECT CASE WHEN PUDTYPE = 'ADHOC'   

                          AND (( A.MKT_SBA_APPLICABLE = 'Y'   

                                OR A.MKT_HIRE_REASON = 'DEDICATED FOR SINGLE CUSTOMER'   

                                OR A.MKT_HIRE_REASON = 'NSL SHIPMENT'   

                                OR A.MKT_HIRE_REASON = 'LATE NIGHT/EARLY MORNING'   

                              )   

                          OR ( A.SENDERCODE = '000119837'    

                               OR A.SENDERCODE = '000118040'   

                               OR A.SENDERCODE = '000118041'   

                               OR A.SENDERCODE = '000119721'   

                               OR A.SENDERCODE = '000120083'   

                             )) THEN 'ADHOC-Special'   

                     ELSE PUDTYPE   

                END PUDTYPE_STATUS ,a.* FROM dbo.tblPUDYestMtdData  a  WITH (NOLOCK)""")
month=pd.read_sql(query,Utilities.cnxn)
# data=pd.read_csv(r'http://spoton.co.in/downloads/PMD/PMD.csv')

# df=df.rename(columns={})
# In[36]:

# data.to_csv('PMD.csv')

month=month.rename(columns={'TYP':'TYP2','DEPOT':'DEPOT2','BRANCH_CODE':'BRANCH_CODE2','PINCODE':'PINCODE2','DATE':'DATE2','PUDTYPE':'PUDTYPE2','COST':'COST2','ACT_WT':'ACT_WT2','SENDERCODE':'SENDERCODE2'})

data=pd.concat([data,month])

# In[69]:

datetoday=datetime.now().date()
todayminus=datetoday-timedelta(days=1)
k=todayminus.strftime('%d')


# In[70]:

data=data[data['TYP2']=='DLV']
data=data[data['DEPOT2'].isin(['PNQD','BLRD'])]
data=data[data['BRANCH_CODE2'].isin(['PHRB','PNQC','DPNQ'])]


# In[71]:

def diff(delivery,arrival):
    time1=delivery-arrival
    return round(time1.total_seconds()/3600.0,2)


# In[72]:

data['DATE2']=pd.to_datetime(data['DATE2'],errors='coerce')


# In[73]:

data['DESTARRV_ARRVDT']=pd.to_datetime(data['DESTARRV_ARRVDT'],errors='coerce')


# In[74]:

data['Timedelay']=data.apply(lambda x:diff(x['DATE2'],x['DESTARRV_ARRVDT']),axis=1)


# In[75]:

data['Month']=data['DATE2'].dt.strftime('%Y/%m')


# In[76]:

data=data[data['BRANCH_CODE2'].isin(['PHRB','PNQC','DPNQ'])]


# In[77]:

pivot=data.pivot_table(index='BRANCH_CODE2',columns='Month',aggfunc={'Timedelay':pd.np.mean})


# In[78]:

pivot=pd.np.round(pivot)


# In[79]:

pivot=pivot.fillna('-')


# In[80]:

pivot0=data.pivot_table(index='DEPOT2',columns='Month',aggfunc={'Timedelay':pd.np.mean})


# In[81]:

pivot0=pivot0.rename_axis({'DEPOT2':'BRANCH_CODE2'})
pivot0=pd.np.round(pivot0)


# In[82]:

pivot=pd.concat([pivot,pivot0])


# In[83]:

lastmonth=month


# In[84]:
lastmonth=lastmonth[lastmonth['TYP2']=='DLV']
lastmonth=lastmonth[lastmonth['BRANCH_CODE2'].isin(['PHRB','PNQC','DPNQ'])]


# In[85]:

lastmonth['DATE2']=pd.to_datetime(lastmonth['DATE2'],errors='coerce')
lastmonth['DESTARRV_ARRVDT']=pd.to_datetime(lastmonth['DESTARRV_ARRVDT'],errors='coerce')


# In[86]:

lastmonth['Timedelay']=lastmonth.apply(lambda x:diff(x['DATE2'],x['DESTARRV_ARRVDT']),axis=1)


# In[87]:

lastmonth['Date']=lastmonth['DATE2'].dt.strftime('%d')


# In[88]:

lastdate=lastmonth[lastmonth['Date']==str(k)]


# In[89]:

pivot1=lastmonth.groupby('BRANCH_CODE2').agg({'Timedelay':pd.np.mean}).reset_index()
pivotpnq1=lastmonth.groupby('DEPOT2').agg({'Timedelay':pd.np.mean}).reset_index()


# In[90]:

pivot2=lastdate.groupby('BRANCH_CODE2').agg({'Timedelay':pd.np.mean}).reset_index()
pivotpnq2=lastdate.groupby('DEPOT2').agg({'Timedelay':pd.np.mean}).reset_index()


# In[91]:

pivotpnq=pd.merge(pivotpnq1,pivotpnq2,on='DEPOT2',suffixes=['_MTD','_Yest'],how='outer')


# In[92]:

pivotpnq=pivotpnq.rename_axis({'DEPOT2':'BRANCH_CODE2'},axis=1)


# In[93]:

final1=pd.merge(pivot1,pivot2,on='BRANCH_CODE2',suffixes=['_MTD','_Yest'],how='outer')


# In[94]:

final1=pd.concat([final1,pivotpnq])


# In[95]:

final=final.rename_axis({'BRCD':'BRANCH_CODE2'},axis=1)


# In[96]:

final['BRANCH_CODE2']=final['BRANCH_CODE2'].astype(str)


# In[97]:

final=pd.merge(final1,final,left_on=['BRANCH_CODE2'],right_on=['BRANCH_CODE2'],how='outer')


# In[98]:

final


# In[99]:

pivot


# In[58]:

final=pd.np.round(final)


# In[59]:

pivot=pd.np.round(pivot)

pivot.columns = pivot.columns.swaplevel(0,1)

k=pivot.columns.tolist()

for i in k:
    try:
        pivot[i[0]]=pivot[i[0]].astype('int')
    except:
        pass

pivot.columns = pivot.columns.swaplevel(0,1)
k=final.columns.tolist()

for i in k:
    try:
        final[i]=final[i].astype('int')
    except:
        pass


# In[101]:

def dfs_tabs(df_list, sheet_list, file_name):
    writer = pd.ExcelWriter(file_name,engine='xlsxwriter')   
    for dataframe, sheet in zip(df_list, sheet_list):
        dataframe.to_excel(writer, sheet_name=sheet, startrow=0 , startcol=0)   
    writer.save()

# list of dataframes and sheet names
dfs = [lastmonth,pickp_df_month_data,del_eff_df_month_data]
sheets = ['timedelay','pickup','delivery']    

# run function
dfs_tabs(dfs, sheets, 'D:\Data\DirectDelivery-DPNQ\DD Performance-PNQ-'+str(todayminus)+'.xlsx')


# In[61]:

df=final.to_html()
df1=pivot.to_html()


# In[62]:

# filePath=r'D:\Data\DirectDelivery-DPNQ\DD Performance-PNQ-'+str(todayminus)+'.xlsx'


# In[63]:

def sendEmail(#TO = ["Ramniwas.Sharma@Spoton.Co.In","rajesh.debnath@spoton.co.in"],
            TO = ["shashvat.suhane@spoton.co.in"],
            # TO = ["vishwas.j@spoton.co.in"],
            CC = ["shashvat.suhane@spoton.co.in"],
            # CC = ["supratim@iepfunds.com","Krishna.Chandrasekar@Spoton.Co.In","pawan.sharma@spoton.co.in","shashvat.suhane@spoton.co.in","vishwas.j@spoton.co.in","abhik.mitra@spoton.co.in","ankit@iepfunds.com"],
            #BCC = ["vinayak.kumbhar@spoton.co.in","vinodkumar.mishra@spoton.co.in","nitin.tatyarao@spoton.co.in","kiran.pawar@spoton.co.in","jai.prakash@spoton.co.in","rajesh.mishra@spoton.co.in","ops.hub.idrh.1@spoton.co.in"] ,
            #BCC = ["vishwas.j@spoton.co.in"],
            FROM="reports.ie@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["BCC"] = ",".join(BCC)
    msg["Subject"] = "DD Performance-PNQ-"+str(todayminus1)+"  "
    body_text = df
    msgtext="""Dear All ,"""
    msg.attach( MIMEText(msgtext) )
    msg.attach( MIMEText(body_text+"<br><br><br>"+df1,'html') )
    # part = MIMEBase('application', "octet-stream")
    # part.set_payload( open(filePath,"rb").read() )
    # Encoders.encode_base64(part)
    # part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    # msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()


# In[ ]:



