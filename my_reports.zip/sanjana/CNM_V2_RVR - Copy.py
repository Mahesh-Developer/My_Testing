
# coding: utf-8

# In[6]:

from suds.client import Client
import pandas as pd
import json
import requests as req
import datetime
import numpy as np

# In[7]:

gpsdata = pd.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\GPS_critical.csv')
ippath4 = r'D:\Python\Scripts and Files\Path and Graph Files\ApilistGC.xlsx'
xl4 = pd.ExcelFile(ippath4)
APIlist = xl4.parse('Sheet10')
keylist = APIlist['API list'].tolist()
divisionbase= len(keylist)


# In[8]:

url_service = 'http://118.67.240.88:5009/Service.asmx?WSDL'
client = Client(url_service)
url1 = 'https://maps.googleapis.com/maps/api/geocode/json?'


# In[10]:

ts = datetime.datetime.now()


# In[11]:

for i in range (0, len(gpsdata)):
    routecode = gpsdata.iloc[i]['ROUTE CODE']
    simno = gpsdata.iloc[i]['SIM NO']
    routepath = gpsdata.iloc[i]['ROUTE PATH']
    vehno = gpsdata.iloc[i]['VEHICLE NO']
    try:
        response = client.service.Get_Information(User_Id="stladmin1", vehicle_Id=str(simno))
        output = response.split('::')
        phone_id = output[0]
        ping_time = output[3]
        lati=output[5]
        longi=output[6]
        speed = output[7]
        
        gpsdata.loc[i,'Ping_Time'] = ping_time
        gpsdata.loc[i,'Latitude'] = lati
        gpsdata.loc[i,'Longitude'] = longi
        gpsdata.loc[i,'Speed'] = speed
        gpsdata.loc[i,'Remarks'] = 'OK'
        gpsdata.loc[i,'Timestamp'] = ts
        
        
    except:
        gpsdata.loc[i,'Remarks'] = 'Check'
        pass
    
    
    try:
        latlong = str(lati)+','+str(longi)
        rowmode= i%divisionbase
        url3='&key='+ str (keylist[rowmode])
        url = url1+str('latlng='+str(latlong))+url3
        r = req.get(url)
        text = r.text
        json_data=json.loads(text)
        addcheck= json_data['status']
        #print('addcheck is',addcheck)
        if addcheck == 'NOT_FOUND' or addcheck == 'ZERO_RESULTS' or addcheck == 'UNKNOWN_ERROR':
            print('Address not found')
            gpsdata.loc[i,'AddressError'] = 'Check Address'
        else:
            #a = json_data['results'][0]['geometry']['location']
            gpsdata.loc[i,'Address'] = json_data['results'][0]['formatted_address']
            
    except:
        pass

#datetimenow = datetime.now()
opfilevar=ts.date()
opfilevar1=ts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=np.round((float(currhrs)/60),0)

gpsdata.to_csv('D:\\Data\\CNM\\OP_'+str(opfilevar)+str('_')+str(opfilevar2)+'.csv', encoding='utf-8')   




