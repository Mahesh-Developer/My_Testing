
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
import calendar
import datetime
from pandas import ExcelWriter
import os
import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import Utilities

# In[2]:


now = datetime.datetime.now()
today = now.strftime("%a")
print (today)


# In[3]:


openingstock = pd.io.excel.read_excel(r'http://10.109.230.50/downloads/OCID/OCID.xls','OPENING STOCK')
len(openingstock)


# In[4]:


deliveredstock = pd.io.excel.read_excel(r'http://10.109.230.50/downloads/OCID/OCID.xls','DELIVERED')
len(deliveredstock)


# In[5]:


liblist = [000119721.0]
openingstock = openingstock[~(openingstock['CSGNCD'].isin(liblist))&~(openingstock['CSGECD'].isin(liblist))]
#openingstock = openingstock[~(openingstock['CSGECD'].isin([000119721.0]))]


# In[6]:



len(openingstock)


# In[7]:


deliveredstock = deliveredstock[~(deliveredstock['CSGNCD'].isin(liblist))&~(deliveredstock['CSGECD'].isin(liblist))]
#deliveredstock = deliveredstock[~(deliveredstock['CSGECD'].isin([000119721.0]))]


# In[8]:


len(deliveredstock)


# In[9]:


projectparentcodesexclist = [000117991.0,000118040.0,000118041.0,000118042.0,000118043.0,000118075.0,000111007.0,000114381.0]
openingstock = openingstock[~(openingstock['PARENTCODE'].isin(projectparentcodesexclist))]


# In[10]:


deliveredstock = deliveredstock[~(deliveredstock['PARENTCODE'].isin(projectparentcodesexclist))]


# In[11]:


projectconsgcd = [000117991.0,000118040.0,000118041.0,000118043.0,000111007.0,000118042.0,000118075.0,000114381.0]


# In[12]:


openingstock = openingstock[~(openingstock['CSGNCD'].isin(projectconsgcd)) & ~(openingstock['CSGECD'].isin(projectconsgcd))]
# openingstock = openingstock[~(openingstock['CSGECD'].isin(projectconsgcd))]


# In[13]:


len(openingstock)


# In[14]:


deliveredstock = deliveredstock[~(deliveredstock['CSGNCD'].isin(projectconsgcd))&~(deliveredstock['CSGECD'].isin(projectconsgcd))]


# In[15]:


len(deliveredstock)


# In[16]:


delbranchdf=deliveredstock[['DEST BRCD','DEST AREA']]
opbranchdf=openingstock[['DEST BRCD','DEST AREA']]


# In[17]:


print (len(delbranchdf),len(opbranchdf))


# In[18]:


branchdf = pd.merge(delbranchdf,opbranchdf,on=['DEST BRCD','DEST AREA'],how='outer')
branchdf.rename(columns={'DEST BRCD':'BRANCH CODE','DEST AREA':'Area'}, inplace=True)
branchdf = branchdf.drop_duplicates(['BRANCH CODE'])


# In[19]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


# In[20]:






holidayquery = ("""
        select * from tblYearlyHolidayMst with (nolock) where HDAY_DATE>'2016-01-01'
        """)


# In[21]:


holidaymaster = pd.read_sql(holidayquery, Utilities.cnxn)
print (len(holidaymaster))


# In[22]:


def datestring(x):
    try:
        x = str(x)
        fulldate = datetime.datetime.strptime(x,'%Y-%m-%d %H:%M:%S')
        return fulldate
    except:
        x = str(x)
        fulldate = datetime.datetime.strptime(x,'%d-%m-%Y %H:%M')
        return fulldate


# In[23]:


holidaymaster['HDAY_DATE'] = holidaymaster.apply(lambda x : datestring(x['HDAY_DATE']),axis=1)


# In[24]:


holidaymaster['HDAY_DATE'].head()


# In[25]:


selectdate = now-timedelta(days=1)


# In[26]:


selectdate = selectdate.replace(hour=0, minute=0, second=0).strftime('%Y-%m-%d %H:%M:%S')


# In[27]:


type(selectdate)


# In[28]:


selectdate = datetime.datetime.strptime(selectdate,'%Y-%m-%d %H:%M:%S')


# In[29]:


selectdate


# In[30]:


holidaylist = list(set(holidaymaster['HDAY_DATE'].tolist()))
#holidaylist


# In[31]:


if selectdate in holidaylist:
    print ('Yesterday in holiday list')
    selectdf = holidaymaster[holidaymaster['HDAY_DATE']==selectdate]
    selectdfbrcdlist = selectdf['BRCD'].tolist()
    selectdfbrcdlist = list(set(selectdfbrcdlist))
    selectdfarealist = selectdf['ControlArea'].tolist()
    selectdfarealist = list(set(selectdfarealist))
    print (selectdfbrcdlist)
    print (selectdfarealist)
    
    openingstock = openingstock[~(openingstock['DEST BRCD'].isin(selectdfbrcdlist))]
    openingstock = openingstock[~(openingstock['DEST AREA'].isin(selectdfarealist))]
    
    deliveredstock = deliveredstock[~(deliveredstock['DEST BRCD'].isin(selectdfbrcdlist))]
    deliveredstock = deliveredstock[~(deliveredstock['DEST AREA'].isin(selectdfarealist))]
else:
    selectdfbrcdlist = []
    selectdfarealist = []
    print ('Yesterday not in holiday list')


# In[32]:


openingstock = openingstock[openingstock['DEL LOCATION TYPE']=='ODA']


# In[33]:


len(openingstock)


# In[34]:


deliveredstock = deliveredstock[deliveredstock['DEL LOCATION TYPE']=='ODA']


# In[35]:


ignorestatuscodelist = ['UCG','SSC','UG1','UG2','UG3','SHS']


# In[36]:


openingstock=openingstock[~openingstock['Con Status Code'].isin(ignorestatuscodelist)]


# In[37]:


openingstock = openingstock[(openingstock['REPORTDATE MIN ARRVDT']>48)]


# In[38]:


openinggroupby=openingstock.groupby(['DEST BRCD']).agg({'DOCKNO': 'count'}).reset_index()


# In[39]:


deliveredgroupby=deliveredstock.groupby(['DEST BRCD']).agg({'DOCKNO': 'count'}).reset_index()


# In[40]:


merge_effeciency = pd.merge(openinggroupby,deliveredgroupby, on=['DEST BRCD'], suffixes=['_open','_d'], how='outer')
merge_effeciency.head()


# In[41]:


merge_effeciency = merge_effeciency.fillna(0)


# In[42]:


merge_effeciency['Delivery_Efficiency']=pd.np.round((merge_effeciency['DOCKNO_d']*100.0/merge_effeciency['DOCKNO_open']).replace([np.inf,-np.inf],np.nan).fillna(0),2)


# In[43]:


# merge_effeciency['Delivery_Efficiency']=pd.np.round(merge_effeciency['Delivery_Efficiency'],2)


# In[44]:


merge_effeciency.head()


# In[45]:


merge_effeciency.rename(columns={'DOCKNO_d':'DOCKNO_Delivered'}, inplace=True)


# In[46]:


branchdf.head()


# In[47]:


merge_effeciency=pd.merge(merge_effeciency,branchdf,left_on=['DEST BRCD'],right_on=['BRANCH CODE'], how = 'inner')


# In[48]:


merge_effeciency = merge_effeciency.drop(['BRANCH CODE'], axis=1)
merge_effeciency.head()


# In[49]:


openingcons = merge_effeciency['DOCKNO_open'].sum() 
deliveredcons = merge_effeciency['DOCKNO_Delivered'].sum()
deliveryefficiency = pd.np.round(deliveredcons*100.0/(openingcons),2)


# In[50]:


merge_effeciency_area=merge_effeciency.groupby(['Area']).agg({'DOCKNO_open': 'sum','DOCKNO_Delivered': 'sum'}).reset_index()


# In[51]:


merge_effeciency_area


# In[52]:


merge_effeciency_area['Delivery_Efficiency']=pd.np.round((merge_effeciency_area['DOCKNO_Delivered']*100.0/merge_effeciency_area['DOCKNO_open']).replace([np.inf,-np.inf],np.nan).fillna(0),2)
#merge_effeciency_area['Delivery_Efficiency']= merge_effeciency_area.apply(lambda x:getsum(x['DOCKNO_Delivered'],x['DOCKNO_open']),axis=1)


# In[53]:


merge_effeciency_area.head(8)


# In[54]:


sumlist = ['TOTAL',deliveredcons,openingcons,deliveryefficiency]
col_list = ['Area','DOCKNO_Delivered','DOCKNO_open','Delivery_Efficiency']
totalsdf = pd.DataFrame(data=[sumlist], columns = col_list)
merge_effeciency_area = merge_effeciency_area.append(totalsdf,ignore_index=True)


# In[55]:


merge_effeciency_area


# In[56]:


opfilevar =date.today() - timedelta(hours=24)

print ('opfilevar',opfilevar)


# In[57]:


openingstocknotdel = openingstock[openingstock['Delivery Status']=='NO']
dueyestopening = openingstocknotdel[openingstocknotdel['DUE DATE']==opfilevar]
dueyestopeningcons = len(dueyestopening)


# In[58]:


merge_effeciency =merge_effeciency[~(merge_effeciency['DEST BRCD'].isin(selectdfbrcdlist))]
merge_effeciency_area =merge_effeciency_area[~(merge_effeciency_area['Area'].isin(selectdfarealist))]


# In[59]:

oppath2=r'D:\Data\eta_rank\Delivery_Efficiency_ODA\Delivery_Efficiency_ODA_'+str(opfilevar)+'.xlsx'
#oppath2=r'C:\Users\S2769MAH\Downloads\PMD_data\13-02-2018_PMD-Data\downloads\PMD\Delivery_Efficiency_ODA_'+str(opfilevar)+'.xlsx'


# In[60]:


with ExcelWriter(r'D:\Data\eta_rank\Delivery_Efficiency_ODA\Delivery_Efficiency_ODA_'+str(opfilevar)+'.xlsx') as writer:
    merge_effeciency.to_excel(writer, sheet_name='SC_WISE',engine='xlsxwriter')
    merge_effeciency_area.to_excel(writer, sheet_name='AREA_WISE',engine='xlsxwriter')


# In[61]:


with ExcelWriter(r'D:\Data\DE_Conwise_Stock\DE_ODA\Delivery_Efficiency_ODA_'+str(opfilevar)+'.xlsx') as writer:
    openingstock.to_excel(writer, sheet_name='OPENING_STOCK',engine='xlsxwriter')
    deliveredstock.to_excel(writer, sheet_name='DELIVERED',engine='xlsxwriter')


# In[62]:
merge_effeciency.to_csv(r'D:\Data\eta_rank\ODA_DE_SC.csv', encoding='utf-8')
merge_effeciency_area.to_csv(r'D:\Data\eta_rank\ODA_DE.csv', encoding='utf-8')



def datestring2(tsp):
    tsp = str(tsp)
    try:
        return datetime.datetime.strptime(tsp.split(' ')[0], '%d-%m-%Y')
    except:
        return datetime.datetime.strptime(tsp.split(' ')[0], '%Y-%m-%d')


# In[63]:


def datestring(x):
    try:
        fulldate = datetime.datetime.strptime(x,'%Y-%m-%d')
        return fulldate
    except:
        fulldate = datetime.datetime.strptime(x,'%d-%m-%Y')
        return fulldate


# In[64]:


deliveredstock['Delivery_Date']= deliveredstock.apply(lambda x: datestring2(x['DELY DT']), axis=1)
deliveredstock['Due_date'] = deliveredstock.apply(lambda x: datestring2(x['DUE DATE']), axis=1)
deliveredstock['DD_DelyDt'] = deliveredstock.apply(lambda x: (x['Delivery_Date']-x['Due_date']).days,axis=1)


# In[65]:


sumofdiffdays = deliveredstock['DD_DelyDt'].sum()
avrghoursofdelcons = pd.np.round((sumofdiffdays*24.0)/deliveredcons,2)

#### For Average Delay hours of DELIVERED CONS
filePath = oppath2


# In[67]:



import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template
#vishwas.j@spoton.co.in
#TO=['mahesh.reddy@spoton.co.in']
TO = ["aom_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in","rajesh.mishra@spoton.co.in","raghavendra.rao@spoton.co.in","ashwani.gangwar@spoton.co.in","pramod.pandey@spoton.co.in","trilochan.panda@spoton.co.in","sunil.nakte@spoton.co.in","chandrima.banerjee@spoton.co.in", "suresh.d@spoton.co.in", "pankaj.jha@spoton.co.in"]
FROM='vishwas.j@spoton.co.in'
#CC=['mahesh.reddy@spoton.co.in']
CC = ["sqtf@spoton.co.in","SQ_spot@spoton.co.in"]
#BCC=['maheshmahesh11464@gmail.com']
BCC = ["mahesh.reddy@spoton.co.in","shashvat.suhane@spoton.co.in","sachidanand.pandey@spoton.co.in","renugopal.l@spoton.co.in","sathya.chander@spoton.co.in","alagu.mahendran@spoton.co.in","awadhesh.kumar.mishra@spoton.co.in","sanjay.parab@spoton.co.in","ramesh.s@spoton.co.in","md.zaya@spoton.co.in"]
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "ODA DELIVERY EFFICIENCY" + " - " + str(opfilevar)
html='''<html>
<style>
p
{
  margin:0;
  margin-top: 5px;
  padding:0;
  font-size:17px;
    line-height:20px;
}
</style>
<h4>Dear All,</h4>
<p>Delivered = $deliveredcons</p>
<p>Opening Stock = $openingcons</p>
<p>Cons of Duedate $opfilevar Not Delivered = $dueyestopeningcons</p>
<p>Average Delay Hours of Delivered Cons = $avrghoursofdelcons Hrs</p>
<p>The Overall Delivery efficiency of ODA cons is $deliveryefficiency %</p>
<p>PFB the ODA Delivery Efficiency Area wise as of $opfilevar</p>
<p>The AREA-WISE and SC-WISE summary has been attached in the mail.</p>
</html>'''

html3='''
<h5> For the base data, please refer the link </h5>
<p><a href= "http://spoton.co.in/downloads/OCID/OCID.xls"</a>http://spoton.co.in/downloads/OCID/OCID.xls</p></b>
'''
s = Template(html).safe_substitute(deliveryefficiency=deliveryefficiency,avrghoursofdelcons=avrghoursofdelcons,deliveredcons=deliveredcons,openingcons=openingcons,dueyestopeningcons=dueyestopeningcons,opfilevar=opfilevar)
report=""
report+=s
report+='<br>'
report+='<br>'+merge_effeciency_area.to_html()+'<br>'
report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filePath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()
