
# coding: utf-8

# In[1]:

import pandas as pd
from datetime import datetime, timedelta
import glob
import numpy as np

import os
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from pandas import ExcelWriter
from email import encoders
# In[2]:


path =r'D:\Data\Closing_Stock_1HR' # use your path
allFiles = glob.glob(path + "/*.csv")
frame = pd.DataFrame()
list_ = []
for file_ in allFiles:
    df = pd.read_csv(file_,index_col=None, header=0)
    list_.append(df)
frame = pd.concat(list_)
frame.to_csv(r'D:\Data\Combined_closing_1HR.csv')

closing1yes = pd.read_csv(r'D:\Data\Combined_closing_1HR.csv')


# In[3]:

def datestring(x):
    fulldate = datetime.strptime(x,'%Y-%m-%d %H:%M:%S')
    return fulldate


# In[4]:

def datestring1(x):
    try:
        fulldate1 = datetime.strptime(x,'%Y-%m-%d %H:%M:%S')
        return fulldate1
    except:
        return 0


# In[5]:

closing1yes['Timestamp'] = closing1yes.apply(lambda x:datestring (x['Timestate Date']),axis=1)
closing1yes['DRS_Preparation'] = closing1yes.apply(lambda x:datestring1 (x['LASTDRS PREPAREDDATE']),axis=1)


# In[6]:

closing1hrgrp = closing1yes.groupby(['Timestamp']).agg({'DOCKNO':len,'REPORTDATE MIN ARRVDT':pd.np.sum}).reset_index()
closing1hrgrp['Avg_Cooling'] = closing1hrgrp.apply(lambda x: x['REPORTDATE MIN ARRVDT']*1.0/x['DOCKNO'],axis=1)


# In[7]:

closing1hrgrp= closing1hrgrp.sort_values(['Timestamp'],ascending=False)

def setceil(x):
    a = np.ceil(x)
    return a
    
closing1hrgrp['Avg_Cooling'] = closing1hrgrp.apply(lambda x :setceil(x['Avg_Cooling']),axis =1)
closing1hrgrp = closing1hrgrp.drop(['REPORTDATE MIN ARRVDT'],axis=1)

closing1hrgrp.to_csv(r'D:\Data\Closing_Stock_Hourly.csv')

datetimenow = datetime.now()

opfilevar=datetimenow.date()
opfilevar1=datetimenow.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=np.round((float(currhrs)/60),0)

oppath2 = r'D:\Data\Closing_Stock_Hourly.csv'

filePath = oppath2
def sendEmail(TO = ["rajeesh.vr@spoton.co.in"],
            #TO = ["vishwas.j@spoton.co.in"],
            #CC = ["vishwas.j@spoton.co.in"],
            CC = ["vishwas.j@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["Subject"] = "Hourly_Closing_Stock" + '_' + str(opfilevar)+'_'+str(opfilevar2)
    body_text = """
    Dear All,
    
    PFB the Hourly Closing stock as of """+str(opfilevar)+'_'+str(opfilevar2)+ """
    
    """+str(closing1hrgrp)+"""

    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("vishwas.j@spoton.co.in", "Startrek#123")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
print('Email sent')
#Sending output file via mail ends
