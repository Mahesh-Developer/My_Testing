
# coding: utf-8

# In[ ]:


import pandas as pd
import numpy as np
from datetime import datetime
import pyodbc
import smtplib
import os
import ftplib
import traceback
import Utilities

# In[ ]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")


# In[ ]:


query=("EXEC USP_STOCK_OPS_SQ")

curr_time=datetime.strftime(datetime.now(),'%Y-%m-%d %H')
# In[ ]:


df=pd.read_sql(query,Utilities.cnxn)
# df=pd.read_sql(query,cnxn)
len(df)
df=df[~df['CurLocConStatusCode'].isin(['APT','APN'])]


# In[ ]:


df.columns


# In[ ]:


def getBucket(hrs):
#     print (hrs)
    hrs=int(hrs)
    if hrs in range(-25,25):
        return '0-24'
    elif hrs in range(25,49):
        return '24-48'
    elif hrs in range(49,97):
        return '48-96'
    else:
        return '96+'


# In[ ]:


df=df.fillna(0)


# In[ ]:


df['HOURS_LYING']=df.apply(lambda x:getBucket(x['HOURS_LYING_AT_CURR_LOCATION']),axis=1)


# In[ ]:


sc_df=df[df['HUBCENTER']=='N']
len(sc_df)


# In[ ]:


hub_df=df[df['HUBCENTER']=='Y']
len(hub_df)


# In[ ]:





hub_df_pivot=hub_df.pivot_table(index=['CURR_BRANCHCODE'],columns=['HOURS_LYING'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').fillna(0)


# In[ ]:


hub_df_pivot.sort_values(('DOCKNO','Total'),ascending=False,inplace=True)


# In[ ]:

hub_df_pivot=hub_df_pivot[[('DOCKNO','0-24'),('DOCKNO','24-48'),('DOCKNO','48-96'),('DOCKNO','96+'),('DOCKNO','Total')]]

hub_df_pivot


# In[ ]:


sc_df_pivot=sc_df.pivot_table(index=['CURR_AREA'],columns=['HOURS_LYING'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').fillna(0)


# In[ ]:


sc_df_pivot.sort_values(('DOCKNO','Total'),ascending=False,inplace=True)


# In[ ]:


sc_df_pivot['DOCKNO']=sc_df_pivot['DOCKNO'].astype(int)


# In[ ]:


sc_df_pivot['DOCKNO']


# In[ ]:


#sc_df.to_csv(r'Delayed_Cons_SC_Data.csv')
hub_df.to_csv(r'D:\Data\Appointment Reports\Delayed Cons\hub\Delayed_Cons_HUB_Data'+str(curr_time)+'.csv')

hub_df.to_csv(r'D:\Data\Appointment Reports\Delayed Cons\hub\Delayed_Cons_HUB_Data.csv')

# In[ ]:


#filepath=r'Delayed_Cons_SC_Data.csv'
filepath1=r'D:\Data\Appointment Reports\Delayed Cons\hub\Delayed_Cons_HUB_Data.csv'


# In[ ]:



print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = filepath1
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()


# In[ ]:


date=datetime.strftime(datetime.now(),'%Y-%m-%d %H:%M:%S')
date


# In[ ]:


sc_df_pivot.head()


# In[ ]:


topfailinglocation=sc_df_pivot.index[1]
hubtopfailinglocation=hub_df_pivot.index[1]
topfailinglocation,hubtopfailinglocation


# In[ ]:


example=sc_df_pivot.loc[:,("DOCKNO","Total")][1]
example1=hub_df_pivot.loc[:,("DOCKNO","Total")][1]
example,example1


# In[ ]:


sc_totnonccf_notofdcons=len(sc_df)
hub_totnonccf_notofdcons=len(hub_df)
sc_totnonccf_notofdcons,hub_totnonccf_notofdcons


# In[ ]:


sc_critnonccfdf=sc_df[(sc_df["HOURS_LYING"]!="0-24")&(sc_df["HOURS_LYING"]!="24-48")]
hub_critnonccfdf=hub_df[(hub_df["HOURS_LYING"]!="0-24")&(hub_df["HOURS_LYING"]!="24-48")]
len(sc_critnonccfdf),len(hub_critnonccfdf)


# In[ ]:


sc_df_pivot['DOCKNO']=sc_df_pivot['DOCKNO'].astype(int)
hub_df_pivot['DOCKNO']=hub_df_pivot['DOCKNO'].astype(int)


# In[ ]:


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

TO=['hubmgr_spot@spoton.co.in','aom_spot@spoton.co.in','dom_spot@spoton.co.in','rom_spot@spoton.co.in','rajkumar@spoton.co.in','deepak.sharma@spoton.co.in']
#TO=['shravani.g@spoton.co.in','sangeetha.s@spoton.co.in','vaishnavi@spoton.co.in','sharanagouda.biradar@spoton.co.in']
FROM='reports.ie@spoton.co.in'
#CC=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in','anitha.thyagarajan@spoton.co.in','shivananda.p@spoton.co.in']
CC=['abhik.mitra@spoton.co.in','jothi.menon@spoton.co.in','shivananda.p@spoton.co.in','pawan.sharma@spoton.co.in','rajesh.kumar@spoton.co.in','sharmistha.majumdar@spoton.co.in','SQ_spot@spoton.co.in','mahesh.reddy@spoton.co.in','anoop.kumar@spoton.co.in','avnish.tripathi@spoton.co.in','yogesh.singh@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
msg["Subject"] = "OPS Controllable Cons Lying at @ HUB" + " : " + date
html='''<html>
<style>
p
{
  margin:0;
  margin-top: 5px;
  padding:0;
  font-size:17px;
    line-height:20px;
}
</style>
<h3>Dear All,</h3>
<p>Please Find POD's Summary.</p>
</html>'''


s = Template(html).safe_substitute()
report=""
#report+=s
#report+='<br>'+final_dff5.to_html()+'<br>'
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='Please Find Total OPS Controllable Cons lying @ HUB :'+str(hub_totnonccf_notofdcons)
report+='<br>'
report+='<br>'+hub_df_pivot.to_html()+'<br>'
report+='<br>'
html5='''
<h5> To download the data , Please click the link below </h5>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Delayed_Cons_HUB_Data.csv"</a>http://spoton.co.in/downloads/IEProjects/ETA/Delayed_Cons_HUB_Data.csv</p></b>
    '''
report+=html5
abc=MIMEText(report,'html')
msg.attach(abc)
# part = MIMEBase('application', "octet-stream")
# part.set_payload( open(filePath,"rb").read() )
# encoders.encode_base64(part)
# part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
# msg.attach(part)
# part1 = MIMEBase('application', "octet-stream")
# part1.set_payload( open(filePath1,"rb").read() )
# encoders.encode_base64(part1)
# part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath1))
# msg.attach(part1)

server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()

