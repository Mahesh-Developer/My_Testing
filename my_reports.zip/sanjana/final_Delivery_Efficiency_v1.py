
# coding: utf-8

# In[ ]:


import pandas as pd
import numpy as np 
from datetime import datetime, timedelta, date 
import calendar
# import datetime 
from pandas import ExcelWriter 
import os 
import pandas.io.sql 
import sys 
from sqlalchemy import create_engine, MetaData, Table, select 
import pyodbc 
import smtplib 
from email.mime.multipart import MIMEMultipart 
from email.mime.text import MIMEText 
from email.mime.base import MIMEBase 
from email import encoders 
from string import Template 
import ftplib 
from sqlalchemy import * 
import pandas.io.sql 
import sys
import Utilities

querydate=date.today()-timedelta(1)
print (querydate)

# In[ ]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
cursor = cnxn.cursor()


# In[ ]:


query1=("""EXEC dbo.USP_DELV_EFF_SC_WISE_ALL 'S', '{0}' , '{1}'""".format(querydate,querydate))
query2=("""EXEC dbo.USP_DELV_EFF_SC_WISE_ALL 'D', '{0}' , '{1}'""".format(querydate,querydate))
#print (query1)

data=pd.read_sql(query1,Utilities.cnxn)
#print (data)
data1=pd.read_sql(query2,Utilities.cnxn)
#print (data1)
print (len(data))
print (len(data1))


# In[ ]:


data.rename(columns={'CCF': 'CCF_without_DRS_block'}, inplace=True)
# data.rename(columns={'NON-CCF': 'STF'}, inplace=True)
data.rename(columns={'NON_CCF': 'STF'}, inplace=True)
#print (data.head())
data[['DRS_BLOCK','CCF_without_DRS_block']]
data = data.reset_index()
data['CCF']=data['DRS_BLOCK'] + data['CCF_without_DRS_block']


# In[ ]:


Std = data[data['DEL_LOCATION_TYPE']=='STD']


# In[ ]:


pivotS=pd.pivot_table(Std,index=["ControlArea",],values=["TOTAL","Delivered","Opening","Incoming"],aggfunc={"Incoming":sum,"Opening":sum,"TOTAL":sum,"Delivered":sum},fill_value=0,margins=True)
pivotS['STD_DE%'] = pd.np.round((pivotS['Delivered'] / pivotS['TOTAL'])*100,0)
pivotS=pivotS.reset_index()


# In[ ]:


pivotS['STD_DE%']=pivotS['STD_DE%'].astype(int)


# In[ ]:


pivotS=pivotS[['ControlArea','TOTAL','Opening','Incoming','Delivered','STD_DE%']]


# In[ ]:


branchpivotS=pd.pivot_table(Std,index=["ControlArea","DEST_BRCD"],values=["TOTAL","Delivered","Opening","Incoming"],aggfunc={"Incoming":sum,"Opening":sum,"TOTAL":sum,"Delivered":sum},fill_value=0,margins=True)
branchpivotS['STD_DE%'] = pd.np.round((branchpivotS['Delivered'] / branchpivotS['TOTAL'])*100,0)


# In[ ]:


branchpivotS=branchpivotS.replace([np.inf,-np.inf],np.nan).fillna('-')


# In[ ]:


branchpivotS=branchpivotS.reset_index()
branchpivotS=branchpivotS[['ControlArea','DEST_BRCD','TOTAL','Opening','Incoming','Delivered','STD_DE%']]

#branchpivotS


# In[ ]:


opfilevar=querydate
opfilevar


# In[ ]:


deliveredcons_std=Std['Delivered'].sum()
openingcons_std=Std['Opening'].sum()
incomingcons_std=Std['Incoming'].sum()
total_std=Std['TOTAL'].sum()
deliveredcons_std,openingcons_std,incomingcons_std,total_std


# In[ ]:


deliveryefficiency_std=pd.np.round(deliveredcons_std*100.0/total_std)
deliveryefficiency_std


# In[ ]:


from pandas import ExcelWriter


# In[ ]:


with ExcelWriter(r'D:\Data\eta_rank\Delivery_Efficiency\Delivery_Efficiency_'+str(opfilevar)+'.xlsx') as writer:
        ###orginal_cancel_basedata.to_excel(writer, sheet_name='Sheet1',engine='xlsxwriter')
        branchpivotS.to_excel(writer, sheet_name='SC_WISE',engine='xlsxwriter')
        pivotS.to_excel(writer, sheet_name='AREA_WISE',engine='xlsxwriter')

with ExcelWriter(r'D:\Data\eta_rank\Delivery_Efficiency\Delivery_Efficiency.xlsx') as writer:
        ###orginal_cancel_basedata.to_excel(writer, sheet_name='Sheet1',engine='xlsxwriter')
        branchpivotS.to_excel(writer, sheet_name='SC_WISE',engine='xlsxwriter')
        pivotS.to_excel(writer, sheet_name='AREA_WISE',engine='xlsxwriter')


# In[ ]:


filePath1=r'D:\Data\eta_rank\Delivery_Efficiency\Delivery_Efficiency.xlsx'


# In[ ]:


TO = ["reports.ie@spoton.co.in"]
# TO=['vishwas.j@spoton.co.in']
FROM="reports.ie@spoton.co.in"
# CC=["mahesh.reddy@spoton.co.in"]
CC = ["reports.ie@spoton.co.in"]
# BCC=["vishwas.j@spoton.co.in"]
BCC = ["sqtf@spoton.co.in","SQ_spot@spoton.co.in","abhik.mitra@spoton.co.in",'mahesh.reddy@spoton.co.in',"sachidanand.pandey@spoton.co.in","renugopal.l@spoton.co.in","sathya.chander@spoton.co.in","alagu.mahendran@spoton.co.in","awadhesh.kumar.mishra@spoton.co.in","sanjay.parab@spoton.co.in","ramesh.s@spoton.co.in","md.zaya@spoton.co.in","Pradyumna.Kumar@Spoton.Co.In","rajesh.mishra@spoton.co.in","raghavendra.rao@spoton.co.in","ashwani.gangwar@spoton.co.in","pramod.pandey@spoton.co.in","trilochan.panda@spoton.co.in","sunil.nakte@spoton.co.in","chandrima.banerjee@spoton.co.in", "suresh.d@spoton.co.in", "pankaj.jha@spoton.co.in","aom_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in","narendra.londhe@spoton.co.in"]
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
html='''<html>
<style>
p
{
  margin:0;
  margin-top: 5px;
  padding:0;
  font-size:15px;
    line-height:20px;
}
</style>
<h4>Dear All,</h4>
<p>Delivered = $deliveredcons_std</p>
<p>Opening Stock = $openingcons_std</p>
<p>Incoming Stock = $incomingcons_std</p>
<p>The Overall Delivery efficiency of STD cons is $deliveryefficiency_std %</p>
<p>PFB the Delivery Efficiency Area wise as of $opfilevar</p>
</html>'''

html3='''
<h5>The AREA-WISE and SC-WISE summary has been attached in the mail.</h5>
<h5> For the base data, please refer the link </h5>
<p><a href= "http://10.109.230.50/downloads/OCID/OCID.xls"</a>http://10.109.230.50/downloads/OCID/OCID.xls</p></b>
'''
#s = Template(html).safe_substitute(deliveryefficiency_std=deliveryefficiency_std,avrghoursofdelcons_std=avrghoursofdelcons_std,ccfpercentagecons_std=ccfpercentagecons_std,combinedfreeconlist_std=combinedfreeconlist_std,totaldueconsfree_std=totaldueconsfree_std,totalduecons_std=totalduecons_std,opfilevar=opfilevar,closingstoctl24aging_std=closingstoctl24aging_std,closingstoctl24cons_std=closingstoctl24cons_std,closingstockcons_std=closingstockcons_std,incomingcons_std=incomingcons_std,openingcons_std=openingcons_std,deliveredcons_std=deliveredcons_std)
report=""
report+="Dear All,"
report+='<br>'
report+='<br>'
report+="Delivered ="+str(deliveredcons_std)
report+='<br>'
report+="Opening Stock ="+str(openingcons_std)
report+='<br>'
report+="Incoming Stock ="+str(incomingcons_std)
report+='<br>'
report+="The Overall Delivery efficiency of STD cons is "+str(deliveryefficiency_std)+ '%'
report+='<br>'
report+="PFB the Delivery Efficiency Area wise"
report+='<br>'


report+='<br>'+pivotS.to_html()+'<br>'
report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filePath1,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath1))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
# server=smtplib.SMTP('smtp.gmail.com', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
# server.login('vishwas.j@spoton.co.in', 'Nov@2018')
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()



# In[ ]:


## ODA


# In[ ]:


Oda = data[data['DEL_LOCATION_TYPE']=='ODA']
pivotO=pd.pivot_table(Oda,index=["ControlArea",],values=["TOTAL","Opening","Delivered"],aggfunc={"TOTAL":sum,"Opening":sum,"Delivered":sum},fill_value=0,margins=True)
pivotO['ODA_DE%'] = pivotO['Delivered'].divide(pivotO['TOTAL'])*100
pivotO=pivotO.reset_index()
pivotO=pivotO[['ControlArea','Delivered','Opening','ODA_DE%']]


# In[ ]:
### Vishwas Edit
pivotO=pivotO.replace([np.inf,-np.inf],np.nan)
pivotO.fillna(0,inplace=True)
pivotO['ODA_DE%']=pivotO['ODA_DE%'].astype(int)
### Vishwas Edit

# In[ ]:


pivotO=pivotO[['ControlArea','Opening','Delivered','ODA_DE%']]


# In[ ]:


Oda = data[data['DEL_LOCATION_TYPE']=='ODA']
branchpivotO=pd.pivot_table(Oda,index=["ControlArea","DEST_BRCD"],values=["TOTAL","Opening","Delivered"],aggfunc={"TOTAL":sum,"Opening":sum,"Delivered":sum},fill_value=0,margins=True)
branchpivotO['ODA_DE%'] = pd.np.round(branchpivotO['Delivered'].divide(branchpivotO['TOTAL'])*100,0)
branchpivotO=branchpivotO.replace([np.inf,-np.inf],np.nan).fillna('-')
branchpivotO=branchpivotO.reset_index()
branchpivotO=branchpivotO[['ControlArea',"DEST_BRCD",'Delivered','Opening','ODA_DE%']]


# In[ ]:


#branchpivotO['ODA_DE%']=pd.np.round(branchpivotO['ODA_DE%'],0)
branchpivotO=branchpivotO[['ControlArea','DEST_BRCD','Opening','Delivered','ODA_DE%']]



# In[ ]:


deliveredcons_oda=Oda['Delivered'].sum()
openingcons_oda=Oda['Opening'].sum()
total_oda=Oda['TOTAL'].sum()
deliveryefficiency_oda=pd.np.round(deliveredcons_oda*100.0/total_oda,1)
deliveredcons_oda,openingcons_oda,total_oda,deliveryefficiency_oda


# In[ ]:


with ExcelWriter(r'D:\Data\eta_rank\Delivery_Efficiency_ODA\Delivery_Efficiency_ODA'+str(opfilevar)+'.xlsx') as writer:
        ###orginal_cancel_basedata.to_excel(writer, sheet_name='Sheet1',engine='xlsxwriter')
        branchpivotO.to_excel(writer, sheet_name='SC_WISE',engine='xlsxwriter')
        pivotO.to_excel(writer, sheet_name='AREA_WISE',engine='xlsxwriter')

with ExcelWriter(r'D:\Data\eta_rank\Delivery_Efficiency_ODA\Delivery_Efficiency_ODA.xlsx') as writer:
        ###orginal_cancel_basedata.to_excel(writer, sheet_name='Sheet1',engine='xlsxwriter')
        branchpivotO.to_excel(writer, sheet_name='SC_WISE',engine='xlsxwriter')
        pivotO.to_excel(writer, sheet_name='AREA_WISE',engine='xlsxwriter')


# In[ ]:


filePath2=r'D:\Data\eta_rank\Delivery_Efficiency_ODA\Delivery_Efficiency_ODA.xlsx'


# In[ ]:


TO = ["reports.ie@spoton.co.in"]
# TO=['vishwas.j@spoton.co.in']
FROM="reports.ie@spoton.co.in"
# CC=["mahesh.reddy@spoton.co.in"]
CC = ["reports.ie@spoton.co.in"]
# BCC=["vishwas.j@spoton.co.in"]
BCC = ["sqtf@spoton.co.in","SQ_spot@spoton.co.in","abhik.mitra@spoton.co.in",'mahesh.reddy@spoton.co.in',"sachidanand.pandey@spoton.co.in","renugopal.l@spoton.co.in","sathya.chander@spoton.co.in","alagu.mahendran@spoton.co.in","awadhesh.kumar.mishra@spoton.co.in","sanjay.parab@spoton.co.in","ramesh.s@spoton.co.in","md.zaya@spoton.co.in","Pradyumna.Kumar@Spoton.Co.In","rajesh.mishra@spoton.co.in","raghavendra.rao@spoton.co.in","ashwani.gangwar@spoton.co.in","pramod.pandey@spoton.co.in","trilochan.panda@spoton.co.in","sunil.nakte@spoton.co.in","chandrima.banerjee@spoton.co.in", "suresh.d@spoton.co.in", "pankaj.jha@spoton.co.in","aom_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in","narendra.londhe@spoton.co.in"]
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "ODA DELIVERY EFFICIENCY" + " - " + str(opfilevar)

html3='''
<h5> For the base data, please refer the link </h5>
<p><a href= "http://spoton.co.in/downloads/OCID/OCID.xls"</a>http://spoton.co.in/downloads/OCID/OCID.xls</p></b>
'''

report=""
report+='Dear All,'
report+='<br>'
report+='PFB the ODA Delivery Efficiency of '+str(opfilevar)
report+='<br>'
report+='<br>'
report+='Delivered = '+str(deliveredcons_oda)
report+='<br>'
report+='Opening Stock = '+str(openingcons_oda)
report+='<br>'
report+='ODA DE = '+str(deliveryefficiency_oda)+ '%'
report+='<br>'
report+='<br>'+pivotO.to_html()+'<br>'
report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)


part = MIMEBase('application', "octet-stream")
part.set_payload( open(filePath2,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath2))
msg.attach(part)
    
server=smtplib.SMTP('smtp.sendgrid.net', 587)
# server=smtplib.SMTP('smtp.gmail.com', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
# server.login('vishwas.j@spoton.co.in', 'Nov@2018')
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()



# In[ ]:


## TOTAL DE


# In[ ]:


pivot=pd.pivot_table(data,index=["ControlArea",],values=["TOTAL","Delivered"],aggfunc={"TOTAL":sum,"Delivered":sum},fill_value=0,margins=True)
pivot['DE%'] = pd.np.round((pivot['Delivered'] / pivot['TOTAL'])*100)
pivot=pivot.reset_index()


# In[ ]:


pivot['DE%']=pivot['DE%'].astype(int)

pivot=pivot[['ControlArea','TOTAL','Delivered','DE%']]
# In[ ]:


branchpivot=pd.pivot_table(data,index=["ControlArea","DEST_BRCD"],values=["TOTAL","Delivered"],aggfunc={"TOTAL":sum,"Delivered":sum},fill_value=0,margins=True)
branchpivot['DE%'] = pd.np.round((branchpivot['Delivered'] / branchpivot['TOTAL'])*100)
branchpivot=branchpivot.replace([np.inf,-np.inf],np.nan).fillna('-')
branchpivot=branchpivot.reset_index()

branchpivot=branchpivot[['ControlArea','DEST_BRCD','TOTAL','Delivered','DE%']]
# In[ ]:


pivot.rename(columns={'ControlArea':'Area','TOTAL':'Stock'},inplace=True)


# In[ ]:


oda_pivot_summary=pivotO[['ControlArea','ODA_DE%']]
std_pivot_summary=pivotS[['ControlArea','STD_DE%']]


# In[ ]:


merge=pd.merge(pivot,oda_pivot_summary,left_on='Area',right_on='ControlArea',how='outer')
del merge['ControlArea']


# In[ ]:


merge1=pd.merge(merge,std_pivot_summary,left_on='Area',right_on='ControlArea',how='outer')
del merge1['ControlArea']

merge1=merge1[['Area','Stock','Delivered','DE%','STD_DE%','ODA_DE%']]
# In[ ]:


merge1.head()


# In[ ]:


totaldeliveredcons_total=data['Delivered'].sum()
stockcons_total=data['TOTAL'].sum()
totalefficiency_total=pd.np.round(totaldeliveredcons_total*100.0/stockcons_total,1)
totaldeliveredcons_total,stockcons_total,totalefficiency_total


# In[ ]:


with ExcelWriter(r'D:\Data\eta_rank\Delivery_Efficiency_Total\Delivery_Efficiency_TOTAL'+str(opfilevar)+'.xlsx') as writer:
        ###orginal_cancel_basedata.to_excel(writer, sheet_name='Sheet1',engine='xlsxwriter')
        branchpivot.to_excel(writer, sheet_name='SC_WISE',engine='xlsxwriter')
        pivot.to_excel(writer, sheet_name='AREA_WISE',engine='xlsxwriter')

with ExcelWriter(r'D:\Data\eta_rank\Delivery_Efficiency_Total\Delivery_Efficiency_TOTAL.xlsx') as writer:
        ###orginal_cancel_basedata.to_excel(writer, sheet_name='Sheet1',engine='xlsxwriter')
        branchpivot.to_excel(writer, sheet_name='SC_WISE',engine='xlsxwriter')
        pivot.to_excel(writer, sheet_name='AREA_WISE',engine='xlsxwriter')





filePath4=r'D:\Data\eta_rank\Delivery_Efficiency_Total\Delivery_Efficiency_TOTAL.xlsx'


# In[ ]:


TO = ["reports.ie@spoton.co.in"]
# TO=['vishwas.j@spoton.co.in']
FROM="reports.ie@spoton.co.in"
# CC=["mahesh.reddy@spoton.co.in"]
CC = ["reports.ie@spoton.co.in"]
# BCC=["vishwas.j@spoton.co.in"]
BCC = ['sc_incharge@spoton.co.in',"sqtf@spoton.co.in","SQ_spot@spoton.co.in","abhik.mitra@spoton.co.in",'mahesh.reddy@spoton.co.in',"sachidanand.pandey@spoton.co.in","renugopal.l@spoton.co.in","sathya.chander@spoton.co.in","alagu.mahendran@spoton.co.in","awadhesh.kumar.mishra@spoton.co.in","sanjay.parab@spoton.co.in","ramesh.s@spoton.co.in","md.zaya@spoton.co.in","Pradyumna.Kumar@Spoton.Co.In","rajesh.mishra@spoton.co.in","raghavendra.rao@spoton.co.in","ashwani.gangwar@spoton.co.in","pramod.pandey@spoton.co.in","trilochan.panda@spoton.co.in","sunil.nakte@spoton.co.in","chandrima.banerjee@spoton.co.in", "suresh.d@spoton.co.in", "pankaj.jha@spoton.co.in","aom_spot@spoton.co.in","dom_spot@spoton.co.in","rom_spot@spoton.co.in","narendra.londhe@spoton.co.in"]
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "TOTAL DELIVERY EFFICIENCY" + " - " + str(opfilevar)

html3='''
<h5> To download the Duedate cons Undel, Please click the link below </h5>
<p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Duedate_cons_undel.xlsx"</a>http://spoton.co.in/downloads/IEProjects/ETA/Duedate_cons_undel.xlsx</p></b>
'''

report=""
report+='Dear All,'
report+='<br>'
report+='PFB the TOTAL Delivery Efficiency of '+str(opfilevar)
report+='<br>'
report+='<br>'
report+='Total Delivered = '+str(totaldeliveredcons_total)
report+='<br>'
report+='Total Stock = '+str(stockcons_total)
report+='<br>'
report+='Total Delivery Efficiency = '+str(totalefficiency_total)+ '%'
report+='<br>'
report+='<br>'+merge1.to_html()+'<br>'
report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)


part = MIMEBase('application', "octet-stream")
part.set_payload( open(filePath4,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath4))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
# server=smtplib.SMTP('smtp.gmail.com', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
# server.login('vishwas.j@spoton.co.in', 'Nov@2018')
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()



# In[ ]:


