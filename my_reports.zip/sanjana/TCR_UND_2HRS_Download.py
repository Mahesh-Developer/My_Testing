
# coding: utf-8

# In[1]:

import numpy as np
import pandas as pd
from pandas import ExcelWriter
from datetime import datetime,timedelta,date
import urllib


# In[2]:

tcrdata = pd.io.excel.read_excel('http://10.109.230.50/downloads/TCR_UND_2HRS/TCR_UND_ISDEPART_YES_2HRS.xls','TCR_UND_ISDEPART_YES_2HRS ')
ts = tcrdata.iloc[0]['TIME STAMP'].to_pydatetime()


# In[3]:

opfilevar=ts.date()
opfilevar1=ts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=np.ceil(float(currhrs)/60)

print 'opfilevar,opfilevar2',opfilevar,opfilevar2
tcrdata.to_csv(r'D:\Data\eta_intransitfiles\ETA_Intrasit'+'-'+str(opfilevar)+'-'+str(opfilevar2)+'.csv', encoding="utf-8")
print 'Done!!!!!'

