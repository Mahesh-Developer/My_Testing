
# coding: utf-8

# In[33]:


import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
from string import Template
import Utilities

# In[2]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()


# In[3]:


ewbnpquery = ("""
        EXEC dbo.USP_EWAYBILL_BOOKEDCONS_SQ
        """)


# In[8]:


ewbfull = pd.read_sql(ewbnpquery, Utilities.cnxn)


# In[9]:


len(ewbfull)


# In[6]:


ewbfull.columns


# In[10]:


ewb_na = ewbfull[ewbfull['IS_EWAYBILL_REQUIRE']=='YES']


# In[11]:


len(ewb_na)


# In[12]:


pivot=pd.pivot_table(ewb_na,index=['ORG_AREA'],columns=['IS_EWAYBILL_AVLB','IS_UPDATED'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True)


# In[14]:


pivot=pivot.sort_values([('DOCKNO','All')],ascending=False)


# In[16]:


pivot=pivot.fillna(0)


# In[18]:


pivot['DOCKNO']=pivot['DOCKNO'].astype(int)


# In[19]:


pivot


# In[20]:


total_cons=len(ewbfull)
total_cons


# In[21]:


ewbill_req_count=ewbfull[ewbfull['IS_EWAYBILL_REQUIRE']=='YES']
len(ewbill_req_count)


# In[22]:


ewbill_avlb_count=ewbfull[(ewbfull['IS_EWAYBILL_REQUIRE']=='YES') & (ewbfull['IS_EWAYBILL_AVLB']=='YES')]
len(ewbill_avlb_count)


# In[23]:


ewbill_notavlb_count=ewbfull[(ewbfull['IS_EWAYBILL_REQUIRE']=='YES') & (ewbfull['IS_EWAYBILL_AVLB']=='NO')]
len(ewbill_notavlb_count)


# In[24]:


ewbill_PARTB_updt_count=ewbfull[(ewbfull['IS_EWAYBILL_REQUIRE']=='YES') & (ewbfull['IS_EWAYBILL_AVLB']=='YES')&(ewbfull['IS_UPDATED']=='YES')]
len(ewbill_PARTB_updt_count)


# In[25]:


ewbill_PARTB_notupdt_count=ewbfull[(ewbfull['IS_EWAYBILL_REQUIRE']=='YES') & (ewbfull['IS_EWAYBILL_AVLB']=='YES')&(ewbfull['IS_UPDATED']=='NO')]
len(ewbill_PARTB_notupdt_count)


# In[26]:


reportts = datetime.now()
opfilevar=reportts.date()
opfilevar1=reportts.time()
ct2= str (opfilevar1)
currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

opfilevar2=pd.np.round((float(currhrs)/60),0)


# In[27]:


ewbill_PARTB_notupdt_count.to_csv(r'D:\Data\Ewaybill\Cons Booked\EWB_req_avlb_ntupdated'+str(opfilevar)+'.csv')
ewbill_notavlb_count.to_csv(r'D:\Data\Ewaybill\Cons Booked\EWB_req_notupdated_'+str(opfilevar)+'.csv')


# In[28]:


ewbill_PARTB_notupdt_count.to_csv(r'D:\Data\Ewaybill\Cons Booked\EWB_req_avlb_ntupdated.csv')
ewbill_notavlb_count.to_csv(r'D:\Data\Ewaybill\Cons Booked\EWB_req_notupdated_.csv')


# In[29]:


oppath1 = r'D:\Data\Ewaybill\Cons Booked\EWB_req_avlb_ntupdated.csv'
oppath2 = r'D:\Data\Ewaybill\Cons Booked\EWB_req_notupdated_.csv'


# In[34]:

TO=['mahesh.reddy@spoton.co.in']
CC=['mahesh.reddy@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in']
FROM='reports.ie@spoton.co.in'
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "Ewaybill  Compliance Report - Yesterday's Booking" + str(opfilevar)+"-"+str(opfilevar2)
html='''<html>
<h4>Dear All,</h4>
</html>'''
report=""
report+='Dear All,'

report+='<br>'
report+='Total Cons = '+str(total_cons)
report+='<br>'
report+= 'Cons where Ewaybill required = '+str(len(ewbill_req_count))
report+='<br>'
report+= 'Cons where Ewaybill Available = '+str(len(ewbill_avlb_count))
report+='<br>'
report+= 'Cons where Ewaybill Not Available = '+str(len(ewbill_notavlb_count))
report+='<br>'
report+= 'Cons where Ewaybill Part B Updated = '+str(len(ewbill_PARTB_updt_count))
report+='<br>'
report+= 'Cons where Ewaybill Part B Not Updated = '+str(len(ewbill_PARTB_notupdt_count))
report+=''
report+='<br>'
report+='<br>'+pivot.to_html()+'<br>'
abc=MIMEText(report,'html')
msg.attach(abc)

part = MIMEBase('application', "octet-stream")
part.set_payload( open(oppath1,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
msg.attach(part)

part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(oppath2,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath2))
msg.attach(part1)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()

