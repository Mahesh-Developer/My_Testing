# -*- coding: utf-8 -*-
"""
Created on Wed Jul 13 18:38:08 2016

@author: rajeeshv
"""
import graphlab as gl
import pandas as pd
import datetime
from datetime import datetime, timedelta
import calendar
import copy
#import graphlab as gl
import graphlab.aggregate as agg
from itertools import izip
import os

## invsf is the input file wiht the name dfbase.csv

invsf = gl.SFrame.read_csv(r'D:\Python\Scripts and Files\Path and Graph Files\sector_buildup_routing\dfbase.csv')
loclist = ['DESTCD','CURR BRANCHCODE','ORIGIN BRCODE']
maplist = dict({'MAAG': 'MAAC','NEIR': 'GAUB','RJPR': 'PTLF','SIKM': 'SILB','KLMF':'COKB','AMDE':'AMDO'})



def convloc(location):
    get_dict = maplist.get(location)
    if get_dict is None:
        return location
    else:
        return get_dict
    
for locnames in loclist:
    invsf[locnames] = invsf.apply(lambda x: convloc(x[locnames]))

## Saving the file for debugging. 
invsf.save('D:\Python\Scripts and Files\Path and Graph Files\sector_buildup_routing\debug_intransit123.csv',format='csv')