
# coding: utf-8

# In[1]:


"""
Created on Tue Aug 11 15:09:14 2015

@author: s1602vis
"""
import pandas as pd
import numpy as np
from pandas import ExcelWriter
import urllib
import csv
from datetime import datetime, timedelta, time, date
import os
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
import urllib
import ftplib
import traceback
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import Utilities

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


query = ("""EXEC UBESP_PUD_ANALYSIS_OPEN_CLOSE_STOCK_ARRV_DELV_SSRS_DL """)
print (query)

# In[2]:

def datestring(x):
    fulldate = datetime.strptime(x,'%d %b %Y %H:%M')
    return fulldate

def dockno(x):
    return x

yesterdate=date.today()-timedelta(hours=24)
# In[3]:

pmddata = pd.read_csv(r'http://10.109.230.50/downloads/PMD/PMD.csv')
#pmddata = pd.read_csv(r'C:\Data\OCID_PMD\PMD.csv')
#delivered = pd.io.excel.read_excel(r'C:\Data\OCID_PMD\OCID11D.xls','DELIVERED')

#delivered = pd.io.excel.read_excel(r'http://10.109.230.50/downloads/OCID/OCID.xls','DELIVERED')
delivered = pd.read_sql(query, Utilities.cnxn)
delivered.rename(columns={'CDELDT':'DUE DATE','DEFAULTHUB':'DEST DEFAULT HUB','DEST_BRCD':'DEST BRCD','DEST_BRNM':'DEST BRNM','DEST_BA_LOC':'DEST BA LOC','DEST_AREA':'DEST AREA','DEST_DEPOT':'DEST DEPOT','DEST_REGION':'DEST REGION','DEL_LOCATION_TYPE':'DEL LOCATION TYPE','ARRV_AT_DEST_SC':'ARRV AT DEST SC','DELY_DT':'DELY DT','DELDATE_MIN_ARRVDT':'DELDATE MIN ARRVDT','ORG_BRCD':'ORG BRCD','ORG_BRNM':'ORG BRNM','ORG_AREA':'ORG AREA','ORG_DEPOT':'ORG DEPOT','ORG_REGION':'ORG REGION','BAD_POD_STATUS':'BAD POD STATUS','NORMAL_DELIVERY':'NORMAL DELIVERY','ANDROID_DELIVERY':'ANDROID DELIVERY','ORG_PINCODE':'ORG PINCODE','DEST_PINCODE':'DEST PINCODE'},inplace=True)
pmddata.columns.tolist()
pmddata=pmddata.rename(columns={'\xef\xbb\xbfCON_ID2':'CON_ID2'})
pmddata.columns


# In[5]:

pmddata['Condate'] = pmddata.apply(lambda x:datestring(x['DATE2']),axis=1)


# In[6]:

vehlist = ['ADHOC']
yesterdaydf = pmddata[(pmddata['Condate'] >= yesterdate) & (pmddata['PUDTYPE2'].isin(vehlist))]
print len(yesterdaydf)
#yesterdaydf.to_csv(r'C:\Data\OCID_PMD\yesterdaydf.csv')


# In[7]:

opfilevar =date.today() - timedelta(hours=24)
opfilevar


# In[8]:

def roundoff(x):
    a = np.ceil(x)
    return a


# In[17]:

deliveredyest = pd.merge(yesterdaydf,delivered,left_on=['CON_ID2'],right_on=['DOCKNO'],how='outer')
columnsdel = ['CON_ID2','AREA2','REGION2','BRANCH_CODE2','PINTYPE','ACT_WT2','TYP2','COST2','DUE DATE','ARRV AT DEST SC','DELY DT','DELDATE MIN ARRVDT','BAVEHTYPE','BAVEHNO','BAVEHCAP'] 
deliveredyest = pd.DataFrame(deliveredyest,columns=columnsdel)

iy = deliveredyest[deliveredyest['DELDATE MIN ARRVDT']<0].index
deliveredyest.loc[iy,'DELDATE MIN ARRVDT'] = 0

deliveredgroupby = deliveredyest.groupby(['BRANCH_CODE2']).agg({'CON_ID2': 'count','DELDATE MIN ARRVDT': np.mean}).reset_index()


# <b> For Cap utilization</b>

# In[18]:

deliveredbacap = deliveredyest.drop_duplicates(cols='BAVEHNO')
print len(deliveredbacap)
deliveredbacapgroupby = deliveredbacap.groupby(['BRANCH_CODE2']).agg({'BAVEHCAP':'sum'}).reset_index()
print len(deliveredbacapgroupby)
iz = deliveredbacapgroupby[deliveredbacapgroupby['BAVEHCAP']==0].index
deliveredbacapgroupby.loc[iz,'BAVEHCAP'] = 1


totalbacap = deliveredbacapgroupby['BAVEHCAP'].sum()
totalactwt = deliveredyest['ACT_WT2'].sum()
totalcost = deliveredyest['COST2'].sum()
totalutil = np.round(((totalactwt*100)/totalbacap),2)
totalcpk = np.round((totalcost/totalactwt),2)


deliveredyestwts = deliveredyest.groupby(['BRANCH_CODE2']).agg({'ACT_WT2':'sum','COST2':'sum'}).reset_index()

deliveredcaputil = pd.merge(deliveredyestwts,deliveredbacapgroupby,left_on=['BRANCH_CODE2'],right_on=['BRANCH_CODE2'],how='outer')

deliveredcaputil['Utilization'] = deliveredcaputil.apply(lambda x:roundoff(x['ACT_WT2']*100.0/x['BAVEHCAP']),axis=1)
deliveredcaputil['CPKG'] = deliveredcaputil.apply(lambda x:np.round((x['COST2']/x['ACT_WT2']),2),axis=1)


# In[19]:

deliveredgroupby['Avg Cooling Hrs'] = deliveredgroupby.apply(lambda x : roundoff(x['DELDATE MIN ARRVDT']),axis=1)

deliveredbacapmerge = pd.merge(deliveredcaputil,deliveredgroupby,left_on=['BRANCH_CODE2'],right_on=['BRANCH_CODE2'],how='outer')

columnsdelgrpby = ['BRANCH_CODE2','CON_ID2','ACT_WT2','Utilization','CPKG'] 
deliveredbacapmerge = pd.DataFrame(deliveredbacapmerge,columns=columnsdelgrpby)


# In[45]:

deliveredyest = deliveredyest.dropna(subset=['PINTYPE'])

# For STD and ODA separate Cooling Hours
deliveredyestdlv = deliveredyest[deliveredyest['TYP2']=='DLV']

coolinghrs = (deliveredyestdlv['DELDATE MIN ARRVDT'].sum())*1.0
totalconsdlv = (deliveredyestdlv['CON_ID2'].count())*1.0

totalcons = (deliveredyest['CON_ID2'].count())*1.0

avgcooling = np.round((coolinghrs/totalconsdlv),2)


stddeliveredyest = deliveredyestdlv[deliveredyestdlv['PINTYPE']=='STD']
stdcoolinghrs = (stddeliveredyest['DELDATE MIN ARRVDT'].sum())*1.0
stdtotalcons = len(stddeliveredyest)
stdavgcooling = np.round((stdcoolinghrs/stdtotalcons),2)

try:
    odadeliveredyest = deliveredyestdlv[deliveredyestdlv['PINTYPE']=='ODA']
    odacoolinghrs = (odadeliveredyest['DELDATE MIN ARRVDT'].sum())*1.0
    odatotalcons = len(odadeliveredyest)
    odaavgcooling = np.round((odacoolinghrs/odatotalcons),2)
except(ZeroDivisionError):
    odaavgcooling = 0

# For STD and ODA separate Cooling Hours

totaldelduecons = deliveredyestdlv[deliveredyestdlv['DUE DATE']>= opfilevar] 
dueconsno = len(totaldelduecons)



# In[46]:
print ('done')

with ExcelWriter(r'D:\Data\Market_vehicle_ageing\Market_Delivered_'+str(opfilevar)+'.xlsx') as writer:
    deliveredbacapmerge.to_excel(writer, sheet_name='SUMMARY',engine='xlsxwriter')
    deliveredyest.to_excel(writer, sheet_name='DATA',engine='xlsxwriter')
    
oppath1 = r'D:\Data\Market_vehicle_ageing\Market_Delivered_'+str(opfilevar)+'.xlsx'



# In[47]:

filePath = oppath1
def sendEmail(TO = ["sukumar.sakthivel@spoton.co.in"],
            #TO = ["vishwas.j@spoton.co.in"],
            #CC = ["vishwas.j@spoton.co.in"],
            CC = ["rajeesh.vr@spoton.co.in"],
            FROM="mahesh.reddy@spoton.co.in"):
    HOST = "smtp.spoton.co.in"
#smtplib.SMTP('smtp.spoton.co.in', 25)

    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    #msg["Subject"] = "Cons Delivered By Market" + " - " + str(opfilevar)
    msg["Subject"] = "Cons Delivered By Market" + " - " + str(opfilevar)
    body_text = """
    Dear All,
    
    PFA the Cons delivered by Market vehicle on """ + str(opfilevar) +"""
    
    Total cons via Market = """+str(totalcons)+""" 
    Total cons delivered = """+str(totalconsdlv)+"""
    Average cooling hrs = """+str(avgcooling)+""" Hrs
    Average cooling hrs of STD Cons = """+str(stdavgcooling)+""" Hrs
    Average cooling hrs of ODA Cons = """+str(odaavgcooling)+""" Hrs
    Cons having Duedate>= """+str(opfilevar)+""" = """ +str(dueconsno)+"""
    Overall Capacity Utilization = """+str(totalutil)+""" %
    Overall CPKG = """+str(totalcpk)+"""
    
    PFB the Summary Branch wise of cons delivered and their ageing"""+"""
    
    """+str(deliveredbacapmerge)+"""

    """

    if body_text:
        msg.attach( MIMEText(body_text) )
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filePath,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
    msg.attach(part)
    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login("spoton.net.in", "Star@123#")

    try:
        failed = server.sendmail(FROM, TO+CC, msg.as_string())
        server.close()
    except Exception, e:
        errorMsg = "Unable to send email. Error: %s" % str(e)

if __name__ == "__main__":
    sendEmail()
#Sending output file via mail ends


# In[ ]:



