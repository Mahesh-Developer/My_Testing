
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
# import matplotlib.pyplot as plt
# import seaborn
from glob import glob
from IPython import display
from datetime import datetime,timedelta
import pyodbc
# import geopy
import pandas as pd
import calendar
import os
import Utilities

# In[2]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=SQTeam;PWD=eSp0T@321$Sq")
# cursor = cnxn.cursor()


# In[3]:


cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
cursor = cnxn.cursor()


# In[4]:


Year1=int(datetime.strftime(datetime.now(),'%Y'))
Year1

Month1=int(datetime.strftime(datetime.now(),'%m'))

Month1


# In[5]:


EDAY=calendar.monthrange(Year1, Month1)[1]
EDAY


# In[6]:


Sday=1


now= int(datetime.strftime((datetime.today()),'%d'))
now


# In[7]:


# if now == 1:
#     Month1= int(datetime.strftime(datetime.now(),'%m'))-1
#     EDAY=calendar.monthrange(Year1, Month1)[1]
    
#     print( Month1,EDAY, 'equal to one' )
    
# else:
#      print( Month1,EDAY )
    
  


# In[8]:


if now == 1:
    Month1= Month1 -1
    EDAY=calendar.monthrange(Year1, Month1)[1]
    
    print( Month1,EDAY, 'equal to one' )
    
else:
     print( 'NOT FIRST OF THE MONTH',Month1,EDAY )
    
  


# In[9]:


startdate=datetime.strftime((datetime.today().replace(day=Sday,
                                                      month= Month1,                                                   
                                                      year= Year1)),'%Y-%m-%d')


yest=datetime.now()-timedelta(1)
enddate=yest.date()
enddate=str(enddate)

# startdate
[[startdate,enddate]]


# In[10]:


query= """ EXEC dbo.USP_APT_DELV_PERFRMC_DAILY_SQ '{0}','{1}'   """ .format(startdate,enddate)
# query= """ EXEC dbo.USP_APT_DELV_PERFRMC_DAILY_SQ '{0}','{1}'   """ .format('2019-03-05','2019-03-07')
print (query)


# In[11]:


rawDATA=pd.read_sql(query,Utilities.cnxn)


# In[12]:


Q1=pd.read_sql(query,cnxn)


# In[13]:


Q1.rename(columns={'PERFORMANCE':'Perf_Y_N'}, inplace=True)


# In[14]:


Q1[['APT_DATE']]


# In[15]:


def tag (APORD1):     
#### tag is the name of the function, APORD1 is the variable which inherits the values in 'APORDER' column, 
###  then it goes on to test the condition
    if APORD1== 1:
        return '1'
    elif APORD1== 2:
        return '2' 
    else:
        return '3+ Days'

Q1.head()

Q1['APORDER1'] = Q1.apply(lambda x:tag(x['APORDER']), axis=1)


# In[16]:


def tagPERF (PERF):     
#### tag is the name of the function, z is the variable which inherits the values in 'APORDER' column, 
###  then it goes on to test the condition
    if PERF== 'YES' :
        return 'SUCCESS'
    else:
        return 'FAILURE'

Q1['PERFORMANCE'] = Q1.apply(lambda x:tagPERF(x['Perf_Y_N']), axis=1)


# In[17]:


# Q1.head()


# In[18]:


ECM=Q1[Q1.Con_Category == 'e-Commerce']


# In[19]:


df=pd.pivot_table(ECM,index=["APT_DATE"], 
                  columns=["PERFORMANCE","APORDER1"], 
                  values= ['DOCKNO'],
                  aggfunc={'DOCKNO':len},margins= True, margins_name= 'Total Cons' ).fillna(0)
df['DOCKNO']=df['DOCKNO'].astype(int)
df.head(2)
df.rename(columns={'DOCKNO':'E Commerce - Cons','APT_DATE':'DATE'}, inplace=True)
# df[('E Commerce - Cons','Total Cons')]
df


# In[20]:


df['E Commerce - Cons','SUCCESS Total','']=df['E Commerce - Cons','SUCCESS'].sum(axis=1)
df['E Commerce - Cons','FAILURE Total','']=df['E Commerce - Cons','FAILURE'].sum(axis=1)
df


# In[21]:



try:
    df['E Commerce - %','FAILURE%','1']=pd.np.round((df['E Commerce - Cons','FAILURE','1']/
                                                     (df['E Commerce - Cons','FAILURE','1']+ 
                                                      df['E Commerce - Cons','SUCCESS','1']))*100,0).fillna(0).astype(int)
except:
    pass
    
try:    
    df['E Commerce - %','FAILURE% Total','']=pd.np.round((df['E Commerce - Cons','FAILURE Total','']/
                                                     df['E Commerce - Cons','Total Cons'])*100,0).astype(int)
except:
    pass
# try:
#     df['E Commerce - %','FAILURE%','3+ Days']=pd.np.round((df['E Commerce - Cons','FAILURE','3+ Days']
#                                                             /df['E Commerce - Cons','Total Cons'])*100,0).astype(int)
# except:
#        print (df)

df


# In[22]:


# try:
    
#     df['E Commerce - %','FAILURE% Total','']=df['E Commerce - %','FAILURE%'].sum(axis=1)
# except:
#     pass


try:
    df['E Commerce - %','FAILURE%','1']=df['E Commerce - %','FAILURE%','1'].astype(str)+'%'
except: 
    pass
try:  
    df['E Commerce - %','FAILURE%','2']=df['E Commerce - %','FAILURE%','2'].astype(str)+'%'
except: 
    pass
try:    
    df['E Commerce - %','FAILURE%','3+ Days']=df['E Commerce - %','FAILURE%','3+ Days'].astype(str)+'%'
except: 
    pass
try:
    df['E Commerce - %','FAILURE% Total','']=df['E Commerce - %','FAILURE% Total',''].astype(str)+'%'
except:
    pass

    


# In[23]:


df


# In[24]:


df['E Commerce - %','SUCCESS%','1']=pd.np.round((df['E Commerce - Cons','SUCCESS','1']/
                                                     (df['E Commerce - Cons','FAILURE','1']+ 
                                                      df['E Commerce - Cons','SUCCESS','1']))*100,0).fillna(0).astype(int)


# df['E Commerce - %','SUCCESS%','2']=pd.np.round((df['E Commerce - Cons','SUCCESS','2']/
#                                                      df['E Commerce - Cons','Total Cons'])*100,0).astype(int)


# df['E Commerce - %','SUCCESS%','3+ Days']=pd.np.round((df['E Commerce - Cons','SUCCESS','3+ Days']/
#                                                            df['E Commerce - Cons','Total Cons'])*100,0).astype(int)



df['E Commerce - %','SUCCESS% Total','']=pd.np.round((df['E Commerce - Cons','SUCCESS Total','']/
                                                     df['E Commerce - Cons','Total Cons'])*100,0).astype(int)
df


# In[25]:


df['E Commerce - %','SUCCESS%','1']=df['E Commerce - %','SUCCESS%','1'].astype(str)+'%'
# df['E Commerce - %','SUCCESS%','2']=df['E Commerce - %','SUCCESS%','2'].astype(str)+'%'
# df['E Commerce - %','SUCCESS%','3+ Days']=df['E Commerce - %','SUCCESS%','3+ Days'].astype(str)+'%'
df['E Commerce - %','SUCCESS% Total','']=df['E Commerce - %','SUCCESS% Total',''].astype(str)+'%'
df.head(1)
df


# In[26]:


Ecom=df[[
               ('E Commerce - %','SUCCESS%','1'),     
#                ('E Commerce - %','SUCCESS%','2'),       
#                ('E Commerce - %','SUCCESS%','3+ Days'),        
               ('E Commerce - %','SUCCESS% Total',''),       
               ('E Commerce - %','FAILURE%','1'),        
#                ('E Commerce - %','FAILURE%','2'),      
#                ('E Commerce - %','FAILURE%','3+ Days'),    
               ('E Commerce - %','FAILURE% Total','')]].tail(2)
        

    
Ecom


# In[27]:


# Ecom=df[[
#                ('E Commerce - %','SUCCESS%','1'),
        
#                ('E Commerce - %','SUCCESS%','2'),

#                ('E Commerce - %','SUCCESS% Total',''),
        
#                ('E Commerce - %','FAILURE%','1'),
         
#                ('E Commerce - %','FAILURE%','2'),
        
#                ('E Commerce - %','FAILURE% Total','')]].tail(2)
        

    
# Ecom


# In[28]:


Necm=Q1[Q1.Con_Category == 'Non e-Commerce']
Necm


# In[29]:


df2=pd.pivot_table(Necm,index=["APT_DATE"], 
                  columns=["PERFORMANCE","APORDER1"], 
                  values= ['DOCKNO'],
                  aggfunc={'DOCKNO':len},margins= True, margins_name= 'Total Cons' ).fillna(0)
df2['DOCKNO']=df2['DOCKNO'].astype(int)
df2.head(2)


# In[30]:


df2.rename(columns={'DOCKNO':'Non-E Commerce - Cons','APT_DATE':'DATE'}, inplace=True)

# df['Total Cons']=df.sum(axis=1)


df2['Non-E Commerce - Cons','SUCCESS Total','']=df2['Non-E Commerce - Cons','SUCCESS'].sum(axis=1)
df2['Non-E Commerce - Cons','FAILURE Total','']=df2['Non-E Commerce - Cons','FAILURE'].sum(axis=1)




df2.head()


# In[31]:


# df[('E Commerce - Cons','Total Cons')]
# 

df2['Non-E Commerce - %','FAILURE%','1']=pd.np.round((df2['Non-E Commerce - Cons','FAILURE','1']/
                                                 (df2['Non-E Commerce - Cons','FAILURE','1']+ 
                                                 df2['Non-E Commerce - Cons','SUCCESS','1']))
                                                     *100,0).fillna(0).astype(int)


# In[32]:


# df2['Non-E Commerce - %','FAILURE%','2']=pd.np.round((df2['Non-E Commerce - Cons','FAILURE','2']/
#                                                  df2['Non-E Commerce - Cons','Total Cons'])*100,0).astype(int)
# df2['Non-E Commerce - %','FAILURE%','3+ Days']=pd.np.round((df2['Non-E Commerce - Cons','FAILURE','3+ Days']
#                                                        /df2['Non-E Commerce - Cons','Total Cons'])*100,0).astype(int)

df2['Non-E Commerce - %','FAILURE% Total','']=pd.np.round((df2['Non-E Commerce - Cons','FAILURE Total','']/
                                                     df2['Non-E Commerce - Cons','Total Cons'])*100,0).astype(int)
df2

df2['Non-E Commerce - %','SUCCESS%','1']=pd.np.round((df2['Non-E Commerce - Cons','SUCCESS','1']/
                                                 (df2['Non-E Commerce - Cons','FAILURE','1']+ 
                                                      df2['Non-E Commerce - Cons','SUCCESS','1']))*100,0).fillna(0).astype(int)

df2

# df2['Non-E Commerce - %','SUCCESS%','2']=pd.np.round((df2['Non-E Commerce - Cons','SUCCESS','2']/
#                                                  df2['Non-E Commerce - Cons','Total Cons'])*100,0).astype(int)
# df2

# df2['Non-E Commerce - %','SUCCESS%','3+ Days']=pd.np.round((df2['Non-E Commerce - Cons','SUCCESS','3+ Days']/
#                                                        df2['Non-E Commerce - Cons','Total Cons'])*100,0).astype(int)
# df

df2['Non-E Commerce - %','SUCCESS% Total','']=pd.np.round((df2['Non-E Commerce - Cons','SUCCESS Total','']/
                                                     df2['Non-E Commerce - Cons','Total Cons'])*100,0).astype(int)

df2.head(4)


# In[33]:


df2['Non-E Commerce - %','SUCCESS%','1']=df2['Non-E Commerce - %','SUCCESS%','1'].astype(str)+'%'


# df2['Non-E Commerce - %','SUCCESS%','2']=df2['Non-E Commerce - %','SUCCESS%','2'].astype(str)+'%'


# df2['Non-E Commerce - %','SUCCESS%','3+ Days']=df2['Non-E Commerce - %','SUCCESS%','3+ Days'].astype(str)+'%'
df2['Non-E Commerce - %','SUCCESS% Total','']=df2['Non-E Commerce - %','SUCCESS% Total',''].astype(str)+'%'


df2['Non-E Commerce - %','FAILURE%','1']=df2['Non-E Commerce - %','FAILURE%','1'].astype(str)+'%'


# df2['Non-E Commerce - %','FAILURE%','2']=df2['Non-E Commerce - %','FAILURE%','2'].astype(str)+'%'


# df2['Non-E Commerce - %','FAILURE%','3+ Days']=df2['Non-E Commerce - %','FAILURE%','3+ Days'].astype(str)+'%'
df2['Non-E Commerce - %','FAILURE% Total','']=df2['Non-E Commerce - %','FAILURE% Total',''].astype(str)+'%'

nonEcom=df2[[
               ('Non-E Commerce - %','SUCCESS%','1'),
#                ('Non-E Commerce - %','SUCCESS%','2'),
#                ('Non-E Commerce - %','SUCCESS%','3+ Days'),
               ('Non-E Commerce - %','SUCCESS% Total',''),
               ('Non-E Commerce - %','FAILURE%','1'),
#                ('Non-E Commerce - %','FAILURE%','2'),
#                ('Non-E Commerce - %','FAILURE%','3+ Days'),
               ('Non-E Commerce - %','FAILURE% Total','')]].tail(2)
nonEcom


# In[34]:


from pandas import ExcelWriter
# with ExcelWriter(r"E:\APT-DE-SHARAN.xlsx") as writer:
#     Ecom.to_excel(writer, sheet_name='APT-DE',
#                      engine='xlsxwriter',startrow=0 , startcol=0)
#     nonEcom.to_excel(writer, sheet_name='APT-DE',
#                    engine='xlsxwriter',startrow=10 , startcol=0)


# In[35]:


from glob import glob
from IPython import display
from datetime import datetime,timedelta
import pyodbc

# date=datetime.strftime(datetime.now()-timedelta(2),'%Y-%m-%d-%H')
date=datetime.strftime(datetime.now(),'%Y-%m-%d-%H')
date


# In[36]:


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template
                  

# TO=['sanjana.narayana@spoton.co.in']
TO=['sharanagouda.biradar@spoton.co.in','anitha.thyagarajan@spoton.co.in']

FROM="sanjana.narayana@spoton.co.in"
# CC = ['sanjana.narayana@spoton.co.in']


BCC = ['sanjana.narayana@spoton.co.in']


msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
# msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = " APT_DE- summary " + " - " + str(enddate)
html='''<html>
<style>        
p
 {
   margin:0;
   margin-top: 5px;
   padding:0;
   font-size:15px;
   line-height:20px;
 }
</style>                


 '''
# html3='''
# <h5> To download File, Please click the link below </h5>
# <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/APT_DE_"+str(today)+".xlsx"</a>
# "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/APT_DE.xlsx"</p>
# '''
report=""
report+='<br>'
report+='Hello,'
report+='<br>'
report+='<br>'
report+=' Please find below, summary of Appointment DE for your reference.'
report+='<br>'
report+='<br>'
report+='E- COMMERCE.'
report+='<br>'
report+='<br>'+Ecom.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='NON- E COMMERCE.'
report+='<br>'
report+='<br>'+nonEcom.to_html()+'<br>'
report+='<br>'
report+='<br>'


# In[37]:


# report+=html
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
# part.set_payload( open(oppath1,"rb").read() )
# encoders.encode_base64(part)
# part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
# msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login('spoton.net.in', 'Star@123#')
failed = server.sendmail(FROM, TO+BCC, msg.as_string())
print ('mail sent')
server.quit()

