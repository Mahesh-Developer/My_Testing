
# coding: utf-8

# In[1]:


#1. Imports
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from sqlalchemy import *
engine = create_engine("mysql+pymysql://spotonhr:spoton54321@104.199.198.197/puddata")
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template


# In[2]:

try:
  #2. Importing df = std delivery df for last 30 days with cost netted off with SBA
  startdate="'"+datetime.strftime((datetime.now()-timedelta(days=30)).replace(day=1),"%Y-%m-%d")+"'"
  enddate="'"+datetime.strftime(datetime.now(),"%Y-%m-%d")+"'"
  print (startdate)
  print (enddate)
  query=("SELECT `CON_ID2`,`DATE2`,`PINCODE2`,`PINTYPE`,`BRANCH_CODE2`,`BRANCH_NAME2`,`ACT_WT2`,`PUD_NAME2`,`PUDTYPE2`,`COST2`,`TYP2`,`CUSTOMERCODE`,`CUSTOMERNAME`,`MKT_SBA_AMT` FROM `puddata` WHERE `PINTYPE`='STD' AND `TYP2`='DLV' AND `DATE2` >= {0} AND `DATE2` < {1}".format(startdate,enddate))
  print (query)
  df = pd.read_sql(query,engine)
  print (df.columns)
  print (df.head(10))

  df=df.rename_axis({"BRANCH_CODE2":'Branch',"PINCODE2":"Pincode","CUSTOMERCODE":"Code","ACT_WT2":"Wt","COST2":"Cost"},axis=1)
  df['Cost']=df['Cost']-df['MKT_SBA_AMT']
  os.chdir(r"C:\Users\rajeeshv\Downloads")



  import pickle
  shortlistbr=['AMDO','BLRB','BLRC','BLRF','BLRN','BWDB','CCUC','CCUK','CCUN','DELC','DELM','GTBB','GZBB','HYDO','KLBL','MAAC','MHPF','PNQC','PNQO']
  pkl_file = open(r'C:\Users\rajeeshv\Downloads\Rajesh\mahesh\Appointment Reports\combos.pkl', 'rb')
  combos = pickle.load(pkl_file)
  pkl_file.close()
  pkl_file = open(r'C:\Users\rajeeshv\Downloads\Rajesh\mahesh\Appointment Reports\classifdict.pkl', 'rb')
  classifdict = pickle.load(pkl_file)
  pkl_file.close()


  # In[5]:

  # def getDate(date):
  #     d=datetime.strftime(date,'%Y-%m-%d')
  #     return d 

  # dfy['DATE']=dfy.apply(lambda x: getDate(x['DATE2']),axis=1)
  dfy=df[(df["DATE2"]>=(pd.to_datetime('today')-timedelta(days=1)))]
  toexclude = ['STD','FIXED']
  mktdfy=dfy[~(dfy['PUDTYPE2'].isin(toexclude))]
  print ('dfy',len(dfy))
  print ('mktdfy',len(mktdfy))
  pivmktstd = mktdfy.pivot_table(index =['CON_ID2','PUD_NAME2','Branch','Pincode','Code'], aggfunc={'Cost': lambda x: np.round(np.sum(x),1),'Wt': lambda x: np.round(np.sum(x),1)})
  pivstdy = dfy.pivot_table(index =['CON_ID2','PUD_NAME2','Branch','Pincode','Code'], aggfunc={'Cost': lambda x: np.round(np.sum(x),1),'Wt': lambda x: np.round(np.sum(x),1)})
  pivstdy = pd.merge(pivstdy,pivmktstd, left_index=True,right_index=True,suffixes=['_t','_m'], how = 'left').fillna(0.0)
  print (pivstdy.columns)
  pivstdy['TotCPKG'] = np.round(pivstdy.Cost_t/pivstdy.Wt_t,2)
  pivstdy['MktCPKG'] = np.round(pivstdy.Cost_m/pivstdy.Wt_m,2).fillna(0.0)
  pivstdy=pivstdy.reset_index()
  pivstdy['Key']=pivstdy['Pincode'].astype(int).astype(str)+pivstdy['Code'].astype(int).astype(str)
  pivstdy=pivstdy[pivstdy['Key'].isin(combos)]

  pivstdy=pivstdy[pivstdy['Cost_m']>0]
  pivstdy=pivstdy[pivstdy['MktCPKG']>2]

  pivstdy['Type']=pivstdy['Key'].map(classifdict)

  brpivy=pivstdy.loc[:,['Branch','Type','Cost_m','Wt_m']].pivot_table(index=['Branch'],columns=["Type"],aggfunc={'Cost_m': np.sum, 'Wt_m': np.sum},margins=True).reset_index().sort_values(("Cost_m","All"),ascending=False)

  for i in ['Dedicated','Mixed','All']:
      try:
          brpivy[('CPK',i)]=np.round(brpivy[('Cost_m',i)]/brpivy[('Wt_m',i)],1).fillna(0.0)
      except:
          pass



  # In[6]:


  #7 Last 30 days
  mktdf=df[~(df['PUDTYPE2'].isin(toexclude))]
  pivmktstd = mktdf.pivot_table(index =['Branch','Pincode','Code'], aggfunc={'Cost': lambda x: np.round(np.sum(x),1),'Wt': lambda x: np.round(np.sum(x),1)})
  pivstd = df.pivot_table(index =['Branch','Pincode','Code'], aggfunc={'Cost': lambda x: np.round(np.sum(x),1),'Wt': lambda x: np.round(np.sum(x),1)})
  pivstd = pd.merge(pivstd,pivmktstd, left_index=True,right_index=True,suffixes=['_t','_m'], how = 'left').fillna(0.0)
  pivstd['TotCPKG'] = np.round(pivstd.Cost_t/pivstd.Wt_t,2)
  pivstd['MktCPKG'] = np.round(pivstd.Cost_m/pivstd.Wt_m,2).fillna(0.0)
  pivstd=pivstd.reset_index()
  pivstd['Key']=pivstd['Pincode'].astype(int).astype(str)+pivstd['Code'].astype(int).astype(str)
  pivstd=pivstd[pivstd['Key'].isin(combos)]
  pivstd=pivstd[pivstd['Cost_m']>0]
  pivstd=pivstd[pivstd['MktCPKG']>2]
  pivstd['Type']=pivstd['Key'].map(classifdict)
  brpiv=pivstd.loc[:,['Branch','Type','Cost_m','Wt_m']].pivot_table(index=['Branch'],columns=["Type"],aggfunc={'Cost_m': np.sum, 'Wt_m': np.sum},margins=True).reset_index().sort_values(("Cost_m","All"),ascending=False)
  for i in ['Dedicated','Mixed','All']:
      try:
          brpiv[('CPK',i)]=np.round(brpiv[('Cost_m',i)]/brpiv[('Wt_m',i)],1).fillna(0.0)
      except:
          pass

  # In[7]:


  #8. Adding costperc
  totsd=pivstd.loc[:,["Branch","Cost_t","Wt_t"]].pivot_table(index=['Branch'],aggfunc={'Cost_t':np.sum,'Wt_t':np.sum},margins=True)
  totsddict=totsd['Cost_t'].to_dict()#["CPK"]=np.round(totsd['Cost_t']/totsd['Wt_t'],1)
  # pd.merge(brpiv.set_index("Branch"),totsd,left_index=True,right_index=True)
  brpiv["Cost_t"]=brpiv['Branch'].map(totsddict)
  brpiv["CostPerc"]=np.round(brpiv[("Cost_m","All")]*100.0/brpiv["Cost_t"])


  # In[8]:


  #Descriptors
  mktspendy=round(brpivy['Cost_m']['All'].max()/1e5,2)
  mktcpky=round(brpivy['Cost_m']['All'].max()/brpivy['Wt_m']['All'].max(),1)
  mktspend=round(brpiv['Cost_m']['All'].max()/1e5,2)
  mktcpk=round(brpiv['Cost_m']['All'].max()/brpiv['Wt_m']['All'].max(),1)
  mktcostperc=brpiv['CostPerc'].values[0]
  brpivy1=brpivy.fillna(0)
  brpiv1=brpiv.fillna(0)
  # In[9]:

  print (pivstdy)
  #Mail
  filePath=r'D:\Data\Appointment Reports\Std_Picodes\Detailed_Report.csv'
  filePath2=r'D:\Data\Appointment Reports\Detailed_Report.csv'
  try:
      pivstdy.to_csv(filePath,encoding='utf-8')
  except:
      pivstdy.to_csv(filePath2,encoding='utf-8')
      
  # ('Yesterday market spend on focus std pincodes is Rs. <b>'+str(mktspendy)+' lakhs </b>, '+
  #                        'at a CPK of Rs. <b>'+str(mktcpky)+'</b>. '+
  #                        '<br>Last 30 days market spend  is Rs.'+str(mktspend)+' lakhs </b> at a CPK of Rs. <b>'+str(mktcpk)+'</b> (Target Rs. 2.5)'+
  #                        #'are CCF due to address/contact issue and <b>'+str(ucgcons)+'</b> '+
  #                        #'are UCG cons. <b>'+
  #                        '.<br>Last 30 days Non-STD cost percentage for these std pincodes: <b>'+str(mktcostperc)+'%</b>'+
  #                        '<br><br><b> A. Yesterdays Performance Summary (Branch-Level): </b>'+
  #                        brpivy.to_html()+'<br><br><b> B. Last 30 days Performance Summary (Branch-Level):</b><br>'+brpiv.to_html(), 'html')
  #     msgAlternative.attach(msgText)
     
  # send_email(["ankit@iepfunds.com","supratim@iepfunds.com","krishna.chandrasekar@spoton.co.in","abhik.mitra@spoton.co.in","anto.paul@spoton.co.in","nikhil.saxena@spoton.co.in","aom_spot@spoton.co.in", "dom_spot@spoton.co.in", "rom_spot@spoton.co.in"])

  from datetime import date,timedelta
  todate=date.today()-timedelta(1)
  today_date=datetime.strftime(todate,'%d-%m-%Y')
  today_date
  #vishwas.j@spoton.co.in

  TO=["krishna.chandrasekar@spoton.co.in","abhik.mitra@spoton.co.in","anto.paul@spoton.co.in","aom_spot@spoton.co.in", "dom_spot@spoton.co.in", "rom_spot@spoton.co.in",'vishwas.j@spoton.co.in']
  # TO=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
  FROM="reports.ie@spoton.co.in"
  #CC=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
  BCC=['mahesh.reddy@spoton.co.in']
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  #msg["CC"] = ",".join(CC)
  msg["BCC"] = ",".join(BCC)
  msg["Subject"] = "STD_Pincode Report" + " : " + str(today_date)
  html='''<html>
  <style>
  p
  {
    margin:0;
    margin-top: 5px;
    padding:0;
    font-size:17px;
      line-height:20px;
  }
  </style>
  <h4>Dear All,</h4>
  <p>Yesterday market spend on focus std pincodes is Rs. <b>$mktspendy</b> lakhs at a CPK of Rs. <b>$mktcpky</b></p>
  <p>Last 30 days market spend  is Rs. <b>$mktspend</b> lakhs at a CPK of Rs. <b>$mktcpk</b> (Target Rs. 2.5)</p>
  <p>Last 30 days Non-STD cost percentage for these std pincodes: <b>$mktcostperc %</b></p>
  <h4>A. Yesterdays Performance Summary (Branch-Level):</h4>
  </html>'''

  html3='''
  <h3>B. Last 30 days Performance Summary (Branch-Level):</h3>

  '''
  s = Template(html).safe_substitute(mktcostperc=mktcostperc,mktcpk=mktcpk,mktspend=mktspend,mktcpky=mktcpky,mktspendy=mktspendy,date=today_date)
  report=""
  report+=s
  report+='<br>'
  report+='<br>'+brpivy1.to_html()+'<br>'
  report+=html3
  #depotpivot_std
  report+='<br>'+brpiv1.to_html()+'<br>'
  abc=MIMEText(report,'html')
  msg.attach(abc)
  part = MIMEBase('application', "octet-stream")
  part.set_payload( open(filePath,"rb").read() )
  encoders.encode_base64(part)
  part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
  msg.attach(part)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO+BCC, msg.as_string())
  server.quit()

except:
  TO=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  #msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "STD_Pincode Report Error in Execution" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in STD_Pincode Report'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO, msg.as_string())
  server.quit()




