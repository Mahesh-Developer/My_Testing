# -*- coding: utf-8 -*-
"""
Created on Fri Oct 21 18:05:16 2016

@author: rajeeshv
"""
import ftplib
import os
import traceback


oppath3 =r'C:\Users\rajeeshv\Downloads\CFR_v1.zip'
# In[ ]:
print ('Logging in...')
ftp = ftplib.FTP()
ftp.connect('10.109.230.50')
print (ftp.getwelcome())
try:
    try:
        ftp.login('IEPROJECTUSER', 'spotStar@123')
        ftp.cwd('ETA')
        # move to the desired upload directory
        print ("Currently in:", ftp.pwd())
        print ('Uploading...')
        fullname = oppath3
        name = os.path.split(fullname)[1]
        f = open(fullname, "rb")
        ftp.storbinary('STOR ' + name, f)
        f.close()
        print ("OK"  )
        print ("Files:")
        print (ftp.retrlines('LIST'))
    finally:
        print ("Quitting...")
        ftp.quit()
except:
    traceback.print_exc()