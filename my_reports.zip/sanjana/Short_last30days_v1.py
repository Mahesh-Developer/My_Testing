# -*- coding: utf-8 -*-
"""
Created on Mon Oct 17 18:55:02 2016

@author: rajeeshv
"""

import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
import datetime
import os
import graphlab as gl
import graphlab.aggregate as agg
import Utilities

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()

###EXEC dbo.USP_DEPS_DATA_TO_SQ_IE

query = ("""
        EXEC dbo.USP_DEPS_DATA_TO_SQ_IE
        """)

shortagedata = pd.read_sql(query, Utilities.cnxn)
#print len(shortagedata)

#shortagedata = gl.SFrame.from_sql(cnxn,query)
print len(shortagedata)
print type(shortagedata)