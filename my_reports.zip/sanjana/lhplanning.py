from __future__ import print_function, division
import pandas as pd
from datetime import datetime, timedelta
import webbrowser
import simplejson
import urllib
import numpy as np
import ast
from sqlalchemy import *
import operator
engine = create_engine("mysql+pymysql://spotonhr:spoton54321@104.199.198.197/condata")
engine2 = create_engine("mysql+pymysql://spotonhr:spoton54321@104.199.198.197/LH30days")
engine3 = create_engine("mysql+pymysql://spotonhr:spoton54321@104.199.198.197/schedule")
# Dont start self. inside a function (except init) or you will overwrite variables globally; also dont use same names as global vars inside function
class lhplanning:

    def __init__(self,startdate,enddate):
        condata = pd.read_sql("SELECT `Pickupdate`,`Origin_area`,`OPP`,`Reach`,`ARRV_AT_DESTCD`,`DELY_DT`,`Orgin`,`Destn`,`Dest_area`,`ACTUAL_WEIGHT`,`DOCKNO`,`VOLUME` FROM `condata` WHERE `Pickupdate` >= '{0}' AND `Pickupdate` < '{1}'".format(startdate,enddate+' '+'23:59:59'),engine)
        condata['Pickupdate']=condata['Pickupdate'].dt.date
        condata = condata.rename(columns={'Origin_area': 'Org_Area'})
        condata['OPP'] = condata['OPP'].map(lambda x: 1 if x=='YES' else 0)
        condata['Reach'] = condata['Reach'].map(lambda x: 1 if x=='YES' else 0)
        condata2 = condata[(condata["ARRV_AT_DESTCD"].notnull())&(condata["DELY_DT"].notnull())]
        condata2 = condata2[(condata2["ARRV_AT_DESTCD"]!='abc')&(condata2["DELY_DT"]!='abc')]
        self.condata=condata
        self.condata2=condata2
        self.scgrp = self.condata.pivot_table(index=['Orgin','Destn','Org_Area','Dest_area'],aggfunc={'ACTUAL_WEIGHT':np.sum,'DOCKNO': len,'Reach': np.sum,'VOLUME': np.sum}).reset_index().rename(columns={"DOCKNO":'Con',"VOLUME":"Volume"})
        self.scgrp2 = self.condata2.pivot_table(index=['Orgin','Destn','Org_Area','Dest_area'],aggfunc={'ACTUAL_WEIGHT':np.sum,'DOCKNO': len,'Reach': np.sum,'VOLUME': np.sum}).reset_index().rename(columns={"DOCKNO":'Con',"VOLUME":"Volume"})
        self.scgrp['AdjWt'] =  np.round(np.maximum(self.scgrp['ACTUAL_WEIGHT'],self.scgrp['Volume']*6.0),0)
        self.totaldayslist = self.condata['Pickupdate'].unique()
        self.workingdaylist = [i for i in self.totaldayslist if i.weekday()!=6]
        self.workingdays = len(self.workingdaylist)
        self.td = len(self.totaldayslist)

        thcdatapd = pd.read_sql("SELECT `Vech Type`,`ROUTE CODE`,`NEW PATH`,`ROUTE NAME`,`VEHICLE PAYLOAD`,`THC NUMBER`,`COST`,`THC DATE`,`THC Finish Date`,`TOTAL ACTUAL LOAD`,`TOTAL VOLUME`,`VENDOR NAME` FROM LH30days WHERE `THC DATE` >= '{0}' AND `THC DATE` < '{1}'".format(startdate,enddate+' '+'23:59:59'),engine2)
        thcdatapd=thcdatapd[~(thcdatapd["Vech Type"].isin(['DATAVECHILE','VIRTUALHUB']))]
        thcdatapd['ROUTE NAME']=thcdatapd['ROUTE NAME'].str.replace(' ','')
        thcdatapd['THC Finish Date'] = pd.to_datetime(thcdatapd['THC Finish Date'])
        thcdatapd['AdjWt'] = np.round(np.maximum(thcdatapd['TOTAL ACTUAL LOAD'],thcdatapd['TOTAL VOLUME']*6.0),0)
        thcdatapd["Util%"] = np.round(thcdatapd['AdjWt']/thcdatapd['VEHICLE PAYLOAD'],0)
        thcdatapd["CPKPL"] = np.round(thcdatapd['COST']/thcdatapd['VEHICLE PAYLOAD'],2)
        thcdatapd = thcdatapd.rename(columns={"ROUTE CODE":"CODE","VEHICLE PAYLOAD":"PL","TOTAL ACTUAL LOAD":"ActWt"})
        thcdatapd["routelist"]=thcdatapd["ROUTE NAME"].map(lambda x: x.split("-"))
        self.thcdatapd = thcdatapd

        tcdf = pd.read_sql("SELECT `ROUTE_CODE`,`ROUTE_NAME`,`VEHICLE_PAYLOAD`,`THC_DATE`,`THC_NUMBER`,`TC_DATE`,`TC_NUMBER`,`TC_BR`,`TC_TOBRCODE`,`TOTAL_ACTUAL_LOAD`,`TOTAL_VOLUME` FROM TC WHERE `THC_DATE` >= '{0}' AND `THC_DATE` < '{1}'".format(startdate,enddate+' '+'23:59:59'),engine2)
        tcdf['AdjWt'] = np.round(np.maximum(tcdf['TOTAL_ACTUAL_LOAD'],tcdf['TOTAL_VOLUME']*0.0),0)
        wtdf=tcdf[tcdf['ROUTE_CODE']!='9888'].pivot_table(index=['ROUTE_CODE','ROUTE_NAME','TC_BR','TC_TOBRCODE'],aggfunc={'AdjWt':np.sum,'VEHICLE_PAYLOAD':np.mean,'THC_NUMBER':lambda x: len(set(x))}).reset_index()
        self.tcdf = tcdf
        self.wtdf = wtdf

        schedules = pd.read_sql("SELECT * FROM schedule",engine3)
        schedules['Departure time']=schedules['Departure time'].replace('-','12:00')
        schedules['Arrival time']=schedules['Arrival time'].replace('-','12:00')
        schedules['Departs']=schedules.apply(lambda x: pd.datetime(2018,1,x['Departure Day'],int(x['Departure time'].split(":")[0]),int(x['Departure time'].split(":")[1])),axis=1)
        schedules['Arrives']=schedules.apply(lambda x: pd.datetime(2018,1,x['Arrival day'],int(x['Arrival time'].split(":")[0]),int(x['Arrival time'].split(":")[1])),axis=1)
        schedules['TT']=np.round((schedules['Arrives']-schedules['Departs'])/np.timedelta64(1, 'h'),1)
        self.schedules=schedules
        schedules_thc=schedules.pivot_table(index=['Route Code','Route Details'],aggfunc={'Departs':min,'Arrives':max,'Transit Distance':np.sum}).reset_index().loc[:,['Route Code','Route Details','Transit Distance','Departs','Arrives']] #Dont do TT=np.sum since we is actually has halting time at Hub as well
        schedules_thc['TT']=np.round((schedules_thc['Arrives']-schedules_thc['Departs'])/np.timedelta64(1, 'h'),1)
        self.schedules_thc=schedules_thc

        instructions = pd.read_sql("SELECT * FROM instructions",engine3)
        listoflists = pd.read_sql("SELECT * FROM listoflists",engine3)
        brsf = listoflists.loc[:,['default','SC']].rename(columns={"default":"areakey","SC":"arealist"})
        scdetails = pd.read_sql("SELECT `SC`,`Name of SC`,`Type`,`Pincode` FROM branchmaster",engine3)
        hubdetails = pd.read_sql("SELECT `HUB`,`Hub Name`,`Location Status`,`Pincode` FROM `hubmaster`",engine3)
        hubdetails.columns=scdetails.columns
        scdetails=scdetails.append(hubdetails)        
        listoflists["SC"] = listoflists["SC"].apply(ast.literal_eval)
        instructions["Path"] = instructions["Path"].apply(ast.literal_eval)
        brsf["arealist"] = brsf["arealist"].apply(ast.literal_eval)        
        self.listoflists=listoflists #for audit
        self.brsf=brsf
        self.scdetails=scdetails

        listdf=self.listoflists.loc[:,['total','SC']].pivot_table(index='total',aggfunc={'SC':lambda i:[x for t in i for x in t]}).reset_index().rename(columns={'total':'brlist'})
        scdf=pd.DataFrame(listdf['SC'].values.tolist()).T.rename(columns={0:"brlist"}).merge(pd.DataFrame(listdf['SC'].values.tolist()).T.rename(columns={0:"SC"}),left_on='brlist',right_on='SC')
        scdf['SC']=scdf['SC'].map(lambda x: [x])
        listdf=listdf.append(scdf)
        for col in ['large','small','region','default']:
            listdf = listdf.append(self.listoflists.loc[:,[col,'SC']].pivot_table(index=col,aggfunc={'SC':lambda i:[x for t in i for x in t]}).reset_index().rename(columns={col:'brlist'}))
        self.listdict=listdf.set_index('brlist')['SC'].to_dict()
        self.brlist=brsf.set_index('areakey')['arealist'].to_dict()
        self.instructiondict=instructions.set_index(['Origin','Destination'])['Path'].to_dict()
        self.scdetaildict=self.scdetails.set_index("SC")["Name of SC"].to_dict()
        self.scpindict=self.scdetails.set_index("SC")["Pincode"].to_dict()
        self.lhcodedict=self.thcdatapd.set_index("CODE")["routelist"].to_dict()

    def distance_(self):
        legdist = self.schedules.set_index(['Origin','Destination'])
        legdist = legdist.rename({'Transit Distance':'Kms'},axis=1)
        legdist = legdist[['Kms']]
        wtdf = pd.merge(self.wtdf,legdist, left_on=['TC_BR','TC_TOBRCODE'], right_index=True, how = 'left')
        updatedf = wtdf[pd.isna(wtdf.Kms)][['TC_BR','TC_TOBRCODE']]
        updatedf = updatedf.drop_duplicates()
        self.updatedf = updatedf
            
    def getloadmovementonesided (self,list1,list2,flag='all'):
        wt = np.round(self.scgrp[(self.scgrp['Orgin'].isin(list1))&(self.scgrp['Destn'].isin(list2))]['AdjWt'].sum()*1.0/(self.workingdays*1000),1)
        if flag=='all':
            cons = np.round(self.scgrp2[(self.scgrp2['Orgin'].isin(list1))&(self.scgrp2['Destn'].isin(list2))]['Con'].sum()*1.0/(self.workingdays),1)
            reached = np.round(self.scgrp2[(self.scgrp2['Orgin'].isin(list1))&(self.scgrp2['Destn'].isin(list2))]['Reach'].sum()*1.0/(self.workingdays),1)
            return [wt,cons,np.round(reached*100.0/cons,1)]
        else:
            return [wt]

    def getloadmovementtwosided (self,list1,list2):
        a = self.getloadmovementonesided(list1,list2)
        b = self.getloadmovementonesided(list2,list1)
        return a,b

    def checklhcost(self,checklist):
        thcdatapd=self.thcdatapd
        thcdatapd["shortlist"]=thcdatapd['routelist'].apply(lambda x: True if all(i in x for i in checklist) else False)
        thcdatapd=thcdatapd[thcdatapd['shortlist']==True]
        return thcdatapd.drop(['routelist','shortlist','Vech Type','NEW PATH'],axis=1)

    def legutil(self, routecode):
        legutillist=[]
        try:
	        sdf=self.wtdf[self.wtdf['ROUTE_CODE']==routecode]
	        routename = sdf['ROUTE_NAME'].unique()[0].replace(" ","").split("-")
	        leglist=[[routename[i],routename[i+1]] for i in range(0,len(routename)-1)]
	        for i in leglist:
	            orgs = routename[0:(routename.index(i[0])+1)]
	            dests = routename[(routename.index(i[1])):]
	            util = sdf[(sdf['TC_BR'].isin(orgs))&(sdf['TC_TOBRCODE'].isin(dests))]['AdjWt'].sum()*100.0/(sdf['THC_NUMBER'].max()*sdf['VEHICLE_PAYLOAD'].unique()[0]) #this presumes one leg always there in all TCs
	            legutillist=legutillist+[(i[0],i[1],np.round(util,0))]
        except:
            legutillist=[]
        return legutillist

    def checklhsum(self,checklist):
        thcdatapd=self.thcdatapd
        aggdict = {'THC NUMBER':len,'PL':np.sum,'COST':np.sum,'AdjWt':np.sum}
        if 'All' in checklist:
            checklhsumtable=thcdatapd.pivot_table(index=["CODE","ROUTE NAME"],aggfunc=aggdict)
        else:        
            thcdatapd["shortlist"]=thcdatapd['routelist'].apply(lambda x: True if all(i in x for i in checklist) else False)
            checklhsumtable=thcdatapd[thcdatapd['shortlist']==True].pivot_table(index=["CODE","ROUTE NAME"],aggfunc=aggdict)
        
        checklhsumtable["AvgCost"]=np.round(checklhsumtable["COST"]/checklhsumtable['THC NUMBER'])
        checklhsumtable["Util%"]=np.round(checklhsumtable["AdjWt"]*100.0/checklhsumtable["PL"])
        checklhsumtable["CPKPL"]=np.round(checklhsumtable["COST"]/checklhsumtable["PL"],2)

        checklhsumtable["PL"]=np.round(checklhsumtable["PL"]/checklhsumtable['THC NUMBER']/1e3,1)
        checklhsumtable["COST"]=np.round(checklhsumtable["COST"]/1e5,2)
        checklhsumtable["AdjWt"]=np.round(checklhsumtable["AdjWt"]/checklhsumtable['THC NUMBER']/1e3,1)

        checklhsumtable2=checklhsumtable.merge(self.schedules_thc.rename(columns={'Route Code':'CODE','Route Details':'ROUTE NAME','Transit Distance':'Kms'}).set_index(['CODE','ROUTE NAME']),how='left',left_index=True,right_index=True).fillna('-').reset_index()
        checklhsumtable2['Legutil']=checklhsumtable2['CODE'].map(self.legutil)
        checklhsumtable2['Origin'] = [i.split('-')[0] for i in checklhsumtable2['ROUTE NAME'].values]
        checklhsumtable2['Destination'] = [i.split('-')[-1]  for i in checklhsumtable2['ROUTE NAME'].values]
        return checklhsumtable2.sort_values('COST',ascending = False)

    def mapsc(self,x):
        '''mapsc(["DELH","IDRH","SNRH","PNQH"])'''
        exp=""
        for sc in x:
            exp=exp+"/"+str(self.scpindict.get(sc))
        return webbrowser.open("https://www.google.co.in/maps/dir"+exp)

    def maplh(self,x):
        '''maplh('D1597')'''
        return self.mapsc(self.lhcodedict.get(x))

    def checklists(self,listitem):
        sclist=[]
        for brlist in listitem:
            sclist=sclist+self.listdict.get(brlist)
        if len(set([x for x in sclist if sclist.count(x) > 1]))>=1:
            print ('Warning! Repeated SCs:'+str(set([x for x in sclist if sclist.count(x) > 1])))

    def loadtable(self,orglist,destlist):
        self.checklists(orglist)
        self.checklists(destlist)
        od = [(x, y) for x in orglist for y in destlist]
        loadtable = pd.DataFrame(od, columns=['org', 'dest'])
        loadtable["Wt"] = loadtable.apply(lambda x: self.getloadmovementonesided(self.listdict.get(x['org']),self.listdict.get(x['dest']),flag='wtonly')[0],axis=1)
        return pd.pivot_table(loadtable,values='Wt',index='org', columns='dest', aggfunc=np.sum, margins=True).reset_index()
        
    def loadtablerev(self,x,y):
        return self.loadtable(y,x)

    def reachtable(self,orglist,destlist):
        od = [(x, y) for x in orglist for y in destlist]
        loadtable = pd.DataFrame(od, columns=['org', 'dest'])
        loadtable["Reach"] = loadtable.apply(lambda x: self.getloadmovementonesided(self.listdict.get(x['org']),self.listdict.get(x['dest']))[2],axis=1)
        return pd.pivot_table(loadtable,values='Reach',index='org', columns='dest', aggfunc=np.sum, margins=True).reset_index()
        
    def reachtablerev(self,x,y):
        return self.reachtable(y,x)

    def getdrivdist(self,org,dest):
        '''getdrivdist("MAAH","DELH")'''
        orig_coord = str(self.scpindict.get(org))
        dest_coord = str(self.scpindict.get(dest))
        url = "http://maps.googleapis.com/maps/api/distancematrix/json?origins={0}&destinations={1}&mode=driving&language=en-EN&sensor=false".format(str(orig_coord),str(dest_coord))
        try:
            from urllib.request import urlopen
            result= simplejson.load(urlopen(url))
        except:
            from urllib import urlopen
            result= simplejson.load(urlopen(url))
        driving_dist = result['rows'][0]['elements'][0]['distance']['text']
        return driving_dist

    def getdrivtime(self,org,dest):
        '''getdrivtime("MAAH","DELH")'''
        orig_coord = str(self.scpindict.get(org))
        dest_coord = str(self.scpindict.get(dest))
        url = "http://maps.googleapis.com/maps/api/distancematrix/json?origins={0}&destinations={1}&mode=driving&language=en-EN&sensor=false".format(str(orig_coord),str(dest_coord))
        result= simplejson.load(urllib.request.urlopen(url))
        driving_time = result['rows'][0]['elements'][0]['duration']['text']
        return driving_time

    def getdrivdistroute(self,x):
        odlist=x.split("-")
        orglist = odlist[0:-1]
        destlist = odlist[1:]
        retlist = []
        for i in range(0,len(odlist)-1):
            retitem = [orglist[i],destlist[i]]
            retlist.append(retitem)
        kmslist=[]
        for j in retlist:
            kmsitem=self.getdrivdist(j[0],j[1])
            kmslist.append(kmsitem)
        intkmslist=[]
        for k in kmslist:
            intkmsitem=int(k.split(" ")[0].replace(",",""))
            intkmslist.append(intkmsitem)
        return kmslist,sum(intkmslist),retlist

    def retroute(self,x):
        '''retroute("DELH-RPRH-VZAH-MAAH")'''
        y=x.split("-")
        z = '-'.join(list(reversed(y)))
        return z
    
    def edgecomputation(self):
        routingbranches = self.brsf.set_index("areakey").apply(lambda x: pd.Series(x['arealist']),axis=1).stack().reset_index(level=1, drop=False).reset_index().drop({'level_1'},axis=1).rename(columns={0:"branch"})
        routingdict = routingbranches.set_index('branch')['areakey'].to_dict()
        edgedf=self.scgrp
        edgedf['Org_area'] = edgedf['Orgin'].map(routingdict)
        edgedf['Dest_area'] = edgedf['Destn'].map(routingdict)
        areagrp = edgedf.pivot_table(index=['Org_area','Dest_area'],aggfunc={'AdjWt':np.sum}).reset_index()
        areagrp['Wt_day']=np.round(areagrp['AdjWt']/(1e3*self.workingdays),1)
        areagrp['Path']=areagrp.apply(lambda x: self.instructiondict.get((x['Org_area'],x['Dest_area'])),axis=1)
        areagrp=areagrp[areagrp['Path'].isnull()==False]
        areagrp['Pathbrk']=areagrp['Path'].apply(lambda cehck: [[x,cehck[cehck.index(x)+1]] for x in cehck if cehck.index(x)!=len(cehck)-1])
        stackareagrp=areagrp.set_index(['Org_area','Dest_area','Wt_day']).apply(lambda x: pd.Series(x['Pathbrk']),axis=1).stack().reset_index(level=1, drop=False).reset_index().drop({'level_2'},axis=1).rename(columns={0:"Edge"})
        stackareagrp = stackareagrp.replace({'himachalbrlist':'ixcabrlist','westpunjabbrlist':'ixcabrlist','ixcaharyanabrlist':'ixcabrlist','northuknabrlist':'ixcabrlist','chandigarhbrlist':'ixcabrlist','jkbrlist':'ixcabrlist','northpunjabrlist':'ixcabrlist'},regex=True).replace({'brlist':''},regex=True)
        stackareagrp['Origin']=stackareagrp['Edge'].map(lambda x: x[0])
        stackareagrp['Destn']=stackareagrp['Edge'].map(lambda x: x[1])
        stackareagrp['areabrkup']=stackareagrp['Org_area']+"-"+stackareagrp['Dest_area']+":"+stackareagrp['Wt_day'].astype(str)
        edgedf=stackareagrp.pivot_table(index=['Origin','Destn'],aggfunc={'Wt_day':np.sum,"areabrkup":lambda x: tuple(x)}).reset_index()
        return edgedf

    def transhipmentdf(self):
        edges = self.edgecomputation()
        controllinghubdict={'amdabrlist': 'AMDH', 'apdabrlist': 'VZAH', 'blraexnktkbrlist': 'BLRH', 'bomabrlist': 'BOMH', 'cbeabrlist': 'CJBH', 'ccuabrlist': 'CCUH', 'cgsabrlist': 'RPRH', 'chandigarhbrlist': 'IXCB', 'cokabrlist': 'COKB', 'eastuknabrlist': 'RDPF', 'eastupbrlist': 'KNPH', 'goiabrlist': 'GOIB', 'guaabrlist': 'GAUH', 'himachalbrlist': 'BDIB', 'hydabrlist': 'HYDH', 'idrabrlist': 'IDRH', 'ixcabrlist': 'AMCH', 'ixcaharyanabrlist': 'YMNF', 'ixmabrlist': 'SXVF', 'ixubbrlist': 'IXUH', 'jaiabrlist': 'JAIH', 'jkbrlist': 'AMCH', 'jspabrlist': 'BRGH', 'maaabrlist': 'MAAH', 'nagabrlist': 'NAGH', 'ncrnonupbrlist': 'DELH', 'ncrupbrlist': 'GZBH', 'nktkbrlist': 'BGMH', 'northpunjabrlist': 'LUHB', 'northuknabrlist': 'DEDF', 'orsabrlist': 'BBIH', 'pathbrlist': 'PATH', 'pnpfbrlist': 'DELH', 'pnqabrlist': 'PNQH', 'sgujbrlist': 'VPIH', 'sjaiabrlist': 'UDRF','snrabrlist': 'SNRH','westpunjabbrlist': 'BUPF', 'westupbrlist': 'AGRB'}
        def gettranshipment(org,dest,areadict):
            tsload = 0.0
            for keys in areadict.keys():
                orghub = controllinghubdict.get(keys.split('-')[0]+'brlist')
                desthub = controllinghubdict.get(keys.split('-')[1]+'brlist')
                if (org==orghub) and (dest==desthub):
                    tsload = tsload+areadict.get(keys)
            return tsload

        def getmaxload(x):
            sorted_x = sorted(x.items(), key=operator.itemgetter(1))[-1]
            return sorted_x

        edges['CoreWt'] = edges.apply(lambda x: gettranshipment(x['Origin'],x['Destn'],x['areabrkup']),axis=1)
        edges['XshipFactor'] = np.round(edges.CoreWt*100.0/edges.Wt,0)
        edges['MaxLoad'] = edges.apply(lambda x: getmaxload(x['areabrkup']),axis=1)
        edges['Flag']= edges.apply(lambda x: 1 if x['XshipFactor']<50.0 and x['MaxLoad'][1]>5 else 0,axis=1)
        return edges[edges['Flag']==1]

    def regiontolist(self,region):
        print (self.listoflists[self.listoflists["region"]==region]['default'].unique().tolist())

    def	loadtrend(self,start="'"+datetime.strftime(datetime.now()-timedelta(days=62),"%Y-%m-%d")+"'",end="'"+datetime.strftime(datetime.now(),"%Y-%m-%d")+"'",level='large'):
        condf = pd.read_sql("SELECT `DOCKNO`,`Pickupdate`,`PARENTCODE`,`PARENTNAME`,`ACTUAL_WEIGHT`,`OD_PATH`,`Orgin`,`Destn` FROM `condata` WHERE `Pickupdate` >= '{0}' AND `Pickupdate` <= '{1}'".format(start,end+' '+'23:59:59'),engine)
        areadf=self.listoflists.loc[:,[level,'SC']].set_index(level).apply(lambda x: pd.Series(x['SC']),axis=1).stack().reset_index(level=1, drop=False).reset_index().drop({'level_1'},axis=1).rename_axis({0:'SC'},axis=1)
        defaultdict=areadf.set_index('SC')[level].to_dict()
        condf['orglist']=condf["Orgin"].map(defaultdict)
        condf['destlist']=condf["Destn"].map(defaultdict)
        condf['Date']=condf['Pickupdate'].dt.date
        condf["MonthYear"]=condf["Pickupdate"].map(lambda x: datetime.strftime(x,"%m-%Y"))
        daysdf=condf.pivot_table(index=['MonthYear'],aggfunc={'Date':lambda x: len(list(set(x)))}).reset_index()
        # condf['OD']=pd.Series(zip(condf['orglist'],condf['destlist']))
        trendtable=condf.pivot_table(index=['MonthYear','orglist','destlist'],aggfunc={"ACTUAL_WEIGHT":np.sum}).reset_index().merge(daysdf,left_on='MonthYear',right_on='MonthYear')
        trendtable['Wt_day']=np.round(trendtable['ACTUAL_WEIGHT']/(trendtable['Date']*1000.0),0)
        return trendtable.drop(['ACTUAL_WEIGHT','Date'],axis=1)

# import pandas as pd
# import sframe as gl
# from datetime import datetime, timedelta
# startdate = "'2017-07-21'"
# enddate = "'2017-08-20'"

# a = lhplanning(startdate,enddate)

# a.loadtable(["LKOB","GOPF","UNAF","AMNF","AZMF","MAUF"],["southlist","westlist"])

# import requests
# import json

# url = "http://loadtable.ap.ngrok.io"
# data = {'originlist': '["bomabrlist","sgujbrlist"]', 'destinationlist': '["ncrnonupbrlist"]'}
# headers = {'Content-type': 'application/json'}
# r = requests.get(url, data=json.dumps(data), headers=headers)

# r.content