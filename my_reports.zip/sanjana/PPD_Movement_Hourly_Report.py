
# coding: utf-8

# In[1]:

import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta, date
import os
import ftplib
import traceback
import Utilities

#cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# In[2]:
# try:
query = ("""
        EXEC USP_PART_PIECE_MOVEMENT_HRLY_SQ
        """)


# In[3]:

df=pd.read_sql(query,Utilities.cnxn)

# In[4]:

len(df)


# In[5]:

df.columns


# In[6]:

df.head()


# In[7]:

df=df.fillna(0)


# In[8]:

main_pivot=df.pivot_table(index=['TYPE'],values=['DOCKNO'],aggfunc={'DOCKNO':len},margins=True,margins_name='Total').reset_index()


# In[9]:

main_pivot


# In[10]:

hubtohubdf=df[df['TYPE']=='HUB-HUB']
len(hubtohubdf)


# In[31]:

hubtohubdf_branch_pivot=hubtohubdf.pivot_table(index=['TCBR'],values=['DOCKNO'],
                                               aggfunc={'DOCKNO':len},margins=True,margins_name='Total').reset_index()


# In[32]:

hubtohubdf_branch_pivot


# In[15]:

hubtoscdf=df[df['TYPE']=='HUB-SC']
len(hubtoscdf)


# In[33]:

hubtoscdf_branch_pivot=hubtoscdf.pivot_table(index=['TCBR'],values=['DOCKNO'],
                                               aggfunc={'DOCKNO':len},margins=True,margins_name='Total').reset_index()


# In[34]:

hubtoscdf_branch_pivot


# In[18]:

sctohubdf=df[df['TYPE']=='SC-HUB']
len(sctohubdf)


# In[35]:

sctohubdf_branch_pivot=sctohubdf.pivot_table(index=['TCBR'],values=['DOCKNO'],
                                               aggfunc={'DOCKNO':len},margins=True,margins_name='Total').reset_index()


# In[36]:

sctohubdf_branch_pivot


# In[22]:

sctoscdf=df[df['TYPE']=='SC-SC']
len(sctoscdf)


# In[37]:

sctoscdf_branch_pivot=sctoscdf.pivot_table(index=['TCBR'],values=['DOCKNO'],
                                               aggfunc={'DOCKNO':len},margins=True,margins_name='Total').reset_index()


# In[38]:

sctoscdf_branch_pivot


# In[25]:

today=datetime.strftime(datetime.now(),'%Y-%m-%d')
today


# In[27]:

from pandas import ExcelWriter
with ExcelWriter(r'D:\Data\PPD_Movement_Cons\PPD_Movement_Cons-'+str(today)+'.xlsx') as writer:
    main_pivot.to_excel(writer,engine='xlsxwriter',sheet_name='Summary')
    df.to_excel(writer,engine='xlsxwriter',sheet_name='Con Data')
    


# In[28]:

from pandas import ExcelWriter
with ExcelWriter(r'D:\Data\PPD_Movement_Cons\PPD_Movement_Cons.xlsx') as writer:
    main_pivot.to_excel(writer,engine='xlsxwriter',sheet_name='Summary')
    df.to_excel(writer,engine='xlsxwriter',sheet_name='Con Data')
    


# In[29]:

filepath=r'D:\Data\PPD_Movement_Cons\PPD_Movement_Cons.xlsx'


# In[30]:

FROM='mis.ho@spoton.co.in'


TO=['HUBMGR_SPOT@spoton.co.in',"SQ_SPOT@spoton.co.in"]
CC=['sqtf@spoton.co.in','rajesh.kumar@spoton.co.in','abhik.mitra@spoton.co.in','jothi.menon@spoton.co.in','shivananda.p@spoton.co.in','rajesh.kapase@spoton.co.in','pawan.sharma@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in']
#TO=['mahesh.reddy@spoton.co.in']
#CC=['mahesh.reddy@spoton.co.in']
#BCC=['mahesh.reddy@spoton.co.in']

msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "PPM Movement Cons Hourly Report" + str(today)

report=""
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='PFA PPM Movement Cons'
report+='<br>'
report+='<br>'
report+='Summary'
report+='<br>'
report+='<br>'
report+='<br>'+main_pivot.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+='HUB-HUB Summary'
report+='<br>'
report+='<br>'+hubtohubdf_branch_pivot.to_html()+'<br>'
report+='<br>'
report+='HUB-SC Summary'
report+='<br>'
report+='<br>'+hubtoscdf_branch_pivot.to_html()+'<br>'
report+='<br>'
report+='SC-HUB Summary'
report+='<br>'
report+='<br>'+sctohubdf_branch_pivot.to_html()+'<br>'
report+='<br>'
report+='SC-SC Summary'
report+='<br>'
report+='<br>'+sctoscdf_branch_pivot.to_html()+'<br>'
report+='<br>'



#report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)

part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % 
os.path.basename(filepath))
msg.attach(part)



server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()

# except:

#   TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in'] 
#   #TO=['mahesh.reddy@spoton.co.in']
#   CC=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
#   FROM="mahesh.reddy@spoton.co.in"
#   msg = MIMEMultipart()
#   msg["From"] = FROM
#   msg["To"] = ",".join(TO)
#   msg["CC"] = ",".join(CC)
#   #msg["BCC"] = ",".join(BCC)
#   #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
#   msg["Subject"] = "PPM Movement Cons Hourly Report Error in Execution" 
#   report=""
#   report+='Hi,'

#   report+='<br>'
#   report+='There was some error in PPM Movement Cons Hourly Report'
#   report+='<br>'
  
#   abc=MIMEText(report.encode('utf-8'),'html')
#   msg.attach(abc)
#   server=smtplib.SMTP('smtp.sendgrid.net', 587)
#   server.ehlo()
#   server.starttls()
#   server.ehlo()
#   server.login("spoton.net.in", "Star@123#")
#   failed = server.sendmail(FROM, TO+CC, msg.as_string())
#   server.quit()


# In[ ]:



