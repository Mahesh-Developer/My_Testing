
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
from datetime import datetime, timedelta, date
import calendar
import datetime
from pandas import ExcelWriter
import os
import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from string import Template
import ftplib
from sqlalchemy import *
import pandas.io.sql
import sys
import Utilities


# In[2]:

todate=datetime.datetime.now()

today_date=datetime.datetime.strftime(todate,'%d-%b-%Y_%H')
print (today_date)

todayhr = datetime.datetime.now().hour
print (type(todayhr))

hourlist=[9,12,14]


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()


# In[3]:


# closingstockfull = closingstockfull.replace({'DBOM':'BWDB','DBLR':'BLRF','DPNQ':'PNQO','DLKO':'LKOB','DCCU':'CCUC'})


# In[4]:


orgquery = ("""EXEC USP_ORIGINSC_STOCK """)
originstock = pd.read_sql(orgquery, Utilities.cnxn)


# In[5]:


len(originstock)


# In[6]:


# replacedict = {'DBOM':'BWDB','DBLR':'BLRF','DPNQ':'PNQO','DLKO':'LKOB','DCCU':'CCUC'}


# In[7]:


# originstock['ORGBRCD_1'] = originstock['ORGBRCD'].map(replacedict)

# originstock['ORGBRCD'] = originstock['ORGBRCD'].replace
originstock['ORGBRCD'] = originstock['ORGBRCD'].replace({'DBOM':'BWDB','DBLR':'BLRC','DPNQ':'PNQO','DLKO':'LKOB','DCCU':'CCUC','JAIO':'JAIC','HSRB':'BLRT'})


# In[8]:


# replacedict.get('DBOM')


# In[9]:


# originstock['ORGBRCD_1'] = originstock['ORGBRCD'].apply(lambda x: x if replacedict.get(x)==None else replacedict.get(x))


# In[10]:


# originstock.to_csv(r'Origin.csv')


# In[11]:


originstock['Dest_Check'] = originstock.apply(lambda x: True if x['ORGBRCD']== x['DLVBRCD'] else False, axis=1)


# In[12]:


originstock['Dest_Check'].unique()


# In[13]:


# originstock.to_csv(r'Originstoc.csv')


# In[14]:


originstock = originstock[originstock['Dest_Check']==False]


# In[15]:


orggrp = originstock.groupby(['ORGBRCD']).agg({'ACTUWT':sum}).reset_index().sort_values('ACTUWT',ascending=False)


# In[16]:


orggrp.rename(columns={'ORGBRCD':'Location','ACTUWT':'Org_Inventory'},inplace=True)


# In[17]:


orggrp['Org_Inventory'] = pd.np.round(orggrp['Org_Inventory']/1000.0,0)


# In[18]:


orggrp


# In[19]:


query3 = ("""EXEC USP_CLOSINGSTOCK_REPORT_1HR_IE """)
# query3 = ("""EXEC UBESP_PUD_ANALYSIS_OPEN_CLOSE_STOCK_ARRV_DELV_SSRS_CS """)
closingstockfull=pd.read_sql(query3, Utilities.cnxn)


# In[20]:


# closingstockfull.to_csv(r'Closingstock1hr.csv')


# In[21]:


closingstockfull[closingstockfull['DEST_BRCD']=='DBOM']['ACTUWT'].sum(), closingstockfull[closingstockfull['DEST_BRCD']=='BWDB']['ACTUWT'].sum()


# In[22]:


# closingstockfull = closingstockfull.replace({'DBOM':'BWDB','DBLR':'BLRF','DPNQ':'PNQO','DLKO':'LKOB','DCCU':'CCUC'})

# closingstockfull['DEST_BRCD_1'] = closingstockfull['DEST_BRCD'].map(replacedict)
closingstockfull['DEST_BRCD'] = closingstockfull['DEST_BRCD'].replace({'DBOM':'BWDB','DBLR':'BLRC','DPNQ':'PNQO','DLKO':'LKOB','DCCU':'CCUC','JAIO':'JAIC','HSRB':'BLRT'})


# In[23]:


closingstockfull.columns


# In[24]:


closingstockfull[closingstockfull['DEST_BRCD']=='DBOM']['ACTUWT'].sum(), closingstockfull[closingstockfull['DEST_BRCD']=='BWDB']['ACTUWT'].sum()


# In[25]:


closingstockfull = closingstockfull[closingstockfull['DRS_PREPARED']=='NO']


# In[26]:


closingstockfull['DRS_PREPARED'].unique()


# In[27]:


closingstockfull[closingstockfull['DEST_BRCD']=='DCCU']['ACTUWT'].sum(), closingstockfull[closingstockfull['DEST_BRCD']=='CCUC']['ACTUWT'].sum()


# In[28]:


len(closingstockfull)


# In[29]:


ccflist= ['ADC','CPN','HCM','VSC','SSC','CDA','DNR','AFS','DDV','HWC','RRA','NPO','NPE','NPH','RRF','RRL','DIP','RRT','SHD','SPS','WIA','WIP','SRH','PSP','HIP','NTW','HIM','HMP','EWX','EWN','EWI','EEG']
ncflist = ['DNH','DEP','DDS','LDR','WIH','DDB','DDR','DGA','PDB','CSD','DLI','DSI','LMA','LCC','LDW','SHS','VCI']
stflist =['CCD','NSL','HBH','AND','PVB','WDP','MRS','SRD','SWP','SRS','SRP','CNC','LAM','SHO','SRC','DNL','SDC','SPD','DAL','SRE','DWA','DIA','DLP','DWR','FLD','ODV','SMD','LHI','MMB','MCD','MCL','MPH','MSH','LDV','LCR','LXL','LDD','LXN','LXO','LXV','LOC','LCN','LVB','MCV','HPM','LDO','MCA','MOO','MOP','SLX','DWC','AOD','SWN','DIR','EIR','SIR','PIR','VSV','VSD','VNT','DNC','VLE','SPC','NTD','CFD']
ucglist =['UCG','UG1','UG2','UG3']
aptlist=['APT','APN']
#blanklist =['CCD','NSL','SSC','CPN','HCM','HBH','AND','VSC']
def ccffunc(statuscode):
    if statuscode in ccflist:
        return 'CCF Con'
    elif statuscode in ucglist:
        return 'UCG'
    elif statuscode in ncflist:
        return "STF Con"
    elif statuscode in aptlist:
        return "Appointment Con"
    else:
        return "STF Con"


# In[30]:


closingstockfull['CCF_Con'] =closingstockfull.apply(lambda x:ccffunc(x['ConStatusCode']),axis=1)
destsummary = pd.pivot_table(closingstockfull,index=['DEST_BRCD'], columns=['CCF_Con'], values='ACTUWT', aggfunc={sum}, fill_value=0).reset_index()


# In[31]:


closingstockccf = closingstockfull[closingstockfull['CCF_Con']=='CCF Con']

closingstockccf = closingstockccf[['DOCKNO', 'ACTUWT', 'DEST_BRCD', 
                                    'ARRV_AT_DEST_SC', 'ORG_BRCD', 'ConStatusCode', 
                                    'ConStatusDesc','ConStatusReason','PARENTCODE', 'PARENTNAME','TimestateDate','CCF_Con']]

closingstockccf.rename(columns={'DOCKNO':'Con', 'ACTUWT':'Wt', 'DEST_BRCD':'Location', 
                                    'ARRV_AT_DEST_SC':'Arrv@Loc', 'ORG_BRCD':'Org', 'ConStatusCode':'ConStatusCode', 
                                    'ConStatusDesc':'ConStatusDesc','ConStatusReason':'ConStatusReason','PARENTCODE':'AccountCode', 'PARENTNAME':'AccountName','TimestateDate':'TIMESTAMP','CCF_Con':'CCF_Con'},inplace=True)


# In[32]:


destsummary.columns = [' '.join(col).strip() for col in destsummary.columns.values]
destsummary.rename(columns={'DEST_BRCD':'Location','sum Appointment Con':'Wt_Appointment_Dest','sum CCF Con':'Wt_CCF_Dest','sum STF Con':'Wt_Other_Dest','sum UCG':'Wt_UCG_Dest'},inplace=True)


# In[33]:


destsummary['Dest_Inventory'] = destsummary['Wt_CCF_Dest']+destsummary['Wt_Other_Dest']+destsummary['Wt_UCG_Dest']+destsummary['Wt_Appointment_Dest']


# In[34]:


# destsummary['%CCF'] = pd.np.round(destsummary['Wt_CCF_Dest']*100.0/destsummary['Dest_Inventory'],0)


# In[35]:


destsummary[destsummary['Location']=='CCUC']


# In[36]:


mergedf = pd.merge(orggrp, destsummary, on=['Location'], how='outer')


# In[37]:


mergedf['Wt_CCF_Dest'] = pd.np.round(mergedf['Wt_CCF_Dest']/1000.0,0)
# mergedf['Wt_CCF_Dest'] = pd.np.round(mergedf['Wt_CCF_Dest']/1000.0,0)
mergedf['Wt_Other_Dest'] = pd.np.round(mergedf['Wt_Other_Dest']/1000.0,0)
mergedf['Wt_UCG_Dest'] = pd.np.round(mergedf['Wt_UCG_Dest']/1000.0,0)
mergedf['Wt_Appointment_Dest'] = pd.np.round(mergedf['Wt_Appointment_Dest']/1000.0,0)
mergedf['Dest_Inventory'] = pd.np.round(mergedf['Dest_Inventory']/1000.0,0)


# In[38]:


# mergedf['Total_Inventory'] = mergedf['Org_Inventory']+mergedf['Dest_Inventory']


# In[39]:


# mergedf.sort_values('Total_Inventory',ascending=False,inplace=True)


# In[40]:


mergedf


# In[41]:


query2 = ("""EXEC USP_HUB_THROUGHPUT_DETAILS_SALES_ONEHOUR""")
intermediate =pd.read_sql(query2, Utilities.cnxn)


# In[42]:


# intermediate.to_csv(r'Intermediate.csv')


# In[43]:


# intermediate = intermediate.replace({'DBOM':'BWDB','DBLR':'BLRF','DPNQ':'PNQO','DLKO':'LKOB','DCCU':'CCUC'})
intermediate['Hub/SC Location'] = intermediate['Hub/SC Location'].replace({'DBOM':'BWDB','DBLR':'BLRC','DPNQ':'PNQO','DLKO':'LKOB','DCCU':'CCUC','JAIO':'JAIC','HSRB':'BLRT'})
# intermediate['Hub/SC Location_1'] = intermediate['Hub/SC Location'].map(replacedict)


# In[44]:


intermediate[intermediate['Hub/SC Location']=='DCCU']['Act.WtInTonnes'].sum(), intermediate[intermediate['Hub/SC Location']=='CCUC']['Act.WtInTonnes'].sum()


# In[45]:


intermediate['Org_Check'] = intermediate.apply(lambda x: True if x['Hub/SC Location']== x['Origin Branch'] else False, axis=1)
print (len(intermediate))
intermediate = intermediate[intermediate['Org_Check']==False]
print (len(intermediate))


# In[46]:


intermediate['Dest_Check'] = intermediate.apply(lambda x: True if x['Hub/SC Location']== x['DestnBranch'] else False, axis=1)
intermediate = intermediate[intermediate['Dest_Check']==False]
len(intermediate)


# In[47]:


intermediate['CCF_Con'] = intermediate.apply(lambda x:ccffunc(x['LatestStatusCode']),axis=1)


# In[48]:


# intermediate.to_csv(r'HTR_Data.csv')


# In[49]:


# intermediategrp = intermediate.groupby(['Hub/SC Location']).agg({'Act.WtInTonnes':sum}).reset_index()

intermediategrp = pd.pivot_table(intermediate,index=['Hub/SC Location'], columns=['CCF_Con'], values='Act.WtInTonnes', aggfunc={sum}, fill_value=0).reset_index()
intermediategrp.columns = [' '.join(col).strip() for col in intermediategrp.columns.values]
intermediategrp.rename(columns={'Hub/SC Location':'Location','sum Appointment Con':'Wt_Appointment_Intmd','sum CCF Con':'Wt_CCF_Intmd','sum STF Con':'Wt_Other_Intmd','sum UCG':'Wt_UCG_Intmd'},inplace=True)


# In[50]:


intermediateccf = intermediate[intermediate['CCF_Con']=='CCF Con']
intermediateccf = intermediateccf[['Hub/SC Location','Arrival Date @ Hub','Con Number','Origin Branch','DestnBranch',
                                'Act.WtInTonnes','LatestStatusCode','LatestStatusReason','AccountCode','AccountName',
                                'TIMESTAMP','CCF_Con']]

intermediateccf.rename(columns={'Con Number':'Con', 'Act.WtInTonnes':'Wt', 'Hub/SC Location':'Location', 
                                    'Arrival Date @ Hub':'Arrv@Loc', 'Origin Branch':'Org', 'LatestStatusCode':'ConStatusCode', 
                                    'ConStatusDesc':'ConStatusDesc','LatestStatusReason':'ConStatusReason'},inplace=True)


# In[51]:


intermediategrp['Wt_CCF_Intmd'] = pd.np.round(intermediategrp['Wt_CCF_Intmd'],0)
intermediategrp['Wt_Other_Intmd'] = pd.np.round(intermediategrp['Wt_Other_Intmd'],0)
intermediategrp['Wt_UCG_Intmd'] = pd.np.round(intermediategrp['Wt_UCG_Intmd'],0)
intermediategrp['Wt_Appointment_Intmd'] = pd.np.round(intermediategrp['Wt_Appointment_Intmd'],0)



# In[52]:


intermediategrp


# In[53]:


mergedf = pd.merge(mergedf, intermediategrp, on=['Location'], how='left')


# In[54]:


mergedf.fillna(0,inplace=True)


# In[55]:


mergedf.head()


# In[56]:


mergedf['Total_CCF'] = mergedf['Wt_CCF_Dest']+mergedf['Wt_CCF_Intmd']
mergedf['Total_Appointment'] = mergedf['Wt_Appointment_Dest']+mergedf['Wt_Appointment_Intmd']
mergedf['Total_Inventory'] = mergedf['Org_Inventory']+mergedf['Dest_Inventory']+mergedf['Wt_CCF_Intmd']+mergedf['Wt_Other_Intmd']+mergedf['Wt_UCG_Intmd']+mergedf['Wt_Appointment_Intmd']


# In[57]:


mergedf[mergedf['Location']=='IXRB']


# In[58]:


# mergedf.to_csv(r'Mergeddf.csv')


# In[59]:


capacity = pd.read_csv(r'D:\Python\Scripts and Files\Python Scripts\SC_Space.csv')


# In[60]:


capacity.head()


# In[61]:


merger = pd.merge(mergedf, capacity, on=['Location'], how='left')


# In[62]:


# merger.to_csv(r'Mergeddfv8.csv')


# In[63]:


merger['Current Space(Sqft)'].fillna('-',inplace=True)


# In[64]:


mergerreq = merger[merger['Current Space(Sqft)']!='-']


# In[65]:


mergerreq.head()


# In[66]:


mergerreq['%_Filled'] = pd.np.round(mergerreq['Total_Inventory']*100.0/mergerreq['Capacity(T)'],0)


# In[67]:


mergerreq['%_Filled_CCF'] = pd.np.round(mergerreq['Total_CCF']*100.0/mergerreq['Capacity(T)'],0)
mergerreq['%_Filled_Appointment'] = pd.np.round(mergerreq['Total_Appointment']*100.0/mergerreq['Capacity(T)'],0)


# ## For removing branches that dont need to be considered

# In[68]:


removelist = ['NMBB','SHBB']
mergerreq = mergerreq[~(mergerreq['Location'].isin(removelist))]


# In[69]:


reqbranches = mergerreq['Location'].unique().tolist()


# In[70]:


# mergerreqcols = mergerreq[['Location','Org_Inventory','Wt_CCF_Dest','Wt_Other_Dest','Wt_UCG_Dest','Dest_Inventory','Wt_CCF_Intmd','Wt_Other_Intmd','Total_CCF','Total_Inventory','Current Space','Total Hub space','Capacity','']]


# In[71]:


# mergerreq.to_csv(r'Mergerv10.csv')


# In[72]:


# intermediate.to_csv(r'HTR_Data.csv')


# In[73]:


closingstockccf['Wt'] = pd.np.round(closingstockccf['Wt']/1000.0,2)


# In[74]:


ccfmerge = closingstockccf.append(intermediateccf)


# In[75]:


ccfmerge[ccfmerge['Location']=='CCUC']['Wt'].sum()


# In[76]:


ccfgrp = ccfmerge.groupby(['Location','AccountCode','AccountName']).agg({'Wt':sum}).reset_index()


# In[77]:


ccfgrp['Wt'] = pd.np.round(ccfgrp['Wt'],1)


# In[78]:


def getwt(wt):
    df = ccfgrp[ccfgrp['Location']==wt].sort_values('Wt',ascending=False).head(3)
    return df


# In[79]:


# ccfgrp23=ccfgrp.head(1)


# In[80]:


finaccfdf = pd.DataFrame()
for i in reqbranches:
    dff=getwt(i)
    finaccfdf = pd.concat([finaccfdf,dff],ignore_index=True)





finaccfdf['Top_3_Customers']=finaccfdf.apply(lambda x:{x['AccountName']:x['Wt']},axis=1)

finaccfdfgrp = finaccfdf.groupby('Location')['Top_3_Customers'].apply(lambda x: x.values).reset_index() 


# In[85]:


# finaccfdfgrp.to_csv(r'CCFGRP.csv')


# In[86]:


ccfgrp[ccfgrp['Location']=='JAIC'].sort_values('Wt',ascending=False)['Wt'].sum()


# In[87]:


mergerreqccf = pd.merge(mergerreq,finaccfdfgrp, on=['Location'], how='left')


# In[88]:


mergerreqccf


# In[89]:


mergerreqccf = mergerreqccf.sort_values('%_Filled_CCF',ascending=False)


# In[90]:


mergerreqccf


# In[91]:


mergerreqccfmail = mergerreqccf[['Location','Total_CCF','Total_Appointment','Total_Inventory','Current Space(Sqft)','Capacity(T)','%_Filled','%_Filled_CCF','%_Filled_Appointment','Top_3_Customers']] #


# In[92]:


mergerreqccfmail = mergerreqccfmail.head(20)


# In[93]:


mergerreqccfmail


# In[94]:

# todate=date.today()

# todate=datetime.datetime.now()

# today_date=datetime.strftime(todate,'%d-%m-%H')
# todate


# with ExcelWriter(r'D:\Data\CCF_Major_SC\CCF_Customer_Wise_'+str(todate)+'.xlsx') as writer:
#     ###orginal_cancel_basedata.to_excel(writer, sheet_name='Sheet1',engine='xlsxwriter')
#     mergerreqccf.to_excel(writer, sheet_name='Summary_Branchwise',engine='xlsxwriter')
#     finaccfdf.to_excel(writer, sheet_name='TOP3_Customers_Branchwise',engine='xlsxwriter')
#     ccfmerge.to_excel(writer, sheet_name='CCF_Conwise_Data',engine='xlsxwriter')


writer = pd.ExcelWriter(r'D:\Data\CCF_Major_SC\CCF_Customer_Wise_'+str(today_date)+'.xlsx', engine='xlsxwriter')
mergerreqccf.to_excel(writer, sheet_name='Summary_Branchwise',engine='xlsxwriter')
# finaccfdf.to_excel(writer, sheet_name='TOP3_Customers_Branchwise',engine='xlsxwriter')
# ccfmerge.to_excel(writer, sheet_name='CCF_Conwise_Data',engine='xlsxwriter')
writer.save()

ccfmerge.to_csv(r'D:\Data\CCF_Major_SC\CCF_Cons_data_'+str(today_date)+'.csv')
finaccfdf.to_csv(r'D:\Data\CCF_Major_SC\TOP3_Customers_Branchwise_'+str(today_date)+'.csv')
# In[95]:


filepath = r'D:\Data\CCF_Major_SC\CCF_Customer_Wise_'+str(today_date)+'.xlsx'
filepath1 = r'D:\Data\CCF_Major_SC\CCF_Cons_data_'+str(today_date)+'.csv'
filepath2 = r'D:\Data\CCF_Major_SC\TOP3_Customers_Branchwise_'+str(today_date)+'.csv'

# In[96]:


# In[97]:

if todayhr in hourlist:
    TO=['pawan.sharma@spoton.co.in','sharmistha.majumdar@spoton.co.in','rajesh.kumar@spoton.co.in','jothi.menon@spoton.co.in','spot_cstl@spoton.co.in']
    # TO=['vishwas.j@spoton.co.in','syed.hussain@spoton.co.in']
    FROM="reports.ie@spoton.co.in"
    # CC=['vish.kimi@gmail.com']
    CC=['syed.hussain@spoton.co.in','shivananda.p@spoton.co.in','satya.pal@spoton.co.in','abhik.mitra@spoton.co.in','vineet.vikram@spoton.co.in']
    # BCC=['vishwas.j@spoton.co.in']
    BCC=['mahesh.reddy@spoton.co.in']


else:
    TO=['syed.hussain@spoton.co.in']
    FROM="reports.ie@spoton.co.in"
    CC=['mahesh.reddy@spoton.co.in']
    BCC=['mahesh.reddy@spoton.co.in']


msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = "CCF - Major Locations" + " - " + str(today_date)
html='''<html>
<style>
p
{
margin:0;
margin-top: 5px;
padding:0;
font-size:17px;
line-height:20px;
}
</style>
</html>'''

report="Dear All,"
report+='<br>'
report+='<br>'
report+="Top 20 Branches with Major CCF are as below. The summary is sorted on the fullness of location based on CCF. "
report+='<br>'
report+='<br>'
report+='<br>'+mergerreqccfmail.to_html()+'<br>'
report+='<br>'
report+='Only the Top 20 branches are mentioned on the email. The entire list is attached in the email. The attachment contains'
report+='<br>'
report+='<br>'
report+='Summary_Branchwise : Contains branchwise summary of inventory with the split of CCF and Non-CCF'
report+='<br>'
report+='TOP3_Customers_Branchwise : Contains the branchwise Top 3 customers contributing to CCF'
report+='<br>'
report+='CCF_Conwise_Data : Conwise information of the CCF cons with few important parameters'
report+='<br>'
report+='<br>'
report+='NOTE : For virtual branches, as we dont have the breakup of hub and sc area, have assumed 40% of the hub area. Will incorporate actual area once we have the breakup'



#report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)


part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(filepath1,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
msg.attach(part1)

part2 = MIMEBase('application', "octet-stream")
part2.set_payload( open(filepath2,"rb").read() )
encoders.encode_base64(part2)
part2.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath2))
msg.attach(part2)

server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
# server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()

