
# coding: utf-8

# In[ ]:

import pandas.io.sql
import pandas as pd
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
#import datetime
import os
import numpy as np
import Utilities


# In[ ]:

cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")


# In[ ]:

query=("exec USP_STOCK_ALL_SQ_AIR")


# In[ ]:

df=pd.read_sql(query,cnxn)
print (len(df))

# In[ ]:

len(df)
def getParameter(curr,orgnbrnch,originhub,desthub,destsc):
    if curr==orgnbrnch:
        return "1. Origin Branch"
    elif curr==originhub:
        return "2. Origin Hub"
    elif curr==desthub:
        return "3. Destination Hub"
    elif curr==destsc:
        return "4. Destination Sc"
    else:
        return "5. Intransit"
df['Type']=df.apply(lambda x:getParameter(x['CURR_BRANCHCODE'],x['ORIGIN_BRCODE'],x['DEFAULTHUB'],x['DESTHUB'],x['REASSIGN_DESTCD']),axis=1)

# In[ ]:

def getBucket(hrs):
    if hrs in range(0,4):
        return "<4 Hrs"
    elif hrs in range(4,8):
        return "4-8 Hrs"
    elif hrs in range(8,16):
        return "8-16 Hrs"
    elif hrs in range(16,24):
        return "16-24 Hrs"
    elif hrs in range(24,48):
        return "24-48 Hrs"
    elif hrs in range(48,72):
        return "48-72 Hrs"
    else:
        return ">72 Hrs"


# In[ ]:

df['Bucket']=df.apply(lambda x: getBucket(x['HOURS_LYING_AT_CURR_LOCATION']),axis=1)


# In[ ]:




# In[ ]:

summary=df.pivot_table(index=['Type', 'CURR_BRANCHCODE'],columns=['Bucket'],aggfunc={'DOCKNO':len}).fillna(0)
summary


# In[ ]:



# In[ ]:

depotdftots1 = summary.groupby(level='Type').sum()



depotdftots1.index = [depotdftots1.index, ['Total'] * len(depotdftots1)]


# In[ ]:

depotdftots1


# In[ ]:

depotpivot1 = np.round(pd.concat([summary,depotdftots1]).sort_index().append(summary.sum().rename(('Grand', 'Total'))),2)
depotpivot1=depotpivot1.fillna(0)

depotpivot1['DOCKNO']=depotpivot1['DOCKNO'].astype(int)



# summary1

print (depotpivot1)

depotpivot2=pd.DataFrame()
for i in ["<4 Hrs","4-8 Hrs","8-16 Hrs","16-24 Hrs","24-48 Hrs","48-72 Hrs",">72 Hrs"]:
    try:
        depotpivot2[i]=depotpivot1[('DOCKNO',i)].astype(int)
    except:
        depotpivot2[i]=0
depotpivot2['Total']=depotpivot2.sum(axis=1)
depotpivot2['Total']=depotpivot2['Total'].astype(int)

todate=datetime.strftime(datetime.now(),"%Y-%m-%d")
todate


# In[ ]:

df.to_csv(r'D:\Data\undel_mgt_air\Undel_Mgt_Air_Data'+str(todate)+'.csv')
df.to_csv(r'D:\Data\undel_mgt_air\Undel_Mgt_Air_Data.csv')


# In[ ]:

depotpivot2.to_csv(r'D:\Data\undel_mgt_air\Undel_Mgt_Air_Summary'+str(todate)+'.csv')
depotpivot2.to_csv(r'D:\Data\undel_mgt_air\Undel_Mgt_Air_Summary.csv')


# In[ ]:

filepath=r'D:\Data\undel_mgt_air\Undel_Mgt_Air_Data.csv'
filepath1=r'D:\Data\undel_mgt_air\Undel_Mgt_Air_Summary.csv'


# In[ ]:

dt=datetime.strftime(datetime.now(),"%Y-%m-%d %H")
dt


# In[ ]:

# BCC=['mahesh.reddy@spoton.co.in']
BCC=["rom_spot@spoton.co.in","aom_spot@spoton.co.in","dom_spot@spoton.co.in","sq_spot@spoton.co.in","sqtf@spoton.co.in","Air_Operation@spoton.co.in","mahesh.reddy@spoton.co.in"]
#CC=['mahesh.reddy@spoton.co.in']
FROM="reports.ie@spoton.co.in"
# FROM="mahesh.reddy@spoton.co.in"
msg = MIMEMultipart()
msg["From"] = FROM
# msg["To"] = ",".join(TO)
msg["BCC"] = ",".join(BCC)
#msg["BCC"] = ",".join(BCC)
#msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
msg["Subject"] = "Undel Mgt -Air " + " - " + str(dt)
html='''<html>
<h4>Dear All,</h4>
<p>PFA the Air Monitoring Report for $date</p>
</html>'''
#s = Template(html).safe_substitute(date=yest_date)
report=""
report+="Dear All"
report+='<br>'
report+='Please find Undel Managment for Air'
report+='<br>'
report+='PFA Summary'
report+='<br>'
report+='<br>'+depotpivot2.to_html()+'<br>'
report+='<br>'

abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(filepath1,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
msg.attach(part1)


# server=smtplib.SMTP('smtp.sendgrid.net', 587)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
# server.login("mahesh.reddy@spoton.co.in", "Nov@2018")
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, BCC, msg.as_string())
server.quit()


# In[ ]:

