
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import pyodbc
from datetime import date,timedelta,datetime
import sys
import Utilities
reload(sys).setdefaultencoding("ISO-8859-1")



# In[2]:


# cnxn=pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")


# # In[3]:


# cursor=cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()
# In[4]:


query=(""" EXEC USP_NETWORK_STOCK_SQ """)


# In[5]:


network_df=pd.read_sql(query,Utilities.cnxn)


# In[6]:


len(network_df)


# In[7]:



# In[8]:


from pandas import ExcelWriter


# In[9]:


with ExcelWriter(r'D:\Data\ODA_Loads_Ton_wise\\Network_stock.xlsx') as writer:
    network_df.to_excel(writer, sheet_name='Network_stock',engine='xlsxwriter')
    
    


# In[10]:


filepath=r'D:\Data\ODA_Loads_Ton_wise\Network_stock.xlsx'


# In[11]:


import numpy as np
import pandas as pd
import itertools
import json
from pandas import ExcelWriter
from pandas import pivot_table
from datetime import datetime
import os
import ftplib
import traceback

oppath1=filepath
#FTP Upload starts
print ('Logging in...')
ftp = ftplib.FTP()  
ftp.connect('10.109.230.50')  
print (ftp.getwelcome())
try:  
    try:  
        ftp.login('HOSQTeam', 'Te@mH0$q')
        print ('login done')
        ftp.cwd('Auto_reports')  
        #ftp.cwd('FIFO')
        # move to the desired upload directory  
        print ("Currently in:", ftp.pwd()) 
        print ('Uploading...')  
        fullname = oppath1
        name = os.path.split(fullname)[1]  
        print ('os path ok')
        f = open(fullname, "rb")  
        ftp.storbinary('STOR ' + name, f)  
        f.close()  
        print ("OK"  )
        print ("Files:")  
        print (ftp.retrlines('LIST'))
    finally:  
        print ("Quitting...")
        ftp.quit()  
except:  
    traceback.print_exc()


# In[13]:


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
from email.mime.base import MIMEBase
# from email import Encoders
import os
from email import encoders

from_addr = 'mis.ho@spoton.co.in'
# sharanagouda.biradar@spoton.co.in
#to_addr = ['mahesh.reddy@spoton.co.in']
#to_addr = ['prafulla.masurkar@spoton.co.in']
#cc_addr = ['maheshmahesh11464@gmail.com']
cc_addr = ['shivananda.p@spoton.co.in','rajesh.kumar@spoton.co.in','anitha.thyagarajan@spoton.co.in']


username = 'mis.ho@spoton.co.in'
password = 'Mis@2019'

msg = MIMEMultipart()

msg['From'] = from_addr
#msg['To'] = ', '.join(to_addr)
#msg['bcc'] = ', '.join(bcc_addr)
msg['cc'] = ', '.join(cc_addr)
msg['Subject'] = 'Network & Destination Stock Report'
html='''<html>
<h4>Dear All</h4>
<p> Pls find the below Network Stock details</p>
</html>'''



# part10=MIMEText(html1,'html')
#  <h5>Rajesh M P </h5></b>
# msg.attach(part10)
html3='''
<h5> To download the Details of "Network Stock details", Please click the link below </h5>
<p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Network_stock.xlsx"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Network_stock.xlsx</p></b>
'''



html4='''<h5>Thanks & Regards</h5></b>
<h5>HO-SQ</h5>'''

report=""
report+=html
# report+=html1
report+='<br>'
report+=html3
abc=MIMEText(report,'html')
msg.attach(abc)

server = smtplib.SMTP('smtp.spoton.co.in',587)
part=MIMEBase('application','octet-stream')
# for attachment insted of link
# part.set_payload(open(filepath,'rb').read())
# Encoders.encode_base64(part)
# part.add_header('Content-Disposition','attachment;filename="%s"'%os.path.basename(filepath))
# msg.attach(part)

server.ehlo()
server.starttls()
server.ehlo()
server.login('mis.ho@spoton.co.in','Mis@2019')
server.sendmail(from_addr,cc_addr,msg.as_string())
print ('mail sent succesfully')
server.quit()

