
# coding: utf-8

# In[1]:

import pandas as pd
from datetime import datetime, timedelta
import numpy as np
pd.set_option('display.max_columns',40)
from sqlalchemy import *
import os
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders

# engine = create_engine("mysql+pymysql://user:pwd@104.199.198.197/LH30days")
try:
	engine = create_engine("mysql+pymysql://spotonhr:spoton54321@104.199.198.197/LH30days")

	# In[2]:

	provrev=60


	# In[3]:

	startdate=datetime.strftime(datetime.now()-timedelta(days=31),"%Y-%m-%d")
	df = pd.read_sql("SELECT * FROM LH30days WHERE `THC DATE` >='{}'".format(startdate),engine)
	df=df[~(df["Vech Type"].isin(['DATAVECHILE','VIRTUALHUB']))]
	df["VEHICLE PAYLOAD"]=df["VEHICLE PAYLOAD"].replace(0,13500)
	df["Util%"] = df.apply(lambda x: round(x["TOTAL ACTUAL LOAD"]*100.0/x["VEHICLE PAYLOAD"],1),axis=1)
	df["Vol Util%"] = df.apply(lambda x: round(x["TOTAL VOL WEIGHT"]*100.0/x["VEHICLE PAYLOAD"],1),axis=1)


	# In[4]:

	dfyest=df[(df["THC DATE"]>=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)-timedelta(days=1)))&(df["THC DATE"]<=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)))]
	
	lhcost=round(dfyest["COST"].sum()/1e5,1)
	yestutil = round(dfyest["TOTAL ACTUAL LOAD"].sum()*100.0/dfyest["VEHICLE PAYLOAD"].sum(),1)
	mktusageyest=round(dfyest[dfyest['ROUTE CODE']=='9888']["COST"].sum()*100.0/(1e5*lhcost),1)


	# In[8]:

	dfmtd=df[(df["THC DATE"]>=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)-timedelta(days=1)).replace(day=1))&(df["THC DATE"]<=(datetime.today().replace(hour=9,minute=0,second=0,microsecond=0)))]
	mtdlhcost=round(dfmtd["COST"].sum()/1e5,1)-provrev
	mtdutil = round(dfmtd["TOTAL ACTUAL LOAD"].sum()*100.0/dfmtd["VEHICLE PAYLOAD"].sum(),1)
	mktusagemtd=round(dfmtd[dfmtd['ROUTE CODE']=='9888']["COST"].sum()*100.0/(1e5*(mtdlhcost+provrev)),1)


	# In[ ]:

	# engine2 = create_engine("mysql+pymysql://user:pwd@104.199.198.197/revenuebkg")
	engine2 = create_engine("mysql+pymysql://spotonhr:spoton54321@104.199.198.197/revenuebkg")

	startdate="'"+datetime.strftime((datetime.now()-timedelta(days=1)).replace(day=1),"%Y-%m-%d")+"'"
	enddate="'"+datetime.strftime(datetime.now(),"%Y-%m-%d")+"'"
	df = pd.read_sql("SELECT `PARENTNAME`,`AccountType`,`PICKUP_DATE`,`CUSTOMERCODE`,`CUSTOMER_SIGNED_AT_DEPOT`,`CUSTOMER_REGION`,`Actual_Weight`,`NetRev`,`ORG_REGION`,`DEST_REGION`,`Source_Branch`,`Destination_Branch`,`SaleDepott` FROM revenuebkg WHERE `PICKUP_DATE` >= {0} AND `PICKUP_DATE` < {1}".format(startdate,enddate),engine2) 
	yeststart = datetime.combine((datetime.now()-timedelta(days=1)).date(), datetime.min.time())
	mtdrevenue = round(df["NetRev"].sum()*0.9645/100000.0,1)
	yestrevenue=round(df[df["PICKUP_DATE"]>=yeststart]["NetRev"].sum()*0.9645/100000.0,1)


	# In[ ]:

	if yestrevenue==0:
	    yestrevenue = '--error--'
	    mtdrevenue = '--error--'
	    mtdprop = '--error--'

	if yestrevenue!=0:
	    prop = round((lhcost/yestrevenue)*100.0,1)
	    mtdprop=round((mtdlhcost/mtdrevenue)*100.0,1)
	else:
	    prop = 0
	    mtdprop=0


	# In[ ]:

	


	# In[ ]:
	#TO=["ankit@iepfunds.com","supratim@iepfunds.com","krishna.chandrasekar@spoton.co.in","pawan.sharma@spoton.co.in","satya.pal@spoton.co.in","vishwas.j@spoton.co.in","abhik.mitra@spoton.co.in"]
	# TO=['vishwas.j@spoton.co.in',"ankit@iepfunds.com","satya.pal@spoton.co.in"]
	#TO=['vishwas.j@spoton.co.in',"satya.pal@spoton.co.in"]
	TO=["krishna.chandrasekar@spoton.co.in","pawan.sharma@spoton.co.in","satya.pal@spoton.co.in","vishwas.j@spoton.co.in","abhik.mitra@spoton.co.in"]

	CC=['mahesh.reddy@spoton.co.in']
	FROM="reports.ie@spoton.co.in"
	msg = MIMEMultipart()
	msg["From"] = FROM
	msg["To"] = ",".join(TO)
	msg["CC"] = ",".join(CC)
	#msg["BCC"] = ",".join(BCC)

	msg["Subject"] = "LH cost" + ' - ' +str(datetime.strftime(datetime.today()-timedelta(hours=24),"%d-%m"))

	report=""
	report+='Dear All,'

	report+='<br>'
	report+='<br>'
	report+='LH cost for yesterday is Rs.'+str(lhcost)+" lakhs."
	#report+='<br>'
	report+='<br>'
	report+='Approx. revenue for yesterday is Rs.'+str(yestrevenue)+' lakhs.'
	report+='<br>'
	report+='Approx. LH% : '+str(prop)+'%'
	report+='<br>'
	report+='<br>'
	report+='MTD LH cost is Rs.'+str(mtdlhcost)+' lakhs (after providing Rs.'+str(provrev)+' lakhs).'
	report+='<br>'
	report+='MTD revenue is Rs.'+str(mtdrevenue)+' lakhs.'
	report+='<br>'
	report+='LH% of Rev for the month is: '+str(mtdprop)+'%.'
	report+='<br>'
	report+='<br>'
	report+='Yesterdays utilisation is '+str(yestutil)+'%'+ '(excl. touching mkt veh adjustment)'
	report+='<br>'
	report+='MTD utilisation is '+ str(mtdutil)+'%.'
	report+='<br>'
	report+='Yesterdays market % is '+ str(mktusageyest)+'%.'
	report+='<br>'
	report+='MTD market % (in terms of cost) is '+str(mktusagemtd)+'%.'

	abc=MIMEText(report,'html')
	msg.attach(abc)




	server=smtplib.SMTP('smtp.sendgrid.net', 587)
	server.ehlo()
	server.starttls()
	server.ehlo()
	server.login("spoton.net.in", "Star@123#")
	failed = server.sendmail(FROM, TO+CC, msg.as_string())
	server.quit()

except:
  TO=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  #msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "ERROR Report" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in LH cost'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO, msg.as_string())
  server.quit()

#send_email(["ankit@iepfunds.com","supratim@iepfunds.com","krishna.chandrasekar@spoton.co.in","pawan.sharma@spoton.co.in","satya.pal@spoton.co.in","vishwas.j@spoton.co.in","abhik.mitra@spoton.co.in"])

