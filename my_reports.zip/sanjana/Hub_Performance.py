
# coding: utf-8

# In[1]:

import pandas.io.sql
import pandas as pd
import sys
import numpy as np
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
import smtplib
import ftplib
import traceback
import calendar
import os
import Utilities

# In[2]:

cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()


# In[3]:
try:
    query=(""" EXEC USP_HUB_THROUGHPUT_PYTHON ''""")


    # In[4]:

    # df=pd.read_sql(query,Utilities.cnxn)
    df=pd.read_sql(query,cnxn)


    # In[5]:

    len(df)


    # In[6]:

    df1=df[df['ELEDESC'].isin(['OPENING STOCK','INCOMING','OUTGOING','CLOSING STOCK'])]


    # In[7]:

    len(df1)


    # In[8]:

    df1.rename(columns={'DOCKNO':'CON','ACTUWT':'Wt'},inplace=True)


    # In[9]:

    pivot=pd.pivot_table(df1,index=['HUBLOC'],columns=['ELEDESC'],values=['CON','Wt'],aggfunc={'CON':len,'Wt':sum}).reset_index()


    # In[10]:

    pivot['Wt']=pd.np.round(pivot['Wt']/1000.0,0)


    # In[11]:

    pivot['Wt','Performance']=pd.np.round(pivot[('Wt','OUTGOING')]*100/(pivot[('Wt','INCOMING')]+pivot[('Wt','OPENING STOCK')]),0)


    # In[12]:

    pivot


    # In[13]:

    pivot['CON','Performance']=pd.np.round(pivot[('CON','OUTGOING')]*100/(pivot[('CON','INCOMING')]+pivot[('CON','OPENING STOCK')]),0)


    # In[14]:

    pivot


    # In[15]:

    query1=("""EXEC USP_HUB_THROUGHPUT_DETAILS ''""")


    # In[16]:
    # depspaperworkcodelist = ['ADC','AND','DDS','DIA','DWC','PCF','PER','RRF','SDR','SHO','SPC','SPS','WIH','EWN','EWX','EWI','SRE','SRD','SRS','SRP','DLP','SWP','PWS','HCM','HPM','MOP','SRH','HOC','ONR','SPH','SPO','DBO','DIP','SHS','SSC','HIP','RNX','APT','APN','SHD','SMT','SPL','MSH','UCG','RRA','HPE','WIA','UG1','UG2','UG3','HMP','HWC','NPE','HIM','LDR','SWN','LOC','LVB']
    depspaperworkcodelist = ['LDW','DDS','DGA','DDB','SFM','DDK','RRL','DNH','HBH','PPL','PPR','ADC','AND','DIA','DWC','PCF','PER','RRF','SDR','SHO','SPC','SPS','WIH','EWN','EWX','EWI','SRE','SRD','SRS','SRP','DLP','SWP','PWS','HCM','HPM','MOP','SRH','HOC','ONR','SPH','SPO','DBO','DIP','SHS','SSC','HIP','RNX','APT','APN','SHD','SMT','SPL','MSH','UCG','RRA','HPE','WIA','UG1','UG2','UG3','HMP','HWC','NPE','HIM','LDR','SWN','LVB']

    details_df=pd.read_sql(query1,cnxn)
    print ('details_df',details_df)
    details_df=details_df[~details_df['DOCKNO'].isin([730450031,715128049])]
    print ('details_df',details_df)
    details_df['Is Deps']=details_df['LATESTSTATUSCODE'].apply(lambda x: True if x in depspaperworkcodelist else False)

    # In[17]:

    len(details_df)

    # In[18]:

    details_df['Current Time']=datetime.today().replace(hour=11,minute=0,second=0,microsecond=0)
    print (details_df['Current Time'].head())
    # In[19]:

    details_df['Time Difference']=details_df['Current Time']-details_df['FEEDER_THC_INCOM_DATE']
    
    # In[20]:

    details_df['Hours']=details_df['Time Difference']/np.timedelta64(1,'h')
    overallcool = pd.np.round(details_df['Hours'].sum()/len(details_df),0)


    # In[21]:

    pivot1=pd.pivot_table(details_df,index=['HUBLOC'],values=['Hours'],aggfunc={'Hours':pd.np.mean})


    # In[22]:

    pivot1=pivot1.reset_index()


    # In[23]:

    pivot1['Hours']=pd.np.round(pivot1['Hours'],0)


    # In[24]:

    pivot1


    # In[33]:

    pivot.columns


    # In[ ]:



    # In[ ]:




    # In[34]:

    pivot=pd.merge(pivot,pivot1,on='HUBLOC')


    # In[ ]:

    pivot


    # In[35]:

    pivot.rename(columns={(u'CON', u'CLOSING STOCK'):'CON_CLOSING',(u'CON', u'INCOMING'):'CON_INCOMING',(u'CON', u'OPENING STOCK'):'CON_OPENING',(u'CON', u'OUTGOING'):'CON_OUTGOING',(u'CON', u'Performance'):'CON_PERF%',(u'Wt', u'CLOSING STOCK'):'Wt_CLOSING',(u'Wt', u'INCOMING'):'Wt_INCOMING',(u'Wt', u'OPENING STOCK'):'Wt_OPENING',(u'Wt', u'OUTGOING'):'Wt_OUTGOING',(u'Wt', u'Performance'):'Wt_PERF%','Hours':'Cooling'},inplace=True)


    # In[36]:

    del pivot[(u'HUBLOC', u'')]


    # In[37]:

    pivot1=pivot[['HUBLOC','Cooling','CON_INCOMING','CON_OPENING','CON_OUTGOING','CON_CLOSING','CON_PERF%','Wt_INCOMING','Wt_OPENING','Wt_OUTGOING','Wt_CLOSING','Wt_PERF%']]
    ovllinc_con = pivot1['CON_INCOMING'].sum()
    ovllopn_con = pivot1['CON_OPENING'].sum()
    ovllcls_con = pivot1['CON_CLOSING'].sum()
    ovllout_con = pivot1['CON_OUTGOING'].sum()
    ovllperf_con = pd.np.round((ovllout_con*1.0/(ovllinc_con+ovllopn_con))*100,0)

    print ovllperf_con, ovllinc_con, ovllopn_con, ovllcls_con, ovllout_con
    print type(ovllperf_con), type(ovllinc_con), type(ovllopn_con), type(ovllcls_con), type(ovllout_con)

    ovllinc_wt = pivot1['Wt_INCOMING'].sum()
    ovllopn_wt = pivot1['Wt_OPENING'].sum()
    ovllcls_wt = pivot1['Wt_CLOSING'].sum()
    ovllout_wt = pivot1['Wt_OUTGOING'].sum()
    ovllperf_wt = pd.np.round((ovllout_wt/(ovllinc_wt+ovllopn_wt))*100.0,0)


    sumlist = ['ALL',overallcool,ovllinc_con,ovllopn_con,ovllout_con,ovllcls_con,ovllperf_con,ovllinc_wt,ovllopn_wt,ovllout_wt,ovllcls_wt,ovllperf_wt]
    col_list = ['HUBLOC','Cooling','CON_INCOMING','CON_OPENING','CON_OUTGOING','CON_CLOSING','CON_PERF%','Wt_INCOMING','Wt_OPENING','Wt_OUTGOING','Wt_CLOSING','Wt_PERF%']
    totalsdf = pd.DataFrame(data=[sumlist], columns = col_list)
    pivot1 = pivot1.append(totalsdf,ignore_index=True)
    # In[ ]:


    # In[38]:

    pivot1_excdeps=pivot1[['HUBLOC','CON_INCOMING','CON_OPENING','CON_OUTGOING','CON_PERF%','Wt_INCOMING','Wt_OPENING','Wt_OUTGOING','Wt_PERF%']]


    # In[39]:

    pivot1_excdeps.head()


    # In[ ]:

    len(details_df)


    # In[40]:

    details_df_excdeps=details_df[~details_df['LATESTSTATUSCODE'].isin(depspaperworkcodelist)]

    excldepscool = pd.np.round(details_df_excdeps['Hours'].sum()/len(details_df_excdeps),0)


    # In[41]:

    len(details_df_excdeps)


    # In[42]:

    details_df_excdeps.rename(columns={'DOCKNO':'CON','ACTUWT':'Wt'},inplace=True)


    # In[43]:

    pivot_excdeps=pd.pivot_table(details_df_excdeps,index=['HUBLOC'],values=['Hours','CON','Wt'],aggfunc={'Hours':pd.np.mean,'CON':len,'Wt':sum}).reset_index()


    # In[44]:

    pivot_excdeps.head()


    # In[45]:

    pivot_excdeps['Hours']=pd.np.round(pivot_excdeps['Hours'],0)


    # In[46]:

    pivot1_excdeps=pd.merge(pivot1_excdeps,pivot_excdeps,on='HUBLOC')


    # In[47]:

    pivot1_excdeps.rename(columns={'CON':'CON_CLOSING','Hours':'Cooling','Wt':'Wt_CLOSING'},inplace=True)


    # In[48]:

    pivot2_excdeps=pivot1_excdeps[['HUBLOC','Cooling','CON_INCOMING','CON_OPENING','CON_OUTGOING','CON_CLOSING','CON_PERF%','Wt_INCOMING','Wt_OPENING','Wt_OUTGOING','Wt_CLOSING','Wt_PERF%']]

    pivot2_excdeps['Wt_CLOSING']=pd.np.round(pivot2_excdeps['Wt_CLOSING']/1000.0,0)

    exdepscon_cls = pivot2_excdeps['CON_CLOSING'].sum()
    exdepswt_cls = pivot2_excdeps['Wt_CLOSING'].sum()
    # In[49]:


    ## Adding totals
    sumlist2 = ['ALL',excldepscool,ovllinc_con,ovllopn_con,ovllout_con,exdepscon_cls,ovllperf_con,ovllinc_wt,ovllopn_wt,ovllout_wt,exdepscon_cls,ovllperf_wt]
    col_list2 = ['HUBLOC','Cooling','CON_INCOMING','CON_OPENING','CON_OUTGOING','CON_CLOSING','CON_PERF%','Wt_INCOMING','Wt_OPENING','Wt_OUTGOING','Wt_CLOSING','Wt_PERF%']
    totalsdf2 = pd.DataFrame(data=[sumlist2], columns = col_list2)
    pivot2_excdeps = pivot2_excdeps.append(totalsdf2,ignore_index=True)


    df1colslist = pivot1.columns.tolist()
    df2colslist = pivot2_excdeps.columns.tolist()
    pivot1=pivot1.fillna(0)
    pivot2_excdeps=pivot2_excdeps.fillna(0)
    for i in df1colslist:
        if i=='HUBLOC':
            pass
        else:
            pivot1[i] = pivot1[i].astype(int)

    for i in df2colslist:
        if i=='HUBLOC':
            pass
        else:
            pivot2_excdeps[i] = pivot2_excdeps[i].astype(int)


    # In[51]:

    reportts = datetime.now()
    opfilevar=reportts.date()
    opfilevar1=reportts.time()
    ct2= str (opfilevar1)
    currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60
    opfilevar2=np.round((float(currhrs)/60),0)


    # In[53]:
    ## Vishwas Edit for adding cons with DEPS status for Sopan
    details_df_deps = details_df[details_df['Is Deps']==True]
    details_df_deps.to_csv(r'D:\Data\Hub Performance\Hub_Perfor_DEPS_condata_'+str(opfilevar)+"-"+str(opfilevar2)+'.csv')
    details_df_deps.to_csv(r'D:\Data\Hub Performance\Hub_Perfor_DEPS_condata.csv')


    details_df_false=details_df[details_df['Is Deps']==False]
    details_df_false.to_csv(r'D:\Data\Hub Performance\Hub_Perfor_Data_'+str(opfilevar)+"-"+str(opfilevar2)+'.csv')
    pivot1.to_csv(r'D:\Data\Hub Performance\Summary_With_Deps'+str(opfilevar)+"-"+str(opfilevar2)+'.csv')
    pivot2_excdeps.to_csv(r'D:\Data\Hub Performance\Summary_Without_Deps'+str(opfilevar)+"-"+str(opfilevar2)+'.csv')

    pivot1.to_csv(r'D:\Data\Hub Performance\Summary_With_Deps.csv')
    pivot2_excdeps.to_csv(r'D:\Data\Hub Performance\Summary_Without_Deps.csv')

    # In[54]:

    details_df_false.to_csv(r'D:\Data\Hub Performance\Hub_Perfor_Data.csv')


    # In[55]:

    filepath=r'D:\Data\Hub Performance\Hub_Perfor_Data.csv'
    filepath1=r'D:\Data\Hub Performance\Summary_With_Deps.csv'
    filepath2=r'D:\Data\Hub Performance\Summary_Without_Deps.csv'
    filepath3=r'D:\Data\Hub Performance\Hub_Perfor_DEPS_condata.csv'

    # In[56]:


    print ('Logging in...')
    ftp = ftplib.FTP()
    ftp.connect('10.109.230.50')
    print (ftp.getwelcome())
    try:
        try:
            ftp.login('IEPROJECTUSER', 'spotStar@123')
            ftp.cwd('ETA')
            # move to the desired upload directory
            print ("Currently in:", ftp.pwd())
            print ('Uploading...')
            fullname = filepath
            name = os.path.split(fullname)[1]
            f = open(fullname, "rb")
            ftp.storbinary('STOR ' + name, f)
            f.close()
            print ("OK"  )
            print ("Files:")
            print (ftp.retrlines('LIST'))
        finally:
            print ("Quitting...")
            ftp.quit()
    except:
        traceback.print_exc()


    print ('Logging in...')
    ftp = ftplib.FTP()
    ftp.connect('10.109.230.50')
    print (ftp.getwelcome())
    try:
        try:
            ftp.login('IEPROJECTUSER', 'spotStar@123')
            ftp.cwd('ETA')
            # move to the desired upload directory
            print ("Currently in:", ftp.pwd())
            print ('Uploading...')
            fullname = filepath3
            name = os.path.split(fullname)[1]
            f = open(fullname, "rb")
            ftp.storbinary('STOR ' + name, f)
            f.close()
            print ("OK"  )
            print ("Files:")
            print (ftp.retrlines('LIST'))
        finally:
            print ("Quitting...")
            ftp.quit()
    except:
        traceback.print_exc()    


    # In[52]:
    TO=['sharanagouda.biradar@spoton.co.in','prasad.sanka@spoton.co.in','jai.prakash@spoton.co.in','yogesh.singh@spoton.co.in','suresh.d@spoton.co.in','ashok.dwivedi@spoton.co.in','awadh.narayan@spoton.co.in','ashwani.gangwar@spoton.co.in','lingaraj.chidambaram@spoton.co.in','sachidanand.pandey@spoton.co.in','suresh.kp@spoton.co.in','pramod.kumar@spoton.co.in','hintendrakumar.prusty@spoton.co.in','rom_spot@spoton.co.in','dom_spot@spoton.co.in','HUBMGR_SPOT@spoton.co.in','onkar.sharma@spoton.co.in','sopanrao.bhoite@spoton.co.in','singh.vijay@spoton.co.in','Rajnish.pathak@spoton.co.in','pinkesh.sharma@spoton.co.in','amit.mishra1@spoton.co.in','aditya.shekhar@spoton.co.in','pandurangkrushna.patil@spoton.co.in','mangesh.gaikwad@spoton.co.in','k.thanigachalam@spoton.co.in','lingaraj.chidambaram@spoton.co.in','suresh.kp@spoton.co.in','anoop.kumar@spoton.co.in','avnish.tripathi@spoton.co.in']
    # TO=['vishwas.j@spoton.co.in','prasanna.hegde@spoton.co.in']
    # TO=['mahesh.reddy@spoton.co.in']
    CC=['pawan.sharma@spoton.co.in','abhik.mitra@spoton.co.in','jothi.menon@spoton.co.in']
    # CC=['vishwas.j@spoton.co.in','prasanna.hegde@spoton.co.in','mahesh.reddy@spoton.co.in']
    # CC=['mahesh.reddy@spoton.co.in']
    BCC=['shivananda.p@spoton.co.in','prasanna.hegde@spoton.co.in','mahesh.reddy@spoton.co.in','vineet.vikram@spoton.co.in','sq_spot@spoton.co.in','sanjana.narayana@spoton.co.in']
    # BCC=['vishwas.j@spoton.co.in','prasanna.hegde@spoton.co.in','mahesh.reddy@spoton.co.in']
    # BCC=['mahesh.reddy@spoton.co.in']
    FROM="reports.ie@spoton.co.in"
    msg = MIMEMultipart()
    msg["From"] = FROM
    msg["To"] = ",".join(TO)
    msg["CC"] = ",".join(CC)
    msg["BCC"] = ",".join(BCC)
    #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
    msg["Subject"] = "Hub Performance " + '- ' + str(opfilevar)+str('-')+ str(opfilevar2)
    html3='''
    <h5> To download the data , Please click the link below </h5>
    <p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Hub_Perfor_Data.csv"</a>http://spoton.co.in/downloads/IEProjects/ETA/Hub_Perfor_Data.csv</p></b>

    <h5> To download the condata of DEPS/excluded cons , Please click the link below </h5>
    <p><a href= "http://spoton.co.in/downloads/IEProjects/ETA/Hub_Perfor_DEPS_condata.csv"</a>http://spoton.co.in/downloads/IEProjects/ETA/Hub_Perfor_DEPS_condata.csv</p></b>

    '''
    report=""
    report+='Dear All,'
    report+='<br>'
    report+='<br>'
    report+='PFA Hub Performance'
    report+='<br>'
    report+='<br>'
    report+='<br>'+pivot1.to_html()+'<br>'
    report+='<br>'
    report+='<br>'
    report+='<br>'+pivot2_excdeps.to_html()+'<br>'
    report+='<br>'
    report+='<br>'
    report+=html3
    abc=MIMEText(report,'html')
    msg.attach(abc)

    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(filepath1,"rb").read() )
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
    msg.attach(part)

    part2 = MIMEBase('application', "octet-stream")
    part2.set_payload( open(filepath2,"rb").read() )
    encoders.encode_base64(part2)
    part2.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath2))
    msg.attach(part2)



    server=smtplib.SMTP('smtp.sendgrid.net', 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    # server.login("spoton.net.in", "Star@123#")
    server.login('spoton.net.in', 'Star@123#')
    failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
    server.quit()

except:
  TO=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  #msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "ERROR Report" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in Hub Performance'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO, msg.as_string())
  server.quit()


# In[ ]:



