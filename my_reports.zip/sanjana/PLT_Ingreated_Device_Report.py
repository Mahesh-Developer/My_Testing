
# coding: utf-8

# In[1]:


#from Networkmeeting_Reach import lhplanning
import numpy as np
import pandas as pd
import pyodbc
from IPython import display
from datetime import datetime
from datetime import datetime,timedelta
from datetime import datetime, timedelta
import smtplib
import ftplib
import traceback
import calendar
import os


# In[2]:


# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


# In[3]:


enddate=datetime.strftime(datetime.now(),'%Y-%m-%d')
enddate1=enddate+' 23:59:00'
enddate,enddate1


# In[4]:


startdate=datetime.strftime(datetime.now()-timedelta(days=1),'%Y-%m-%d')
startdate1=startdate+' 23:59:00'
startdate,startdate1


# In[5]:


lastdate=datetime.strftime(datetime.now()-timedelta(days=2),'%Y-%m-%d')
lastdate


# In[6]:


blrh_query=("""select sheetno,case when SheetNo like '%blrh%' then 'LOADING' else 'UNLOADING' END [LOADING STATUS],sum(con_count) conncount,sum(pcs_count) pcscount,sccode,min(starttime) starttime,max(endtime) endtime  from
(select sheetno, count(conno) con_count,sum(pcs) pcs_count ,sccode,starttime,endtime from (
select SheetNo, ConNo,count(pcsno) pcs,min(pd.scanTime) starttime,max(pd.scanTime) endtime,ph.SCCode
from tblPLTAPIPcsDtls pd with(nolock) join tblPLTAPIHDR ph with(nolock) on pd.plthdrid=ph.AutoID where ph.SCCode='blrh' and   ph.RequestDate between '2019-02-16 00:00:00' and '{0}'
group by SheetNo,conno,SCCode) a
group by SheetNo,SCCode,starttime,endtime)ab 
group by sheetno,SCCode,case when SheetNo like '%blrh%' then 'LOADING' else 'UNLOADING' END
""").format(startdate1)


# In[7]:


blrh_df=pd.read_sql(blrh_query,Utilities.cnxn)


# In[8]:


len(blrh_df)


# In[9]:


blrh_df['Date']=blrh_df['starttime'].dt.date


# In[10]:


blrh_df['Type']='2019-02-16/'+startdate


# In[11]:


blrh_df=blrh_df[~blrh_df['endtime'].isnull()]
len(blrh_df)


# In[12]:


blrh_df=blrh_df[~blrh_df['starttime'].isnull()]
len(blrh_df)


# In[13]:


blrh_df['Date']=blrh_df['Date'].astype(str)


# In[14]:


blrh_df['Diff_in_Sec']=(blrh_df['endtime']-blrh_df['starttime']).dt.seconds


# In[15]:


blrh_df['Sec/pc']=pd.np.round(blrh_df['Diff_in_Sec']/blrh_df['pcscount'],0)


# In[16]:


blrh_df=blrh_df[(blrh_df['Sec/pc']>1.0) & (blrh_df['Sec/pc']<=50.0)]
len(blrh_df)


# In[17]:


blrh_df['Max_Sec/pc']=blrh_df['Sec/pc']


# In[18]:


blrh_df['Min_Sec/pc']=blrh_df['Sec/pc']


# In[19]:


# blrh_df.loc[(blrh_df['starttime']==startdate),'TYPE']=='YST'
yblrh_df=blrh_df[blrh_df['Date']<=lastdate]
len(yblrh_df)


# In[20]:


yblrh_df['Type']='2019-02-16/'+lastdate


# In[21]:


b2=blrh_df.pivot_table(index=['sccode','LOADING STATUS'],columns=['Type'],aggfunc={'pcscount':sum,'sheetno':len,'Sec/pc':pd.np.mean})


# In[22]:


b2.swaplevel(i=-2,j=-1,axis=1)


# In[ ]:


# yblrh_df.pivot_table(index=['sccode','LOADING STATUS'],columns=['Type'],aggfunc={'pcscount':sum,'sheetno':len,'Sec/pc':pd.np.mean})


# In[23]:


pnqh_query=("""select sheetno,case when SheetNo like '%pnqh%' then 'LOADING' else 'UNLOADING' END [LOADING STATUS],sum(con_count) conncount,sum(pcs_count) pcscount,sccode,min(starttime) starttime,max(endtime) endtime  from
(select sheetno, count(conno) con_count,sum(pcs) pcs_count ,sccode,starttime,endtime from (
select SheetNo, ConNo,count(pcsno) pcs,min(pd.scanTime) starttime,max(pd.scanTime) endtime,ph.SCCode
from tblPLTAPIPcsDtls pd with(nolock) join tblPLTAPIHDR ph with(nolock) on pd.plthdrid=ph.AutoID where ph.SCCode='pnqh' and   ph.RequestDate between '2019-02-16 00:00:00' and '{0}'
group by SheetNo,conno,SCCode) a
group by SheetNo,SCCode,starttime,endtime)ab 
group by sheetno,SCCode,case when SheetNo like '%pnqh%' then 'LOADING' else 'UNLOADING' END
""").format(startdate1)


# In[24]:


pnqh_df=pd.read_sql(pnqh_query,Utilities.cnxn)


# In[25]:


len(pnqh_df)


# In[26]:


pnqh_df=pnqh_df[~pnqh_df['endtime'].isnull()]
#len(pnqh_df)
pnqh_df=pnqh_df[~pnqh_df['starttime'].isnull()]
len(pnqh_df)


# In[27]:


pnqh_df['Date']=pnqh_df['starttime'].dt.date
pnqh_df['Date']=pnqh_df['Date'].astype(str)


# In[28]:


# pnqh_df['Type']='MTD'
pnqh_df['Type']='2019-02-16/'+startdate


# In[29]:


pnqh_df['Diff_in_Sec']=(pnqh_df['endtime']-pnqh_df['starttime']).dt.seconds
pnqh_df['Sec/pc']=pd.np.round(pnqh_df['Diff_in_Sec']/pnqh_df['pcscount'],0)


# In[30]:


pnqh_df=pnqh_df[(pnqh_df['Sec/pc']>1.0) & (pnqh_df['Sec/pc']<=50.0)]
len(pnqh_df)


# In[31]:


pnqh_df['Max_Sec/pc']=pnqh_df['Sec/pc']
pnqh_df['Min_Sec/pc']=pnqh_df['Sec/pc']


# In[32]:


ypnqh_df=pnqh_df[pnqh_df['Date']<=lastdate]
len(ypnqh_df)


# In[33]:


ypnqh_df['Type']='2019-02-16/'+lastdate


# In[ ]:


#pnqh_df.pivot_table(index=['sccode','LOADING STATUS'],columns=['Type'],aggfunc={'pcscount':sum,'sheetno':len,'Sec/pc':pd.np.mean})


# In[ ]:


#ypnqh_df.pivot_table(index=['sccode','LOADING STATUS'],columns=['Type'],aggfunc={'pcscount':sum,'sheetno':len,'Sec/pc':pd.np.mean,'Min_Sec/pc':pd.np.min,'Max_Sec/pc':pd.np.max})


# In[34]:


delh_query=("""select sheetno,case when SheetNo like '%delh%' then 'LOADING' else 'UNLOADING' END [LOADING STATUS],sum(con_count) conncount,sum(pcs_count) pcscount,sccode,min(starttime) starttime,max(endtime) endtime  from
(select sheetno, count(conno) con_count,sum(pcs) pcs_count ,sccode,starttime,endtime from (
select SheetNo, ConNo,count(pcsno) pcs,min(pd.scanTime) starttime,max(pd.scanTime) endtime,ph.SCCode
from tblPLTAPIPcsDtls pd with(nolock) join tblPLTAPIHDR ph with(nolock) on pd.plthdrid=ph.AutoID where ph.SCCode='delh' and   ph.RequestDate between '2019-02-16 00:00:00' and '{0}'
group by SheetNo,conno,SCCode) a
group by SheetNo,SCCode,starttime,endtime)ab 
group by sheetno,SCCode,case when SheetNo like '%delh%' then 'LOADING' else 'UNLOADING' END
""").format(startdate1)


# In[35]:


delh_df=pd.read_sql(delh_query,Utilities.cnxn)
len(delh_df)


# In[36]:


delh_df=delh_df[~delh_df['endtime'].isnull()]
delh_df=delh_df[~delh_df['starttime'].isnull()]
len(delh_df)


# In[37]:


delh_df['Date']=delh_df['starttime'].dt.date
delh_df['Date']=delh_df['Date'].astype(str)


# In[38]:


delh_df['Type']='2019-02-16/'+startdate


# In[39]:


delh_df['Diff_in_Sec']=(delh_df['endtime']-delh_df['starttime']).dt.seconds
delh_df['Sec/pc']=pd.np.round(delh_df['Diff_in_Sec']/delh_df['pcscount'],0)


# In[40]:


delh_df=delh_df[(delh_df['Sec/pc']>1.0) & (delh_df['Sec/pc']<=50.0)]
len(delh_df)


# In[41]:


delh_df['Max_Sec/pc']=delh_df['Sec/pc']
delh_df['Min_Sec/pc']=delh_df['Sec/pc']


# In[42]:


ydelh_df=delh_df[delh_df['Date']<=lastdate]
len(ydelh_df)
# ydelh_df['Type']='YST'


# In[43]:


ydelh_df['Type']='2019-02-16/'+lastdate


# In[ ]:


# delh_df.pivot_table(index=['sccode','LOADING STATUS'],columns=['Type'],aggfunc={'pcscount':sum,'sheetno':len,'Sec/pc':pd.np.mean})


# In[ ]:


# ydelh_df.pivot_table(index=['sccode','LOADING STATUS'],columns=['Type'],aggfunc={'pcscount':sum,'sheetno':len,'Sec/pc':pd.np.mean})


# In[44]:


bomh_query=("""select sheetno,case when SheetNo like '%bomh%' then 'LOADING' else 'UNLOADING' END [LOADING STATUS],sum(con_count) conncount,sum(pcs_count) pcscount,sccode,min(starttime) starttime,max(endtime) endtime  from
(select sheetno, count(conno) con_count,sum(pcs) pcs_count ,sccode,starttime,endtime from (
select SheetNo, ConNo,count(pcsno) pcs,min(pd.scanTime) starttime,max(pd.scanTime) endtime,ph.SCCode
from tblPLTAPIPcsDtls pd with(nolock) join tblPLTAPIHDR ph with(nolock) on pd.plthdrid=ph.AutoID where ph.SCCode='bomh' and   ph.RequestDate between '2019-02-16 00:00:00' and '{0}'
group by SheetNo,conno,SCCode) a
group by SheetNo,SCCode,starttime,endtime)ab 
group by sheetno,SCCode,case when SheetNo like '%bomh%' then 'LOADING' else 'UNLOADING' END
""").format(startdate1)


# In[45]:


bomh_df=pd.read_sql(bomh_query,Utilities.cnxn)
len(bomh_df)


# In[46]:


bomh_df=bomh_df[~bomh_df['endtime'].isnull()]
bomh_df=bomh_df[~bomh_df['starttime'].isnull()]
len(bomh_df)


# In[47]:


bomh_df['Date']=bomh_df['starttime'].dt.date
bomh_df['Date']=bomh_df['Date'].astype(str)


# In[48]:


bomh_df['Type']='2019-02-16/'+startdate


# In[49]:


bomh_df['Diff_in_Sec']=(bomh_df['endtime']-bomh_df['starttime']).dt.seconds
bomh_df['Sec/pc']=pd.np.round(bomh_df['Diff_in_Sec']/bomh_df['pcscount'],0)


# In[50]:


bomh_df=bomh_df[(bomh_df['Sec/pc']>1.0) & (bomh_df['Sec/pc']<=50.0)]
len(bomh_df)


# In[51]:


bomh_df['Max_Sec/pc']=bomh_df['Sec/pc']
bomh_df['Min_Sec/pc']=bomh_df['Sec/pc']


# In[52]:


ybomh_df=bomh_df[bomh_df['Date']<=lastdate]
len(ybomh_df)
# ybomh_df['Type']='YST'


# In[53]:


ybomh_df['Type']='2019-02-16/'+lastdate


# In[ ]:


# bomh_df.pivot_table(index=['sccode','LOADING STATUS'],columns=['Type'],aggfunc={'pcscount':sum,'sheetno':len,'Sec/pc':pd.np.mean})


# In[ ]:


# ybomh_df.pivot_table(index=['sccode','LOADING STATUS'],columns=['Type'],aggfunc={'pcscount':sum,'sheetno':len,'Sec/pc':pd.np.mean})


# In[54]:


final_df=pd.concat([blrh_df,pnqh_df,delh_df,bomh_df],ignore_index=True)


# In[55]:


len(final_df)


# In[56]:


final_summary=final_df.pivot_table(index=['sccode','LOADING STATUS'],columns=['Type'],aggfunc={'pcscount':sum,'sheetno':len,'Sec/pc':pd.np.mean})


# In[57]:


# final_summary.round({"Sec/pc":1,})
final_summary['Sec/pc']=pd.np.round(final_summary['Sec/pc'],0)


# In[58]:


final_summary=final_summary.swaplevel(i=-2,j=-1,axis=1)


# In[59]:


final_summary


# In[60]:


yfinal_df=pd.concat([yblrh_df,ybomh_df,ydelh_df,ypnqh_df],ignore_index=True)


# In[61]:


yfinal_summary=yfinal_df.pivot_table(index=['sccode','LOADING STATUS'],columns=['Type'],aggfunc={'pcscount':sum,'sheetno':len,'Sec/pc':pd.np.mean})


# In[62]:


yfinal_summary


# In[63]:


yfinal_summary=yfinal_summary.swaplevel(i=-2,j=-1,axis=1)


# In[64]:


yfinal_summary


# In[65]:


summary=pd.merge(yfinal_summary,final_summary,left_index=True,right_index=True,how='outer')


# In[66]:


summary


# In[ ]:


# depotdftots = final_summary.groupby(level='sccode').sum()
# depotdftots.index = [depotdftots.index, ['total'] * len(depotdftots)]
# depotpivot = np.round(pd.concat([final_summary,depotdftots]).sort_index().append(final_summary.sum().rename(('Grand', 'Total'))),2)


# ## Month Range

# In[67]:


st1='2018-07-01 00:00:00'
st2='2018-12-31 23:59:00'


# In[68]:


blrh_query1=("""select sheetno,case when SheetNo like '%blrh%' then 'LOADING' else 'UNLOADING' END [LOADING STATUS],sum(con_count) conncount,sum(pcs_count) pcscount,sccode,min(starttime) starttime,max(endtime) endtime  from
(select sheetno, count(conno) con_count,sum(pcs) pcs_count ,sccode,starttime,endtime from (
select SheetNo, ConNo,count(pcsno) pcs,min(pd.scanTime) starttime,max(pd.scanTime) endtime,ph.SCCode
from tblPLTAPIPcsDtls pd with(nolock) join tblPLTAPIHDR ph with(nolock) on pd.plthdrid=ph.AutoID where ph.SCCode='blrh' and   ph.RequestDate between '{0}' and '{1}'
group by SheetNo,conno,SCCode) a
group by SheetNo,SCCode,starttime,endtime)ab 
group by sheetno,SCCode,case when SheetNo like '%blrh%' then 'LOADING' else 'UNLOADING' END
""").format(st1,st2)


# In[69]:


mblrh_df=pd.read_sql(blrh_query1,Utilities.cnxn)


# In[70]:


len(mblrh_df)


# In[71]:


mblrh_df=mblrh_df[~mblrh_df['endtime'].isnull()]
mblrh_df=mblrh_df[~mblrh_df['starttime'].isnull()]
len(mblrh_df)


# In[72]:


mblrh_df['Diff_in_Sec']=(mblrh_df['endtime']-mblrh_df['starttime']).dt.seconds
mblrh_df['Sec/pc']=pd.np.round(mblrh_df['Diff_in_Sec']/mblrh_df['pcscount'],0)


# In[73]:


mblrh_df=mblrh_df[(mblrh_df['Sec/pc']>1.0) & (mblrh_df['Sec/pc']<=50.0)]
len(mblrh_df)


# In[74]:


mblrh_df['Max_Sec/pc']=mblrh_df['Sec/pc']
mblrh_df['Min_Sec/pc']=mblrh_df['Sec/pc']


# In[75]:


mblrh_df['Type']='Non-Integrated Device(6 months)'


# In[76]:


pnqh_query1=("""select sheetno,case when SheetNo like '%pnqh%' then 'LOADING' else 'UNLOADING' END [LOADING STATUS],sum(con_count) conncount,sum(pcs_count) pcscount,sccode,min(starttime) starttime,max(endtime) endtime  from
(select sheetno, count(conno) con_count,sum(pcs) pcs_count ,sccode,starttime,endtime from (
select SheetNo, ConNo,count(pcsno) pcs,min(pd.scanTime) starttime,max(pd.scanTime) endtime,ph.SCCode
from tblPLTAPIPcsDtls pd with(nolock) join tblPLTAPIHDR ph with(nolock) on pd.plthdrid=ph.AutoID where ph.SCCode='pnqh' and   ph.RequestDate between '{0}' and '{1}'
group by SheetNo,conno,SCCode) a
group by SheetNo,SCCode,starttime,endtime)ab 
group by sheetno,SCCode,case when SheetNo like '%pnqh%' then 'LOADING' else 'UNLOADING' END
""").format(st1,st2)


# In[77]:


mpnqh_df=pd.read_sql(pnqh_query1,Utilities.cnxn)
len(mpnqh_df)


# In[78]:


mpnqh_df=mpnqh_df[~mpnqh_df['endtime'].isnull()]
mpnqh_df=mpnqh_df[~mpnqh_df['starttime'].isnull()]
len(mpnqh_df)


# In[79]:


mpnqh_df['Diff_in_Sec']=(mpnqh_df['endtime']-mpnqh_df['starttime']).dt.seconds
mpnqh_df['Sec/pc']=pd.np.round(mpnqh_df['Diff_in_Sec']/mpnqh_df['pcscount'],0)


# In[80]:


mpnqh_df=mpnqh_df[(mpnqh_df['Sec/pc']>1.0) & (mpnqh_df['Sec/pc']<=50.0)]
len(mpnqh_df)


# In[81]:


mpnqh_df['Max_Sec/pc']=mpnqh_df['Sec/pc']
mpnqh_df['Min_Sec/pc']=mpnqh_df['Sec/pc']


# In[82]:


mpnqh_df['Type']='Non-Integrated Device(6 months)'


# In[83]:


delh_query1=("""select sheetno,case when SheetNo like '%delh%' then 'LOADING' else 'UNLOADING' END [LOADING STATUS],sum(con_count) conncount,sum(pcs_count) pcscount,sccode,min(starttime) starttime,max(endtime) endtime  from
(select sheetno, count(conno) con_count,sum(pcs) pcs_count ,sccode,starttime,endtime from (
select SheetNo, ConNo,count(pcsno) pcs,min(pd.scanTime) starttime,max(pd.scanTime) endtime,ph.SCCode
from tblPLTAPIPcsDtls pd with(nolock) join tblPLTAPIHDR ph with(nolock) on pd.plthdrid=ph.AutoID where ph.SCCode='delh' and   ph.RequestDate between '{0}' and '{1}'
group by SheetNo,conno,SCCode) a
group by SheetNo,SCCode,starttime,endtime)ab 
group by sheetno,SCCode,case when SheetNo like '%delh%' then 'LOADING' else 'UNLOADING' END
""").format(st1,st2)


# In[84]:


mdelh_df=pd.read_sql(delh_query1,Utilities.cnxn)
len(mdelh_df)


# In[85]:


mdelh_df=mdelh_df[~mdelh_df['endtime'].isnull()]
mdelh_df=mdelh_df[~mdelh_df['starttime'].isnull()]
len(mdelh_df)


# In[86]:


mdelh_df['Diff_in_Sec']=(mdelh_df['endtime']-mdelh_df['starttime']).dt.seconds
mdelh_df['Sec/pc']=pd.np.round(mdelh_df['Diff_in_Sec']/mdelh_df['pcscount'],0)


# In[87]:


mdelh_df=mdelh_df[(mdelh_df['Sec/pc']>1.0) & (mdelh_df['Sec/pc']<=50.0)]
len(mdelh_df)


# In[88]:


mdelh_df['Max_Sec/pc']=mdelh_df['Sec/pc']
mdelh_df['Min_Sec/pc']=mdelh_df['Sec/pc']


# In[89]:


mdelh_df['Type']='Non-Integrated Device(6 months)'


# In[90]:


bomh_query1=("""select sheetno,case when SheetNo like '%bomh%' then 'LOADING' else 'UNLOADING' END [LOADING STATUS],sum(con_count) conncount,sum(pcs_count) pcscount,sccode,min(starttime) starttime,max(endtime) endtime  from
(select sheetno, count(conno) con_count,sum(pcs) pcs_count ,sccode,starttime,endtime from (
select SheetNo, ConNo,count(pcsno) pcs,min(pd.scanTime) starttime,max(pd.scanTime) endtime,ph.SCCode
from tblPLTAPIPcsDtls pd with(nolock) join tblPLTAPIHDR ph with(nolock) on pd.plthdrid=ph.AutoID where ph.SCCode='bomh' and   ph.RequestDate between '{0}' and '{1}'
group by SheetNo,conno,SCCode) a
group by SheetNo,SCCode,starttime,endtime)ab 
group by sheetno,SCCode,case when SheetNo like '%bomh%' then 'LOADING' else 'UNLOADING' END
""").format(st1,st2)


# In[91]:


mbomh_df=pd.read_sql(bomh_query1,Utilities.cnxn)
len(mbomh_df)


# In[92]:


mbomh_df=mbomh_df[~mbomh_df['endtime'].isnull()]
mbomh_df=mbomh_df[~mbomh_df['starttime'].isnull()]
len(mbomh_df)


# In[93]:


mbomh_df['Diff_in_Sec']=(mbomh_df['endtime']-mbomh_df['starttime']).dt.seconds
mbomh_df['Sec/pc']=pd.np.round(mbomh_df['Diff_in_Sec']/mbomh_df['pcscount'],0)


# In[94]:


mbomh_df=mbomh_df[(mbomh_df['Sec/pc']>1.0) & (mbomh_df['Sec/pc']<=50.0)]
len(mbomh_df)


# In[95]:


mbomh_df['Max_Sec/pc']=mbomh_df['Sec/pc']
mbomh_df['Min_Sec/pc']=mbomh_df['Sec/pc']


# In[96]:


mbomh_df['Type']='Non-Integrated Device(6 months)'


# In[97]:


f2=pd.concat([mblrh_df,mdelh_df,mbomh_df,mpnqh_df],ignore_index=True)


# In[98]:


len(f2)


# In[99]:


f2_summary=f2.pivot_table(index=['sccode','LOADING STATUS'],columns=['Type'],aggfunc={'pcscount':sum,'sheetno':len,'Sec/pc':pd.np.mean})


# In[100]:


f2_summary=f2_summary.swaplevel(i=-2,j=-1,axis=1)


# In[101]:


final_main_summary=pd.merge(f2_summary,summary,left_index=True,right_index=True,how='outer')


# In[102]:


final_main_summary=pd.np.round(final_main_summary,0)


# In[103]:


final_main_summary


# In[104]:


final_main_summary['Integrated','YST_Variance']=final_main_summary['Non-Integrated Device(6 months)','Sec/pc']-final_main_summary['2019-02-16/'+lastdate,'Sec/pc']
final_main_summary['Integrated','Today_Variance']=final_main_summary['Non-Integrated Device(6 months)','Sec/pc']-final_main_summary['2019-02-16/'+startdate,'Sec/pc']


# In[105]:


final_main_summary


# In[ ]:


todate=datetime.strftime(datetime.now(),'%Y-%m-%d')
todate


# In[ ]:


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template

#TO=['abhishek.cv@spoton.co.in']
#CC=['mahesh.reddy@spoton.co.in']
FROM="reports.ie@spoton.co.in"
TO=['abhik.mitra@spoton.co.in','pawan.sharma@spoton.co.in','abhishek.cv@spoton.co.in','ashwani.gangwar@spoton.co.in','']
CC=['ramachandran.p@spoton.co.in','satya.pal@spoton.co.in','rajnish.pathak@spoton.co.in','sopanrao.bhoite@spoton.co.in','krishna.kumar.bhardwaj@spoton.co.in','alok.b@spoton.co.in','mahesh.reddy@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
#msg["BCC"] = ",".join(BCC)
msg["Subject"] = "PLT Integrated Device Report" + " : " + todate
html='''<html>
<style>
p
{
  margin:0;
  margin-top: 5px;
  padding:0;
  font-size:17px;
    line-height:20px;
}
</style>
<h3>Dear All,</h3>
<p>Please Find POD's Summary.</p>
</html>'''


s = Template(html).safe_substitute()
report=""
#report+=s
#report+='<br>'+final_dff5.to_html()+'<br>'
report+='Dear All,'
report+='<br>'
report+='<br>'
report+='Please Find attached Integrated Device Summary:'
report+='<br>'
report+='<br>'
report+='<br>'+final_main_summary.to_html()+'<br>'
report+='<br>'
report+='<br>'

# html5='''
# <h5> To download the data , Please click the link below </h5>
# <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Undel_Management_Data.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Undel_Management_Data.csv</p></b>
# <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Over_All_Summary.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Over_All_Summary.csv</p></b>
# <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Special_Cust_Summary.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Special_Cust_Summary.csv</p></b>
# <p><a href= "http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Other_Cust_Summary.csv"</a>http://www.spoton.co.in/downloads/HOSQTeam/Auto_reports/Other_Cust_Summary.csv</p></b>

#     '''
# report+=html5
abc=MIMEText(report,'html')
msg.attach(abc)
# part = MIMEBase('application', "octet-stream")
# part.set_payload( open(filePath,"rb").read() )
# encoders.encode_base64(part)
# part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
# msg.attach(part)
# part1 = MIMEBase('application', "octet-stream")
# part1.set_payload( open(filePath1,"rb").read() )
# encoders.encode_base64(part1)
# part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath1))
# msg.attach(part1)

server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC, msg.as_string())
server.quit()


# In[ ]:


exit(0)

