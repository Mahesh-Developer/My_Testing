
# coding: utf-8

# In[ ]:


import pandas as pd
from datetime import datetime, timedelta
import numpy as np
from sqlalchemy import *
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
# from email.MIMEBase import MIMEBase
# from email import Encoders
from email.mime.base import MIMEBase
from email import encoders
import os
from string import Template
import pyodbc
import Utilities

# In[ ]:

#try:
cnxn1 = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=PYTHON_DB;UID=PythonOnline;PWD=P@ssw0rd123$")
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()


# In[ ]:


query=("""SELECT  TC.thcno AS ThcNo ,
      CASE WHEN ISNULL(vs.SourceCode, '') = '' THEN TC.sourcehb
           ELSE vs.SourceCode
      END THC_SOURCE ,
      CASE WHEN ISNULL(vs.DestinationCode, '') = '' THEN TC.tobh_code
           ELSE vs.DestinationCode
      END THC_DEST ,
      TC.routety ,
      CASE WHEN TC.routety = 'D' THEN GETDATE()
           ELSE dbo.UFN_GET_THC_ARRCTIME_ASPER_GPS_CNM_NEW(TC.thcno, NULL)
      END AS ArrivalTime_ASPER_GPS_CNM ,
      CAST(CONVERT(VARCHAR, hd2.actarrv_dt, 112) + ' ' + hd2.actarrv_tm AS SMALLDATETIME) Arrivaltime ,
      TR.TCHDRFLAG ,
      CASE WHEN hd2.tobh_code IS NULL THEN 'Y'
           WHEN hd2.tobh_code = 'Null' THEN 'Y'
           ELSE 'N'
      END AlreadyArrived ,
      SUM(pd.pcs_actuwt) AS ld_actuwt ,
      COUNT(PC.PcsNo) TOTPCS ,
      TC.routename ,
      TR.TCNO ,
      TR.ToBH_CODE,
            td.FinalSubmitDate    'FinalSubmission'
FROM    THCHDR TC WITH ( NOLOCK )
      LEFT OUTER JOIN tbl_VehicleRunningStatus_New vs WITH ( NOLOCK ) ON vs.ThcNo = TC.thcno
      INNER JOIN THCHDR hd2 WITH ( NOLOCK ) ON TC.thcno = hd2.thcno
                                               AND TC.tobh_code = hd2.sourcehb
      LEFT OUTER JOIN dbo.TCHDR TR WITH ( NOLOCK ) ON TR.THCNO = TC.thcno
                                                      AND TR.ToBH_CODE = hd2.sourcehb
      INNER  JOIN dbo.TCTRN d WITH ( NOLOCK ) ON d.TCNO = TR.TCNO
      INNER JOIN dbo.tblPLTAPIHDR TD WITH ( NOLOCK ) ON TD.SheetNo = hd2.thcno
                                                        AND TD.SCCode = hd2.sourcehb
                                                        AND TD.SheetType = 'UT'
      INNER JOIN dbo.tblPLTAPIPcsDtls PC WITH ( NOLOCK ) ON PC.PLTHDRID = TD.AutoID
                                                            AND d.DOCKNO = PC.ConNo
      INNER JOIN dbo.PCR_PIECES_Detail pd WITH ( NOLOCK ) ON pd.PartNo = PC.PcsNo
                                                            AND pd.Dockno = PC.ConNo
                                                            AND pd.isActive = 1
WHERE   TC.thcdt >= CONVERT(DATE, GETDATE() - 1)
        --  AND TC.tobh_code = 'BLRH'
      AND TC.tobh_code <> 'Null'
      AND TR.TCHDRFLAG = 'Y'
      AND hd2.sourcehb IS NOT NULL -- TO GET ONLY ARRIVED THC's
  --  AND TC.thcno = 'ETBBIHX0005471'
      AND td.FinalSubmitDate IS NULL
    --  AND PC.UpdatedOn IS NULL
      AND hd2.routety <> 'D'
GROUP BY TC.thcno ,
      TC.sourcehb ,
      TC.tobh_code ,
      TC.routety ,
      hd2.actarrv_dt ,
      hd2.actarrv_tm ,
      TR.TCHDRFLAG ,
      hd2.tobh_code ,
      vs.SourceCode ,
      vs.DestinationCode ,
      TC.routename ,
      TR.TCNO ,
      TR.ToBH_CODE,td.FinalSubmitDate """)

# In[ ]:


df=pd.read_sql(query,Utilities.cnxn)
print (len(df))
#print (df.columns)
df=df.pivot_table(index=['ThcNo','THC_SOURCE','THC_DEST','ToBH_CODE','ArrivalTime_ASPER_GPS_CNM','Arrivaltime','routety','AlreadyArrived','routename'],
            values=['ld_actuwt','TOTPCS'],aggfunc={'TOTPCS':sum,'ld_actuwt':sum}).reset_index()
# df['TimeStamp']=datetime.now()
print (df.head())
# df['HOURS']=(df['TimeStamp']-df['Arrivaltime']).astype('timedelta64[h]')



##### Vishwas Edit for diff hours

df.loc[df.index,'CurrentTime'] = datetime.now()

def diffhr(currtime,arrivetime):
  diff = (currtime - arrivetime)
  return pd.np.round(diff.total_seconds()/3600,1)

df['HOURS'] = df.apply(lambda x:diffhr (x['CurrentTime'],x['Arrivaltime']),axis=1)

##### Vishwas Edit for diff hours


df['>3Hrs']=df['HOURS'].apply(lambda x: 1 if x>3 else 0)
# pivot_summary=df.pivot_table(index=['ToBH_CODE'],values=['ld_actuwt','TOTPCS','ThcNo','>3Hrs'],aggfunc={'ld_actuwt':sum,'TOTPCS':sum,'ThcNo':len,'>3Hrs':sum})

pivot_summary=df.pivot_table(index=['ToBH_CODE'],values=['ld_actuwt','TOTPCS','ThcNo','>3Hrs','HOURS'],aggfunc={'ld_actuwt':sum,'TOTPCS':sum,'ThcNo':len,'>3Hrs':sum,'HOURS':sum})
pivot_summary['WtTimeDiff'] = pivot_summary.apply(lambda x:pd.np.round((x['HOURS']/x['ThcNo']),1),axis=1)
# pivot_summary['WtTimeDiff'] = pivot_summary.apply(lambda x:pd.np.round((x['Time_diff']/x['ThcNo']),1),axis=1)
pivot_summary['ld_actuwt(T)']=pd.np.round(pivot_summary['ld_actuwt']/1000.0,2)

from datetime import date,timedelta
todate=date.today()
today_date=datetime.strftime(todate,'%d-%m-%Y')
today_date


pivot_summary=pivot_summary.reset_index()
filepath=r'D:\Data\Vehicle_PileUP_PLT\Data\VehiclePileUp_Data_'+str(today_date)+'.csv'
pivot_summary1=pivot_summary[['ToBH_CODE', 'ThcNo', 'ld_actuwt(T)', 'TOTPCS','WtTimeDiff','>3Hrs']]
filepath1=r'D:\Data\Vehicle_PileUP_PLT\Summary\Summary_'+str(today_date)+'.csv'
df.to_csv(filepath)
pivot_summary1.to_csv(filepath1)


hubmaster=pd.read_sql("select * from hubmaster",cnxn1)
hublist=hubmaster['HUB'].tolist()
hublist.append('NDAH')
hublist.append('COKH')
hub_veh_df=pivot_summary1[pivot_summary1['ToBH_CODE'].isin(hublist)]

sc_veh_df=pivot_summary1[~pivot_summary1['ToBH_CODE'].isin(hublist)]
sc_veh_df=sc_veh_df.sort_values('ThcNo',ascending=False)

hub_veh_df=hub_veh_df.sort_values('ThcNo',ascending=False)

# TO=['vishwas.j@spoton.co.in']
TO=['pawan.sharma@spoton.co.in','ashwani.gangwar@spoton.co.in','prasanna.hegde@spoton.co.in']
   
FROM="reports.ie@spoton.co.in"
CC=['mahesh.reddy@spoton.co.in','abhik.mitra@spoton.co.in','rajesh.kapase@spoton.co.in','saptarshi.pathak@spoton.co.in','satya.pal@spoton.co.in']
# CC = ['vishwas.j@spoton.co.in']
BCC=['mahesh.reddy@spoton.co.in']
msg = MIMEMultipart()
msg["From"] = FROM
msg["To"] = ",".join(TO)
msg["CC"] = ",".join(CC)
msg["BCC"] = ",".join(BCC)
msg["Subject"] = "Vehicle Pileup Report - PLT : "+str(datetime.strftime(datetime.now(), '%Y-%m-%d-%H')) 


#s = Template(html).safe_substitute(mktcostperc=mktcostperc,mktcpk=mktcpk,mktspend=mktspend,mktcpky=mktcpky,mktspendy=mktspendy,date=today_date)
report=""
#report+=s
report+="Dear All"
report+='<br>'
report+='<br>'
report+="PFB Summary of Vehicle Pile up report for hubs :"
report+='<br>'
report+='<br>'+hub_veh_df.to_html()+'<br>'
report+='<br>'
report+='<br>'
report+="PFB Summary of Vehicle Pile up report for SC's :"
report+='<br>'
report+='<br>'+sc_veh_df.to_html()+'<br>'

#report+=html3
#depotpivot_std
abc=MIMEText(report,'html')
msg.attach(abc)
part = MIMEBase('application', "octet-stream")
part.set_payload( open(filepath,"rb").read() )
encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath))
msg.attach(part)

part1 = MIMEBase('application', "octet-stream")
part1.set_payload( open(filepath1,"rb").read() )
encoders.encode_base64(part1)
part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filepath1))
msg.attach(part1)

server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
server.quit()

# except:
#   TO=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
#   FROM="mahesh.reddy@spoton.co.in"
#   msg = MIMEMultipart()
#   msg["From"] = FROM
#   msg["To"] = ",".join(TO)
#   #msg["CC"] = ",".join(CC)
#   #msg["BCC"] = ",".join(BCC)
#   #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
#   msg["Subject"] = "ERROR Report" 
#   report=""
#   report+='Hi,'

#   report+='<br>'
#   report+='There was some error in Vehicle Pileup PLT Report All Location'
#   report+='<br>'

#   abc=MIMEText(report.encode('utf-8'),'html')
#   msg.attach(abc)
#   server=smtplib.SMTP('smtp.sendgrid.net', 587)
#   server.ehlo()
#   server.starttls()
#   server.ehlo()
#   server.login("spoton.net.in", "Star@123#")
#   failed = server.sendmail(FROM, TO, msg.as_string())
#   server.quit()




