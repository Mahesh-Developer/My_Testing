
# coding: utf-8

# In[ ]:

import pandas.io.sql
import sys
from sqlalchemy import create_engine, MetaData, Table, select
import pyodbc
from pandas import ExcelWriter
import smtplib
import pandas as pd
from datetime import datetime,timedelta
import sys
import pandas.io.sql
import pandas as pd
from email import Encoders
from email.MIMEBase import MIMEBase
from email.MIMEMultipart import MIMEMultipart
from email.Utils import formatdate
from email.mime.text import MIMEText
from email import encoders
from datetime import datetime, timedelta
import os
import glob
from string import Template
import numpy as np
import Utilities

# In[ ]:

reload(sys).setdefaultencoding("ISO-8859-1")


# In[ ]:
# try:
datetoday = datetime.now().date()
todayminus1 = datetoday-timedelta(days=1)
todayminus1=datetime.strftime(todayminus1,'%Y-%m-%d')
todayminus1


# In[ ]:

# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
# cursor = cnxn.cursor()
# cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.102;DATABASE=ESTL_CRP2;UID=PythonOnline;PWD=P@ssw0rd123$")
# cursor = cnxn.cursor()

# In[ ]:

#Delivery Efficiency Procedure
del_eff_query = ("""
        EXEC dbo.USP_DELV_EFF_SC_WISE_ALL 'S', '{0}','{1}'
       """.format(todayminus1,todayminus1))


# In[ ]:

del_eff_df = pd.read_sql_query(del_eff_query, Utilities.cnxn)
#print ('del_eff_df',del_eff_df)


# In[ ]:

del_eff_df_data=del_eff_df[del_eff_df['ControlArea']=='BLRA']


# In[ ]:

dedf = del_eff_df_data.groupby('BRNM').agg({'TOTAL':sum,'Delivered':sum}).reset_index()


# In[ ]:

dedf['DE%']=dedf['Delivered'].divide(dedf['TOTAL'])*100
dedf=dedf.replace([np.inf, -np.inf], np.nan)


# In[ ]:

#pickup procedure
pickpquery = ("""
        EXEC dbo.CRM_WEEKLY_PERFORMANCE_SCWISE_DATA_SHIVA_KPI  '{0}','{1}'
       """.format(todayminus1,todayminus1))


# In[ ]:
# print (pickpquery)
pickp_df=pd.read_sql(pickpquery,Utilities.cnxn)
# print (pickp_df)
pickp_df_data=pickp_df[pickp_df['ControlArea']=='BLRA']

#print (pickp_df_data)
pkdf = pickp_df_data.groupby(['BRNM']).agg({'Total_Pickups':sum,'Total_Success':sum}).reset_index()
pkdf['Pkp_Per%']=pkdf.apply(lambda x:pd.np.round((x['Total_Success']*1.0/x['Total_Pickups'])*100.0,2),axis=1)


# In[ ]:

dedf_pkdf=pd.merge(dedf,pkdf, on=['BRNM'],how='outer')
dedf_pkdf.fillna(0)
result_dedf_pkdf = dedf_pkdf[['BRNM','DE%','Pkp_Per%']]
result_dedf_pkdf.fillna(0)


# In[ ]:

#con image procedure
conimgquery = ("""
        EXEC USP_CON_IMAGE_KPI
        """)
conimg_df = pd.read_sql(conimgquery, Utilities.cnxn)
#conimg_df.to_csv(r'C:\Users\rajeeshv\Downloads\condata1.csv')
conimg_df_data= conimg_df[conimg_df['ControlArea']=='BLRA']
print (len(conimg_df_data))
conimg_df_data=conimg_df_data[~conimg_df_data["DOCKNO"].isin(["514166367 ","514287418 ","987677775 ","515134000 ","987667779 "])]
# conimg_df_data=conimg_df_data[np.logical_not(conimg_df_data["DOCKNO"].isin([514166367,514287418]))]
print (len(conimg_df_data))

# In[ ]:
if len(conimg_df_data)>0:
    conimg_df=conimg_df_data.rename(columns={'BOOKING_BRNAME':'BRNM'})
    conimg_df_pivot = pd.pivot_table(conimg_df,index=['BRNM'],values=['DOCKNO'],aggfunc=len).reset_index()
    conimg_df_pivot = conimg_df_pivot.fillna(0)
    conimg_df_pivot = conimg_df_pivot.rename(columns = {'DOCKNO':'ConImg_Cons'})
else:
    conimg_df_pivot = pd.DataFrame(columns=['BRNM','ConImg_Cons'])
    print (conimg_df_pivot)




# In[ ]:

#POD Forward procedure
forwardquery = ("""
        EXEC USP_POD_FORWARDING_REPORT_KPI
        """)
pod_df_fwd = pd.read_sql(forwardquery, Utilities.cnxn)
pod_df_forward_data = pod_df_fwd[pod_df_fwd['AREA']=='BLRA']


# In[ ]:

pod_df = pd.pivot_table(pod_df_forward_data,index=['BRNM'],values=['DelCon'],aggfunc=len).reset_index()


# In[ ]:

dedf_pkdf_conimg=pd.merge(result_dedf_pkdf,conimg_df_pivot, on=['BRNM'],how='outer')
dedf_pkdf_conimg_podforward = pd.merge(dedf_pkdf_conimg,pod_df,on=['BRNM'],how='outer')


# In[ ]:

dedf_pkdf_conimg_podforward  =dedf_pkdf_conimg_podforward.rename(columns={'BRNM':'Branch_Name','DelCon':'POD_FRWD_PENDING','Pkp_Per%':'PKP_Perf%','ConImg_Cons':'CON-IMG_PENDING'})
dedf_pkdf_conimg_podforward=dedf_pkdf_conimg_podforward.fillna(0)
dedf_pkdf_conimg_podforward = np.round(dedf_pkdf_conimg_podforward,decimals=1)
dedf_pkdf_conimg_podforward['CON-IMG_PENDING']=dedf_pkdf_conimg_podforward['CON-IMG_PENDING'].astype(int)
dedf_pkdf_conimg_podforward['POD_FRWD_PENDING']=dedf_pkdf_conimg_podforward['POD_FRWD_PENDING'].astype(int)
dedf_pkdf_conimg_podforward


# In[ ]:

with ExcelWriter(r'D:\Data\BLRA Performance Reports\BLRA_Performance_Metrics_Monitoring_'+str(todayminus1)+'.xlsx') as writer:
    dedf_pkdf_conimg_podforward.to_excel(writer, sheet_name='Final_Summary',engine='xlsxwriter',na_rep='NA')
    pod_df_forward_data.to_excel(writer, sheet_name='POD_fwd_Data',engine='xlsxwriter')
    conimg_df_data.to_excel(writer, sheet_name='Con_Img_Data',engine='xlsxwriter')
    del_eff_df_data.to_excel(writer, sheet_name='Delvry_Eff_Data',engine='xlsxwriter')
    pickp_df_data.to_excel(writer, sheet_name='Pickup_Data',engine='xlsxwriter')


# In[ ]:

filePath=r'D:\Data\BLRA Performance Reports\BLRA_Performance_Metrics_Monitoring_'+str(todayminus1)+'.xlsx'


# In[ ]:

from_addr = 'reports.ie@spoton.co.in'
to_addr = ['blr_pud_ops@spoton.co.in','sasikumar.kannan@spoton.co.in','sreekanth.s@spoton.co.in']
# to_addr = ['mahesh.reddy@spoton.co.in','vishwas.j@spoton.co.in']
cc_addr=['mahesh.reddy@spoton.co.in','rajesh.kumar@spoton.co.in','shivananda.p@spoton.co.in']
# cc_addr=['mahesh.reddy@spoton.co.in']
date=todayminus1
msg = MIMEMultipart()
msg["From"] = from_addr
msg["To"] = ",".join(to_addr)
msg["CC"] = ",".join(cc_addr)
#msg["BCC"] = ",".join(BCC)
msg["Subject"] = "Performance Metrics Monitoring-BLRA" + " - " + str(todayminus1)
html='''<html>
<h4>Hi All,</h4>
<h5>PFA the Performance Metrics Monitoring-BLRA : $date<h5>
</html>'''
s = Template(html).safe_substitute(date=date)
html1='''
    <h4>Below are the legends for the different sheets in the attachment</h4>
    <h4><p> </p></h4>
    <p><b>Final_Summary :</b> This will contain the trend of all the parameters daywise</p>
    <p><b>Delivery Efficiency Data:</b> This is the Delivery Efficiency data</p>
    <p><b>Pickup Data :</b> This sheet contains Pickups data</p>
    <p><b>ConImage Data :</b> This sheet contains ConImage data</p>
    <p><b>POD Data :</b> This sheet contains POD data</p>
</html>'''
report=""
report+=s
report+='<br>'
report+='<br>'+dedf_pkdf_conimg_podforward.to_html()+'<br>'
report+=html1
abc=MIMEText(report,'html')
msg.attach(abc)

part = MIMEBase('application', "octet-stream")
part.set_payload( open(filePath,"rb").read() )
Encoders.encode_base64(part)
part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filePath))
msg.attach(part)
server=smtplib.SMTP('smtp.sendgrid.net', 587)
server.ehlo()
server.starttls()
server.ehlo()
server.login("spoton.net.in", "Star@123#")
server.sendmail(from_addr,to_addr+cc_addr,msg.as_string())
server.quit()

# except:
#     TO=['shivananda.p@spoton.co.in','anitha.thyagarajan@spoton.co.in'] 
#     CC=['mahesh.reddy@spoton.co.in']
#     FROM="mahesh.reddy@spoton.co.in"
#     msg = MIMEMultipart()
#     msg["From"] = FROM
#     msg["To"] = ",".join(TO)
#     msg["CC"] = ",".join(CC)
#     #msg["BCC"] = ",".join(BCC)
#     #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
#     msg["Subject"] = "Performance Metrics Monitoring-BLRA Error in Execution" 
#     report=""
#     report+='Hi,'
#     report+='<br>'
#     report+='There was some error in Performance Metrics Monitoring-BLRA'
#     report+='<br>'
  
#     abc=MIMEText(report.encode('utf-8'),'html')
#     msg.attach(abc)
#     server=smtplib.SMTP('smtp.sendgrid.net', 587)
#     server.ehlo()
#     server.starttls()
#     server.ehlo()
#     server.login("spoton.net.in", "Star@123#")
#     failed = server.sendmail(FROM, TO+CC, msg.as_string())
#     server.quit()



# In[ ]:




# In[ ]:



