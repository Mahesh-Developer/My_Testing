
# coding: utf-8

# In[ ]:

import pandas as pd
from datetime import datetime
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
import os
import pyodbc
from string import Template
from email import *
import numpy as np
import Utilities

try:
  day_name=datetime.now()
  name_day=day_name.strftime("%A")

  # In[ ]:

  today=datetime.strftime(datetime.now(),'%Y-%m-%d')
  yestdate=datetime.strftime(datetime.now()-timedelta(1),'%Y-%m-%d')
  yestdateminus=datetime.strftime(datetime.now()-timedelta(2),'%Y-%m-%d')
  print (today,yestdate)


  # In[ ]:
  if name_day=='Tuesday':
  	print ('I am Tuesday')
  	clng_ful_df1=pd.read_csv(r'D:\Data\eta_rank\Destination_sc_closingstock\Jan2018_jun05_2018\Closing_Stock_Area_Summary_'+yestdateminus+'.csv')
  	dlry_ful_df1=pd.read_csv(r'D:\Data\eta_rank\Destination_sc_delivered\Jan2018_Jun05_2018\Delivered_Area_Summary_'+yestdateminus+'.csv')
  else:
  	print ('I am not Tuesday')
  	clng_ful_df1=pd.read_csv(r'D:\Data\eta_rank\Destination_sc_closingstock\Jan2018_jun05_2018\Closing_Stock_Area_Summary_'+yestdate+'.csv')
  	dlry_ful_df1=pd.read_csv(r'D:\Data\eta_rank\Destination_sc_delivered\Jan2018_Jun05_2018\Delivered_Area_Summary_'+yestdate+'.csv')

  fromdate=datetime.strftime(datetime.now()-timedelta(32),'%Y-%m-%d')
  yestdate=datetime.strftime(datetime.now()-timedelta(1),'%Y-%m-%d')


  # In[ ]:

  clng_ful_df=clng_ful_df1[clng_ful_df1['Timestamp']>=fromdate]

  dlry_ful_df=dlry_ful_df1[dlry_ful_df1['Timestamp']>=fromdate]


  # In[ ]:

  clng_ful_df.rename(columns={'ACTUWT':'Clsng_Wt'},inplace=True)
  dlry_ful_df.rename(columns={'ACTUWT':'Dlry_Wt'},inplace=True)

  clng_ful_df=pd.merge(clng_ful_df,dlry_ful_df,on=['DEST AREA','Timestamp'])

  clng_ful_df=clng_ful_df[clng_ful_df['Timestamp']!='2018-05-01']

  clng_ful_df=clng_ful_df[clng_ful_df['Timestamp']!='2018-06-15']

  clng_ful_df['Timestamp']=pd.to_datetime(clng_ful_df['Timestamp'])
  clng_ful_df['Day']=clng_ful_df['Timestamp'].dt.weekday


  # In[ ]:

  clng_ful_df=clng_ful_df[clng_ful_df['Day']!=6]
  clng_ful_df['Timestamp']=clng_ful_df['Timestamp'].astype(str)
  holiday_df=pd.read_csv(r'C:\Users\rajeeshv\Downloads\holidaylist.csv')
  holiday_df['HDAY_DATE']=holiday_df['HDAY_DATE'].apply(lambda x: x.split(' ')[0])

  cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
  cursor = cnxn.cursor()


  # In[ ]:

  query2 = ("""
          EXEC UBESP_PUD_ANALYSIS_OPEN_CLOSE_STOCK_ARRV_DELV_SSRS_DL
          """)

  dlvrydf=pd.read_sql(query2, Utilities.cnxn)
  dlvrydf.rename(columns={'CDELDT':'DUE DATE','DELY_DT':'DELY DT','ConStatusCode':'Con Status Code',
                          'DEL_LOCATION_TYPE':'DEL LOCATION TYPE','DEST_BRCD':'DEST BRCD','DEST_AREA':'DEST AREA'},inplace=True)


  # In[ ]:

  dlvrydf.columns


  # In[ ]:

  #last 7days delivery summary
  lastwk_area_dlvrydf=dlry_ful_df[dlry_ful_df['Timestamp']>=(datetime.strftime(datetime.now()-timedelta(8),"%Y-%m-%d"))]
  lastwk_area_dlvrydf['Timestamp']=pd.to_datetime(lastwk_area_dlvrydf['Timestamp'])
  lastwk_area_dlvrydf['Day']=lastwk_area_dlvrydf['Timestamp'].dt.weekday
  lastwk_area_dlvrydf1=lastwk_area_dlvrydf[lastwk_area_dlvrydf['Day']!=6]
  lastwk_area_dlvrydf1['Timestamp']=lastwk_area_dlvrydf1['Timestamp'].astype(str)

  lastwk_area_dlvrydf1['Uniq_Days']=1
  lastwk_area_dlvrydf1.rename(columns={'Dlry_Wt':'ACTUWT'},inplace=True)
  lastwk_area_dlry_pivot=lastwk_area_dlvrydf1.pivot_table(index=['DEST AREA'],values=['ACTUWT','Uniq_Days'],
                                                          aggfunc={'Uniq_Days':sum,'ACTUWT':sum}).reset_index()


  # In[ ]:

  lastwk_area_dlry_pivot.rename(columns={'ACTUWT':'Delivered'},inplace=True)
  lastwk_area_dlry_pivot['Delivered']=pd.np.round(lastwk_area_dlry_pivot['Delivered']/1000.0,0)
  lastwk_area_dlry_pivot['7Days_Dlvry(T)']=pd.np.round(lastwk_area_dlry_pivot['Delivered']/lastwk_area_dlry_pivot['Uniq_Days'],1)


  # In[ ]:

  #Merging Closig yest Wt with last 7days delivery wt
  #clsng_df=pd.read_excel(r'http://spoton.co.in/downloads/OCID/OCID.xls',sheetname='CLOSING STOCK')
  query3 = ("""
          EXEC UBESP_PUD_ANALYSIS_OPEN_CLOSE_STOCK_ARRV_DELV_SSRS_CS
          """)


  clsng_df=pd.read_sql(query3, Utilities.cnxn)

  print (len(clsng_df))
  print (clsng_df.columns)
  clsng_df.rename(columns={'DEST_AREA':'DEST AREA','DEST_BRCD':'DEST BRCD'},inplace=True)
  #drs_prepared=no
  clsng_df=clsng_df[clsng_df['DRS_PREPARED']=="NO"]
  clng_pivot=clsng_df.pivot_table(index=['DEST AREA'],values=['ACTUWT'],aggfunc={'ACTUWT':sum}).reset_index()
  #dlvrydf=pd.read_excel(r'http://spoton.co.in/downloads/OCID/OCID.xls',sheetname='DELIVERED')
  dlry_pivot=dlvrydf.pivot_table(index=['DEST AREA'],values=['ACTUWT'],aggfunc={'ACTUWT':sum}).reset_index()
  clng_pivot.rename(columns={'ACTUWT':'Closing_Stock'},inplace=True)
  dlry_pivot.rename(columns={'ACTUWT':'Delivered'},inplace=True)
  clng_pivot['Closing_Stock']=pd.np.round(clng_pivot['Closing_Stock']/1000.0,0)
  dlry_pivot['Delivered']=pd.np.round(dlry_pivot['Delivered']/1000.0,0)
  clng_pivot=pd.merge(clng_pivot,lastwk_area_dlry_pivot,on=['DEST AREA'])


  # In[ ]:

  clsng_df.columns


  # In[ ]:

  #Calculating Days of Stock Areawise
  clng_pivot['DaysOfStock']=pd.np.round(clng_pivot['Closing_Stock']/clng_pivot['7Days_Dlvry(T)'],1)
  clng_pivot=clng_pivot.replace([np.inf,-np.inf],np.nan).fillna(0)
  clng_pivot1=clng_pivot.sort_values('DaysOfStock',ascending=False)
  #clng_pivot1=clng_pivot[clng_pivot['DaysOfStock']>=1.8].sort_values('Closing_Stock',ascending=False)
  clng_pivot1=clng_pivot1.reset_index()


  # In[ ]:




  # In[ ]:

  datetoday = datetime.now().date()
  todayminus1 = datetoday-timedelta(days=1)
  todayminus1=datetime.strftime(todayminus1,'%Y-%m-%d')
  todayminus1


  # In[ ]:

  #Calculating Delivery Efficiency
  cnxn = pyodbc.connect("DRIVER={SQL Server};SERVER=10.109.230.18\estl,49280;DATABASE=ESTL_CRP2;UID=sa;PWD=password@123")
  cursor = cnxn.cursor()
  #Delivery Efficiency Procedure
  del_eff_query = ("""
          EXEC dbo.USP_DELV_EFF_SC_WISE_ALL 'S', '{0}','{1}'
         """.format(todayminus1,todayminus1))
  del_eff_df = pd.read_sql_query(del_eff_query, Utilities.cnxn)


  # In[ ]:

  area_dedf = del_eff_df.groupby('ControlArea').agg({'TOTAL':sum,'Delivered':sum}).reset_index()


  # In[ ]:

  area_dedf['DE%']=area_dedf['Delivered'].divide(area_dedf['TOTAL'])*100
  area_dedf=area_dedf.replace([np.inf, -np.inf], np.nan)


  # In[ ]:

  area_dedf['DE%']=pd.np.round(area_dedf['DE%'],1)


  # In[ ]:

  area_dedf.rename(columns={'ControlArea':'DEST AREA'},inplace=True)


  # In[ ]:

  clng_pivot1


  # In[ ]:

  area_dedf


  # In[ ]:

  clng_pivot1=pd.merge(clng_pivot1,area_dedf,on='DEST AREA',how='left')


  # In[ ]:

  clng_pivot1=clng_pivot1[['DEST AREA','Closing_Stock','7Days_Dlvry(T)','DaysOfStock','DE%']]


  # In[ ]:

  clng_pivot2=clng_pivot1.head()
  #del clng_pivot2['index']
  clng_pivot2['Closing_Stock']=pd.np.round(clng_pivot2['Closing_Stock'],1)


  # In[ ]:

  clng_pivot2=clng_pivot2.fillna(0)


  # In[ ]:

  clng_pivot2.head()


  # In[ ]:

  reportts = datetime.now()
  opfilevar=reportts.date()
  opfilevar1=reportts.time()
  ct2= str (opfilevar1)
  currhrs=(sum(float(x) * 60 ** i for i,x in enumerate(reversed(ct2.split(":")))))/60

  opfilevar2=pd.np.round((float(currhrs)/60),0)


  # In[ ]:

  yestdate


  # In[ ]:

  #last sevendays sc delivery
  if name_day=='Tuesday':
  	sc_summary=pd.read_csv(r'D:\Data\eta_rank\Destination_sc_delivered\Jan2018_Jun05_2018\Delivered_SC_Summary_'+yestdateminus+'.csv')
  else:
  	sc_summary=pd.read_csv(r'D:\Data\eta_rank\Destination_sc_delivered\Jan2018_Jun05_2018\Delivered_SC_Summary_'+yestdate+'.csv')
  #sc_summary=pd.read_csv(r'D:\Data\eta_rank\Destination_sc_delivered\Jan2018_Jun05_2018\Delivered_SC_Summary_'+('2018-07-05')+'.csv')

  len(sc_summary)
  sc_summary1=sc_summary[sc_summary['Timestamp']>=(datetime.strftime(datetime.now()-timedelta(8),"%Y-%m-%d"))]
  sc_summary1['Timestamp']=pd.to_datetime(sc_summary1['Timestamp'])
  sc_summary1['Day']=sc_summary1['Timestamp'].dt.weekday
  sc_summary2=sc_summary1[sc_summary1['Day']!=6]
  sc_summary2['Timestamp']=sc_summary2['Timestamp'].astype(str)


  # In[ ]:

  sc_summary2['Uniq_Days']=1


  # In[ ]:

  #sc closing stock master 
  if name_day=='Tuesday':
  	sc_clsng_stock_summary=pd.read_csv(r'D:\Data\eta_rank\Destination_sc_closingstock\Jan2018_jun05_2018\Closing_Stock_SC_Summary_'+yestdateminus+'.csv')
  else:
  	sc_clsng_stock_summary=pd.read_csv(r'D:\Data\eta_rank\Destination_sc_closingstock\Jan2018_jun05_2018\Closing_Stock_SC_Summary_'+yestdate+'.csv')
  #sc_clsng_stock_summary=pd.read_csv(r'D:\Data\eta_rank\Destination_sc_closingstock\Jan2018_jun05_2018\Closing_Stock_SC_Summary_'+('2018-07-05')+'.csv')


  # In[ ]:

  #calculating days of stock sc wise
  lastwk_sc_summary=pd.pivot_table(sc_summary2,index=['DEST BRCD'],values=['ACTUWT','Uniq_Days'],aggfunc={'ACTUWT':sum,'Uniq_Days':sum}).reset_index()
  #print (lastwk_sc_summary)

  lastwk_sc_summary['ACTUWT']=pd.np.round(lastwk_sc_summary['ACTUWT']/1000.0,1)

  #yester closing stock sc wise

  yest_Clsng_summary=clsng_df.pivot_table(index=['DEST BRCD'],values=['ACTUWT'],aggfunc={'ACTUWT':sum}).reset_index()
  yest_Clsng_summary['ACTUWT']=pd.np.round(yest_Clsng_summary['ACTUWT']/1000.0,1)

  yest_Clsng_summary.rename(columns={'ACTUWT':'Yest_Clsng_Wt(T)'},inplace=True)
  lastwk_sc_summary.rename(columns={'ACTUWT':'7Days_Dlvry_Wt(T)'},inplace=True)


  # In[ ]:

  yest_Clsng_summary=pd.merge(yest_Clsng_summary,lastwk_sc_summary,on='DEST BRCD')
  yest_Clsng_summary['7Days_Dlvry_Wt(T)']=pd.np.round(yest_Clsng_summary['7Days_Dlvry_Wt(T)']/yest_Clsng_summary['Uniq_Days'],1)


  # In[ ]:

  sc_final_summary=pd.DataFrame()
  for i in yest_Clsng_summary['DEST BRCD'].unique().tolist():
      result_df=yest_Clsng_summary[yest_Clsng_summary['DEST BRCD']==i]
      result_df['DaysOfStock']=pd.np.round(result_df['Yest_Clsng_Wt(T)']/result_df['7Days_Dlvry_Wt(T)'],1)
      sc_final_summary=pd.concat([sc_final_summary,result_df],ignore_index=True)


  # In[ ]:

  len(sc_final_summary)


  # In[ ]:

  current_stock_df=pd.read_csv(r'D:\Data\Stock_at_origin_hourly\Origin_Hourly_Stock_'+str(today)+'_4.0.csv')


  # In[ ]:

  current_stock_pivot=current_stock_df.pivot_table(index=['ORGBRCD'],values=['ACTUWT'],aggfunc={'ACTUWT':sum}).reset_index()


  # In[ ]:

  current_stock_pivot['Current_Wt(T)']=pd.np.round(current_stock_pivot['ACTUWT']/1000.0,1)


  # In[ ]:

  current_stock_pivot.rename(columns={'ORGBRCD':'DEST BRCD'},inplace=True)


  # In[ ]:

  #adding current stock to yest closing stock
  sc_final_summary=pd.merge(sc_final_summary,current_stock_pivot,on='DEST BRCD')


  # In[ ]:

  len(sc_final_summary)


  # In[ ]:

  sc_final_summary['Total_Stock_Wt(T)']=sc_final_summary['Yest_Clsng_Wt(T)']+sc_final_summary['Current_Wt(T)']


  # In[ ]:

  # calculating Delivery Efficiency for SCwise
  sc_dedf = del_eff_df.groupby('DEST_BRCD').agg({'TOTAL':sum,'Delivered':sum}).reset_index()


  # In[ ]:

  sc_dedf['DE%']=sc_dedf['Delivered'].divide(sc_dedf['TOTAL'])*100
  sc_dedf=sc_dedf.replace([np.inf, -np.inf], np.nan)


  # In[ ]:

  sc_dedf['DE%']=pd.np.round(sc_dedf['DE%'],1)


  # In[ ]:

  sc_dedf.rename(columns={'DEST_BRCD':'DEST BRCD'},inplace=True)


  # In[ ]:

  sc_dedf


  # In[ ]:

  sc_final_summary=pd.merge(sc_final_summary,sc_dedf,on='DEST BRCD',how='left')


  # In[ ]:

  len(sc_final_summary)


  # In[ ]:

  sc_final_summary=sc_final_summary.fillna(0)


  # In[ ]:

  spacedf=pd.read_csv(r'C:\Users\rajeeshv\Downloads\Location_capacity.csv')
  spacedf.rename(columns={'DEST':'DEST BRCD'},inplace=True)


  # In[ ]:

  len(spacedf)


  # In[ ]:

  spacedf=spacedf[spacedf['Storage_capacity in Tonnes']!=0]


  # In[ ]:

  #calculating space utilization
  sc_final_summary=sc_final_summary.replace([np.inf,-np.inf],np.nan).fillna(0) 
  sc_final_summary=pd.merge(sc_final_summary,spacedf,on='DEST BRCD',how='left')


  # In[ ]:

  len(sc_final_summary)


  # In[ ]:

  sc_final_summary['Space_Util%']=pd.np.round(sc_final_summary['Total_Stock_Wt(T)']*100.0/sc_final_summary['Storage_capacity in Tonnes'],1)   
  sc_final_summary=sc_final_summary.replace([-np.inf,np.inf],np.nan).fillna(0)
  sc_final_summary=sc_final_summary.sort_values(['Space_Util%','DaysOfStock'],ascending=[False,False])


  # In[ ]:

  sc_final_summary.head()


  # In[ ]:

  sc_final_summary=sc_final_summary[['DEST BRCD','Yest_Clsng_Wt(T)','7Days_Dlvry_Wt(T)','DaysOfStock','Current_Wt(T)','Total_Stock_Wt(T)','DE%','Space_Util%']]


  # In[ ]:

  branch_df=pd.read_excel(r'C:\Users\rajeeshv\Downloads\Branch_master.xlsx')[['SC-Code','Type of branch']]


  # In[ ]:

  len(branch_df)


  # In[ ]:

  branch_df.rename(columns={'SC-Code':'DEST BRCD'},inplace=True)


  # In[ ]:

  sc_final_summary['Type']=sc_final_summary['DEST BRCD'].map(branch_df.set_index('DEST BRCD')['Type of branch'])


  # In[ ]:

  sc_final_summary['Type'].unique()


  # In[ ]:

  #Getting VB Branch list
  hub_df=pd.read_excel(r'D:\Python\Scripts and Files\Python Scripts\Timegraph\Hublist.xlsx')


  # In[ ]:

  def getType(brcd,brtype):
      if brcd in hub_df['VB'].unique().tolist():
          return "VB"
      elif (brtype=="BA")or(brtype=="PUD"):
          return "BA-PUD"
      else:
          return "Own"


  # In[ ]:

  sc_final_summary['BR_TYPE']=sc_final_summary.apply(lambda x: getType(x['DEST BRCD'],x['Type']),axis=1)


  # In[ ]:

  len(sc_final_summary)


  # In[ ]:

  sc_final_summary=sc_final_summary.drop_duplicates('DEST BRCD')


  # In[ ]:

  len(sc_final_summary)


  # In[ ]:

  sc_final_summary.columns


  # In[ ]:

  sc_final_summary['BR_TYPE'].unique()


  # In[ ]:

  from datetime import date


  # In[ ]:

  querydate=date.today()-timedelta(1)


  # In[ ]:

  query4=("""EXEC dbo.USP_DELV_EFF_SC_WISE_ALL 'S', '{0}' , '{1}'""".format(querydate,querydate))
  query4


  # In[ ]:

  data=pd.read_sql(query4,Utilities.cnxn)


  # In[ ]:

  len(data)


  # In[ ]:

  data.columns


  # In[ ]:

  data.head()


  # In[ ]:

  data.rename(columns={'CCF': 'CCF_without_DRS_block'}, inplace=True)
  data.rename(columns={'NON-CCF': 'STF'}, inplace=True)
  data = data.reset_index()
  data['CCF']=data['DRS_BLOCK'] + data['CCF_without_DRS_block']


  # In[ ]:

  ccf_pivot=pd.pivot_table(data,index=["DEST_BRCD",],values=["TOTAL","Delivered","NCF","STF","CCF","DEPS"],
                       aggfunc={"TOTAL":sum,"Delivered":sum,"NCF":sum,"STF":sum,"CCF":sum,"DEPS":sum}).reset_index()


  # In[ ]:

  ccf_pivot.head()


  # In[ ]:

  ccf_pivot['STF%'] = pd.np.round((ccf_pivot['STF']/ ccf_pivot['TOTAL'])*100)
  ccf_pivot['NCF%']= pd.np.round((ccf_pivot['NCF'] / ccf_pivot['TOTAL'])*100)
  ccf_pivot['CCF%']= pd.np.round((ccf_pivot['CCF'] / ccf_pivot['TOTAL'])*100)


  # In[ ]:

  ccf_pivot.rename(columns={'DEST_BRCD':'DEST BRCD'},inplace=True)


  # In[ ]:

  sc_final_summary=pd.merge(sc_final_summary,ccf_pivot,on='DEST BRCD',how='left')


  # In[ ]:

  sc_final_summary.head()


  # In[ ]:

  vb_sc_final_summary=sc_final_summary[sc_final_summary['BR_TYPE']=='VB'][['DEST BRCD','Total_Stock_Wt(T)',
                                                                            'DaysOfStock','DE%','CCF%','STF%','NCF%','Space_Util%']]


  # In[ ]:

  len(vb_sc_final_summary)


  # In[ ]:

  vb_sc_final_summary1=vb_sc_final_summary.head(10)


  # In[ ]:

  vb_sc_final_summary1


  # In[ ]:

  own_sc_final_summary=sc_final_summary[sc_final_summary['BR_TYPE']=='Own'][['DEST BRCD','Total_Stock_Wt(T)','7Days_Dlvry_Wt(T)',
                                                                            'DaysOfStock','DE%','CCF%','STF%','NCF%','Space_Util%']]


  # In[ ]:

  len(own_sc_final_summary)


  # In[ ]:

  own_sc_final_summary


  # In[ ]:

  own_sc_final_summary1=own_sc_final_summary.head(10)


  # In[ ]:

  bapud_sc_final_summary=sc_final_summary[sc_final_summary['BR_TYPE']=='BA-PUD'][['DEST BRCD','Total_Stock_Wt(T)',
                                                                            'DaysOfStock','DE%','CCF%','STF%','NCF%','Space_Util%']]


  # In[ ]:

  len(bapud_sc_final_summary)


  # In[ ]:

  bapud_sc_final_summary1=bapud_sc_final_summary.head(10)


  # In[ ]:

  sc_final_summary.to_csv(r'D:\Data\Day of Stock\DaysOfStock_SC'+str(opfilevar)+'.csv')
  sc_final_summary.to_csv(r'D:\Data\Day of Stock\DaysOfStock_SC.csv')

  clng_pivot1.to_csv(r'D:\Data\Day of Stock\DaysOfStock_Area'+str(opfilevar)+'.csv')
  clng_pivot1.to_csv(r'D:\Data\Day of Stock\DaysOfStock_Area.csv')

  oppath1=r'D:\Data\Day of Stock\DaysOfStock_SC.csv'
  oppath2=r'D:\Data\Day of Stock\DaysOfStock_Area.csv'


  # In[ ]:

  from email.mime.multipart import MIMEMultipart
  from email.mime.text import MIMEText
  from email.mime.image import MIMEImage
  from email.mime.base import MIMEBase


  # In[ ]:

  TO=['aom_spot@spoton.co.in','dom_spot@spoton.co.in','rom_spot@spoton.co.in','sqtf@spoton.co.in']
  #TO=['mahesh.reddy@spoton.co.in']
  CC=['abhik.mitra@spoton.co.in','satya.pal@spoton.co.in','pawan.sharma@spoton.co.in','vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
  #CC=['mahesh.reddy@spoton.co.in']
  BCC=['mahesh.reddy@spoton.co.in']
  FROM='reports.ie@spoton.co.in'
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  msg["CC"] = ",".join(CC)
  msg["BCC"] = ",".join(BCC)

  msg["Subject"] = "Days Of Stock Report -" + str(opfilevar)
  html='''<html>
  <h4>Dear All,</h4>
  </html>'''
  report=""
  report+='Dear All,'
  report+='<br>'
  report+='<br>'
  report+='PFA Days Of Stock Summary'
  report+='<br>'
  report+='<br>'
  report+='Days Of Stock Area Wise'
  report+='<br>'
  report+='<br>'+clng_pivot2.to_html()+'<br>'
  report+='<br>'
  report+='Days Of Stock Own Branch Wise'
  report+='<br>'
  report+='<br>'+own_sc_final_summary1.to_html()+'<br>'
  report+='<br>'
  report+='Days Of Stock Virtual Branch Wise'
  report+='<br>'
  report+='<br>'+vb_sc_final_summary1.to_html()+'<br>'

  report+='<br>'
  report+='Days Of Stock BA-PUD Branch Wise'
  report+='<br>'
  report+='<br>'+bapud_sc_final_summary1.to_html()+'<br>'

  abc=MIMEText(report,'html')
  msg.attach(abc)
  part = MIMEBase('application', "octet-stream")
  part.set_payload( open(oppath1,"rb").read() )
  encoders.encode_base64(part)
  part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath1))
  msg.attach(part)

  part1 = MIMEBase('application', "octet-stream")
  part1.set_payload( open(oppath2,"rb").read() )
  encoders.encode_base64(part1)
  part1.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(oppath2))
  msg.attach(part1)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO+CC+BCC, msg.as_string())
  server.quit()


  # In[ ]:

  #adding yester day closing stock and delivered summary to Master data

  checkday=datetime.strftime(datetime.now()-timedelta(1),'%Y-%m-%d')
  clsng_df['Timestamp']=datetime.strftime(datetime.now()-timedelta(1),'%Y-%m-%d')

  daily_clsng_pivot=pd.pivot_table(clsng_df,index=['Timestamp','DEST AREA'],values=['ACTUWT'],aggfunc={'ACTUWT':sum}).reset_index()
  dlvrydf['Timestamp']=datetime.strftime(datetime.now()-timedelta(1),'%Y-%m-%d')
  daily_dlvry_pivot=pd.pivot_table(dlvrydf,index=['Timestamp','DEST AREA'],values=['ACTUWT'],aggfunc={'ACTUWT':sum}).reset_index()
  clng_ful_df1=pd.concat([clng_ful_df1,daily_clsng_pivot],ignore_index=True)
  dlry_ful_df1=pd.concat([dlry_ful_df1,daily_dlvry_pivot],ignore_index=True)
  dlry_ful_df1.to_csv(r'D:\Data\eta_rank\Destination_sc_delivered\Jan2018_Jun05_2018\Delivered_Area_Summary_'+today+'.csv')
  clng_ful_df1.to_csv(r'D:\Data\eta_rank\Destination_sc_closingstock\Jan2018_jun05_2018\Closing_Stock_Area_Summary_'+today+'.csv')
  daily_dlvry_sc_pivot=pd.pivot_table(dlvrydf,index=['Timestamp','DEST BRCD'],values=['ACTUWT'],aggfunc={'ACTUWT':sum}).reset_index()
  sc_summary=pd.concat([sc_summary,daily_dlvry_sc_pivot],ignore_index=True)
  sc_summary
  sc_summary.to_csv(r'D:\Data\eta_rank\Destination_sc_delivered\Jan2018_Jun05_2018\Delivered_SC_Summary_'+today+'.csv')
  daily_clsng_sc_pivot=pd.pivot_table(clsng_df,index=['Timestamp','DEST BRCD'],values=['ACTUWT'],aggfunc={'ACTUWT':sum}).reset_index()
  sc_clsng_stock_summary=pd.concat([sc_clsng_stock_summary,daily_clsng_sc_pivot],ignore_index=True)
  sc_clsng_stock_summary
  sc_clsng_stock_summary.to_csv(r'D:\Data\eta_rank\Destination_sc_closingstock\Jan2018_jun05_2018\Closing_Stock_SC_Summary_'+today+'.csv')


except:
  TO=['vishwas.j@spoton.co.in','mahesh.reddy@spoton.co.in']
  FROM="mahesh.reddy@spoton.co.in"
  msg = MIMEMultipart()
  msg["From"] = FROM
  msg["To"] = ",".join(TO)
  #msg["CC"] = ",".join(CC)
  #msg["BCC"] = ",".join(BCC)
  #msg["Subject"] = "DELIVERY EFFICIENCY" + " - " + str(opfilevar)
  msg["Subject"] = "ERROR Report" 
  report=""
  report+='Hi,'

  report+='<br>'
  report+='There was some error in DaysOfStock'
  report+='<br>'
  
  abc=MIMEText(report.encode('utf-8'),'html')
  msg.attach(abc)
  server=smtplib.SMTP('smtp.sendgrid.net', 587)
  server.ehlo()
  server.starttls()
  server.ehlo()
  server.login("spoton.net.in", "Star@123#")
  failed = server.sendmail(FROM, TO, msg.as_string())
  server.quit()

